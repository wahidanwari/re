# Monthly Group Reports Implementation

## Overview

This document describes the implementation of the Monthly Group Reports system, which provides deterministic and auditable aggregation of KPIs per group per month.

## Completed Components

### 1. Database Schema

**Migration:** `migrations/030_monthly_group_reports.sql`

- Added `monthly_tax_target` field to `groups` table (optional numeric field)
- Created `monthly_group_reports` table with all required fields
- Created `monthly_report_anomalies` table for tracking data quality issues

**Schema Updates:** `shared/schema.ts`

- Added `monthlyGroupReports` and `monthlyReportAnomalies` table definitions
- Added `monthlyTaxTarget` field to `groups` table
- Added TypeScript types and insert schemas

### 2. Backend Service

**Service:** `server/services/monthlyGroupReportService.ts`

Implements all required calculations:

- **distributed_count**: Cases created/distributed to group during month
- **finalized_count**: Cases completed during month
- **under_review_count**: distributed_count - finalized_count (clamped to 0 if negative)
- **collected_amount**: Sum of:
  - `collectedCurrentMonth` from `caseReportsV2` for completed cases
  - `amountPaid` from `installmentPayments` during the month
- **installments_count**: Distinct cases with installment payments
- **nonresponsive_count**: Cases sent to law enforcement (via `caseStatusTransitions`)
- **percent_of_target**: (collected_amount / monthly_tax_target) * 100 (null if target not set)

**Features:**
- Automatic anomaly detection (negative under_review_count, missing target, high percentage)
- Contributing case/payment tracking for audit trail
- Deterministic calculations using exact date ranges

### 3. Storage Methods

**File:** `server/storage.ts`

Added methods:
- `getMonthlyGroupReport(groupId, monthNumber, year)`
- `upsertMonthlyGroupReport(report)`
- `getMonthlyReportAnomalies(reportId)`
- `updateGroupMonthlyTaxTarget(groupId, target)`

### 4. API Endpoints

**File:** `server/routes/monthlyReports.ts`

Endpoints:
- `GET /api/reports/monthly?groupId=X&year=YYYY&month=MM` - Get report with breakdown
- `POST /api/reports/monthly/compute` - Compute/regenerate report
- `PUT /api/reports/monthly/:reportId/manual-override` - Manual field override (with audit trail)
- `PUT /api/reports/monthly/groups/:groupId/monthly-tax-target` - Update group target

**Permissions:**
- View: `reports:view` (senior auditors can only see their group)
- Compute: `reports:generate`
- Override: `reports:override`
- Manage targets: `groups:manage`

### 5. Tab Filter Fixes

**File:** `client/src/pages/Cases.tsx`

- Fixed "قضایای تازه اختصاص داده شده" tab to include `PENDING_REVIEW_BY_SENIOR_AUDITOR` status
- Fixed "قضایای در اقساط" tab to use `CaseStatus.INSTALLMENT` constant
- Fixed "قضایای ارسال‌شده به تنفیذ قانون" tab to use `CaseStatus.SENT_TO_LAW_ENFORCEMENT` constant

## Completed Components

### 1. Frontend UI ✅

**File:** `client/src/components/reports/MonthlyGroupReportTab.tsx`

**Features Implemented:**
- ✅ Group selector (filtered by user permissions)
- ✅ Month/year selector (Shamsi calendar)
- ✅ Display aggregated values with breakdown
- ✅ Show anomalies/warnings
- ✅ Report breakdown modal with:
  - List of distributed cases
  - List of finalized cases with collected amounts
  - List of installment payments
  - List of nonresponsive cases
- ✅ Manual override dialog with:
  - Field selector (distributedCount, finalizedCount, underReviewCount, collectedAmount)
  - Value input
  - Reason textarea
  - Audit trail (stored in manualOverrides JSONB)
- ✅ Group target configuration dialog
- ✅ Integrated into Reports page as new tab

### 2. Monthly Aggregation Job ✅

**File:** `server/scripts/monthlyAggregationJob.ts`

**Features:**
- ✅ Computes reports for specified month/year (or previous month by default)
- ✅ Processes all active groups
- ✅ Logs results and errors
- ✅ Provides summary report

**Usage:**
```bash
# Process previous month (default)
node -r ts-node/register server/scripts/monthlyAggregationJob.ts

# Process specific month/year
node -r ts-node/register server/scripts/monthlyAggregationJob.ts 1 1404
```

**Integration:** Can be scheduled via cron or run manually

### 3. Additional Audit Logging ✅

Already implemented in:
- ✅ Report computation
- ✅ Manual overrides
- ✅ Target updates

## Remaining Work

### 1. Tests

**Unit Tests:**
- `tests/monthly-report-calculations.test.ts` - Test calculation logic with synthetic data

**Integration Tests:**
- `tests/monthly-report-e2e.test.ts` - End-to-end: create cases → complete → payments → compute → verify

**Frontend Tests:**
- Tab visibility for PENDING_REVIEW_BY_SENIOR_AUDITOR
- Tab visibility for INSTALLMENT and SENT_TO_LAW_ENFORCEMENT

### 2. Export Functionality

**Optional Enhancement:**
- Add CSV/Excel export for monthly reports
- Include breakdown data in export

## Usage Examples

### Compute Monthly Report

```typescript
import { upsertMonthlyReport } from './services/monthlyGroupReportService';

const report = await upsertMonthlyReport(
  'group-id',
  1, // حمل (month number 1-12)
  1404, // Shamsi year
  'user-id'
);
```

### Get Report Breakdown

```typescript
import { getMonthlyReportBreakdown } from './services/monthlyGroupReportService';

const breakdown = await getMonthlyReportBreakdown(
  'group-id',
  1, // حمل
  1404
);

console.log(breakdown.report.collectedAmount);
console.log(breakdown.distributedCases.length);
console.log(breakdown.anomalies);
```

## Assumptions & Defaults

1. **Monthly Tax Target**: Optional field. If not set, `percent_of_target` is null and a warning is logged.

2. **Date Boundaries**: Uses Afghan solar calendar months. Month boundaries calculated using `jalaali-js`.

3. **Collected Amount**: 
   - Primary source: `caseReportsV2.collectedCurrentMonth` for completed cases
   - Secondary source: `installmentPayments.amountPaid` for payments during month
   - If case report missing collected amount, only installment payments are counted (logged as anomaly)

4. **Negative Under Review Count**: Clamped to 0 with error-level anomaly logged.

5. **High Percentage Warning**: Triggered when `percent_of_target > 300%`.

## Configuration

### Setting Group Monthly Tax Target

Via API:
```bash
PUT /api/reports/monthly/groups/:groupId/monthly-tax-target
Body: { "monthlyTaxTarget": 1000000 }
```

Via UI: (To be implemented in Groups management page)

## Anomaly Types

1. **negative_under_review**: Calculated under_review_count < 0 (data inconsistency)
2. **missing_target**: Group has no monthly_tax_target configured
3. **high_percentage**: percent_of_target > 300% (verify calculations)
4. **data_inconsistency**: Other data quality issues

## Next Steps

1. Implement frontend UI components
2. Create monthly aggregation cron job
3. Add comprehensive test suite
4. Add export functionality (CSV/Excel)
5. Add admin anomaly review page

