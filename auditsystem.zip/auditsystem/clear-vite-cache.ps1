# Clear Vite cache to fix HMR issues after deleting files
Write-Host "Clearing Vite cache..."

# Clear node_modules/.vite if it exists
if (Test-Path "node_modules\.vite") {
    Remove-Item -Recurse -Force "node_modules\.vite"
    Write-Host "✓ Cleared node_modules/.vite"
} else {
    Write-Host "  No node_modules/.vite cache found"
}

# Clear .vite in root if it exists
if (Test-Path ".vite") {
    Remove-Item -Recurse -Force ".vite"
    Write-Host "✓ Cleared .vite"
} else {
    Write-Host "  No .vite cache found"
}

# Clear dist if it exists (optional, but helps)
if (Test-Path "dist") {
    Remove-Item -Recurse -Force "dist"
    Write-Host "✓ Cleared dist folder"
} else {
    Write-Host "  No dist folder found"
}

Write-Host ""
Write-Host "Cache cleared! Please restart your dev server."
Write-Host "Press any key to exit..."
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")

