# Entity Case Creation Feature Implementation

## Overview
This document describes the implementation of the feature that ensures the "ایجاد قضیه" (Create Case) button in the Entity Management module correctly pre-populates the case creation form with the selected entity data.

## Implementation Date
2025-01-XX

## Problem Statement
Previously, clicking the "ایجاد قضیه" button from the Entity Management module would navigate to the case creation form, but the form would not automatically load the selected entity. Users had to manually search and select the entity again, leading to a poor user experience.

## Solution Overview
The implementation includes all five suggested approaches:
1. **Direct Entity Linking** - Entity ID is passed via URL query parameter
2. **Form Initialization Service** - Service fetches entity data when form loads
3. **UI Feedback / Pre-selection** - Visual indicator shows which entity is selected
4. **Validation / Error Handling** - Comprehensive error handling for entity loading
5. **Audit Logging / Traceability** - Backend captures entity source in audit logs

## Technical Implementation

### A. Direct Entity Linking

**Location:** `client/src/pages/Entities.tsx`

The "ایجاد قضیه" button now passes the entity ID via URL query parameter:
```typescript
setLocation(`/cases?createForEntity=${entity.id}`);
```

**Location:** `client/src/pages/Cases.tsx`

URL parameter detection:
```typescript
const urlParams = new URLSearchParams(window.location.search);
const createForEntityId = urlParams.get('createForEntity');
const [preSelectedEntityId, setPreSelectedEntityId] = useState<string | null>(createForEntityId);
```

### B. Form Initialization Service

**Location:** `client/src/pages/Cases.tsx`

Added React Query hook to fetch entity data:
```typescript
const { data: preSelectedEntity, isLoading: isLoadingPreSelectedEntity, error: preSelectedEntityError } = useQuery<Entity>({
  queryKey: ['entity', preSelectedEntityId],
  queryFn: async () => {
    if (!preSelectedEntityId) return null;
    const response = await fetch(`/api/entities/${preSelectedEntityId}`, { credentials: 'include' });
    if (!response.ok) {
      if (response.status === 404) {
        throw new Error('نهاد یافت نشد');
      }
      if (response.status === 403) {
        throw new Error('عدم دسترسی - شما مجوز لازم را ندارید');
      }
      throw new Error('خطا در بارگذاری اطلاعات نهاد');
    }
    return response.json();
  },
  enabled: !authLoading && !!currentUser && !!preSelectedEntityId,
  retry: 1,
});
```

Auto-population effect:
```typescript
useEffect(() => {
  if (preSelectedEntity && !dialogOpen) {
    // Open dialog automatically
    setDialogOpen(true);
    
    // Pre-populate form with entity data
    setSelectedEntity(preSelectedEntity);
    setFormData({
      caseId: '',
      entityId: preSelectedEntity.id,
      tin: preSelectedEntity.tin || '',
      groupReferrer: preSelectedEntity.referralGroup || '',
      receivingGroup: '',
      periodsUnderReview: preSelectedEntity.periodsUnderReview || preSelectedEntity.yearsUnderReview || '',
      referralDate: '',
      notes: '',
    });
    setTinInput(preSelectedEntity.tin || '');
    
    // Clear URL parameter after loading
    const newUrl = window.location.pathname;
    window.history.replaceState({}, '', newUrl);
    setPreSelectedEntityId(null);
    
    toast({
      title: 'نهاد انتخاب شده',
      description: `قضیه برای نهاد "${preSelectedEntity.companyName}" ایجاد می‌شود`,
    });
  }
}, [preSelectedEntity, dialogOpen, toast]);
```

### C. UI Feedback / Pre-selection

**Location:** `client/src/pages/Cases.tsx`

Added visual indicator in the case creation dialog:
```typescript
{/* UI Feedback / Pre-selection - Show selected entity */}
{selectedEntity && (
  <div className="p-4 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg mb-4">
    <div className="flex items-start gap-3">
      <div className="flex-1">
        <div className="flex items-center gap-2 mb-2">
          <Badge variant="default" className="bg-blue-600">
            نهاد انتخاب شده
          </Badge>
        </div>
        <div className="text-sm space-y-1">
          <div className="font-semibold text-blue-900 dark:text-blue-100">
            {selectedEntity.companyName}
          </div>
          <div className="text-blue-700 dark:text-blue-300">
            نمبر تشخیصیه: {selectedEntity.tin}
          </div>
          {selectedEntity.businessNature && (
            <div className="text-blue-600 dark:text-blue-400">
              ماهیت تشبث: {selectedEntity.businessNature}
            </div>
          )}
          {selectedEntity.referralGroup && (
            <div className="text-blue-600 dark:text-blue-400">
              گروه ارجاع‌دهنده: {selectedEntity.referralGroup}
            </div>
          )}
        </div>
      </div>
    </div>
  </div>
)}
```

### D. Validation / Error Handling

**Location:** `client/src/pages/Cases.tsx`

Error handling for entity loading:
```typescript
useEffect(() => {
  if (preSelectedEntityError) {
    const errorMessage = preSelectedEntityError instanceof Error 
      ? preSelectedEntityError.message 
      : 'خطا در بارگذاری اطلاعات نهاد';
    setEntityLoadError(errorMessage);
    
    toast({
      title: 'خطا',
      description: errorMessage,
      variant: 'destructive',
    });
    
    // Clear URL parameter on error
    const newUrl = window.location.pathname;
    window.history.replaceState({}, '', newUrl);
    setPreSelectedEntityId(null);
  }
}, [preSelectedEntityError, toast]);
```

Error display in UI:
```typescript
{/* Error message for entity loading */}
{entityLoadError && (
  <div className="p-4 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg mb-4">
    <div className="text-sm text-red-800 dark:text-red-200">
      <strong>خطا:</strong> {entityLoadError}
    </div>
    <p className="text-xs text-red-600 dark:text-red-400 mt-2">
      لطفا نهاد را به صورت دستی انتخاب کنید یا دوباره تلاش کنید.
    </p>
  </div>
)}
```

Loading indicator:
```typescript
{/* Loading indicator for entity */}
{isLoadingPreSelectedEntity && (
  <div className="p-4 bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 rounded-lg mb-4">
    <div className="text-sm text-yellow-800 dark:text-yellow-200">
      در حال بارگذاری اطلاعات نهاد...
    </div>
  </div>
)}
```

Form validation:
```typescript
// Additional validation: Ensure entity data is complete
if (!selectedEntity.companyName || !selectedEntity.tin) {
  toast({
    title: 'خطا',
    description: 'اطلاعات نهاد ناقص است. لطفا نهاد را دوباره انتخاب کنید',
    variant: 'destructive',
  });
  return;
}
```

### E. Audit Logging / Traceability

**Location:** `server/routes/cases.ts`

Enhanced audit logging to capture entity source:
```typescript
// Audit Logging / Traceability - Capture entity source
await storage.createAuditLog({
  userId: (req.user as any).id,
  action: 'create_case',
  entityType: 'case',
  entityId: newCase.id,
  details: {
    case: newCase,
    sourceEntity: {
      id: entity.id,
      companyName: entity.companyName,
      tin: entity.tin,
    },
    createdFromEntity: true, // Flag indicating case was created from entity management
    groupReferrer: senderGroup,
    receivingGroup: req.body.receivingGroup || null,
  },
  ipAddress: extractClientIp(req),
});
```

## Files Modified

1. **client/src/pages/Cases.tsx**
   - Added URL parameter detection
   - Added entity fetching query
   - Added auto-population effect
   - Added UI feedback components
   - Added error handling
   - Added validation

2. **server/routes/cases.ts**
   - Enhanced audit logging to capture entity source

## User Experience Flow

1. User clicks "ایجاد قضیه" button in Entity Management module
2. System navigates to Cases page with `?createForEntity=<entityId>` query parameter
3. System automatically:
   - Detects the query parameter
   - Fetches entity data from backend
   - Opens the case creation dialog
   - Pre-populates form fields with entity data
   - Displays visual indicator showing selected entity
   - Shows success toast notification
4. User can:
   - See which entity is selected (highlighted in blue box)
   - Modify any pre-populated fields if needed
   - Complete the case creation form
   - Submit the form

## Error Scenarios Handled

1. **Entity Not Found (404)**
   - Error message displayed
   - User can manually select entity
   - URL parameter cleared

2. **Access Denied (403)**
   - Error message displayed
   - User can manually select entity
   - URL parameter cleared

3. **Network/Server Error**
   - Error message displayed
   - User can manually select entity
   - URL parameter cleared

4. **Incomplete Entity Data**
   - Validation prevents form submission
   - Error message displayed
   - User must select valid entity

## Testing Checklist

- [x] Entity ID is correctly passed via URL parameter
- [x] Entity data is fetched when parameter is present
- [x] Form is automatically opened when entity is loaded
- [x] Form fields are pre-populated with entity data
- [x] Visual indicator shows selected entity
- [x] Error handling works for 404 errors
- [x] Error handling works for 403 errors
- [x] Error handling works for network errors
- [x] Validation prevents submission with invalid entity
- [x] Audit logs capture entity source
- [x] URL parameter is cleared after loading
- [x] Manual entity selection still works
- [x] Existing case creation flow is not broken

## Benefits

1. **Improved User Experience**
   - No need to manually search for entity
   - Immediate form population
   - Clear visual feedback

2. **Reduced Errors**
   - Prevents selecting wrong entity
   - Ensures data consistency
   - Validates entity before submission

3. **Better Traceability**
   - Audit logs capture entity source
   - Can track which entities initiated case creation
   - Better reporting capabilities

4. **Maintainability**
   - Clean separation of concerns
   - Reusable entity fetching logic
   - Comprehensive error handling

## Future Enhancements

1. Add ability to create multiple cases for same entity
2. Pre-fill additional fields based on entity history
3. Show entity case history in the dialog
4. Add quick actions for common case types

## Notes

- The feature maintains backward compatibility
- Manual entity selection still works as before
- All existing functionality is preserved
- No breaking changes to API

