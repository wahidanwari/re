# Quick Start Guide: Session Persistence & Permission Propagation

## Installation Steps

### 1. Run Database Migration
```bash
npm run db:migrate-permissions-version
```

Or manually:
```bash
psql $DATABASE_URL -f migrations/003_add_permissions_version.sql
```

### 2. Configure Environment Variables
Add to `.env`:
```bash
# Session timeout in milliseconds (default: 30 minutes)
SESSION_TIMEOUT=1800000

# Enable sliding expiration (default: true)
SLIDING_EXPIRATION=true
```

### 3. Restart Server
```bash
npm run dev
# or
npm start
```

## Testing

### Test Session Persistence
1. Login to the application
2. Press F5 (reload page)
3. ✅ User should remain logged in

### Test Inactivity Logout
1. Set `SESSION_TIMEOUT=60000` (1 minute) in `.env`
2. Login to the application
3. Wait 1 minute without activity
4. Make any API call
5. ✅ Should return 401 with `SESSION_EXPIRED`

### Test Permission Propagation
1. Login as a regular user (e.g., Auditor)
2. Open browser console to see WebSocket messages
3. In another browser (admin session), grant Coordinator package to the user
4. ✅ User's browser should immediately receive WebSocket notification
5. ✅ User's permissions should refresh automatically
6. ✅ User can now perform coordinator actions (assign cases, etc.)

## Key Features

- **Session Persistence**: Users stay logged in across page reloads
- **Inactivity Logout**: Automatic logout after 30 minutes of inactivity (configurable)
- **Permission Propagation**: Immediate permission updates via WebSocket
- **Heartbeat**: Client sends heartbeat every 5 minutes to keep session alive
- **Activity Tracking**: Mouse, keyboard, and touch events reset inactivity timer

## API Endpoints

- `POST /api/session/heartbeat` - Keep session alive
- `GET /api/auth/me` - Get user with permissions and version

## Troubleshooting

### Sessions not persisting
- Check that cookies are enabled in browser
- Verify `SESSION_SECRET` is set in `.env`
- Check browser console for errors

### Permission changes not propagating
- Check WebSocket connection in browser console
- Verify `permissions_version` column exists in database
- Check server logs for WebSocket errors

### Inactivity logout not working
- Verify `SESSION_TIMEOUT` is set correctly
- Check that `sessionTimeout()` middleware is applied (in `server/index.ts`)
- Check browser console for activity tracking errors

## Monitoring

Check audit logs for:
- `session_expired` - Session expiration events
- `update_user_permissions` - Permission change events

## Support

See full documentation in `docs/SESSION_PERSISTENCE_IMPLEMENTATION.md`

