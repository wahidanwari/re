# Audit Case State Machine - Complete Inventory

**Document Purpose:** Complete and exact extraction of the audit case state machine as it currently exists in the system. This is a READ-ONLY inventory document for redesign planning.

**Generated:** 2025-01-XX
**Scope:** All case statuses, transitions, assignment rules, backend enforcement, frontend coupling, and database constraints

---

## 1. ALL CASE STATUSES

### 1.1 Status Definitions

**Location:** `shared/schema.ts` (lines 77-92)

| Status Key | Enum Value (Dari) | Display Label | Description | Active/Deprecated |
|------------|-------------------|---------------|-------------|-------------------|
| `NEW` | `'جدید'` | جدید | Initial status when case is created, not yet assigned | **ACTIVE** |
| `ASSIGNED` | `'اختصاص داده شده'` | اختصاص داده شده | Case assigned to user/group, not started | **ACTIVE** |
| `PENDING_REVIEW_BY_SENIOR_AUDITOR` | `'منتظر بررسی بازرس ارشد'` | منتظر بررسی بازرس ارشد | Case assigned to group, waiting for senior auditor to assign to specific auditor | **ACTIVE** |
| `ASSIGNED_TO_AUDITOR` | `'اختصاص داده شده به بازرس'` | اختصاص داده شده به بازرس | Case assigned to specific auditor by senior auditor | **ACTIVE** |
| `UNDER_AUDIT_REVIEW` | `'در جریان بررسی'` | در جریان بررسی | Case is actively being worked on by auditor | **ACTIVE** |
| `IN_PROGRESS` | `'در جریان بررسی'` | در جریان بررسی | Legacy alias for UNDER_AUDIT_REVIEW (same value) | **DEPRECATED** (use UNDER_AUDIT_REVIEW) |
| `COMPLETED` | `'تکمیل شده'` | تکمیل شده | Case work finished, report complete, ready for approval | **ACTIVE** |
| `PENDING_APPROVAL` | `'منتظر تایید'` | منتظر تایید | Case submitted for approval (optional intermediate state) | **ACTIVE** |
| `APPROVED` | `'تایید شده'` | تایید شده | Case approved, final state | **ACTIVE** |
| `REJECTED` | `'رد شده'` | رد شده | Case rejected, can be reopened | **ACTIVE** |
| `NONRESPONSIVE` | `'عدم پاسخگو'` | عدم پاسخگو | Entity is non-responsive to audit requests | **ACTIVE** |
| `REFERRED_TO_ENFORCEMENT` | `'ارسال‌ شده به تنفیذ قانون'` | ارسال‌ شده به تنفیذ قانون | Case referred to law enforcement (variant spelling) | **ACTIVE** |
| `INSTALLMENT` | `'در اقساط'` | در اقساط | Case is in installment payment plan | **ACTIVE** |
| `SENT_TO_LAW_ENFORCEMENT` | `'ارسال‌شده به تنفیذ قانون'` | ارسال‌شده به تنفیذ قانون | Case sent to law enforcement (primary spelling) | **ACTIVE** |

### 1.2 Status Badge Display Configuration

**Location:** `client/src/components/StatusBadge.tsx` (lines 7-20)

| Status Value | Badge Variant | CSS Classes |
|-------------|---------------|-------------|
| `'جدید'` | `default` | `bg-blue-500 hover:bg-blue-600 text-white` |
| `'اختصاص داده شده'` | `default` | `bg-blue-400 hover:bg-blue-500 text-white` |
| `'در جریان بررسی'` | `secondary` | `bg-amber-500 hover:bg-amber-600 text-white` |
| `'تکمیل شده'` | `default` | `bg-green-500 hover:bg-green-600 text-white` |
| `'تایید شده'` | `default` | `bg-emerald-700 hover:bg-emerald-800 text-white` |
| `'رد شده'` | `destructive` | (default destructive styling) |
| `'منتظر تایید'` | `default` | `bg-purple-500 hover:bg-purple-600 text-white` |
| `'عدم پاسخگو'` | `secondary` | `bg-orange-500 hover:bg-orange-600 text-white` |
| `'ارسال‌ شده به تنفیذ قانون'` | `destructive` | `bg-red-600 hover:bg-red-700 text-white` |
| `'در اقساط'` | `default` | `bg-indigo-500 hover:bg-indigo-600 text-white` |
| `'ارسال‌شده به تنفیذ قانون'` | `destructive` | `bg-red-700 hover:bg-red-800 text-white` |

---

## 2. ALL STATE TRANSITION RULES

**Location:** `server/services/caseStateMachine.ts` (lines 60-609)

### 2.1 Transition Rules Table

| From Status | To Status | Transition Name | Required Permission | Conditions/Guards |
|-------------|-----------|----------------|-------------------|-------------------|
| `جدید` (NEW) | `منتظر بررسی بازرس ارشد` (PENDING_REVIEW_BY_SENIOR_AUDITOR) | `assign_to_group` | `cases:assign_to_group` | **Must have `groupId` in metadata**<br>Error: "باید گروه مشخص شود" |
| `منتظر بررسی بازرس ارشد` (PENDING_REVIEW_BY_SENIOR_AUDITOR) | `اختصاص داده شده به بازرس` (ASSIGNED_TO_AUDITOR) | `assign_to_auditor` | `cases:assign_to_auditor` | **Must have `userId` in metadata**<br>Error: "باید بازرس مشخص شود" |
| `جدید` (NEW) | `در جریان بررسی` (UNDER_AUDIT_REVIEW) | `start_audit` | `cases:view` | **System admin can start any case**<br>**Otherwise:**<br>- Must have `assignedTo` OR `assignedAuditor`<br>- User must be the assigned auditor (check both `assignedTo` and `assignedAuditor`)<br>Errors:<br>- "قضیه باید به بازرس اختصاص داده شده باشد"<br>- "شما فقط می‌توانید قضایای اختصاص داده شده به خود را شروع کنید" |
| `اختصاص داده شده به بازرس` (ASSIGNED_TO_AUDITOR) | `در جریان بررسی` (UNDER_AUDIT_REVIEW) | `start_audit` | `cases:view` | **System admin can start any case**<br>**Otherwise:**<br>- Must have `assignedTo` OR `assignedAuditor`<br>- User must be the assigned auditor (check both `assignedTo` and `assignedAuditor`)<br>Errors:<br>- "قضیه باید به بازرس اختصاص داده شده باشد"<br>- "شما فقط می‌توانید قضایای اختصاص داده شده به خود را شروع کنید" |
| `جدید` (NEW) | `اختصاص داده شده` (ASSIGNED) | `assign` | `cases:assign_to_auditor` OR `cases:assign_to_group` | **Must have `userId` OR `groupId` in metadata**<br>Error: "باید کاربر یا گروه مشخص شود" |
| `اختصاص داده شده` (ASSIGNED) | `در جریان بررسی` (IN_PROGRESS) | `start` | `cases:view` | **Must have `assignedTo` OR `receivingGroup`**<br>Error: "قضیه باید اختصاص داده شده باشد" |
| `در جریان بررسی` (IN_PROGRESS) | `تکمیل شده` (COMPLETED) | `complete` | `cases:complete` | **Report validation required:**<br>1. Report V2 must exist<br>2. Report must pass validation (all required fields)<br>3. Report status must be 'completed'<br>Errors:<br>- "گزارش قضیه تکمیل نشده است. لطفاً ابتدا گزارش را تکمیل کنید."<br>- "گزارش کامل نیست. فیلدهای ناقص: {fields}"<br>- "گزارش باید تکمیل شده باشد. لطفاً ابتدا گزارش را تکمیل کنید."<br>**Fallback:** Uses old validation service if V2 fails |
| `در جریان بررسی` (UNDER_AUDIT_REVIEW) | `تکمیل شده` (COMPLETED) | `complete` | `cases:complete` | **Same validation as above** |
| `تکمیل شده` (COMPLETED) | `منتظر تایید` (PENDING_APPROVAL) | `submit_for_approval` | `cases:complete` | **Must have `completedBy` and `completedAt`**<br>Error: "قضیه باید تکمیل شده باشد" |
| `تکمیل شده` (COMPLETED) | `تایید شده` (APPROVED) | `approve` | `tickets:approve` | **Must be in COMPLETED or PENDING_APPROVAL status**<br>Error: "فقط قضایای تکمیل شده می‌توانند تایید شوند" |
| `منتظر تایید` (PENDING_APPROVAL) | `تایید شده` (APPROVED) | `approve` | `tickets:approve` | **No additional validation** |
| `تکمیل شده` (COMPLETED) | `رد شده` (REJECTED) | `reject` | `tickets:approve` | **Must have `rejectionReason` in metadata (non-empty)**<br>Error: "دلیل رد الزامی است" |
| `منتظر تایید` (PENDING_APPROVAL) | `رد شده` (REJECTED) | `reject` | `tickets:approve` | **Must have `rejectionReason` in metadata (non-empty)**<br>Error: "دلیل رد الزامی است" |
| `رد شده` (REJECTED) | `در جریان بررسی` (IN_PROGRESS) | `reopen` | `tickets:approve` OR `cases:complete` | **No additional validation** |
| `در جریان بررسی` (IN_PROGRESS) | `اختصاص داده شده` (ASSIGNED) | `reassign` | `cases:assign_to_auditor` OR `cases:assign_to_group` | **Must have `userId` OR `groupId` in metadata**<br>Error: "باید کاربر یا گروه مشخص شود" |
| `اختصاص داده شده به بازرس` (ASSIGNED_TO_AUDITOR) | `در اقساط` (INSTALLMENT) | `to_installment` | **None** (null permission) | **Role-based validation:**<br>- System admin: Always allowed<br>- Senior auditor: Always allowed<br>- Auditor: Only if case is assigned to them (check both `assignedTo` and `assignedAuditor`)<br>Error: "شما فقط می‌توانید قضایای اختصاص داده شده به خود را به وضعیت 'در اقساط' منتقل کنید" |
| `تکمیل شده` (COMPLETED) | `در اقساط` (INSTALLMENT) | `to_installment` | `cases:manage_installments` | **Only senior_auditor or system_admin**<br>Error: "فقط بازرس ارشد می‌تواند قضیه را به وضعیت 'در اقساط' منتقل کند" |
| `تایید شده` (APPROVED) | `در اقساط` (INSTALLMENT) | `to_installment` | `cases:manage_installments` | **Only senior_auditor or system_admin**<br>Error: "فقط بازرس ارشد می‌تواند قضیه را به وضعیت 'در اقساط' منتقل کند" |
| `اختصاص داده شده به بازرس` (ASSIGNED_TO_AUDITOR) | `در اقساط` (INSTALLMENT) | `move_to_installment` | **None** (null permission) | **Same validation as `to_installment` from ASSIGNED_TO_AUDITOR** |
| `در جریان بررسی` (UNDER_AUDIT_REVIEW) | `در اقساط` (INSTALLMENT) | `to_installment` | **None** (null permission) | **Same validation as `to_installment` from ASSIGNED_TO_AUDITOR** |
| `در جریان بررسی` (UNDER_AUDIT_REVIEW) | `در اقساط` (INSTALLMENT) | `move_to_installment` | **None** (null permission) | **Same validation as `to_installment` from ASSIGNED_TO_AUDITOR** |
| `تکمیل شده` (COMPLETED) | `در اقساط` (INSTALLMENT) | `move_to_installment` | `cases:manage_installments` | **Only senior_auditor or system_admin**<br>Error: "فقط بازرس ارشد می‌تواند قضیه را به وضعیت 'در اقساط' منتقل کند" |
| `تایید شده` (APPROVED) | `در اقساط` (INSTALLMENT) | `move_to_installment` | `cases:manage_installments` | **Only senior_auditor or system_admin**<br>Error: "فقط بازرس ارشد می‌تواند قضیه را به وضعیت 'در اقساط' منتقل کند" |
| `تکمیل شده` (COMPLETED) | `ارسال‌شده به تنفیذ قانون` (SENT_TO_LAW_ENFORCEMENT) | `to_law_enforcement` | `cases:manage_law_enforcement` | **Only senior_auditor or system_admin**<br>Error: "فقط بازرس ارشد می‌تواند قضیه را به 'ارسال‌شده به تنفیذ قانون' منتقل کند" |
| `تایید شده` (APPROVED) | `ارسال‌شده به تنفیذ قانون` (SENT_TO_LAW_ENFORCEMENT) | `to_law_enforcement` | `cases:manage_law_enforcement` | **Only senior_auditor or system_admin**<br>Error: "فقط بازرس ارشد می‌تواند قضیه را به 'ارسال‌شده به تنفیذ قانون' منتقل کند" |
| `تکمیل شده` (COMPLETED) | `ارسال‌شده به تنفیذ قانون` (SENT_TO_LAW_ENFORCEMENT) | `send_to_law_enforcement` | `cases:manage_law_enforcement` | **Only senior_auditor or system_admin**<br>Error: "فقط بازرس ارشد می‌تواند قضیه را به 'ارسال‌شده به تنفیذ قانون' منتقل کند" |
| `تایید شده` (APPROVED) | `ارسال‌شده به تنفیذ قانون` (SENT_TO_LAW_ENFORCEMENT) | `send_to_law_enforcement` | `cases:manage_law_enforcement` | **Only senior_auditor or system_admin**<br>Error: "فقط بازرس ارشد می‌تواند قضیه را به 'ارسال‌شده به تنفیذ قانون' منتقل کند" |

### 2.2 Transition Execution Details

**Location:** `server/services/caseStateMachine.ts` (lines 726-934)

#### Status-Specific Field Updates on Transition:

- **To `COMPLETED`:**
  - Sets `completedBy = user.id`
  - Sets `completedAt = new Date()`
  - Determines completion type (financial state tracking)
  - Stores completion metadata in transition record

- **To `APPROVED`:**
  - Sets `approvedBy = user.id`
  - Sets `approvedAt = new Date()`
  - **Locks report** (sets report status to 'locked')

- **To `REJECTED`:**
  - Sets `rejectedBy = user.id`
  - Sets `rejectedAt = new Date()`
  - Sets `rejectionReason = metadata.rejectionReason`
  - **Locks report** (sets report status to 'locked')

- **To `ASSIGNED`:**
  - If `metadata.userId`: Sets `assignedTo = userId`, clears `receivingGroup`
  - If `metadata.groupId`: Sets `receivingGroup = groupId`, clears `assignedTo`

- **To `PENDING_REVIEW_BY_SENIOR_AUDITOR`:**
  - If `metadata.groupId`: Sets `receivingGroup = groupId`, clears `assignedTo`

- **To `ASSIGNED_TO_AUDITOR`:**
  - If `metadata.userId`: Sets `assignedTo = userId`, `assignedAuditor = userId`, `assignedBy = user.id`, `assignedAt = new Date()`

- **To `UNDER_AUDIT_REVIEW`:**
  - No additional fields (status update only)

- **To `INSTALLMENT`:**
  - Status update only

- **To `SENT_TO_LAW_ENFORCEMENT`:**
  - Status update only

#### Transition Record Creation:

Every transition creates a record in `case_status_transitions` table with:
- `caseId`
- `fromStatus`
- `toStatus`
- `transitionName`
- `transitionedBy` (user.id)
- `transitionedAt` (timestamp)
- `notes` (from metadata)
- `rejectionReason` (from metadata, if applicable)
- `metadata` (JSONB with IP address, user agent, user role, userId/groupId, completion type if applicable)

#### Audit Log Creation:

Every transition creates an audit log entry:
- `action`: `case_transition_{transitionName}`
- `entityType`: `'case'`
- `entityId`: case ID
- `details`: Full transition details including from/to status, transition name, transition ID, metadata

---

## 3. ASSIGNMENT-RELATED RULES

**Location:** `server/routes/cases.ts` (lines 829-1091)

### 3.1 Committee Assignment

**Status Requirements:**
- **Committee assignment is NOT directly tied to case status**
- Cases can be created with `committeeId` (deprecated field) or `currentAssignmentId` (new committee module)
- Committee assignment does NOT change case status automatically

**Fields:**
- `committeeId` (deprecated) - Old committee reference
- `currentAssignmentId` - References `committeeCaseAssignments.id` (new committee module)
- `currentAuditGroupId` - References `groups.id` (audit group from committee assignment)

**Validation:**
- `committeeId` must exist in `committees` table if provided (lines 562-568)
- `currentAssignmentId` references `committeeCaseAssignments` table

### 3.2 Audit Group Assignment

**Status Requirements:**
- **Group assignment ONLY allowed when case status is `NEW` (`'جدید'`)**
- **Location:** `server/routes/cases.ts` (lines 869-875)
- **Error if status is not NEW:** "قضیه باید در وضعیت 'جدید' باشد تا به گروه اختصاص داده شود. وضعیت فعلی: {currentStatus}"

**Transition:**
- Uses state machine transition: `assign_to_group`
- From: `NEW` → To: `PENDING_REVIEW_BY_SENIOR_AUDITOR`
- Sets `receivingGroup = groupId`
- Clears `assignedTo`

**Permission:**
- Requires `cases:assign_to_group`
- **Senior Auditor restriction:** If senior auditor (and not coordinator), can only assign to their own group (lines 855-867)
- **Self-assignment:** NOT explicitly blocked for groups (senior auditor can assign to their own group)

**RBAC:**
- System admin: Can assign to any group
- Coordinator: Can assign to any group
- Senior auditor (non-coordinator): Can only assign to their own group

### 3.3 Auditor Assignment

**Status Requirements:**
- **Auditor assignment ONLY allowed when case status is `PENDING_REVIEW_BY_SENIOR_AUDITOR` (`'منتظر بررسی بازرس ارشد'`)**
- **Location:** `server/routes/cases.ts` (lines 970-977)
- **Error if status is not PENDING_REVIEW_BY_SENIOR_AUDITOR:** "قضیه باید در وضعیت 'منتظر بررسی بازرس ارشد' باشد. وضعیت فعلی: {currentStatus}"

**Transition:**
- Uses state machine transition: `assign_to_auditor`
- From: `PENDING_REVIEW_BY_SENIOR_AUDITOR` → To: `ASSIGNED_TO_AUDITOR`
- Sets `assignedTo = userId`
- Sets `assignedAuditor = userId`
- Sets `assignedBy = user.id`
- Sets `assignedAt = new Date()`

**Permission:**
- Requires `cases:assign_to_auditor`
- **Senior Auditor restriction:** If senior auditor (and not coordinator), can only assign to users in their own group (lines 954-968)
- **Self-assignment:** **EXPLICITLY ALLOWED** - Senior auditor can assign to themselves (comment on line 955: "NOTE: This allows self-assignment since the Senior Auditor is in their own group")

**RBAC:**
- System admin: Can assign to any user
- Coordinator: Can assign to any user
- Senior auditor (non-coordinator): Can only assign to users in their own group (including themselves)

### 3.4 Self-Assignment Rules

**Summary:**
- **Group assignment:** NOT explicitly blocked (senior auditor can assign to their own group)
- **Auditor assignment:** **EXPLICITLY ALLOWED** - Senior auditor can assign cases to themselves
- **Location:** `server/routes/cases.ts` (line 955 comment)

### 3.5 Assignment Status Checks

**Backend Enforcement Points:**

1. **Group Assignment Status Check:**
   - **Location:** `server/routes/cases.ts` (lines 869-875)
   - **Check:** `caseToAssign.status !== CaseStatus.NEW`
   - **Error:** "قضیه باید در وضعیت 'جدید' باشد تا به گروه اختصاص داده شود. وضعیت فعلی: {currentStatus}"

2. **Auditor Assignment Status Check:**
   - **Location:** `server/routes/cases.ts` (lines 970-977)
   - **Check:** `caseToAssign.status !== CaseStatus.PENDING_REVIEW_BY_SENIOR_AUDITOR`
   - **Error:** "قضیه باید در وضعیت 'منتظر بررسی بازرس ارشد' باشد. وضعیت فعلی: {currentStatus}"

3. **Start Audit Assignment Check:**
   - **Location:** `server/routes/cases.ts` (lines 1104-1106)
   - **Check:** `caseData.assignedTo !== user.id && caseData.assignedAuditor !== user.id`
   - **Error:** "شما فقط می‌توانید قضایای اختصاص داده شده به خود را شروع کنید"
   - **Exception:** System admin can start any case

---

## 4. BACKEND ENFORCEMENT

### 4.1 Transition Validation Location

**Primary Service:** `server/services/caseStateMachine.ts`

**Functions:**
- `getAllowedTransitions(caseItem, user)` - Returns allowed transitions for a case (lines 614-628)
- `validateTransition(caseItem, user, toStatus, transitionName, metadata)` - Validates a transition (lines 633-721)
- `executeTransition(caseId, user, transitionName, metadata)` - Executes a transition with validation (lines 726-934)

### 4.2 API Endpoints

#### 4.2.1 Primary Transition Endpoint

**Endpoint:** `POST /api/cases/:id/transition`
**Location:** `server/routes/cases.ts` (lines 2799-2967)

**Request Body:**
```typescript
{
  transition: TransitionName,  // 'assign', 'start', 'complete', etc.
  metadata?: {
    userId?: string,
    groupId?: string,
    rejectionReason?: string,
    notes?: string
  }
}
```

**Validation:**
- Validates transition name is in allowed list (lines 2807-2817)
- Checks case exists (lines 2820-2829)
- Checks RBAC access (lines 2831-2884)
- Executes transition via state machine (lines 2886-2891)
- Returns error with allowed transitions if validation fails (lines 2893-2905)

**Error Codes:**
- `INVALID_TRANSITION_NAME` - Transition name not in allowed list
- `CASE_NOT_FOUND` - Case does not exist
- `PERMISSION_DENIED` - User lacks access to case
- `INVALID_TRANSITION` - Transition validation failed

#### 4.2.2 Deprecated Status Update Endpoint

**Endpoint:** `PATCH /api/cases/:id/status`
**Location:** `server/routes/cases.ts` (lines 1127-1260)

**Status:** **DEPRECATED** - Uses state machine internally but logs deprecation warning

**Behavior:**
- Maps status changes to transition names (lines 1148-1164)
- Uses state machine if transition can be mapped (lines 1167-1198)
- Falls back to old validation for unmapped transitions (lines 1200-1250)
- Logs deprecation warning (line 1201)

**Valid Statuses (fallback):**
- `'جدید'`, `'اختصاص داده شده'`, `'در جریان بررسی'`, `'تکمیل شده'`, `'منتظر تایید'`, `'تایید شده'`, `'رد شده'`, `'در اقساط'`, `'ارسال‌شده به تنفیذ قانون'`, `'عدم پاسخگو'`, `'ارسال‌ شده به تنفیذ قانون'`

**Blocked Status Changes:**
- Cannot change status if current status is `'تایید شده'` or `'رد شده'` (lines 1210-1214)

#### 4.2.3 Deprecated Complete Endpoint

**Endpoint:** `POST /api/cases/:id/complete`
**Location:** `server/routes/cases.ts` (lines 1262-1412)

**Status:** **DEPRECATED** - Uses state machine internally

**Behavior:**
- Checks `cases:complete` permission (lines 1274-1277)
- Checks RBAC access (lines 1279-1308)
- Uses state machine to execute `complete` transition (lines 1310-1314)
- Falls back to old validation if state machine fails (lines 1316-1334)

#### 4.2.4 Assignment Endpoint

**Endpoint:** `POST /api/cases/:id/assign`
**Location:** `server/routes/cases.ts` (lines 829-1091)

**Request Body:**
```typescript
{
  userId?: string,    // For auditor assignment
  groupId?: string   // For group assignment
}
```

**Validation:**
- Exactly one of `userId` or `groupId` must be provided (lines 836-842)
- Group assignment: Case must be in `NEW` status (lines 869-875)
- Auditor assignment: Case must be in `PENDING_REVIEW_BY_SENIOR_AUDITOR` status (lines 970-977)
- Uses state machine transitions: `assign_to_group` or `assign_to_auditor` (lines 878-884, 980-992)

#### 4.2.5 Start Audit Endpoint

**Endpoint:** `POST /api/cases/:id/start-audit`
**Location:** `server/routes/cases.ts` (lines 1093-1125)

**Validation:**
- Checks user is assigned to case (lines 1104-1106)
- Uses state machine transition: `start_audit` (lines 1108-1116)

### 4.3 Error Messages

**All error messages are in Dari (Persian/Farsi):**

| Error Message | Context | Location |
|---------------|---------|----------|
| "باید گروه مشخص شود" | Group assignment missing groupId | `caseStateMachine.ts:71` |
| "باید بازرس مشخص شود" | Auditor assignment missing userId | `caseStateMachine.ts:87` |
| "قضیه باید به بازرس اختصاص داده شده باشد" | Start audit without assignment | `caseStateMachine.ts:108, 138` |
| "شما فقط می‌توانید قضایای اختصاص داده شده به خود را شروع کنید" | Start audit by non-assigned user | `caseStateMachine.ts:116, 146` |
| "باید کاربر یا گروه مشخص شود" | Assign/reassign missing userId/groupId | `caseStateMachine.ts:163, 391` |
| "قضیه باید اختصاص داده شده باشد" | Start without assignment | `caseStateMachine.ts:179` |
| "گزارش قضیه تکمیل نشده است. لطفاً ابتدا گزارش را تکمیل کنید." | Complete without report | `caseStateMachine.ts:201, 260` |
| "گزارش کامل نیست. فیلدهای ناقص: {fields}" | Complete with incomplete report | `caseStateMachine.ts:212, 271` |
| "گزارش باید تکمیل شده باشد. لطفاً ابتدا گزارش را تکمیل کنید." | Complete with non-completed report | `caseStateMachine.ts:221, 280` |
| "قضیه باید تکمیل شده باشد" | Submit for approval without completion | `caseStateMachine.ts:313` |
| "فقط قضایای تکمیل شده می‌توانند تایید شوند" | Approve non-completed case | `caseStateMachine.ts:329` |
| "دلیل رد الزامی است" | Reject without reason | `caseStateMachine.ts:352, 368` |
| "شما فقط می‌توانید قضایای اختصاص داده شده به خود را به وضعیت 'در اقساط' منتقل کنید" | Installment transition by non-assigned auditor | `caseStateMachine.ts:414, 467, 488, 509` |
| "فقط بازرس ارشد می‌تواند قضیه را به وضعیت 'در اقساط' منتقل کند" | Installment transition by non-senior auditor | `caseStateMachine.ts:428, 444, 523, 539` |
| "فقط بازرس ارشد می‌تواند قضیه را به 'ارسال‌شده به تنفیذ قانون' منتقل کند" | Law enforcement transition by non-senior auditor | `caseStateMachine.ts:555, 571, 587, 603` |
| "انتقال از {from} به {to} مجاز نیست" | Invalid transition | `caseStateMachine.ts:648` |
| "شما مجوز اختصاص قضیه را ندارید" | Missing assign permission | `caseStateMachine.ts:667` |
| "شما مجوز بازگشایی قضیه را ندارید" | Missing reopen permission | `caseStateMachine.ts:691` |
| "شما مجوز تایید/رد قضیه را ندارید" | Missing approve/reject permission | `caseStateMachine.ts:699` |
| "شما مجوز لازم را ندارید" | Missing general permission | `caseStateMachine.ts:709` |
| "قضیه یافت نشد" | Case not found | `caseStateMachine.ts:743` |
| "انتقال '{name}' از وضعیت '{status}' مجاز نیست. وضعیت مورد نیاز: '{required}'" | Transition from wrong status | `caseStateMachine.ts:763` |
| "انتقال نامعتبر است" | Invalid transition | `caseStateMachine.ts:769` |
| "قضیه باید در وضعیت 'جدید' باشد تا به گروه اختصاص داده شود. وضعیت فعلی: {status}" | Group assignment wrong status | `cases.ts:873` |
| "قضیه باید در وضعیت 'منتظر بررسی بازرس ارشد' باشد. وضعیت فعلی: {status}" | Auditor assignment wrong status | `cases.ts:975` |
| "شما فقط می‌توانید قضایا را به گروه خود اختصاص دهید" | Group assignment to wrong group | `cases.ts:863` |
| "شما فقط می‌توانید قضایا را به کاربران گروه خود اختصاص دهید" | Auditor assignment to wrong group | `cases.ts:964` |

### 4.4 Hardcoded Status Checks

**Location:** `server/routes/cases.ts`

1. **Line 737:** Prevents updates to approved/rejected cases
   ```typescript
   if (oldCase.status === 'تایید شده' || oldCase.status === 'رد شده') {
     return res.status(400).json({ message: "..." });
   }
   ```

2. **Line 871:** Group assignment requires NEW status
   ```typescript
   if (caseToAssign.status !== CaseStatus.NEW) { ... }
   ```

3. **Line 973:** Auditor assignment requires PENDING_REVIEW_BY_SENIOR_AUDITOR status
   ```typescript
   if (caseToAssign.status !== CaseStatus.PENDING_REVIEW_BY_SENIOR_AUDITOR) { ... }
   ```

4. **Line 1104:** Start audit requires assignment
   ```typescript
   if (caseData.assignedTo !== user.id && caseData.assignedAuditor !== user.id) { ... }
   ```

5. **Line 1210:** Prevents status change from approved/rejected
   ```typescript
   if (currentCase.status === 'تایید شده' || currentCase.status === 'رد شده') { ... }
   ```

6. **Line 1216:** Complete transition requires report validation
   ```typescript
   if (status === 'تکمیل شده' && currentCase.status !== 'تکمیل شده') { ... }
   ```

7. **Line 1749:** Prevents report updates on approved/rejected cases
   ```typescript
   if (caseData.status === 'تایید شده' || caseData.status === 'رد شده') { ... }
   ```

8. **Line 3422:** Installment transition requires non-installment status
   ```typescript
   if (caseData.status !== CaseStatus.INSTALLMENT) { ... }
   ```

9. **Line 3429:** Installment transition from COMPLETED/APPROVED requires senior auditor
   ```typescript
   if (caseData.status === CaseStatus.COMPLETED || caseData.status === 'تکمیل شده') { ... }
   ```

10. **Line 4007:** Prevents updates to approved/rejected cases (senior auditor check)
    ```typescript
    if ((oldCase.status === 'تایید شده' || oldCase.status === 'رد شده') && !isSeniorAuditor) { ... }
    ```

---

## 5. FRONTEND COUPLING

### 5.1 UI Components Checking Case Status

**Location:** `client/src/pages/Cases.tsx`

#### 5.1.1 Status-Based Tab Filtering

**Lines 1600-1674:** Tab triggers with status-based counts

- **"قضایای تازه اختصاص داده شده" tab:**
  - Filters: `NEW`, `ASSIGNED`, `PENDING_REVIEW_BY_SENIOR_AUDITOR`, `ASSIGNED_TO_AUDITOR`, `UNDER_AUDIT_REVIEW`, `IN_PROGRESS`
  - Also checks string values: `'جدید'`, `'اختصاص داده شده'`, `'منتظر بررسی بازرس ارشد'`, `'اختصاص داده شده به بازرس'`, `'در جریان بررسی'`
  - Also checks English keys: `'NEW'`, `'ASSIGNED'`, `'ASSIGNED_TO_AUDITOR'`, `'IN_PROGRESS'`

- **"قضایای تکمیل شده" tab:**
  - Filters: `'تکمیل شده'`, `'تایید شده'`, `'رد شده'`, `'بسته شده'`, `'COMPLETED'`, `'APPROVED'`, `'REJECTED'`

- **"دوسیه‌های کمیته جدید" tab:**
  - Filters: Status `'در انتظار بررسی'` AND has `currentAuditGroupId` or `current_assignment_id` or `receivingGroup`

- **"قضایای در اقساط" tab:**
  - Filters: `INSTALLMENT`, `'در اقساط'`, or status containing `'اقساط'` or `'installment'` (case-insensitive)

- **"قضایای ارسال‌شده به تنفیذ قانون" tab:**
  - Filters: `SENT_TO_LAW_ENFORCEMENT`, `'ارسال‌شده به تنفیذ قانون'`, or status containing `'ارسال'` and `'تنفیذ'`, or `'sent_to_law_enforcement'` (case-insensitive)

#### 5.1.2 Status-Based Button Visibility

**Lines 3162-3215:** "شروع بررسی" (Start Audit) Button

**Conditions:**
- User role: `auditor`, `senior_auditor`, or `system_admin`
- Case assigned to user: `displayCase.assignedTo === currentUser.id` OR `displayCase.assignedAuditor === currentUser.id`
- Case status is one of:
  - `CaseStatus.ASSIGNED`
  - `CaseStatus.ASSIGNED_TO_AUDITOR`
  - `CaseStatus.NEW`
  - `CaseStatus.PENDING_REVIEW_BY_SENIOR_AUDITOR`
  - `'اختصاص داده شده'`
  - `'اختصاص داده شده به بازرس'`
  - `'جدید'`
  - `'منتظر بررسی بازرس ارشد'`

**Action:** Calls `POST /api/cases/:id/start-audit`

**Lines 3218-3229:** "بازگشایی" (Reopen) Button

**Conditions:**
- User role: `senior_auditor` or `system_admin`
- Case status: `'تکمیل شده'` OR `'تایید شده'`

**Lines 3257-3354:** "تنظیم به عنوان قضیه قسط" (Set as Installment) Button

**Conditions:**
- User role: `auditor`, `senior_auditor`, or `system_admin`
- Case status: **NOT** `CaseStatus.INSTALLMENT`

**Action:** Tries state machine transitions `to_installment` or `move_to_installment`, falls back to direct status update

**Lines 3356-3363:** Installment Payments Component

**Conditions:**
- User role: `auditor`, `senior_auditor`, or `system_admin`
- Case status: `CaseStatus.INSTALLMENT`

#### 5.1.3 Status-Based Case Filtering

**Lines 1890-1984:** Universal status filter

- Filters cases by `universalStatusFilter` if not `'all'`
- Checks `isNewlyAssigned` statuses for highlighting
- Checks `isLawEnforcement` statuses for filtering
- Checks `isCompleted` statuses for filtering

**Status checks include:**
- `CaseStatus.NEW`, `CaseStatus.ASSIGNED`, `CaseStatus.PENDING_REVIEW_BY_SENIOR_AUDITOR`, `CaseStatus.ASSIGNED_TO_AUDITOR`, `CaseStatus.UNDER_AUDIT_REVIEW`, `CaseStatus.IN_PROGRESS`
- String values: `'جدید'`, `'اختصاص داده شده'`, `'منتظر بررسی بازرس ارشد'`, `'اختصاص داده شده به بازرس'`, `'در جریان بررسی'`
- English keys: `'NEW'`, `'ASSIGNED'`, `'ASSIGNED_TO_AUDITOR'`, `'IN_PROGRESS'`

### 5.2 Client-Side Status Guards

**Location:** `client/src/pages/Cases.tsx`

1. **Line 3165-3172:** Start audit button guard - checks status and assignment
2. **Line 3219:** Reopen button guard - checks status and role
3. **Line 3260:** Installment button guard - checks status is not INSTALLMENT
4. **Line 3359:** Installment payments guard - checks status is INSTALLMENT

### 5.3 Status Badge Component

**Location:** `client/src/components/StatusBadge.tsx`

- Displays status with color-coded badges
- Maps status values to badge variants and CSS classes
- Defaults to `'جدید'` styling if status not found in config

---

## 6. DATABASE LAYER

### 6.1 Case Status Constraint

**Location:** `migrations/035_update_cases_status_check_constraint.sql` (lines 24-40)

**Constraint Name:** `cases_status_check`

**Allowed Values:**
```sql
CHECK (status IN (
  'جدید',
  'اختصاص داده شده',
  'منتظر بررسی بازرس ارشد',
  'اختصاص داده شده به بازرس',
  'در جریان بررسی',
  'تکمیل شده',
  'منتظر تایید',
  'تایید شده',
  'رد شده',
  'عدم پاسخگو',
  'ارسال‌ شده به تنفیذ قانون',
  'در اقساط',
  'ارسال‌شده به تنفیذ قانون'
))
```

**Migration History:**
- `migrations/013_case_status_state_machine.sql` - Initial constraint (7 statuses)
- `migrations/027_case_management_enhancements.sql` - Added new statuses
- `migrations/028_add_installment_and_law_enforcement_statuses.sql` - Added INSTALLMENT and SENT_TO_LAW_ENFORCEMENT
- `migrations/029_case_status_and_committee_updates.sql` - Updated constraint
- `migrations/035_update_cases_status_check_constraint.sql` - **Current constraint** (13 statuses)

### 6.2 Default Status on Case Creation

**Location:** `shared/schema.ts` (line 153)

**Default Value:** `"جدید"` (NEW)

```typescript
status: text("status").notNull().default("جدید"),
```

**Location:** `server/routes/cases.ts` (line 689)

**Explicit Setting:** Cases are created with `status: 'جدید'` (or `CaseStatus.NEW`)

### 6.3 Case Status Transitions Table

**Location:** `shared/schema.ts` (lines 183-196)

**Table Name:** `case_status_transitions`

**Schema:**
```typescript
{
  id: varchar (PRIMARY KEY, UUID)
  caseId: varchar (NOT NULL, FK to cases.id, CASCADE DELETE)
  fromStatus: text (NOT NULL)
  toStatus: text (NOT NULL)
  transitionName: text (NOT NULL)
  transitionedBy: varchar (NOT NULL, FK to users.id, SET NULL on delete)
  transitionedAt: timestamp (NOT NULL, DEFAULT NOW())
  notes: text (nullable)
  rejectionReason: text (nullable)
  metadata: jsonb (nullable)
  createdAt: timestamp (NOT NULL, DEFAULT NOW())
}
```

**Indexes:**
- `idx_case_status_transitions_case_id` on `case_id`
- `idx_case_status_transitions_transitioned_at` on `transitioned_at`
- `idx_case_status_transitions_from_status` on `from_status`
- `idx_case_status_transitions_to_status` on `to_status`
- `idx_case_status_transitions_transitioned_by` on `transitioned_by`

**Migration:** `migrations/013_case_status_state_machine.sql` (lines 16-41)

### 6.4 Cases Table Status Field

**Location:** `shared/schema.ts` (line 153)

**Field Definition:**
```typescript
status: text("status").notNull().default("جدید"),
```

**Constraints:**
- NOT NULL
- DEFAULT: `"جدید"`
- CHECK constraint: `cases_status_check` (see 6.1)

**Indexes:**
- `idx_cases_status` on `status` (from migration 013)
- `idx_cases_status_enhanced` on `status` (from migration 027)
- `idx_cases_status_installment` on `status` WHERE `status = 'در اقساط'` (from migration 028)
- `idx_cases_status_law_enforcement` on `status` WHERE `status = 'ارسال‌شده به تنفیذ قانون'` (from migration 028)

### 6.5 Status-Related Fields in Cases Table

**Location:** `shared/schema.ts` (lines 134-181)

| Field | Type | Nullable | Description |
|-------|------|----------|-------------|
| `status` | text | NOT NULL | Current case status (default: `'جدید'`) |
| `assignedTo` | varchar | nullable | User ID of assigned auditor |
| `assignedAuditor` | varchar | nullable | User ID of assigned auditor (explicit field) |
| `assignedBy` | varchar | nullable | User ID who made the assignment (FK to users.id) |
| `assignedAt` | timestamp | nullable | Timestamp of assignment |
| `receivingGroup` | varchar | nullable | Group ID of assigned audit group (FK to groups.id) |
| `completedBy` | varchar | nullable | User ID who completed the case (FK to users.id) |
| `completedAt` | timestamp | nullable | Timestamp of completion |
| `approvedBy` | varchar | nullable | User ID who approved the case (FK to users.id) |
| `approvedAt` | timestamp | nullable | Timestamp of approval |
| `rejectedBy` | varchar | nullable | User ID who rejected the case (FK to users.id) |
| `rejectedAt` | timestamp | nullable | Timestamp of rejection |
| `rejectionReason` | text | nullable | Reason for rejection |
| `reopenedBy` | varchar | nullable | User ID who reopened the case (FK to users.id) |
| `reopenedAt` | timestamp | nullable | Timestamp of reopening |
| `reopenReason` | text | nullable | Reason for reopening |
| `currentAssignmentId` | varchar | nullable | Current committee assignment ID (FK to committeeCaseAssignments.id) |
| `currentAuditGroupId` | varchar | nullable | Current audit group ID (FK to groups.id) |

### 6.6 Database Constraints Related to Status

1. **Status Check Constraint:** `cases_status_check` - Enforces valid status values (see 6.1)
2. **Foreign Key Constraints:**
   - `assignedBy` → `users.id` (SET NULL on delete)
   - `assignedTo` → `users.id` (implicit, no FK constraint)
   - `assignedAuditor` → `users.id` (implicit, no FK constraint)
   - `receivingGroup` → `groups.id` (SET NULL on delete)
   - `completedBy` → `users.id` (implicit, no FK constraint)
   - `approvedBy` → `users.id` (implicit, no FK constraint)
   - `rejectedBy` → `users.id` (implicit, no FK constraint)
   - `reopenedBy` → `users.id` (SET NULL on delete)
   - `currentAssignmentId` → `committeeCaseAssignments.id` (SET NULL on delete)
   - `currentAuditGroupId` → `groups.id` (SET NULL on delete)

3. **Case Status Transitions Foreign Keys:**
   - `caseId` → `cases.id` (CASCADE DELETE)
   - `transitionedBy` → `users.id` (SET NULL on delete)

---

## 7. SUMMARY OF KEY FINDINGS

### 7.1 Status Count
- **Total Statuses:** 13 active statuses (plus 1 deprecated alias)
- **Core Workflow Statuses:** 7 (NEW → ASSIGNED → IN_PROGRESS → COMPLETED → PENDING_APPROVAL → APPROVED/REJECTED)
- **Special Statuses:** 6 (PENDING_REVIEW_BY_SENIOR_AUDITOR, ASSIGNED_TO_AUDITOR, NONRESPONSIVE, REFERRED_TO_ENFORCEMENT, INSTALLMENT, SENT_TO_LAW_ENFORCEMENT)

### 7.2 Transition Count
- **Total Transitions:** 28 transition rules defined
- **Unique Transition Names:** 12 (`assign`, `assign_to_group`, `assign_to_auditor`, `start`, `start_audit`, `complete`, `submit_for_approval`, `approve`, `reject`, `reopen`, `reassign`, `to_installment`, `move_to_installment`, `to_law_enforcement`, `send_to_law_enforcement`)

### 7.3 Assignment Rules Summary
- **Group Assignment:** Only allowed from `NEW` status
- **Auditor Assignment:** Only allowed from `PENDING_REVIEW_BY_SENIOR_AUDITOR` status
- **Self-Assignment:** Explicitly allowed for senior auditors (auditor assignment)
- **Status Enforcement:** Hardcoded checks in assignment endpoint prevent wrong-status assignments

### 7.4 Permission Requirements
- **Most transitions require permissions:** Only `to_installment` and `move_to_installment` from certain statuses have null permission (role-based validation instead)
- **Permission flexibility:** Some transitions accept multiple permissions (e.g., `assign` accepts `cases:assign_to_auditor` OR `cases:assign_to_group`)

### 7.5 Terminal States
- **APPROVED:** Terminal state (no transitions out, except via direct status update which is blocked)
- **REJECTED:** Can transition to `IN_PROGRESS` via `reopen` transition

### 7.6 Report Locking
- **Report is locked when case is APPROVED or REJECTED**
- **Location:** `server/services/caseStateMachine.ts` (lines 824-837)
- **Action:** Sets report status to `'locked'` in `caseReportsV2` table

---

## END OF INVENTORY

**Note:** This document is a complete extraction of the current state machine implementation. All information is based on actual code analysis and should be used as the authoritative reference for redesign planning.

