# Test migration step by step to identify the exact error

Write-Host "🧪 Testing Migration 034 Step by Step" -ForegroundColor Cyan
Write-Host ""

if (-not $env:DATABASE_URL) {
    Write-Host "❌ ERROR: DATABASE_URL not set" -ForegroundColor Red
    exit 1
}

$db = $env:DATABASE_URL

Write-Host "Step 1: Test connection..." -ForegroundColor Yellow
& psql $db -c "SELECT 1;" 2>&1 | Out-Null
if ($LASTEXITCODE -ne 0) {
    Write-Host "❌ Connection failed" -ForegroundColor Red
    exit 1
}
Write-Host "✅ Connected" -ForegroundColor Green
Write-Host ""

Write-Host "Step 2: Check if cases table exists..." -ForegroundColor Yellow
$result = & psql $db -t -c "SELECT EXISTS (SELECT FROM information_schema.tables WHERE table_name = 'cases');" 2>&1
if ($result -match "t") {
    Write-Host "✅ Cases table exists" -ForegroundColor Green
} else {
    Write-Host "❌ Cases table does not exist" -ForegroundColor Red
    exit 1
}
Write-Host ""

Write-Host "Step 3: Try to create btree_gist extension..." -ForegroundColor Yellow
& psql $db -c "CREATE EXTENSION IF NOT EXISTS btree_gist;" 2>&1
if ($LASTEXITCODE -eq 0) {
    Write-Host "✅ Extension created" -ForegroundColor Green
} else {
    Write-Host "⚠️  Extension creation failed (may need superuser)" -ForegroundColor Yellow
}
Write-Host ""

Write-Host "Step 4: Add audit_year_start column..." -ForegroundColor Yellow
& psql $db -c "ALTER TABLE cases ADD COLUMN IF NOT EXISTS audit_year_start INTEGER;" 2>&1
if ($LASTEXITCODE -eq 0) {
    Write-Host "✅ Column added" -ForegroundColor Green
} else {
    Write-Host "❌ Failed to add column" -ForegroundColor Red
    exit 1
}
Write-Host ""

Write-Host "Step 5: Add audit_year_end column..." -ForegroundColor Yellow
& psql $db -c "ALTER TABLE cases ADD COLUMN IF NOT EXISTS audit_year_end INTEGER;" 2>&1
if ($LASTEXITCODE -eq 0) {
    Write-Host "✅ Column added" -ForegroundColor Green
} else {
    Write-Host "❌ Failed to add column" -ForegroundColor Red
    exit 1
}
Write-Host ""

Write-Host "Step 6: Test data migration (first 5 rows)..." -ForegroundColor Yellow
$migrationTest = @"
DO `$$
DECLARE
  case_record RECORD;
  range_str TEXT;
  start_year INTEGER;
  end_year INTEGER;
  range_match TEXT[];
  single_year_match TEXT[];
  count INTEGER := 0;
BEGIN
  FOR case_record IN SELECT id, audit_year_range FROM cases WHERE audit_year_range IS NOT NULL AND audit_year_range != '' LIMIT 5 LOOP
    count := count + 1;
    range_str := TRIM(case_record.audit_year_range);
    range_match := regexp_match(range_str, '^(\d{4})[\s\-–—]+(\d{4})$');
    
    IF range_match IS NOT NULL THEN
      start_year := range_match[1]::INTEGER;
      end_year := range_match[2]::INTEGER;
    ELSE
      single_year_match := regexp_match(range_str, '^(\d{4})$');
      IF single_year_match IS NOT NULL THEN
        start_year := single_year_match[1]::INTEGER;
        end_year := start_year;
      END IF;
    END IF;
    
    IF start_year IS NOT NULL AND end_year IS NOT NULL AND start_year <= end_year THEN
      UPDATE cases SET audit_year_start = start_year, audit_year_end = end_year WHERE id = case_record.id;
      RAISE NOTICE 'Migrated case %: % -> [%, %]', case_record.id, range_str, start_year, end_year;
    END IF;
  END LOOP;
  RAISE NOTICE 'Processed % cases', count;
END `$$;
"@
& psql $db -c $migrationTest 2>&1
Write-Host ""

Write-Host "Step 7: Create indexes..." -ForegroundColor Yellow
& psql $db -c "CREATE INDEX IF NOT EXISTS idx_cases_audit_year_start ON cases(audit_year_start) WHERE audit_year_start IS NOT NULL;" 2>&1 | Out-Null
& psql $db -c "CREATE INDEX IF NOT EXISTS idx_cases_audit_year_end ON cases(audit_year_end) WHERE audit_year_end IS NOT NULL;" 2>&1 | Out-Null
Write-Host "✅ Indexes created" -ForegroundColor Green
Write-Host ""

Write-Host "Step 8: Add check constraint..." -ForegroundColor Yellow
& psql $db -c "ALTER TABLE cases DROP CONSTRAINT IF EXISTS cases_audit_years_check; ALTER TABLE cases ADD CONSTRAINT cases_audit_years_check CHECK ((audit_year_start IS NULL AND audit_year_end IS NULL) OR (audit_year_start IS NOT NULL AND audit_year_end IS NOT NULL AND audit_year_start <= audit_year_end));" 2>&1
if ($LASTEXITCODE -eq 0) {
    Write-Host "✅ Check constraint added" -ForegroundColor Green
} else {
    Write-Host "❌ Failed to add check constraint" -ForegroundColor Red
}
Write-Host ""

Write-Host "Step 9: Try to add exclusion constraint..." -ForegroundColor Yellow
$exclusionSQL = @"
DO `$$
DECLARE
  extension_exists BOOLEAN;
BEGIN
  SELECT EXISTS(SELECT 1 FROM pg_extension WHERE extname = 'btree_gist') INTO extension_exists;
  
  IF NOT extension_exists THEN
    RAISE NOTICE 'btree_gist not available';
    RETURN;
  END IF;
  
  ALTER TABLE cases DROP CONSTRAINT IF EXISTS no_overlapping_audit_years;
  
  BEGIN
    ALTER TABLE cases 
      ADD CONSTRAINT no_overlapping_audit_years
      EXCLUDE USING GIST (
        entity_id WITH =,
        int4range(audit_year_start, audit_year_end, '[]') WITH &&
      )
      WHERE (audit_year_start IS NOT NULL AND audit_year_end IS NOT NULL);
    RAISE NOTICE 'Constraint created successfully';
  EXCEPTION
    WHEN OTHERS THEN
      RAISE WARNING 'Error: %', SQLERRM;
  END;
END `$$;
"@
& psql $db -c $exclusionSQL 2>&1
Write-Host ""

Write-Host "✅ All steps completed. Check output above for any errors." -ForegroundColor Green

