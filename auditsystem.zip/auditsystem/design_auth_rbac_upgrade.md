# Phase 2: Design - Authentication & RBAC Upgrade

## 1. Design Overview

This design proposes improvements to the Authentication & RBAC system to address:
1. Proper session invalidation/regeneration when permissions change
2. Consistent effectivePermissions resolver with role + package + overrides
3. New endpoints for permission management
4. Frontend contract for modules list
5. Session refresh strategy compatible with PostgreSQL session store

## 2. Architecture Improvements

### 2.1 effectivePermissions Resolver Enhancement

**Current State:**
- Resolver exists in `server/services/permissionService.ts`
- Calculates: role + packages (from `shared/permissions.ts`)
- Secondary: Database RBAC tables (if populated)

**Proposed Enhancement:**
- Keep existing resolver as-is (it works correctly)
- Add support for permission overrides (future-proofing)
- Add caching layer (optional, for performance)
- Ensure consistent calculation across all endpoints

**Implementation:**
- No changes needed to `getEffectivePermissions()` function
- Add helper function to compute modules list from permissions
- Add validation to ensure permissionsVersion is always returned

### 2.2 New API Endpoints

#### 2.2.1 GET /api/users/:id/effective-permissions
**Status:** ✅ Already exists (line 47 in `server/routes/users.ts`)

**Current Response:**
```json
{
  "permissions": { "entities:view": true, ... },
  "modules": ["entities", "cases", ...]
}
```

**Enhancement:**
- Add `permissionsVersion` to response
- Add `calculatedAt` timestamp
- Add `role` and `packages` used in calculation

**Proposed Response:**
```json
{
  "permissions": { "entities:view": true, ... },
  "modules": ["entities", "cases", ...],
  "permissionsVersion": 2,
  "role": "auditor",
  "packages": ["acting_coordinator"],
  "calculatedAt": "2024-01-15T10:30:00Z"
}
```

#### 2.2.2 POST /api/users/:id/recompute-permissions
**Status:** ❌ Does not exist - **NEW ENDPOINT**

**Purpose:**
- Manually trigger permission recalculation for a user
- Useful for debugging or fixing permission issues
- Increments `permissionsVersion` to trigger cache invalidation

**Request:**
```http
POST /api/users/:id/recompute-permissions
Authorization: (session cookie)
```

**Response:**
```json
{
  "message": "Permissions recomputed successfully",
  "permissions": { "entities:view": true, ... },
  "modules": ["entities", "cases", ...],
  "permissionsVersion": 3,
  "previousVersion": 2
}
```

**Authorization:**
- Requires `users:manage` permission
- Or user can recompute their own permissions

**Implementation:**
```typescript
router.post("/:id/recompute-permissions", requireAuth, async (req: Request, res: Response) => {
  const targetUserId = req.params.id;
  const currentUser = req.user as User;
  
  // Check permission: must be admin or self
  if (targetUserId !== currentUser.id && !await hasPermission(currentUser.id, 'users:manage')) {
    return res.status(403).json({ message: 'عدم دسترسی' });
  }
  
  // Get current user data
  const user = await storage.getUser(targetUserId);
  if (!user) {
    return res.status(404).json({ message: 'کاربر یافت نشد' });
  }
  
  // Recompute permissions
  const { getEffectivePermissions } = await import('../services/permissionService');
  const effectivePermissions = await getEffectivePermissions(targetUserId);
  
  // Increment permissionsVersion
  const previousVersion = user.permissionsVersion || 1;
  await storage.updateUser(targetUserId, {
    permissionsVersion: previousVersion + 1
  });
  
  // Get modules list
  const modules = computeModulesFromPermissions(effectivePermissions);
  
  // Invalidate session if not self-update
  if (targetUserId !== currentUser.id) {
    await invalidateUserSession(targetUserId);
  }
  
  // Send WebSocket notification
  const wsServer = getWebSocketServer();
  if (wsServer) {
    wsServer.notifyPermissionChange(targetUserId);
  }
  
  res.json({
    message: 'Permissions recomputed successfully',
    permissions: effectivePermissions,
    modules,
    permissionsVersion: previousVersion + 1,
    previousVersion
  });
});
```

#### 2.2.3 POST /api/users/:id/invalidate-session
**Status:** ❌ Does not exist - **NEW ENDPOINT**

**Purpose:**
- Force user to re-login by invalidating their session
- Useful when permissions change significantly
- Alternative to session regeneration

**Request:**
```http
POST /api/users/:id/invalidate-session
Authorization: (session cookie)
```

**Response:**
```json
{
  "message": "Session invalidated successfully. User must re-login.",
  "userId": "user-123"
}
```

**Authorization:**
- Requires `users:manage` permission
- Cannot invalidate own session (use logout instead)

**Implementation:**
```typescript
router.post("/:id/invalidate-session", requireAuth, requirePermission('users:manage'), async (req: Request, res: Response) => {
  const targetUserId = req.params.id;
  const currentUser = req.user as User;
  
  // Cannot invalidate own session
  if (targetUserId === currentUser.id) {
    return res.status(400).json({ message: 'برای خروج از حساب خود از دکمه خروج استفاده کنید' });
  }
  
  // Invalidate all sessions for this user
  await invalidateUserSession(targetUserId);
  
  // Send WebSocket notification
  const wsServer = getWebSocketServer();
  if (wsServer) {
    wsServer.notifySessionInvalidated(targetUserId);
  }
  
  res.json({
    message: 'Session invalidated successfully. User must re-login.',
    userId: targetUserId
  });
});
```

#### 2.2.4 POST /api/auth/refresh-session
**Status:** ❌ Does not exist - **NEW ENDPOINT**

**Purpose:**
- Refresh current user's session with latest data
- Regenerate session cookie
- Update `req.user` with fresh data from database
- Useful after permission changes

**Request:**
```http
POST /api/auth/refresh-session
Authorization: (session cookie)
```

**Response:**
```json
{
  "message": "Session refreshed successfully",
  "user": {
    ...userData,
    "effectivePermissions": [...],
    "permissionsVersion": 2
  },
  "effectivePermissions": { ... },
  "modules": [...]
}
```

**Authorization:**
- Requires authentication (any logged-in user)

**Implementation:**
```typescript
router.post('/refresh-session', requireAuth, async (req: Request, res: Response) => {
  const user = req.user as User;
  
  // Get fresh user data
  const { storage } = await import('../storage');
  const freshUser = await storage.getUser(user.id);
  
  if (!freshUser) {
    return res.status(404).json({ message: 'کاربر یافت نشد' });
  }
  
  // Get effective permissions
  const { getEffectivePermissions } = await import('../services/permissionService');
  const effectivePermissions = await getEffectivePermissions(freshUser.id);
  
  // Regenerate session
  req.logIn(freshUser, async (err) => {
    if (err) {
      return res.status(500).json({ message: 'خطا در بروزرسانی نشست' });
    }
    
    // Get modules list
    const modules = computeModulesFromPermissions(effectivePermissions);
    
    // Convert permissions to array
    const effectivePermissionsList = Object.entries(effectivePermissions)
      .filter(([_, has]) => has)
      .map(([perm]) => perm);
    
    const { password, ...userWithoutPassword } = freshUser;
    
    res.json({
      message: 'Session refreshed successfully',
      user: {
        ...userWithoutPassword,
        effectivePermissions: effectivePermissionsList,
      },
      effectivePermissions,
      modules,
      permissionsVersion: freshUser.permissionsVersion || 1
    });
  });
});
```

### 2.3 Session Invalidation/Regeneration Strategy

#### 2.3.1 PostgreSQL Session Store Compatibility

**Challenge:**
- PostgreSQL session store (`connect-pg-simple`) does not provide a method to invalidate sessions by user ID
- Sessions are stored with session ID as key, not user ID

**Solution:**
1. **Query-based invalidation:** Query session table for sessions matching user ID
2. **Session regeneration:** Use `req.regenerate()` to create new session
3. **WebSocket notification:** Notify frontend to refresh or logout

**Implementation:**
```typescript
// server/utils/sessionUtils.ts (NEW FILE)

import { sessionStore } from '../config/session';
import { db } from '../db';
import { sql } from 'drizzle-orm';

/**
 * Invalidate all sessions for a user
 * Since PostgreSQL session store doesn't support user-based lookup,
 * we query the session table directly
 */
export async function invalidateUserSession(userId: string): Promise<number> {
  try {
    // Query session table for sessions containing this user ID
    // Session data is stored as JSON, so we need to search within it
    const result = await db.execute(sql`
      DELETE FROM session
      WHERE sess::text LIKE ${`%"passport":{"user":"${userId}"}%`}
         OR sess::text LIKE ${`%"passport":{"user":{"id":"${userId}"}%`}
    `);
    
    return result.rowCount || 0;
  } catch (error) {
    console.error('Error invalidating user session:', error);
    // Fallback: return 0 (session may not exist)
    return 0;
  }
}

/**
 * Regenerate session for current user
 * Creates new session ID and updates session data
 */
export async function regenerateUserSession(req: Request): Promise<void> {
  return new Promise((resolve, reject) => {
    req.session.regenerate((err) => {
      if (err) {
        reject(err);
      } else {
        resolve();
      }
    });
  });
}
```

#### 2.3.2 Session Refresh on Permission Change

**Strategy:**
1. **Self-update:** User updates their own permissions
   - Regenerate session immediately
   - Update `req.user` with fresh data
   - Return updated permissions in response

2. **Admin-update:** Admin updates another user's permissions
   - Invalidate user's session (optional, can be configurable)
   - Send WebSocket notification
   - User's next request will refresh via `refreshUserData` middleware
   - Or user can call `/api/auth/refresh-session` manually

**Implementation in `server/routes/users.ts`:**
```typescript
// When permissions change (lines 254-282)
if (permissionChanged) {
  // ... existing code ...
  
  // Handle session invalidation/regeneration
  const currentUserId = (req.user as any)?.id;
  
  if (updatedUser.id === currentUserId) {
    // Self-update: Regenerate session
    try {
      await regenerateUserSession(req);
      req.user = freshUser;
      req.session.save((err) => {
        if (err) console.error('Failed to save session:', err);
      });
    } catch (error) {
      console.error('Failed to regenerate session:', error);
    }
  } else {
    // Admin-update: Invalidate user's session (optional)
    const shouldInvalidate = process.env.INVALIDATE_SESSION_ON_PERMISSION_CHANGE === 'true';
    
    if (shouldInvalidate) {
      await invalidateUserSession(updatedUser.id);
      // Send session invalidated notification
      if (wsServer) {
        wsServer.notifySessionInvalidated(updatedUser.id);
      }
    } else {
      // Just send permission change notification
      if (wsServer) {
        wsServer.notifyPermissionChange(updatedUser.id);
      }
    }
  }
}
```

### 2.4 Frontend Contract for Modules List

#### 2.4.1 Module Calculation Function

**Location:** `server/services/permissionService.ts` (NEW FUNCTION)

```typescript
/**
 * Calculate modules list from effective permissions
 * This ensures consistency between server and client
 */
export function computeModulesFromPermissions(
  permissions: EffectivePermissions
): string[] {
  const modules: string[] = [];
  
  if (permissions['entities:view']) modules.push('entities');
  if (permissions['cases:view']) modules.push('cases');
  if (permissions['users:manage']) modules.push('users');
  if (permissions['groups:manage']) modules.push('groups');
  if (permissions['groups:set_targets']) modules.push('target-settings');
  if (permissions['tickets:submit'] || permissions['tickets:approve']) {
    modules.push('tickets');
  }
  if (permissions['cases:view']) modules.push('documents');
  if (permissions['settings:manage']) modules.push('settings');
  if (permissions['logs:view']) modules.push('audit-logs');
  if (permissions['reports:generate']) modules.push('reports');
  
  return modules;
}
```

#### 2.4.2 Include Modules in All Auth Endpoints

**Update `/api/auth/login`:**
```typescript
// After calculating effectivePermissions (line 138)
const modules = computeModulesFromPermissions(effectivePermissions);

return res.json({
  message: 'ورود موفقیت آمیز',
  user: {
    ...userResponse,
    effectivePermissions: effectivePermissionsList,
  },
  effectivePermissions,
  modules, // ADD THIS
  permissionsVersion: freshUser.permissionsVersion || 1, // ADD THIS
  mustChangePassword: user.mustChangePassword || false,
  passwordExpired: user.passwordExpiresAt ? new Date() > user.passwordExpiresAt : false,
});
```

**Update `/api/auth/me`:**
```typescript
// After calculating effectivePermissions (line 216)
const modules = computeModulesFromPermissions(effectivePermissions);

res.json({ 
  user: {
    ...userResponse,
    effectivePermissions: effectivePermissionsList,
  },
  effectivePermissions,
  effectivePermissionsList,
  modules, // ADD THIS
  permissionsVersion,
});
```

**Update `/api/auth/effective-permissions`:**
```typescript
// Optionally add modules to this endpoint too
const modules = computeModulesFromPermissions(permissions);

res.json({
  ...permissions,
  modules, // ADD THIS (optional)
});
```

## 3. Database Changes

### 3.1 No Schema Changes Required

**Current Schema:**
- `users.permissionsVersion` - Already exists ✅
- `session` table - Already exists ✅

**No migrations needed** - All changes are code-only.

## 4. UI/UX Improvements

### 4.1 Frontend Changes

#### 4.1.1 Use Server-Provided Modules List

**Location:** `client/src/components/AppSidebar.tsx`

**Current:** Client calculates modules from permissions
**Proposed:** Use `modules` array from server if available, fallback to client calculation

```typescript
// In AppSidebar component
const { user } = useAuth();
const serverModules = user?.modules; // From /api/auth/me response

// Use server modules if available, otherwise calculate client-side
const visibleMenuItems = useMemo(() => {
  if (serverModules) {
    // Use server-provided modules
    return menuItems.filter(item => {
      if (!item.permission && !item.requireAny) return true; // Dashboard always visible
      // Map module names to menu items
      const moduleMap: Record<string, string> = {
        'entities': '/entities',
        'cases': '/cases',
        'users': '/users',
        'groups': '/groups',
        'target-settings': '/target-settings',
        'tickets': '/tickets',
        'documents': '/documents',
        'settings': '/settings',
        'audit-logs': '/audit-logs',
        'reports': '/reports',
      };
      return serverModules.some(module => moduleMap[module] === item.url);
    });
  }
  
  // Fallback to client-side calculation
  return menuItems.filter((item) => {
    // ... existing permission check logic ...
  });
}, [user, serverModules, hasPermission]);
```

#### 4.1.2 Add Session Refresh on Permission Change

**Location:** `client/src/contexts/AuthContext.tsx`

**Current:** WebSocket notification triggers user data refresh
**Proposed:** Also call `/api/auth/refresh-session` to regenerate session

```typescript
// In WebSocket message handler (line 286)
if (message.type === 'permission_change') {
  console.log('Permission change notification received, refreshing...');
  
  // Clear caches
  const { clearPermissionsCache } = await import('../utils/permissions');
  clearPermissionsCache();
  
  // Option 1: Refresh session endpoint (recommended)
  try {
    const refreshResponse = await fetch('/api/auth/refresh-session', {
      method: 'POST',
      credentials: 'include',
    });
    
    if (refreshResponse.ok) {
      const data = await refreshResponse.json();
      setUser({
        ...data.user,
        modules: data.modules,
        permissionsVersion: data.permissionsVersion,
      });
      return; // Success, exit early
    }
  } catch (error) {
    console.error('Failed to refresh session:', error);
  }
  
  // Option 2: Fallback to /api/auth/me
  const response = await fetch('/api/auth/me', {
    credentials: 'include',
    cache: 'no-store',
  });
  // ... existing code ...
}
```

#### 4.1.3 Handle Session Invalidated Notification

**Location:** `client/src/contexts/AuthContext.tsx`

**New:** Handle `session_invalidated` WebSocket message

```typescript
// In WebSocket message handler
if (message.type === 'session_invalidated') {
  console.log('Session invalidated, logging out...');
  // Clear user data
  setUser(null);
  clearPermissionsCache();
  // Redirect to login
  window.location.href = '/login';
}
```

## 5. Acceptance Criteria

### 5.1 effectivePermissions Resolver

✅ **AC1:** `getEffectivePermissions(userId)` correctly calculates permissions from role + packages
✅ **AC2:** Resolver returns consistent results across all endpoints
✅ **AC3:** System admin always gets all permissions
✅ **AC4:** Package permissions merge/add to base role permissions (don't remove)

### 5.2 API Endpoints

✅ **AC5:** `GET /api/users/:id/effective-permissions` returns permissions + modules + permissionsVersion
✅ **AC6:** `POST /api/users/:id/recompute-permissions` exists and works
✅ **AC7:** `POST /api/users/:id/invalidate-session` exists and works
✅ **AC8:** `POST /api/auth/refresh-session` exists and works
✅ **AC9:** All auth endpoints (`/login`, `/me`, `/effective-permissions`) return `modules` array
✅ **AC10:** All auth endpoints return `permissionsVersion`

### 5.3 Session Management

✅ **AC11:** When user updates their own permissions, session is regenerated
✅ **AC12:** When admin updates another user's permissions, session can be invalidated (configurable)
✅ **AC13:** Session invalidation works with PostgreSQL session store
✅ **AC14:** WebSocket notifications are sent on permission changes
✅ **AC15:** Frontend receives and handles permission change notifications

### 5.4 Frontend Contract

✅ **AC16:** Frontend receives `modules` array from server in login/me responses
✅ **AC17:** Frontend uses server-provided modules list when available
✅ **AC18:** Frontend falls back to client-side calculation if modules not provided
✅ **AC19:** Frontend refreshes session on permission change notification
✅ **AC20:** Frontend handles session invalidated notification

### 5.5 Reproducible Scenarios Fixed

✅ **AC21:** Scenario 1 (Assign Coordination Package → APIs return empty) is fixed
  - Session is refreshed/invalidated
  - Permissions are recalculated
  - Frontend receives updated permissions

✅ **AC22:** Scenario 2 (Permission changes not reflected until re-login) is fixed
  - Session is regenerated on self-update
  - WebSocket notification triggers refresh
  - Frontend calls refresh-session endpoint

✅ **AC23:** Scenario 3 (API returns 403 even though user has permission) is fixed
  - Permissions are recalculated correctly
  - Session has fresh user data
  - Permission checks use latest permissions

## 6. Security Considerations

### 6.1 Authorization

- All new endpoints require proper authorization
- `recompute-permissions`: Admin or self
- `invalidate-session`: Admin only (cannot invalidate own session)
- `refresh-session`: Any authenticated user (self only)

### 6.2 Session Security

- Session regeneration creates new session ID (prevents session fixation)
- Session invalidation removes old sessions (prevents unauthorized access)
- WebSocket notifications are authenticated

### 6.3 Rate Limiting

- Consider rate limiting on `refresh-session` endpoint
- Consider rate limiting on `recompute-permissions` endpoint

## 7. Testing Strategy

### 7.1 Unit Tests

- Test `computeModulesFromPermissions()` function
- Test `invalidateUserSession()` function
- Test `regenerateUserSession()` function

### 7.2 Integration Tests

- Test login returns modules + permissionsVersion
- Test `/api/auth/me` returns modules + permissionsVersion
- Test `recompute-permissions` endpoint
- Test `invalidate-session` endpoint
- Test `refresh-session` endpoint
- Test session regeneration on self-update
- Test session invalidation on admin-update

### 7.3 E2E Tests

- Test Scenario 1: Assign package → user sees modules → APIs work
- Test Scenario 2: Permission change → reflected without re-login
- Test Scenario 3: Permission check works correctly

## 8. Migration Plan

### 8.1 Backward Compatibility

- All changes are backward compatible
- Existing endpoints continue to work
- New endpoints are additive
- Frontend falls back to client-side calculation if modules not provided

### 8.2 Deployment Steps

1. Deploy backend changes (new endpoints, session utilities)
2. Deploy frontend changes (use server modules, handle notifications)
3. Test in staging environment
4. Monitor for errors
5. Roll out to production

### 8.3 Rollback Plan

- Remove new endpoints (if needed)
- Frontend will fall back to client-side calculation
- No database changes to rollback

## 9. Performance Considerations

### 9.1 Session Invalidation

- Querying session table by user ID may be slow with many sessions
- Consider adding index on session data (if possible)
- Consider limiting session invalidation to recent sessions only

### 9.2 Permission Calculation

- Current implementation queries database on each check
- Consider adding caching layer (Redis) for permissions
- Consider caching permissions in session (with version check)

## 10. Future Enhancements

### 10.1 Permission Overrides

- Add support for permission overrides (grant/deny specific permissions)
- Store overrides in database
- Merge overrides with role + package permissions

### 10.2 Permission Caching

- Add Redis cache for permissions
- Cache permissions per user with TTL
- Invalidate cache on permission changes

### 10.3 Audit Trail

- Log all permission changes
- Log session invalidations
- Track permission calculation history

