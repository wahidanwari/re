# Entity Excel Import Feature

This document describes the Excel import feature for entities in the audit system.

## Overview

The Excel import feature allows Coordinators and System Admins to bulk import entities from Excel/CSV files. The system validates data, processes imports asynchronously, and provides detailed error reports.

## Features

- **4-Step Wizard**: Upload → Preview & Validate → Confirm → Progress & Result
- **Validation**: Row-level validation with errors and warnings
- **Async Processing**: Background job processing using Bull + Redis
- **Error Reporting**: Downloadable error reports with invalid rows
- **Template Download**: Sample Excel template with exact headers
- **Permission-Based**: Only Coordinators and Admins can import

## Database Schema

### New Tables

1. **import_batches**: Tracks import operations
   - `id`: Serial primary key
   - `uploaded_by`: User ID who uploaded
   - `file_name`, `file_path`, `file_size_bytes`: File metadata
   - `total_rows`, `created_count`, `updated_count`, `invalid_count`: Statistics
   - `status`: 'pending', 'processing', 'completed', 'failed'
   - `error_file_path`: Path to error report file

2. **import_errors**: Stores validation and processing errors
   - `id`: Serial primary key
   - `batch_id`: Foreign key to import_batches
   - `row_number`: Row number in the file
   - `tin`, `company_name`: Entity identifiers
   - `error_type`: 'validation_error', 'duplicate_tin', 'database_error'
   - `error_message`: Detailed error message
   - `raw_row_data`: JSONB with original row data

### Entity Table Extensions

New columns added to `entities` table:
- `referred_date_shamsi`: VARCHAR(10) - Shamsi date string (DD-MM-YYYY)
- `referred_date`: DATE - Gregorian date
- `import_batch_id`: INTEGER - Reference to import batch
- `created_by_import`: BOOLEAN - Flag indicating import origin
- `responsible_evaluator`: VARCHAR(255) - Evaluator name from import

## API Endpoints

### 1. POST /api/imports/entities/upload

Upload Excel/CSV file and create import batch.

**Request:**
- Method: POST
- Content-Type: multipart/form-data
- Body: `file` (Excel/CSV file, max 10MB)
- Headers: Authentication required
- Permissions: `entities:import` (Coordinator or Admin)

**Response:**
```json
{
  "batchId": 1,
  "totalRows": 100,
  "preview": [
    {
      "valid": true,
      "warnings": [],
      "errors": [],
      "row": { ... }
    }
  ],
  "previewCount": 50
}
```

**cURL Example:**
```bash
curl -X POST http://localhost:5000/api/imports/entities/upload \
  -H "Cookie: connect.sid=..." \
  -F "file=@entities.xlsx"
```

### 2. GET /api/imports/:batchId/preview

Get preview details for a batch.

**Request:**
- Method: GET
- Path: `/api/imports/:batchId/preview`
- Headers: Authentication required

**Response:**
```json
{
  "batch": { ... },
  "preview": [ ... ],
  "totalRows": 100,
  "previewCount": 50
}
```

**cURL Example:**
```bash
curl -X GET http://localhost:5000/api/imports/1/preview \
  -H "Cookie: connect.sid=..."
```

### 3. POST /api/imports/:batchId/confirm

Confirm import and queue background job.

**Request:**
- Method: POST
- Path: `/api/imports/:batchId/confirm`
- Headers: Authentication required
- Permissions: `entities:import`

**Response:**
```json
{
  "message": "واردات در صف پردازش قرار گرفت",
  "batchId": 1
}
```

**cURL Example:**
```bash
curl -X POST http://localhost:5000/api/imports/1/confirm \
  -H "Cookie: connect.sid=..."
```

### 4. GET /api/imports/:batchId/status

Get batch status and results.

**Request:**
- Method: GET
- Path: `/api/imports/:batchId/status`
- Headers: Authentication required

**Response:**
```json
{
  "batch": {
    "id": 1,
    "status": "completed",
    "totalRows": 100,
    "createdCount": 80,
    "updatedCount": 15,
    "invalidCount": 5
  },
  "errors": [ ... ],
  "totalErrors": 5
}
```

**cURL Example:**
```bash
curl -X GET http://localhost:5000/api/imports/1/status \
  -H "Cookie: connect.sid=..."
```

### 5. GET /api/imports/:batchId/errors/download

Download error report file.

**Request:**
- Method: GET
- Path: `/api/imports/:batchId/errors/download`
- Headers: Authentication required

**Response:**
- Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet
- File download: Excel file with error details

**cURL Example:**
```bash
curl -X GET http://localhost:5000/api/imports/1/errors/download \
  -H "Cookie: connect.sid=..." \
  -o errors.xlsx
```

### 6. GET /api/imports/entities/template

Download sample template file.

**Request:**
- Method: GET
- Path: `/api/imports/entities/template`
- Headers: Authentication required

**Response:**
- Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet
- File download: `entities_import_template.xlsx`

**cURL Example:**
```bash
curl -X GET http://localhost:5000/api/imports/entities/template \
  -H "Cookie: connect.sid=..." \
  -o template.xlsx
```

## Excel Template Format

The template file (`entities_import_template.xlsx`) has the following headers (Persian):

1. **نام نهاد** (Company Name) - Required
2. ** نمبر تشخیصیه** (TIN) - Required, Unique
3. **ماهیت تشبث** (Business Nature) - Required
4. **سال‌های بررسی** (Years Under Review) - Optional, Format: `1402` or `1398-1401`
5. **تاریخ ارجاع به بررسی** (Referral Date) - Optional, Format: `DD-MM-YYYY` (Shamsi)
6. **گروه ارجاع‌دهنده** (Referral Group) - Optional
7. **وضعیت نهاد** (Status) - Optional, Values: `جدید`, `در جریان بررسی`, `تکمیل شده`
8. **ملاحظات** (Notes) - Optional

## Validation Rules

### Required Fields
- نام نهاد (Company Name)
-  نمبر تشخیصیه (TIN)
- ماهیت تشبث (Business Nature)

### TIN Validation
- Must be unique (upsert by TIN)
- Duplicate TIN in file: Warning in preview, last-one-wins on import
- Existing TIN in DB: Warning, entity will be updated

### Date Validation
- **تاریخ ارجاع به بررسی**: Must be Shamsi format `DD-MM-YYYY`
- Converted to Gregorian date automatically
- Invalid dates result in validation error

### Years Under Review Validation
- Must be numeric (e.g., `1402`) or range (e.g., `1398-1401`)
- Years must be between 1300-1500
- Invalid format results in validation error

### Status Mapping
Persian status strings are mapped to canonical statuses:
- `جدید` → `NEW`
- `در جریان بررسی` → `IN_REVIEW`
- `تکمیل شده` → `COMPLETED`

## Background Processing

### Queue System

The import uses **Bull** queue with **Redis** for background processing:

1. **Upload**: File is uploaded and parsed, batch created with status `pending`
2. **Preview**: First 50 rows are validated and shown to user
3. **Confirm**: User confirms, batch status set to `processing`, job queued
4. **Processing**: Worker processes file, creates/updates entities, records errors
5. **Completion**: Batch status set to `completed`, error report generated if needed

### Worker Setup

The worker is automatically started when the server starts. It processes jobs from the `entity-import` queue.

**Queue Configuration:**
- Redis connection: `REDIS_HOST` (default: localhost), `REDIS_PORT` (default: 6379)
- Job attempts: 3 with exponential backoff
- Completed jobs: Kept for 24 hours
- Failed jobs: Kept for 7 days

## File Storage

### Upload Directory
- Path: `uploads/imports/`
- Files are stored with unique names: `import-{timestamp}-{random}.{ext}`

### Error Reports
- Path: `uploads/imports/errors/`
- Files: `errors-{batchId}-{timestamp}.xlsx`
- Contains: Invalid rows with error messages

## Permissions

### Required Permission
- `entities:import` - Only Coordinators and System Admins have this permission

### Role Access
- **System Admin**: Full access
- **Coordinator**: Full access (via `acting_coordinator` package)
- **Senior Auditor**: No access
- **Auditor**: No access

## Rate Limiting

- **Upload**: 10 uploads per hour per user
- **Confirm**: 20 confirmations per hour per user
- Uses in-memory rate limiting (consider Redis for distributed systems)

## Error Handling

### Validation Errors
- Row-level validation errors are shown in preview
- Invalid rows are skipped during import
- Errors are recorded in `import_errors` table

### Processing Errors
- Database errors are caught and recorded
- Batch status set to `failed` on critical errors
- Error messages stored in `batch.error_message`

## Frontend Components

### EntityImportWizard
Location: `client/src/components/EntityImportWizard.tsx`

A 4-step wizard component:
1. **Upload**: File selection and template download
2. **Preview**: Validation results table (first 50 rows)
3. **Confirm**: Confirmation dialog
4. **Progress**: Real-time progress indicator (polls every 2 seconds)
5. **Result**: Summary with counts and error report download

### Integration
The wizard is integrated into the Entities page (`client/src/pages/Entities.tsx`) with an "واردات Excel" button visible only to Coordinators and Admins.

## Running the Worker

The worker is automatically started with the server. For production, you may want to run workers separately:

```bash
# Start Redis (if not already running)
# Windows: See REDIS_SETUP_WINDOWS.md for installation options
# Linux/Mac: redis-server
# Docker: docker run -d -p 6379:6379 redis:alpine

# Start server (worker starts automatically)
npm run dev:server
```

**Note:** Redis is required for the import feature. See `REDIS_SETUP_WINDOWS.md` for Windows installation instructions.

## Environment Variables

```env
# Redis Configuration (optional, defaults shown)
REDIS_HOST=localhost
REDIS_PORT=6379
REDIS_PASSWORD=

# Debug Logging (optional)
DEBUG_LOGGING=false
```

## Testing

### Unit Tests
- Validation functions: `server/services/importValidation.ts`
- Test Shamsi date conversion, years validation, status mapping

### Integration Tests
- Full import flow: Upload → Preview → Confirm → Process → Result
- Error handling: Invalid rows, duplicate TINs, database errors

### Manual Testing Steps

1. **Download Template**:
   ```bash
   curl -X GET http://localhost:5000/api/imports/entities/template \
     -H "Cookie: connect.sid=..." \
     -o template.xlsx
   ```

2. **Fill Template** with sample data

3. **Upload File**:
   ```bash
   curl -X POST http://localhost:5000/api/imports/entities/upload \
     -H "Cookie: connect.sid=..." \
     -F "file=@template.xlsx"
   ```

4. **Check Preview**:
   ```bash
   curl -X GET http://localhost:5000/api/imports/1/preview \
     -H "Cookie: connect.sid=..."
   ```

5. **Confirm Import**:
   ```bash
   curl -X POST http://localhost:5000/api/imports/1/confirm \
     -H "Cookie: connect.sid=..."
   ```

6. **Check Status** (poll until completed):
   ```bash
   curl -X GET http://localhost:5000/api/imports/1/status \
     -H "Cookie: connect.sid=..."
   ```

7. **Download Errors** (if any):
   ```bash
   curl -X GET http://localhost:5000/api/imports/1/errors/download \
     -H "Cookie: connect.sid=..." \
     -o errors.xlsx
   ```

## Migration

Run the database migration:

```bash
psql $DATABASE_URL -f migrations/021_entity_import_system.sql
```

Or use the migration script:

```bash
npm run db:migrate-entity-import
```

## Troubleshooting

### Redis Connection Issues
- Ensure Redis is running: `redis-cli ping`
- Check `REDIS_HOST` and `REDIS_PORT` environment variables

### File Upload Issues
- Check `uploads/imports/` directory exists and is writable
- Verify file size limit (10MB)
- Check file format (.xlsx, .xls, .csv)

### Processing Issues
- Check worker logs for errors
- Verify database connection
- Check `import_batches` table for batch status

### Permission Issues
- Verify user has `entities:import` permission
- Check user role (must be Coordinator or Admin)

## Future Enhancements

- CSV parsing improvements (handle quoted fields, different delimiters)
- Progress tracking via WebSocket instead of polling
- Email notifications on completion
- Import history and audit trail
- Batch import scheduling
- Custom validation rules configuration

