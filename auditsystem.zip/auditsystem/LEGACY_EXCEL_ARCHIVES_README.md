# Legacy Data Archival & Access Module

## Overview

The Legacy Data Archival & Access Module (بایگانی داده‌های Excel قدیمی) provides a structured, read-only repository for archiving legacy Excel files with full search, filtering, versioning, and access logging capabilities.

## Features

- **Structured Storage**: Files organized by year in `/data/archives/legacy-excel/{year}/`
- **Versioning**: Automatic version management when uploading files with the same name
- **Access Control**: Role-based permissions (Director, Coordinator, System Admin)
- **Full Audit Trail**: All file access events logged (download, upload, view metadata)
- **Search & Filter**: Advanced search with filters by year, category, uploader, date range
- **Read-Only Files**: Files set to read-only (chmod 0444) after ingestion

## Permissions

- **Director**: `archives:view`, `archives:upload`
- **Coordinator** (acting_coordinator package): `archives:view`, `archives:upload`
- **System Admin**: `archives:view`, `archives:upload`, `archives:delete`

## Database Schema

### Tables

1. **archived_files**: Main file metadata
   - `id`, `file_name`, `original_file_name`, `year`, `category`, `description`
   - `path`, `size_bytes`, `uploaded_by`, `uploaded_at`
   - `is_readonly`, `current_version`, `deleted_at`

2. **archived_file_versions**: Version history
   - `id`, `archived_file_id`, `version_number`
   - `file_name`, `path`, `size_bytes`, `uploaded_by`, `uploaded_at`, `notes`

3. **archived_file_access_logs**: Access audit trail
   - `id`, `archived_file_id`, `user_id`, `action`, `ip_address`, `created_at`

## API Endpoints

### GET /api/archives
List/search archived files with pagination and filters.

**Query Parameters:**
- `page` (default: 1)
- `size` (default: 25, max: 100)
- `year` - Filter by year
- `category` - Filter by category
- `q` - Search query (searches filename, description, category)
- `sort` - Sort order (e.g., `uploadedAt:desc`, `year:asc`)
- `uploadedBy` - Filter by uploader user ID
- `dateFrom` - Filter by upload date (from)
- `dateTo` - Filter by upload date (to)

**Response:**
```json
{
  "files": [...],
  "pagination": {
    "total": 100,
    "page": 1,
    "size": 25,
    "totalPages": 4
  }
}
```

### GET /api/archives/:id
Get file metadata and version history.

**Response:**
```json
{
  "id": "...",
  "fileName": "...",
  "originalFileName": "...",
  "year": 1400,
  "category": "...",
  "description": "...",
  "versions": [...]
}
```

### GET /api/archives/:id/download?version=N
Download file (current version or specific version).

**Headers:**
- `Content-Type`: `application/vnd.openxmlformats-officedocument.spreadsheetml.sheet`
- `Content-Disposition`: `attachment; filename="..."`

### POST /api/archives
Upload new file for archiving.

**Required Permissions:** `archives:upload`

**Form Data:**
- `file` (multipart file) - Excel file (.xlsx, .xls)
- `year` (required) - Shamsi year (e.g., 1400)
- `category` (required) - Category classification
- `description` (optional) - Short description
- `notes` (optional) - Notes for this version

**Response:**
```json
{
  "message": "فایل با موفقیت آپلود و بایگانی شد",
  "file": {
    "id": "...",
    "fileName": "...",
    "version": 1
  },
  "checksum": "..."
}
```

### DELETE /api/archives/:id
Soft delete archived file (System Admin only).

**Required Permissions:** `archives:delete`

## File Naming Convention

Stored files follow this format:
```
[YYYY]_[Category]_[ShortDescription]_[OriginalFileName]_[v{N}].xlsx
```

Example:
```
1400_گزارشات مالی_گزارش مالی سال 1400_original_file_v1.xlsx
```

## Storage Structure

```
/data/archives/legacy-excel/
├── incoming/          # Staging area for uploads
├── 1400/             # Year-based folders
├── 1401/
└── ...
```

## Migration Script

### Prerequisites

Install the required dependency for CSV parsing:
```bash
npm install csv-parse
```

### Ingesting Legacy Files

Use the ingestion script to migrate existing Excel files:

```bash
npm run ingest-legacy-excel -- --csv metadata.csv --source-dir /path/to/files --migration-user-id <user-id>
```

### CSV Format (metadata.csv)

```csv
originalFileName,year,category,description,sourcePath
file1.xlsx,1400,گزارشات مالی,گزارش مالی سال 1400,/path/to/file1.xlsx
file2.xlsx,1401,اسناد حسابداری,اسناد حسابداری سال 1401,/path/to/file2.xlsx
```

**Columns:**
- `originalFileName`: Original filename
- `year`: Shamsi year (e.g., 1400)
- `category`: Category classification
- `description`: Short description
- `sourcePath`: Full path to source file (or filename if using --source-dir)

### Options

- `--csv <path>`: Path to CSV metadata file (required)
- `--source-dir <path>`: Source directory (optional, if all files are in one directory)
- `--migration-user-id <id>`: User ID for migration (required)
- `--dry-run`: Preview what would be ingested without making changes

### Example

```bash
# Dry run first
npm run ingest-legacy-excel -- --csv metadata.csv --source-dir ./legacy-files --migration-user-id abc123 --dry-run

# Actual ingestion
npm run ingest-legacy-excel -- --csv metadata.csv --source-dir ./legacy-files --migration-user-id abc123
```

### What the Script Does

1. Parses CSV metadata file
2. Validates each source file exists
3. Moves files to `/data/archives/legacy-excel/{year}/`
4. Generates stored filename according to convention
5. Sets read-only permissions (chmod 0444)
6. Creates `ArchivedFile` and `ArchivedFileVersion` database records
7. Calculates and stores file checksums
8. Logs all operations

## Configuration

### Environment Variables

- `ARCHIVE_BASE_PATH`: Base path for archives (default: `./data/archives/legacy-excel`)

### File Size Limits

- Maximum file size: 100MB per file
- Allowed types: `.xlsx`, `.xls` (Excel files only)

## Frontend Usage

1. Navigate to "بایگانی داده‌های Excel قدیمی" in the sidebar
2. Use search and filters to find files
3. Click "آپلود فایل جدید" to upload (if you have permission)
4. Click the eye icon to view file details and version history
5. Click the download icon to download files
6. System Admins can delete files (soft delete)

## Security

- All file access is logged with user ID and IP address
- Files are served via authenticated API endpoints (not direct file access)
- Read-only permissions enforced at filesystem level
- Role-based access control for all operations

## Testing

### Unit Tests

```bash
npm test -- archives
```

### Integration Tests

```bash
npm test -- archives-integration
```

## Troubleshooting

### Files Not Appearing

- Check file permissions on archive directory
- Verify database migration was run: `migrations/026_legacy_excel_archives.sql`
- Check server logs for ingestion errors

### Upload Fails

- Verify file is Excel format (.xlsx or .xls)
- Check file size is under 100MB
- Ensure user has `archives:upload` permission
- Check server logs for detailed error messages

### Permission Errors

- On Windows, chmod may not work as expected (files are still moved correctly)
- Ensure archive directory is writable by the application

## Deployment Notes

1. Run database migration:
   ```bash
   # Windows/PowerShell (recommended - no psql needed)
   npm run db:migrate-archives
   
   # Or if you have psql installed:
   # psql $DATABASE_URL -f migrations/026_legacy_excel_archives.sql
   ```

2. Create archive directory structure:
   ```bash
   mkdir -p /data/archives/legacy-excel/incoming
   ```

3. Set appropriate permissions:
   ```bash
   chmod 755 /data/archives/legacy-excel
   chmod 755 /data/archives/legacy-excel/incoming
   ```

4. Run ingestion script for legacy files (if applicable)

5. Verify API endpoints are accessible

## Future Enhancements

- Antivirus scanning integration (mentioned in requirements)
- Advanced search with full-text indexing
- Bulk upload support
- Export access logs
- File preview (if needed)

