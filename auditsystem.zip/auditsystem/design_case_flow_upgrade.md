# Phase 2: Design - Case Management Core Flow Upgrade

## 1. Design Overview

This design proposes a complete "Level-4" case lifecycle system with:
1. Explicit state machine with validated transitions
2. Comprehensive validation rules per state
3. Professional UI/UX with RTL support
4. Complete audit trail for all transitions
5. Unified API contracts with full validation
6. Database integrity constraints

## 2. State Machine Design

### 2.1 Case Status Enum

**Location:** `shared/schema.ts` (NEW)

```typescript
export const CaseStatus = {
  NEW: 'جدید',
  ASSIGNED: 'اختصاص داده شده',
  IN_PROGRESS: 'در جریان بررسی',
  COMPLETED: 'تکمیل شده',
  PENDING_APPROVAL: 'منتظر تایید',
  APPROVED: 'تایید شده',
  REJECTED: 'رد شده',
} as const;

export type CaseStatus = typeof CaseStatus[keyof typeof CaseStatus];
```

**Status Definitions:**
- `'جدید'` (NEW) - Case created, not yet assigned
- `'اختصاص داده شده'` (ASSIGNED) - Case assigned to user/group, not started
- `'در جریان بررسی'` (IN_PROGRESS) - Case is actively being worked on
- `'تکمیل شده'` (COMPLETED) - Case work finished, report complete, ready for approval
- `'منتظر تایید'` (PENDING_APPROVAL) - Case submitted for approval (optional intermediate state)
- `'تایید شده'` (APPROVED) - Case approved, final state
- `'رد شده'` (REJECTED) - Case rejected, can be reopened

### 2.2 State Machine Diagram

```
┌─────────┐
│  جدید   │ (NEW)
└────┬────┘
     │ [assign]
     ↓
┌─────────────────┐
│ اختصاص داده شده │ (ASSIGNED)
└────┬────────────┘
     │ [start]
     ↓
┌──────────────────┐
│ در جریان بررسی   │ (IN_PROGRESS)
└────┬─────────────┘
     │ [complete]
     ↓
┌──────────────────┐
│ تکمیل شده        │ (COMPLETED)
└────┬─────────────┘
     │ [submit_for_approval] (optional)
     ↓
┌──────────────────┐
│ منتظر تایید      │ (PENDING_APPROVAL)
└────┬─────────────┘
     │ [approve] or [reject]
     ↓
┌─────────────┐    ┌──────────┐
│ تایید شده   │    │ رد شده   │
│ (APPROVED)  │    │ (REJECTED)│
└─────────────┘    └────┬─────┘
                        │ [reopen] (optional)
                        ↓
                 ┌──────────────────┐
                 │ در جریان بررسی   │ (IN_PROGRESS)
                 └──────────────────┘
```

### 2.3 Allowed Transitions

**Transition Rules:**

| From State | To State | Transition Name | Required Conditions | Permission Required |
|------------|----------|-----------------|---------------------|-------------------|
| `جدید` | `اختصاص داده شده` | `assign` | - | `cases:assign_to_auditor` OR `cases:assign_to_group` |
| `اختصاص داده شده` | `در جریان بررسی` | `start` | Must be assigned (`assignedTo` OR `receivingGroup`) | `cases:view` (assigned user) |
| `در جریان بررسی` | `تکمیل شده` | `complete` | Report validation passes | `cases:complete` |
| `تکمیل شده` | `منتظر تایید` | `submit_for_approval` | - | `cases:complete` |
| `تکمیل شده` | `تایید شده` | `approve` | - | `tickets:approve` |
| `منتظر تایید` | `تایید شده` | `approve` | - | `tickets:approve` |
| `منتظر تایید` | `رد شده` | `reject` | Must provide `rejectionReason` | `tickets:approve` |
| `تکمیل شده` | `رد شده` | `reject` | Must provide `rejectionReason` | `tickets:approve` |
| `رد شده` | `در جریان بررسی` | `reopen` | - | `tickets:approve` OR `cases:complete` |
| `در جریان بررسی` | `اختصاص داده شده` | `reassign` | - | `cases:assign_to_auditor` OR `cases:assign_to_group` |

**Special Rules:**
- `تایید شده` and `رد شده` are terminal states (cannot transition from them, except `رد شده` → `در جریان بررسی` via `reopen`)
- System admin can override transition rules (with audit log)
- Coordinator can perform most transitions (with audit log)

### 2.4 State Validation Rules

**Per-State Requirements:**

#### `جدید` (NEW)
- ✅ No assignment required
- ✅ No report required
- ❌ Cannot be completed
- ❌ Cannot be approved/rejected

#### `اختصاص داده شده` (ASSIGNED)
- ✅ Must have `assignedTo` OR `receivingGroup`
- ✅ Cannot transition to `در جریان بررسی` without assignment
- ❌ Cannot be completed
- ❌ Cannot be approved/rejected

#### `در جریان بررسی` (IN_PROGRESS)
- ✅ Must have `assignedTo` OR `receivingGroup`
- ✅ Can have partial report
- ❌ Cannot be completed without full report validation
- ❌ Cannot be approved/rejected

#### `تکمیل شده` (COMPLETED)
- ✅ Must have complete report (all required fields)
- ✅ Must have `completedBy` and `completedAt`
- ✅ Can transition to `منتظر تایید` or directly to `تایید شده`/`رد شده`
- ❌ Cannot go back to `در جریان بررسی` (except via reject → reopen)

#### `منتظر تایید` (PENDING_APPROVAL)
- ✅ Must have complete report
- ✅ Must have `completedBy` and `completedAt`
- ✅ Can only transition to `تایید شده` or `رد شده`
- ❌ Cannot go back to previous states

#### `تایید شده` (APPROVED)
- ✅ Terminal state (no transitions out)
- ✅ Must have `approvedBy` and `approvedAt`
- ❌ Cannot be modified
- ❌ Cannot transition to any other state

#### `رد شده` (REJECTED)
- ✅ Must have `rejectedBy`, `rejectedAt`, and `rejectionReason`
- ✅ Can transition to `در جریان بررسی` via `reopen`
- ❌ Cannot transition to `تایید شده` directly (must go through `در جریان بررسی` → `تکمیل شده`)

## 3. Database Changes

### 3.1 Status Enum Constraint

**Migration:** `migrations/002_case_status_enum.sql`

```sql
-- Create enum type for case status
CREATE TYPE case_status_enum AS ENUM (
  'جدید',
  'اختصاص داده شده',
  'در جریان بررسی',
  'تکمیل شده',
  'منتظر تایید',
  'تایید شده',
  'رد شده'
);

-- Add check constraint to cases table
ALTER TABLE cases 
  DROP CONSTRAINT IF EXISTS cases_status_check;

ALTER TABLE cases
  ADD CONSTRAINT cases_status_check 
  CHECK (status IN ('جدید', 'اختصاص داده شده', 'در جریان بررسی', 'تکمیل شده', 'منتظر تایید', 'تایید شده', 'رد شده'));

-- Create index for status filtering
CREATE INDEX IF NOT EXISTS idx_cases_status ON cases(status);
CREATE INDEX IF NOT EXISTS idx_cases_assigned_to ON cases(assigned_to) WHERE assigned_to IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_cases_receiving_group ON cases(receiving_group) WHERE receiving_group IS NOT NULL;
```

### 3.2 Case Status Transitions Table

**New Table:** `case_status_transitions`

**Purpose:** Track all status transitions with full audit trail

**Schema:**
```sql
CREATE TABLE case_status_transitions (
  id VARCHAR PRIMARY KEY DEFAULT gen_random_uuid(),
  case_id VARCHAR NOT NULL REFERENCES cases(id) ON DELETE CASCADE,
  from_status TEXT NOT NULL,
  to_status TEXT NOT NULL,
  transition_name TEXT NOT NULL, -- 'assign', 'start', 'complete', etc.
  transitioned_by VARCHAR NOT NULL REFERENCES users(id),
  transitioned_at TIMESTAMP NOT NULL DEFAULT NOW(),
  notes TEXT, -- Optional notes/reason for transition
  rejection_reason TEXT, -- If transition is 'reject'
  metadata JSONB, -- Additional context (IP address, user agent, etc.)
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_case_status_transitions_case_id ON case_status_transitions(case_id);
CREATE INDEX idx_case_status_transitions_transitioned_at ON case_status_transitions(transitioned_at);
CREATE INDEX idx_case_status_transitions_from_status ON case_status_transitions(from_status);
CREATE INDEX idx_case_status_transitions_to_status ON case_status_transitions(to_status);
```

**Benefits:**
- Complete history of all status changes
- Query "when did case move from X to Y"
- Audit trail for compliance
- Debugging state issues

### 3.3 Foreign Key Constraints

**Migration:** Add foreign key constraints

```sql
-- Add foreign key constraints for user references
ALTER TABLE cases
  ADD CONSTRAINT fk_cases_approved_by 
  FOREIGN KEY (approved_by) REFERENCES users(id) ON DELETE SET NULL;

ALTER TABLE cases
  ADD CONSTRAINT fk_cases_rejected_by 
  FOREIGN KEY (rejected_by) REFERENCES users(id) ON DELETE SET NULL;

ALTER TABLE cases
  ADD CONSTRAINT fk_cases_completed_by 
  FOREIGN KEY (completed_by) REFERENCES users(id) ON DELETE SET NULL;

ALTER TABLE cases
  ADD CONSTRAINT fk_cases_assigned_to 
  FOREIGN KEY (assigned_to) REFERENCES users(id) ON DELETE SET NULL;
```

### 3.4 Check Constraints

**Migration:** Add business rule constraints

```sql
-- Ensure approved/rejected cases have required fields
ALTER TABLE cases
  ADD CONSTRAINT cases_approved_check 
  CHECK (
    (status != 'تایید شده') OR 
    (approved_by IS NOT NULL AND approved_at IS NOT NULL)
  );

ALTER TABLE cases
  ADD CONSTRAINT cases_rejected_check 
  CHECK (
    (status != 'رد شده') OR 
    (rejected_by IS NOT NULL AND rejected_at IS NOT NULL AND rejection_reason IS NOT NULL)
  );

ALTER TABLE cases
  ADD CONSTRAINT cases_completed_check 
  CHECK (
    (status != 'تکمیل شده' AND status != 'منتظر تایید' AND status != 'تایید شده' AND status != 'رد شده') OR 
    (completed_by IS NOT NULL AND completed_at IS NOT NULL)
  );
```

## 4. State Machine Service

### 4.1 State Machine Service

**Location:** `server/services/caseStateMachine.ts` (NEW FILE)

```typescript
import type { Case, User } from '@shared/schema';
import { CaseStatus } from '@shared/schema';

export type TransitionName = 
  | 'assign'
  | 'start'
  | 'complete'
  | 'submit_for_approval'
  | 'approve'
  | 'reject'
  | 'reopen'
  | 'reassign';

export interface TransitionRule {
  from: CaseStatus;
  to: CaseStatus;
  name: TransitionName;
  requiredPermission?: string;
  requiredFields?: string[];
  validationFn?: (caseItem: Case, user: User, metadata?: any) => Promise<ValidationResult>;
}

export interface ValidationResult {
  isValid: boolean;
  errorMessage?: string;
  missingFields?: string[];
}

export interface TransitionResult {
  success: boolean;
  newStatus: CaseStatus;
  errorMessage?: string;
  transitionId?: string;
}

/**
 * State machine transition rules
 */
const TRANSITION_RULES: TransitionRule[] = [
  {
    from: CaseStatus.NEW,
    to: CaseStatus.ASSIGNED,
    name: 'assign',
    requiredPermission: 'cases:assign_to_auditor', // OR cases:assign_to_group
    validationFn: async (caseItem, user, metadata) => {
      // Must have userId or groupId in metadata
      if (!metadata?.userId && !metadata?.groupId) {
        return {
          isValid: false,
          errorMessage: 'باید کاربر یا گروه مشخص شود',
        };
      }
      return { isValid: true };
    },
  },
  {
    from: CaseStatus.ASSIGNED,
    to: CaseStatus.IN_PROGRESS,
    name: 'start',
    requiredPermission: 'cases:view',
    validationFn: async (caseItem) => {
      // Must be assigned
      if (!caseItem.assignedTo && !caseItem.receivingGroup) {
        return {
          isValid: false,
          errorMessage: 'قضیه باید اختصاص داده شده باشد',
        };
      }
      return { isValid: true };
    },
  },
  {
    from: CaseStatus.IN_PROGRESS,
    to: CaseStatus.COMPLETED,
    name: 'complete',
    requiredPermission: 'cases:complete',
    validationFn: async (caseItem, user) => {
      // Validate report completion
      const { validateCaseReportCompletion, canOverrideValidation } = await import('./reportValidationService');
      const allowOverride = await canOverrideValidation(user);
      const validation = await validateCaseReportCompletion(caseItem, allowOverride);
      
      if (!validation.isValid) {
        return {
          isValid: false,
          errorMessage: validation.errorMessage,
          missingFields: validation.missingFields,
        };
      }
      return { isValid: true };
    },
  },
  {
    from: CaseStatus.COMPLETED,
    to: CaseStatus.PENDING_APPROVAL,
    name: 'submit_for_approval',
    requiredPermission: 'cases:complete',
    validationFn: async (caseItem) => {
      // Must have completedBy
      if (!caseItem.completedBy || !caseItem.completedAt) {
        return {
          isValid: false,
          errorMessage: 'قضیه باید تکمیل شده باشد',
        };
      }
      return { isValid: true };
    },
  },
  {
    from: CaseStatus.COMPLETED,
    to: CaseStatus.APPROVED,
    name: 'approve',
    requiredPermission: 'tickets:approve',
    validationFn: async (caseItem) => {
      // Must be completed
      if (caseItem.status !== CaseStatus.COMPLETED && caseItem.status !== CaseStatus.PENDING_APPROVAL) {
        return {
          isValid: false,
          errorMessage: 'فقط قضایای تکمیل شده می‌توانند تایید شوند',
        };
      }
      return { isValid: true };
    },
  },
  {
    from: CaseStatus.PENDING_APPROVAL,
    to: CaseStatus.APPROVED,
    name: 'approve',
    requiredPermission: 'tickets:approve',
    validationFn: async () => ({ isValid: true }),
  },
  {
    from: CaseStatus.COMPLETED,
    to: CaseStatus.REJECTED,
    name: 'reject',
    requiredPermission: 'tickets:approve',
    validationFn: async (caseItem, user, metadata) => {
      // Must have rejectionReason
      if (!metadata?.rejectionReason || metadata.rejectionReason.trim() === '') {
        return {
          isValid: false,
          errorMessage: 'دلیل رد الزامی است',
        };
      }
      return { isValid: true };
    },
  },
  {
    from: CaseStatus.PENDING_APPROVAL,
    to: CaseStatus.REJECTED,
    name: 'reject',
    requiredPermission: 'tickets:approve',
    validationFn: async (caseItem, user, metadata) => {
      // Must have rejectionReason
      if (!metadata?.rejectionReason || metadata.rejectionReason.trim() === '') {
        return {
          isValid: false,
          errorMessage: 'دلیل رد الزامی است',
        };
      }
      return { isValid: true };
    },
  },
  {
    from: CaseStatus.REJECTED,
    to: CaseStatus.IN_PROGRESS,
    name: 'reopen',
    requiredPermission: 'tickets:approve', // OR cases:complete
    validationFn: async () => ({ isValid: true }),
  },
  {
    from: CaseStatus.IN_PROGRESS,
    to: CaseStatus.ASSIGNED,
    name: 'reassign',
    requiredPermission: 'cases:assign_to_auditor', // OR cases:assign_to_group
    validationFn: async (caseItem, user, metadata) => {
      // Must have userId or groupId in metadata
      if (!metadata?.userId && !metadata?.groupId) {
        return {
          isValid: false,
          errorMessage: 'باید کاربر یا گروه مشخص شود',
        };
      }
      return { isValid: true };
    },
  },
];

/**
 * Get allowed transitions for a case in its current state
 */
export function getAllowedTransitions(
  caseItem: Case,
  user: User
): TransitionRule[] {
  return TRANSITION_RULES.filter(rule => {
    // Check if transition is from current state
    if (rule.from !== caseItem.status) {
      return false;
    }
    
    // Check if user has required permission (if specified)
    // This will be checked more thoroughly in validateTransition
    return true;
  });
}

/**
 * Validate if a transition is allowed
 */
export async function validateTransition(
  caseItem: Case,
  user: User,
  toStatus: CaseStatus,
  transitionName: TransitionName,
  metadata?: any
): Promise<ValidationResult> {
  // Find transition rule
  const rule = TRANSITION_RULES.find(
    r => r.from === caseItem.status && r.to === toStatus && r.name === transitionName
  );
  
  if (!rule) {
    return {
      isValid: false,
      errorMessage: `انتقال از ${caseItem.status} به ${toStatus} مجاز نیست`,
    };
  }
  
  // Check permission (if required)
  if (rule.requiredPermission) {
    const { getEffectivePermissions } = await import('./permissionService');
    const permissions = await getEffectivePermissions(user.id);
    
    // Special handling for assign permission (can be either)
    if (rule.requiredPermission === 'cases:assign_to_auditor') {
      const hasAssignPermission = 
        permissions['cases:assign_to_auditor'] || 
        permissions['cases:assign_to_group'] ||
        user.role === 'system_admin';
      
      if (!hasAssignPermission) {
        return {
          isValid: false,
          errorMessage: 'شما مجوز اختصاص قضیه را ندارید',
        };
      }
    } else {
      // Check specific permission
      if (!permissions[rule.requiredPermission as any] && user.role !== 'system_admin') {
        return {
          isValid: false,
          errorMessage: 'شما مجوز لازم را ندارید',
        };
      }
    }
  }
  
  // Run custom validation function
  if (rule.validationFn) {
    return await rule.validationFn(caseItem, user, metadata);
  }
  
  return { isValid: true };
}

/**
 * Execute a transition (with validation and audit logging)
 */
export async function executeTransition(
  caseId: string,
  user: User,
  transitionName: TransitionName,
  metadata?: any
): Promise<TransitionResult> {
  const { storage } = await import('../storage');
  const { db } = await import('../db');
  const { cases: casesTable, caseStatusTransitions } = await import('@shared/schema');
  const { eq } = await import('drizzle-orm');
  
  // Get current case
  const caseItem = await storage.getCase(caseId);
  if (!caseItem) {
    return {
      success: false,
      newStatus: caseItem?.status as CaseStatus,
      errorMessage: 'قضیه یافت نشد',
    };
  }
  
  // Find transition rule
  const rule = TRANSITION_RULES.find(r => r.name === transitionName);
  if (!rule) {
    return {
      success: false,
      newStatus: caseItem.status as CaseStatus,
      errorMessage: 'انتقال نامعتبر است',
    };
  }
  
  // Validate transition
  const validation = await validateTransition(caseItem, user, rule.to, transitionName, metadata);
  if (!validation.isValid) {
    return {
      success: false,
      newStatus: caseItem.status as CaseStatus,
      errorMessage: validation.errorMessage,
    };
  }
  
  // Execute transition in transaction
  let transitionId: string | undefined;
  
  await db.transaction(async (tx) => {
    // Update case status
    const updateData: any = { status: rule.to };
    
    // Set status-specific fields
    if (rule.to === CaseStatus.COMPLETED) {
      updateData.completedBy = user.id;
      updateData.completedAt = new Date();
    } else if (rule.to === CaseStatus.APPROVED) {
      updateData.approvedBy = user.id;
      updateData.approvedAt = new Date();
    } else if (rule.to === CaseStatus.REJECTED) {
      updateData.rejectedBy = user.id;
      updateData.rejectedAt = new Date();
      updateData.rejectionReason = metadata?.rejectionReason;
    } else if (rule.to === CaseStatus.ASSIGNED) {
      // Handle assignment
      if (metadata?.userId) {
        updateData.assignedTo = metadata.userId;
        updateData.receivingGroup = null;
      } else if (metadata?.groupId) {
        updateData.receivingGroup = metadata.groupId;
        updateData.assignedTo = null;
      }
    }
    
    // Update case
    const [updatedCase] = await tx
      .update(casesTable)
      .set(updateData)
      .where(eq(casesTable.id, caseId))
      .returning();
    
    // Create transition record
    const [transition] = await tx
      .insert(caseStatusTransitions)
      .values({
        caseId: caseId,
        fromStatus: caseItem.status,
        toStatus: rule.to,
        transitionName: transitionName,
        transitionedBy: user.id,
        notes: metadata?.notes,
        rejectionReason: metadata?.rejectionReason,
        metadata: {
          ipAddress: metadata?.ipAddress,
          userAgent: metadata?.userAgent,
          userRole: user.role,
        },
      })
      .returning();
    
    transitionId = transition.id;
    
    // Create audit log
    await storage.createAuditLog({
      userId: user.id,
      action: `case_transition_${transitionName}`,
      entityType: 'case',
      entityId: caseId,
      details: {
        fromStatus: caseItem.status,
        toStatus: rule.to,
        transitionName: transitionName,
        transitionId: transition.id,
        metadata: metadata,
      },
      ipAddress: metadata?.ipAddress,
    });
  });
  
  return {
    success: true,
    newStatus: rule.to,
    transitionId,
  };
}
```

## 5. API Contracts

### 5.1 Unified Status Transition Endpoint

**Location:** `server/routes/cases.ts` (NEW)

**Endpoint:** `POST /api/cases/:id/transition`

**Purpose:** Single unified endpoint for all status transitions

**Request:**
```typescript
{
  transition: 'assign' | 'start' | 'complete' | 'submit_for_approval' | 'approve' | 'reject' | 'reopen' | 'reassign',
  metadata?: {
    userId?: string,        // For assign/reassign
    groupId?: string,       // For assign/reassign
    rejectionReason?: string, // For reject
    notes?: string,         // Optional notes
  }
}
```

**Response (Success):**
```json
{
  "success": true,
  "case": {
    "id": "case-123",
    "status": "تکمیل شده",
    ...
  },
  "transition": {
    "id": "transition-456",
    "fromStatus": "در جریان بررسی",
    "toStatus": "تکمیل شده",
    "transitionName": "complete",
    "transitionedBy": "user-789",
    "transitionedAt": "2024-01-15T12:00:00Z"
  }
}
```

**Response (Error):**
```json
{
  "success": false,
  "error": {
    "code": "INVALID_TRANSITION",
    "message": "انتقال از در جریان بررسی به تایید شده مجاز نیست",
    "allowedTransitions": ["complete", "reassign"]
  }
}
```

**Implementation:**
```typescript
router.post("/:id/transition", requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user as User;
    const { transition, metadata } = req.body;
    const caseId = req.params.id;
    
    // Get case and check RBAC
    const caseItem = await storage.getCase(caseId);
    if (!caseItem) {
      return res.status(404).json({ message: 'قضیه یافت نشد' });
    }
    
    // Check RBAC access to this case
    const { getCaseVisibility } = await import('../utils/permissionHelpers');
    const visibility = await getCaseVisibility(user);
    
    // ... RBAC checks ...
    
    // Execute transition
    const { executeTransition } = await import('../services/caseStateMachine');
    const result = await executeTransition(caseId, user, transition, {
      ...metadata,
      ipAddress: extractClientIp(req),
    });
    
    if (!result.success) {
      // Get allowed transitions for error message
      const { getAllowedTransitions } = await import('../services/caseStateMachine');
      const allowed = getAllowedTransitions(caseItem, user);
      
      return res.status(400).json({
        success: false,
        error: {
          code: 'INVALID_TRANSITION',
          message: result.errorMessage,
          allowedTransitions: allowed.map(t => t.name),
        },
      });
    }
    
    // Get updated case
    const updatedCase = await storage.getCase(caseId);
    
    // Get transition record
    const transitionRecord = await storage.getCaseStatusTransition(result.transitionId!);
    
    res.json({
      success: true,
      case: updatedCase,
      transition: transitionRecord,
    });
  } catch (error) {
    console.error('Error executing transition:', error);
    res.status(500).json({ message: 'خطا در اجرای انتقال وضعیت' });
  }
});
```

### 5.2 Get Allowed Transitions Endpoint

**Endpoint:** `GET /api/cases/:id/transitions`

**Purpose:** Get list of allowed transitions for current case state

**Response:**
```json
{
  "currentStatus": "در جریان بررسی",
  "allowedTransitions": [
    {
      "name": "complete",
      "toStatus": "تکمیل شده",
      "label": "تکمیل قضیه",
      "description": "قضیه را تکمیل کنید",
      "requiredPermission": "cases:complete",
      "requiresConfirmation": true,
      "validation": {
        "requiresReport": true,
        "requiresAssignment": false,
      }
    },
    {
      "name": "reassign",
      "toStatus": "اختصاص داده شده",
      "label": "واگذاری مجدد",
      "description": "قضیه را به کاربر یا گروه دیگری اختصاص دهید",
      "requiredPermission": "cases:assign_to_auditor",
      "requiresConfirmation": true,
    }
  ]
}
```

### 5.3 Get Transition History Endpoint

**Endpoint:** `GET /api/cases/:id/transitions/history`

**Purpose:** Get complete history of status transitions

**Response:**
```json
{
  "caseId": "case-123",
  "transitions": [
    {
      "id": "transition-1",
      "fromStatus": "جدید",
      "toStatus": "اختصاص داده شده",
      "transitionName": "assign",
      "transitionedBy": {
        "id": "user-1",
        "fullName": "احمد احمدی",
        "role": "senior_auditor"
      },
      "transitionedAt": "2024-01-15T10:00:00Z",
      "notes": null,
      "metadata": {
        "userId": "user-2",
        "ipAddress": "192.168.1.1"
      }
    },
    {
      "id": "transition-2",
      "fromStatus": "اختصاص داده شده",
      "toStatus": "در جریان بررسی",
      "transitionName": "start",
      "transitionedBy": {
        "id": "user-2",
        "fullName": "محمد محمدی",
        "role": "auditor"
      },
      "transitionedAt": "2024-01-15T11:00:00Z",
      "notes": "شروع بررسی",
      "metadata": {}
    }
  ]
}
```

### 5.4 Deprecate Old Endpoints

**Endpoints to Deprecate:**
- `PATCH /api/cases/:id/status` - Replace with `POST /api/cases/:id/transition`
- `POST /api/cases/:id/complete` - Replace with `POST /api/cases/:id/transition` with `transition: 'complete'`
- `POST /api/cases/:id/approve` - Replace with `POST /api/cases/:id/transition` with `transition: 'approve'`
- `POST /api/cases/:id/reject` - Replace with `POST /api/cases/:id/transition` with `transition: 'reject'`

**Migration Strategy:**
- Keep old endpoints for backward compatibility
- Add deprecation warnings
- Redirect to new endpoint internally
- Remove in future version

## 6. UI/UX Design

### 6.1 Status Transition UI Component

**Location:** `client/src/components/CaseStatusTransition.tsx` (NEW)

**Features:**
- Visual state machine diagram
- Available transitions as buttons
- Disabled states with tooltips
- Confirmation dialogs
- RTL layout support

**Component Structure:**
```typescript
interface CaseStatusTransitionProps {
  caseItem: Case;
  onTransition: (transitionName: string, metadata?: any) => Promise<void>;
  allowedTransitions: TransitionInfo[];
}

export function CaseStatusTransition({ caseItem, onTransition, allowedTransitions }: CaseStatusTransitionProps) {
  // Show current status
  // Show available transitions as buttons
  // Show disabled transitions with tooltips
  // Handle confirmation dialogs
  // RTL-aware layout
}
```

### 6.2 Confirmation Dialog Component

**Location:** `client/src/components/CaseTransitionDialog.tsx` (NEW)

**Features:**
- RTL-aware dialog
- Shows transition details
- Shows validation warnings
- Requires confirmation
- Shows impact of transition

**Dialog Content:**
- Current status → New status
- Transition name and description
- Required fields (if any)
- Validation warnings (if any)
- Confirmation checkbox
- Cancel/Confirm buttons

### 6.3 Status History Timeline

**Location:** `client/src/components/CaseStatusHistory.tsx` (NEW)

**Features:**
- Visual timeline of status changes
- Shows who made each change
- Shows when each change occurred
- Shows notes/reasons
- RTL-aware timeline

### 6.4 Status Badge Enhancement

**Location:** `client/src/components/StatusBadge.tsx` (UPDATE)

**Enhancements:**
- Add tooltip showing status description
- Add indicator for available transitions
- Add animation for status changes
- RTL-aware badge positioning

### 6.5 Case Detail Page Updates

**Location:** `client/src/pages/Cases.tsx` (UPDATE)

**Updates:**
- Add status transition panel
- Add status history timeline
- Add inline validation feedback
- Add confirmation dialogs for all transitions
- Update button states based on allowed transitions

## 7. RTL Layout Considerations

### 7.1 State Machine Diagram

- Use RTL-aware flow direction (right to left)
- Status badges aligned for RTL
- Transition arrows point right-to-left
- Timeline flows right-to-left

### 7.2 Confirmation Dialogs

- Dialog content RTL-aligned
- Buttons positioned for RTL (Cancel on right, Confirm on left)
- Form fields RTL-aligned
- Text direction RTL

### 7.3 Status History Timeline

- Timeline flows right-to-left
- Dates formatted for RTL
- User names RTL-aligned
- Icons positioned for RTL

## 8. Audit Trail Schema

### 8.1 Transition Record Schema

**Table:** `case_status_transitions`

**Fields:**
- `id` - Unique identifier
- `case_id` - Reference to case
- `from_status` - Previous status
- `to_status` - New status
- `transition_name` - Name of transition ('assign', 'complete', etc.)
- `transitioned_by` - User who made transition
- `transitioned_at` - Timestamp of transition
- `notes` - Optional notes
- `rejection_reason` - If transition is 'reject'
- `metadata` - JSONB with additional context (IP, user agent, etc.)

### 8.2 Audit Log Integration

**Existing:** `audit_logs` table

**New Actions:**
- `case_transition_assign`
- `case_transition_start`
- `case_transition_complete`
- `case_transition_submit_for_approval`
- `case_transition_approve`
- `case_transition_reject`
- `case_transition_reopen`
- `case_transition_reassign`

**Details Structure:**
```json
{
  "fromStatus": "در جریان بررسی",
  "toStatus": "تکمیل شده",
  "transitionName": "complete",
  "transitionId": "transition-123",
  "metadata": {
    "ipAddress": "192.168.1.1",
    "userAgent": "Mozilla/5.0...",
    "userRole": "auditor"
  }
}
```

## 9. Validation Rules Summary

### 9.1 Per-Transition Validation

| Transition | Validation Rules |
|------------|------------------|
| `assign` | Must provide userId OR groupId |
| `start` | Must be assigned (assignedTo OR receivingGroup) |
| `complete` | Report must be complete (all required fields) |
| `submit_for_approval` | Must be completed (completedBy set) |
| `approve` | Must be completed or pending approval |
| `reject` | Must provide rejectionReason, must be completed or pending approval |
| `reopen` | Must be rejected |
| `reassign` | Must provide userId OR groupId |

### 9.2 State-Specific Validation

| State | Required Fields | Cannot Do |
|-------|----------------|-----------|
| `جدید` | None | Complete, Approve, Reject |
| `اختصاص داده شده` | assignedTo OR receivingGroup | Complete, Approve, Reject |
| `در جریان بررسی` | assignedTo OR receivingGroup | Approve, Reject (without completion) |
| `تکمیل شده` | completedBy, completedAt, full report | Start, Assign (can reassign) |
| `منتظر تایید` | completedBy, completedAt, full report | Start, Assign, Complete |
| `تایید شده` | approvedBy, approvedAt | All transitions (terminal) |
| `رد شده` | rejectedBy, rejectedAt, rejectionReason | Approve (can reopen) |

## 10. Acceptance Criteria

### 10.1 State Machine

✅ **AC1:** State machine is explicitly defined with all allowed transitions
✅ **AC2:** No illegal transitions are possible (validated at API level)
✅ **AC3:** Database stores only valid status values (enum constraint)
✅ **AC4:** All transitions are logged in `case_status_transitions` table
✅ **AC5:** Transition history can be queried for any case

### 10.2 Validation

✅ **AC6:** Every transition is validated before execution
✅ **AC7:** Report validation is required before `complete` transition
✅ **AC8:** Assignment is required before `start` transition
✅ **AC9:** Rejection reason is required for `reject` transition
✅ **AC10:** Permission checks are enforced for all transitions

### 10.3 API Contracts

✅ **AC11:** `POST /api/cases/:id/transition` endpoint exists and works
✅ **AC12:** `GET /api/cases/:id/transitions` returns allowed transitions
✅ **AC13:** `GET /api/cases/:id/transitions/history` returns transition history
✅ **AC14:** All transitions return consistent response format
✅ **AC15:** Error responses include allowed transitions

### 10.4 Database Integrity

✅ **AC16:** Status enum constraint prevents invalid values
✅ **AC17:** Foreign key constraints on user references
✅ **AC18:** Check constraints ensure required fields for terminal states
✅ **AC19:** Indexes exist for status filtering
✅ **AC20:** Transition history table is properly indexed

### 10.5 UI/UX

✅ **AC21:** Status transition UI component exists
✅ **AC22:** Confirmation dialogs for all transitions
✅ **AC23:** Status history timeline component
✅ **AC24:** RTL layout is properly implemented
✅ **AC25:** Button states clearly indicate available actions
✅ **AC26:** Validation errors shown inline
✅ **AC27:** Transition preview before confirmation

### 10.6 Audit Trail

✅ **AC28:** Every transition creates audit log entry
✅ **AC29:** Every transition creates transition history record
✅ **AC30:** Audit logs include full context (IP, user agent, etc.)
✅ **AC31:** Transition history is queryable
✅ **AC32:** Cannot delete or modify transition history

### 10.7 Backward Compatibility

✅ **AC33:** Old endpoints still work (with deprecation warnings)
✅ **AC34:** Old status values are migrated to new enum
✅ **AC35:** Existing cases maintain their current status
✅ **AC36:** No data loss during migration

## 11. Migration Plan

### 11.1 Database Migrations

**Step 1:** Create enum type and constraints
**Step 2:** Create `case_status_transitions` table
**Step 3:** Add foreign key constraints
**Step 4:** Add check constraints
**Step 5:** Create indexes
**Step 6:** Migrate existing status values (if needed)

### 11.2 Code Migration

**Step 1:** Create state machine service
**Step 2:** Create new transition endpoint
**Step 3:** Update storage methods to use state machine
**Step 4:** Create transition history storage methods
**Step 5:** Update frontend components
**Step 6:** Add deprecation warnings to old endpoints

### 11.3 Testing Strategy

**Unit Tests:**
- State machine transition validation
- Permission checks
- Validation functions

**Integration Tests:**
- API endpoint tests
- Database constraint tests
- Transition history tests

**E2E Tests:**
- Complete workflow: New → Assigned → In Progress → Completed → Approved
- Rejection workflow: Completed → Rejected → Reopened → In Progress
- Permission-based access tests
- Validation error handling

## 12. Security Considerations

### 12.1 Permission Enforcement

- All transitions check permissions
- RBAC enforced at API level
- System admin can override (with audit log)
- Coordinator permissions respected

### 12.2 Input Validation

- All transition metadata validated
- SQL injection prevention
- XSS prevention in notes/rejection reasons
- Rate limiting on transition endpoint

### 12.3 Audit Trail Security

- Transition history cannot be modified
- Audit logs are append-only
- IP addresses logged for security
- User agent logged for fraud detection

## 13. Performance Considerations

### 13.1 Database Indexes

- Index on `cases.status` for filtering
- Index on `case_status_transitions.case_id` for history queries
- Index on `case_status_transitions.transitioned_at` for timeline queries
- Composite indexes for common queries

### 13.2 Caching

- Cache allowed transitions per case (invalidate on status change)
- Cache transition history (with TTL)
- Cache state machine rules (static)

### 13.3 Query Optimization

- Use transactions for atomic updates
- Batch transition history queries
- Optimize RBAC permission checks

## 14. Future Enhancements

### 14.1 Workflow Automation

- Auto-assign cases based on rules
- Auto-transition on conditions (e.g., auto-approve after X days)
- Escalation rules (e.g., notify if case stuck in status)

### 14.2 Advanced State Machine

- Conditional transitions (based on case properties)
- Parallel states (e.g., "In Review" + "Awaiting Documents")
- State machine versioning (for future changes)

### 14.3 Analytics

- Status transition analytics
- Time-in-status metrics
- Bottleneck identification
- Performance dashboards

