// React hook for permissions
// Fetches and caches effective permissions from API

import { useEffect, useState, useRef } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { getUserPermissions, clearPermissionCache, type EffectivePermissions, type Permission } from '@/utils/permissions';

export function usePermissions() {
  const { user } = useAuth();
  const [permissions, setPermissions] = useState<EffectivePermissions | null>(null);
  const [loading, setLoading] = useState(true);
  const lastPermissionsVersionRef = useRef<number | undefined>(undefined);

  useEffect(() => {
    if (!user) {
      setPermissions(null);
      setLoading(false);
      lastPermissionsVersionRef.current = undefined;
      return;
    }

    // Check if permissionsVersion changed - if so, clear cache and force refresh
    const currentVersion = user.permissionsVersion || 1;
    const versionChanged = lastPermissionsVersionRef.current !== undefined && lastPermissionsVersionRef.current !== currentVersion;
    
    if (versionChanged) {
      console.log('Permissions version changed, clearing cache and refreshing...', {
        old: lastPermissionsVersionRef.current,
        new: currentVersion
      });
      clearPermissionCache();
    }
    lastPermissionsVersionRef.current = currentVersion;

    setLoading(true);
    // Force refresh if version changed or if this is the first load
    const forceRefresh = versionChanged || lastPermissionsVersionRef.current === undefined;
    getUserPermissions(user, forceRefresh)
      .then(perms => {
        setPermissions(perms);
        setLoading(false);
      })
      .catch(error => {
        console.error('Error loading permissions:', error);
        setPermissions(null);
        setLoading(false);
      });
  }, [
    user?.id, 
    user?.permissionsVersion, 
    user?.role, 
    JSON.stringify(user?.permissionPackages || []), // Stringify to detect array content changes
    JSON.stringify(user?.effectivePermissions || []), // Also watch effectivePermissions from server
  ]);

  const hasPermission = (permission: Permission): boolean => {
    if (!permissions) return false;
    return permissions[permission] === true;
  };

  return {
    permissions,
    loading,
    hasPermission,
  };
}

