import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useParams, useLocation } from 'wouter';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Calendar, User, Users, FileText, CheckCircle, Edit, ArrowRight } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { useState } from 'react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';

interface AuditRecord {
  id: string;
  entityId: string;
  yearFrom: number;
  yearTo: number;
  status: 'planned' | 'in_progress' | 'completed' | 'closed' | 'transferred';
  auditGroupId?: string;
  assignedAt?: string;
  createdByUserId?: string;
  notes?: string;
  responsibleEvaluator?: string;
  createdAt: string;
  updatedAt: string;
  completedAt?: string;
  entity?: {
    id: string;
    companyName: string;
    tin: string;
  };
  responsibleEvaluatorUser?: {
    id: string;
    fullName: string;
    auditId: string;
  };
  auditGroupInfo?: {
    id: string;
    name: string;
    code?: string;
  };
  createdByUser?: {
    id: string;
    fullName: string;
  };
  history?: Array<{
    id: string;
    version: number;
    changeType: string;
    changedBy: string;
    changedAt: string;
    changes: any;
    notes?: string;
    changedByUser?: {
      id: string;
      fullName: string;
      role: string;
    };
  }>;
}

export default function AuditRecordDetail() {
  const params = useParams();
  const [, setLocation] = useLocation();
  const auditRecordId = params.id;
  const { toast } = useToast();
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [editNotesDialogOpen, setEditNotesDialogOpen] = useState(false);
  const [notes, setNotes] = useState('');

  const { data: auditRecord, isLoading, error } = useQuery<AuditRecord>({
    queryKey: ['audit-record', auditRecordId],
    queryFn: async () => {
      const response = await fetch(`/api/audit-records/${auditRecordId}`, {
        credentials: 'include',
      });
      if (!response.ok) {
        throw new Error('Failed to fetch audit record');
      }
      return response.json();
    },
    enabled: !!auditRecordId,
  });

  const completeMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch(`/api/audit-records/${auditRecordId}/complete`, {
        method: 'POST',
        credentials: 'include',
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to complete audit record');
      }
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: 'موفقیت',
        description: 'سابقه بررسی با موفقیت تکمیل شد',
      });
      queryClient.invalidateQueries({ queryKey: ['audit-record', auditRecordId] });
      queryClient.invalidateQueries({ queryKey: ['audit-records'] });
    },
    onError: (error: any) => {
      toast({
        title: 'خطا',
        description: error.message || 'خطا در تکمیل سابقه بررسی',
        variant: 'destructive',
      });
    },
  });

  const updateNotesMutation = useMutation({
    mutationFn: async (newNotes: string) => {
      const response = await fetch(`/api/audit-records/${auditRecordId}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify({ notes: newNotes }),
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to update notes');
      }
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: 'موفقیت',
        description: 'یادداشت‌ها با موفقیت بروزرسانی شد',
      });
      queryClient.invalidateQueries({ queryKey: ['audit-record', auditRecordId] });
      setEditNotesDialogOpen(false);
    },
    onError: (error: any) => {
      toast({
        title: 'خطا',
        description: error.message || 'خطا در بروزرسانی یادداشت‌ها',
        variant: 'destructive',
      });
    },
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200';
      case 'in_progress':
        return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200';
      case 'planned':
        return 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-200';
      case 'closed':
        return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200';
      case 'transferred':
        return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200';
      default:
        return 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-200';
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'completed':
        return 'تکمیل شده';
      case 'in_progress':
        return 'در جریان';
      case 'planned':
        return 'برنامه‌ریزی شده';
      case 'closed':
        return 'بسته شده';
      case 'transferred':
        return 'منتقل شده';
      default:
        return status;
    }
  };

  const formatYearRange = (yearFrom: number, yearTo: number) => {
    if (yearFrom === yearTo) {
      return `سال ${yearFrom}`;
    }
    return `${yearFrom}-${yearTo}`;
  };

  const formatDate = (dateString?: string) => {
    if (!dateString) return '-';
    return new Date(dateString).toLocaleDateString('fa-IR', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  };

  if (isLoading) {
    return (
      <div className="container mx-auto p-6">
        <div className="text-center text-muted-foreground">در حال بارگذاری...</div>
      </div>
    );
  }

  if (error || !auditRecord) {
    return (
      <div className="container mx-auto p-6">
        <Card>
          <CardContent className="p-6">
            <div className="text-center text-destructive">
              خطا در بارگذاری سابقه بررسی
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  const isCompleted = auditRecord.status === 'completed';
  const canEdit = !isCompleted;
  const canComplete = !isCompleted && (user?.role === 'system_admin' || user?.role === 'coordinator');

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => {
              if (auditRecord.entityId) {
                setLocation(`/entities`);
              } else {
                setLocation('/audit-records');
              }
            }}
          >
            <ArrowRight className="ml-2 h-4 w-4" />
            بازگشت
          </Button>
          <h1 className="text-2xl font-bold">جزئیات سابقه بررسی</h1>
        </div>
        {canComplete && (
          <Button
            onClick={() => completeMutation.mutate()}
            disabled={completeMutation.isPending}
          >
            <CheckCircle className="ml-2 h-4 w-4" />
            {completeMutation.isPending ? 'در حال تکمیل...' : 'تکمیل سابقه'}
          </Button>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Information */}
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>اطلاعات اصلی</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-muted-foreground">نهاد</Label>
                  <p className="font-medium">
                    {auditRecord.entity?.companyName || '-'}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    TIN: {auditRecord.entity?.tin || '-'}
                  </p>
                </div>
                <div>
                  <Label className="text-muted-foreground">بازه سالی</Label>
                  <p className="font-medium">
                    {formatYearRange(auditRecord.yearFrom, auditRecord.yearTo)}
                  </p>
                </div>
                <div>
                  <Label className="text-muted-foreground">وضعیت</Label>
                  <div className="mt-1">
                    <Badge className={getStatusColor(auditRecord.status)}>
                      {getStatusLabel(auditRecord.status)}
                    </Badge>
                  </div>
                </div>
                {auditRecord.auditGroupInfo && (
                  <div>
                    <Label className="text-muted-foreground">گروه بررسی</Label>
                    <p className="font-medium">{auditRecord.auditGroupInfo.name}</p>
                  </div>
                )}
                {auditRecord.responsibleEvaluatorUser && (
                  <div>
                    <Label className="text-muted-foreground">بررس مسئول</Label>
                    <p className="font-medium">
                      {auditRecord.responsibleEvaluatorUser.fullName}
                    </p>
                    <p className="text-sm text-muted-foreground">
                      {auditRecord.responsibleEvaluatorUser.auditId}
                    </p>
                  </div>
                )}
                {auditRecord.assignedAt && (
                  <div>
                    <Label className="text-muted-foreground">تاریخ اختصاص</Label>
                    <p className="font-medium">{formatDate(auditRecord.assignedAt)}</p>
                  </div>
                )}
                {auditRecord.completedAt && (
                  <div>
                    <Label className="text-muted-foreground">تاریخ تکمیل</Label>
                    <p className="font-medium">{formatDate(auditRecord.completedAt)}</p>
                  </div>
                )}
                {auditRecord.createdByUser && (
                  <div>
                    <Label className="text-muted-foreground">ایجاد شده توسط</Label>
                    <p className="font-medium">{auditRecord.createdByUser.fullName}</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>یادداشت‌ها</CardTitle>
                {canEdit && (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      setNotes(auditRecord.notes || '');
                      setEditNotesDialogOpen(true);
                    }}
                  >
                    <Edit className="ml-2 h-4 w-4" />
                    ویرایش
                  </Button>
                )}
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-sm whitespace-pre-wrap">
                {auditRecord.notes || 'یادداشتی ثبت نشده است'}
              </p>
            </CardContent>
          </Card>

          {auditRecord.history && auditRecord.history.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle>تاریخچه تغییرات</CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>نسخه</TableHead>
                      <TableHead>نوع تغییر</TableHead>
                      <TableHead>تغییر داده شده توسط</TableHead>
                      <TableHead>تاریخ</TableHead>
                      <TableHead>یادداشت</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {auditRecord.history.map((entry) => (
                      <TableRow key={entry.id}>
                        <TableCell>{entry.version}</TableCell>
                        <TableCell>
                          {entry.changeType === 'create' && 'ایجاد'}
                          {entry.changeType === 'update' && 'بروزرسانی'}
                          {entry.changeType === 'status_change' && 'تغییر وضعیت'}
                          {entry.changeType === 'assignment_change' && 'تغییر اختصاص'}
                        </TableCell>
                        <TableCell>
                          {entry.changedByUser?.fullName || '-'}
                        </TableCell>
                        <TableCell>{formatDate(entry.changedAt)}</TableCell>
                        <TableCell>{entry.notes || '-'}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>عملیات</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {auditRecord.entityId && (
                <Button
                  variant="outline"
                  className="w-full"
                  onClick={() => setLocation(`/entities`)}
                >
                  <FileText className="ml-2 h-4 w-4" />
                  مشاهده نهاد
                </Button>
              )}
              {!isCompleted && (
                <Button
                  variant="outline"
                  className="w-full"
                  onClick={() => {
                    if (auditRecord.entityId) {
                      setLocation(`/entities`);
                    }
                  }}
                >
                  <Edit className="ml-2 h-4 w-4" />
                  ویرایش سابقه
                </Button>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>اطلاعات سیستم</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 text-sm">
              <div>
                <Label className="text-muted-foreground">ایجاد شده در</Label>
                <p>{formatDate(auditRecord.createdAt)}</p>
              </div>
              <div>
                <Label className="text-muted-foreground">آخرین بروزرسانی</Label>
                <p>{formatDate(auditRecord.updatedAt)}</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Edit Notes Dialog */}
      <Dialog open={editNotesDialogOpen} onOpenChange={setEditNotesDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>ویرایش یادداشت‌ها</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>یادداشت‌ها</Label>
              <Textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                rows={6}
                className="mt-1"
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setEditNotesDialogOpen(false)}
            >
              انصراف
            </Button>
            <Button
              onClick={() => updateNotesMutation.mutate(notes)}
              disabled={updateNotesMutation.isPending}
            >
              {updateNotesMutation.isPending ? 'در حال ذخیره...' : 'ذخیره'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

