import { useState, useMemo } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Search, CheckCircle, XCircle, Plus, Eye, Filter, X, Key, Copy } from 'lucide-react';
import StatusBadge from '@/components/StatusBadge';
import { Badge } from '@/components/ui/badge';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import type { Ticket } from '@shared/schema';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { userHasPermission, getUserPermissions } from '@/utils/permissions';
import ShamsiDatePickerDDMMYYYY from '@/components/ShamsiDatePickerDDMMYYYY';

export default function Tickets() {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [typeFilter, setTypeFilter] = useState<string>('all');
  const [dateFromFilter, setDateFromFilter] = useState('');
  const [dateToFilter, setDateToFilter] = useState('');
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [isDetailsDialogOpen, setIsDetailsDialogOpen] = useState(false);
  const [selectedTicket, setSelectedTicket] = useState<Ticket | null>(null);
  const [rejectReason, setRejectReason] = useState('');
  const [isRejectDialogOpen, setIsRejectDialogOpen] = useState(false);
  const [isResetPasswordDialogOpen, setIsResetPasswordDialogOpen] = useState(false);
  const [generatedPassword, setGeneratedPassword] = useState<string | null>(null);
  const [createForm, setCreateForm] = useState({
    type: '',
    description: '',
  });
  const { user: currentUser, loading: authLoading } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const canCreateTickets = currentUser !== null;
  const canApproveReject = currentUser && userHasPermission(
    currentUser,
    'tickets:approve'
  );
  const canResetPassword = currentUser && userHasPermission(
    currentUser,
    'users:manage'
  );

  const { data: tickets = [], isLoading } = useQuery<Ticket[]>({
    queryKey: ['tickets'],
    queryFn: async () => {
      const response = await fetch('/api/tickets', { credentials: 'include' });
      if (!response.ok) throw new Error('Failed to fetch tickets');
      return response.json();
    },
    enabled: !authLoading && !!currentUser && (canCreateTickets || canApproveReject),
  });


  const { data: ticketDetails } = useQuery<Ticket>({
    queryKey: ['ticket', selectedTicket?.id],
    queryFn: async () => {
      if (!selectedTicket?.id) throw new Error('No ticket selected');
      const response = await fetch(`/api/tickets/${selectedTicket.id}`, { credentials: 'include' });
      if (!response.ok) throw new Error('Failed to fetch ticket details');
      return response.json();
    },
    enabled: !!selectedTicket?.id && isDetailsDialogOpen,
  });

  const createTicketMutation = useMutation({
    mutationFn: async (data: { type: string; description?: string }) => {
      const response = await fetch('/api/tickets', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
        credentials: 'include',
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to create ticket');
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['tickets'] });
      setIsCreateDialogOpen(false);
      setCreateForm({ type: '', description: '' });
      toast({
        title: 'موفق',
        description: 'تکت با موفقیت ایجاد شد',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'خطا',
        description: error.message || 'ایجاد تکت با مشکل مواجه شد',
        variant: 'destructive',
      });
    },
  });

  const approveTicketMutation = useMutation({
    mutationFn: async (ticketId: string) => {
      const response = await fetch(`/api/tickets/${ticketId}/approve`, {
        method: 'POST',
        credentials: 'include',
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to approve ticket');
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['tickets'] });
      if (selectedTicket) {
        queryClient.invalidateQueries({ queryKey: ['ticket', selectedTicket.id] });
      }
      toast({ title: 'موفق', description: 'تکت با موفقیت تایید شد' });
    },
    onError: (error: Error) => {
      toast({ title: 'خطا', description: error.message || 'تایید تکت با مشکل مواجه شد', variant: 'destructive' });
    },
  });

  const rejectTicketMutation = useMutation({
    mutationFn: async ({ ticketId, reason }: { ticketId: string; reason?: string }) => {
      const response = await fetch(`/api/tickets/${ticketId}/reject`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ reason }),
        credentials: 'include',
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to reject ticket');
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['tickets'] });
      if (selectedTicket) {
        queryClient.invalidateQueries({ queryKey: ['ticket', selectedTicket.id] });
      }
      setIsRejectDialogOpen(false);
      setRejectReason('');
      toast({ title: 'موفق', description: 'تکت با موفقیت رد شد' });
    },
    onError: (error: Error) => {
      toast({ title: 'خطا', description: error.message || 'رد تکت با مشکل مواجه شد', variant: 'destructive' });
    },
  });

  const resetPasswordMutation = useMutation({
    mutationFn: async (ticketId: string) => {
      const response = await fetch(`/api/tickets/${ticketId}/reset-password`, {
        method: 'POST',
        credentials: 'include',
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to reset password');
      }
      return response.json();
    },
    onSuccess: (data) => {
      setGeneratedPassword(data.password);
      setIsResetPasswordDialogOpen(true);
      queryClient.invalidateQueries({ queryKey: ['tickets'] });
      if (selectedTicket) {
        queryClient.invalidateQueries({ queryKey: ['ticket', selectedTicket.id] });
      }
      toast({ title: 'موفق', description: 'رمز عبور با موفقیت بازنشانی شد' });
    },
    onError: (error: Error) => {
      toast({ title: 'خطا', description: error.message || 'بازنشانی رمز عبور با مشکل مواجه شد', variant: 'destructive' });
    },
  });

  const handleCreateTicket = (e: React.FormEvent) => {
    e.preventDefault();
    if (!createForm.type) {
      toast({
        title: 'خطا',
        description: 'لطفا نوع تکت را انتخاب کنید',
        variant: 'destructive',
      });
      return;
    }
    createTicketMutation.mutate({
      type: createForm.type,
      description: createForm.description,
    });
  };

  const handleViewDetails = (ticket: Ticket) => {
    setSelectedTicket(ticket);
    setIsDetailsDialogOpen(true);
  };

  const handleApprove = (ticket: Ticket) => {
    approveTicketMutation.mutate(ticket.id);
  };

  const handleReject = (ticket: Ticket) => {
    setSelectedTicket(ticket);
    setIsRejectDialogOpen(true);
  };

  const handleResetPassword = (ticket: Ticket) => {
    setSelectedTicket(ticket);
    resetPasswordMutation.mutate(ticket.id);
  };

  const copyPassword = async () => {
    if (generatedPassword) {
      try {
        await navigator.clipboard.writeText(generatedPassword);
        toast({ title: 'موفق', description: 'رمز عبور در کلیپ‌بورد کپی شد' });
      } catch (error) {
        toast({ title: 'خطا', description: 'کپی کردن رمز عبور با مشکل مواجه شد', variant: 'destructive' });
      }
    }
  };

  const confirmReject = () => {
    if (selectedTicket) {
      rejectTicketMutation.mutate({ ticketId: selectedTicket.id, reason: rejectReason });
    }
  };

  // Filter and search tickets
  const filteredTickets = useMemo(() => {
    let filtered = tickets;

    // Status filter
    if (statusFilter !== 'all') {
      filtered = filtered.filter(t => t.status === statusFilter);
    }

    // Type filter
    if (typeFilter !== 'all') {
      filtered = filtered.filter(t => t.type === typeFilter);
    }

    // Date range filter
    if (dateFromFilter) {
      const fromDate = new Date(dateFromFilter);
      filtered = filtered.filter(t => {
        const ticketDate = new Date(t.createdAt);
        return ticketDate >= fromDate;
      });
    }
    if (dateToFilter) {
      const toDate = new Date(dateToFilter);
      toDate.setHours(23, 59, 59, 999);
      filtered = filtered.filter(t => {
        const ticketDate = new Date(t.createdAt);
        return ticketDate <= toDate;
      });
    }

    // Search query
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(t => 
        t.ticketId.toLowerCase().includes(query) ||
        t.description?.toLowerCase().includes(query)
      );
    }

    return filtered;
  }, [tickets, statusFilter, typeFilter, dateFromFilter, dateToFilter, searchQuery]);

  // Get unique ticket types
  const ticketTypes = useMemo(() => {
    const types = new Set(tickets.map(t => t.type));
    return Array.from(types);
  }, [tickets]);

  const clearFilters = () => {
    setStatusFilter('all');
    setTypeFilter('all');
    setDateFromFilter('');
    setDateToFilter('');
    setSearchQuery('');
  };

  const hasActiveFilters = statusFilter !== 'all' || typeFilter !== 'all' || dateFromFilter || dateToFilter || searchQuery;

  return (
    <div className="p-8 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-semibold">مدیریت تکت‌ها</h1>
          <p className="text-muted-foreground">پیگیری و مدیریت تکت‌های سیستم</p>
        </div>
        {canCreateTickets && (
          <Button onClick={() => setIsCreateDialogOpen(true)} data-testid="button-create-ticket">
            <Plus className="ml-2 h-4 w-4" />
            ایجاد تکت جدید
          </Button>
        )}
      </div>

      <Card>
        <CardHeader>
          <div className="space-y-4">
            <div className="flex items-center gap-4">
              <div className="relative flex-1">
                <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="جستجو بر اساس شماره تکت، توضیحات یا نمبر قضیه..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pr-10 text-right"
                  data-testid="input-search-tickets"
                />
              </div>
            </div>
            <div className="flex items-center gap-4 flex-wrap">
              <div className="flex items-center gap-2">
                <Filter className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm font-medium">فیلترها:</span>
              </div>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="وضعیت" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">همه وضعیت‌ها</SelectItem>
                  <SelectItem value="منتظر تایید">منتظر تایید</SelectItem>
                  <SelectItem value="تایید شده">تایید شده</SelectItem>
                  <SelectItem value="رد شده">رد شده</SelectItem>
                </SelectContent>
              </Select>
              <Select value={typeFilter} onValueChange={setTypeFilter}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="نوع" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">همه انواع</SelectItem>
                  {ticketTypes.map(type => (
                    <SelectItem key={type} value={type}>{type}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <div className="flex items-center gap-2">
                <Label className="text-sm whitespace-nowrap">از تاریخ:</Label>
                <ShamsiDatePickerDDMMYYYY
                  value={dateFromFilter}
                  onChange={setDateFromFilter}
                />
              </div>
              <div className="flex items-center gap-2">
                <Label className="text-sm whitespace-nowrap">تا تاریخ:</Label>
                <ShamsiDatePickerDDMMYYYY
                  value={dateToFilter}
                  onChange={setDateToFilter}
                />
              </div>
              {hasActiveFilters && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={clearFilters}
                  className="gap-2"
                >
                  <X className="h-4 w-4" />
                  پاک کردن فیلترها
                </Button>
              )}
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="text-center py-8 text-muted-foreground">در حال بارگذاری...</div>
          ) : filteredTickets.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              {tickets.length === 0 ? 'هیچ تکتی وجود ندارد' : 'نتیجه‌ای یافت نشد'}
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="text-right">شماره تکت</TableHead>
                  <TableHead className="text-right">نوع</TableHead>
                  <TableHead className="text-right">وضعیت</TableHead>
                  <TableHead className="text-right">تاریخ</TableHead>
                  <TableHead className="text-right">عملیات</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredTickets.map((ticket) => (
                  <TableRow key={ticket.id} className="hover-elevate">
                    <TableCell className="font-medium">{ticket.ticketId}</TableCell>
                    <TableCell>
                      <Badge variant="outline">{ticket.type}</Badge>
                    </TableCell>
                    <TableCell><StatusBadge status={ticket.status} /></TableCell>
                    <TableCell>{new Date(ticket.createdAt).toLocaleDateString('fa-AF')}</TableCell>
                    <TableCell>
                      <div className="flex gap-2">
                        <Button
                          size="icon"
                          variant="ghost"
                          onClick={() => handleViewDetails(ticket)}
                          data-testid={`button-view-ticket-${ticket.id}`}
                        >
                          <Eye className="h-4 w-4" />
                        </Button>
                        {canApproveReject && ticket.status === 'منتظر تایید' && (
                          <>
                            <Button
                              size="icon"
                              variant="ghost"
                              onClick={() => handleApprove(ticket)}
                              disabled={approveTicketMutation.isPending}
                              data-testid={`button-approve-${ticket.id}`}
                            >
                              <CheckCircle className="h-4 w-4 text-green-600" />
                            </Button>
                            <Button
                              size="icon"
                              variant="ghost"
                              onClick={() => handleReject(ticket)}
                              disabled={rejectTicketMutation.isPending}
                              data-testid={`button-reject-${ticket.id}`}
                            >
                              <XCircle className="h-4 w-4 text-destructive" />
                            </Button>
                          </>
                        )}
                        {canResetPassword && 
                         (ticket.type === 'password_recovery' || ticket.type === 'lost_password' || ticket.type === 'بازیابی رمز') && 
                         ticket.status === 'منتظر تایید' && (
                          <Button
                            size="icon"
                            variant="ghost"
                            onClick={() => handleResetPassword(ticket)}
                            disabled={resetPasswordMutation.isPending}
                            data-testid={`button-reset-password-${ticket.id}`}
                            title="بازنشانی رمز عبور"
                          >
                            <Key className="h-4 w-4 text-blue-600" />
                          </Button>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* Create Ticket Dialog */}
      <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>ایجاد تکت جدید</DialogTitle>
            <DialogDescription>
              اطلاعات تکت جدید را وارد کنید
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleCreateTicket}>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="create-ticket-type">نوع تکت *</Label>
                <Select
                  value={createForm.type}
                  onValueChange={(value) => setCreateForm({ ...createForm, type: value })}
                >
                  <SelectTrigger id="create-ticket-type">
                    <SelectValue placeholder="انتخاب نوع تکت" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="password_recovery">بازیابی رمز عبور</SelectItem>
                    <SelectItem value="approval_request">درخواست تایید</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="create-ticket-description">توضیحات</Label>
                <Textarea
                  id="create-ticket-description"
                  value={createForm.description}
                  onChange={(e) => setCreateForm({ ...createForm, description: e.target.value })}
                  placeholder="توضیحات اختیاری در مورد تکت"
                  rows={4}
                  className="text-right"
                />
              </div>
            </div>
            <DialogFooter className="mt-6">
              <Button
                type="button"
                variant="outline"
                onClick={() => {
                  setIsCreateDialogOpen(false);
                  setCreateForm({ type: '', description: '' });
                }}
              >
                لغو
              </Button>
              <Button type="submit" disabled={createTicketMutation.isPending}>
                {createTicketMutation.isPending ? 'در حال ایجاد...' : 'ایجاد تکت'}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Ticket Details Dialog */}
      <Dialog open={isDetailsDialogOpen} onOpenChange={setIsDetailsDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>جزئیات تکت: {ticketDetails?.ticketId || selectedTicket?.ticketId}</DialogTitle>
            <DialogDescription>
              مشاهده اطلاعات کامل تکت
            </DialogDescription>
          </DialogHeader>
          {ticketDetails && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>شماره تکت</Label>
                  <p className="text-sm font-medium">{ticketDetails.ticketId}</p>
                </div>
                <div>
                  <Label>نوع</Label>
                  <p className="text-sm">
                    <Badge variant="outline">{ticketDetails.type}</Badge>
                  </p>
                </div>
                <div>
                  <Label>وضعیت</Label>
                  <p className="text-sm">
                    <StatusBadge status={ticketDetails.status} />
                  </p>
                </div>
                <div>
                  <Label>تاریخ ایجاد</Label>
                  <p className="text-sm">{new Date(ticketDetails.createdAt).toLocaleDateString('fa-AF')}</p>
                </div>
              </div>
              {ticketDetails.description && (
                <div>
                  <Label>توضیحات</Label>
                  <p className="text-sm text-muted-foreground whitespace-pre-wrap">{ticketDetails.description}</p>
                </div>
              )}
              {canApproveReject && ticketDetails.status === 'منتظر تایید' && (
                <div className="flex gap-2 pt-4">
                  <Button
                    onClick={() => handleApprove(ticketDetails)}
                    disabled={approveTicketMutation.isPending}
                    className="flex-1"
                  >
                    <CheckCircle className="ml-2 h-4 w-4" />
                    تایید
                  </Button>
                  <Button
                    variant="destructive"
                    onClick={() => handleReject(ticketDetails)}
                    disabled={rejectTicketMutation.isPending}
                    className="flex-1"
                  >
                    <XCircle className="ml-2 h-4 w-4" />
                    رد
                  </Button>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Reject Ticket Dialog */}
      <Dialog open={isRejectDialogOpen} onOpenChange={setIsRejectDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>رد تکت</DialogTitle>
            <DialogDescription>
              لطفا دلیل رد تکت را وارد کنید
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            {selectedTicket && (
              <div className="bg-muted p-4 rounded-lg space-y-2">
                <p><strong>شماره تکت:</strong> {selectedTicket.ticketId}</p>
                <p><strong>نوع:</strong> {selectedTicket.type}</p>
              </div>
            )}
            <div className="space-y-2">
              <Label htmlFor="reject-reason">دلیل رد *</Label>
              <Textarea
                id="reject-reason"
                value={rejectReason}
                onChange={(e) => setRejectReason(e.target.value)}
                className="text-right"
                placeholder="لطفا دلیل رد تکت را وارد کنید..."
                rows={4}
                required
              />
            </div>
            <DialogFooter>
              <Button
                variant="outline"
                onClick={() => {
                  setIsRejectDialogOpen(false);
                  setRejectReason('');
                }}
              >
                لغو
              </Button>
              <Button
                variant="destructive"
                onClick={confirmReject}
                disabled={rejectTicketMutation.isPending || !rejectReason.trim()}
              >
                {rejectTicketMutation.isPending ? 'در حال رد...' : 'رد تکت'}
              </Button>
            </DialogFooter>
          </div>
        </DialogContent>
      </Dialog>

      {/* Reset Password Dialog */}
      <Dialog open={isResetPasswordDialogOpen} onOpenChange={setIsResetPasswordDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>رمز عبور بازنشانی شد</DialogTitle>
            <DialogDescription>
              رمز عبور جدید برای کاربر ایجاد شد. لطفا این رمز را به صورت امن به کاربر تحویل دهید.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            {generatedPassword && (
              <>
                <div className="space-y-2">
                  <Label>رمز عبور جدید</Label>
                  <div className="flex gap-2">
                    <Input
                      value={generatedPassword}
                      readOnly
                      className="font-mono text-lg"
                      data-testid="input-generated-password"
                    />
                    <Button
                      type="button"
                      variant="outline"
                      onClick={copyPassword}
                      data-testid="button-copy-password"
                    >
                      <Copy className="h-4 w-4 ml-2" />
                      کپی
                    </Button>
                  </div>
                </div>
                <div className="bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 rounded-lg p-4">
                  <p className="text-sm text-yellow-800 dark:text-yellow-200">
                    ⚠️ توجه: این رمز عبور فقط یک بار نمایش داده می‌شود. لطفا آن را در جای امن ذخیره کنید.
                  </p>
                </div>
              </>
            )}
            <DialogFooter>
              <Button
                onClick={() => {
                  setIsResetPasswordDialogOpen(false);
                  setGeneratedPassword(null);
                  setSelectedTicket(null);
                }}
                data-testid="button-close-reset-dialog"
              >
                بستن
              </Button>
            </DialogFooter>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
