import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Plus, Users, Edit, Trash2, Eye, UserPlus, X, CheckCircle2, Clock, Target, TrendingUp } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import type { Group, InsertGroup, User, GroupMember } from '@shared/schema';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';
import { userHasPermission, getUserPermissions } from '@/utils/permissions';
import ShamsiDatePicker from '@/components/ShamsiDatePicker';
import { useLocation } from 'wouter';
import RoleBadge from '@/components/RoleBadge';

// Helper function to translate role to Dari
const getRoleDari = (role: string): string => {
  const roleMap: Record<string, string> = {
    system_admin: 'مدیر سیستم',
    director: 'آمر بررسی',
    senior_auditor: 'مدیر عمومی گروه',
    auditor: 'بررس',
  };
  return roleMap[role] || role;
};

// Helper function to translate assigned role to Dari
const getAssignedRoleDari = (role: string): string => {
  const roleMap: Record<string, string> = {
    senior_auditor: 'مدیر عمومی گروه',
    auditor: 'بررس',
  };
  return roleMap[role] || role;
};

const createGroupSchema = z.object({
  name: z.string().min(1, 'نام گروه الزامی است'),
  description: z.string().optional(),
  code: z.string().min(1, 'کد گروه الزامی است'),
});

const editGroupSchema = createGroupSchema;

const addMemberSchema = z.object({
  userId: z.string().min(1, 'کاربر الزامی است'),
  assignedRole: z.string().min(1, 'نقش الزامی است'),
});


type CreateGroupForm = z.infer<typeof createGroupSchema>;
type EditGroupForm = z.infer<typeof editGroupSchema>;
type AddMemberForm = z.infer<typeof addMemberSchema>;

interface GroupMemberWithUser extends GroupMember {
  user: {
    id: string;
    auditId: string;
    fullName: string;
    role: string;
  } | null;
}

interface GroupStatistics {
  groupId: string;
  groupName: string;
  period: {
    monthShamsi: number;
    yearShamsi: number;
  };
  statistics: {
    totalAssignedCases: number;
    completedCases: number;
    pendingCases: number;
    membersCount: number;
  };
  targetAchieved: {
    target: number;
    achieved: number;
    percentComplete: number;
  } | null;
  memberActivity: Array<{
    userId: string;
    userName: string;
    auditId: string;
    role: string;
    assignedRole: string;
    casesHandled: number;
    casesCompleted: number;
    isActive: boolean;
  }>;
}

export default function Groups() {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [isDetailsDialogOpen, setIsDetailsDialogOpen] = useState(false);
  const [isAddMemberDialogOpen, setIsAddMemberDialogOpen] = useState(false);
  const [selectedGroup, setSelectedGroup] = useState<Group | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { user: currentUser, loading: authLoading } = useAuth();
  const [, setLocation] = useLocation();

  // Allow access if user has groups:manage OR groups:set_targets (for Directors)
  const hasGroupsPermission = currentUser && (
    userHasPermission(currentUser, 'groups:manage') || 
    userHasPermission(currentUser, 'groups:set_targets')
  );
  
  if (currentUser && !hasGroupsPermission) {
    return (
      <div className="p-8">
        <div className="text-center">
          <h2 className="text-2xl font-semibold mb-4">عدم دسترسی</h2>
          <p className="text-muted-foreground mb-4">شما مجوز دسترسی به این صفحه را ندارید.</p>
          <button
            onClick={() => setLocation('/')}
            className="text-blue-600 hover:underline"
          >
            بازگشت به داشبورد
          </button>
        </div>
      </div>
    );
  }

  const canManageGroups = currentUser && userHasPermission(
    currentUser,
    'groups:manage'
  );
  
  const canSetTargets = currentUser && userHasPermission(
    currentUser,
    'groups:set_targets'
  );

  const { data: groups = [], isLoading } = useQuery<Group[]>({
    queryKey: ['groups'],
    queryFn: async () => {
      const response = await fetch('/api/groups', { credentials: 'include' });
      if (!response.ok) throw new Error('Failed to fetch groups');
      return response.json();
    },
    enabled: !authLoading && !!currentUser && (canManageGroups || canSetTargets),
  });

  const { data: users = [] } = useQuery<User[]>({
    queryKey: ['users'],
    queryFn: async () => {
      const response = await fetch('/api/users', { credentials: 'include' });
      if (!response.ok) throw new Error('Failed to fetch users');
      return response.json();
    },
    enabled: canManageGroups || false,
  });

  const { data: groupMembers = [], refetch: refetchMembers } = useQuery<GroupMemberWithUser[]>({
    queryKey: ['groupMembers', selectedGroup?.id],
    queryFn: async () => {
      if (!selectedGroup?.id) return [];
      const response = await fetch(`/api/groups/${selectedGroup.id}/members`, { credentials: 'include' });
      if (!response.ok) throw new Error('Failed to fetch group members');
      return response.json();
    },
    enabled: !!selectedGroup?.id && isDetailsDialogOpen,
  });

  // Fetch group statistics
  const { data: groupStatistics, isLoading: statsLoading } = useQuery<GroupStatistics>({
    queryKey: ['groupStatistics', selectedGroup?.id],
    queryFn: async () => {
      if (!selectedGroup?.id) throw new Error('No group selected');
      const response = await fetch(`/api/groups/${selectedGroup.id}/statistics`, { credentials: 'include' });
      if (!response.ok) throw new Error('Failed to fetch group statistics');
      return response.json();
    },
    enabled: !!selectedGroup?.id && isDetailsDialogOpen,
  });

  // Fetch statistics for all groups (for cards)
  const { data: allGroupsStats = [] } = useQuery<GroupStatistics[]>({
    queryKey: ['allGroupsStatistics'],
    queryFn: async () => {
      const statsPromises = groups.map(async (group) => {
        try {
          const response = await fetch(`/api/groups/${group.id}/statistics`, { credentials: 'include' });
          if (response.ok) {
            return await response.json();
          }
          return null;
        } catch (error) {
          console.error(`Failed to fetch stats for group ${group.id}:`, error);
          return null;
        }
      });
      const results = await Promise.all(statsPromises);
      return results.filter(s => s !== null) as GroupStatistics[];
    },
    enabled: groups.length > 0 && !authLoading && !!currentUser && (canManageGroups || canSetTargets),
  });

  // Helper to get statistics for a group
  const getGroupStats = (groupId: string) => {
    return allGroupsStats.find(s => s.groupId === groupId);
  };


  const createGroupMutation = useMutation({
    mutationFn: async (data: InsertGroup) => {
      const response = await fetch('/api/groups', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
        credentials: 'include',
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to create group');
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['groups'] });
      setIsDialogOpen(false);
      reset();
      toast({
        title: 'موفق',
        description: 'گروه جدید با موفقیت ایجاد شد',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'خطا',
        description: error.message || 'ایجاد گروه با مشکل مواجه شد',
        variant: 'destructive',
      });
    },
  });

  const updateGroupMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: Partial<InsertGroup> }) => {
      const response = await fetch(`/api/groups/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
        credentials: 'include',
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to update group');
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['groups'] });
      setIsEditDialogOpen(false);
      setSelectedGroup(null);
      resetEdit();
      toast({
        title: 'موفق',
        description: 'گروه با موفقیت بروز رسانی شد',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'خطا',
        description: error.message || 'بروز رسانی گروه با مشکل مواجه شد',
        variant: 'destructive',
      });
    },
  });

  const deleteGroupMutation = useMutation({
    mutationFn: async (id: string) => {
      const response = await fetch(`/api/groups/${id}`, {
        method: 'DELETE',
        credentials: 'include',
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to delete group');
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['groups'] });
      setIsDeleteDialogOpen(false);
      setSelectedGroup(null);
      toast({
        title: 'موفق',
        description: 'گروه با موفقیت حذف شد',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'خطا',
        description: error.message || 'حذف گروه با مشکل مواجه شد',
        variant: 'destructive',
      });
    },
  });

  const addMemberMutation = useMutation({
    mutationFn: async ({ groupId, userId, assignedRole }: { groupId: string; userId: string; assignedRole: string }) => {
      const response = await fetch(`/api/groups/${groupId}/members`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId, role: assignedRole }),
        credentials: 'include',
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to add member');
      }
      return response.json();
    },
    onSuccess: (data) => {
      // CRITICAL: Invalidate both groups and users queries to sync UI
      queryClient.invalidateQueries({ queryKey: ['groups'] });
      queryClient.invalidateQueries({ queryKey: ['users'] });
      
      // Optimistically update group members if backend returned updated data
      if (data && data.members && selectedGroup) {
        queryClient.setQueryData(['group-members', selectedGroup.id], data.members);
        // Update selected group if provided
        if (data.group) {
          setSelectedGroup(data.group);
        }
      }
      
      refetchMembers();
      setIsAddMemberDialogOpen(false);
      resetAddMember();
      toast({
        title: 'موفق',
        description: 'عضو با موفقیت به گروه اضافه شد',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'خطا',
        description: error.message || 'افزودن عضو با مشکل مواجه شد',
        variant: 'destructive',
      });
    },
  });

  const removeMemberMutation = useMutation({
    mutationFn: async ({ groupId, userId }: { groupId: string; userId: string }) => {
      const response = await fetch(`/api/groups/${groupId}/members/${userId}`, {
        method: 'DELETE',
        credentials: 'include',
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to remove member');
      }
      return response.json();
    },
    onSuccess: (data) => {
      // CRITICAL: Invalidate both groups and users queries to sync UI
      queryClient.invalidateQueries({ queryKey: ['groups'] });
      queryClient.invalidateQueries({ queryKey: ['users'] });
      
      // Optimistically update group members if backend returned updated data
      if (data && data.members && selectedGroup) {
        queryClient.setQueryData(['group-members', selectedGroup.id], data.members);
        // Update selected group if provided
        if (data.group) {
          setSelectedGroup(data.group);
        }
      }
      
      refetchMembers();
      toast({
        title: 'موفق',
        description: 'عضو با موفقیت از گروه حذف شد',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'خطا',
        description: error.message || 'حذف عضو با مشکل مواجه شد',
        variant: 'destructive',
      });
    },
  });


  const {
    register,
    handleSubmit,
    reset,
    formState: { errors, isSubmitting },
  } = useForm<CreateGroupForm>({
    resolver: zodResolver(createGroupSchema),
  });

  const {
    register: registerEdit,
    handleSubmit: handleSubmitEdit,
    reset: resetEdit,
    formState: { errors: errorsEdit, isSubmitting: isSubmittingEdit },
    setValue: setValueEdit,
  } = useForm<EditGroupForm>({
    resolver: zodResolver(editGroupSchema),
  });

  const [addMemberForm, setAddMemberForm] = useState<AddMemberForm>({
    userId: '',
    assignedRole: '',
  });


  const onSubmit = (data: CreateGroupForm) => {
    createGroupMutation.mutate(data);
  };

  const onSubmitEdit = (data: EditGroupForm) => {
    if (selectedGroup) {
      updateGroupMutation.mutate({ id: selectedGroup.id, data });
    }
  };

  const onSubmitAddMember = (e: React.FormEvent) => {
    e.preventDefault();
    if (!addMemberForm.userId || !addMemberForm.assignedRole) {
      toast({
        title: 'خطا',
        description: 'لطفا همه فیلدها را پر کنید',
        variant: 'destructive',
      });
      return;
    }
    if (selectedGroup) {
      addMemberMutation.mutate({
        groupId: selectedGroup.id,
        userId: addMemberForm.userId,
        assignedRole: addMemberForm.assignedRole,
      });
    }
  };

  const resetAddMember = () => {
    setAddMemberForm({ userId: '', assignedRole: '' });
  };


  const handleViewDetails = (group: Group) => {
    setSelectedGroup(group);
    setIsDetailsDialogOpen(true);
  };

  const handleEdit = (group: Group) => {
    setSelectedGroup(group);
    setValueEdit('name', group.name);
    setValueEdit('description', group.description || '');
    setValueEdit('code', group.code);
    setIsEditDialogOpen(true);
  };

  const handleDelete = (group: Group) => {
    setSelectedGroup(group);
    setIsDeleteDialogOpen(true);
  };

  const confirmDelete = () => {
    if (selectedGroup) {
      deleteGroupMutation.mutate(selectedGroup.id);
    }
  };

  const handleRemoveMember = (member: GroupMemberWithUser) => {
    if (selectedGroup && member.user) {
      removeMemberMutation.mutate({
        groupId: selectedGroup.id,
        userId: member.user.id,
      });
    }
  };

  // Filter out users who are already members
  const availableUsers = users.filter(user => 
    !groupMembers.some(member => member.user?.id === user.id)
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-semibold">مدیریت گروه‌ها</h1>
          <p className="text-muted-foreground">مدیریت گروه های بررسی و اعضاء</p>
        </div>
        {canManageGroups && (
          <Button onClick={() => setIsDialogOpen(true)} data-testid="button-create-group">
            <Plus className="ml-2 h-4 w-4" />
            گروه جدید
          </Button>
        )}
      </div>

      {isLoading ? (
        <div className="text-center py-8 text-muted-foreground">در حال بارگذاری...</div>
      ) : groups.length === 0 ? (
        <div className="text-center py-8 text-muted-foreground">هیچ گروهی وجود ندارد</div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {groups.map((group) => {
            const stats = getGroupStats(group.id);
            return (
              <Card key={group.id} className="hover-elevate">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Users className="h-5 w-5" />
                    {group.name}
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {group.description && (
                    <p className="text-sm text-muted-foreground">{group.description}</p>
                  )}
                  
                  {/* Statistics Section */}
                  {stats && (
                    <div className="grid grid-cols-2 gap-2 pt-2 border-t">
                      <div className="space-y-1">
                        <div className="text-xs text-muted-foreground">کل قضایا</div>
                        <div className="text-lg font-semibold">{stats.statistics.totalAssignedCases}</div>
                      </div>
                      <div className="space-y-1">
                        <div className="text-xs text-muted-foreground">تکمیل شده</div>
                        <div className="text-lg font-semibold text-green-600">{stats.statistics.completedCases}</div>
                      </div>
                      <div className="space-y-1">
                        <div className="text-xs text-muted-foreground">در جریان</div>
                        <div className="text-lg font-semibold text-yellow-600">{stats.statistics.pendingCases}</div>
                      </div>
                      <div className="space-y-1">
                        <div className="text-xs text-muted-foreground">اعضاء</div>
                        <div className="text-lg font-semibold">{stats.statistics.membersCount}</div>
                      </div>
                      {stats.targetAchieved && (
                        <div className="col-span-2 space-y-1 pt-1 border-t">
                          <div className="flex items-center justify-between text-xs">
                            <span className="text-muted-foreground">هدف ماهانه</span>
                            <span className="font-medium">
                              {stats.targetAchieved.achieved} / {stats.targetAchieved.target}
                            </span>
                          </div>
                          <div className="w-full bg-gray-200 rounded-full h-2">
                            <div 
                              className={`h-2 rounded-full ${
                                stats.targetAchieved.percentComplete >= 100 ? 'bg-green-600' :
                                stats.targetAchieved.percentComplete >= 80 ? 'bg-yellow-500' :
                                'bg-red-500'
                              }`}
                              style={{ width: `${Math.min(stats.targetAchieved.percentComplete, 100)}%` }}
                            />
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                  
                  <div className="flex gap-2">
                    <Button 
                      variant="outline" 
                      className="flex-1" 
                      size="sm" 
                      onClick={() => handleViewDetails(group)}
                      data-testid={`button-view-group-${group.id}`}
                    >
                      <Eye className="ml-2 h-4 w-4" />
                      مشاهده جزئیات
                    </Button>
                    {canManageGroups && (
                      <>
                        <Button 
                          variant="outline" 
                          size="icon" 
                          onClick={() => handleEdit(group)}
                          data-testid={`button-edit-group-${group.id}`}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button 
                          variant="outline" 
                          size="icon" 
                          onClick={() => handleDelete(group)}
                          data-testid={`button-delete-group-${group.id}`}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </>
                    )}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {/* Create Group Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>ایجاد گروه جدید</DialogTitle>
            <DialogDescription>
              اطلاعات گروه جدید را وارد کنید
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSubmit(onSubmit)}>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="code">کد گروه *</Label>
                <Input
                  id="code"
                  {...register('code')}
                  placeholder="مثلا: GRP-001"
                />
                {errors.code && (
                  <p className="text-sm text-destructive">{errors.code.message}</p>
                )}
              </div>
              <div className="space-y-2">
                <Label htmlFor="name">نام گروه *</Label>
                <Input
                  id="name"
                  {...register('name')}
                  placeholder="مثلا: گروه اول سنجش ابتدایی"
                />
                {errors.name && (
                  <p className="text-sm text-destructive">{errors.name.message}</p>
                )}
              </div>
              <div className="space-y-2">
                <Label htmlFor="description">توضیحات</Label>
                <Textarea
                  id="description"
                  {...register('description')}
                  placeholder="توضیحات اختیاری در مورد گروه"
                  rows={3}
                />
              </div>
            </div>
            <DialogFooter className="mt-6">
              <Button
                type="button"
                variant="outline"
                onClick={() => {
                  setIsDialogOpen(false);
                  reset();
                }}
              >
                لغو
              </Button>
              <Button type="submit" disabled={isSubmitting}>
                {isSubmitting ? 'در حال ایجاد...' : 'ایجاد گروه'}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Edit Group Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>ویرایش گروه</DialogTitle>
            <DialogDescription>
              اطلاعات گروه را ویرایش کنید
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSubmitEdit(onSubmitEdit)}>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="edit-code">کد گروه *</Label>
                <Input
                  id="edit-code"
                  {...registerEdit('code')}
                />
                {errorsEdit.code && (
                  <p className="text-sm text-destructive">{errorsEdit.code.message}</p>
                )}
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-name">نام گروه *</Label>
                <Input
                  id="edit-name"
                  {...registerEdit('name')}
                />
                {errorsEdit.name && (
                  <p className="text-sm text-destructive">{errorsEdit.name.message}</p>
                )}
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-description">توضیحات</Label>
                <Textarea
                  id="edit-description"
                  {...registerEdit('description')}
                  rows={3}
                />
              </div>
            </div>
            <DialogFooter className="mt-6">
              <Button
                type="button"
                variant="outline"
                onClick={() => {
                  setIsEditDialogOpen(false);
                  setSelectedGroup(null);
                  resetEdit();
                }}
              >
                لغو
              </Button>
              <Button type="submit" disabled={isSubmittingEdit}>
                {isSubmittingEdit ? 'در حال ذخیره...' : 'ذخیره تغییرات'}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Delete Group Confirmation */}
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>حذف گروه</AlertDialogTitle>
            <AlertDialogDescription>
              آیا مطمئن هستید که می‌خواهید گروه "{selectedGroup?.name}" را حذف کنید؟
              این عمل قابل بازگشت نیست.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>لغو</AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmDelete}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              حذف
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Group Details Dialog */}
      <Dialog open={isDetailsDialogOpen} onOpenChange={setIsDetailsDialogOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto" dir="rtl">
          <DialogHeader>
            <DialogTitle className="text-right">جزئیات گروه: {selectedGroup?.name}</DialogTitle>
            <DialogDescription className="text-right">
              {selectedGroup?.description}
            </DialogDescription>
          </DialogHeader>
          <Tabs defaultValue="info" className="w-full">
            <TabsList className="grid w-full grid-cols-3" dir="rtl">
              <TabsTrigger value="info" className="text-right">اطلاعات</TabsTrigger>
              <TabsTrigger value="statistics" className="text-right">آمار</TabsTrigger>
              <TabsTrigger value="members" className="text-right">اعضاء ({groupMembers.length})</TabsTrigger>
            </TabsList>
            <TabsContent value="info" className="space-y-4 mt-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4" dir="rtl">
                <div className="space-y-2 text-right">
                  <Label className="text-right block">کد گروه</Label>
                  <p className="text-sm font-medium text-right">{selectedGroup?.code}</p>
                </div>
                <div className="space-y-2 text-right">
                  <Label className="text-right block">نام گروه</Label>
                  <p className="text-sm font-medium text-right">{selectedGroup?.name}</p>
                </div>
                <div className="space-y-2 text-right">
                  <Label className="text-right block">وضعیت</Label>
                  <div className="flex justify-end">
                    <Badge variant={selectedGroup?.isActive ? 'default' : 'secondary'}>
                      {selectedGroup?.isActive ? 'فعال' : 'غیرفعال'}
                    </Badge>
                  </div>
                </div>
                {selectedGroup?.description && (
                  <div className="md:col-span-2 space-y-2 text-right">
                    <Label className="text-right block">توضیحات</Label>
                    <p className="text-sm text-muted-foreground whitespace-pre-wrap text-right">{selectedGroup.description}</p>
                  </div>
                )}
              </div>
            </TabsContent>
            <TabsContent value="statistics" className="space-y-4 mt-4" dir="rtl">
              {statsLoading ? (
                <div className="text-center py-8 text-muted-foreground">در حال بارگذاری آمار...</div>
              ) : groupStatistics ? (
                <div className="space-y-6">
                  {/* KPIs Section */}
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <Card>
                      <CardContent className="pt-6">
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="text-sm text-muted-foreground">کل قضایا</p>
                            <p className="text-2xl font-bold mt-1">{groupStatistics.statistics.totalAssignedCases}</p>
                          </div>
                          <Target className="h-8 w-8 text-muted-foreground" />
                        </div>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardContent className="pt-6">
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="text-sm text-muted-foreground">تکمیل شده</p>
                            <p className="text-2xl font-bold mt-1 text-green-600">{groupStatistics.statistics.completedCases}</p>
                          </div>
                          <CheckCircle2 className="h-8 w-8 text-green-600" />
                        </div>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardContent className="pt-6">
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="text-sm text-muted-foreground">در جریان</p>
                            <p className="text-2xl font-bold mt-1 text-yellow-600">{groupStatistics.statistics.pendingCases}</p>
                          </div>
                          <Clock className="h-8 w-8 text-yellow-600" />
                        </div>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardContent className="pt-6">
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="text-sm text-muted-foreground">اعضاء</p>
                            <p className="text-2xl font-bold mt-1">{groupStatistics.statistics.membersCount}</p>
                          </div>
                          <Users className="h-8 w-8 text-muted-foreground" />
                        </div>
                      </CardContent>
                    </Card>
                  </div>

                  {/* Target Achievement */}
                  {groupStatistics.targetAchieved && (
                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                          <TrendingUp className="h-5 w-5" />
                          پیشرفت هدف
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div className="space-y-2">
                          <div className="flex items-center justify-between text-sm">
                            <span className="text-muted-foreground">هدف ماهانه</span>
                            <span className="font-medium">
                              {groupStatistics.targetAchieved.achieved} / {groupStatistics.targetAchieved.target}
                            </span>
                          </div>
                          <div className="w-full bg-gray-200 rounded-full h-3">
                            <div 
                              className={`h-3 rounded-full transition-all ${
                                groupStatistics.targetAchieved.percentComplete >= 100 ? 'bg-green-600' :
                                groupStatistics.targetAchieved.percentComplete >= 80 ? 'bg-yellow-500' :
                                'bg-red-500'
                              }`}
                              style={{ width: `${Math.min(groupStatistics.targetAchieved.percentComplete, 100)}%` }}
                            />
                          </div>
                          <div className="text-xs text-muted-foreground text-left">
                            {groupStatistics.targetAchieved.percentComplete}% تکمیل شده
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  )}

                  {/* Member Activity */}
                  <Card>
                    <CardHeader>
                      <CardTitle>فعالیت اعضاء</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead className="text-right">نام</TableHead>
                            <TableHead className="text-right">نقش</TableHead>
                            <TableHead className="text-right">قضایا</TableHead>
                            <TableHead className="text-right">تکمیل شده</TableHead>
                            <TableHead className="text-right">درصد موفقیت</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {groupStatistics.memberActivity.length === 0 ? (
                            <TableRow>
                              <TableCell colSpan={5} className="text-center text-muted-foreground">
                                هیچ فعالیتی ثبت نشده است
                              </TableCell>
                            </TableRow>
                          ) : (
                            groupStatistics.memberActivity.map((member) => {
                              const successRate = member.casesHandled > 0 
                                ? Math.round((member.casesCompleted / member.casesHandled) * 100)
                                : 0;
                              return (
                                <TableRow key={member.userId}>
                                  <TableCell className="text-right">
                                    <div>
                                      <div className="font-medium">{member.userName}</div>
                                      <div className="text-xs text-muted-foreground">{member.auditId}</div>
                                    </div>
                                  </TableCell>
                                  <TableCell className="text-right">
                                    {member.assignedRole ? getAssignedRoleDari(member.assignedRole) : '—'}
                                  </TableCell>
                                  <TableCell className="text-right">{member.casesHandled}</TableCell>
                                  <TableCell className="text-right text-green-600">{member.casesCompleted}</TableCell>
                                  <TableCell className="text-right">
                                    <Badge variant={successRate >= 80 ? 'default' : successRate >= 50 ? 'secondary' : 'destructive'}>
                                      {successRate}%
                                    </Badge>
                                  </TableCell>
                                </TableRow>
                              );
                            })
                          )}
                        </TableBody>
                      </Table>
                    </CardContent>
                  </Card>
                </div>
              ) : (
                <div className="text-center py-8 text-muted-foreground">آمار در دسترس نیست</div>
              )}
            </TabsContent>
            <TabsContent value="members" className="space-y-4 mt-4" dir="rtl">
              {canManageGroups && (
                <Button
                  onClick={() => setIsAddMemberDialogOpen(true)}
                  size="sm"
                  className="mb-4"
                >
                  <UserPlus className="ml-2 h-4 w-4" />
                  افزودن عضو
                </Button>
              )}
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="text-right">نام</TableHead>
                    <TableHead className="text-right">آی دی بررسی</TableHead>
                    <TableHead className="text-right">نقش اصلی</TableHead>
                    <TableHead className="text-right">نقش در گروه</TableHead>
                    {canManageGroups && <TableHead className="text-right">عملیات</TableHead>}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {groupMembers.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={canManageGroups ? 5 : 4} className="text-center text-muted-foreground">
                        هیچ عضوی وجود ندارد
                      </TableCell>
                    </TableRow>
                  ) : (
                    groupMembers.map((member) => (
                      <TableRow key={member.id}>
                        <TableCell className="text-right">{member.user?.fullName || '—'}</TableCell>
                        <TableCell className="text-right">{member.user?.auditId || '—'}</TableCell>
                        <TableCell className="text-right">
                          {member.user?.role ? getRoleDari(member.user.role) : '—'}
                        </TableCell>
                        <TableCell className="text-right">
                          {member.assignedRole ? getAssignedRoleDari(member.assignedRole) : '—'}
                        </TableCell>
                        {canManageGroups && (
                          <TableCell className="text-right">
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => handleRemoveMember(member)}
                              className="text-destructive hover:text-destructive"
                              title="حذف عضو"
                            >
                              <X className="h-4 w-4" />
                            </Button>
                          </TableCell>
                        )}
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </TabsContent>
          </Tabs>
        </DialogContent>
      </Dialog>

      {/* Add Member Dialog */}
      <Dialog open={isAddMemberDialogOpen} onOpenChange={setIsAddMemberDialogOpen}>
        <DialogContent dir="rtl" className="text-right">
          <DialogHeader>
            <DialogTitle>افزودن عضو به گروه</DialogTitle>
            <DialogDescription>
              کاربر و نقش را انتخاب کنید.
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={onSubmitAddMember}>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="add-member-user">کاربر *</Label>
                <Select
                  value={addMemberForm.userId}
                  onValueChange={(value) => setAddMemberForm({ ...addMemberForm, userId: value })}
                >
                  <SelectTrigger id="add-member-user" dir="rtl">
                    <SelectValue placeholder="انتخاب کاربر" />
                  </SelectTrigger>
                  <SelectContent dir="rtl">
                    {availableUsers.map((user) => (
                      <SelectItem key={user.id} value={user.id}>
                        {user.fullName} ({user.auditId})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="add-member-role">نقش در گروه *</Label>
                <Select
                  value={addMemberForm.assignedRole}
                  onValueChange={(value) => setAddMemberForm({ ...addMemberForm, assignedRole: value })}
                >
                  <SelectTrigger id="add-member-role" dir="rtl">
                    <SelectValue placeholder="انتخاب نقش" />
                  </SelectTrigger>
                  <SelectContent dir="rtl">
                    <SelectItem value="auditor">بررس</SelectItem>
                    <SelectItem value="senior_auditor">مدیر عمومی گروه</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <DialogFooter className="mt-6">
              <Button
                type="button"
                variant="outline"
                onClick={() => {
                  setIsAddMemberDialogOpen(false);
                  resetAddMember();
                }}
              >
                لغو
              </Button>
              <Button type="submit" disabled={addMemberMutation.isPending}>
                {addMemberMutation.isPending ? 'در حال افزودن...' : 'افزودن'}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

    </div>
  );
}
