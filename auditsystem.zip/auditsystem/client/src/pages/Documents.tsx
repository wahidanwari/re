import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Upload, FileText, Download, Eye, X, AlertCircle } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import type { Document, Case } from '@shared/schema';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';
import { userHasPermission, getUserPermissions } from '@/utils/permissions';
import ShamsiDatePickerDDMMYYYY from '@/components/ShamsiDatePickerDDMMYYYY';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';

const ALLOWED_DOCUMENT_TYPES = ['مکتوب', 'استعلام', 'اسناد حمایوی'];
const MAX_FILE_SIZE = 25 * 1024 * 1024; // 25MB
const ALLOWED_FILE_TYPES = ['application/pdf', 'image/jpeg', 'image/png'];

export default function Documents() {
  const [selectedCaseId, setSelectedCaseId] = useState<string>('');
  const [isUploadDialogOpen, setIsUploadDialogOpen] = useState(false);
  const [isDetailsDialogOpen, setIsDetailsDialogOpen] = useState(false);
  const [isRevokeDialogOpen, setIsRevokeDialogOpen] = useState(false);
  const [selectedDocument, setSelectedDocument] = useState<Document | null>(null);
  const [revokeReason, setRevokeReason] = useState('');
  const [uploadForm, setUploadForm] = useState({
    caseId: '',
    docType: '',
    docDate: '',
    description: '',
    isFinal: false,
  });
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [uploadProgress, setUploadProgress] = useState(0);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { user: currentUser, loading: authLoading } = useAuth();

  const canUpload = currentUser && userHasPermission(
    currentUser,
    'documents:upload'
  );
  const canRevoke = currentUser && userHasPermission(
    currentUser,
    'users:manage'
  );

  const { data: cases = [] } = useQuery<Case[]>({
    queryKey: ['cases'],
    queryFn: async () => {
      const response = await fetch('/api/cases', { credentials: 'include' });
      if (!response.ok) throw new Error('Failed to fetch cases');
      return response.json();
    },
    enabled: !authLoading && !!currentUser && userHasPermission(currentUser, 'cases:view'),
  });

  const { data: documents = [], isLoading } = useQuery<Document[]>({
    queryKey: ['documents', selectedCaseId],
    queryFn: async () => {
      if (!selectedCaseId) return [];
      const response = await fetch(`/api/documents/case/${selectedCaseId}`, { credentials: 'include' });
      if (!response.ok) throw new Error('Failed to fetch documents');
      return response.json();
    },
    enabled: !!selectedCaseId,
  });

  const { data: documentDetails } = useQuery<Document>({
    queryKey: ['document', selectedDocument?.id],
    queryFn: async () => {
      if (!selectedDocument?.id) throw new Error('No document selected');
      const response = await fetch(`/api/documents/${selectedDocument.id}`, { credentials: 'include' });
      if (!response.ok) throw new Error('Failed to fetch document details');
      return response.json();
    },
    enabled: !!selectedDocument?.id && isDetailsDialogOpen,
  });

  const uploadDocumentMutation = useMutation({
    mutationFn: async (formData: FormData) => {
      const response = await fetch('/api/documents/upload', {
        method: 'POST',
        body: formData,
        credentials: 'include',
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to upload document');
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['documents'] });
      setIsUploadDialogOpen(false);
      setUploadForm({ caseId: '', docType: '', docDate: '', description: '', isFinal: false });
      setSelectedFile(null);
      setUploadProgress(0);
      toast({
        title: 'موفق',
        description: 'سند با موفقیت آپلود شد',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'خطا',
        description: error.message || 'آپلود سند با مشکل مواجه شد',
        variant: 'destructive',
      });
      setUploadProgress(0);
    },
  });

  const revokeDocumentMutation = useMutation({
    mutationFn: async ({ documentId, reason }: { documentId: string; reason: string }) => {
      const response = await fetch(`/api/documents/${documentId}/revoke`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ revocationReason: reason }),
        credentials: 'include',
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to revoke document');
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['documents'] });
      setIsRevokeDialogOpen(false);
      setRevokeReason('');
      setSelectedDocument(null);
      toast({
        title: 'موفق',
        description: 'سند با موفقیت لغو شد',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'خطا',
        description: error.message || 'لغو سند با مشکل مواجه شد',
        variant: 'destructive',
      });
    },
  });

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Validate file type
    if (!ALLOWED_FILE_TYPES.includes(file.type)) {
      toast({
        title: 'خطا',
        description: 'نوع فایل مجاز نیست. فقط PDF، JPG و PNG مجاز است',
        variant: 'destructive',
      });
      return;
    }

    // Validate file size
    if (file.size > MAX_FILE_SIZE) {
      toast({
        title: 'خطا',
        description: `حجم فایل بیش از حد مجاز است (حداکثر ${MAX_FILE_SIZE / 1024 / 1024}MB)`,
        variant: 'destructive',
      });
      return;
    }

    setSelectedFile(file);
  };

  const handleUpload = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedFile) {
      toast({
        title: 'خطا',
        description: 'لطفا یک فایل انتخاب کنید',
        variant: 'destructive',
      });
      return;
    }

    if (!uploadForm.caseId) {
      toast({
        title: 'خطا',
        description: 'لطفا قضیه را انتخاب کنید',
        variant: 'destructive',
      });
      return;
    }

    if (!uploadForm.docType) {
      toast({
        title: 'خطا',
        description: 'لطفا نوع سند را انتخاب کنید',
        variant: 'destructive',
      });
      return;
    }

    if (!uploadForm.docDate) {
      toast({
        title: 'خطا',
        description: 'لطفا تاریخ سند را وارد کنید',
        variant: 'destructive',
      });
      return;
    }

    const formData = new FormData();
    formData.append('file', selectedFile);
    formData.append('caseId', uploadForm.caseId);
    formData.append('docType', uploadForm.docType);
    formData.append('docDate', uploadForm.docDate);
    formData.append('description', uploadForm.description);
    formData.append('isFinal', uploadForm.isFinal.toString());

    uploadDocumentMutation.mutate(formData);
  };

  const handleDownload = async (doc: Document) => {
    try {
      const response = await fetch(`/api/documents/${doc.id}/download`, {
        credentials: 'include',
      });
      if (!response.ok) throw new Error('Failed to download document');
      
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = doc.storagePath.split('/').pop() || 'document';
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    } catch (error) {
      toast({
        title: 'خطا',
        description: 'دانلود سند با مشکل مواجه شد',
        variant: 'destructive',
      });
    }
  };

  const handleViewDetails = (document: Document) => {
    setSelectedDocument(document);
    setIsDetailsDialogOpen(true);
  };

  const handleRevoke = (document: Document) => {
    setSelectedDocument(document);
    setIsRevokeDialogOpen(true);
  };

  const confirmRevoke = () => {
    if (selectedDocument && revokeReason.trim()) {
      revokeDocumentMutation.mutate({
        documentId: selectedDocument.id,
        reason: revokeReason,
      });
    } else {
      toast({
        title: 'خطا',
        description: 'لطفا دلیل لغو را وارد کنید',
        variant: 'destructive',
      });
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(2) + ' KB';
    return (bytes / 1024 / 1024).toFixed(2) + ' MB';
  };

  const getFileTypeIcon = (mimeType: string) => {
    if (mimeType === 'application/pdf') return 'PDF';
    if (mimeType.startsWith('image/')) return 'IMG';
    return 'FILE';
  };

  return (
    <div className="p-8 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-semibold">مدیریت اسناد</h1>
          <p className="text-muted-foreground">آپلود و مدیریت اسناد بررسی</p>
        </div>
        {canUpload && (
          <Button onClick={() => setIsUploadDialogOpen(true)} data-testid="button-upload-document">
            <Upload className="ml-2 h-4 w-4" />
            آپلود سند
          </Button>
        )}
      </div>

      <Card>
        <CardHeader>
          <div className="flex items-center gap-4">
            <div className="flex-1">
              <Label htmlFor="select-case">انتخاب قضیه</Label>
              <Select value={selectedCaseId} onValueChange={setSelectedCaseId}>
                <SelectTrigger id="select-case" className="mt-2">
                  <SelectValue placeholder="قضیه را انتخاب کنید" />
                </SelectTrigger>
                <SelectContent>
                  {cases.map((case_) => (
                    <SelectItem key={case_.id} value={case_.caseId}>
                      {case_.caseId} - {case_.companyName}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {!selectedCaseId ? (
            <div className="text-center py-8 text-muted-foreground">
              لطفا یک قضیه انتخاب کنید تا اسناد آن نمایش داده شود
            </div>
          ) : isLoading ? (
            <div className="text-center py-8 text-muted-foreground">در حال بارگذاری...</div>
          ) : documents.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">هیچ سندی برای این قضیه وجود ندارد</div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="text-right">نوع سند</TableHead>
                  <TableHead className="text-right">نوع فایل</TableHead>
                  <TableHead className="text-right">تاریخ سند</TableHead>
                  <TableHead className="text-right">حجم</TableHead>
                  <TableHead className="text-right">وضعیت</TableHead>
                  <TableHead className="text-right">تاریخ آپلود</TableHead>
                  <TableHead className="text-right">عملیات</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {documents.map((doc) => (
                  <TableRow key={doc.id} className="hover-elevate">
                    <TableCell>
                      <Badge variant="outline">{doc.docType}</Badge>
                    </TableCell>
                    <TableCell>{getFileTypeIcon(doc.mimeType)}</TableCell>
                    <TableCell>{doc.docDate}</TableCell>
                    <TableCell>{formatFileSize(doc.sizeBytes)}</TableCell>
                    <TableCell>
                      {doc.isRevoked ? (
                        <Badge variant="destructive">لغو شده</Badge>
                      ) : doc.isFinal ? (
                        <Badge variant="default">نهایی</Badge>
                      ) : (
                        <Badge variant="secondary">موقت</Badge>
                      )}
                    </TableCell>
                    <TableCell>
                      {doc.uploadedAt ? new Date(doc.uploadedAt).toLocaleDateString('fa-AF') : '—'}
                    </TableCell>
                    <TableCell>
                      <div className="flex gap-2">
                        <Button
                          size="icon"
                          variant="ghost"
                          onClick={() => handleViewDetails(doc)}
                          data-testid={`button-view-document-${doc.id}`}
                        >
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button
                          size="icon"
                          variant="ghost"
                          onClick={() => handleDownload(doc)}
                          disabled={doc.isRevoked}
                          data-testid={`button-download-${doc.id}`}
                        >
                          <Download className="h-4 w-4" />
                        </Button>
                        {canRevoke && !doc.isRevoked && (
                          <Button
                            size="icon"
                            variant="ghost"
                            onClick={() => handleRevoke(doc)}
                            data-testid={`button-revoke-${doc.id}`}
                          >
                            <X className="h-4 w-4 text-destructive" />
                          </Button>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* Upload Document Dialog */}
      <Dialog open={isUploadDialogOpen} onOpenChange={setIsUploadDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>آپلود سند</DialogTitle>
            <DialogDescription>
              فایل سند را انتخاب کرده و اطلاعات آن را وارد کنید
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleUpload}>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="upload-file">فایل *</Label>
                <Input
                  id="upload-file"
                  type="file"
                  accept=".pdf,.jpg,.jpeg,.png"
                  onChange={handleFileSelect}
                  required
                />
                {selectedFile && (
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <FileText className="h-4 w-4" />
                    <span>{selectedFile.name}</span>
                    <span>({formatFileSize(selectedFile.size)})</span>
                  </div>
                )}
                <p className="text-xs text-muted-foreground">
                  انواع مجاز: PDF, JPG, PNG | حداکثر حجم: 25MB
                </p>
              </div>
              <div className="space-y-2">
                <Label htmlFor="upload-case">قضیه *</Label>
                <Select
                  value={uploadForm.caseId}
                  onValueChange={(value) => setUploadForm({ ...uploadForm, caseId: value })}
                >
                  <SelectTrigger id="upload-case">
                    <SelectValue placeholder="انتخاب قضیه" />
                  </SelectTrigger>
                  <SelectContent>
                    {cases.map((case_) => (
                      <SelectItem key={case_.id} value={case_.caseId}>
                        {case_.caseId} - {case_.companyName}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="upload-doc-type">نوع سند *</Label>
                <Select
                  value={uploadForm.docType}
                  onValueChange={(value) => setUploadForm({ ...uploadForm, docType: value })}
                >
                  <SelectTrigger id="upload-doc-type">
                    <SelectValue placeholder="انتخاب نوع سند" />
                  </SelectTrigger>
                  <SelectContent>
                    {ALLOWED_DOCUMENT_TYPES.map((type) => (
                      <SelectItem key={type} value={type}>
                        {type}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="upload-doc-date">تاریخ سند *</Label>
                <ShamsiDatePickerDDMMYYYY
                  value={uploadForm.docDate}
                  onChange={(date) => setUploadForm({ ...uploadForm, docDate: date })}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="upload-description">توضیحات</Label>
                <Textarea
                  id="upload-description"
                  value={uploadForm.description}
                  onChange={(e) => setUploadForm({ ...uploadForm, description: e.target.value })}
                  placeholder="توضیحات اختیاری"
                  rows={3}
                  className="text-right"
                />
              </div>
              <div className="flex items-center space-x-2 space-x-reverse">
                <Checkbox
                  id="upload-is-final"
                  checked={uploadForm.isFinal}
                  onCheckedChange={(checked) => setUploadForm({ ...uploadForm, isFinal: checked === true })}
                />
                <Label htmlFor="upload-is-final" className="cursor-pointer">
                  سند نهایی است
                </Label>
              </div>
            </div>
            <DialogFooter className="mt-6">
              <Button
                type="button"
                variant="outline"
                onClick={() => {
                  setIsUploadDialogOpen(false);
                  setUploadForm({ caseId: '', docType: '', docDate: '', description: '', isFinal: false });
                  setSelectedFile(null);
                }}
              >
                لغو
              </Button>
              <Button type="submit" disabled={uploadDocumentMutation.isPending}>
                {uploadDocumentMutation.isPending ? 'در حال آپلود...' : 'آپلود'}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Document Details Dialog */}
      <Dialog open={isDetailsDialogOpen} onOpenChange={setIsDetailsDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>جزئیات سند</DialogTitle>
            <DialogDescription>
              مشاهده اطلاعات کامل سند
            </DialogDescription>
          </DialogHeader>
          {documentDetails && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>نوع سند</Label>
                  <p className="text-sm">
                    <Badge variant="outline">{documentDetails.docType}</Badge>
                  </p>
                </div>
                <div>
                  <Label>نوع فایل</Label>
                  <p className="text-sm">{getFileTypeIcon(documentDetails.mimeType)}</p>
                </div>
                <div>
                  <Label>تاریخ سند</Label>
                  <p className="text-sm">{documentDetails.docDate}</p>
                </div>
                <div>
                  <Label>حجم</Label>
                  <p className="text-sm">{formatFileSize(documentDetails.sizeBytes)}</p>
                </div>
                <div>
                  <Label>وضعیت</Label>
                  <p className="text-sm">
                    {documentDetails.isRevoked ? (
                      <Badge variant="destructive">لغو شده</Badge>
                    ) : documentDetails.isFinal ? (
                      <Badge variant="default">نهایی</Badge>
                    ) : (
                      <Badge variant="secondary">موقت</Badge>
                    )}
                  </p>
                </div>
                <div>
                  <Label>تاریخ آپلود</Label>
                  <p className="text-sm">
                    {documentDetails.uploadedAt
                      ? new Date(documentDetails.uploadedAt).toLocaleDateString('fa-AF')
                      : '—'}
                  </p>
                </div>
              </div>
              {documentDetails.description && (
                <div>
                  <Label>توضیحات</Label>
                  <p className="text-sm text-muted-foreground whitespace-pre-wrap">
                    {documentDetails.description}
                  </p>
                </div>
              )}
              {documentDetails.isRevoked && documentDetails.revocationReason && (
                <div className="bg-destructive/10 p-4 rounded-lg">
                  <Label className="text-destructive">دلیل لغو</Label>
                  <p className="text-sm text-destructive">{documentDetails.revocationReason}</p>
                </div>
              )}
              <div className="flex gap-2 pt-4">
                <Button
                  onClick={() => handleDownload(documentDetails)}
                  disabled={documentDetails.isRevoked}
                  className="flex-1"
                >
                  <Download className="ml-2 h-4 w-4" />
                  دانلود
                </Button>
                {canRevoke && !documentDetails.isRevoked && (
                  <Button
                    variant="destructive"
                    onClick={() => handleRevoke(documentDetails)}
                    className="flex-1"
                  >
                    <X className="ml-2 h-4 w-4" />
                    لغو سند
                  </Button>
                )}
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Revoke Document Dialog */}
      <AlertDialog open={isRevokeDialogOpen} onOpenChange={setIsRevokeDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>لغو سند</AlertDialogTitle>
            <AlertDialogDescription>
              آیا مطمئن هستید که می‌خواهید این سند را لغو کنید؟ لطفا دلیل لغو را وارد کنید.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="revoke-reason">دلیل لغو *</Label>
              <Textarea
                id="revoke-reason"
                value={revokeReason}
                onChange={(e) => setRevokeReason(e.target.value)}
                className="text-right"
                placeholder="لطفا دلیل لغو سند را وارد کنید..."
                rows={4}
                required
              />
            </div>
            <AlertDialogFooter>
              <AlertDialogCancel>لغو</AlertDialogCancel>
              <AlertDialogAction
                onClick={confirmRevoke}
                disabled={!revokeReason.trim() || revokeDocumentMutation.isPending}
                className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              >
                {revokeDocumentMutation.isPending ? 'در حال لغو...' : 'لغو سند'}
              </AlertDialogAction>
            </AlertDialogFooter>
          </div>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
