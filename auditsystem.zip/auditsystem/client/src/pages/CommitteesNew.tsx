/**
 * Committee List Page
 * Displays all committees with actions to view, close, and export reports
 */

import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Plus, Eye, X, FileDown, Loader2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';
import jalaali from 'jalaali-js';

interface Committee {
  id: string;
  title: string;
  year: number;
  month: number;
  status: 'DRAFT' | 'APPROVED' | 'CLOSED';
  createdAt: string;
  approvedAt?: string;
  createdBy: string;
  approvedBy?: string;
}

const monthNames = [
  'حمل', 'ثور', 'جوزا', 'سرطان', 'اسد', 'سنبله',
  'میزان', 'عقرب', 'قوس', 'جدی', 'دلو', 'حوت'
];

function getStatusBadge(status: string) {
  const statusMap: Record<string, { label: string; variant: 'default' | 'secondary' | 'destructive' | 'outline' }> = {
    DRAFT: { label: 'پیش‌نویس', variant: 'outline' },
    APPROVED: { label: 'تایید شده', variant: 'default' },
    CLOSED: { label: 'بسته شده', variant: 'secondary' },
  };
  const statusInfo = statusMap[status] || { label: status, variant: 'outline' };
  return <Badge variant={statusInfo.variant}>{statusInfo.label}</Badge>;
}

function formatShamsiDate(dateString: string): string {
  const date = new Date(dateString);
  const j = jalaali.toJalaali(date);
  return `${j.jy}/${String(j.jm).padStart(2, '0')}/${String(j.jd).padStart(2, '0')}`;
}

export default function CommitteesNew() {
  const [location, setLocation] = useLocation();
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch committees
  const { data: committees = [], isLoading } = useQuery<Committee[]>({
    queryKey: ['committees-new'],
    queryFn: async () => {
      const response = await fetch('/api/committees-new', {
        credentials: 'include',
      });
      if (!response.ok) throw new Error('Failed to fetch committees');
      return response.json();
    },
  });

  // Close committee mutation
  const closeMutation = useMutation({
    mutationFn: async (committeeId: string) => {
      const response = await fetch(`/api/committees-new/${committeeId}/close`, {
        method: 'POST',
        credentials: 'include',
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to close committee');
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['committees-new'] });
      toast({
        title: 'موفق',
        description: 'کمیته با موفقیت بسته شد',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'خطا',
        description: error.message,
        variant: 'destructive',
      });
    },
  });

  // Export report
  const handleExport = async (committeeId: string) => {
    try {
      const response = await fetch(`/api/committee-reports/committees/${committeeId}/export?format=excel`, {
        credentials: 'include',
      });
      if (!response.ok) throw new Error('Failed to export report');
      
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `committee-report-${committeeId}.xlsx`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      
      toast({
        title: 'موفق',
        description: 'گزارش با موفقیت صادر شد',
      });
    } catch (error: any) {
      toast({
        title: 'خطا',
        description: error.message || 'خطا در صادر کردن گزارش',
        variant: 'destructive',
      });
    }
  };

  // Check if user can manage committees
  const canManage = user?.role === 'system_admin' || 
                    user?.role === 'director' || 
                    (user?.permissionPackages && Array.isArray(user.permissionPackages) && user.permissionPackages.includes('acting_coordinator'));

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">کمیته‌ها</h1>
        {canManage && (
          <Button onClick={() => setLocation('/committees-new/create')}>
            <Plus className="ml-2 h-4 w-4" />
            ایجاد کمیته جدید
          </Button>
        )}
      </div>

      <Card>
        <CardHeader>
          <CardTitle>لیست کمیته‌ها</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="h-6 w-6 animate-spin" />
            </div>
          ) : committees.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              هیچ کمیته‌ای یافت نشد
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>عنوان</TableHead>
                  <TableHead>ماه</TableHead>
                  <TableHead>سال</TableHead>
                  <TableHead>وضعیت</TableHead>
                  <TableHead>تاریخ ایجاد</TableHead>
                  <TableHead>عملیات</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {committees.map((committee) => (
                  <TableRow key={committee.id}>
                    <TableCell className="font-medium">{committee.title}</TableCell>
                    <TableCell>{monthNames[committee.month - 1]}</TableCell>
                    <TableCell>{committee.year}</TableCell>
                    <TableCell>{getStatusBadge(committee.status)}</TableCell>
                    <TableCell>{formatShamsiDate(committee.createdAt)}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => setLocation(`/committees-new/${committee.id}`)}
                        >
                          <Eye className="ml-1 h-4 w-4" />
                          مشاهده
                        </Button>
                        {canManage && committee.status === 'APPROVED' && (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => {
                              if (confirm('آیا مطمئن هستید که می‌خواهید این کمیته را ببندید؟')) {
                                closeMutation.mutate(committee.id);
                              }
                            }}
                            disabled={closeMutation.isPending}
                          >
                            <X className="ml-1 h-4 w-4" />
                            بستن
                          </Button>
                        )}
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleExport(committee.id)}
                        >
                          <FileDown className="ml-1 h-4 w-4" />
                          گزارش
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

