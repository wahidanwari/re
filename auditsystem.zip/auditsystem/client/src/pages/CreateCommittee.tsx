/**
 * Create Committee Page
 * Allows creating a new committee and assigning cases to audit groups
 */

import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { ArrowRight, Loader2, X } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';
import jalaali from 'jalaali-js';
import type { Case } from '@shared/schema';

interface EligibleCase extends Case {
  isEligible: boolean;
  entityName?: string;
}

interface Group {
  id: string;
  name: string;
}

const monthNames = [
  'حمل', 'ثور', 'جوزا', 'سرطان', 'اسد', 'سنبله',
  'میزان', 'عقرب', 'قوس', 'جدی', 'دلو', 'حوت'
];

export default function CreateCommittee() {
  const [location, setLocation] = useLocation();
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [title, setTitle] = useState('');
  const [year, setYear] = useState<number>(() => {
    const j = jalaali.toJalaali(new Date());
    return j.jy;
  });
  const [month, setMonth] = useState<number>(() => {
    const j = jalaali.toJalaali(new Date());
    return j.jm;
  });
  const [selectedCases, setSelectedCases] = useState<Set<string>>(new Set());
  const [selectedGroup, setSelectedGroup] = useState<string>('');
  const [step, setStep] = useState<'create' | 'assign'>('create');
  const [createdCommitteeId, setCreatedCommitteeId] = useState<string | null>(null);

  // Fetch all cases and filter client-side for eligible cases
  // Use existing /api/cases endpoint and filter client-side for eligible cases
  const { data: allCases = [], isLoading: casesLoading, error: casesError } = useQuery<Case[]>({
    queryKey: ['cases'],
    queryFn: async () => {
      const response = await fetch('/api/cases', {
        credentials: 'include',
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'خطا در دریافت قضایا');
      }
      return response.json();
    },
    enabled: step === 'assign',
    onError: (error: Error) => {
      toast({
        title: 'خطا',
        description: error.message || 'خطا در دریافت قضایا',
        variant: 'destructive',
      });
    },
  });

  // Filter cases client-side to match eligible criteria:
  // - Status must be "جدید" (NEW) or "در انتظار بررسی" (COMMITTEE_ASSIGNED_STATUS)
  // - NOT assigned to any audit group (no receivingGroup, currentAuditGroupId, or currentAssignmentId)
  const eligibleCases: EligibleCase[] = allCases
    .filter(case_ => {
      const status = case_.status as string;
      // Check status: must be "جدید" or "در انتظار بررسی"
      const hasEligibleStatus = status === 'جدید' || status === 'در انتظار بررسی';
      if (!hasEligibleStatus) return false;
      
      // Check if already assigned to audit group
      const isAssignedToGroup = !!(case_.receivingGroup || case_.currentAuditGroupId || case_.currentAssignmentId);
      if (isAssignedToGroup) return false;
      
      return true;
    })
    .map(case_ => ({
      ...case_,
      isEligible: true,
      entityName: case_.companyName || 'نامشخص',
    }));

  // Fetch groups
  const { data: groups = [], error: groupsError } = useQuery<Group[]>({
    queryKey: ['groups'],
    queryFn: async () => {
      const response = await fetch('/api/groups', {
        credentials: 'include',
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'خطا در دریافت گروه‌ها');
      }
      return response.json();
    },
    enabled: step === 'assign',
    onError: (error: Error) => {
      toast({
        title: 'خطا',
        description: error.message || 'خطا در دریافت گروه‌ها',
        variant: 'destructive',
      });
    },
  });

  // Create committee mutation
  const createMutation = useMutation({
    mutationFn: async (data: { title: string; year: number; month: number }) => {
      const response = await fetch('/api/committees-new', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(data),
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'خطا در ایجاد کمیته');
      }
      return response.json();
    },
    onSuccess: (committee) => {
      queryClient.invalidateQueries({ queryKey: ['committees-new'] });
      // Store committee ID for assignment
      setCreatedCommitteeId(committee.id);
      setStep('assign');
      // Force refetch of cases when step changes
      queryClient.invalidateQueries({ queryKey: ['cases'] });
      toast({
        title: 'موفق',
        description: 'کمیته با موفقیت ایجاد شد. حالا می‌توانید قضایا را اختصاص دهید.',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'خطا',
        description: error.message,
        variant: 'destructive',
      });
    },
  });

  // Assign cases mutation
  const assignMutation = useMutation({
    mutationFn: async (data: { committeeId: string; caseIds: string[]; auditGroupId: string }) => {
      // Validate and prepare payload
      if (!data.caseIds || !Array.isArray(data.caseIds) || data.caseIds.length === 0) {
        throw new Error('لیست قضایا الزامی است');
      }
      if (!data.auditGroupId || typeof data.auditGroupId !== 'string') {
        throw new Error('گروه بررسی الزامی است');
      }
      if (!data.committeeId || typeof data.committeeId !== 'string') {
        throw new Error('شناسه کمیته الزامی است');
      }
      
      // Ensure all caseIds are strings (database IDs)
      const validCaseIds = data.caseIds
        .map(id => String(id).trim())
        .filter(id => id.length > 0);
      
      if (validCaseIds.length === 0) {
        throw new Error('شناسه‌های قضایای انتخاب شده نامعتبر است');
      }
      
      // Prepare payload exactly as backend expects
      const payload = {
        caseIds: validCaseIds,
        auditGroupId: String(data.auditGroupId).trim(),
      };
      
      const response = await fetch(`/api/committees-new/${data.committeeId}/assign-cases`, {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify(payload),
      });
      
      // Parse response body regardless of status code
      const responseData = await response.json();
      
      // If response is not ok, check if there are partial successes
      if (!response.ok) {
        // Backend may return 400 with assignments array showing partial failures
        if (responseData.assignments && Array.isArray(responseData.assignments)) {
          const successfulAssignments = responseData.assignments.filter((a: any) => a.success) || [];
          const failedAssignments = responseData.assignments.filter((a: any) => !a.success) || [];
          
          // If there are any successful assignments, return the data for onSuccess handler
          if (successfulAssignments.length > 0) {
            return {
              ...responseData,
              hasPartialSuccess: true,
            };
          }
        }
        
        // All assignments failed, throw error with backend message
        throw new Error(responseData.message || 'Failed to assign cases');
      }
      
      return responseData;
    },
    onSuccess: (data) => {
      // CRITICAL: Only update UI state after successful backend response
      // Check for partial failures
      const failedAssignments = data.assignments?.filter((a: any) => !a.success) || [];
      const successfulAssignments = data.assignments?.filter((a: any) => a.success) || [];
      
      if (failedAssignments.length > 0) {
        toast({
          title: 'اخطار',
          description: `${successfulAssignments.length} قضیه با موفقیت اختصاص داده شد، اما ${failedAssignments.length} قضیه با خطا مواجه شد`,
          variant: 'destructive',
        });
      } else {
        toast({
          title: 'موفق',
          description: `${successfulAssignments.length} قضیه با موفقیت اختصاص داده شدند`,
        });
      }
      
      // Refetch data to get updated case states
      queryClient.invalidateQueries({ queryKey: ['committees-new'] });
      queryClient.invalidateQueries({ queryKey: ['cases'] });
      queryClient.invalidateQueries({ queryKey: ['eligible-cases'] });
      
      // Navigate only if all assignments succeeded
      if (failedAssignments.length === 0) {
        setLocation('/committees-new');
      }
    },
    onError: (error: Error) => {
      // CRITICAL: Show backend error message
      toast({
        title: 'خطا',
        description: error.message || 'خطا در اختصاص قضایا',
        variant: 'destructive',
      });
    },
  });

  const handleCreate = () => {
    if (!title.trim()) {
      toast({
        title: 'خطا',
        description: 'عنوان کمیته الزامی است',
        variant: 'destructive',
      });
      return;
    }
    createMutation.mutate({ title, year, month });
  };

  const handleAssign = () => {
    if (selectedCases.size === 0) {
      toast({
        title: 'خطا',
        description: 'لطفاً حداقل یک قضیه را انتخاب کنید',
        variant: 'destructive',
      });
      return;
    }
    if (!selectedGroup) {
      toast({
        title: 'خطا',
        description: 'لطفاً یک گروه بررسی را انتخاب کنید',
        variant: 'destructive',
      });
      return;
    }
    const committeeId = createdCommitteeId || createMutation.data?.id;
    if (!committeeId) {
      toast({
        title: 'خطا',
        description: 'کمیته یافت نشد',
        variant: 'destructive',
      });
      return;
    }
    
    // Prepare payload - ensure caseIds are strings (database IDs)
    const caseIdsArray = Array.from(selectedCases)
      .map(id => String(id).trim())
      .filter(id => id && id.length > 0);
    
    if (caseIdsArray.length === 0) {
      toast({
        title: 'خطا',
        description: 'شناسه‌های قضایای انتخاب شده نامعتبر است',
        variant: 'destructive',
      });
      return;
    }
    
    assignMutation.mutate({
      committeeId: String(committeeId).trim(),
      caseIds: caseIdsArray,
      auditGroupId: String(selectedGroup).trim(),
    });
  };

  const toggleCaseSelection = (caseId: string) => {
    const newSelected = new Set(selectedCases);
    if (newSelected.has(caseId)) {
      newSelected.delete(caseId);
    } else {
      newSelected.add(caseId);
    }
    setSelectedCases(newSelected);
  };

  if (step === 'create') {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-3xl font-bold">ایجاد کمیته جدید</h1>
          <Button variant="ghost" onClick={() => setLocation('/committees-new')}>
            <X className="ml-2 h-4 w-4" />
            انصراف
          </Button>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>اطلاعات کمیته</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="title">عنوان کمیته</Label>
              <Input
                id="title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="مثال: کمیته بررسی قضایای حمل 1403"
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="year">سال</Label>
                <Input
                  id="year"
                  type="number"
                  value={year}
                  onChange={(e) => setYear(parseInt(e.target.value) || year)}
                  min={1300}
                  max={1500}
                />
              </div>
              <div>
                <Label htmlFor="month">ماه</Label>
                <Select value={month.toString()} onValueChange={(v) => setMonth(parseInt(v))}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {monthNames.map((name, index) => (
                      <SelectItem key={index + 1} value={(index + 1).toString()}>
                        {name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="flex justify-end gap-2">
              <Button
                onClick={handleCreate}
                disabled={createMutation.isPending}
              >
                {createMutation.isPending ? (
                  <>
                    <Loader2 className="ml-2 h-4 w-4 animate-spin" />
                    در حال ایجاد...
                  </>
                ) : (
                  <>
                    ایجاد کمیته
                    <ArrowRight className="mr-2 h-4 w-4" />
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">اختصاص قضایا به کمیته</h1>
          {title && (
            <p className="text-sm text-muted-foreground mt-1">
              کمیته "{title}" برای {monthNames[month - 1]} {year}
            </p>
          )}
        </div>
        <Button variant="ghost" onClick={() => setLocation('/committees-new')}>
          <X className="ml-2 h-4 w-4" />
          انصراف
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>انتخاب گروه بررسی</CardTitle>
        </CardHeader>
        <CardContent>
          <Select value={selectedGroup} onValueChange={setSelectedGroup}>
            <SelectTrigger>
              <SelectValue placeholder="گروه بررسی را انتخاب کنید" />
            </SelectTrigger>
            <SelectContent>
              {groups.map((group) => (
                <SelectItem key={group.id} value={group.id}>
                  {group.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>
            قضایای واجد شرایط ({selectedCases.size} انتخاب شده)
          </CardTitle>
        </CardHeader>
        <CardContent>
          {casesLoading ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="h-6 w-6 animate-spin" />
              <span className="mr-2">در حال بارگذاری قضایا...</span>
            </div>
          ) : casesError ? (
            <div className="text-center py-8">
              <p className="text-destructive mb-2">خطا در بارگذاری قضایا</p>
              <p className="text-sm text-muted-foreground">
                {(casesError as Error).message || 'لطفاً دوباره تلاش کنید'}
              </p>
            </div>
          ) : eligibleCases.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-muted-foreground mb-2">هیچ قضیه واجد شرایطی یافت نشد</p>
              <p className="text-sm text-muted-foreground">
                قضایای واجد شرایط باید دارای وضعیت "جدید" یا "در انتظار بررسی" باشند و در حال بررسی فعال نباشند.
              </p>
            </div>
          ) : (
            <>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-12"></TableHead>
                    <TableHead>شماره قضیه</TableHead>
                    <TableHead>نام نهاد</TableHead>
                    <TableHead>وضعیت</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {eligibleCases.map((caseItem) => (
                    <TableRow key={caseItem.id}>
                      <TableCell>
                        <Checkbox
                          checked={selectedCases.has(caseItem.id)}
                          onCheckedChange={() => toggleCaseSelection(caseItem.id)}
                        />
                      </TableCell>
                      <TableCell>{caseItem.caseNumber || caseItem.caseId}</TableCell>
                      <TableCell>{caseItem.entityName || 'نامشخص'}</TableCell>
                      <TableCell>{caseItem.status}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
              <div className="flex justify-end gap-2 mt-4">
                <Button
                  onClick={handleAssign}
                  disabled={assignMutation.isPending || selectedCases.size === 0 || !selectedGroup}
                >
                  {assignMutation.isPending ? (
                    <>
                      <Loader2 className="ml-2 h-4 w-4 animate-spin" />
                      در حال اختصاص...
                    </>
                  ) : (
                    <>
                      اختصاص قضایای انتخاب شده
                      <ArrowRight className="mr-2 h-4 w-4" />
                    </>
                  )}
                </Button>
              </div>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

