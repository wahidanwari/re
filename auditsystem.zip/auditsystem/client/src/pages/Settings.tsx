import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Separator } from '@/components/ui/separator';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogTrigger,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Plus, Edit, Trash2 } from 'lucide-react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';
import { userHasPermission } from '@/utils/permissions';
import { useLocation } from 'wouter';
import { useTheme } from 'next-themes';
import { useLocale } from '@/contexts/LocaleContext';
import type { EntityType } from '@shared/schema';

interface UserPreferences {
  preferredLanguage: 'dari' | 'pashto' | 'english';
  preferredTheme?: 'light' | 'dark' | 'system';
  dateFormat?: 'shamsi' | 'gregorian';
}

export default function Settings() {
  const [preferredLanguage, setPreferredLanguage] = useState<'dari' | 'pashto' | 'english'>('dari');
  const [preferredTheme, setPreferredTheme] = useState<'light' | 'dark' | 'system'>('light');
  const [dateFormat, setDateFormat] = useState<'shamsi' | 'gregorian'>('shamsi');
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { user, loading: authLoading } = useAuth();
  const [, setLocation] = useLocation();
  const { theme: currentTheme, setTheme } = useTheme();
  const { locale: currentLocale, setLocale } = useLocale();
  
  // Settings page is accessible to all authenticated users
  // System settings (entity types, etc.) require settings:manage permission
  // Profile settings (language, theme, etc.) are available to all users

  const { data: preferences, isLoading: preferencesLoading } = useQuery<UserPreferences>({
    queryKey: ['userPreferences'],
    queryFn: async () => {
      const response = await fetch('/api/settings/preferences', { credentials: 'include' });
      if (!response.ok) {
        // Return defaults if endpoint doesn't exist yet
        return { preferredLanguage: 'dari', preferredTheme: 'light', dateFormat: 'shamsi' };
      }
      return response.json();
    },
  });

  useEffect(() => {
    if (preferences) {
      setPreferredLanguage(preferences.preferredLanguage || 'dari');
      setPreferredTheme(preferences.preferredTheme || 'light');
      setDateFormat(preferences.dateFormat || 'shamsi');
      // Apply theme if available
      if (preferences.preferredTheme && setTheme) {
        setTheme(preferences.preferredTheme);
      }
      // Apply locale if available
      if (preferences.preferredLanguage && setLocale) {
        setLocale(preferences.preferredLanguage as 'dari' | 'pashto' | 'english');
      }
    }
  }, [preferences, setTheme, setLocale]);

  const updatePreferencesMutation = useMutation({
    mutationFn: async (prefs: UserPreferences) => {
      const response = await fetch('/api/settings/preferences', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(prefs),
        credentials: 'include',
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to update preferences');
      }
      return response.json();
    },
    onSuccess: (data) => {
      queryClient.setQueryData(['userPreferences'], data);
      // Apply theme and locale immediately
      if (data.preferredTheme && setTheme) {
        setTheme(data.preferredTheme);
      }
      if (data.preferredLanguage && setLocale) {
        setLocale(data.preferredLanguage as 'dari' | 'pashto' | 'english');
      }
      // User preferences updated
      toast({
        title: 'موفق',
        description: 'تنظیمات با موفقیت بروز رسانی شد',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'خطا',
        description: error.message || 'بروز رسانی تنظیمات با مشکل مواجه شد',
        variant: 'destructive',
      });
    },
  });

  const changePasswordMutation = useMutation({
    mutationFn: async ({ currentPassword, newPassword }: { currentPassword: string; newPassword: string }) => {
      const response = await fetch('/api/auth/change-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ currentPassword, newPassword }),
        credentials: 'include',
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to change password');
      }
      return response.json();
    },
    onSuccess: () => {
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
      toast({
        title: 'موفق',
        description: 'رمز عبور با موفقیت تغییر یافت',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'خطا',
        description: error.message || 'تغییر رمز عبور با مشکل مواجه شد',
        variant: 'destructive',
      });
    },
  });

  // Language switch is now handled by Select component

  const handleChangePassword = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!currentPassword || !newPassword || !confirmPassword) {
      toast({
        title: 'خطا',
        description: 'لطفا همه فیلدها را پر کنید',
        variant: 'destructive',
      });
      return;
    }

    if (newPassword.length < 8) {
      toast({
        title: 'خطا',
        description: 'رمز عبور جدید باید حداقل ۸ کاراکتر باشد',
        variant: 'destructive',
      });
      return;
    }

    if (newPassword !== confirmPassword) {
      toast({
        title: 'خطا',
        description: 'رمز عبور جدید و تایید آن مطابقت ندارند',
        variant: 'destructive',
      });
      return;
    }

    changePasswordMutation.mutate({ currentPassword, newPassword });
  };

  if (preferencesLoading) {
    return <div className="p-8"><div className="text-center">در حال بارگذاری...</div></div>;
  }

  return (
    <div className="p-8 space-y-6">
      <div>
        <h1 className="text-3xl font-semibold">تنظیمات</h1>
        <p className="text-muted-foreground">تنظیمات سیستم و تنظیمات شخصی</p>
      </div>

      <div className="grid gap-6">
        <Card>
          <CardHeader>
            <CardTitle>تغییر رمز عبور</CardTitle>
            <CardDescription>تغییر رمز عبور حساب کاربری</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <form onSubmit={handleChangePassword} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="current-password">رمز عبور فعلی</Label>
                <Input
                  id="current-password"
                  type="password"
                  value={currentPassword}
                  onChange={(e) => setCurrentPassword(e.target.value)}
                  data-testid="input-current-password"
                  className="text-right"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="new-password">رمز عبور جدید</Label>
                <Input
                  id="new-password"
                  type="password"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  data-testid="input-new-password"
                  className="text-right"
                  required
                  minLength={8}
                />
                <p className="text-xs text-muted-foreground">حداقل ۸ کاراکتر</p>
              </div>
              <div className="space-y-2">
                <Label htmlFor="confirm-password">تایید رمز عبور جدید</Label>
                <Input
                  id="confirm-password"
                  type="password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  data-testid="input-confirm-password"
                  className="text-right"
                  required
                  minLength={8}
                />
              </div>
              <Button
                type="submit"
                disabled={changePasswordMutation.isPending}
                data-testid="button-change-password"
              >
                {changePasswordMutation.isPending ? 'در حال تغییر...' : 'تغییر رمز عبور'}
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* Profile Settings - Available to all users */}
        <Card>
          <CardHeader>
            <CardTitle>تنظیمات پروفایل</CardTitle>
            <CardDescription>تنظیمات شخصی و رابط کاربری</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Language Settings */}
            <div className="space-y-2">
              <Label>زبان رابط کاربری</Label>
              <Select
                value={preferredLanguage}
                onValueChange={(value: 'dari' | 'pashto' | 'english') => {
                  setPreferredLanguage(value);
                  setLocale(value);
                  updatePreferencesMutation.mutate({
                    preferredLanguage: value,
                    preferredTheme: preferredTheme,
                    dateFormat: dateFormat,
                  });
                }}
              >
                <SelectTrigger className="w-full">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="dari">دری (Dari)</SelectItem>
                  <SelectItem value="pashto">پشتو (Pashto)</SelectItem>
                  <SelectItem value="english">انگلیسی (English)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Theme Settings */}
            <div className="space-y-2">
              <Label>تم (Theme)</Label>
              <Select
                value={preferredTheme}
                onValueChange={(value: 'light' | 'dark' | 'system') => {
                  setPreferredTheme(value);
                  setTheme(value);
                  updatePreferencesMutation.mutate({
                    preferredLanguage: preferredLanguage,
                    preferredTheme: value,
                    dateFormat: dateFormat,
                  });
                }}
              >
                <SelectTrigger className="w-full">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="light">روشن (Light)</SelectItem>
                  <SelectItem value="dark">تاریک (Dark)</SelectItem>
                  <SelectItem value="system">سیستم (System)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Date Format Settings */}
            <div className="space-y-2">
              <Label>فرمت تاریخ</Label>
              <Select
                value={dateFormat}
                onValueChange={(value: 'shamsi' | 'gregorian') => {
                  setDateFormat(value);
                  updatePreferencesMutation.mutate({
                    preferredLanguage: preferredLanguage,
                    preferredTheme: preferredTheme,
                    dateFormat: value,
                  });
                }}
              >
                <SelectTrigger className="w-full">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="shamsi">شمسی (Shamsi/Jalali)</SelectItem>
                  <SelectItem value="gregorian">میلادی (Gregorian)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* PHASE 2: Entity Types Management */}
        <Card>
          <CardHeader>
            <CardTitle>مدیریت انواع نهادها</CardTitle>
            <CardDescription>افزودن، ویرایش و حذف انواع نهادها (ماهیت تشبث)</CardDescription>
          </CardHeader>
          <CardContent>
            <EntityTypesManager />
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

// Entity Types Management Component (PHASE 2)
function EntityTypesManager() {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [selectedType, setSelectedType] = useState<EntityType | null>(null);
  const [formData, setFormData] = useState({ name: '', status: 'active' });
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { user } = useAuth();

  const { data: entityTypes = [], isLoading } = useQuery<EntityType[]>({
    queryKey: ['entity-types'],
    queryFn: async () => {
      const response = await fetch('/api/entity-types', { credentials: 'include' });
      if (!response.ok) throw new Error('Failed to fetch entity types');
      return response.json();
    },
  });

  const createMutation = useMutation({
    mutationFn: async (data: { name: string; status: string }) => {
      const response = await fetch('/api/entity-types', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
        credentials: 'include',
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to create entity type');
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['entity-types'] });
      queryClient.invalidateQueries({ queryKey: ['entity-types', 'active'] });
      setDialogOpen(false);
      setFormData({ name: '', status: 'active' });
      toast({
        title: 'موفق',
        description: 'نوع نهاد جدید با موفقیت ایجاد شد',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'خطا',
        description: error.message || 'ایجاد نوع نهاد با مشکل مواجه شد',
        variant: 'destructive',
      });
    },
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: { name: string; status: string } }) => {
      const response = await fetch(`/api/entity-types/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
        credentials: 'include',
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to update entity type');
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['entity-types'] });
      queryClient.invalidateQueries({ queryKey: ['entity-types', 'active'] });
      setEditDialogOpen(false);
      setSelectedType(null);
      setFormData({ name: '', status: 'active' });
      toast({
        title: 'موفق',
        description: 'نوع نهاد با موفقیت بروز رسانی شد',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'خطا',
        description: error.message || 'بروز رسانی نوع نهاد با مشکل مواجه شد',
        variant: 'destructive',
      });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const response = await fetch(`/api/entity-types/${id}`, {
        method: 'DELETE',
        credentials: 'include',
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to delete entity type');
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['entity-types'] });
      queryClient.invalidateQueries({ queryKey: ['entity-types', 'active'] });
      setDeleteDialogOpen(false);
      setSelectedType(null);
      toast({
        title: 'موفق',
        description: 'نوع نهاد با موفقیت حذف شد',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'خطا',
        description: error.message || 'حذف نوع نهاد با مشکل مواجه شد',
        variant: 'destructive',
      });
    },
  });

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim()) {
      toast({
        title: 'خطا',
        description: 'نام نوع نهاد الزامی است',
        variant: 'destructive',
      });
      return;
    }
    createMutation.mutate(formData);
  };

  const handleEdit = (type: EntityType) => {
    setSelectedType(type);
    setFormData({ name: type.name, status: type.status });
    setEditDialogOpen(true);
  };

  const handleUpdate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedType || !formData.name.trim()) {
      toast({
        title: 'خطا',
        description: 'نام نوع نهاد الزامی است',
        variant: 'destructive',
      });
      return;
    }
    updateMutation.mutate({ id: selectedType.id, data: formData });
  };

  const handleDelete = () => {
    if (!selectedType) return;
    deleteMutation.mutate(selectedType.id);
  };

  if (isLoading) {
    return <div className="text-center py-4 text-muted-foreground">در حال بارگذاری...</div>;
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-end">
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="ml-2 h-4 w-4" />
              افزودن نوع جدید
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>افزودن نوع نهاد جدید</DialogTitle>
              <DialogDescription>نام نوع نهاد جدید را وارد کنید</DialogDescription>
            </DialogHeader>
            <form onSubmit={handleCreate} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="type-name">نام نوع نهاد *</Label>
                <Input
                  id="type-name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="text-right"
                  required
                />
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                  لغو
                </Button>
                <Button type="submit" disabled={createMutation.isPending}>
                  {createMutation.isPending ? 'در حال ایجاد...' : 'ایجاد'}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="text-right">نام</TableHead>
            <TableHead className="text-right">وضعیت</TableHead>
            <TableHead className="text-right">عملیات</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {entityTypes.length === 0 ? (
            <TableRow>
              <TableCell colSpan={3} className="text-center text-muted-foreground">
                هیچ نوع نهادی ثبت نشده است
              </TableCell>
            </TableRow>
          ) : (
            entityTypes.map((type) => (
              <TableRow key={type.id}>
                <TableCell className="font-medium">{type.name}</TableCell>
                <TableCell>
                  <span className={`px-2 py-1 rounded text-xs ${
                    type.status === 'active' 
                      ? 'bg-green-100 text-green-800' 
                      : 'bg-gray-100 text-gray-800'
                  }`}>
                    {type.status === 'active' ? 'فعال' : 'غیرفعال'}
                  </span>
                </TableCell>
                <TableCell>
                  <div className="flex gap-2">
                    <Button
                      size="icon"
                      variant="ghost"
                      onClick={() => handleEdit(type)}
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button
                      size="icon"
                      variant="ghost"
                      onClick={() => {
                        setSelectedType(type);
                        setDeleteDialogOpen(true);
                      }}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))
          )}
        </TableBody>
      </Table>

      {/* Edit Dialog */}
      <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>ویرایش نوع نهاد</DialogTitle>
            <DialogDescription>اطلاعات نوع نهاد را ویرایش کنید</DialogDescription>
          </DialogHeader>
          <form onSubmit={handleUpdate} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="edit-type-name">نام نوع نهاد *</Label>
              <Input
                id="edit-type-name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="text-right"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-type-status">وضعیت</Label>
              <Select
                value={formData.status}
                onValueChange={(v) => setFormData({ ...formData, status: v })}
              >
                <SelectTrigger id="edit-type-status">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="active">فعال</SelectItem>
                  <SelectItem value="inactive">غیرفعال</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setEditDialogOpen(false)}>
                لغو
              </Button>
              <Button type="submit" disabled={updateMutation.isPending}>
                {updateMutation.isPending ? 'در حال بروز رسانی...' : 'بروز رسانی'}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>حذف نوع نهاد</DialogTitle>
            <DialogDescription>
              آیا مطمئن هستید که می‌خواهید نوع نهاد "{selectedType?.name}" را حذف کنید؟
              این عمل قابل بازگشت نیست.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setDeleteDialogOpen(false)}>
              لغو
            </Button>
            <Button
              type="button"
              variant="destructive"
              onClick={handleDelete}
              disabled={deleteMutation.isPending}
            >
              {deleteMutation.isPending ? 'در حال حذف...' : 'حذف'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
