import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Plus, Target, CheckCircle2, XCircle, AlertCircle, TrendingUp, Pencil } from 'lucide-react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';
import { userHasPermission } from '@/utils/permissions';
import { useLocation } from 'wouter';
import { Badge } from '@/components/ui/badge';
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import jalaali from 'jalaali-js';

interface GroupTarget {
  id: string;
  groupId: string;
  yearShamsi: string;
  targetCaseCount: number | null;
  targetMonetary: string | null;
  setBy: string;
  setAt: string;
}

interface Group {
  id: string;
  name: string;
  code: string;
  isActive: boolean;
}

interface TargetAchievement {
  groupId: string;
  groupName: string;
  yearShamsi: number;
  hasTarget: boolean;
  target: {
    targetCaseCount: number | null;
    targetMonetary: string | null;
  } | null;
  achievement: {
    target: number;
    achieved: number;
    percentComplete: number;
    status: 'achieved' | 'almost' | 'not_achieved';
    exceeded: boolean;
  } | null;
  monthlyBreakdown: Array<{
    monthShamsi: number;
    target: number;
    achieved: number;
    percentComplete: number;
    status: 'achieved' | 'almost' | 'not_achieved';
  }>;
}

interface TargetsSummary {
  yearShamsi: number;
  summary: Array<{
    groupId: string;
    groupName: string;
    groupCode: string;
    hasTarget: boolean;
    target: number | null;
    achieved: number | null;
    percentComplete: number;
    status: 'achieved' | 'almost' | 'not_achieved' | 'no_target';
    exceeded: boolean;
  }>;
  totals: {
    totalTargets: number;
    totalAchieved: number;
    totalPercent: number;
    targetsAchieved: number;
    targetsNotAchieved: number;
    totalGroups: number;
  };
}

export default function TargetSettings() {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [departmentDialogOpen, setDepartmentDialogOpen] = useState(false);
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [selectedGroupId, setSelectedGroupId] = useState('');
  const [editingTarget, setEditingTarget] = useState<GroupTarget | null>(null);
  const [formData, setFormData] = useState({
    yearShamsi: '',
    targetCaseCount: '',
    targetMonetary: '',
  });
  const [editFormData, setEditFormData] = useState({
    targetCaseCount: '',
    targetMonetary: '',
  });
  const [departmentFormData, setDepartmentFormData] = useState({
    yearShamsi: '',
    targetCaseCount: '',
    targetMonetary: '',
  });
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { user: currentUser, loading: authLoading } = useAuth();
  const [, setLocation] = useLocation();

  // Check if user has permission (System Admin or Director)
  const hasPermission = currentUser && (
    currentUser.role === 'system_admin' || 
    userHasPermission(currentUser, 'groups:set_targets')
  );

  if (!authLoading && currentUser && !hasPermission) {
    return (
      <div className="p-8">
        <div className="text-center">
          <h2 className="text-2xl font-semibold mb-4">عدم دسترسی</h2>
          <p className="text-muted-foreground mb-4">شما مجوز دسترسی به این صفحه را ندارید.</p>
          <button
            onClick={() => setLocation('/')}
            className="text-blue-600 hover:underline"
          >
            بازگشت به داشبورد
          </button>
        </div>
      </div>
    );
  }

  const { data: groups = [], isLoading: groupsLoading } = useQuery<Group[]>({
    queryKey: ['groups'],
    queryFn: async () => {
      const response = await fetch('/api/groups', { credentials: 'include' });
      if (!response.ok) throw new Error('Failed to fetch groups');
      return response.json();
    },
    enabled: !authLoading && !!currentUser && hasPermission,
  });

  // Fetch targets summary
  const { data: targetsSummary, isLoading: summaryLoading } = useQuery<TargetsSummary>({
    queryKey: ['targetsSummary'],
    queryFn: async () => {
      const response = await fetch('/api/groups/targets/summary', { credentials: 'include' });
      if (!response.ok) throw new Error('Failed to fetch targets summary');
      return response.json();
    },
    enabled: !authLoading && !!currentUser && hasPermission,
  });

  // Fetch targets for all groups
  const { data: allTargets = [], isLoading: targetsLoading } = useQuery<GroupTarget[]>({
    queryKey: ['groupTargets', 'all'],
    queryFn: async () => {
      // Fetch targets for all groups
      const targetsPromises = groups.map(async (group) => {
        try {
          const response = await fetch(`/api/groups/${group.id}/targets`, { 
            credentials: 'include' 
          });
          if (response.ok) {
            const groupTargets = await response.json();
            return Array.isArray(groupTargets) ? groupTargets.map((t: GroupTarget) => ({
              ...t,
              groupId: group.id,
            })) : [];
          }
          return [];
        } catch (error) {
          console.error(`Failed to fetch targets for group ${group.id}:`, error);
          return [];
        }
      });
      
      const allTargetsArrays = await Promise.all(targetsPromises);
      return allTargetsArrays.flat();
    },
    enabled: !authLoading && !!currentUser && hasPermission && groups.length > 0,
  });

  const createTargetMutation = useMutation({
    mutationFn: async (data: { groupId: string; yearShamsi: string; targetCaseCount?: number; targetMonetary?: string }) => {
      const response = await fetch(`/api/groups/${data.groupId}/targets`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          yearShamsi: data.yearShamsi,
          targetCaseCount: data.targetCaseCount ? parseInt(data.targetCaseCount.toString()) : null,
          targetMonetary: data.targetMonetary || null,
        }),
        credentials: 'include',
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to set target');
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['groupTargets'] });
      queryClient.invalidateQueries({ queryKey: ['groups'] });
      setDialogOpen(false);
      setFormData({ yearShamsi: '', targetCaseCount: '', targetMonetary: '' });
      setSelectedGroupId('');
      toast({
        title: 'موفق',
        description: 'هدف با موفقیت تعیین شد',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'خطا',
        description: error.message || 'تعیین هدف با مشکل مواجه شد',
        variant: 'destructive',
      });
    },
  });

  const updateTargetMutation = useMutation({
    mutationFn: async (data: { groupId: string; targetId: string; targetCaseCount?: number; targetMonetary?: string }) => {
      const response = await fetch(`/api/groups/${data.groupId}/targets/${data.targetId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          targetCaseCount: data.targetCaseCount ? parseInt(data.targetCaseCount.toString()) : null,
          targetMonetary: data.targetMonetary || null,
        }),
        credentials: 'include',
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to update target');
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['groupTargets'] });
      queryClient.invalidateQueries({ queryKey: ['targetsSummary'] });
      queryClient.invalidateQueries({ queryKey: ['targetAchievement'] });
      setEditDialogOpen(false);
      setEditingTarget(null);
      setEditFormData({ targetCaseCount: '', targetMonetary: '' });
      toast({
        title: 'موفق',
        description: 'هدف با موفقیت بروز رسانی شد',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'خطا',
        description: error.message || 'بروز رسانی هدف با مشکل مواجه شد',
        variant: 'destructive',
      });
    },
  });

  const createDepartmentTargetMutation = useMutation({
    mutationFn: async (data: { yearShamsi: string; targetCaseCount?: number; targetMonetary?: string }) => {
      const response = await fetch('/api/groups/targets/department', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          yearShamsi: data.yearShamsi,
          targetCaseCount: data.targetCaseCount ? parseInt(data.targetCaseCount.toString()) : null,
          targetMonetary: data.targetMonetary || null,
        }),
        credentials: 'include',
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to set department targets');
      }
      return response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['groupTargets'] });
      queryClient.invalidateQueries({ queryKey: ['groups'] });
      setDepartmentDialogOpen(false);
      setDepartmentFormData({ yearShamsi: '', targetCaseCount: '', targetMonetary: '' });
      toast({
        title: 'موفق',
        description: data.message || `اهداف برای ${data.targetsCreated || 0} گروه با موفقیت تعیین شد`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'خطا',
        description: error.message || 'تعیین اهداف بخش با مشکل مواجه شد',
        variant: 'destructive',
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedGroupId) {
      toast({
        title: 'خطا',
        description: 'لطفا یک گروه انتخاب کنید',
        variant: 'destructive',
      });
      return;
    }
    
    if (!formData.yearShamsi) {
      toast({
        title: 'خطا',
        description: 'سال شمسی الزامی است',
        variant: 'destructive',
      });
      return;
    }

    createTargetMutation.mutate({
      groupId: selectedGroupId,
      yearShamsi: formData.yearShamsi,
      targetCaseCount: formData.targetCaseCount ? parseInt(formData.targetCaseCount) : undefined,
      targetMonetary: formData.targetMonetary || undefined,
    });
  };

  const handleDepartmentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!departmentFormData.yearShamsi) {
      toast({
        title: 'خطا',
        description: 'سال شمسی الزامی است',
        variant: 'destructive',
      });
      return;
    }

    createDepartmentTargetMutation.mutate({
      yearShamsi: departmentFormData.yearShamsi,
      targetCaseCount: departmentFormData.targetCaseCount ? parseInt(departmentFormData.targetCaseCount) : undefined,
      targetMonetary: departmentFormData.targetMonetary || undefined,
    });
  };

  const handleEdit = (target: GroupTarget) => {
    setEditingTarget(target);
    setEditFormData({
      targetCaseCount: target.targetCaseCount?.toString() || '',
      targetMonetary: target.targetMonetary || '',
    });
    setEditDialogOpen(true);
  };

  const handleEditSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!editingTarget) {
      return;
    }

    updateTargetMutation.mutate({
      groupId: editingTarget.groupId,
      targetId: editingTarget.id,
      targetCaseCount: editFormData.targetCaseCount ? parseInt(editFormData.targetCaseCount) : undefined,
      targetMonetary: editFormData.targetMonetary || undefined,
    });
  };

  // Group targets by group
  const targetsByGroup = groups.reduce((acc, group) => {
    acc[group.id] = allTargets.filter(t => t.groupId === group.id);
    return acc;
  }, {} as Record<string, GroupTarget[]>);

  // Component for group target card with achievement
  function GroupTargetCard({ 
    group, 
    targets, 
    summary 
  }: { 
    group: Group; 
    targets: GroupTarget[]; 
    summary?: TargetsSummary['summary'][0] 
  }) {
    const [showChart, setShowChart] = useState(false);
    const currentShamsi = jalaali.toJalaali(new Date());
    const currentYearShamsi = currentShamsi.jy;
    
    // Fetch achievement data
    const { data: achievement } = useQuery<TargetAchievement>({
      queryKey: ['targetAchievement', group.id, currentYearShamsi],
      queryFn: async () => {
        const response = await fetch(`/api/groups/${group.id}/targets/achievement?yearShamsi=${currentYearShamsi}`, { 
          credentials: 'include' 
        });
        if (!response.ok) throw new Error('Failed to fetch achievement');
        return response.json();
      },
      enabled: targets.length > 0,
    });

    return (
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Target className="h-5 w-5" />
              {group.name} {group.code ? `(${group.code})` : ''}
            </CardTitle>
            {achievement?.hasTarget && (
              <Badge 
                variant={
                  achievement.achievement?.status === 'achieved' ? 'default' :
                  achievement.achievement?.status === 'almost' ? 'secondary' :
                  'destructive'
                }
                className="flex items-center gap-1"
              >
                {achievement.achievement?.status === 'achieved' && <CheckCircle2 className="h-3 w-3" />}
                {achievement.achievement?.status === 'almost' && <AlertCircle className="h-3 w-3" />}
                {achievement.achievement?.status === 'not_achieved' && <XCircle className="h-3 w-3" />}
                {achievement.achievement?.percentComplete}%
              </Badge>
            )}
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Achievement Indicator */}
          {achievement?.hasTarget && achievement.achievement && (
            <div className="space-y-2 p-4 bg-gray-50 dark:bg-gray-900 rounded-lg">
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">پیشرفت هدف سال {achievement.yearShamsi}</span>
                <span className="font-medium">
                  {achievement.achievement.achieved} / {achievement.achievement.target}
                </span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-3">
                <div 
                  className={`h-3 rounded-full transition-all ${
                    achievement.achievement.status === 'achieved' ? 'bg-green-600' :
                    achievement.achievement.status === 'almost' ? 'bg-yellow-500' :
                    'bg-red-500'
                  }`}
                  style={{ width: `${Math.min(achievement.achievement.percentComplete, 100)}%` }}
                />
              </div>
              <div className="flex items-center gap-4 text-xs">
                {achievement.achievement.exceeded && (
                  <span className="text-green-600 flex items-center gap-1">
                    <TrendingUp className="h-3 w-3" />
                    بیش از هدف
                  </span>
                )}
                <span className={`${
                  achievement.achievement.status === 'achieved' ? 'text-green-600' :
                  achievement.achievement.status === 'almost' ? 'text-yellow-600' :
                  'text-red-600'
                }`}>
                  {achievement.achievement.status === 'achieved' ? '✓ تحقق یافته' :
                   achievement.achievement.status === 'almost' ? '≈ نزدیک به هدف' :
                   '✗ محقق نشده'}
                </span>
              </div>
              
              {/* Monthly Chart Toggle */}
              {achievement.monthlyBreakdown && achievement.monthlyBreakdown.length > 0 && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setShowChart(!showChart)}
                  className="w-full mt-2"
                >
                  {showChart ? 'پنهان کردن نمودار ماهانه' : 'نمایش نمودار ماهانه'}
                </Button>
              )}
            </div>
          )}

          {/* Monthly Breakdown Chart */}
          {showChart && achievement?.monthlyBreakdown && achievement.monthlyBreakdown.length > 0 && (
            <div className="mt-4">
              <h4 className="text-sm font-semibold mb-2">برنامه ماهانه</h4>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={achievement.monthlyBreakdown}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis 
                    dataKey="monthShamsi" 
                    tickFormatter={(value) => {
                      const months = ['حمل', 'ثور', 'جوزا', 'سرطان', 'اسد', 'سنبله', 'میزان', 'عقرب', 'قوس', 'جدی', 'دلو', 'حوت'];
                      return months[value - 1] || value;
                    }}
                  />
                  <YAxis />
                  <Tooltip 
                    formatter={(value: number) => value.toLocaleString('fa-IR')}
                    labelFormatter={(label) => {
                      const months = ['حمل', 'ثور', 'جوزا', 'سرطان', 'اسد', 'سنبله', 'میزان', 'عقرب', 'قوس', 'جدی', 'دلو', 'حوت'];
                      return months[parseInt(label) - 1] || label;
                    }}
                  />
                  <Legend />
                  <Bar dataKey="target" fill="#94a3b8" name="هدف" />
                  <Bar dataKey="achieved" fill="#10b981" name="تکمیل شده" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}

          {/* Targets Table */}
          {targets.length === 0 ? (
            <p className="text-sm text-muted-foreground text-right">
              هیچ هدفی برای این گروه تعیین نشده است
            </p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="text-right">سال شمسی</TableHead>
                  <TableHead className="text-right">تعداد قضایای هدف</TableHead>
                  <TableHead className="text-right">مبلغ هدف (افغانی)</TableHead>
                  <TableHead className="text-right">تاریخ تعیین</TableHead>
                  <TableHead className="text-right">عملیات</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {targets.map((target) => (
                  <TableRow key={target.id}>
                    <TableCell className="text-right">
                      <Badge variant="outline">{target.yearShamsi}</Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      {target.targetCaseCount ? target.targetCaseCount.toLocaleString('fa-IR') : '—'}
                    </TableCell>
                    <TableCell className="text-right">
                      {target.targetMonetary ? `${target.targetMonetary} افغانی` : '—'}
                    </TableCell>
                    <TableCell className="text-right">
                      {new Date(target.setAt).toLocaleDateString('fa-IR')}
                    </TableCell>
                    <TableCell className="text-right">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleEdit(target)}
                        className="h-8 w-8 p-0"
                      >
                        <Pencil className="h-4 w-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    );
  }

  // Component for group target card with achievement
  function GroupTargetCard({ 
    group, 
    targets, 
    summary 
  }: { 
    group: Group; 
    targets: GroupTarget[]; 
    summary?: TargetsSummary['summary'][0] 
  }) {
    const [showChart, setShowChart] = useState(false);
    const currentShamsi = jalaali.toJalaali(new Date());
    const currentYearShamsi = currentShamsi.jy;
    
    // Fetch achievement data
    const { data: achievement } = useQuery<TargetAchievement>({
      queryKey: ['targetAchievement', group.id, currentYearShamsi],
      queryFn: async () => {
        const response = await fetch(`/api/groups/${group.id}/targets/achievement?yearShamsi=${currentYearShamsi}`, { 
          credentials: 'include' 
        });
        if (!response.ok) throw new Error('Failed to fetch achievement');
        return response.json();
      },
      enabled: targets.length > 0,
    });

    return (
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Target className="h-5 w-5" />
              {group.name} {group.code ? `(${group.code})` : ''}
            </CardTitle>
            {achievement?.hasTarget && (
              <Badge 
                variant={
                  achievement.achievement?.status === 'achieved' ? 'default' :
                  achievement.achievement?.status === 'almost' ? 'secondary' :
                  'destructive'
                }
                className="flex items-center gap-1"
              >
                {achievement.achievement?.status === 'achieved' && <CheckCircle2 className="h-3 w-3" />}
                {achievement.achievement?.status === 'almost' && <AlertCircle className="h-3 w-3" />}
                {achievement.achievement?.status === 'not_achieved' && <XCircle className="h-3 w-3" />}
                {achievement.achievement?.percentComplete}%
              </Badge>
            )}
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Achievement Indicator */}
          {achievement?.hasTarget && achievement.achievement && (
            <div className="space-y-2 p-4 bg-gray-50 dark:bg-gray-900 rounded-lg">
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">پیشرفت هدف سال {achievement.yearShamsi}</span>
                <span className="font-medium">
                  {achievement.achievement.achieved} / {achievement.achievement.target}
                </span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-3">
                <div 
                  className={`h-3 rounded-full transition-all ${
                    achievement.achievement.status === 'achieved' ? 'bg-green-600' :
                    achievement.achievement.status === 'almost' ? 'bg-yellow-500' :
                    'bg-red-500'
                  }`}
                  style={{ width: `${Math.min(achievement.achievement.percentComplete, 100)}%` }}
                />
              </div>
              <div className="flex items-center gap-4 text-xs">
                {achievement.achievement.exceeded && (
                  <span className="text-green-600 flex items-center gap-1">
                    <TrendingUp className="h-3 w-3" />
                    بیش از هدف
                  </span>
                )}
                <span className={`${
                  achievement.achievement.status === 'achieved' ? 'text-green-600' :
                  achievement.achievement.status === 'almost' ? 'text-yellow-600' :
                  'text-red-600'
                }`}>
                  {achievement.achievement.status === 'achieved' ? '✓ تحقق یافته' :
                   achievement.achievement.status === 'almost' ? '≈ نزدیک به هدف' :
                   '✗ محقق نشده'}
                </span>
              </div>
              
              {/* Monthly Chart Toggle */}
              {achievement.monthlyBreakdown && achievement.monthlyBreakdown.length > 0 && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setShowChart(!showChart)}
                  className="w-full mt-2"
                >
                  {showChart ? 'پنهان کردن نمودار ماهانه' : 'نمایش نمودار ماهانه'}
                </Button>
              )}
            </div>
          )}

          {/* Monthly Breakdown Chart */}
          {showChart && achievement?.monthlyBreakdown && achievement.monthlyBreakdown.length > 0 && (
            <div className="mt-4">
              <h4 className="text-sm font-semibold mb-2">برنامه ماهانه</h4>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={achievement.monthlyBreakdown}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis 
                    dataKey="monthShamsi" 
                    tickFormatter={(value) => {
                      const months = ['حمل', 'ثور', 'جوزا', 'سرطان', 'اسد', 'سنبله', 'میزان', 'عقرب', 'قوس', 'جدی', 'دلو', 'حوت'];
                      return months[value - 1] || value;
                    }}
                  />
                  <YAxis />
                  <Tooltip 
                    formatter={(value: number) => value.toLocaleString('fa-IR')}
                    labelFormatter={(label) => {
                      const months = ['حمل', 'ثور', 'جوزا', 'سرطان', 'اسد', 'سنبله', 'میزان', 'عقرب', 'قوس', 'جدی', 'دلو', 'حوت'];
                      return months[parseInt(label) - 1] || label;
                    }}
                  />
                  <Legend />
                  <Bar dataKey="target" fill="#94a3b8" name="هدف" />
                  <Bar dataKey="achieved" fill="#10b981" name="تکمیل شده" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}

          {/* Targets Table */}
          {targets.length === 0 ? (
            <p className="text-sm text-muted-foreground text-right">
              هیچ هدفی برای این گروه تعیین نشده است
            </p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="text-right">سال شمسی</TableHead>
                  <TableHead className="text-right">تعداد قضایای هدف</TableHead>
                  <TableHead className="text-right">مبلغ هدف (افغانی)</TableHead>
                  <TableHead className="text-right">تاریخ تعیین</TableHead>
                  <TableHead className="text-right">عملیات</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {targets.map((target) => (
                  <TableRow key={target.id}>
                    <TableCell className="text-right">
                      <Badge variant="outline">{target.yearShamsi}</Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      {target.targetCaseCount ? target.targetCaseCount.toLocaleString('fa-IR') : '—'}
                    </TableCell>
                    <TableCell className="text-right">
                      {target.targetMonetary ? `${target.targetMonetary} افغانی` : '—'}
                    </TableCell>
                    <TableCell className="text-right">
                      {new Date(target.setAt).toLocaleDateString('fa-IR')}
                    </TableCell>
                    <TableCell className="text-right">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleEdit(target)}
                        className="h-8 w-8 p-0"
                      >
                        <Pencil className="h-4 w-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6" dir="rtl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-semibold">تنظیم اهداف گروه‌ها</h1>
          <p className="text-muted-foreground">تعیین اهداف سالانه برای گروه‌های بررسی</p>
        </div>
        <div className="flex gap-2">
          <Button onClick={() => setDepartmentDialogOpen(true)} variant="default">
            <Target className="ml-2 h-4 w-4" />
            تعیین هدف بخش (همه گروه‌ها)
          </Button>
          <Button onClick={() => setDialogOpen(true)} variant="outline">
            <Plus className="ml-2 h-4 w-4" />
            تعیین هدف برای گروه خاص
          </Button>
        </div>
      </div>

      {/* Targets Summary Dashboard */}
      {targetsSummary && !summaryLoading && (
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5" />
              خلاصه اهداف سال {targetsSummary.yearShamsi}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
              <div className="space-y-1">
                <div className="text-sm text-muted-foreground">کل اهداف</div>
                <div className="text-2xl font-bold">{targetsSummary.totals.totalTargets.toLocaleString('fa-IR')}</div>
              </div>
              <div className="space-y-1">
                <div className="text-sm text-muted-foreground">تکمیل شده</div>
                <div className="text-2xl font-bold text-green-600">{targetsSummary.totals.totalAchieved.toLocaleString('fa-IR')}</div>
              </div>
              <div className="space-y-1">
                <div className="text-sm text-muted-foreground">درصد کلی</div>
                <div className="text-2xl font-bold">{targetsSummary.totals.totalPercent}%</div>
              </div>
              <div className="space-y-1">
                <div className="text-sm text-muted-foreground">گروه‌های موفق</div>
                <div className="text-2xl font-bold text-green-600">{targetsSummary.totals.targetsAchieved} / {targetsSummary.totals.totalGroups}</div>
              </div>
            </div>
            <div className="w-full h-3 bg-gray-200 rounded-full">
              <div 
                className={`h-3 rounded-full transition-all ${
                  targetsSummary.totals.totalPercent >= 100 ? 'bg-green-600' :
                  targetsSummary.totals.totalPercent >= 80 ? 'bg-yellow-500' :
                  'bg-red-500'
                }`}
                style={{ width: `${Math.min(targetsSummary.totals.totalPercent, 100)}%` }}
              />
            </div>
          </CardContent>
        </Card>
      )}

      {groupsLoading || targetsLoading || summaryLoading ? (
        <div className="text-center py-8 text-muted-foreground">در حال بارگذاری...</div>
      ) : groups.length === 0 ? (
        <div className="text-center py-8 text-muted-foreground">هیچ گروهی وجود ندارد</div>
      ) : (
        <div className="space-y-4">
          {groups.filter(g => g.isActive).map((group) => {
            const groupTargets = targetsByGroup[group.id] || [];
            const groupSummary = targetsSummary?.summary.find(s => s.groupId === group.id);
            return (
              <GroupTargetCard 
                key={group.id} 
                group={group} 
                targets={groupTargets} 
                summary={groupSummary}
              />
            );
          })}
        </div>
      )}

      {/* Create Department Target Dialog */}
      <Dialog open={departmentDialogOpen} onOpenChange={setDepartmentDialogOpen}>
        <DialogContent dir="rtl" className="text-right">
          <DialogHeader>
            <DialogTitle>تعیین هدف بخش (همه گروه‌ها)</DialogTitle>
            <DialogDescription>
              هدف سالانه را برای تمام گروه‌های فعال تعیین کنید. این هدف به صورت خودکار برای همه گروه‌ها اعمال می‌شود.
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleDepartmentSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="dept-target-year">سال شمسی *</Label>
              <Input
                id="dept-target-year"
                value={departmentFormData.yearShamsi}
                onChange={(e) => setDepartmentFormData({ ...departmentFormData, yearShamsi: e.target.value })}
                placeholder="مثال: 1403"
                className="text-right"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="dept-target-case-count">تعداد قضایای هدف</Label>
              <Input
                id="dept-target-case-count"
                type="number"
                value={departmentFormData.targetCaseCount}
                onChange={(e) => setDepartmentFormData({ ...departmentFormData, targetCaseCount: e.target.value })}
                placeholder="مثال: 100"
                className="text-right"
                min="0"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="dept-target-monetary">مبلغ هدف (افغانی)</Label>
              <Input
                id="dept-target-monetary"
                value={departmentFormData.targetMonetary}
                onChange={(e) => setDepartmentFormData({ ...departmentFormData, targetMonetary: e.target.value })}
                placeholder="مثال: 1000000"
                className="text-right"
              />
            </div>
            <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
              <p className="text-sm text-blue-800 dark:text-blue-200">
                توجه: این هدف برای تمام گروه‌های فعال اعمال می‌شود. می‌توانید بعداً برای گروه‌های خاص تنظیمات جداگانه تعیین کنید.
              </p>
            </div>
            <DialogFooter className="mt-6">
              <Button
                type="button"
                variant="outline"
                onClick={() => {
                  setDepartmentDialogOpen(false);
                  setDepartmentFormData({ yearShamsi: '', targetCaseCount: '', targetMonetary: '' });
                }}
              >
                لغو
              </Button>
              <Button type="submit" disabled={createDepartmentTargetMutation.isPending}>
                {createDepartmentTargetMutation.isPending ? 'در حال ذخیره...' : 'تعیین هدف برای همه گروه‌ها'}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Create Target Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent dir="rtl" className="text-right">
          <DialogHeader>
            <DialogTitle>تعیین هدف جدید</DialogTitle>
            <DialogDescription>
              هدف سالانه را برای یک گروه تعیین کنید
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="target-group">گروه *</Label>
              <Select
                value={selectedGroupId}
                onValueChange={setSelectedGroupId}
              >
                <SelectTrigger id="target-group" dir="rtl">
                  <SelectValue placeholder="انتخاب گروه" />
                </SelectTrigger>
                <SelectContent dir="rtl">
                  {groups.filter(g => g.isActive).map((group) => (
                    <SelectItem key={group.id} value={group.id}>
                      {group.name} {group.code ? `(${group.code})` : ''}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="target-year">سال شمسی *</Label>
              <Input
                id="target-year"
                value={formData.yearShamsi}
                onChange={(e) => setFormData({ ...formData, yearShamsi: e.target.value })}
                placeholder="مثال: 1403"
                className="text-right"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="target-case-count">تعداد قضایای هدف</Label>
              <Input
                id="target-case-count"
                type="number"
                value={formData.targetCaseCount}
                onChange={(e) => setFormData({ ...formData, targetCaseCount: e.target.value })}
                placeholder="مثال: 100"
                className="text-right"
                min="0"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="target-monetary">مبلغ هدف (افغانی)</Label>
              <Input
                id="target-monetary"
                value={formData.targetMonetary}
                onChange={(e) => setFormData({ ...formData, targetMonetary: e.target.value })}
                placeholder="مثال: 1000000"
                className="text-right"
              />
            </div>
            <DialogFooter className="mt-6">
              <Button
                type="button"
                variant="outline"
                onClick={() => {
                  setDialogOpen(false);
                  setFormData({ yearShamsi: '', targetCaseCount: '', targetMonetary: '' });
                  setSelectedGroupId('');
                }}
              >
                لغو
              </Button>
              <Button type="submit" disabled={createTargetMutation.isPending}>
                {createTargetMutation.isPending ? 'در حال ذخیره...' : 'تعیین هدف'}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Edit Target Dialog */}
      <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
        <DialogContent dir="rtl" className="text-right">
          <DialogHeader>
            <DialogTitle>ویرایش هدف</DialogTitle>
            <DialogDescription>
              مقادیر هدف را ویرایش کنید
            </DialogDescription>
          </DialogHeader>
          {editingTarget && (
            <form onSubmit={handleEditSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="edit-target-year">سال شمسی</Label>
                <Input
                  id="edit-target-year"
                  value={editingTarget.yearShamsi}
                  disabled
                  className="text-right bg-muted"
                />
                <p className="text-xs text-muted-foreground">سال شمسی قابل تغییر نیست</p>
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-target-case-count">تعداد قضایای هدف</Label>
                <Input
                  id="edit-target-case-count"
                  type="number"
                  value={editFormData.targetCaseCount}
                  onChange={(e) => setEditFormData({ ...editFormData, targetCaseCount: e.target.value })}
                  placeholder="مثال: 100"
                  className="text-right"
                  min="0"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-target-monetary">مبلغ هدف (افغانی)</Label>
                <Input
                  id="edit-target-monetary"
                  value={editFormData.targetMonetary}
                  onChange={(e) => setEditFormData({ ...editFormData, targetMonetary: e.target.value })}
                  placeholder="مثال: 1000000"
                  className="text-right"
                />
              </div>
              <DialogFooter className="mt-6">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => {
                    setEditDialogOpen(false);
                    setEditingTarget(null);
                    setEditFormData({ targetCaseCount: '', targetMonetary: '' });
                  }}
                >
                  لغو
                </Button>
                <Button type="submit" disabled={updateTargetMutation.isPending}>
                  {updateTargetMutation.isPending ? 'در حال ذخیره...' : 'ذخیره تغییرات'}
                </Button>
              </DialogFooter>
            </form>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

