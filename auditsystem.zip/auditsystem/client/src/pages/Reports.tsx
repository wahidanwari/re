/**
 * Reports Page - Redesigned with 4 Report Types
 * Clean, RTL-aligned, modern UI
 */

import { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useQuery } from '@tanstack/react-query';
import { Building2, FileText } from 'lucide-react';

// Import report components
import MinistryReportTab from '@/components/reports/MinistryReportTab';
import InternalReportTab from '@/components/reports/InternalReportTab';

export default function Reports() {
  const { user, loading: authLoading } = useAuth();


  return (
    <div className="space-y-6" dir="rtl">
      {/* Page Header */}
      <div>
        <h1 className="text-3xl font-bold tracking-tight">گزارشات</h1>
        <p className="text-muted-foreground mt-2">
          مشاهده و دانلود گزارشات مختلف سیستم
        </p>
      </div>

      {/* Main Content Tabs */}
      <Tabs defaultValue="ministry" className="space-y-6" dir="rtl">
        <TabsList className="grid w-full grid-cols-2" dir="rtl">
          <TabsTrigger value="ministry" className="flex items-center gap-2" dir="rtl">
            <Building2 className="h-4 w-4" />
            گزارشات مرکز
          </TabsTrigger>
          <TabsTrigger value="internal" className="flex items-center gap-2" dir="rtl">
            <FileText className="h-4 w-4" />
            گزارش داخلی
          </TabsTrigger>
        </TabsList>

        {/* Report Type 1: Ministry Reporting */}
        <TabsContent value="ministry" className="space-y-6">
          <MinistryReportTab user={user} />
        </TabsContent>

        {/* Report Type 2: Internal Report */}
        <TabsContent value="internal" className="space-y-6">
          <InternalReportTab user={user} />
        </TabsContent>
      </Tabs>
    </div>
  );
}
