import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Plus, Search, Eye, X, CheckCircle, XCircle, Users, Calendar, FileText } from 'lucide-react';
import StatusBadge from '@/components/StatusBadge';
import ShamsiDatePickerDDMMYYYY, { gregorianToShamsi, shamsiToGregorian } from '@/components/ShamsiDatePickerDDMMYYYY';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import type { Committee, Entity, Case, Group, User } from '@shared/schema';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import jalaali from 'jalaali-js';

export default function Committees() {
  const [createDialogOpen, setCreateDialogOpen] = useState(false);
  const [viewDialogOpen, setViewDialogOpen] = useState(false);
  const [intakeDialogOpen, setIntakeDialogOpen] = useState(false);
  const [selectedCommittee, setSelectedCommittee] = useState<Committee | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'Active' | 'Closed'>('all');
  
  // Afghan months: حمل، ثور، جوزا، سرطان، اسد، سنبله، میزان، عقرب، قوس، جدی، دلو، حوت
  const AFGHAN_MONTHS = [
    { value: 'حمل', label: 'حمل' },
    { value: 'ثور', label: 'ثور' },
    { value: 'جوزا', label: 'جوزا' },
    { value: 'سرطان', label: 'سرطان' },
    { value: 'اسد', label: 'اسد' },
    { value: 'سنبله', label: 'سنبله' },
    { value: 'میزان', label: 'میزان' },
    { value: 'عقرب', label: 'عقرب' },
    { value: 'قوس', label: 'قوس' },
    { value: 'جدی', label: 'جدی' },
    { value: 'دلو', label: 'دلو' },
    { value: 'حوت', label: 'حوت' },
  ];

  const [formData, setFormData] = useState({
    name: '',
    month: '',
    year: '',
    period: '', // Legacy field, auto-generated
    startDate: '',
    endDate: '',
    notes: '',
  });

  const [selectedCases, setSelectedCases] = useState<Set<string>>(new Set());

  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { user: currentUser, loading: authLoading } = useAuth();

  // Check if user has access: System Admin, Director, or Coordinator
  const hasAccess = currentUser && (
    currentUser.role === 'system_admin' ||
    currentUser.role === 'director' ||
    (currentUser.permissionPackages && Array.isArray(currentUser.permissionPackages) && currentUser.permissionPackages.includes('acting_coordinator'))
  );

  // Fetch committees
  const { data: committees = [], isLoading } = useQuery<Committee[]>({
    queryKey: ['committees'],
    queryFn: async () => {
      const response = await fetch('/api/committees', { credentials: 'include' });
      if (!response.ok) throw new Error('Failed to fetch committees');
      return response.json();
    },
    enabled: !authLoading && !!currentUser,
  });

  // Fetch groups for receiving group selection
  const { data: groups = [] } = useQuery<Group[]>({
    queryKey: ['groups'],
    queryFn: async () => {
      const response = await fetch('/api/groups', { credentials: 'include' });
      if (!response.ok) throw new Error('Failed to fetch groups');
      return response.json();
    },
    enabled: !authLoading && !!currentUser && intakeDialogOpen,
  });

  // Fetch users to display assigned auditor names
  const { data: users = [] } = useQuery<User[]>({
    queryKey: ['users'],
    queryFn: async () => {
      const response = await fetch('/api/users', { credentials: 'include' });
      if (!response.ok) return [];
      return response.json();
    },
    enabled: !authLoading && !!currentUser && viewDialogOpen,
  });

  // Fetch available cases for committee intake (filtered by committee month/year)
  // BUG FIX #2/#4: Refetch when dialog opens to include newly created cases
  const { data: availableCases = [], refetch: refetchAvailableCases } = useQuery<Case[]>({
    queryKey: ['available-cases', selectedCommittee?.id],
    queryFn: async () => {
      if (!selectedCommittee) return [];
      const response = await fetch(`/api/committees/${selectedCommittee.id}/available-cases`, { credentials: 'include' });
      if (!response.ok) return [];
      return response.json();
    },
    enabled: !authLoading && !!currentUser && intakeDialogOpen && !!selectedCommittee,
    staleTime: 0, // Always consider data stale to ensure fresh data when dialog opens
    refetchOnMount: true, // Always refetch when component mounts (dialog opens)
    refetchOnWindowFocus: false, // Don't refetch on window focus to avoid unnecessary requests
  });
  
  // BUG FIX #2/#4: Refetch available cases when intake dialog opens
  useEffect(() => {
    if (intakeDialogOpen && selectedCommittee) {
      refetchAvailableCases();
    }
  }, [intakeDialogOpen, selectedCommittee, refetchAvailableCases]);

  // Fetch committee cases when viewing (committees show CASES, not entities)
  const { data: committeeCases = [], refetch: refetchCommitteeCases } = useQuery<Case[]>({
    queryKey: ['committee-cases', selectedCommittee?.id],
    queryFn: async () => {
      if (!selectedCommittee) return [];
      const response = await fetch(`/api/committees/${selectedCommittee.id}/cases`, { credentials: 'include' });
      if (!response.ok) return [];
      return response.json();
    },
    enabled: !!selectedCommittee && viewDialogOpen,
    staleTime: 0, // Always consider data stale to ensure fresh data
  });

  const createCommitteeMutation = useMutation({
    mutationFn: async (data: any) => {
      // Convert Shamsi dates to Gregorian for API
      const startDateGregorian = shamsiToGregorian(data.startDate);
      const endDateGregorian = shamsiToGregorian(data.endDate);
      
      // Validate dates
      if (!startDateGregorian || !endDateGregorian) {
        throw new Error('تاریخ شروع و پایان باید به درستی وارد شوند');
      }
      
      // Validate month and year
      if (!data.month || !data.year) {
        throw new Error('ماه و سال کمیته الزامی است');
      }
      
      // Convert YYYY-MM-DD strings to ISO strings
      const parseDateString = (dateStr: string): string => {
        const [year, month, day] = dateStr.split('-').map(Number);
        const date = new Date(year, month - 1, day);
        return date.toISOString();
      };
      
      const startDateISO = parseDateString(startDateGregorian);
      const endDateISO = parseDateString(endDateGregorian);
      
      // Generate period string
      const period = `${data.month} ${data.year}`;
      
      const response = await fetch('/api/committees', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: data.name,
          month: data.month,
          year: parseInt(data.year, 10),
          period: period,
          startDate: startDateISO,
          endDate: endDateISO,
          notes: data.notes || null,
        }),
        credentials: 'include',
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to create committee');
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['committees'] });
      setCreateDialogOpen(false);
      setFormData({
        name: '',
        month: '',
        year: '',
        period: '',
        startDate: '',
        endDate: '',
        notes: '',
      });
      toast({
        title: 'موفقیت',
        description: 'کمیته با موفقیت ایجاد شد',
      });
    },
    onError: (error: any) => {
      toast({
        title: 'خطا',
        description: error.message || 'خطا در ایجاد کمیته',
        variant: 'destructive',
      });
    },
  });

  const addCasesMutation = useMutation({
    mutationFn: async ({ committeeId, caseIds }: { committeeId: string; caseIds: string[] }) => {
      // Link cases to committee one by one
      const results = [];
      for (const caseId of caseIds) {
        const response = await fetch(`/api/committees/${committeeId}/cases/${caseId}`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          credentials: 'include',
        });
        if (!response.ok) {
          const error = await response.json();
          throw new Error(error.message || `Failed to add case ${caseId}`);
        }
        results.push(await response.json());
      }
      return results;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['committees'] });
      queryClient.invalidateQueries({ queryKey: ['committee-cases'] });
      queryClient.invalidateQueries({ queryKey: ['available-cases'] });
      queryClient.invalidateQueries({ queryKey: ['cases'] });
      // Manually refetch committee cases if view dialog is open
      if (viewDialogOpen && selectedCommittee) {
        refetchCommitteeCases();
      }
      setIntakeDialogOpen(false);
      setSelectedCases(new Set());
      toast({
        title: 'موفقیت',
        description: 'قضایا با موفقیت به کمیته اضافه شدند',
      });
    },
    onError: (error: any) => {
      toast({
        title: 'خطا',
        description: error.message || 'خطا در اضافه کردن قضایا',
        variant: 'destructive',
      });
    },
  });

  const closeCommitteeMutation = useMutation({
    mutationFn: async (committeeId: string) => {
      const response = await fetch(`/api/committees/${committeeId}/close`, {
        method: 'POST',
        credentials: 'include',
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to close committee');
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['committees'] });
      toast({
        title: 'موفقیت',
        description: 'کمیته با موفقیت بسته شد',
      });
    },
    onError: (error: any) => {
      toast({
        title: 'خطا',
        description: error.message || 'خطا در بستن کمیته',
        variant: 'destructive',
      });
    },
  });

  const handleCreateCommittee = () => {
    if (!formData.name || !formData.month || !formData.year || !formData.startDate || !formData.endDate) {
      toast({
        title: 'خطا',
        description: 'لطفاً تمام فیلدهای الزامی را پر کنید',
        variant: 'destructive',
      });
      return;
    }
    createCommitteeMutation.mutate(formData);
  };

  const handleAddCases = () => {
    if (!selectedCommittee) return;
    if (selectedCases.size === 0) {
      toast({
        title: 'خطا',
        description: 'لطفاً حداقل یک قضیه انتخاب کنید',
        variant: 'destructive',
      });
      return;
    }
    addCasesMutation.mutate({
      committeeId: selectedCommittee.id,
      caseIds: Array.from(selectedCases),
    });
  };

  const handleViewCommittee = (committee: Committee) => {
    setSelectedCommittee(committee);
    setViewDialogOpen(true);
    // Refetch committee cases when opening view dialog to ensure fresh data
    setTimeout(() => {
      refetchCommitteeCases();
    }, 100);
  };

  const handleOpenIntake = (committee: Committee) => {
    if (committee.status === 'Closed') {
      toast({
        title: 'خطا',
        description: 'نمی‌توان به کمیته بسته شده قضیه اضافه کرد',
        variant: 'destructive',
      });
      return;
    }
    // Check if committee is locked
    if ((committee as any).locked === true) {
      toast({
        title: 'خطا',
        description: 'کمیته قفل شده است. نمی‌توان قضیه جدید اضافه کرد. فقط اختصاص به گروه و تولید گزارش مجاز است.',
        variant: 'destructive',
      });
      return;
    }
    setSelectedCommittee(committee);
    setIntakeDialogOpen(true);
    // Refetch available cases when opening intake dialog to ensure fresh data
    setTimeout(() => {
      refetchAvailableCases();
    }, 100);
  };

  const toggleCaseSelection = (caseId: string) => {
    const newSelected = new Set(selectedCases);
    if (newSelected.has(caseId)) {
      newSelected.delete(caseId);
    } else {
      newSelected.add(caseId);
    }
    setSelectedCases(newSelected);
  };

  // Filter committees
  const filteredCommittees = committees.filter(committee => {
    const matchesSearch = !searchQuery || 
      committee.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      committee.period.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === 'all' || committee.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  // Get current date in Shamsi for default period
  const now = new Date();
  const shamsiNow = jalaali.toJalaali(now);
  const defaultPeriod = `${shamsiNow.jy}`;

  if (!authLoading && currentUser && !hasAccess) {
    return (
      <div className="p-8">
        <div className="text-center">
          <h2 className="text-2xl font-semibold mb-4">عدم دسترسی</h2>
          <p className="text-muted-foreground mb-4">فقط مدیر سیستم، مدیر، و هماهنگ‌ کننده می‌ توانند به این صفحه دسترسی داشته باشند.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6" dir="rtl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">مدیریت کمیته‌ها</h1>
          <p className="text-muted-foreground mt-2">ایجاد و مدیریت کمیته‌های بررسی</p>
        </div>
        {hasAccess && (
          <Button onClick={() => setCreateDialogOpen(true)}>
            <Plus className="mr-2 h-4 w-4" />
            ایجاد کمیته جدید
          </Button>
        )}
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex gap-4">
            <div className="flex-1">
              <Input
                placeholder="جستجو بر اساس نام یا دوره..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="max-w-sm"
              />
            </div>
            <Select value={statusFilter} onValueChange={(value: any) => setStatusFilter(value)}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="وضعیت" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">همه</SelectItem>
                <SelectItem value="Active">فعال</SelectItem>
                <SelectItem value="Closed">بسته شده</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Committees Table */}
      <Card>
        <CardHeader>
          <CardTitle>لیست کمیته‌ها</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="text-center py-8">در حال بارگذاری...</div>
          ) : filteredCommittees.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">کمیته‌ای یافت نشد</div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[200px] text-right">نام کمیته</TableHead>
                    <TableHead className="w-[120px] text-right">ماه</TableHead>
                    <TableHead className="w-[100px] text-right">سال</TableHead>
                    <TableHead className="w-[150px] text-right">تاریخ شروع</TableHead>
                    <TableHead className="w-[150px] text-right">تاریخ پایان</TableHead>
                    <TableHead className="w-[100px] text-center">وضعیت</TableHead>
                    <TableHead className="w-[100px] text-center">قفل</TableHead>
                    <TableHead className="w-[200px] text-right">عملیات</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredCommittees.map((committee) => {
                    const startDate = new Date(committee.startDate);
                    const endDate = new Date(committee.endDate);
                    
                    // Convert Date objects directly to Shamsi using jalaali
                    const startShamsi = jalaali.toJalaali(startDate);
                    const endShamsi = jalaali.toJalaali(endDate);
                    
                    return (
                      <TableRow key={committee.id}>
                        <TableCell className="font-medium text-right">{committee.name}</TableCell>
                        <TableCell className="text-right">{(committee as any).month || committee.period?.split(' ')[0] || '-'}</TableCell>
                        <TableCell className="text-right">{(committee as any).year || committee.period?.split(' ')[1] || '-'}</TableCell>
                        <TableCell className="text-right">
                          <span dir="ltr" className="font-mono">
                            {String(startShamsi.jd).padStart(2, '0')}-{String(startShamsi.jm).padStart(2, '0')}-{startShamsi.jy}
                          </span>
                        </TableCell>
                        <TableCell className="text-right">
                          <span dir="ltr" className="font-mono">
                            {String(endShamsi.jd).padStart(2, '0')}-{String(endShamsi.jm).padStart(2, '0')}-{endShamsi.jy}
                          </span>
                        </TableCell>
                        <TableCell className="text-center">
                          <StatusBadge status={committee.status} />
                        </TableCell>
                        <TableCell className="text-center">
                          {(committee as any).locked ? (
                            <Badge variant="destructive">قفل شده</Badge>
                          ) : (
                            <Badge variant="outline">باز</Badge>
                          )}
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex items-center justify-end gap-2">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleViewCommittee(committee)}
                            >
                              <Eye className="h-4 w-4 ml-1" />
                            </Button>
                            {committee.status === 'Active' && !(committee as any).locked && (
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => handleOpenIntake(committee)}
                              >
                                <Users className="h-4 w-4 ml-1" />
                                افزودن قضیه
                              </Button>
                            )}
                            {committee.status === 'Active' && hasAccess && (
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => {
                                  if (confirm('آیا از بستن این کمیته اطمینان دارید؟ کمیته قفل خواهد شد و نمی‌توان قضیه جدید اضافه کرد.')) {
                                    closeCommitteeMutation.mutate(committee.id);
                                  }
                                }}
                              >
                                <XCircle className="h-4 w-4 ml-1" />
                                بستن و قفل
                              </Button>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Create Committee Dialog */}
      <Dialog open={createDialogOpen} onOpenChange={setCreateDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>ایجاد کمیته جدید</DialogTitle>
            <DialogDescription>
              کمیته جدید برای بررسی دوره‌ای قضیه ایجاد کنید
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="name">نام کمیته *</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="مثال: کمیته بررسی سال 1404"
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="month">ماه (افغانی) *</Label>
                <Select 
                  value={formData.month} 
                  onValueChange={(v) => setFormData({ ...formData, month: v })}
                >
                  <SelectTrigger id="month">
                    <SelectValue placeholder="انتخاب ماه" />
                  </SelectTrigger>
                  <SelectContent>
                    {AFGHAN_MONTHS.map((m) => (
                      <SelectItem key={m.value} value={m.value}>{m.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="year">سال (شمسی) *</Label>
                <Input
                  id="year"
                  type="number"
                  value={formData.year}
                  onChange={(e) => setFormData({ ...formData, year: e.target.value })}
                  placeholder="مثال: 1404"
                  min="1300"
                  max="1500"
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="startDate">تاریخ شروع *</Label>
                <ShamsiDatePickerDDMMYYYY
                  value={formData.startDate}
                  onChange={(date) => setFormData({ ...formData, startDate: date })}
                />
              </div>
              <div>
                <Label htmlFor="endDate">تاریخ پایان *</Label>
                <ShamsiDatePickerDDMMYYYY
                  value={formData.endDate}
                  onChange={(date) => setFormData({ ...formData, endDate: date })}
                />
              </div>
            </div>
            <div>
              <Label htmlFor="notes">ملاحظات</Label>
              <Textarea
                id="notes"
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                placeholder="ملاحظات اختیاری..."
                rows={3}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setCreateDialogOpen(false)}>
              انصراف
            </Button>
            <Button onClick={handleCreateCommittee} disabled={createCommitteeMutation.isPending}>
              {createCommitteeMutation.isPending ? 'در حال ایجاد...' : 'ایجاد'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* View Committee Dialog */}
      <Dialog open={viewDialogOpen} onOpenChange={setViewDialogOpen}>
        <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{selectedCommittee?.name}</DialogTitle>
            <DialogDescription>
              جزئیات کمیته و قضایای مرتبط
            </DialogDescription>
          </DialogHeader>
          {selectedCommittee && (
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>ماه</Label>
                  <p className="text-sm font-medium">{(selectedCommittee as any).month || selectedCommittee.period?.split(' ')[0] || '-'}</p>
                </div>
                <div>
                  <Label>سال</Label>
                  <p className="text-sm font-medium">{(selectedCommittee as any).year || selectedCommittee.period?.split(' ')[1] || '-'}</p>
                </div>
                <div>
                  <Label>وضعیت</Label>
                  <div className="mt-1">
                    <StatusBadge status={selectedCommittee.status} />
                  </div>
                </div>
                <div>
                  <Label>وضعیت قفل</Label>
                  <div className="mt-1">
                    {(selectedCommittee as any).locked ? (
                      <Badge variant="destructive">قفل شده</Badge>
                    ) : (
                      <Badge variant="outline">باز</Badge>
                    )}
                  </div>
                </div>
              </div>
              {selectedCommittee.notes && (
                <div>
                  <Label>ملاحظات</Label>
                  <p className="text-sm text-muted-foreground mt-1">{selectedCommittee.notes}</p>
                </div>
              )}
              
              {/* Committees show CASES, not entities */}
              <div className="space-y-4">
                  {committeeCases.length === 0 ? (
                    <p className="text-sm text-muted-foreground text-center py-4">قضیه‌ای در این کمیته وجود ندارد</p>
                  ) : (
                    <div className="overflow-x-auto">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead className="text-right">شماره قضیه</TableHead>
                            <TableHead className="text-right">نام نهاد</TableHead>
                            <TableHead className="text-right">نمبر تشخیصیه</TableHead>
                            <TableHead className="text-right">ماهیت تشبث</TableHead>
                            <TableHead className="text-right">سال‌های بررسی</TableHead>
                            <TableHead className="text-right">گروه اختصاص داده شده</TableHead>
                            <TableHead className="text-right">بازرس اختصاص داده شده</TableHead>
                            <TableHead className="text-center">وضعیت</TableHead>
                            <TableHead className="text-right">عملیات</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {committeeCases.map((case_) => (
                            <TableRow key={case_.id}>
                              <TableCell className="text-right">
                                <span dir="ltr">{case_.caseId}</span>
                              </TableCell>
                              <TableCell className="text-right font-medium">{case_.companyName}</TableCell>
                              <TableCell className="text-right">
                                <span dir="ltr">{case_.tin}</span>
                              </TableCell>
                              <TableCell className="text-right">{case_.businessNature || '-'}</TableCell>
                              <TableCell className="text-right">{(case_ as any).auditYearRange || case_.periodsUnderReview || '-'}</TableCell>
                              <TableCell className="text-right">
                                {case_.receivingGroup ? (
                                  groups.find(g => g.id === case_.receivingGroup)?.name || case_.receivingGroup
                                ) : '-'}
                              </TableCell>
                              <TableCell className="text-right">
                                {case_.assignedAuditor ? (
                                  users.find(u => u.id === case_.assignedAuditor)?.fullName || case_.assignedAuditor
                                ) : '-'}
                              </TableCell>
                              <TableCell className="text-center">
                                <StatusBadge status={case_.status} />
                              </TableCell>
                              <TableCell className="text-right">
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => {
                                    // Navigate to case detail or open in new tab
                                    window.open(`/cases?caseId=${case_.id}`, '_blank');
                                  }}
                                >
                                  <Eye className="h-4 w-4" />
                                </Button>
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  )}
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Entity Intake Dialog */}
      <Dialog open={intakeDialogOpen} onOpenChange={setIntakeDialogOpen}>
        <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>افزودن قضیه به کمیته: {selectedCommittee?.name}</DialogTitle>
            <DialogDescription>
              قضایای واجد شرایط را انتخاب کنید. فقط قضایایی با وضعیت "جدید" یا "در انتظار" که هنوز به کمیته یا گروه دیگری اختصاص داده نشده‌اند نمایش داده می‌شوند.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>قضایای موجود ({availableCases.length} قضیه، {selectedCases.size} انتخاب شده)</Label>
              {availableCases.length === 0 ? (
                <div className="border rounded-md mt-2 p-8 text-center text-muted-foreground">
                  هیچ قضیه واجد شرایطی یافت نشد. قضایا باید دارای وضعیت "جدید" یا "در انتظار" باشند و هنوز به کمیته یا گروه دیگری اختصاص داده نشده باشند.
                </div>
              ) : (
                <div className="border rounded-md mt-2 max-h-[400px] overflow-y-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="w-12"></TableHead>
                        <TableHead className="text-right">شماره قضیه</TableHead>
                        <TableHead className="text-right">نام نهاد</TableHead>
                        <TableHead className="text-right">نمبر تشخیصیه</TableHead>
                        <TableHead className="text-right">ماهیت تشبث</TableHead>
                        <TableHead className="text-right">سال‌های بررسی</TableHead>
                        <TableHead className="text-right">وضعیت</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {availableCases.map((case_) => (
                        <TableRow key={case_.id}>
                          <TableCell>
                            <Checkbox
                              checked={selectedCases.has(case_.id)}
                              onCheckedChange={() => toggleCaseSelection(case_.id)}
                            />
                          </TableCell>
                          <TableCell className="text-right">
                            <span dir="ltr">{case_.caseId}</span>
                          </TableCell>
                          <TableCell className="text-right font-medium">{case_.companyName}</TableCell>
                          <TableCell className="text-right">
                            <span dir="ltr">{case_.tin}</span>
                          </TableCell>
                          <TableCell className="text-right">{case_.businessNature || '-'}</TableCell>
                          <TableCell className="text-right">{(case_ as any).auditYearRange || case_.periodsUnderReview || '-'}</TableCell>
                          <TableCell className="text-right">
                            <StatusBadge status={case_.status} />
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => {
              setIntakeDialogOpen(false);
              setSelectedCases(new Set());
            }}>
              انصراف
            </Button>
            <Button 
              onClick={handleAddCases} 
              disabled={addCasesMutation.isPending || selectedCases.size === 0}
            >
              {addCasesMutation.isPending ? 'در حال افزودن...' : `افزودن ${selectedCases.size} قضیه`}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

