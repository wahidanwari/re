import { useAuth } from '@/contexts/AuthContext';
import { userHasPermission } from '@/utils/permissions';
import MetricCard from '@/components/MetricCard';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { FileText, Users, CheckCircle, Clock, Activity, Upload, Settings, BarChart3, Target } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import StatusBadge from '@/components/StatusBadge';
import { useQuery } from '@tanstack/react-query';
import type { Case, User, Ticket, Notification, Group } from '@shared/schema';
import { useLocation } from 'wouter';

export default function Dashboard() {
  const { user, loading: authLoading } = useAuth();
  const [, setLocation] = useLocation();

  const { data: cases = [], isLoading: casesLoading } = useQuery<Case[]>({
    queryKey: ['cases'],
    queryFn: async () => {
      const response = await fetch('/api/cases', { credentials: 'include' });
      if (!response.ok) throw new Error('Failed to fetch cases');
      return response.json();
    },
    enabled: !authLoading && !!user,
  });

  const { data: users = [] } = useQuery<User[]>({
    queryKey: ['users'],
    queryFn: async () => {
      const response = await fetch('/api/users', { credentials: 'include' });
      if (!response.ok) throw new Error('Failed to fetch users');
      return response.json();
    },
    enabled: !authLoading && !!user && userHasPermission(user, 'logs:view'),
  });

  const { data: tickets = [] } = useQuery<Ticket[]>({
    queryKey: ['tickets'],
    queryFn: async () => {
      const response = await fetch('/api/tickets', { credentials: 'include' });
      if (!response.ok) throw new Error('Failed to fetch tickets');
      return response.json();
    },
    enabled: !authLoading && !!user,
  });

  const { data: groups = [] } = useQuery<Group[]>({
    queryKey: ['groups'],
    queryFn: async () => {
      const response = await fetch('/api/groups', { credentials: 'include' });
      if (!response.ok) throw new Error('Failed to fetch groups');
      return response.json();
    },
    enabled: !authLoading && !!user && (userHasPermission(user, 'reports:generate') || user?.role === 'director'),
  });

  // Fetch group targets for director dashboard (global target management)
  const { data: allGroupTargets = [] } = useQuery<any[]>({
    queryKey: ['group-targets'],
    queryFn: async () => {
      // Fetch targets for all groups
      const targetsPromises = groups.map(group =>
        fetch(`/api/groups/${group.id}/targets`, { credentials: 'include' })
          .then(res => res.ok ? res.json() : [])
          .catch(() => [])
      );
      const allTargets = await Promise.all(targetsPromises);
      return allTargets.flat();
    },
    enabled: !authLoading && !!user && user?.role === 'director' && groups.length > 0,
  });

  const { data: notifications = [] } = useQuery<Notification[]>({
    queryKey: ['notifications'],
    queryFn: async () => {
      if (!user?.id) return [];
      const response = await fetch('/api/notifications', { credentials: 'include' });
      if (!response.ok) throw new Error('Failed to fetch notifications');
      return response.json();
    },
    enabled: !authLoading && !!user,
  });

  // Fetch user's group for displaying group tag (must be before early return)
  const { data: userGroup } = useQuery<Group | null>({
    queryKey: ['group', user?.groupId],
    queryFn: async () => {
      if (!user?.groupId) return null;
      try {
        const response = await fetch(`/api/groups/${user.groupId}`, { credentials: 'include' });
        if (!response.ok) {
          // Silently handle 403/404 - user may not have permission to view this group
          if (response.status === 403 || response.status === 404) {
            return null;
          }
          // For other errors, return null silently
          return null;
        }
        return response.json();
      } catch (error) {
        // Silently handle all errors - don't log to console
        return null;
      }
    },
    enabled: !authLoading && !!user?.groupId,
    retry: false, // Don't retry on any error
    throwOnError: false, // Don't throw errors to avoid console logging
    onError: () => {
      // Silently handle errors - no logging
    },
  });

  const recentCases = cases.slice(0, 5);
  const recentNotifications = notifications.slice(0, 5);

  // Ticket status data (numerical counts only)
  const ticketStatusData = [
    { name: 'منتظر تایید', value: tickets.filter(t => t.status === 'منتظر تایید').length },
    { name: 'تایید شده', value: tickets.filter(t => t.status === 'تایید شده').length },
    { name: 'رد شده', value: tickets.filter(t => t.status === 'رد شده').length },
  ].filter(item => item.value > 0);

  // Group performance data for director
  const groupPerformanceData = groups.map(group => {
    const groupCases = cases.filter(c => c.groupReferrer === group.id);
    return {
      name: group.name,
      total: groupCases.length,
      completed: groupCases.filter(c => c.status === 'تکمیل شده').length,
      inProgress: groupCases.filter(c => c.status === 'در جریان بررسی').length,
    };
  }).filter(item => item.total > 0);

  const handleExportReport = async (format: 'pdf' | 'excel') => {
    try {
      const url = `/api/reports/completed-cases?format=${format}`;
      window.open(url, '_blank');
    } catch (error) {
      console.error('Export failed:', error);
    }
  };

  if (authLoading || casesLoading) {
    return <div className="p-8"><div className="text-center">در حال بارگذاری...</div></div>;
  }

  const renderSystemAdminDashboard = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <MetricCard title="کاربران فعال" value={users.filter(u => u.isActive).length.toString()} icon={Users} />
        <MetricCard title="تکت های در صف" value={tickets.filter(t => t.status === 'منتظر تایید').length.toString()} icon={Clock} />
        <MetricCard title="قضایا" value={cases.length.toString()} icon={FileText} />
        <MetricCard title="کل تکت‌ها" value={tickets.length.toString()} icon={Activity} />
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>وضعیت قضایا</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-5 gap-4">
              <div className="text-center p-4 border rounded-lg">
                <div className="text-2xl font-bold">{cases.filter(c => c.status === 'جدید').length}</div>
                <div className="text-sm text-muted-foreground">جدید</div>
              </div>
              <div className="text-center p-4 border rounded-lg">
                <div className="text-2xl font-bold">{cases.filter(c => c.status === 'در جریان بررسی').length}</div>
                <div className="text-sm text-muted-foreground">در جریان بررسی</div>
              </div>
              <div className="text-center p-4 border rounded-lg">
                <div className="text-2xl font-bold">{cases.filter(c => c.status === 'تکمیل شده').length}</div>
                <div className="text-sm text-muted-foreground">تکمیل شده</div>
              </div>
              <div className="text-center p-4 border rounded-lg">
                <div className="text-2xl font-bold">{cases.filter(c => c.status === 'منتظر تایید').length}</div>
                <div className="text-sm text-muted-foreground">منتظر تایید</div>
              </div>
              <div className="text-center p-4 border rounded-lg">
                <div className="text-2xl font-bold">{cases.filter(c => c.status === 'تایید شده').length}</div>
                <div className="text-sm text-muted-foreground">تایید شده</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>وضعیت تکت‌ها</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-3 gap-4">
              <div className="text-center p-4 border rounded-lg">
                <div className="text-2xl font-bold">{tickets.filter(t => t.status === 'منتظر تایید').length}</div>
                <div className="text-sm text-muted-foreground">منتظر تایید</div>
              </div>
              <div className="text-center p-4 border rounded-lg">
                <div className="text-2xl font-bold">{tickets.filter(t => t.status === 'تایید شده').length}</div>
                <div className="text-sm text-muted-foreground">تایید شده</div>
              </div>
              <div className="text-center p-4 border rounded-lg">
                <div className="text-2xl font-bold">{tickets.filter(t => t.status === 'رد شده').length}</div>
                <div className="text-sm text-muted-foreground">رد شده</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>دسترسی سریع</CardTitle>
        </CardHeader>
        <CardContent className="flex gap-3 flex-wrap">
          <Button onClick={() => setLocation('/users')} data-testid="button-manage-users">
            <Users className="ml-2 h-4 w-4" />
            مدیریت کاربران
          </Button>
          <Button variant="outline" onClick={() => setLocation('/groups')} data-testid="button-manage-groups">
            <BarChart3 className="ml-2 h-4 w-4" />
            مدیریت گروه‌ها
          </Button>
          <Button variant="outline" onClick={() => setLocation('/settings')} data-testid="button-settings">
            <Settings className="ml-2 h-4 w-4" />
            تنظیمات
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>فعالیت‌های اخیر</CardTitle>
        </CardHeader>
        <CardContent>
          {recentNotifications.length === 0 ? (
            <p className="text-center text-muted-foreground py-4">هیچ اعلانی وجود ندارد</p>
          ) : (
            <div className="space-y-2">
              {recentNotifications.map((notification) => (
                <div key={notification.id} className="flex items-start gap-3 p-3 border rounded-lg">
                  <div className="flex-1">
                    <p className="text-sm">{notification.message}</p>
                    <p className="text-xs text-muted-foreground mt-1">
                      {new Date(notification.createdAt).toLocaleDateString('fa-AF')}
                    </p>
                  </div>
                  {!notification.isRead && (
                    <div className="w-2 h-2 bg-blue-500 rounded-full" />
                  )}
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );

  const renderDirectorDashboard = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <MetricCard title="قضایای تکمیل شده" value={cases.filter(c => c.status === 'تکمیل شده').length.toString()} icon={CheckCircle} />
        <MetricCard title="منتظر تایید" value={tickets.filter(t => t.status === 'منتظر تایید').length.toString()} icon={Clock} />
        <MetricCard title="کل قضایا" value={cases.length.toString()} icon={FileText} />
      </div>
      
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0">
          <CardTitle>عملکرد گروه‌ها</CardTitle>
          <div className="flex gap-2">
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => handleExportReport('excel')}
              data-testid="button-export-excel"
            >
              خروجی Excel
            </Button>
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => handleExportReport('pdf')}
              data-testid="button-export-pdf"
            >
              خروجی PDF
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {groupPerformanceData.length > 0 ? (
            <div className="space-y-4">
              {groupPerformanceData.map((group) => (
                <div key={group.name} className="p-4 border rounded-lg">
                  <div className="flex items-center justify-between mb-3">
                    <h4 className="font-semibold">{group.name}</h4>
                  </div>
                  <div className="grid grid-cols-3 gap-4">
                    <div className="text-center">
                      <div className="text-2xl font-bold">{group.total}</div>
                      <div className="text-sm text-muted-foreground">کل</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-green-600">{group.completed}</div>
                      <div className="text-sm text-muted-foreground">تکمیل شده</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-yellow-600">{group.inProgress}</div>
                      <div className="text-sm text-muted-foreground">در جریان</div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="h-64 flex items-center justify-center text-muted-foreground">
              داده‌ای برای نمایش وجود ندارد
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0">
          <CardTitle className="flex items-center gap-2">
            <Target className="h-5 w-5" />
            مدیریت اهداف گروه‌ها
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <p className="text-sm text-muted-foreground text-right">
              شما می‌توانید اهداف سالانه را برای تمام گروه‌های بررسی تعیین کنید.
            </p>
            {groups.length > 0 ? (
              <div className="space-y-3">
                {groups.map((group) => {
                  const groupTargets = allGroupTargets.filter((t: any) => t.groupId === group.id);
                  return (
                    <div key={group.id} className="p-4 border rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-semibold">{group.name}</h4>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => setLocation(`/groups?target=${group.id}`)}
                        >
                          <Target className="ml-2 h-4 w-4" />
                          مدیریت اهداف
                        </Button>
                      </div>
                      {groupTargets.length > 0 ? (
                        <div className="mt-3 space-y-2">
                          {groupTargets.map((target: any) => (
                            <div key={target.id} className="text-sm text-muted-foreground flex justify-between">
                              <span>سال {target.yearShamsi}:</span>
                              <span>
                                {target.targetCaseCount ? `${target.targetCaseCount} قضیه` : ''}
                                {target.targetCaseCount && target.targetMonetary ? ' • ' : ''}
                                {target.targetMonetary || ''}
                              </span>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <p className="text-sm text-muted-foreground mt-2">هیچ هدفی تعیین نشده است</p>
                      )}
                    </div>
                  );
                })}
              </div>
            ) : (
              <p className="text-center text-muted-foreground py-4">هیچ گروهی وجود ندارد</p>
            )}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>قضایای اخیر</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="text-right">نمبر قضیه</TableHead>
                <TableHead className="text-right">نام شرکت</TableHead>
                <TableHead className="text-right">وضعیت</TableHead>
                <TableHead className="text-right">تاریخ</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {recentCases.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={4} className="text-center text-muted-foreground">
                    هیچ قضیه‌ای وجود ندارد
                  </TableCell>
                </TableRow>
              ) : (
                recentCases.map((case_) => (
                  <TableRow key={case_.id} className="hover-elevate cursor-pointer" onClick={() => setLocation(`/cases`)}>
                    <TableCell className="font-medium">{case_.caseId}</TableCell>
                    <TableCell>{case_.companyName}</TableCell>
                    <TableCell><StatusBadge status={case_.status} /></TableCell>
                    <TableCell>{case_.referralDate || '—'}</TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>اعلانات اخیر</CardTitle>
        </CardHeader>
        <CardContent>
          {recentNotifications.length === 0 ? (
            <p className="text-center text-muted-foreground py-4">هیچ اعلانی وجود ندارد</p>
          ) : (
            <div className="space-y-2">
              {recentNotifications.map((notification) => (
                <div key={notification.id} className="flex items-start gap-3 p-3 border rounded-lg">
                  <div className="flex-1">
                    <p className="text-sm">{notification.message}</p>
                    <p className="text-xs text-muted-foreground mt-1">
                      {new Date(notification.createdAt).toLocaleDateString('fa-AF')}
                    </p>
                  </div>
                  {!notification.isRead && (
                    <div className="w-2 h-2 bg-blue-500 rounded-full" />
                  )}
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );

  const renderSeniorAuditorDashboard = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <MetricCard title="بار کاری گروه" value={cases.length.toString()} icon={FileText} />
        <MetricCard title="در انتظار واگذاری" value={cases.filter(c => c.status === 'جدید').length.toString()} icon={Clock} />
        <MetricCard title="در جریان بررسی" value={cases.filter(c => c.status === 'در جریان بررسی').length.toString()} icon={Activity} />
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle>وضعیت قضایا</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-5 gap-4">
            <div className="text-center p-4 border rounded-lg">
              <div className="text-2xl font-bold">{cases.filter(c => c.status === 'جدید').length}</div>
              <div className="text-sm text-muted-foreground">جدید</div>
            </div>
            <div className="text-center p-4 border rounded-lg">
              <div className="text-2xl font-bold">{cases.filter(c => c.status === 'در جریان بررسی').length}</div>
              <div className="text-sm text-muted-foreground">در جریان بررسی</div>
            </div>
            <div className="text-center p-4 border rounded-lg">
              <div className="text-2xl font-bold">{cases.filter(c => c.status === 'تکمیل شده').length}</div>
              <div className="text-sm text-muted-foreground">تکمیل شده</div>
            </div>
            <div className="text-center p-4 border rounded-lg">
              <div className="text-2xl font-bold">{cases.filter(c => c.status === 'منتظر تایید').length}</div>
              <div className="text-sm text-muted-foreground">منتظر تایید</div>
            </div>
            <div className="text-center p-4 border rounded-lg">
              <div className="text-2xl font-bold">{cases.filter(c => c.status === 'تایید شده').length}</div>
              <div className="text-sm text-muted-foreground">تایید شده</div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>قضایای اخیر</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="text-right">نمبر قضیه</TableHead>
                <TableHead className="text-right">نام شرکت</TableHead>
                <TableHead className="text-right">وضعیت</TableHead>
                <TableHead className="text-right">تاریخ</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {recentCases.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={4} className="text-center text-muted-foreground">
                    هیچ قضیه‌ای وجود ندارد
                  </TableCell>
                </TableRow>
              ) : (
                recentCases.map((case_) => (
                  <TableRow key={case_.id} className="hover-elevate cursor-pointer" onClick={() => setLocation(`/cases`)}>
                    <TableCell className="font-medium">{case_.caseId}</TableCell>
                    <TableCell>{case_.companyName}</TableCell>
                    <TableCell><StatusBadge status={case_.status} /></TableCell>
                    <TableCell>{case_.referralDate || '—'}</TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>اعلانات اخیر</CardTitle>
        </CardHeader>
        <CardContent>
          {recentNotifications.length === 0 ? (
            <p className="text-center text-muted-foreground py-4">هیچ اعلانی وجود ندارد</p>
          ) : (
            <div className="space-y-2">
              {recentNotifications.map((notification) => (
                <div key={notification.id} className="flex items-start gap-3 p-3 border rounded-lg">
                  <div className="flex-1">
                    <p className="text-sm">{notification.message}</p>
                    <p className="text-xs text-muted-foreground mt-1">
                      {new Date(notification.createdAt).toLocaleDateString('fa-AF')}
                    </p>
                  </div>
                  {!notification.isRead && (
                    <div className="w-2 h-2 bg-blue-500 rounded-full" />
                  )}
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );

  const renderAuditorDashboard = () => {
    const myCases = cases.filter(c => c.assignedTo === user?.id);
    
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <MetricCard title="قضایای اختصاص داده شده" value={myCases.length.toString()} icon={FileText} />
          <MetricCard title="در جریان بررسی" value={myCases.filter(c => c.status === 'در جریان بررسی').length.toString()} icon={Clock} />
          <MetricCard title="تکمیل شده" value={myCases.filter(c => c.status === 'تکمیل شده').length.toString()} icon={CheckCircle} />
        </div>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0">
            <CardTitle>قضایای من</CardTitle>
            <Button size="sm" onClick={() => setLocation('/documents')} data-testid="button-upload">
              <Upload className="ml-2 h-4 w-4" />
              آپلود سند
            </Button>
          </CardHeader>
          <CardContent>
            {myCases.length === 0 ? (
              <p className="text-center text-muted-foreground py-4">هیچ قضیه‌ای به شما اختصاص داده نشده است</p>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="text-right">نمبر قضیه</TableHead>
                    <TableHead className="text-right">نام شرکت</TableHead>
                    <TableHead className="text-right">وضعیت</TableHead>
                    <TableHead className="text-right">تاریخ</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {myCases.slice(0, 5).map((case_) => (
                    <TableRow key={case_.id} className="hover-elevate cursor-pointer" onClick={() => setLocation(`/cases`)}>
                      <TableCell className="font-medium">{case_.caseId}</TableCell>
                      <TableCell>{case_.companyName}</TableCell>
                      <TableCell><StatusBadge status={case_.status} /></TableCell>
                      <TableCell>{case_.referralDate || '—'}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>تکت‌های من</CardTitle>
          </CardHeader>
          <CardContent>
            {(() => {
              const myTickets = tickets.filter(t => t.requestedBy === user?.id);
              if (myTickets.length === 0) {
                return <p className="text-center text-muted-foreground py-4">شما هیچ تکتی ایجاد نکرده‌اید</p>;
              }
              return (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="text-right">نمبر تکت</TableHead>
                      <TableHead className="text-right">نوع</TableHead>
                      <TableHead className="text-right">وضعیت</TableHead>
                      <TableHead className="text-right">تاریخ</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {myTickets.slice(0, 5).map((ticket) => (
                      <TableRow key={ticket.id} className="hover-elevate cursor-pointer" onClick={() => setLocation('/tickets')}>
                        <TableCell className="font-medium">{ticket.ticketId}</TableCell>
                        <TableCell>{ticket.type || '—'}</TableCell>
                        <TableCell><StatusBadge status={ticket.status} /></TableCell>
                        <TableCell>{ticket.createdAt ? new Date(ticket.createdAt).toLocaleDateString('fa-AF') : '—'}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              );
            })()}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>اعلانات اخیر</CardTitle>
          </CardHeader>
          <CardContent>
            {recentNotifications.length === 0 ? (
              <p className="text-center text-muted-foreground py-4">هیچ اعلانی وجود ندارد</p>
            ) : (
              <div className="space-y-2">
                {recentNotifications.map((notification) => (
                  <div key={notification.id} className="flex items-start gap-3 p-3 border rounded-lg">
                    <div className="flex-1">
                      <p className="text-sm">{notification.message}</p>
                      <p className="text-xs text-muted-foreground mt-1">
                        {new Date(notification.createdAt).toLocaleDateString('fa-AF')}
                      </p>
                    </div>
                    {!notification.isRead && (
                      <div className="w-2 h-2 bg-blue-500 rounded-full" />
                    )}
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    );
  };

  const dashboards = {
    system_admin: renderSystemAdminDashboard,
    director: renderDirectorDashboard,
    senior_auditor: renderSeniorAuditorDashboard,
    auditor: renderAuditorDashboard,
  };

  const renderDashboard = dashboards[user?.role as keyof typeof dashboards] || renderAuditorDashboard;

  return (
    <div className="p-8 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-semibold">داشبورد</h1>
          <p className="text-muted-foreground">خوش آمدید، {user?.fullName}</p>
        </div>
        {/* User's Group Tag */}
        {userGroup && (
          <Badge variant="outline" className="text-sm px-3 py-1">
            <Users className="h-3 w-3 ml-1" />
            {userGroup.name}
          </Badge>
        )}
      </div>
      {renderDashboard()}
    </div>
  );
}
