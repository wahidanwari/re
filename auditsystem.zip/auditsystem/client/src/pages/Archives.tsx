import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Upload, Download, Eye, Search, Filter, X, Archive, Trash2 } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';
import { userHasPermission } from '@/utils/permissions';
import { formatDistanceToNow } from 'date-fns';
import { faIR } from 'date-fns/locale';

interface ArchivedFile {
  id: string;
  fileName: string;
  originalFileName: string;
  year: number;
  category: string;
  description: string | null;
  path: string;
  sizeBytes: number;
  uploadedBy: string | null;
  uploadedByName: string | null;
  uploadedAt: string;
  isReadonly: boolean;
  currentVersion: number;
}

interface ArchivedFileVersion {
  id: string;
  versionNumber: number;
  fileName: string;
  sizeBytes: number;
  uploadedBy: string | null;
  uploadedByName: string | null;
  uploadedAt: string;
  notes: string | null;
}

interface ArchivesResponse {
  files: ArchivedFile[];
  pagination: {
    total: number;
    page: number;
    size: number;
    totalPages: number;
  };
}

export default function Archives() {
  const [isUploadDialogOpen, setIsUploadDialogOpen] = useState(false);
  const [isDetailsDialogOpen, setIsDetailsDialogOpen] = useState(false);
  const [selectedFile, setSelectedFile] = useState<ArchivedFile | null>(null);
  const [fileVersions, setFileVersions] = useState<ArchivedFileVersion[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [filters, setFilters] = useState({
    year: '',
    category: '',
    uploadedBy: '',
    dateFrom: '',
    dateTo: '',
  });
  const [sort, setSort] = useState('uploadedAt:desc');
  const [page, setPage] = useState(1);
  const [uploadForm, setUploadForm] = useState({
    year: '',
    category: '',
    description: '',
    notes: '',
  });
  const [selectedUploadFile, setSelectedUploadFile] = useState<File | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { user: currentUser } = useAuth();

  const canUpload = currentUser && userHasPermission(currentUser, 'archives:upload');
  const canDelete = currentUser && userHasPermission(currentUser, 'archives:delete');

  // Build query string
  const buildQueryString = () => {
    const params = new URLSearchParams();
    params.set('page', page.toString());
    params.set('size', '25');
    if (searchQuery) params.set('q', searchQuery);
    if (filters.year) params.set('year', filters.year);
    if (filters.category) params.set('category', filters.category);
    if (filters.uploadedBy) params.set('uploadedBy', filters.uploadedBy);
    if (filters.dateFrom) params.set('dateFrom', filters.dateFrom);
    if (filters.dateTo) params.set('dateTo', filters.dateTo);
    if (sort) params.set('sort', sort);
    return params.toString();
  };

  const { data, isLoading, refetch } = useQuery<ArchivesResponse>({
    queryKey: ['archives', page, searchQuery, filters, sort],
    queryFn: async () => {
      const response = await fetch(`/api/archives?${buildQueryString()}`, {
        credentials: 'include',
      });
      if (!response.ok) throw new Error('Failed to fetch archives');
      return response.json();
    },
  });

  const uploadMutation = useMutation({
    mutationFn: async (formData: FormData) => {
      const response = await fetch('/api/archives', {
        method: 'POST',
        credentials: 'include',
        body: formData,
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to upload file');
      }
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: 'موفقیت',
        description: 'فایل با موفقیت آپلود و بایگانی شد',
      });
      setIsUploadDialogOpen(false);
      setUploadForm({ year: '', category: '', description: '', notes: '' });
      setSelectedUploadFile(null);
      queryClient.invalidateQueries({ queryKey: ['archives'] });
    },
    onError: (error: Error) => {
      toast({
        title: 'خطا',
        description: error.message || 'خطا در آپلود فایل',
        variant: 'destructive',
      });
    },
    onSettled: () => {
      setIsUploading(false);
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const response = await fetch(`/api/archives/${id}`, {
        method: 'DELETE',
        credentials: 'include',
      });
      if (!response.ok) throw new Error('Failed to delete file');
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: 'موفقیت',
        description: 'فایل با موفقیت حذف شد',
      });
      queryClient.invalidateQueries({ queryKey: ['archives'] });
    },
    onError: () => {
      toast({
        title: 'خطا',
        description: 'خطا در حذف فایل',
        variant: 'destructive',
      });
    },
  });

  const handleUpload = async () => {
    if (!selectedUploadFile) {
      toast({
        title: 'خطا',
        description: 'لطفاً فایلی انتخاب کنید',
        variant: 'destructive',
      });
      return;
    }

    if (!uploadForm.year || !uploadForm.category) {
      toast({
        title: 'خطا',
        description: 'سال و دسته‌بندی الزامی هستند',
        variant: 'destructive',
      });
      return;
    }

    setIsUploading(true);
    const formData = new FormData();
    formData.append('file', selectedUploadFile);
    formData.append('year', uploadForm.year);
    formData.append('category', uploadForm.category);
    if (uploadForm.description) formData.append('description', uploadForm.description);
    if (uploadForm.notes) formData.append('notes', uploadForm.notes);

    uploadMutation.mutate(formData);
  };

  const handleViewDetails = async (file: ArchivedFile) => {
    setSelectedFile(file);
    try {
      const response = await fetch(`/api/archives/${file.id}`, {
        credentials: 'include',
      });
      if (!response.ok) throw new Error('Failed to fetch file details');
      const data = await response.json();
      setFileVersions(data.versions || []);
      setIsDetailsDialogOpen(true);
    } catch (error) {
      toast({
        title: 'خطا',
        description: 'خطا در دریافت جزئیات فایل',
        variant: 'destructive',
      });
    }
  };

  const handleDownload = async (fileId: string, version?: number) => {
    try {
      const url = version
        ? `/api/archives/${fileId}/download?version=${version}`
        : `/api/archives/${fileId}/download`;
      const response = await fetch(url, {
        credentials: 'include',
      });
      if (!response.ok) throw new Error('Failed to download file');

      const blob = await response.blob();
      const downloadUrl = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = downloadUrl;
      a.download = response.headers.get('Content-Disposition')?.split('filename=')[1]?.replace(/"/g, '') || 'file.xlsx';
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(downloadUrl);
      document.body.removeChild(a);

      toast({
        title: 'موفقیت',
        description: 'فایل با موفقیت دانلود شد',
      });
    } catch (error) {
      toast({
        title: 'خطا',
        description: 'خطا در دانلود فایل',
        variant: 'destructive',
      });
    }
  };

  const formatFileSize = (bytes: number): string => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(2)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
  };

  const clearFilters = () => {
    setFilters({
      year: '',
      category: '',
      uploadedBy: '',
      dateFrom: '',
      dateTo: '',
    });
    setSearchQuery('');
    setPage(1);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">بایگانی داده‌های Excel قدیمی</h1>
          <p className="text-muted-foreground mt-1">
            مدیریت و دسترسی به فایل‌های Excel بایگانی شده
          </p>
        </div>
        {canUpload && (
          <Button onClick={() => setIsUploadDialogOpen(true)}>
            <Upload className="ml-2 h-4 w-4" />
            آپلود فایل جدید
          </Button>
        )}
      </div>

      {/* Search and Filters */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Search className="h-5 w-5" />
            جستجو و فیلتر
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <Label>جستجو</Label>
              <Input
                placeholder="جستجو در نام فایل، دسته‌بندی، توضیحات..."
                value={searchQuery}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  setPage(1);
                }}
              />
            </div>
            <div>
              <Label>سال</Label>
              <Input
                type="number"
                placeholder="مثال: 1400"
                value={filters.year}
                onChange={(e) => {
                  setFilters({ ...filters, year: e.target.value });
                  setPage(1);
                }}
              />
            </div>
            <div>
              <Label>دسته‌بندی</Label>
              <Input
                placeholder="دسته‌بندی"
                value={filters.category}
                onChange={(e) => {
                  setFilters({ ...filters, category: e.target.value });
                  setPage(1);
                }}
              />
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" onClick={clearFilters}>
              <X className="ml-2 h-4 w-4" />
              پاک کردن فیلترها
            </Button>
            <div className="flex-1" />
            <Select value={sort} onValueChange={setSort}>
              <SelectTrigger className="w-[200px]">
                <SelectValue placeholder="مرتب‌سازی" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="uploadedAt:desc">جدیدترین</SelectItem>
                <SelectItem value="uploadedAt:asc">قدیمی‌ترین</SelectItem>
                <SelectItem value="year:desc">سال (نزولی)</SelectItem>
                <SelectItem value="year:asc">سال (صعودی)</SelectItem>
                <SelectItem value="fileName:asc">نام فایل (الفبایی)</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Files Table */}
      <Card>
        <CardHeader>
          <CardTitle>فایل‌های بایگانی شده</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="text-center py-8">در حال بارگذاری...</div>
          ) : data && data.files.length > 0 ? (
            <>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>نام فایل</TableHead>
                    <TableHead>سال</TableHead>
                    <TableHead>دسته‌بندی</TableHead>
                    <TableHead>آپلود شده توسط</TableHead>
                    <TableHead>تاریخ آپلود</TableHead>
                    <TableHead>حجم</TableHead>
                    <TableHead>نسخه</TableHead>
                    <TableHead>عملیات</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {data.files.map((file) => (
                    <TableRow key={file.id}>
                      <TableCell className="font-medium">{file.originalFileName}</TableCell>
                      <TableCell>{file.year}</TableCell>
                      <TableCell>
                        <Badge variant="outline">{file.category}</Badge>
                      </TableCell>
                      <TableCell>{file.uploadedByName || 'نامشخص'}</TableCell>
                      <TableCell>
                        {formatDistanceToNow(new Date(file.uploadedAt), {
                          addSuffix: true,
                          locale: faIR,
                        })}
                      </TableCell>
                      <TableCell>{formatFileSize(file.sizeBytes)}</TableCell>
                      <TableCell>
                        <Badge>v{file.currentVersion}</Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleViewDetails(file)}
                          >
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleDownload(file.id)}
                          >
                            <Download className="h-4 w-4" />
                          </Button>
                          {canDelete && (
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => {
                                if (confirm('آیا از حذف این فایل اطمینان دارید؟')) {
                                  deleteMutation.mutate(file.id);
                                }
                              }}
                            >
                              <Trash2 className="h-4 w-4 text-destructive" />
                            </Button>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
              {/* Pagination */}
              <div className="flex items-center justify-between mt-4">
                <div className="text-sm text-muted-foreground">
                  نمایش {((page - 1) * 25) + 1} تا {Math.min(page * 25, data.pagination.total)} از {data.pagination.total} فایل
                </div>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setPage(p => Math.max(1, p - 1))}
                    disabled={page === 1}
                  >
                    قبلی
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setPage(p => Math.min(data.pagination.totalPages, p + 1))}
                    disabled={page >= data.pagination.totalPages}
                  >
                    بعدی
                  </Button>
                </div>
              </div>
            </>
          ) : (
            <div className="text-center py-8 text-muted-foreground">
              فایلی یافت نشد
            </div>
          )}
        </CardContent>
      </Card>

      {/* Upload Dialog */}
      <Dialog open={isUploadDialogOpen} onOpenChange={setIsUploadDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>آپلود فایل جدید</DialogTitle>
            <DialogDescription>
              فایل Excel را برای بایگانی آپلود کنید. فایل به صورت خودکار در پوشه سال مربوطه ذخیره می‌شود.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>فایل Excel *</Label>
              <Input
                type="file"
                accept=".xlsx,.xls"
                onChange={(e) => setSelectedUploadFile(e.target.files?.[0] || null)}
              />
              {selectedUploadFile && (
                <p className="text-sm text-muted-foreground mt-1">
                  انتخاب شده: {selectedUploadFile.name}
                </p>
              )}
            </div>
            <div>
              <Label>سال (شمسی) *</Label>
              <Input
                type="number"
                placeholder="مثال: 1400"
                value={uploadForm.year}
                onChange={(e) => setUploadForm({ ...uploadForm, year: e.target.value })}
              />
            </div>
            <div>
              <Label>دسته‌بندی *</Label>
              <Input
                placeholder="مثال: گزارشات مالی، اسناد حسابداری"
                value={uploadForm.category}
                onChange={(e) => setUploadForm({ ...uploadForm, category: e.target.value })}
              />
            </div>
            <div>
              <Label>توضیحات</Label>
              <Textarea
                placeholder="توضیحات کوتاه درباره فایل"
                value={uploadForm.description}
                onChange={(e) => setUploadForm({ ...uploadForm, description: e.target.value })}
              />
            </div>
            <div>
              <Label>یادداشت‌ها (اختیاری)</Label>
              <Textarea
                placeholder="یادداشت‌های اضافی برای این نسخه"
                value={uploadForm.notes}
                onChange={(e) => setUploadForm({ ...uploadForm, notes: e.target.value })}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsUploadDialogOpen(false)}>
              انصراف
            </Button>
            <Button onClick={handleUpload} disabled={isUploading}>
              {isUploading ? 'در حال آپلود...' : 'آپلود و بایگانی'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Details Dialog */}
      <Dialog open={isDetailsDialogOpen} onOpenChange={setIsDetailsDialogOpen}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>جزئیات فایل</DialogTitle>
          </DialogHeader>
          {selectedFile && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>نام فایل اصلی</Label>
                  <p className="text-sm">{selectedFile.originalFileName}</p>
                </div>
                <div>
                  <Label>نام فایل ذخیره شده</Label>
                  <p className="text-sm">{selectedFile.fileName}</p>
                </div>
                <div>
                  <Label>سال</Label>
                  <p className="text-sm">{selectedFile.year}</p>
                </div>
                <div>
                  <Label>دسته‌بندی</Label>
                  <p className="text-sm">{selectedFile.category}</p>
                </div>
                <div>
                  <Label>توضیحات</Label>
                  <p className="text-sm">{selectedFile.description || '—'}</p>
                </div>
                <div>
                  <Label>حجم</Label>
                  <p className="text-sm">{formatFileSize(selectedFile.sizeBytes)}</p>
                </div>
                <div>
                  <Label>آپلود شده توسط</Label>
                  <p className="text-sm">{selectedFile.uploadedByName || 'نامشخص'}</p>
                </div>
                <div>
                  <Label>تاریخ آپلود</Label>
                  <p className="text-sm">
                    {new Date(selectedFile.uploadedAt).toLocaleDateString('fa-IR')}
                  </p>
                </div>
              </div>

              <div>
                <Label className="mb-2 block">تاریخچه نسخه‌ها</Label>
                <div className="space-y-2 max-h-64 overflow-y-auto">
                  {fileVersions.map((version) => (
                    <div
                      key={version.id}
                      className="flex items-center justify-between p-2 border rounded"
                    >
                      <div>
                        <p className="font-medium">نسخه {version.versionNumber}</p>
                        <p className="text-sm text-muted-foreground">
                          {formatFileSize(version.sizeBytes)} •{' '}
                          {new Date(version.uploadedAt).toLocaleDateString('fa-IR')}
                        </p>
                        {version.notes && (
                          <p className="text-sm text-muted-foreground mt-1">{version.notes}</p>
                        )}
                      </div>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleDownload(selectedFile.id, version.versionNumber)}
                      >
                        <Download className="h-4 w-4 ml-2" />
                        دانلود
                      </Button>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDetailsDialogOpen(false)}>
              بستن
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

