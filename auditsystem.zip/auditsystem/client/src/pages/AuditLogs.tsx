import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Label } from '@/components/ui/label';
import { Search, Eye, Filter, X, Trash2, Calendar, User } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';
import { userHasPermission } from '@/utils/permissions';
import { useLocation } from 'wouter';

type AuditLog = {
  id: string;
  userId: string | null;
  action: string;
  entityType: string | null;
  entityId: string | null;
  details: any;
  ipAddress: string | null;
  createdAt: Date | string | null;
  user?: {
    id: string;
    auditId: string;
    fullName: string;
    role: string;
  } | null;
};

type AuditLogResponse = {
  logs: AuditLog[];
  pagination: {
    page: number;
    limit: number;
    total: number;
    totalPages: number;
  };
};

const actionLabels: Record<string, string> = {
  create_user: 'ایجاد کاربر',
  update_user: 'ویرایش کاربر',
  delete_user: 'حذف کاربر',
  activate_user: 'فعال کردن کاربر',
  deactivate_user: 'غیرفعال کردن کاربر',
  reset_password: 'بازنشانی رمز عبور',
  create_group: 'ایجاد گروه',
  update_group: 'ویرایش گروه',
  delete_group: 'حذف گروه',
  add_group_member: 'افزودن عضو به گروه',
  remove_group_member: 'حذف عضو از گروه',
  add_group_target: 'تعیین هدف گروه',
  create_entity: 'ایجاد نهاد',
  update_entity: 'ویرایش نهاد',
  delete_entity: 'حذف نهاد',
  create_case: 'ایجاد قضیه',
  update_case: 'ویرایش قضیه',
  assign_case: 'واگذاری قضیه',
  update_case_status: 'تغییر وضعیت قضیه',
  complete_case: 'تکمیل قضیه',
  approve_case: 'تایید قضیه',
  reject_case: 'رد قضیه',
  create_ticket: 'ایجاد تکت',
  update_ticket: 'ویرایش تکت',
  approve_ticket: 'تایید تکت',
  reject_ticket: 'رد تکت',
  upload_document: 'آپلود سند',
  delete_document: 'حذف سند',
  export_report: 'خروجی گزارش',
  login: 'ورود به سیستم',
  logout: 'خروج از سیستم',
  update_setting: 'ویرایش تنظیمات',
};

const entityTypeLabels: Record<string, string> = {
  user: 'کاربر',
  group: 'گروه',
  entity: 'نهاد',
  case: 'قضیه',
  ticket: 'تکت',
  document: 'سند',
  report: 'گزارش',
  setting: 'تنظیمات',
};

export default function AuditLogs() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedLog, setSelectedLog] = useState<AuditLog | null>(null);
  const [detailsDialogOpen, setDetailsDialogOpen] = useState(false);
  const [clearAllDialogOpen, setClearAllDialogOpen] = useState(false);
  const [clearFilteredDialogOpen, setClearFilteredDialogOpen] = useState(false);
  const [clearUserDialogOpen, setClearUserDialogOpen] = useState(false);
  const [clearDays, setClearDays] = useState('');
  const [selectedUserId, setSelectedUserId] = useState('');
  const [filters, setFilters] = useState({
    entityType: '',
    action: '',
    userId: '',
    startDate: '',
    endDate: '',
  });
  const [page, setPage] = useState(1);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { user: currentUser, loading: authLoading } = useAuth();
  const [, setLocation] = useLocation();
  
  // Check if user is system admin
  const isSystemAdmin = currentUser?.role === 'system_admin' || false;

  // Redirect if not system admin
  const hasLogsPermission = currentUser && userHasPermission(currentUser, 'logs:view');
  
  if (!authLoading && currentUser && !hasLogsPermission) {
    return (
      <div className="p-8">
        <div className="text-center">
          <h2 className="text-2xl font-semibold mb-4">عدم دسترسی</h2>
          <p className="text-muted-foreground mb-4">فقط مدیر سیستم می‌تواند به لاگ‌های بررسی دسترسی داشته باشد.</p>
          <Button onClick={() => setLocation('/')}>
            بازگشت به داشبورد
          </Button>
        </div>
      </div>
    );
  }

  const { data: auditLogsData, isLoading } = useQuery<AuditLogResponse>({
    queryKey: ['audit-logs', filters, page],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (filters.entityType) params.append('entityType', filters.entityType);
      if (filters.action) params.append('action', filters.action);
      if (filters.userId) params.append('userId', filters.userId);
      if (filters.startDate) params.append('startDate', filters.startDate);
      if (filters.endDate) params.append('endDate', filters.endDate);
      params.append('page', page.toString());
      params.append('limit', '50');

      const response = await fetch(`/api/audit-logs?${params.toString()}`, { credentials: 'include' });
      if (!response.ok) {
        if (response.status === 403) {
          throw new Error('فقط مدیر سیستم می‌تواند به لاگ‌های بررسی دسترسی داشته باشد');
        }
        throw new Error('Failed to fetch audit logs');
      }
      return response.json();
    },
    enabled: !authLoading && !!currentUser && userHasPermission(currentUser, 'logs:view'),
  });

  const filteredLogs = (auditLogsData?.logs || []).filter((log) => {
    const query = searchQuery.toLowerCase();
    return (
      log.action.toLowerCase().includes(query) ||
      log.user?.fullName?.toLowerCase().includes(query) ||
      log.user?.auditId?.toLowerCase().includes(query) ||
      log.entityType?.toLowerCase().includes(query) ||
      log.entityId?.toLowerCase().includes(query) ||
      log.ipAddress?.toLowerCase().includes(query)
    );
  });

  const handleViewDetails = (log: AuditLog) => {
    setSelectedLog(log);
    setDetailsDialogOpen(true);
  };

  const clearFilters = () => {
    setFilters({
      entityType: '',
      action: '',
      userId: '',
      startDate: '',
      endDate: '',
    });
    setPage(1);
  };

  const formatDate = (date: Date | string | null) => {
    if (!date) return '—';
    const d = new Date(date);
    // CRITICAL: Format as Afghanistan local time (Asia/Kabul, UTC+4:30)
    // Database stores UTC timestamps, but we display them as Afghanistan local time
    // This ensures the displayed time matches the actual local time when the event occurred
    // Example: If event happened at 2:00 PM Afghanistan time, it displays as 2:00 PM
    return new Intl.DateTimeFormat('en-US', {
      timeZone: 'Asia/Kabul', // Afghanistan timezone (UTC+4:30)
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: false, // Use 24-hour format for consistency
    }).format(d);
  };

  const hasActiveFilters = Object.values(filters).some(v => v !== '');

  // Clear all logs mutation
  const clearAllLogsMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch('/api/audit-logs', {
        method: 'DELETE',
        credentials: 'include',
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to clear logs');
      }
      return response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['audit-logs'] });
      setClearAllDialogOpen(false);
      toast({
        title: 'موفق',
        description: `${data.deletedCount} لاگ با موفقیت پاک شد`,
      });
    },
    onError: (error: any) => {
      toast({
        title: 'خطا',
        description: error.message || 'پاک کردن لاگ‌ها با مشکل مواجه شد',
        variant: 'destructive',
      });
    },
  });

  // Clear filtered logs mutation
  const clearFilteredLogsMutation = useMutation({
    mutationFn: async (params: { days?: string; startDate?: string; endDate?: string; entityType?: string }) => {
      const response = await fetch('/api/audit-logs/filtered', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(params),
        credentials: 'include',
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to clear logs');
      }
      return response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['audit-logs'] });
      setClearFilteredDialogOpen(false);
      setClearDays('');
      toast({
        title: 'موفق',
        description: `${data.deletedCount} لاگ با موفقیت پاک شد`,
      });
    },
    onError: (error: any) => {
      toast({
        title: 'خطا',
        description: error.message || 'پاک کردن لاگ‌ها با مشکل مواجه شد',
        variant: 'destructive',
      });
    },
  });

  // Clear user logs mutation
  const clearUserLogsMutation = useMutation({
    mutationFn: async (userId: string) => {
      const response = await fetch(`/api/audit-logs/user/${userId}`, {
        method: 'DELETE',
        credentials: 'include',
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to clear user logs');
      }
      return response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['audit-logs'] });
      setClearUserDialogOpen(false);
      setSelectedUserId('');
      toast({
        title: 'موفق',
        description: data.message || 'لاگ‌های کاربر با موفقیت پاک شد',
      });
    },
    onError: (error: any) => {
      toast({
        title: 'خطا',
        description: error.message || 'پاک کردن لاگ‌های کاربر با مشکل مواجه شد',
        variant: 'destructive',
      });
    },
  });

  const handleClearAll = () => {
    clearAllLogsMutation.mutate();
  };

  const handleClearFiltered = () => {
    if (clearDays) {
      clearFilteredLogsMutation.mutate({ days: clearDays });
    } else {
      clearFilteredLogsMutation.mutate({
        startDate: filters.startDate || undefined,
        endDate: filters.endDate || undefined,
        entityType: filters.entityType || undefined,
      });
    }
  };

  const handleClearUser = () => {
    if (selectedUserId) {
      clearUserLogsMutation.mutate(selectedUserId);
    }
  };

  return (
    <div className="p-8 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-semibold">لاگ‌های بررسی</h1>
          <p className="text-muted-foreground">مشاهده و جستجوی تمام عملیات انجام شده در سیستم</p>
        </div>
        {isSystemAdmin && (
          <div className="flex gap-2">
            <Button
              variant="outline"
              onClick={() => setClearFilteredDialogOpen(true)}
              className="gap-2"
            >
              <Calendar className="h-4 w-4" />
              پاک کردن بر اساس تاریخ
            </Button>
            <Button
              variant="outline"
              onClick={() => setClearUserDialogOpen(true)}
              className="gap-2"
            >
              <User className="h-4 w-4" />
              پاک کردن بر اساس کاربر
            </Button>
            <Button
              variant="destructive"
              onClick={() => setClearAllDialogOpen(true)}
              className="gap-2"
            >
              <Trash2 className="h-4 w-4" />
              پاک کردن همه
            </Button>
          </div>
        )}
      </div>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between gap-4">
            <div className="relative flex-1">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="جستجو بر اساس عمل، کاربر، آی دی بررسی، نوع موجودیت..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pr-10 text-right"
              />
            </div>
            <Button
              variant="outline"
              onClick={() => {
                const filtersDialog = document.getElementById('filters-dialog') as HTMLDialogElement;
                filtersDialog?.showModal();
              }}
            >
              <Filter className="ml-2 h-4 w-4" />
              فیلترها
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {hasActiveFilters && (
            <div className="mb-4 flex items-center gap-2 flex-wrap">
              {filters.entityType && (
                <Badge variant="secondary" className="gap-2">
                  نوع: {entityTypeLabels[filters.entityType] || filters.entityType}
                  <button
                    onClick={() => setFilters({ ...filters, entityType: '' })}
                    className="ml-1 hover:text-destructive"
                  >
                    <X className="h-3 w-3" />
                  </button>
                </Badge>
              )}
              {filters.action && (
                <Badge variant="secondary" className="gap-2">
                  عمل: {actionLabels[filters.action] || filters.action}
                  <button
                    onClick={() => setFilters({ ...filters, action: '' })}
                    className="ml-1 hover:text-destructive"
                  >
                    <X className="h-3 w-3" />
                  </button>
                </Badge>
              )}
              {(filters.startDate || filters.endDate) && (
                <Badge variant="secondary" className="gap-2">
                  تاریخ: {filters.startDate || '...'} تا {filters.endDate || '...'}
                  <button
                    onClick={() => setFilters({ ...filters, startDate: '', endDate: '' })}
                    className="ml-1 hover:text-destructive"
                  >
                    <X className="h-3 w-3" />
                  </button>
                </Badge>
              )}
              <Button variant="ghost" size="sm" onClick={clearFilters}>
                پاک کردن همه
              </Button>
            </div>
          )}

          {isLoading ? (
            <div className="text-center py-8 text-muted-foreground">در حال بارگذاری...</div>
          ) : filteredLogs.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">هیچ لاگی یافت نشد</div>
          ) : (
            <>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="text-right">تاریخ و زمان</TableHead>
                    <TableHead className="text-right">کاربر</TableHead>
                    <TableHead className="text-right">عمل</TableHead>
                    <TableHead className="text-right">نوع موجودیت</TableHead>
                    <TableHead className="text-right">آی دی موجودیت</TableHead>
                    <TableHead className="text-right">آدرس IP</TableHead>
                    <TableHead className="text-right">عملیات</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredLogs.map((log) => (
                    <TableRow key={log.id} className="hover-elevate">
                      <TableCell className="font-mono text-sm text-right" dir="ltr">
                        {formatDate(log.createdAt)}
                      </TableCell>
                      <TableCell>
                        {log.user ? (
                          <div>
                            <div className="font-medium">{log.user.fullName}</div>
                            <div className="text-xs text-muted-foreground">{log.user.auditId}</div>
                          </div>
                        ) : (
                          <span className="text-muted-foreground">کاربر حذف شده</span>
                        )}
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">
                          {actionLabels[log.action] || log.action}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        {log.entityType ? (
                          <Badge variant="secondary">
                            {entityTypeLabels[log.entityType] || log.entityType}
                          </Badge>
                        ) : (
                          '—'
                        )}
                      </TableCell>
                      <TableCell className="font-mono text-sm">
                        {log.entityId || '—'}
                      </TableCell>
                      <TableCell className="font-mono text-sm text-right" dir="ltr">
                        {log.ipAddress || '—'}
                      </TableCell>
                      <TableCell>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleViewDetails(log)}
                        >
                          <Eye className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
              
              {auditLogsData?.pagination && auditLogsData.pagination.totalPages > 1 && (
                <div className="flex items-center justify-between mt-4">
                  <div className="text-sm text-muted-foreground">
                    صفحه {auditLogsData.pagination.page} از {auditLogsData.pagination.totalPages} ({auditLogsData.pagination.total} کل)
                  </div>
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setPage(p => Math.max(1, p - 1))}
                      disabled={page === 1}
                    >
                      قبلی
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setPage(p => Math.min(auditLogsData.pagination.totalPages, p + 1))}
                      disabled={page >= auditLogsData.pagination.totalPages}
                    >
                      بعدی
                    </Button>
                  </div>
                </div>
              )}
            </>
          )}
        </CardContent>
      </Card>

      {/* Filters Dialog */}
      <Dialog open={false} onOpenChange={() => {}}>
        <DialogContent id="filters-dialog" className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>فیلترهای جستجو</DialogTitle>
            <DialogDescription>
              لاگ‌ها را بر اساس معیارهای مختلف فیلتر کنید
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="filter-entityType">نوع موجودیت</Label>
                <Select
                  value={filters.entityType}
                  onValueChange={(v) => setFilters({ ...filters, entityType: v })}
                >
                  <SelectTrigger id="filter-entityType">
                    <SelectValue placeholder="همه" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">همه</SelectItem>
                    {Object.entries(entityTypeLabels).map(([key, label]) => (
                      <SelectItem key={key} value={key}>{label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="filter-action">عمل</Label>
                <Select
                  value={filters.action}
                  onValueChange={(v) => setFilters({ ...filters, action: v })}
                >
                  <SelectTrigger id="filter-action">
                    <SelectValue placeholder="همه" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">همه</SelectItem>
                    {Object.entries(actionLabels).map(([key, label]) => (
                      <SelectItem key={key} value={key}>{label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="filter-startDate">از تاریخ</Label>
                <Input
                  id="filter-startDate"
                  type="date"
                  value={filters.startDate}
                  onChange={(e) => setFilters({ ...filters, startDate: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="filter-endDate">تا تاریخ</Label>
                <Input
                  id="filter-endDate"
                  type="date"
                  value={filters.endDate}
                  onChange={(e) => setFilters({ ...filters, endDate: e.target.value })}
                />
              </div>
            </div>
            <div className="flex gap-2 justify-end">
              <Button variant="outline" onClick={clearFilters}>
                پاک کردن
              </Button>
              <Button onClick={() => {
                const filtersDialog = document.getElementById('filters-dialog') as HTMLDialogElement;
                filtersDialog?.close();
                setPage(1);
              }}>
                اعمال فیلترها
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Details Dialog */}
      <Dialog open={detailsDialogOpen} onOpenChange={setDetailsDialogOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>جزئیات لاگ بررسی</DialogTitle>
            <DialogDescription>
              مشاهده اطلاعات کامل لاگ
            </DialogDescription>
          </DialogHeader>
          {selectedLog && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-muted-foreground">تاریخ و زمان</Label>
                  <p className="font-mono text-right" dir="ltr">{formatDate(selectedLog.createdAt)}</p>
                </div>
                <div>
                  <Label className="text-muted-foreground">کاربر</Label>
                  <p>
                    {selectedLog.user ? (
                      <>
                        {selectedLog.user.fullName} ({selectedLog.user.auditId})
                      </>
                    ) : (
                      'کاربر حذف شده'
                    )}
                  </p>
                </div>
                <div>
                  <Label className="text-muted-foreground">عمل</Label>
                  <p>
                    <Badge variant="outline">
                      {actionLabels[selectedLog.action] || selectedLog.action}
                    </Badge>
                  </p>
                </div>
                <div>
                  <Label className="text-muted-foreground">نوع موجودیت</Label>
                  <p>
                    {selectedLog.entityType ? (
                      <Badge variant="secondary">
                        {entityTypeLabels[selectedLog.entityType] || selectedLog.entityType}
                      </Badge>
                    ) : (
                      '—'
                    )}
                  </p>
                </div>
                <div>
                  <Label className="text-muted-foreground">آی دی موجودیت</Label>
                  <p className="font-mono text-sm">{selectedLog.entityId || '—'}</p>
                </div>
                <div>
                  <Label className="text-muted-foreground">آدرس IP</Label>
                  <p className="font-mono text-sm text-right" dir="ltr">{selectedLog.ipAddress || '—'}</p>
                </div>
              </div>
              
              {selectedLog.details && (
                <div>
                  <Label className="text-muted-foreground mb-2 block">جزئیات (قبل/بعد)</Label>
                  <pre className="bg-muted p-4 rounded-lg overflow-auto text-sm font-mono">
                    {JSON.stringify(selectedLog.details, null, 2)}
                  </pre>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Clear All Logs Dialog */}
      <AlertDialog open={clearAllDialogOpen} onOpenChange={setClearAllDialogOpen}>
        <AlertDialogContent dir="rtl">
          <AlertDialogHeader>
            <AlertDialogTitle>پاک کردن تمام لاگ‌ها</AlertDialogTitle>
            <AlertDialogDescription>
              آیا مطمئن هستید که می‌خواهید تمام لاگ‌های بررسی را پاک کنید؟ این عمل غیرقابل بازگشت است.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>لغو</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleClearAll}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              disabled={clearAllLogsMutation.isPending}
            >
              {clearAllLogsMutation.isPending ? 'در حال پاک کردن...' : 'پاک کردن همه'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Clear Filtered Logs Dialog */}
      <Dialog open={clearFilteredDialogOpen} onOpenChange={setClearFilteredDialogOpen}>
        <DialogContent dir="rtl" className="max-w-md">
          <DialogHeader>
            <DialogTitle>پاک کردن لاگ‌ها بر اساس فیلتر</DialogTitle>
            <DialogDescription>
              لاگ‌ها را بر اساس تاریخ یا فیلترهای دیگر پاک کنید
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="clear-days">پاک کردن لاگ‌های قدیمی‌تر از (روز)</Label>
              <Input
                id="clear-days"
                type="number"
                value={clearDays}
                onChange={(e) => setClearDays(e.target.value)}
                placeholder="مثال: 30 (لاگ‌های قدیمی‌تر از 30 روز)"
                className="text-right"
              />
            </div>
            <div className="text-sm text-muted-foreground">
              یا از فیلترهای فعلی استفاده کنید:
              {filters.startDate && <div>از تاریخ: {filters.startDate}</div>}
              {filters.endDate && <div>تا تاریخ: {filters.endDate}</div>}
              {filters.entityType && <div>نوع موجودیت: {filters.entityType}</div>}
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setClearFilteredDialogOpen(false)}>
              لغو
            </Button>
            <Button
              variant="destructive"
              onClick={handleClearFiltered}
              disabled={clearFilteredLogsMutation.isPending}
            >
              {clearFilteredLogsMutation.isPending ? 'در حال پاک کردن...' : 'پاک کردن'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Clear User Logs Dialog */}
      <Dialog open={clearUserDialogOpen} onOpenChange={setClearUserDialogOpen}>
        <DialogContent dir="rtl" className="max-w-md">
          <DialogHeader>
            <DialogTitle>پاک کردن لاگ‌های کاربر</DialogTitle>
            <DialogDescription>
              تمام لاگ‌های مربوط به یک کاربر خاص را پاک کنید
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="clear-user-id">آی دی کاربر</Label>
              <Input
                id="clear-user-id"
                value={selectedUserId}
                onChange={(e) => setSelectedUserId(e.target.value)}
                placeholder="آی دی کاربر را وارد کنید"
                className="text-right"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setClearUserDialogOpen(false)}>
              لغو
            </Button>
            <Button
              variant="destructive"
              onClick={handleClearUser}
              disabled={clearUserLogsMutation.isPending || !selectedUserId}
            >
              {clearUserLogsMutation.isPending ? 'در حال پاک کردن...' : 'پاک کردن'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

