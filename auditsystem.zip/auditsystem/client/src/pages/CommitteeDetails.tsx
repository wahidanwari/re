/**
 * Committee Details Page
 * Shows committee metadata and assigned cases
 */

import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useLocation, useRoute } from 'wouter';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { ArrowRight, Loader2, FileDown, CheckCircle, X, Users, AlertCircle } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';
import jalaali from 'jalaali-js';
import type { Case, Group } from '@shared/schema';
import StatusBadge from '@/components/StatusBadge';

interface CommitteeReport {
  committee: {
    id: string;
    title: string;
    year: number;
    month: number;
    status: 'DRAFT' | 'APPROVED' | 'CLOSED';
    createdAt: string;
    approvedAt?: string;
    createdBy: string;
    createdByName?: string;
    approvedBy?: string;
    approvedByName?: string;
  };
  cases: Array<{
    caseId: string;
    caseNumber?: number;
    entityName: string;
    auditGroupId: string;
    auditGroupName?: string;
    assignmentDate: string;
    assignmentSource: 'COMMITTEE' | 'DIRECT' | 'REASSIGNMENT';
    assignedBy: string;
    assignedByName?: string;
    caseCurrentStatus: string;
    assignmentId: string;
    tin?: string;
    businessNature?: string;
  }>;
  summary: {
    totalCases: number;
    casesByGroup: Record<string, number>;
    casesBySource: {
      committee: number;
      direct: number;
    };
  };
}

const monthNames = [
  'حمل', 'ثور', 'جوزا', 'سرطان', 'اسد', 'سنبله',
  'میزان', 'عقرب', 'قوس', 'جدی', 'دلو', 'حوت'
];

function getStatusBadge(status: string) {
  const statusMap: Record<string, { label: string; variant: 'default' | 'secondary' | 'destructive' | 'outline' }> = {
    DRAFT: { label: 'پیش‌نویس', variant: 'outline' },
    APPROVED: { label: 'تایید شده', variant: 'default' },
    CLOSED: { label: 'بسته شده', variant: 'secondary' },
  };
  const statusInfo = statusMap[status] || { label: status, variant: 'outline' };
  return <Badge variant={statusInfo.variant}>{statusInfo.label}</Badge>;
}

function formatShamsiDate(dateString: string): string {
  const date = new Date(dateString);
  const j = jalaali.toJalaali(date);
  return `${j.jy}/${String(j.jm).padStart(2, '0')}/${String(j.jd).padStart(2, '0')}`;
}

function getAssignmentSourceLabel(source: string): string {
  const sourceMap: Record<string, string> = {
    COMMITTEE: 'کمیته',
    DIRECT: 'مستقیم',
    REASSIGNMENT: 'اختصاص مجدد',
  };
  return sourceMap[source] || source;
}

interface EligibleCase extends Case {
  isEligible: boolean;
  reason?: string;
  entityName?: string;
}

export default function CommitteeDetails() {
  const [, params] = useRoute('/committees-new/:id');
  const [location, setLocation] = useLocation();
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const committeeId = params?.id || '';
  
  // State for case assignment
  const [selectedCaseIds, setSelectedCaseIds] = useState<Set<string>>(new Set());
  const [selectedAuditGroupId, setSelectedAuditGroupId] = useState<string>('');

  // Fetch committee report
  const { data: report, isLoading, refetch: refetchReport } = useQuery<CommitteeReport>({
    queryKey: ['committee-report', committeeId],
    queryFn: async () => {
      const response = await fetch(`/api/committee-reports/committees/${committeeId}`, {
        credentials: 'include',
      });
      if (!response.ok) throw new Error('Failed to fetch committee report');
      return response.json();
    },
    enabled: !!committeeId,
  });

  // Fetch eligible cases for assignment
  // Use existing /api/cases endpoint and filter client-side for eligible cases
  const { data: allCases = [], isLoading: isLoadingEligibleCases, refetch: refetchEligibleCases } = useQuery<Case[]>({
    queryKey: ['cases'],
    queryFn: async () => {
      const response = await fetch('/api/cases', {
        credentials: 'include',
      });
      if (!response.ok) throw new Error('Failed to fetch cases');
      return response.json();
    },
    enabled: !!committeeId && !!report && (report.committee.status === 'APPROVED' || report.committee.status === 'DRAFT'), // Only fetch if committee is APPROVED or DRAFT
  });

  // Filter cases client-side to match eligible criteria:
  // - Status must be "جدید" (NEW) or "در انتظار بررسی" (COMMITTEE_ASSIGNED_STATUS)
  // - NOT assigned to any audit group (no receivingGroup, currentAuditGroupId, or currentAssignmentId)
  const eligibleCases: EligibleCase[] = allCases
    .filter(case_ => {
      const status = case_.status as string;
      // Check status: must be "جدید" or "در انتظار بررسی"
      const hasEligibleStatus = status === 'جدید' || status === 'در انتظار بررسی';
      if (!hasEligibleStatus) return false;
      
      // Check if already assigned to audit group
      const isAssignedToGroup = !!(case_.receivingGroup || case_.currentAuditGroupId || case_.currentAssignmentId);
      if (isAssignedToGroup) return false;
      
      return true;
    })
    .map(case_ => ({
      ...case_,
      isEligible: true,
      reason: undefined,
      entityName: case_.companyName || 'نامشخص',
    }));

  // Fetch audit groups
  const { data: auditGroups = [] } = useQuery<Group[]>({
    queryKey: ['groups'],
    queryFn: async () => {
      const response = await fetch('/api/groups', {
        credentials: 'include',
      });
      if (!response.ok) return [];
      return response.json();
    },
  });

  // Approve committee mutation
  const approveMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch(`/api/committees-new/${committeeId}/approve`, {
        method: 'POST',
        credentials: 'include',
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to approve committee');
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['committee-report', committeeId] });
      queryClient.invalidateQueries({ queryKey: ['committees-new'] });
      toast({
        title: 'موفق',
        description: 'کمیته با موفقیت تایید شد',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'خطا',
        description: error.message,
        variant: 'destructive',
      });
    },
  });

  // Close committee mutation
  const closeMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch(`/api/committees-new/${committeeId}/close`, {
        method: 'POST',
        credentials: 'include',
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to close committee');
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['committee-report', committeeId] });
      queryClient.invalidateQueries({ queryKey: ['committees-new'] });
      toast({
        title: 'موفق',
        description: 'کمیته با موفقیت بسته شد',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'خطا',
        description: error.message,
        variant: 'destructive',
      });
    },
  });

  // Assign cases mutation
  const assignCasesMutation = useMutation({
    mutationFn: async ({ caseIds, auditGroupId }: { caseIds: string[]; auditGroupId: string }) => {
      // Validate and prepare payload
      if (!caseIds || !Array.isArray(caseIds) || caseIds.length === 0) {
        throw new Error('لیست قضایا الزامی است');
      }
      if (!auditGroupId || typeof auditGroupId !== 'string') {
        throw new Error('گروه بررسی الزامی است');
      }
      if (!committeeId || typeof committeeId !== 'string') {
        throw new Error('شناسه کمیته الزامی است');
      }
      
      // Ensure all caseIds are strings (database IDs)
      const validCaseIds = caseIds
        .map(id => String(id).trim())
        .filter(id => id.length > 0);
      
      if (validCaseIds.length === 0) {
        throw new Error('شناسه‌های قضایای انتخاب شده نامعتبر است');
      }
      
      // Prepare payload exactly as backend expects
      const payload = {
        caseIds: validCaseIds,
        auditGroupId: String(auditGroupId).trim(),
      };
      
      const response = await fetch(`/api/committees-new/${committeeId}/assign-cases`, {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify(payload),
      });
      
      // Parse response body regardless of status code
      const data = await response.json();
      
      // If response is not ok, check if there are partial successes
      if (!response.ok) {
        // Backend may return 400 with assignments array showing partial failures
        if (data.assignments && Array.isArray(data.assignments)) {
          const successfulAssignments = data.assignments.filter((a: any) => a.success) || [];
          const failedAssignments = data.assignments.filter((a: any) => !a.success) || [];
          
          // If there are any successful assignments, return the data for onSuccess handler
          if (successfulAssignments.length > 0) {
            return {
              ...data,
              hasPartialSuccess: true,
            };
          }
        }
        
        // All assignments failed, throw error with backend message
        throw new Error(data.message || 'Failed to assign cases');
      }
      
      return data;
    },
    onSuccess: (data) => {
      // CRITICAL: Only update UI state after successful backend response
      // Check for partial failures
      const failedAssignments = data.assignments?.filter((a: any) => !a.success) || [];
      const successfulAssignments = data.assignments?.filter((a: any) => a.success) || [];
      
      if (failedAssignments.length > 0) {
        // Show detailed error messages for failed assignments
        const errorMessages = failedAssignments
          .map((a: any) => a.errorMessage)
          .filter((msg: string) => msg)
          .slice(0, 3); // Show first 3 error messages
        
        const errorDetails = errorMessages.length > 0 
          ? `\nخطاها: ${errorMessages.join('; ')}${errorMessages.length < failedAssignments.length ? '...' : ''}`
          : '';
        
        toast({
          title: data.hasPartialSuccess ? 'اخطار' : 'خطا',
          description: `${successfulAssignments.length} قضیه با موفقیت اختصاص داده شد، اما ${failedAssignments.length} قضیه با خطا مواجه شد.${errorDetails}`,
          variant: 'destructive',
        });
      } else {
        toast({
          title: 'موفق',
          description: `${successfulAssignments.length} قضیه با موفقیت به گروه اختصاص داده شد`,
        });
      }
      
      // CRITICAL: Only clear selections and refetch AFTER successful assignment
      // Clear selections
      setSelectedCaseIds(new Set());
      setSelectedAuditGroupId('');
      
      // Refetch data to get updated case states
      refetchReport();
      refetchEligibleCases();
      queryClient.invalidateQueries({ queryKey: ['committee-report', committeeId] });
      queryClient.invalidateQueries({ queryKey: ['cases'] });
      queryClient.invalidateQueries({ queryKey: ['eligible-cases'] });
    },
    onError: (error: Error) => {
      toast({
        title: 'خطا',
        description: error.message || 'خطا در اختصاص قضایا',
        variant: 'destructive',
      });
    },
  });

  // Export report
  const handleExport = async () => {
    try {
      const response = await fetch(`/api/committee-reports/committees/${committeeId}/export?format=excel`, {
        credentials: 'include',
      });
      if (!response.ok) throw new Error('Failed to export report');
      
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `committee-report-${committeeId}.xlsx`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      
      toast({
        title: 'موفق',
        description: 'گزارش با موفقیت صادر شد',
      });
    } catch (error: any) {
      toast({
        title: 'خطا',
        description: error.message || 'خطا در صادر کردن گزارش',
        variant: 'destructive',
      });
    }
  };

  // Check if user can manage committees
  const canManage = user?.role === 'system_admin' || 
                    user?.role === 'director' || 
                    (user?.permissionPackages && Array.isArray(user.permissionPackages) && user.permissionPackages.includes('acting_coordinator'));

  const isClosed = report?.committee.status === 'CLOSED';
  const isDraft = report?.committee.status === 'DRAFT';
  const isApproved = report?.committee.status === 'APPROVED';

  // Filter out already assigned cases from eligible cases
  // Match by caseId (string identifier) since report uses caseId, not database id
  const assignedCaseIds = new Set(report?.cases.map(c => c.caseId) || []);
  const unassignedEligibleCases = eligibleCases.filter(
    case_ => !assignedCaseIds.has(case_.caseId)
  );

  // Toggle case selection (uses database id, not caseId string)
  const toggleCaseSelection = (caseDatabaseId: string) => {
    const newSelected = new Set(selectedCaseIds);
    if (newSelected.has(caseDatabaseId)) {
      newSelected.delete(caseDatabaseId);
    } else {
      newSelected.add(caseDatabaseId);
    }
    setSelectedCaseIds(newSelected);
  };

  // Select all visible cases
  const selectAllCases = () => {
    const allIds = new Set(unassignedEligibleCases.map(c => c.id));
    setSelectedCaseIds(allIds);
  };

  // Deselect all cases
  const deselectAllCases = () => {
    setSelectedCaseIds(new Set());
  };

  // Handle assign cases
  const handleAssignCases = () => {
    if (selectedCaseIds.size === 0) {
      toast({
        title: 'خطا',
        description: 'لطفاً حداقل یک قضیه انتخاب کنید',
        variant: 'destructive',
      });
      return;
    }
    if (!selectedAuditGroupId) {
      toast({
        title: 'خطا',
        description: 'لطفاً یک گروه بررسی انتخاب کنید',
        variant: 'destructive',
      });
      return;
    }
    if (!committeeId) {
      toast({
        title: 'خطا',
        description: 'شناسه کمیته یافت نشد',
        variant: 'destructive',
      });
      return;
    }
    
    // Prepare payload - ensure caseIds are strings (database IDs)
    const caseIdsArray = Array.from(selectedCaseIds).filter(id => id && typeof id === 'string');
    
    if (caseIdsArray.length === 0) {
      toast({
        title: 'خطا',
        description: 'شناسه‌های قضایای انتخاب شده نامعتبر است',
        variant: 'destructive',
      });
      return;
    }
    
    assignCasesMutation.mutate({
      caseIds: caseIdsArray,
      auditGroupId: selectedAuditGroupId,
    });
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-8">
        <Loader2 className="h-6 w-6 animate-spin" />
      </div>
    );
  }

  if (!report) {
    return (
      <div className="text-center py-8">
        <p className="text-muted-foreground">کمیته یافت نشد</p>
        <Button onClick={() => setLocation('/committees-new')} className="mt-4">
          بازگشت به لیست
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <Button variant="ghost" onClick={() => setLocation('/committees-new')}>
            <ArrowRight className="ml-2 h-4 w-4" />
            بازگشت به لیست
          </Button>
        </div>
        <div className="flex items-center gap-2">
          {canManage && isDraft && (
            <Button
              onClick={() => approveMutation.mutate()}
              disabled={approveMutation.isPending}
            >
              <CheckCircle className="ml-2 h-4 w-4" />
              تایید کمیته
            </Button>
          )}
          {canManage && isApproved && (
            <Button
              variant="destructive"
              onClick={() => {
                if (confirm('آیا مطمئن هستید که می‌خواهید این کمیته را ببندید؟')) {
                  closeMutation.mutate();
                }
              }}
              disabled={closeMutation.isPending}
            >
              <X className="ml-2 h-4 w-4" />
              بستن کمیته
            </Button>
          )}
          <Button variant="outline" onClick={handleExport}>
            <FileDown className="ml-2 h-4 w-4" />
            صادر کردن گزارش
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>اطلاعات کمیته</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <p className="text-sm text-muted-foreground">عنوان</p>
              <p className="font-medium">{report.committee.title}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">ماه</p>
              <p className="font-medium">{monthNames[report.committee.month - 1]}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">سال</p>
              <p className="font-medium">{report.committee.year}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">وضعیت</p>
              <div className="mt-1">{getStatusBadge(report.committee.status)}</div>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">تاریخ ایجاد</p>
              <p className="font-medium">{formatShamsiDate(report.committee.createdAt)}</p>
            </div>
            {report.committee.approvedAt && (
              <div>
                <p className="text-sm text-muted-foreground">تاریخ تایید</p>
                <p className="font-medium">{formatShamsiDate(report.committee.approvedAt)}</p>
              </div>
            )}
            <div>
              <p className="text-sm text-muted-foreground">ایجاد شده توسط</p>
              <p className="font-medium">{report.committee.createdByName || 'نامشخص'}</p>
            </div>
            {report.committee.approvedByName && (
              <div>
                <p className="text-sm text-muted-foreground">تایید شده توسط</p>
                <p className="font-medium">{report.committee.approvedByName}</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>خلاصه</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-3 gap-4">
            <div>
              <p className="text-sm text-muted-foreground">تعداد کل قضایا</p>
              <p className="text-2xl font-bold">{report.summary.totalCases}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">قضایای اختصاص داده شده از طریق کمیته</p>
              <p className="text-2xl font-bold">{report.summary.casesBySource.committee}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">قضایای اختصاص داده شده مستقیم</p>
              <p className="text-2xl font-bold">{report.summary.casesBySource.direct}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Case Assignment Section - Only show for APPROVED or DRAFT committees */}
      {(isApproved || isDraft) && canManage && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="h-5 w-5" />
              اختصاص قضایا به گروه‌های بررسی
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Audit Group Selection */}
            <div className="space-y-2">
              <Label htmlFor="audit-group">گروه بررسی *</Label>
              <Select
                value={selectedAuditGroupId}
                onValueChange={setSelectedAuditGroupId}
              >
                <SelectTrigger id="audit-group" className="w-full">
                  <SelectValue placeholder="یک گروه بررسی انتخاب کنید" />
                </SelectTrigger>
                <SelectContent>
                  {auditGroups.length === 0 ? (
                    <SelectItem value="no-groups" disabled>
                      هیچ گروهی یافت نشد
                    </SelectItem>
                  ) : (
                    auditGroups.map((group) => (
                      <SelectItem key={group.id} value={group.id}>
                        {group.name}
                      </SelectItem>
                    ))
                  )}
                </SelectContent>
              </Select>
            </div>

            {/* Eligible Cases List */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <Label className="text-base font-semibold">
                  قضایای واجد شرایط ({unassignedEligibleCases.length} قضیه، {selectedCaseIds.size} انتخاب شده)
                </Label>
                {unassignedEligibleCases.length > 0 && (
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={selectAllCases}
                      disabled={selectedCaseIds.size === unassignedEligibleCases.length}
                    >
                      انتخاب همه
                    </Button>
                    {selectedCaseIds.size > 0 && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={deselectAllCases}
                      >
                        لغو انتخاب
                      </Button>
                    )}
                  </div>
                )}
              </div>

              {isLoadingEligibleCases ? (
                <div className="flex items-center justify-center py-8">
                  <Loader2 className="h-6 w-6 animate-spin" />
                </div>
              ) : unassignedEligibleCases.length === 0 ? (
                <div className="border rounded-md p-8 text-center text-muted-foreground">
                  <AlertCircle className="h-8 w-8 mx-auto mb-2 opacity-50" />
                  <p>هیچ قضیه واجد شرایطی یافت نشد.</p>
                  <p className="text-sm mt-1">
                    قضایا باید دارای وضعیت "جدید" یا "در انتظار بررسی" باشند و هنوز به گروهی اختصاص داده نشده باشند.
                  </p>
                </div>
              ) : (
                <div className="border rounded-md max-h-[400px] overflow-y-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="w-12">
                          <Checkbox
                            checked={
                              unassignedEligibleCases.length > 0 &&
                              selectedCaseIds.size === unassignedEligibleCases.length
                            }
                            onCheckedChange={(checked) => {
                              if (checked) {
                                selectAllCases();
                              } else {
                                deselectAllCases();
                              }
                            }}
                          />
                        </TableHead>
                        <TableHead className="text-right">شماره قضیه</TableHead>
                        <TableHead className="text-right">نام نهاد</TableHead>
                        <TableHead className="text-right">نمبر تشخیصیه</TableHead>
                        <TableHead className="text-right">ماهیت تشبث</TableHead>
                        <TableHead className="text-right">سال‌های بررسی</TableHead>
                        <TableHead className="text-right">وضعیت</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {unassignedEligibleCases.map((case_) => (
                        <TableRow key={case_.id}>
                          <TableCell>
                            <Checkbox
                              checked={selectedCaseIds.has(case_.id)}
                              onCheckedChange={() => toggleCaseSelection(case_.id)}
                            />
                          </TableCell>
                          <TableCell className="font-medium text-right">
                            <span dir="ltr">{case_.caseId}</span>
                          </TableCell>
                          <TableCell className="text-right">{case_.entityName || case_.companyName || '-'}</TableCell>
                          <TableCell className="text-right">
                            <span dir="ltr">{case_.tin || '-'}</span>
                          </TableCell>
                          <TableCell className="text-right">{case_.businessNature || '-'}</TableCell>
                          <TableCell className="text-right">
                            {(case_ as any).auditYearRange || case_.periodsUnderReview || '-'}
                          </TableCell>
                          <TableCell className="text-right">
                            <StatusBadge status={case_.status} />
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </div>

            {/* Assign Button */}
            <div className="flex justify-end pt-2">
              <Button
                onClick={handleAssignCases}
                disabled={
                  assignCasesMutation.isPending ||
                  selectedCaseIds.size === 0 ||
                  !selectedAuditGroupId
                }
              >
                {assignCasesMutation.isPending ? (
                  <>
                    <Loader2 className="ml-2 h-4 w-4 animate-spin" />
                    در حال اختصاص...
                  </>
                ) : (
                  <>
                    <Users className="ml-2 h-4 w-4" />
                    اختصاص {selectedCaseIds.size} قضیه به گروه
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Assigned Cases Section - Always visible */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base font-semibold">قضایای اختصاص داده شده</CardTitle>
        </CardHeader>
        <CardContent>
          {report.cases.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <AlertCircle className="h-8 w-8 mx-auto mb-2 opacity-50" />
              <p>هیچ قضیه‌ای اختصاص داده نشده است</p>
            </div>
          ) : (
            <div className="space-y-3">
              <div className="text-sm text-muted-foreground">
                تعداد کل: {report.cases.length} قضیه
              </div>
              <div className="border rounded-md max-h-[400px] overflow-y-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="text-right">شماره قضیه</TableHead>
                      <TableHead className="text-right">نام نهاد</TableHead>
                      <TableHead className="text-right">نمبر تشخیصیه</TableHead>
                      <TableHead className="text-right">گروه بررسی</TableHead>
                      <TableHead className="text-right">تاریخ اختصاص</TableHead>
                      <TableHead className="text-right">منبع اختصاص</TableHead>
                      <TableHead className="text-right">وضعیت فعلی</TableHead>
                      <TableHead className="text-right">اختصاص داده شده توسط</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {report.cases.map((caseItem) => (
                      <TableRow key={caseItem.assignmentId}>
                        <TableCell className="font-medium text-right">
                          <span dir="ltr">{caseItem.caseNumber || caseItem.caseId}</span>
                        </TableCell>
                        <TableCell className="text-right">{caseItem.entityName || 'نامشخص'}</TableCell>
                        <TableCell className="text-right">
                          <span dir="ltr">{caseItem.tin || '-'}</span>
                        </TableCell>
                        <TableCell className="text-right">{caseItem.auditGroupName || 'نامشخص'}</TableCell>
                        <TableCell className="text-right">{formatShamsiDate(caseItem.assignmentDate)}</TableCell>
                        <TableCell className="text-right">{getAssignmentSourceLabel(caseItem.assignmentSource)}</TableCell>
                        <TableCell className="text-right">
                          <StatusBadge status={caseItem.caseCurrentStatus} />
                        </TableCell>
                        <TableCell className="text-right">{caseItem.assignedByName || 'نامشخص'}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

