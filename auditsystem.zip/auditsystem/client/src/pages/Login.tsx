import { useState } from 'react';
import { useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import ChangePasswordDialog from '@/components/ChangePasswordDialog';
import { Eye, EyeOff, Moon, Sun } from 'lucide-react';
import { useTheme } from 'next-themes';

export default function Login() {
  const [, setLocation] = useLocation();
  const { login, refresh } = useAuth();
  const { toast } = useToast();
  const { theme, setTheme } = useTheme();
  const [auditId, setAuditId] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [currentPasswordForChange, setCurrentPasswordForChange] = useState('');
  const [rememberMe, setRememberMe] = useState(false);
  const [forgotDialogOpen, setForgotDialogOpen] = useState(false);
  const [forgotAuditId, setForgotAuditId] = useState('');
  const [forgotGroupId, setForgotGroupId] = useState('');
  const [forgotPhone, setForgotPhone] = useState('');
  const [changePasswordOpen, setChangePasswordOpen] = useState(false);
  const [requirePasswordChange, setRequirePasswordChange] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await login(auditId, password);
      
      // After successful login, check if user needs to change password
      const meResponse = await fetch('/api/auth/me', { credentials: 'include' });
      if (meResponse.ok) {
        const userData = await meResponse.json();
        const user = userData.user;
        
        // Check if password change is required
        if (user.mustChangePassword || (user.passwordExpiresAt && new Date() > new Date(user.passwordExpiresAt))) {
          setRequirePasswordChange(true);
          setCurrentPasswordForChange(password); // Store current password for change dialog
          setChangePasswordOpen(true);
          toast({
            title: 'تغییر رمز عبور الزامی',
            description: 'شما باید رمز عبور خود را تغییر دهید',
          });
          return;
        }
      }
      
      toast({
        title: 'ورود موفقیت آمیز',
        description: 'به سیستم آمریت بررسی خوش آمدید',
      });
      setLocation('/');
    } catch (error: any) {
      toast({
        title: 'خطا',
        description: error.message || 'آی دی بررسی یا رمز عبور نادرست است',
        variant: 'destructive',
      });
    }
  };

  const handlePasswordChangeSuccess = async (newPassword: string) => {
    toast({
      title: 'موفق',
      description: 'رمز عبور با موفقیت تغییر یافت. در حال ورود مجدد...',
    });
    setChangePasswordOpen(false);
    setRequirePasswordChange(false);
    
    // Re-authenticate with the new password to ensure session is valid
    try {
      await login(auditId, newPassword);
      toast({
        title: 'ورود موفقیت آمیز',
        description: 'به سیستم آمریت بررسی خوش آمدید',
      });
      setLocation('/');
    } catch (error) {
      toast({
        title: 'خطا',
        description: 'لطفا دوباره وارد شوید',
        variant: 'destructive',
      });
    }
  };

  const handleForgotPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const response = await fetch('/api/tickets/lost-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          auditId: forgotAuditId,
          groupId: forgotGroupId,
          phoneNumber: forgotPhone,
          description: 'درخواست بازیابی رمز عبور از صفحه ورود',
        }),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'خطا در ایجاد تکت');
      }

      const data = await response.json();
      toast({
        title: 'تکت ایجاد شد',
        description: `شماره تکت شما: ${data.ticketId}. لطفا منتظر بمانید تا مدیر سیستم رمز عبور شما را بازنشانی کند.`,
      });
      setForgotDialogOpen(false);
      setForgotAuditId('');
      setForgotGroupId('');
      setForgotPhone('');
      // DO NOT auto-login - user must wait for admin approval
    } catch (error: any) {
      toast({
        title: 'خطا',
        description: error.message || 'خطا در ایجاد تکت',
        variant: 'destructive',
      });
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-muted/30 p-4 sm:p-6 md:p-8 relative">
      {/* Theme Toggle */}
      <div className="absolute top-4 left-4 sm:top-6 sm:left-6">
        <Button
          variant="ghost"
          size="icon"
          onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
          data-testid="button-theme-toggle"
          className="h-9 w-9"
          aria-label="تبدیل تم"
        >
          <Sun className="h-5 w-5 rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0" />
          <Moon className="absolute h-5 w-5 rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100" />
          <span className="sr-only">تبدیل تم</span>
        </Button>
      </div>
      
      <Card className="w-full max-w-md shadow-lg">
        <CardHeader className="text-center space-y-3 pb-6">
          <CardTitle className="text-2xl sm:text-3xl font-bold">سیستم آمریت بررسی</CardTitle>
          <CardDescription className="text-base sm:text-lg">وزارت مالیه</CardDescription>
        </CardHeader>
        <CardContent className="space-y-5">
          <form onSubmit={handleLogin} className="space-y-5">
            <div className="space-y-2">
              <Label htmlFor="audit-id" className="text-sm font-medium">آی دی بررسی (Audit ID)</Label>
              <Input
                id="audit-id"
                placeholder="AUD-xxxxx"
                value={auditId}
                onChange={(e) => setAuditId(e.target.value)}
                data-testid="input-audit-id"
                className="text-right h-11"
                autoComplete="username"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password" className="text-sm font-medium">رمز عبور</Label>
              <div className="relative">
                <Input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  data-testid="input-password"
                  className="text-right pr-11 h-11"
                  autoComplete="current-password"
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  className="absolute right-0 top-1/2 -translate-y-1/2 h-9 w-9 mr-1 hover:bg-transparent"
                  onClick={() => setShowPassword(!showPassword)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' || e.key === ' ') {
                      e.preventDefault();
                      setShowPassword(!showPassword);
                    }
                  }}
                  data-testid="button-toggle-password"
                  aria-label={showPassword ? "مخفی کردن رمز عبور" : "نمایش رمز عبور"}
                  tabIndex={0}
                >
                  {showPassword ? (
                    <EyeOff className="h-4 w-4 text-muted-foreground" />
                  ) : (
                    <Eye className="h-4 w-4 text-muted-foreground" />
                  )}
                  <span className="sr-only">نمایش/مخفی کردن رمز عبور</span>
                </Button>
              </div>
            </div>
            <div className="flex items-center space-x-2 space-x-reverse pt-1">
              <Checkbox
                id="remember"
                checked={rememberMe}
                onCheckedChange={(checked) => setRememberMe(checked as boolean)}
                data-testid="checkbox-remember"
              />
              <Label htmlFor="remember" className="cursor-pointer text-sm">
                مرا به خاطر بسپار
              </Label>
            </div>
            <Button type="submit" className="w-full h-11 text-base font-medium" data-testid="button-login">
              ورود
            </Button>
            <Dialog open={forgotDialogOpen} onOpenChange={setForgotDialogOpen}>
              <DialogTrigger asChild>
                <Button variant="ghost" className="w-full" data-testid="button-forgot-password">
                  فراموشی رمز عبور
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>بازیابی رمز عبور</DialogTitle>
                  <DialogDescription>
                    لطفاً اطلاعات زیر را وارد کنید. یک تکت برای شما ایجاد می‌شود.
                  </DialogDescription>
                </DialogHeader>
                <form onSubmit={handleForgotPassword} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="forgot-audit-id">آی دی بررسی</Label>
                    <Input
                      id="forgot-audit-id"
                      value={forgotAuditId}
                      onChange={(e) => setForgotAuditId(e.target.value)}
                      data-testid="input-forgot-audit-id"
                      className="text-right"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="forgot-group-id">گروه</Label>
                    <Input
                      id="forgot-group-id"
                      value={forgotGroupId}
                      onChange={(e) => setForgotGroupId(e.target.value)}
                      data-testid="input-forgot-group-id"
                      placeholder="شناسه گروه (مثال: group-1)"
                      className="text-right"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="forgot-phone">شماره تماس (واتساپ)</Label>
                    <Input
                      id="forgot-phone"
                      type="tel"
                      value={forgotPhone}
                      onChange={(e) => setForgotPhone(e.target.value)}
                      data-testid="input-forgot-phone"
                      className="text-right"
                    />
                  </div>
                  <Button type="submit" className="w-full" data-testid="button-submit-forgot">
                    ارسال درخواست
                  </Button>
                </form>
              </DialogContent>
            </Dialog>
          </form>
        </CardContent>
      </Card>
      
      <ChangePasswordDialog
        open={changePasswordOpen}
        onOpenChange={setChangePasswordOpen}
        onSuccess={handlePasswordChangeSuccess}
        required={requirePasswordChange}
        currentPasswordValue={currentPasswordForChange}
      />
    </div>
  );
}
