import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Plus, Search, Edit, Power, PowerOff, Copy, Check, Trash2 } from 'lucide-react';
import RoleBadge from '@/components/RoleBadge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import type { User, InsertUser } from '@shared/schema';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';
import { userHasPermission, clearPermissionCache } from '@/utils/permissions';
import { useLocation } from 'wouter';

export default function Users() {
  const [searchQuery, setSearchQuery] = useState('');
  const [createDialogOpen, setCreateDialogOpen] = useState(false);
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [activateDialogOpen, setActivateDialogOpen] = useState(false);
  const [deactivateDialogOpen, setDeactivateDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [actionUser, setActionUser] = useState<User | null>(null);
  const [credentialsDialogOpen, setCredentialsDialogOpen] = useState(false);
  const [createdCredentials, setCreatedCredentials] = useState<{ auditId: string; password: string } | null>(null);
  const [copiedField, setCopiedField] = useState<'auditId' | 'password' | null>(null);
  const [formData, setFormData] = useState({
    fullName: '',
    role: '',
    groupId: '',
    phoneNumber: '',
    permissionPackages: [] as string[],
  });
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { user: currentUser, loading: authLoading, refresh: refreshAuth } = useAuth();
  const [, setLocation] = useLocation();

  const hasUserManagementPermission = currentUser && userHasPermission(currentUser, 'users:manage');
  const isSystemAdmin = currentUser?.role === 'system_admin';

  const { data: users = [], isLoading } = useQuery<User[]>({
    queryKey: ['users'],
    queryFn: async () => {
      const response = await fetch('/api/users', { credentials: 'include' });
      if (!response.ok) throw new Error('Failed to fetch users');
      return response.json();
    },
    enabled: !authLoading && !!currentUser && hasUserManagementPermission,
  });

  // Fetch groups for user assignment
  // System admin sees all groups, others see audit department groups only
  const { data: auditDepartmentGroups = [], isLoading: groupsLoading, error: groupsError } = useQuery<any[]>({
    queryKey: ['groups', 'user-creation'],
    queryFn: async () => {
      // System admin can see all groups, others see only audit department groups
      const url = isSystemAdmin ? '/api/groups' : '/api/groups?department=audit';
      const response = await fetch(url, { credentials: 'include' });
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({ message: 'Failed to fetch groups' }));
        throw new Error(errorData.message || 'Failed to fetch groups');
      }
      return response.json();
    },
    enabled: !authLoading && !!currentUser && hasUserManagementPermission,
  });

  // Redirect if user doesn't have permission
  if (!authLoading && currentUser && !hasUserManagementPermission) {
    return (
      <div className="p-8">
        <div className="text-center">
          <h2 className="text-2xl font-semibold mb-4">عدم دسترسی</h2>
          <p className="text-muted-foreground mb-4">شما مجوز دسترسی به این صفحه را ندارید.</p>
          <button
            onClick={() => setLocation('/')}
            className="text-blue-600 hover:underline"
          >
            بازگشت به داشبورد
          </button>
        </div>
      </div>
    );
  }

  const filteredUsers = users.filter((user) => {
    const query = searchQuery.toLowerCase();
    return (
      user.fullName.toLowerCase().includes(query) ||
      user.auditId.toLowerCase().includes(query)
    );
  });

  const createUserMutation = useMutation({
    mutationFn: async (data: Partial<InsertUser>) => {
      const response = await fetch('/api/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
        credentials: 'include',
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to create user');
      }
      return response.json();
    },
    onSuccess: (data) => {
      // CRITICAL: Invalidate both users and groups queries to sync UI
      queryClient.invalidateQueries({ queryKey: ['users'] });
      queryClient.invalidateQueries({ queryKey: ['groups'] });
      setCreateDialogOpen(false);
      setFormData({ fullName: '', role: '', groupId: '', phoneNumber: '', permissionPackages: [] });
      // Show credentials dialog instead of toast
      setCreatedCredentials({
        auditId: data.auditId,
        password: data.password,
      });
      setCredentialsDialogOpen(true);
    },
    onError: (error: any) => {
      toast({
        title: 'خطا',
        description: error.message || 'ایجاد کاربر با مشکل مواجه شد',
        variant: 'destructive',
      });
    },
  });

  const updateUserMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: Partial<InsertUser> }) => {
      const response = await fetch(`/api/users/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
        credentials: 'include',
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to update user');
      }
      return response.json();
    },
    onSuccess: async (responseData, variables) => {
      // Check if permissions were changed (backend returns this flag)
      const permissionsChanged = responseData.permissionsChanged === true;
      const effectivePermissions = responseData.effectivePermissions;
      const modules = responseData.modules;
      
      // If permissions changed, clear permission cache to force refresh
      if (permissionsChanged) {
        clearPermissionCache();
        
        // If updating the current user, refresh their session immediately
        if (editingUser && editingUser.id === currentUser?.id) {
          // User's own permissions changed - refresh immediately
          try {
            // Refresh auth context to get updated permissions
            await refreshAuth();
            
            // Invalidate all queries to force UI refresh
            queryClient.invalidateQueries();
            
            // Show modules that should now be visible
            const modulesList = modules && modules.length > 0 
              ? modules.join(', ') 
              : 'هیچ ماژولی';
            
            toast({
              title: 'موفق',
              description: `دسترسی‌های شما بروز رسانی شد. ماژول‌های قابل دسترسی: ${modulesList}`,
              variant: 'default',
            });
          } catch (error) {
            console.error('Failed to refresh user permissions:', error);
            toast({
              title: 'اطلاع',
              description: 'دسترسی‌های شما تغییر کرده است. لطفاً صفحه را رفرش کنید تا تغییرات اعمال شود.',
              variant: 'default',
            });
          }
        } else {
          // Another user's permissions changed - show what modules they now have access to
          const modulesList = modules && modules.length > 0 
            ? modules.join(', ') 
            : 'هیچ ماژولی';
          
          toast({
            title: 'موفق',
            description: `کاربر و دسترسی‌هایش با موفقیت بروز رسانی شد. ماژول‌های قابل دسترسی: ${modulesList}. کاربر باید دوباره وارد شود تا تغییرات اعمال شود.`,
          });
        }
      } else {
        toast({
          title: 'موفق',
          description: 'اطلاعات کاربر با موفقیت بروز رسانی شد',
        });
      }
      
      queryClient.invalidateQueries({ queryKey: ['users'] });
      setEditDialogOpen(false);
      setEditingUser(null);
      setFormData({ fullName: '', role: '', groupId: '', phoneNumber: '', permissionPackages: [] });
    },
    onError: (error: any) => {
      toast({
        title: 'خطا',
        description: error.message || 'بروز رسانی کاربر با مشکل مواجه شد',
        variant: 'destructive',
      });
    },
  });

  const activateUserMutation = useMutation({
    mutationFn: async (id: string) => {
      const response = await fetch(`/api/users/${id}/activate`, {
        method: 'POST',
        credentials: 'include',
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to activate user');
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['users'] });
      setActivateDialogOpen(false);
      setActionUser(null);
      toast({
        title: 'موفق',
        description: 'کاربر با موفقیت فعال شد',
      });
    },
    onError: (error: any) => {
      toast({
        title: 'خطا',
        description: error.message || 'فعال کردن کاربر با مشکل مواجه شد',
        variant: 'destructive',
      });
    },
  });

  const deactivateUserMutation = useMutation({
    mutationFn: async (id: string) => {
      const response = await fetch(`/api/users/${id}/deactivate`, {
        method: 'POST',
        credentials: 'include',
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to deactivate user');
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['users'] });
      setDeactivateDialogOpen(false);
      setActionUser(null);
      toast({
        title: 'موفق',
        description: 'کاربر با موفقیت غیرفعال شد',
      });
    },
    onError: (error: any) => {
      toast({
        title: 'خطا',
        description: error.message || 'غیرفعال کردن کاربر با مشکل مواجه شد',
        variant: 'destructive',
      });
    },
  });

  const deleteUserMutation = useMutation({
    mutationFn: async (id: string) => {
      const response = await fetch(`/api/users/${id}`, {
        method: 'DELETE',
        credentials: 'include',
      });
      if (!response.ok) {
        let errorMessage = 'Failed to delete user';
        try {
          const contentType = response.headers.get('content-type');
          if (contentType && contentType.includes('application/json')) {
            const error = await response.json();
            errorMessage = error.message || errorMessage;
          } else {
            // If response is not JSON (e.g., HTML error page), use status text
            errorMessage = `Server error: ${response.status} ${response.statusText}`;
          }
        } catch (e) {
          errorMessage = `Server error: ${response.status} ${response.statusText}`;
        }
        throw new Error(errorMessage);
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['users'] });
      setDeleteDialogOpen(false);
      setActionUser(null);
      toast({
        title: 'موفق',
        description: 'کاربر با موفقیت حذف شد',
      });
    },
    onError: (error: any) => {
      toast({
        title: 'خطا',
        description: error.message || 'حذف کاربر با مشکل مواجه شد',
        variant: 'destructive',
      });
    },
  });

  // Helper function to map checkbox values to actual package names
  const mapCheckboxToPackage = (checkboxValue: string): string => {
    if (checkboxValue === 'coordinator') return 'acting_coordinator';
    if (checkboxValue === 'approval') return 'approval_authority';
    return checkboxValue;
  };

  // Helper function to map package names to checkbox values
  const mapPackageToCheckbox = (packageName: string): string => {
    if (packageName === 'acting_coordinator') return 'coordinator';
    if (packageName === 'approval_authority') return 'approval';
    return packageName;
  };

  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Map checkbox values to actual package names before submitting
    const mappedPackages = formData.permissionPackages.map(mapCheckboxToPackage);
    // Convert __none__ to empty string for groupId
    const submitData = {
      ...formData,
      groupId: formData.groupId === '__none__' ? '' : formData.groupId,
      permissionPackages: mappedPackages,
    };
    createUserMutation.mutate(submitData);
  };

  const handleEditSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingUser) return;
    // Map checkbox values to actual package names before submitting
    const mappedPackages = formData.permissionPackages.map(mapCheckboxToPackage);
    // Convert __none__ to empty string for groupId
    const submitData = {
      ...formData,
      groupId: formData.groupId === '__none__' ? '' : formData.groupId,
      permissionPackages: mappedPackages,
    };
    updateUserMutation.mutate({ id: editingUser.id, data: submitData });
  };

  const handleEdit = (user: User) => {
    setEditingUser(user);
    // Map actual package names to checkbox values when loading user for editing
    const checkboxPackages = (user.permissionPackages || []).map(mapPackageToCheckbox);
    setFormData({
      fullName: user.fullName,
      role: user.role,
      groupId: user.groupId || '__none__',
      phoneNumber: user.phoneNumber || '',
      permissionPackages: checkboxPackages,
    });
    setEditDialogOpen(true);
  };

  const handleActivate = (user: User) => {
    setActionUser(user);
    setActivateDialogOpen(true);
  };

  const handleDeactivate = (user: User) => {
    setActionUser(user);
    setDeactivateDialogOpen(true);
  };

  const handleDelete = (user: User) => {
    setActionUser(user);
    setDeleteDialogOpen(true);
  };

  const confirmActivate = () => {
    if (actionUser) {
      activateUserMutation.mutate(actionUser.id);
    }
  };

  const confirmDeactivate = () => {
    if (actionUser) {
      deactivateUserMutation.mutate(actionUser.id);
    }
  };

  const confirmDelete = () => {
    if (actionUser) {
      deleteUserMutation.mutate(actionUser.id);
    }
  };

  const copyToClipboard = async (text: string, field: 'auditId' | 'password') => {
    if (!text) {
      toast({
        title: 'خطا',
        description: 'مقداری برای کپی وجود ندارد',
        variant: 'destructive',
      });
      return;
    }

    try {
      // Try modern clipboard API first (requires HTTPS or localhost)
      if (navigator.clipboard && navigator.clipboard.writeText) {
        await navigator.clipboard.writeText(text);
      } else {
        // Fallback for older browsers or non-HTTPS
        const textArea = document.createElement('textarea');
        textArea.value = text;
        textArea.style.position = 'fixed';
        textArea.style.left = '-999999px';
        textArea.style.top = '-999999px';
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();
        try {
          document.execCommand('copy');
        } catch (err) {
          throw new Error('Copy command failed');
        }
        document.body.removeChild(textArea);
      }
      
      setCopiedField(field);
      setTimeout(() => setCopiedField(null), 2000);
      toast({
        title: 'کپی شد',
        description: 'مقدار با موفقیت در کلیپ‌بورد کپی شد',
      });
    } catch (error) {
      console.error('Copy failed:', error);
      toast({
        title: 'خطا',
        description: 'کپی کردن با مشکل مواجه شد. لطفاً به صورت دستی کپی کنید.',
        variant: 'destructive',
      });
    }
  };

  return (
    <div className="p-8 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-semibold">مدیریت کاربران</h1>
          <p className="text-muted-foreground">مدیریت کاربران و دسترسی‌ های سیستم</p>
        </div>
        <Dialog open={createDialogOpen} onOpenChange={setCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button data-testid="button-create-user">
              <Plus className="ml-2 h-4 w-4" />
              کاربر جدید
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>ایجاد کاربر جدید</DialogTitle>
              <DialogDescription>
                اطلاعات کاربر جدید را وارد کنید. آی دی بررسی و رمز عبور به صورت خودکار تولید می‌شود.
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleCreateSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="create-fullName">نام کامل *</Label>
                  <Input
                    id="create-fullName"
                    value={formData.fullName}
                    onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                    data-testid="input-full-name"
                    className="text-right"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="create-phoneNumber">شماره تماس</Label>
                  <Input
                    id="create-phoneNumber"
                    type="tel"
                    value={formData.phoneNumber}
                    onChange={(e) => setFormData({ ...formData, phoneNumber: e.target.value })}
                    data-testid="input-phone"
                    className="text-right"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="create-role">نقش *</Label>
                  <Select value={formData.role} onValueChange={(v) => setFormData({ ...formData, role: v })}>
                    <SelectTrigger id="create-role" data-testid="select-role">
                      <SelectValue placeholder="انتخاب کنید" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="system_admin">مدیر سیستم</SelectItem>
                      <SelectItem value="director">آمر بررسی</SelectItem>
                      <SelectItem value="senior_auditor">مدیر عمومی گروه</SelectItem>
                      <SelectItem value="auditor">بررس</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="create-groupId">گروه</Label>
                  <Select 
                    value={formData.groupId || undefined} 
                    onValueChange={(v) => setFormData({ ...formData, groupId: v === '__none__' ? '' : v })}
                    disabled={groupsLoading}
                  >
                    <SelectTrigger id="create-groupId" data-testid="select-group">
                      <SelectValue placeholder={groupsLoading ? "در حال بارگذاری..." : groupsError ? "خطا در بارگذاری" : auditDepartmentGroups.length === 0 ? "گروهی یافت نشد" : "انتخاب کنید"} />
                    </SelectTrigger>
                    <SelectContent>
                      {groupsLoading ? (
                        <SelectItem value="__loading__" disabled>در حال بارگذاری...</SelectItem>
                      ) : groupsError ? (
                        <SelectItem value="__error__" disabled>خطا در بارگذاری گروه‌ها</SelectItem>
                      ) : auditDepartmentGroups.length === 0 ? (
                        <SelectItem value="__empty__" disabled>گروهی یافت نشد</SelectItem>
                      ) : (
                        <>
                          <SelectItem value="__none__">بدون گروه</SelectItem>
                          {auditDepartmentGroups.map((group) => (
                            <SelectItem key={group.id} value={group.id}>
                              {group.name} {group.namePashto ? `(${group.namePashto})` : ''}
                            </SelectItem>
                          ))}
                        </>
                      )}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="space-y-2">
                <Label>بسته‌های دسترسی موقت</Label>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2 space-x-reverse">
                    <Checkbox
                      id="create-pkg-coordinator"
                      checked={formData.permissionPackages.includes('coordinator')}
                      onCheckedChange={(checked) => {
                        const packages = checked
                          ? [...formData.permissionPackages, 'coordinator']
                          : formData.permissionPackages.filter((p) => p !== 'coordinator');
                        setFormData({ ...formData, permissionPackages: packages });
                      }}
                      data-testid="checkbox-coordinator"
                    />
                    <Label htmlFor="create-pkg-coordinator" className="cursor-pointer">هماهنگ کننده موقت</Label>
                  </div>
                  <div className="flex items-center space-x-2 space-x-reverse">
                    <Checkbox
                      id="create-pkg-approval"
                      checked={formData.permissionPackages.includes('approval')}
                      onCheckedChange={(checked) => {
                        const packages = checked
                          ? [...formData.permissionPackages, 'approval']
                          : formData.permissionPackages.filter((p) => p !== 'approval');
                        setFormData({ ...formData, permissionPackages: packages });
                      }}
                      data-testid="checkbox-approval"
                    />
                    <Label htmlFor="create-pkg-approval" className="cursor-pointer">صلاحیت منظوری</Label>
                  </div>
                </div>
              </div>
              <div className="flex gap-2 justify-end">
                <Button type="button" variant="outline" onClick={() => setCreateDialogOpen(false)} data-testid="button-cancel">
                  لغو
                </Button>
                <Button type="submit" data-testid="button-submit-user">ایجاد کاربر</Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>ویرایش کاربر</DialogTitle>
            <DialogDescription>
              اطلاعات کاربر را ویرایش کنید.
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleEditSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="edit-fullName">نام کامل *</Label>
                <Input
                  id="edit-fullName"
                  value={formData.fullName}
                  onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                  className="text-right"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-phoneNumber">شماره تماس</Label>
                <Input
                  id="edit-phoneNumber"
                  type="tel"
                  value={formData.phoneNumber}
                  onChange={(e) => setFormData({ ...formData, phoneNumber: e.target.value })}
                  className="text-right"
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="edit-role">نقش *</Label>
                <Select value={formData.role} onValueChange={(v) => setFormData({ ...formData, role: v })}>
                  <SelectTrigger id="edit-role">
                    <SelectValue placeholder="انتخاب کنید" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="system_admin">مدیر سیستم</SelectItem>
                    <SelectItem value="director">آمر بررسی</SelectItem>
                    <SelectItem value="senior_auditor">مدیر عمومی گروه</SelectItem>
                    <SelectItem value="auditor">بررس</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-groupId">گروه</Label>
                <Select value={formData.groupId || '__none__'} onValueChange={(v) => setFormData({ ...formData, groupId: v === '__none__' ? '' : v })}>
                  <SelectTrigger id="edit-groupId">
                    <SelectValue placeholder="انتخاب کنید" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="__none__">بدون گروه</SelectItem>
                    {auditDepartmentGroups.map((group) => (
                      <SelectItem key={group.id} value={group.id}>
                        {group.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-2">
              <Label>بسته‌های دسترسی موقت</Label>
              <div className="space-y-2">
                <div className="flex items-center space-x-2 space-x-reverse">
                  <Checkbox
                    id="edit-pkg-coordinator"
                    checked={formData.permissionPackages.includes('coordinator')}
                    onCheckedChange={(checked) => {
                      const packages = checked
                        ? [...formData.permissionPackages, 'coordinator']
                        : formData.permissionPackages.filter((p) => p !== 'coordinator');
                      setFormData({ ...formData, permissionPackages: packages });
                    }}
                  />
                  <Label htmlFor="edit-pkg-coordinator" className="cursor-pointer">هماهنگ کننده موقت</Label>
                </div>
                <div className="flex items-center space-x-2 space-x-reverse">
                  <Checkbox
                    id="edit-pkg-approval"
                    checked={formData.permissionPackages.includes('approval')}
                    onCheckedChange={(checked) => {
                      const packages = checked
                        ? [...formData.permissionPackages, 'approval']
                        : formData.permissionPackages.filter((p) => p !== 'approval');
                      setFormData({ ...formData, permissionPackages: packages });
                    }}
                  />
                  <Label htmlFor="edit-pkg-approval" className="cursor-pointer">صلاحیت منظوری</Label>
                </div>
              </div>
            </div>
            <div className="flex gap-2 justify-between items-center">
              <Button 
                type="button" 
                variant="outline" 
                onClick={async () => {
                  if (!editingUser) return;
                  try {
                    const response = await fetch(`/api/users/${editingUser.id}/reset-password`, {
                      method: 'POST',
                      credentials: 'include',
                    });
                    if (!response.ok) {
                      const error = await response.json();
                      throw new Error(error.message || 'Failed to reset password');
                    }
                    const data = await response.json();
                    setCreatedCredentials({
                      auditId: editingUser.auditId,
                      password: data.password,
                    });
                    setCredentialsDialogOpen(true);
                    toast({
                      title: 'موفق',
                      description: 'رمز عبور با موفقیت بازنشانی شد',
                    });
                  } catch (error: any) {
                    toast({
                      title: 'خطا',
                      description: error.message || 'بازنشانی رمز عبور با مشکل مواجه شد',
                      variant: 'destructive',
                    });
                  }
                }}
                data-testid="button-reset-password"
              >
                بازنشانی رمز عبور
              </Button>
              <div className="flex gap-2">
                <Button type="button" variant="outline" onClick={() => setEditDialogOpen(false)}>
                  لغو
                </Button>
                <Button type="submit">ذخیره تغییرات</Button>
              </div>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      <AlertDialog open={activateDialogOpen} onOpenChange={setActivateDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>فعال کردن کاربر</AlertDialogTitle>
            <AlertDialogDescription>
              آیا مطمئن هستید که می‌خواهید کاربر "{actionUser?.fullName}" را فعال کنید؟
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>لغو</AlertDialogCancel>
            <AlertDialogAction onClick={confirmActivate}>فعال کردن</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AlertDialog open={deactivateDialogOpen} onOpenChange={setDeactivateDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>غیرفعال کردن کاربر</AlertDialogTitle>
            <AlertDialogDescription>
              آیا مطمئن هستید که می‌خواهید کاربر "{actionUser?.fullName}" را غیرفعال کنید؟
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>لغو</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDeactivate} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              غیرفعال کردن
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>حذف دائمی کاربر</AlertDialogTitle>
            <AlertDialogDescription>
              آیا مطمئن هستید که می‌خواهید کاربر "{actionUser?.fullName}" را به صورت دائمی حذف کنید؟ این عمل قابل بازگشت نیست.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>لغو</AlertDialogCancel>
            <AlertDialogAction 
              onClick={confirmDelete} 
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              disabled={deleteUserMutation.isPending}
            >
              {deleteUserMutation.isPending ? 'در حال حذف...' : 'حذف دائمی'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Credentials Dialog */}
      <Dialog open={credentialsDialogOpen} onOpenChange={setCredentialsDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="text-center">اطلاعات ورود کاربر</DialogTitle>
          </DialogHeader>
          <div className="space-y-6 py-4">
            <div className="rounded-lg bg-muted/50 p-4 space-y-3">
              <div className="space-y-2">
                <Label className="text-sm font-medium text-muted-foreground">آی دی بررسی (Username)</Label>
                <div className="flex items-center gap-2">
                  <Input
                    value={createdCredentials?.auditId || ''}
                    readOnly
                    className="text-right font-mono bg-background"
                  />
                  <Button
                    type="button"
                    variant="outline"
                    size="icon"
                    onClick={() => createdCredentials && copyToClipboard(createdCredentials.auditId, 'auditId')}
                    className="shrink-0"
                  >
                    {copiedField === 'auditId' ? (
                      <Check className="h-4 w-4 text-green-600" />
                    ) : (
                      <Copy className="h-4 w-4" />
                    )}
                  </Button>
                </div>
              </div>
              <div className="space-y-2">
                <Label className="text-sm font-medium text-muted-foreground">رمز عبور (Password)</Label>
                <div className="flex items-center gap-2">
                  <Input
                    value={createdCredentials?.password || ''}
                    readOnly
                    className="text-right font-mono bg-background"
                  />
                  <Button
                    type="button"
                    variant="outline"
                    size="icon"
                    onClick={() => createdCredentials && copyToClipboard(createdCredentials.password, 'password')}
                    className="shrink-0"
                  >
                    {copiedField === 'password' ? (
                      <Check className="h-4 w-4 text-green-600" />
                    ) : (
                      <Copy className="h-4 w-4" />
                    )}
                  </Button>
                </div>
              </div>
            </div>
            <div className="rounded-lg border border-amber-200 dark:border-amber-800 bg-amber-50 dark:bg-amber-950/20 p-3">
              <p className="text-sm text-amber-800 dark:text-amber-200 text-center">
                ⚠️ لطفاً این اطلاعات را در جای امنی ذخیره کنید. رمز عبور فقط یک بار نمایش داده می‌شود.
              </p>
            </div>
          </div>
          <div className="flex justify-end">
            <Button onClick={() => setCredentialsDialogOpen(false)}>
              بستن
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      <Card>
        <CardHeader>
          <div className="flex items-center gap-4">
            <div className="relative flex-1">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="جستجو بر اساس نام یا آی دی بررسی..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pr-10 text-right"
                data-testid="input-search-users"
              />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="text-center py-8 text-muted-foreground">در حال بارگذاری...</div>
          ) : filteredUsers.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">هیچ کاربری وجود ندارد</div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="text-right">کاربر</TableHead>
                  <TableHead className="text-right">آی دی بررسی</TableHead>
                  <TableHead className="text-right">نقش و دسترسی‌ها</TableHead>
                  <TableHead className="text-right">گروه</TableHead>
                  <TableHead className="text-right">شماره تماس</TableHead>
                  <TableHead className="text-right">وضعیت</TableHead>
                  <TableHead className="text-right">عملیات</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredUsers.map((user) => (
                  <TableRow key={user.id} className="hover-elevate">
                    <TableCell>
                      <div className="flex items-center gap-3">
                        <Avatar>
                          <AvatarFallback>{user.fullName.charAt(0)}</AvatarFallback>
                        </Avatar>
                        <span className="font-medium">{user.fullName}</span>
                      </div>
                    </TableCell>
                    <TableCell>{user.auditId}</TableCell>
                    <TableCell>
                      <RoleBadge role={user.role} permissionPackages={user.permissionPackages || []} />
                    </TableCell>
                    <TableCell>{(user as any).groupName || user.groupId || '—'}</TableCell>
                    <TableCell>{user.phoneNumber || '—'}</TableCell>
                    <TableCell>
                      <Badge variant={user.isActive !== false ? 'default' : 'secondary'}>
                        {user.isActive !== false ? 'فعال' : 'غیرفعال'}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleEdit(user)}
                          data-testid={`button-edit-user-${user.id}`}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        {user.isActive !== false ? (
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleDeactivate(user)}
                            data-testid={`button-deactivate-user-${user.id}`}
                          >
                            <PowerOff className="h-4 w-4 text-destructive" />
                          </Button>
                        ) : (
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleActivate(user)}
                            data-testid={`button-activate-user-${user.id}`}
                          >
                            <Power className="h-4 w-4 text-green-600" />
                          </Button>
                        )}
                        {isSystemAdmin && (
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleDelete(user)}
                            data-testid={`button-delete-user-${user.id}`}
                            className="text-destructive hover:text-destructive"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
