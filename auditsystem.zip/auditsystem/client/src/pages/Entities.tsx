import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogTrigger,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Plus, Search, Edit, Trash2, Filter, FileText, ArrowUpDown, ArrowUp, ArrowDown, Eye } from 'lucide-react';
import StatusBadge from '@/components/StatusBadge';
import ShamsiDatePickerDDMMYYYY, { gregorianToShamsi, shamsiToGregorian } from '@/components/ShamsiDatePickerDDMMYYYY';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import type { Entity, InsertEntity, EntityType, Case } from '@shared/schema';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';
import { userHasPermission } from '@/utils/permissions';
import { useLocation } from 'wouter';
import jalaali from 'jalaali-js';
import { Badge } from '@/components/ui/badge';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import AuditRecordTimeline from '@/components/AuditRecordTimeline';
import {
  Pagination,
  PaginationContent,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from '@/components/ui/pagination';

// Static list of predefined referral groups (گروه ارجاع‌دهنده)
// These are the only groups that can send cases to the audit department
const STATIC_REFERRAL_GROUPS = [
  { id: 'group-1', name: 'گروه اول سنجش ابتدایی' },
  { id: 'group-2', name: 'گروه دوم سنجش ابتدایی' },
  { id: 'group-3', name: 'گروه سوم سنجش ابتدایی' },
  { id: 'group-4', name: 'گروه چهارم سنجش ابتدایی' },
  { id: 'group-5', name: 'گروه پنجم سنجش ابتدایی' },
  { id: 'group-6', name: 'گروه ششم سنجش ابتدایی' },
  { id: 'group-7', name: 'گروه هفتم سنجش ابتدایی' },
  { id: 'group-8', name: 'گروه هشتم سنجش ابتدایی' },
  { id: 'group-9', name: 'گروه نهم سنجش ابتدایی' },
  { id: 'group-10', name: 'مدیریت عمومی تشخیص مالیه دهنده' },
];

export default function Entities() {
  // Entity filter state (replaces tabs)
  const [entityFilter, setEntityFilter] = useState<'all' | 'has-cases' | 'no-cases' | 'newly-added'>('all');
  
  // Search and filters
  const [searchQuery, setSearchQuery] = useState('');
  const [tinFilter, setTinFilter] = useState('');
  const [groupFilter, setGroupFilter] = useState('');
  const [yearFilter, setYearFilter] = useState('');
  const [createdDateFrom, setCreatedDateFrom] = useState('');
  const [createdDateTo, setCreatedDateTo] = useState('');
  const [filtersOpen, setFiltersOpen] = useState(false);
  
  // Sorting
  const [sortField, setSortField] = useState<'createdAt' | 'companyName' | 'tin'>('createdAt');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('desc');
  
  // Pagination
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 20;
  
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [detailDialogOpen, setDetailDialogOpen] = useState(false);
  const [selectedEntity, setSelectedEntity] = useState<Entity | null>(null);
  const [formData, setFormData] = useState({
    companyName: '',
    tin: '',
    businessNature: '',
    notes: '',
    status: 'Active' as 'Active' | 'Dormant', // Only two valid values: Active (فعال) or Dormant (غیر فعال)
  });
  const [editFormData, setEditFormData] = useState({
    companyName: '',
    tin: '',
    businessNature: '',
    notes: '',
    status: 'Active' as 'Active' | 'Under Audit' | 'Dormant' | 'Deleted/Archived',
  });
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { user: currentUser, loading: authLoading } = useAuth();
  const [, setLocation] = useLocation();

  // Check if user has entities:view permission
  const hasViewPermission = currentUser && userHasPermission(currentUser, 'entities:view');
  
  if (!authLoading && currentUser && !hasViewPermission) {
    return (
      <div className="p-8">
        <div className="text-center">
          <h2 className="text-2xl font-semibold mb-4">عدم دسترسی</h2>
          <p className="text-muted-foreground mb-4">شما مجوز دسترسی به این صفحه را ندارید.</p>
          <button
            onClick={() => setLocation('/')}
            className="text-blue-600 hover:underline"
          >
            بازگشت به داشبورد
          </button>
        </div>
      </div>
    );
  }

  const { data: entities = [], isLoading, refetch: refetchEntities } = useQuery<Entity[]>({
    queryKey: ['entities', currentUser?.id, currentUser?.permissionsVersion],
    queryFn: async () => {
      console.log('Fetching entities from API...');
      const response = await fetch('/api/entities', { 
        credentials: 'include',
        cache: 'no-store', // Force fresh data on each request
      });
      if (!response.ok) {
        if (response.status === 403) {
          throw new Error('عدم دسترسی - شما مجوز لازم را ندارید');
        }
        throw new Error('Failed to fetch entities');
      }
      const data = await response.json();
      console.log('Entities fetched from API:', data.length);
      return data;
    },
    enabled: !authLoading && !!currentUser && hasViewPermission,
    staleTime: 0, // Always consider data stale to force fresh fetch
    gcTime: 0, // Don't cache to ensure RBAC is always enforced (gcTime replaces cacheTime in v5)
  });

  // Note: We no longer fetch groups for referralGroup dropdown - it's now static
  // But we still need groups for displaying group names in the table
  const { data: groups = [] } = useQuery<any[]>({
    queryKey: ['groups', 'entities'],
    queryFn: async () => {
      const response = await fetch('/api/groups', { credentials: 'include' });
      if (!response.ok) throw new Error('Failed to fetch groups');
      return response.json();
    },
    enabled: !authLoading && !!currentUser && hasViewPermission,
  });

  const { data: entityTypes = [] } = useQuery<EntityType[]>({
    queryKey: ['entity-types', 'active'],
    queryFn: async () => {
      const response = await fetch('/api/entity-types/active', { credentials: 'include' });
      if (!response.ok) throw new Error('Failed to fetch entity types');
      return response.json();
    },
    enabled: !authLoading && !!currentUser && hasViewPermission,
  });

  // Fetch cases to determine which entities have cases
  const { data: allCases = [] } = useQuery<Case[]>({
    queryKey: ['cases', 'for-entities'],
    queryFn: async () => {
      const response = await fetch('/api/cases', { credentials: 'include' });
      if (!response.ok) return [];
      return response.json();
    },
    enabled: !authLoading && !!currentUser && hasViewPermission,
  });

  const createEntityMutation = useMutation({
    mutationFn: async (data: Partial<InsertEntity>) => {
      const response = await fetch('/api/entities', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
        credentials: 'include',
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to create entity');
      }
      return response.json();
    },
    onSuccess: async (createdEntity) => {
      console.log('Entity created successfully:', createdEntity);
      
      // Close dialog and reset form first
      setDialogOpen(false);
      setFormData({ companyName: '', tin: '', businessNature: '', notes: '', status: 'Active' as 'Active' | 'Dormant' });
      
      // CRITICAL FIX: Reset ALL filters to ensure new entity is visible
      setEntityFilter('all');
      setSearchQuery('');
      setTinFilter('');
      setGroupFilter('');
      setYearFilter('');
      setCreatedDateFrom('');
      setCreatedDateTo('');
      setStatusFilter('all');
      setCurrentPage(1); // Reset to first page
      
      // Update cache optimistically by adding the new entity
      const queryKey = ['entities', currentUser?.id, currentUser?.permissionsVersion];
      console.log('Updating cache with queryKey:', queryKey);
      
      queryClient.setQueryData<Entity[]>(queryKey, (oldData = []) => {
        console.log('Old data length:', oldData?.length || 0);
        // Add new entity to the beginning of the list (most recent first)
        if (!oldData || oldData.length === 0) {
          console.log('No old data, returning new entity only');
          return [createdEntity];
        }
        // Check if entity already exists (avoid duplicates)
        const exists = oldData.some(e => e.id === createdEntity.id);
        if (exists) {
          console.log('Entity already exists in cache, returning old data');
          return oldData;
        }
        console.log('Adding new entity to cache, new length:', oldData.length + 1);
        return [createdEntity, ...oldData];
      });
      
      // Force invalidate and refetch
      console.log('Invalidating queries...');
      queryClient.invalidateQueries({ 
        queryKey: ['entities'],
        exact: false
      });
      
      // Force refetch using the refetch function directly
      console.log('Refetching entities...');
      try {
        const result = await refetchEntities();
        console.log('Refetch completed, entities count:', result.data?.length || 0);
      } catch (error) {
        console.error('Refetch error:', error);
      }
      
      toast({
        title: 'موفق',
        description: 'نهاد جدید با موفقیت ایجاد شد',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'خطا',
        description: error.message || 'ایجاد نهاد با مشکل مواجه شد',
        variant: 'destructive',
      });
    },
  });

  const updateEntityMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: Partial<InsertEntity> }) => {
      const response = await fetch(`/api/entities/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
        credentials: 'include',
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to update entity');
      }
      return response.json();
    },
    onSuccess: () => {
      // CRITICAL FIX: Invalidate with exact query key pattern
      queryClient.invalidateQueries({ 
        queryKey: ['entities'],
        exact: false
      });
      queryClient.refetchQueries({ 
        queryKey: ['entities', currentUser?.id, currentUser?.permissionsVersion]
      });
      setEditDialogOpen(false);
      setSelectedEntity(null);
      toast({
        title: 'موفق',
        description: 'نهاد با موفقیت بروز رسانی شد',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'خطا',
        description: error.message || 'بروز رسانی نهاد با مشکل مواجه شد',
        variant: 'destructive',
      });
    },
  });

  const deleteEntityMutation = useMutation({
    mutationFn: async (id: string) => {
      const response = await fetch(`/api/entities/${id}`, {
        method: 'DELETE',
        credentials: 'include',
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to delete entity');
      }
      return response.json();
    },
    onSuccess: () => {
      // CRITICAL FIX: Invalidate with exact query key pattern
      queryClient.invalidateQueries({ 
        queryKey: ['entities'],
        exact: false
      });
      queryClient.refetchQueries({ 
        queryKey: ['entities', currentUser?.id, currentUser?.permissionsVersion]
      });
      setDeleteDialogOpen(false);
      setSelectedEntity(null);
      toast({
        title: 'موفق',
        description: 'نهاد با موفقیت حذف شد',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'خطا',
        description: error.message || 'حذف نهاد با مشکل مواجه شد',
        variant: 'destructive',
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    // Validate required fields
    if (!formData.status || (formData.status !== 'Active' && formData.status !== 'Dormant')) {
      toast({
        title: 'خطا',
        description: 'لطفاً وضعیت نهاد را انتخاب کنید',
        variant: 'destructive',
      });
      return;
    }

    // Map formData to match API schema - include status field
    const payload: any = {
      companyName: formData.companyName,
      tin: formData.tin,
      businessNature: formData.businessNature,
      status: formData.status, // Required field: 'Active' or 'Dormant'
      notes: formData.notes || undefined,
    };
    
    // Remove undefined fields (but keep status even if empty string)
    Object.keys(payload).forEach(key => {
      if (payload[key] === undefined || (payload[key] === '' && key !== 'status')) {
        delete payload[key];
      }
    });
    
    createEntityMutation.mutate(payload);
  };

  const handleEdit = (entity: Entity) => {
    setSelectedEntity(entity);
    
    setEditFormData({
      companyName: entity.companyName,
      tin: entity.tin,
      businessNature: entity.businessNature,
      notes: entity.notes || '',
      status: (entity.status as 'Active' | 'Under Audit' | 'Dormant' | 'Deleted/Archived') || 'Active',
    });
    setEditDialogOpen(true);
  };

  const handleDelete = (entity: Entity) => {
    setSelectedEntity(entity);
    setDeleteDialogOpen(true);
  };

  const handleEditSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedEntity) {
      // Map formData to match API schema - only permanent identity fields
      const submitData: any = {
        companyName: editFormData.companyName,
        tin: editFormData.tin,
        businessNature: editFormData.businessNature,
        notes: editFormData.notes || undefined,
      };
      // Remove undefined or empty fields
      Object.keys(submitData).forEach(key => {
        if (submitData[key] === undefined || submitData[key] === '') {
          delete submitData[key];
        }
      });
      updateEntityMutation.mutate({ id: selectedEntity.id, data: submitData });
    }
  };

  const confirmDelete = () => {
    if (selectedEntity) {
      deleteEntityMutation.mutate(selectedEntity.id);
    }
  };

  return (
    <div className="p-8 space-y-6" dir="rtl" style={{ direction: 'rtl', textAlign: 'right' }}>
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-semibold">مدیریت نهادها و شرکت‌ها</h1>
          <p className="text-muted-foreground">مدیریت اطلاعات شرکت‌ها و نهادهای تحت بررسی</p>
        </div>
        <div className="flex gap-2">
          <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
            <DialogTrigger asChild>
              <Button data-testid="button-create-entity">
                <Plus className="ml-2 h-4 w-4" />
                نهاد جدید
              </Button>
            </DialogTrigger>
          <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>ثبت نهاد جدید</DialogTitle>
              <DialogDescription>
                اطلاعات نهاد یا شرکت جدید را وارد کنید.
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="companyName">نام نهاد *</Label>
                  <Input
                    id="companyName"
                    value={formData.companyName}
                    onChange={(e) => setFormData({ ...formData, companyName: e.target.value })}
                    data-testid="input-company-name"
                    className="text-right"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="tin">نمبر تشخیصیه (TIN) *</Label>
                  <Input
                    id="tin"
                    value={formData.tin}
                    onChange={(e) => setFormData({ ...formData, tin: e.target.value })}
                    data-testid="input-tin"
                    className="text-right"
                    required
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="businessNature">ماهیت تشبث *</Label>
                  <Select value={formData.businessNature} onValueChange={(v) => setFormData({ ...formData, businessNature: v })}>
                    <SelectTrigger id="businessNature" data-testid="select-business-nature" className="text-right" dir="rtl">
                      <SelectValue placeholder="انتخاب کنید" />
                    </SelectTrigger>
                    <SelectContent dir="rtl">
                      {entityTypes.map((type) => (
                        <SelectItem key={type.id} value={type.name}>
                          {type.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="status">وضعیت نهاد *</Label>
                  <Select 
                    value={formData.status} 
                    onValueChange={(v: 'Active' | 'Dormant') => setFormData({ ...formData, status: v })}
                    required
                  >
                    <SelectTrigger id="status" className="text-right" dir="rtl">
                      <SelectValue placeholder="انتخاب کنید" />
                    </SelectTrigger>
                    <SelectContent dir="rtl">
                      <SelectItem value="Active">فعال</SelectItem>
                      <SelectItem value="Dormant">غیر فعال</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="notes">ملاحظات</Label>
                <Textarea
                  id="notes"
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  data-testid="textarea-notes"
                  className="text-right"
                />
              </div>
              <div className="flex gap-2 justify-end">
                <Button type="button" variant="outline" onClick={() => setDialogOpen(false)} data-testid="button-cancel">
                  لغو
                </Button>
                <Button type="submit" data-testid="button-submit-entity">ثبت نهاد</Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
        </div>
      </div>

      <Card dir="rtl" style={{ direction: 'rtl' }}>
        <CardHeader className="space-y-4">
            {/* Filter buttons at the top - horizontal layout */}
            <div className="flex items-center justify-start gap-2 flex-wrap w-full" dir="rtl" style={{ direction: 'rtl' }}>
              <Button
                variant={entityFilter === 'all' ? 'default' : 'outline'}
                size="sm"
                onClick={() => {
                  setEntityFilter('all');
                  setCurrentPage(1);
                }}
                className="text-right"
              >
                همه نهادها
              </Button>
              <Button
                variant={entityFilter === 'has-cases' ? 'default' : 'outline'}
                size="sm"
                onClick={() => {
                  setEntityFilter('has-cases');
                  setCurrentPage(1);
                }}
                className="text-right"
              >
                دارای قضیه
                {(() => {
                  const entityIdsWithCases = new Set(allCases.map(c => c.entityId));
                  const count = entities.filter(e => entityIdsWithCases.has(e.id)).length;
                  return count > 0 ? <Badge variant="secondary" className="mr-2">{count}</Badge> : null;
                })()}
              </Button>
              <Button
                variant={entityFilter === 'no-cases' ? 'default' : 'outline'}
                size="sm"
                onClick={() => {
                  setEntityFilter('no-cases');
                  setCurrentPage(1);
                }}
                className="text-right"
              >
                بدون قضیه
                {(() => {
                  const entityIdsWithCases = new Set(allCases.map(c => c.entityId));
                  const count = entities.filter(e => !entityIdsWithCases.has(e.id)).length;
                  return count > 0 ? <Badge variant="secondary" className="mr-2">{count}</Badge> : null;
                })()}
              </Button>
              <Button
                variant={entityFilter === 'newly-added' ? 'default' : 'outline'}
                size="sm"
                onClick={() => {
                  setEntityFilter('newly-added');
                  setCurrentPage(1);
                }}
                className="text-right"
              >
                تازه اضافه شده
                {(() => {
                  const count = entities.filter(e => {
                    const createdDate = e.createdDate ? new Date(e.createdDate) : null;
                    const daysSinceCreation = createdDate ? (Date.now() - createdDate.getTime()) / (1000 * 60 * 60 * 24) : Infinity;
                    return daysSinceCreation <= 30;
                  }).length;
                  return count > 0 ? <Badge variant="secondary" className="mr-2">{count}</Badge> : null;
                })()}
              </Button>
            </div>
            
            {/* Filters and Search at the top - horizontal layout */}
            <div className="flex items-center gap-4 w-full" dir="rtl" style={{ direction: 'rtl' }}>
              <Collapsible open={filtersOpen} onOpenChange={setFiltersOpen}>
                <CollapsibleTrigger asChild>
                  <Button variant="outline" size="sm" className="text-right">
                    <Filter className="ml-2 h-4 w-4" />
                    فیلترها
                  </Button>
                </CollapsibleTrigger>
                <CollapsibleContent className="mt-4 p-4 border rounded-lg bg-muted/50">
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <Label>نمبر تشخیصیه (TIN)</Label>
                      <Input
                        value={tinFilter}
                        onChange={(e) => {
                          setTinFilter(e.target.value);
                          setCurrentPage(1);
                        }}
                        className="text-right"
                        placeholder="TIN..."
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>گروه</Label>
                      <Select value={groupFilter || "all"} onValueChange={(v) => {
                        setGroupFilter(v === "all" ? '' : v);
                        setCurrentPage(1);
                      }}>
                        <SelectTrigger className="text-right" dir="rtl">
                          <SelectValue placeholder="همه" />
                        </SelectTrigger>
                        <SelectContent dir="rtl">
                          <SelectItem value="all">همه</SelectItem>
                          {STATIC_REFERRAL_GROUPS.map((group) => (
                            <SelectItem key={group.id} value={group.name}>
                              {group.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label>سال‌های بررسی</Label>
                      <Input
                        value={yearFilter}
                        onChange={(e) => {
                          setYearFilter(e.target.value);
                          setCurrentPage(1);
                        }}
                        className="text-right"
                        placeholder="مثال: 1402..."
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>وضعیت نهاد</Label>
                      <Select value={statusFilter || "all"} onValueChange={(v) => {
                        setStatusFilter(v === "all" ? '' : v);
                        setCurrentPage(1);
                      }}>
                        <SelectTrigger className="text-right" dir="rtl">
                          <SelectValue placeholder="همه" />
                        </SelectTrigger>
                        <SelectContent dir="rtl">
                          <SelectItem value="all">همه</SelectItem>
                          <SelectItem value="Active">فعال</SelectItem>
                          <SelectItem value="Under Audit">در حال بررسی</SelectItem>
                          <SelectItem value="Dormant">غیرفعال</SelectItem>
                          <SelectItem value="Deleted/Archived">حذف شده/بایگانی</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label>تاریخ ایجاد از</Label>
                      <ShamsiDatePickerDDMMYYYY
                        value={createdDateFrom}
                        onChange={(date) => {
                          setCreatedDateFrom(date);
                          setCurrentPage(1);
                        }}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>تاریخ ایجاد تا</Label>
                      <ShamsiDatePickerDDMMYYYY
                        value={createdDateTo}
                        onChange={(date) => {
                          setCreatedDateTo(date);
                          setCurrentPage(1);
                        }}
                      />
                    </div>
                  </div>
                  <div className="flex justify-end mt-4">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => {
                        setTinFilter('');
                        setGroupFilter('');
                        setYearFilter('');
                        setStatusFilter('all');
                        setCreatedDateFrom('');
                        setCreatedDateTo('');
                        setEntityFilter('all');
                        setCurrentPage(1);
                      }}
                    >
                      پاک کردن فیلترها
                    </Button>
                  </div>
                </CollapsibleContent>
              </Collapsible>
              <div className="relative flex-1">
                <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="جستجو بر اساس نام شرکت یا نمبر تشخیصیه..."
                  value={searchQuery}
                  onChange={(e) => {
                    setSearchQuery(e.target.value);
                    setCurrentPage(1);
                  }}
                  className="pr-10 text-right"
                  dir="rtl"
                  data-testid="input-search-entities"
                />
              </div>
            </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="text-center py-8 text-muted-foreground">در حال بارگذاری...</div>
          ) : (() => {
            // Debug: Log entities count
            console.log('Total entities from API:', entities.length);
            console.log('Current filters:', { entityFilter, searchQuery, statusFilter, tinFilter, groupFilter });
            
            // Filter entities based on entity filter
            let filteredEntities = entities.filter((entity) => {
              // Entity filter-based filtering
              if (entityFilter === 'all') {
                // Show all entities - no filtering
              } else if (entityFilter === 'has-cases') {
                const entityIdsWithCases = new Set(allCases.map(c => c.entityId));
                if (!entityIdsWithCases.has(entity.id)) return false;
              } else if (entityFilter === 'no-cases') {
                const entityIdsWithCases = new Set(allCases.map(c => c.entityId));
                if (entityIdsWithCases.has(entity.id)) return false;
              } else if (entityFilter === 'newly-added') {
                const createdDate = entity.createdDate ? new Date(entity.createdDate) : null;
                const daysSinceCreation = createdDate ? (Date.now() - createdDate.getTime()) / (1000 * 60 * 60 * 24) : Infinity;
                if (daysSinceCreation > 30) return false; // Newly added = within last 30 days
              }
              
              // Apply search query
              const matchesSearch = !searchQuery || 
                entity.companyName?.toLowerCase().includes(searchQuery.toLowerCase()) ||
                entity.tin?.toLowerCase().includes(searchQuery.toLowerCase());
              
              // Apply filters
              const matchesTin = !tinFilter || 
                entity.tin?.toLowerCase().includes(tinFilter.toLowerCase());
              
              const matchesGroup = !groupFilter || 
                entity.referralGroup === groupFilter;
              
              const matchesYear = !yearFilter || 
                entity.periodsUnderReview?.toLowerCase().includes(yearFilter.toLowerCase()) ||
                entity.yearsUnderReview?.toLowerCase().includes(yearFilter.toLowerCase());
              
              const matchesStatus = statusFilter === 'all' || 
                !statusFilter || 
                (entity.status || 'Active') === statusFilter;
              
              // Date filtering (simplified)
              const matchesDateFrom = !createdDateFrom || true; // TODO: Implement date comparison
              const matchesDateTo = !createdDateTo || true; // TODO: Implement date comparison
              
              return matchesSearch && matchesTin && matchesGroup && 
                     matchesYear && matchesStatus && matchesDateFrom && matchesDateTo;
            });
            
            console.log('Filtered entities count:', filteredEntities.length);
            
            // Sort entities
            filteredEntities.sort((a, b) => {
              let comparison = 0;
              if (sortField === 'createdAt') {
                const dateA = new Date(a.createdAt || 0).getTime();
                const dateB = new Date(b.createdAt || 0).getTime();
                comparison = dateA - dateB;
              } else if (sortField === 'companyName') {
                comparison = (a.companyName || '').localeCompare(b.companyName || '');
              } else if (sortField === 'tin') {
                comparison = (a.tin || '').localeCompare(b.tin || '');
              }
              return sortDirection === 'asc' ? comparison : -comparison;
            });
            
            // Pagination
            const totalPages = Math.ceil(filteredEntities.length / itemsPerPage);
            const startIndex = (currentPage - 1) * itemsPerPage;
            const endIndex = startIndex + itemsPerPage;
            const paginatedEntities = filteredEntities.slice(startIndex, endIndex);
            
            // Get entity case counts
            const entityCaseCounts = new Map<string, number>();
            allCases.forEach(c => {
              entityCaseCounts.set(c.entityId, (entityCaseCounts.get(c.entityId) || 0) + 1);
            });
            
            // Get entity case statuses
            const entityCaseStatuses = new Map<string, string[]>();
            allCases.forEach(c => {
              const statuses = entityCaseStatuses.get(c.entityId) || [];
              if (!statuses.includes(c.status)) {
                statuses.push(c.status);
              }
              entityCaseStatuses.set(c.entityId, statuses);
            });
            
            // Get last case date for each entity
            const entityLastCaseDate = new Map<string, Date>();
            allCases.forEach(c => {
              if (c.createdAt) {
                const caseDate = new Date(c.createdAt);
                const existing = entityLastCaseDate.get(c.entityId);
                if (!existing || caseDate > existing) {
                  entityLastCaseDate.set(c.entityId, caseDate);
                }
              }
            });
            
            // Determine empty message based on filter
            const getEmptyMessage = () => {
              switch (entityFilter) {
                case 'has-cases':
                  return 'هیچ نهادی با قضیه یافت نشد';
                case 'no-cases':
                  return 'همه نهادها دارای قضیه هستند';
                case 'newly-added':
                  return 'هیچ نهاد تازه اضافه شده‌ای یافت نشد';
                default:
                  return 'هیچ نهادی یافت نشد';
              }
            };

            return (
              <>
                {filteredEntities.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">{getEmptyMessage()}</div>
                ) : (
                  <>
                    <Table dir="rtl">
                      <TableHeader>
                        <TableRow>
                          <TableHead className="text-right" dir="rtl">
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-8 px-2"
                              onClick={() => {
                                if (sortField === 'companyName') {
                                  setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
                                } else {
                                  setSortField('companyName');
                                  setSortDirection('asc');
                                }
                              }}
                            >
                              نام نهاد
                              {sortField === 'companyName' && (
                                sortDirection === 'asc' ? <ArrowUp className="mr-1 h-3 w-3" /> : <ArrowDown className="mr-1 h-3 w-3" />
                              )}
                            </Button>
                          </TableHead>
                          <TableHead className="text-right" dir="rtl">نمبر تشخیصیه</TableHead>
                          <TableHead className="text-right" dir="rtl">وضعیت نهاد</TableHead>
                          <TableHead className="text-right" dir="rtl">تعداد قضایا</TableHead>
                          <TableHead className="text-right" dir="rtl">آخرین قضیه</TableHead>
                          <TableHead className="text-right" dir="rtl">وضعیت‌های قضایا</TableHead>
                          <TableHead className="text-right" dir="rtl">سال‌های بررسی</TableHead>
                          <TableHead className="text-right" dir="rtl">گروه</TableHead>
                          <TableHead className="text-right" dir="rtl">
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-8 px-2"
                              onClick={() => {
                                if (sortField === 'createdAt') {
                                  setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
                                } else {
                                  setSortField('createdAt');
                                  setSortDirection('desc');
                                }
                              }}
                            >
                              تاریخ ایجاد
                              {sortField === 'createdAt' && (
                                sortDirection === 'asc' ? <ArrowUp className="mr-1 h-3 w-3" /> : <ArrowDown className="mr-1 h-3 w-3" />
                              )}
                            </Button>
                          </TableHead>
                          <TableHead className="text-right" dir="rtl">عملیات</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {paginatedEntities.map((entity) => {
                          const caseCount = entityCaseCounts.get(entity.id) || 0;
                          const caseStatuses = entityCaseStatuses.get(entity.id) || [];
                          const lastCaseDate = entityLastCaseDate.get(entity.id);
                          const entityStatus = entity.status || 'Active';
                          
                          return (
                            <TableRow key={entity.id} className="hover-elevate">
                              <TableCell className="font-medium" dir="rtl">{entity.companyName}</TableCell>
                              <TableCell dir="rtl">{entity.tin}</TableCell>
                              <TableCell dir="rtl">
                                <StatusBadge 
                                  status={entityStatus === 'Active' ? 'فعال' : 
                                         entityStatus === 'Under Audit' ? 'در حال بررسی' :
                                         entityStatus === 'Dormant' ? 'غیرفعال' :
                                         'بایگانی شده'} 
                                />
                              </TableCell>
                              <TableCell dir="rtl">
                                {caseCount > 0 ? (
                                  <Badge variant="secondary">{caseCount}</Badge>
                                ) : (
                                  '-'
                                )}
                              </TableCell>
                              <TableCell dir="rtl">
                                {lastCaseDate ? (() => {
                                  try {
                                    const j = jalaali.toJalaali(lastCaseDate);
                                    return `${j.jy}/${String(j.jm).padStart(2, '0')}/${String(j.jd).padStart(2, '0')}`;
                                  } catch {
                                    return '-';
                                  }
                                })() : '-'}
                              </TableCell>
                              <TableCell dir="rtl">
                                {caseStatuses.length > 0 ? (
                                  <div className="flex flex-wrap gap-1">
                                    {caseStatuses.slice(0, 3).map((status, idx) => (
                                      <StatusBadge key={idx} status={status} />
                                    ))}
                                    {caseStatuses.length > 3 && (
                                      <Badge variant="outline">+{caseStatuses.length - 3}</Badge>
                                    )}
                                  </div>
                                ) : (
                                  '-'
                                )}
                              </TableCell>
                              <TableCell dir="rtl">{entity.periodsUnderReview || entity.yearsUnderReview || '-'}</TableCell>
                              <TableCell dir="rtl">
                                {groups.find(g => g.id === entity.referralGroup)?.name || entity.referralGroup || '-'}
                              </TableCell>
                              <TableCell dir="rtl">
                                {entity.createdDate ? (() => {
                                  try {
                                    const date = new Date(entity.createdDate);
                                    const j = jalaali.toJalaali(date);
                                    return `${j.jy}/${String(j.jm).padStart(2, '0')}/${String(j.jd).padStart(2, '0')}`;
                                  } catch {
                                    return '-';
                                  }
                                })() : '-'}
                              </TableCell>
                              <TableCell dir="rtl">
                                <div className="flex gap-2">
                                  {/* Create Case button - ALWAYS visible and enabled */}
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    onClick={() => {
                                      setLocation(`/cases?createForEntity=${entity.id}`);
                                    }}
                                  >
                                    <Plus className="ml-2 h-4 w-4" />
                                    ایجاد قضیه
                                  </Button>
                                  {/* View Cases button - Only shown if entity has existing cases */}
                                  {caseCount > 0 && (
                                    <Button
                                      size="sm"
                                      variant="outline"
                                      onClick={() => {
                                        setLocation(`/cases?entityId=${entity.id}`);
                                      }}
                                    >
                                      <FileText className="ml-2 h-4 w-4" />
                                      مشاهده قضایا
                                    </Button>
                                  )}
                                  <Button
                                    size="icon"
                                    variant="ghost"
                                    onClick={() => {
                                      setSelectedEntity(entity);
                                      setDetailDialogOpen(true);
                                    }}
                                    title="مشاهده جزئیات و سوابق بررسی"
                                  >
                                    <Eye className="h-4 w-4" />
                                  </Button>
                                  <Button
                                    size="icon"
                                    variant="ghost"
                                    onClick={() => handleEdit(entity)}
                                  >
                                    <Edit className="h-4 w-4" />
                                  </Button>
                                </div>
                              </TableCell>
                            </TableRow>
                          );
                        })}
                      </TableBody>
                    </Table>
                      {totalPages > 1 && (
                        <div className="mt-4 flex items-center justify-between" dir="rtl">
                          <div className="text-sm text-muted-foreground">
                            نمایش {startIndex + 1} تا {Math.min(endIndex, filteredEntities.length)} از {filteredEntities.length} نهاد
                          </div>
                          <Pagination>
                            <PaginationContent>
                              <PaginationItem>
                                <PaginationPrevious
                                  href="#"
                                  onClick={(e) => {
                                    e.preventDefault();
                                    if (currentPage > 1) setCurrentPage(currentPage - 1);
                                  }}
                                  className={currentPage === 1 ? 'pointer-events-none opacity-50' : ''}
                                />
                              </PaginationItem>
                              {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
                                <PaginationItem key={page}>
                                  <PaginationLink
                                    href="#"
                                    onClick={(e) => {
                                      e.preventDefault();
                                      setCurrentPage(page);
                                    }}
                                    isActive={currentPage === page}
                                  >
                                    {page}
                                  </PaginationLink>
                                </PaginationItem>
                              ))}
                              <PaginationItem>
                                <PaginationNext
                                  href="#"
                                  onClick={(e) => {
                                    e.preventDefault();
                                    if (currentPage < totalPages) setCurrentPage(currentPage + 1);
                                  }}
                                  className={currentPage === totalPages ? 'pointer-events-none opacity-50' : ''}
                                />
                              </PaginationItem>
                            </PaginationContent>
                          </Pagination>
                        </div>
                      )}
                    </>
                  )}
              </>
            );
          })()}
        </CardContent>
      </Card>

      {/* Edit Entity Dialog */}
      <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>ویرایش نهاد</DialogTitle>
            <DialogDescription>
              اطلاعات نهاد را ویرایش کنید.
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleEditSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="edit-companyName">نام نهاد *</Label>
                <Input
                  id="edit-companyName"
                  value={editFormData.companyName}
                  onChange={(e) => setEditFormData({ ...editFormData, companyName: e.target.value })}
                  className="text-right"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-tin">نمبر تشخیصیه (TIN) *</Label>
                <Input
                  id="edit-tin"
                  value={editFormData.tin}
                  onChange={(e) => setEditFormData({ ...editFormData, tin: e.target.value })}
                  className="text-right"
                  required
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="edit-businessNature">ماهیت تشبث *</Label>
                <Select value={editFormData.businessNature} onValueChange={(v) => setEditFormData({ ...editFormData, businessNature: v })}>
                  <SelectTrigger id="edit-businessNature" className="text-right" dir="rtl">
                    <SelectValue placeholder="انتخاب کنید" />
                  </SelectTrigger>
                  <SelectContent dir="rtl">
                    {entityTypes.map((type) => (
                      <SelectItem key={type.id} value={type.name}>
                        {type.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-status">وضعیت نهاد *</Label>
                <Select value={editFormData.status} onValueChange={(v: any) => setEditFormData({ ...editFormData, status: v })}>
                  <SelectTrigger id="edit-status" className="text-right" dir="rtl">
                    <SelectValue placeholder="انتخاب کنید" />
                  </SelectTrigger>
                  <SelectContent dir="rtl">
                    <SelectItem value="Active">فعال</SelectItem>
                    <SelectItem value="Under Audit">در حال بررسی</SelectItem>
                    <SelectItem value="Dormant">غیرفعال</SelectItem>
                    <SelectItem value="Deleted/Archived">حذف شده/بایگانی</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-notes">ملاحظات</Label>
              <Textarea
                id="edit-notes"
                value={editFormData.notes}
                onChange={(e) => setEditFormData({ ...editFormData, notes: e.target.value })}
                className="text-right"
              />
            </div>
            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => {
                  setEditDialogOpen(false);
                  setSelectedEntity(null);
                }}
              >
                لغو
              </Button>
              <Button type="submit" disabled={updateEntityMutation.isPending}>
                {updateEntityMutation.isPending ? 'در حال ذخیره...' : 'ذخیره تغییرات'}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Entity Detail Dialog with Audit Timeline */}
      <Dialog open={detailDialogOpen} onOpenChange={setDetailDialogOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>جزئیات نهاد و سوابق بررسی</DialogTitle>
            <DialogDescription>
              {selectedEntity?.companyName} - {selectedEntity?.tin}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-6 mt-4">
            {selectedEntity && (
              <>
                <Card>
                  <CardHeader>
                    <CardTitle>اطلاعات نهاد</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label className="text-muted-foreground">نام نهاد</Label>
                        <p className="font-medium">{selectedEntity.companyName}</p>
                      </div>
                      <div>
                        <Label className="text-muted-foreground">نمبر تشخیصیه (TIN)</Label>
                        <p className="font-medium">{selectedEntity.tin}</p>
                      </div>
                      <div>
                        <Label className="text-muted-foreground">ماهیت تشبث</Label>
                        <p className="font-medium">{selectedEntity.businessNature}</p>
                      </div>
                      <div>
                        <Label className="text-muted-foreground">وضعیت نهاد</Label>
                        <p className="font-medium">
                          <StatusBadge 
                            status={selectedEntity.status === 'Active' ? 'فعال' : 
                                   selectedEntity.status === 'Under Audit' ? 'در حال بررسی' :
                                   selectedEntity.status === 'Dormant' ? 'غیرفعال' :
                                   selectedEntity.status === 'Deleted/Archived' ? 'بایگانی شده' : 'فعال'} 
                          />
                        </p>
                      </div>
                      <div>
                        <Label className="text-muted-foreground">گروه ارجاع‌دهنده</Label>
                        <p className="font-medium">
                          {groups.find(g => g.id === selectedEntity.referralGroup)?.name || selectedEntity.referralGroup || '-'}
                        </p>
                      </div>
                      {/* Audit-related fields removed - now shown in AuditRecordTimeline */}
                      {selectedEntity.notes && (
                        <div className="col-span-2">
                          <Label className="text-muted-foreground">ملاحظات</Label>
                          <p className="font-medium">{selectedEntity.notes}</p>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
                
                <AuditRecordTimeline
                  entityId={selectedEntity.id}
                  entityName={selectedEntity.companyName}
                  onRefresh={() => {
                    queryClient.invalidateQueries({ queryKey: ['entities'] });
                  }}
                />
              </>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* Delete Entity Confirmation */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>حذف نهاد</AlertDialogTitle>
            <AlertDialogDescription>
              آیا مطمئن هستید که می‌خواهید نهاد "{selectedEntity?.companyName}" را حذف کنید؟
              این عمل قابل بازگشت نیست. اگر این نهاد قضایای مرتبط داشته باشد، حذف امکان‌پذیر نیست.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>لغو</AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmDelete}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              disabled={deleteEntityMutation.isPending}
            >
              {deleteEntityMutation.isPending ? 'در حال حذف...' : 'حذف'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
