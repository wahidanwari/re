import { useState, useEffect, useRef, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogTrigger,
  DialogFooter,
} from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Plus, Search, Eye, UserPlus, Upload, CheckCircle, FileText, Download, Filter, ArrowUpDown, ArrowUp, ArrowDown, FileSpreadsheet, DollarSign } from 'lucide-react';
import StatusBadge from '@/components/StatusBadge';
import ShamsiDatePickerDDMMYYYY from '@/components/ShamsiDatePickerDDMMYYYY';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Pagination,
  PaginationContent,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from '@/components/ui/pagination';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { ChevronDown, ChevronRight } from 'lucide-react';
import jalaali from 'jalaali-js';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import type { Case, InsertCase, Entity, Document } from '@shared/schema';
import { CaseStatus } from '@shared/schema';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';
import { userHasPermission, getUserPermissions } from '@/utils/permissions';
import { useLocation } from 'wouter';
import CaseReportForm from '@/components/CaseReportForm';
import CaseReportFormV2 from '@/components/CaseReportFormV2';
import ReopenCaseButton from '@/components/ReopenCaseButton';
import NonResponsiveWorkflow from '@/components/NonResponsiveWorkflow';
import InstallmentPayments from '@/components/InstallmentPayments';
import FinancialFollowUpForm from '@/components/FinancialFollowUpForm';
import CaseCompletionDetails from '@/components/CaseCompletionDetails';

// Static list of predefined referral groups (گروه ارجاع‌دهنده)
// These are the only groups that can send cases to the audit department
const STATIC_REFERRAL_GROUPS = [
  { id: 'group-1', name: 'گروه اول سنجش ابتدایی' },
  { id: 'group-2', name: 'گروه دوم سنجش ابتدایی' },
  { id: 'group-3', name: 'گروه سوم سنجش ابتدایی' },
  { id: 'group-4', name: 'گروه چهارم سنجش ابتدایی' },
  { id: 'group-5', name: 'گروه پنجم سنجش ابتدایی' },
  { id: 'group-6', name: 'گروه ششم سنجش ابتدایی' },
  { id: 'group-7', name: 'گروه هفتم سنجش ابتدایی' },
  { id: 'group-8', name: 'گروه هشتم سنجش ابتدایی' },
  { id: 'group-9', name: 'گروه نهم سنجش ابتدایی' },
  { id: 'group-10', name: 'مدیریت عمومی تشخیص مالیه دهنده' },
];

export default function Cases() {
  // Tab state
  const [activeTab, setActiveTab] = useState<'all-cases' | 'newly-assigned' | 'completed' | 'committee-cases' | 'installment-cases' | 'law-enforcement-cases'>('newly-assigned');
  
  // Universal Cases Tab filters
  const [universalStatusFilter, setUniversalStatusFilter] = useState<string>('all');
  const [universalGroupFilter, setUniversalGroupFilter] = useState<string>('all');
  const [universalCommitteeFilter, setUniversalCommitteeFilter] = useState<string>('all');
  const [universalEntityTypeFilter, setUniversalEntityTypeFilter] = useState<string>('all');
  const [universalAuditYearFilter, setUniversalAuditYearFilter] = useState<string>('');
  const [universalDateFromFilter, setUniversalDateFromFilter] = useState<string>('');
  const [universalDateToFilter, setUniversalDateToFilter] = useState<string>('');
  
  // Archive expansion state
  const [expandedYears, setExpandedYears] = useState<Set<number>>(new Set());
  const [expandedMonths, setExpandedMonths] = useState<Set<string>>(new Set());
  
  // Search and filters
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [entityNameFilter, setEntityNameFilter] = useState('');
  const [tinFilter, setTinFilter] = useState('');
  const [assignedAuditorFilter, setAssignedAuditorFilter] = useState('');
  const [createdDateFrom, setCreatedDateFrom] = useState('');
  const [createdDateTo, setCreatedDateTo] = useState('');
  const [caseTypeFilter, setCaseTypeFilter] = useState('');
  const [filtersOpen, setFiltersOpen] = useState(false);
  
  // Sorting
  const [sortField, setSortField] = useState<'createdAt' | 'companyName' | 'assignedTo' | 'priority'>('createdAt');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('desc');
  
  // Pagination
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 20;
  
  const [dialogOpen, setDialogOpen] = useState(false);
  const [uploadDialogOpen, setUploadDialogOpen] = useState(false);
  const [viewDialogOpen, setViewDialogOpen] = useState(false);
  const [assignDialogOpen, setAssignDialogOpen] = useState(false);
  const [reportDialogOpen, setReportDialogOpen] = useState(false);
  const [financialFollowUpOpen, setFinancialFollowUpOpen] = useState(false);
  const [selectedCase, setSelectedCase] = useState<Case | null>(null);
  const [selectedGroupId, setSelectedGroupId] = useState<string | null>(null);
  const [uploadForm, setUploadForm] = useState({
    docType: '',
    docDate: '',
    description: '',
    isFinal: false,
  });
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [formData, setFormData] = useState({
    entityId: '',
    tin: '',
    auditRecordId: '', // سابقه بررسی - required
    groupReferrer: '', // گروه ارجاع‌دهنده
    receivingGroup: '', // گروه دریافت‌کننده (audit group)
    auditYearRange: '', // سال‌های بررسی (e.g., "1399–1401")
    committeeId: '', // Committee ID
    referralDate: '',
    notes: '',
  });
  // Year range selector state
  const [startYear, setStartYear] = useState<string>('');
  const [endYear, setEndYear] = useState<string>('');
  const [tinInput, setTinInput] = useState('');
  const [tinSearchQuery, setTinSearchQuery] = useState('');
  const [tinSuggestions, setTinSuggestions] = useState<any[]>([]);
  const [showTinSuggestions, setShowTinSuggestions] = useState(false);
  const [selectedEntity, setSelectedEntity] = useState<any | null>(null);
  const tinInputRef = useRef<HTMLInputElement>(null);
  const suggestionsRef = useRef<HTMLDivElement>(null);
  const debounceTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { user: currentUser, loading: authLoading } = useAuth();
  const [location, setLocation] = useLocation();

  // Generate year options (1380 to current Solar Hijri year)
  const getCurrentShamsiYear = (): number => {
    const now = new Date();
    const j = jalaali.toJalaali(now.getFullYear(), now.getMonth() + 1, now.getDate());
    return j.jy;
  };

  const generateYearOptions = (): string[] => {
    const currentYear = getCurrentShamsiYear();
    const years: string[] = [];
    for (let year = 1380; year <= currentYear; year++) {
      years.push(year.toString());
    }
    return years.reverse(); // Most recent years first
  };

  const yearOptions = generateYearOptions();

  // Parse auditYearRange into startYear and endYear
  const parseYearRange = (range: string): { startYear: string; endYear: string } => {
    if (!range || !range.trim()) {
      return { startYear: '', endYear: '' };
    }
    const trimmed = range.trim();
    // Match patterns like "1399-1401", "1399–1401", "1399—1401", or single year "1400"
    const rangeMatch = trimmed.match(/^(\d{4})[\s\-–—]+(\d{4})$/);
    const singleYearMatch = trimmed.match(/^(\d{4})$/);
    
    if (rangeMatch) {
      return { startYear: rangeMatch[1], endYear: rangeMatch[2] };
    } else if (singleYearMatch) {
      const year = singleYearMatch[1];
      return { startYear: year, endYear: year };
    }
    return { startYear: '', endYear: '' };
  };

  // Format startYear and endYear into auditYearRange
  const formatYearRange = (start: string, end: string): string => {
    if (!start || !end) return '';
    if (start === end) return start;
    return `${start}–${end}`; // Using en dash (U+2013)
  };

  // Update auditYearRange when startYear or endYear changes (user interaction)
  useEffect(() => {
    if (startYear && endYear) {
      const formatted = formatYearRange(startYear, endYear);
      setFormData(prev => {
        // Only update if different to prevent unnecessary re-renders
        if (prev.auditYearRange !== formatted) {
          return { ...prev, auditYearRange: formatted };
        }
        return prev;
      });
    } else if (!startYear && !endYear) {
      setFormData(prev => {
        if (prev.auditYearRange !== '') {
          return { ...prev, auditYearRange: '' };
        }
        return prev;
      });
    }
  }, [startYear, endYear]);
  
  // Extract entity ID and audit record ID from URL query parameters
  const urlParams = new URLSearchParams(window.location.search);
  const createForEntityId = urlParams.get('createForEntity');
  const preSelectedAuditRecordId = urlParams.get('auditRecordId');
  const [preSelectedEntityId, setPreSelectedEntityId] = useState<string | null>(createForEntityId);
  const [preSelectedAuditRecordIdState, setPreSelectedAuditRecordIdState] = useState<string | null>(preSelectedAuditRecordId);
  const [entityLoadError, setEntityLoadError] = useState<string | null>(null);
  const [auditRecordSelectorDisabled, setAuditRecordSelectorDisabled] = useState<boolean>(!!preSelectedAuditRecordId);

  const { data: cases = [], isLoading } = useQuery<Case[]>({
    queryKey: ['cases', currentUser?.id, currentUser?.permissionsVersion],
    queryFn: async () => {
      const response = await fetch('/api/cases', { 
        credentials: 'include',
        cache: 'no-store', // Force fresh data on each request
      });
      if (!response.ok) {
        if (response.status === 403) {
          throw new Error('عدم دسترسی - شما مجوز لازم را ندارید');
        }
        throw new Error('Failed to fetch cases');
      }
      return response.json();
    },
    enabled: !authLoading && !!currentUser && userHasPermission(currentUser, 'cases:view'),
    staleTime: 0, // Always consider data stale to force fresh fetch
    gcTime: 0, // Don't cache to ensure RBAC is always enforced
  });

  // Fetch cases with unpaid balance (Financial Tracking - قضایای در اقساط)
  const { data: unpaidCases = [], isLoading: isLoadingUnpaid } = useQuery<any[]>({
    queryKey: ['cases', 'unpaid', currentUser?.id, currentUser?.permissionsVersion],
    queryFn: async () => {
      const response = await fetch('/api/cases/financial/unpaid', { 
        credentials: 'include',
        cache: 'no-store',
      });
      if (!response.ok) {
        if (response.status === 403) {
          throw new Error('عدم دسترسی - شما مجوز لازم را ندارید');
        }
        throw new Error('Failed to fetch unpaid cases');
      }
      return response.json();
    },
    enabled: !authLoading && !!currentUser && userHasPermission(currentUser, 'cases:view'),
    staleTime: 0,
    gcTime: 0,
  });

  const { data: entities = [] } = useQuery<Entity[]>({
    queryKey: ['entities'],
    queryFn: async () => {
      const response = await fetch('/api/entities', { credentials: 'include' });
      if (!response.ok) throw new Error('Failed to fetch entities');
      return response.json();
    },
    enabled: !authLoading && !!currentUser,
  });

  // Fetch entity data when createForEntity is in URL (Form Initialization Service)
  const { data: preSelectedEntity, isLoading: isLoadingPreSelectedEntity, error: preSelectedEntityError } = useQuery<Entity>({
    queryKey: ['entity', preSelectedEntityId],
    queryFn: async () => {
      if (!preSelectedEntityId) return null;
      const response = await fetch(`/api/entities/${preSelectedEntityId}`, { credentials: 'include' });
      if (!response.ok) {
        if (response.status === 404) {
          throw new Error('نهاد یافت نشد');
        }
        if (response.status === 403) {
          throw new Error('عدم دسترسی - شما مجوز لازم را ندارید');
        }
        throw new Error('خطا در بارگذاری اطلاعات نهاد');
      }
      return response.json();
    },
    enabled: !authLoading && !!currentUser && !!preSelectedEntityId,
    retry: 1,
  });

  // Search entities by TIN (debounced)
  const { data: tinSearchResults = [], isLoading: tinSearchLoading } = useQuery<any[]>({
    queryKey: ['entitiesSearch', tinSearchQuery],
    queryFn: async () => {
      if (!tinSearchQuery || tinSearchQuery.trim().length < 1) {
        return [];
      }
      const response = await fetch(`/api/entities/search?tin=${encodeURIComponent(tinSearchQuery.trim())}`, {
        credentials: 'include',
      });
      if (!response.ok) {
        if (response.status === 401) {
          return [];
        }
        throw new Error('Failed to search entities');
      }
      return response.json();
    },
    enabled: tinSearchQuery.trim().length >= 1,
  });

  // Debounce TIN input
  useEffect(() => {
    if (debounceTimeoutRef.current) {
      clearTimeout(debounceTimeoutRef.current);
    }
    
    debounceTimeoutRef.current = setTimeout(() => {
      setTinSearchQuery(tinInput);
    }, 300); // 300ms debounce

    return () => {
      if (debounceTimeoutRef.current) {
        clearTimeout(debounceTimeoutRef.current);
      }
    };
  }, [tinInput]);

  // Update suggestions when search results change
  useEffect(() => {
    if (tinSearchResults.length > 0) {
      setTinSuggestions(tinSearchResults);
      setShowTinSuggestions(true);
    } else if (tinSearchQuery.trim().length >= 1 && !tinSearchLoading) {
      setTinSuggestions([]);
      setShowTinSuggestions(true);
    }
  }, [tinSearchResults, tinSearchQuery, tinSearchLoading]);

  // Close suggestions when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        suggestionsRef.current &&
        !suggestionsRef.current.contains(event.target as Node) &&
        tinInputRef.current &&
        !tinInputRef.current.contains(event.target as Node)
      ) {
        setShowTinSuggestions(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  // Auto-populate form when entity is pre-selected from URL (Direct Entity Linking)
  useEffect(() => {
    if (preSelectedEntity && !dialogOpen) {
      // Open dialog automatically
      setDialogOpen(true);
      
      // Pre-populate form with entity data
      setSelectedEntity(preSelectedEntity);
      setFormData({
        entityId: preSelectedEntity.id,
        tin: preSelectedEntity.tin || '',
        auditRecordId: '', // Will be populated from audit record selector
        groupReferrer: '', // No longer autofilled - user must select
        receivingGroup: '',
        auditYearRange: '', // سال‌های بررسی
        committeeId: '', // Committee ID
        referralDate: '',
        notes: '',
      });
      setTinInput(preSelectedEntity.tin || '');
      // Reset year range selectors
      setStartYear('');
      setEndYear('');
      
      // Clear URL parameter after loading
      const newUrl = window.location.pathname;
      window.history.replaceState({}, '', newUrl);
      setPreSelectedEntityId(null);
      
      toast({
        title: 'نهاد انتخاب شده',
        description: `قضیه برای نهاد "${preSelectedEntity.companyName}" ایجاد می‌شود`,
      });
    }
  }, [preSelectedEntity, dialogOpen, toast]);

  // Handle entity loading errors (Validation / Error Handling)
  useEffect(() => {
    if (preSelectedEntityError) {
      const errorMessage = preSelectedEntityError instanceof Error 
        ? preSelectedEntityError.message 
        : 'خطا در بارگذاری اطلاعات نهاد';
      setEntityLoadError(errorMessage);
      
      toast({
        title: 'خطا',
        description: errorMessage,
        variant: 'destructive',
      });
      
      // Clear URL parameter on error
      const newUrl = window.location.pathname;
      window.history.replaceState({}, '', newUrl);
      setPreSelectedEntityId(null);
    }
  }, [preSelectedEntityError, toast]);

  // Handle TIN selection
  const handleTinSelect = useCallback((entity: any) => {
    setSelectedEntity(entity);
    setTinInput(entity.tin);
    setShowTinSuggestions(false);
    setTinSearchQuery('');
    
    // Auto-populate entity fields (but NOT groupReferrer or auditRecordId - user must select)
    setFormData(prev => ({
      ...prev,
      entityId: entity.id,
      tin: entity.tin,
      auditRecordId: '', // Reset when entity changes - user must select
      groupReferrer: '', // User must explicitly select - no autofill
    }));
  }, []);

  // Handle TIN input change
  const handleTinInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setTinInput(value);
    
    // Clear selected entity if user is typing
    if (selectedEntity && value !== selectedEntity.tin) {
      setSelectedEntity(null);
      setFormData(prev => ({
        ...prev,
        entityId: '',
        auditRecordId: '',
        groupReferrer: '',
      }));
    }
  };

  const { data: groups = [] } = useQuery<any[]>({
    queryKey: ['groups'],
    queryFn: async () => {
      const response = await fetch('/api/groups', { credentials: 'include' });
      if (!response.ok) throw new Error('Failed to fetch groups');
      return response.json();
    },
    enabled: !authLoading && !!currentUser,
  });

  // Fetch pre-selected audit record if auditRecordId is in URL
  const { data: preSelectedAuditRecord, isLoading: isLoadingPreSelectedAuditRecord } = useQuery<any>({
    queryKey: ['audit-record', preSelectedAuditRecordIdState],
    queryFn: async () => {
      if (!preSelectedAuditRecordIdState) return null;
      const response = await fetch(`/api/audit-records/${preSelectedAuditRecordIdState}`, { 
        credentials: 'include' 
      });
      if (!response.ok) {
        if (response.status === 404) {
          throw new Error('سابقه بررسی یافت نشد');
        }
        throw new Error('Failed to fetch audit record');
      }
      return response.json();
    },
    enabled: !!preSelectedAuditRecordIdState && dialogOpen,
  });

  // Fetch audit records for the selected entity
  const { data: entityAuditRecordsData, isLoading: isLoadingEntityAuditRecords } = useQuery<{
    records: any[];
    pagination?: any;
  }>({
    queryKey: ['audit-records', 'entity', formData.entityId],
    queryFn: async () => {
      if (!formData.entityId) return { records: [] };
      const response = await fetch(`/api/audit-records/entities/${formData.entityId}/audits`, { 
        credentials: 'include' 
      });
      if (!response.ok) {
        if (response.status === 404) {
          return { records: [] };
        }
        throw new Error('Failed to fetch audit records');
      }
      return response.json();
    },
    enabled: !!formData.entityId && dialogOpen && !auditRecordSelectorDisabled,
  });

  const entityAuditRecords = entityAuditRecordsData?.records || [];

  // Auto-populate audit record when pre-selected from URL (from AuditRecord detail page)
  useEffect(() => {
    if (preSelectedAuditRecord && dialogOpen && !formData.auditRecordId) {
      setFormData(prev => ({
        ...prev,
        auditRecordId: preSelectedAuditRecord.id,
      }));
      // If audit record has entity, also set entity
      if (preSelectedAuditRecord.entityId && !formData.entityId) {
        // Fetch entity to populate form
        fetch(`/api/entities/${preSelectedAuditRecord.entityId}`, { credentials: 'include' })
          .then(res => res.json())
          .then(entity => {
            setSelectedEntity(entity);
            setFormData(prev => ({
              ...prev,
              entityId: entity.id,
              tin: entity.tin,
            }));
            setTinInput(entity.tin || '');
          })
          .catch(err => console.error('Failed to fetch entity:', err));
      }
      // Disable selector since it's pre-filled
      setAuditRecordSelectorDisabled(true);
      
      // Clear URL parameter
      const newUrl = window.location.pathname;
      window.history.replaceState({}, '', newUrl);
      setPreSelectedAuditRecordIdState(null);
    }
  }, [preSelectedAuditRecord, dialogOpen, formData.auditRecordId, formData.entityId]);

  // Fetch audit groups only (for receiving group selection - PHASE 1)
  const { data: auditGroups = [], isLoading: isLoadingAuditGroups, error: auditGroupsError } = useQuery<any[]>({
    queryKey: ['groups', 'audit'],
    queryFn: async () => {
      const response = await fetch('/api/groups?department=audit', { 
        credentials: 'include',
        cache: 'no-store' // Force fresh data
      });
      if (!response.ok) {
        const error = await response.json().catch(() => ({ message: 'Failed to fetch audit groups' }));
        throw new Error(error.message || 'Failed to fetch audit groups');
      }
      const data = await response.json();
      return Array.isArray(data) ? data : [];
    },
    enabled: !authLoading && !!currentUser && dialogOpen, // Only fetch when dialog is open
    staleTime: 0, // Always consider stale
    gcTime: 0, // Don't cache
  });

  // Fetch committees for case creation (using new committee module)
  const { data: committees = [], isLoading: committeesLoading, error: committeesError } = useQuery<any[]>({
    queryKey: ['committees-new'],
    queryFn: async () => {
      const response = await fetch('/api/committees-new', { credentials: 'include' });
      if (!response.ok) {
        const error = await response.json().catch(() => ({ message: 'Failed to fetch committees' }));
        throw new Error(error.message || 'Failed to fetch committees');
      }
      return response.json();
    },
    enabled: !authLoading && !!currentUser && dialogOpen,
  });

  const { data: users = [] } = useQuery<any[]>({
    queryKey: ['users'],
    queryFn: async () => {
      const response = await fetch('/api/users', { credentials: 'include' });
      if (!response.ok) throw new Error('Failed to fetch users');
      return response.json();
    },
    enabled: !authLoading && !!currentUser && (assignDialogOpen || uploadDialogOpen || viewDialogOpen),
  });

  // Fetch group members when a group is selected OR when case has a receivingGroup
  // This ensures Senior Auditor can see group members when assigning a case that was already assigned to a group
  // Also fetch for coordinators when they select a group to assign to
  const groupIdToFetch = selectedGroupId || selectedCase?.receivingGroup || 
    (currentUser?.role === 'senior_auditor' && !currentUser?.permissionPackages?.includes('acting_coordinator') 
      ? currentUser.groupId : null) || null;
  
  // Fetch auditors specifically for case assignment (includes both auditors and senior_auditors for self-assignment)
  const { data: groupAuditors = [], refetch: refetchGroupAuditors } = useQuery<any[]>({
    queryKey: ['groupAuditors', groupIdToFetch],
    queryFn: async () => {
      if (!groupIdToFetch) return [];
      const response = await fetch(`/api/groups/${groupIdToFetch}/auditors`, { 
        credentials: 'include',
        cache: 'no-store' // Force fresh data
      });
      if (!response.ok) {
        if (response.status === 403) {
          // User doesn't have permission to see this group's auditors
          console.warn(`Permission denied to view group ${groupIdToFetch} auditors`);
          return [];
        }
        throw new Error('Failed to fetch group auditors');
      }
      const auditors = await response.json();
      return Array.isArray(auditors) ? auditors : [];
    },
    enabled: !!groupIdToFetch && assignDialogOpen,
    staleTime: 0, // Always consider stale to force refresh
    gcTime: 0, // Don't cache
  });
  
  const { data: groupMembers = [], refetch: refetchGroupMembers } = useQuery<any[]>({
    queryKey: ['groupMembers', groupIdToFetch],
    queryFn: async () => {
      if (!groupIdToFetch) return [];
      const response = await fetch(`/api/groups/${groupIdToFetch}/members`, { 
        credentials: 'include',
        cache: 'no-store' // Force fresh data
      });
      if (!response.ok) {
        if (response.status === 403) {
          // User doesn't have permission to see this group's members
          console.warn(`Permission denied to view group ${groupIdToFetch} members`);
          return [];
        }
        throw new Error('Failed to fetch group members');
      }
      const members = await response.json();
      // Members already include user details from backend, no need to fetch separately
      return Array.isArray(members) ? members : [];
    },
    enabled: !!groupIdToFetch && assignDialogOpen,
    staleTime: 0, // Always consider stale to force refresh
    gcTime: 0, // Don't cache
  });
  
  // Also fetch current user's group members if they're a senior auditor (for assignment to their own group)
  const currentUserGroupId = currentUser?.groupId || null;
  const shouldFetchCurrentUserGroup = Boolean(
    currentUser?.role === 'senior_auditor' && 
    !currentUser?.permissionPackages?.includes('acting_coordinator') &&
    currentUserGroupId &&
    !groupIdToFetch && // Only if we're not already fetching another group
    assignDialogOpen
  );
  
  const { data: currentUserGroupMembers = [] } = useQuery<any[]>({
    queryKey: ['groupMembers', currentUserGroupId],
    queryFn: async () => {
      if (!currentUserGroupId) return [];
      const response = await fetch(`/api/groups/${currentUserGroupId}/members`, { 
        credentials: 'include',
        cache: 'no-store'
      });
      if (!response.ok) {
        if (response.status === 403) {
          return [];
        }
        throw new Error('Failed to fetch group members');
      }
      const members = await response.json();
      return Array.isArray(members) ? members : [];
    },
    enabled: shouldFetchCurrentUserGroup,
    staleTime: 0,
    gcTime: 0,
  });
  
  // Combine group auditors - prioritize selected group, then case's receiving group, then current user's group
  // Use auditors endpoint for case assignment (only auditors, not senior_auditors)
  const availableAuditors = Array.isArray(groupAuditors) ? groupAuditors : [];
  
  // Combine group members for group assignment view
  const groupMembersArray = Array.isArray(groupMembers) ? groupMembers : [];
  const currentUserGroupMembersArray = Array.isArray(currentUserGroupMembers) ? currentUserGroupMembers : [];
  const availableGroupMembers = groupMembersArray.length > 0 ? groupMembersArray : 
                                (currentUserGroupMembersArray.length > 0 ? currentUserGroupMembersArray : []);

  const { data: caseDocuments = [] } = useQuery<Document[]>({
    queryKey: ['documents', selectedCase?.caseId],
    queryFn: async () => {
      if (!selectedCase?.caseId) return [];
      const response = await fetch(`/api/documents/case/${selectedCase.caseId}`, { credentials: 'include' });
      if (!response.ok) throw new Error('Failed to fetch documents');
      return response.json();
    },
    enabled: !!selectedCase?.caseId && (viewDialogOpen || uploadDialogOpen),
  });

  const canUploadDocuments = currentUser && userHasPermission(
    currentUser,
    'documents:upload'
  );

  const createCaseMutation = useMutation({
    mutationFn: async (data: Partial<InsertCase>) => {
      const response = await fetch('/api/cases', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
        credentials: 'include',
      });
      if (!response.ok) {
        const error = await response.json();
        // Preserve structured error from backend (code, messageFa, etc.)
        const errorObj = new Error(error.messageFa || error.message || 'Failed to create case');
        (errorObj as any).messageFa = error.messageFa;
        (errorObj as any).code = error.code;
        (errorObj as any).help = error.help;
        throw errorObj;
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['cases'] });
      queryClient.invalidateQueries({ queryKey: ['available-cases'] }); // Refresh available cases for committees
      queryClient.invalidateQueries({ queryKey: ['committee-cases'] }); // Refresh committee cases
      setDialogOpen(false);
      setFormData({ entityId: '', tin: '', auditRecordId: '', groupReferrer: '', receivingGroup: '', auditYearRange: '', committeeId: '', referralDate: '', notes: '' });
      setStartYear('');
      setEndYear('');
      setTinInput('');
      setSelectedEntity(null);
      setTinSuggestions([]);
      setShowTinSuggestions(false);
      toast({
        title: 'موفق',
        description: 'قضیه جدید با موفقیت ایجاد شد',
      });
    },
    onError: (error: any) => {
      // Handle structured error responses from backend
      const errorMessage = error.messageFa || error.message || 'ایجاد قضیه با مشکل مواجه شد';
      toast({
        title: 'خطا',
        description: errorMessage,
        variant: 'destructive',
      });
    },
  });


  // Fetch case report data
  const { data: caseReportData, refetch: refetchCaseReport } = useQuery({
    queryKey: ['caseReport', selectedCase?.id],
    queryFn: async () => {
      if (!selectedCase) return null;
      const response = await fetch(`/api/cases/${selectedCase.id}/report`, {
        credentials: 'include',
      });
      if (!response.ok) throw new Error('Failed to fetch case report');
      return response.json();
    },
    enabled: !!selectedCase && reportDialogOpen,
  });

  // Save case report mutation
  const saveCaseReportMutation = useMutation({
    mutationFn: async ({ caseId, reportData }: { caseId: string; reportData: any }) => {
      const response = await fetch(`/api/cases/${caseId}/report`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(reportData),
      });
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({ message: 'Failed to save report' }));
        throw new Error(errorData.message || 'Failed to save report');
      }
      return response.json();
    },
  });

  const completeCaseMutation = useMutation({
    mutationFn: async (caseId: string) => {
      const response = await fetch(`/api/cases/${caseId}/complete`, {
        method: 'POST',
        credentials: 'include',
      });
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({ message: 'Failed to complete case' }));
        // Create error with additional data
        const error = new Error(errorData.message || 'Failed to complete case') as any;
        error.missingFields = errorData.missingFields || [];
        error.canOverride = errorData.canOverride || false;
        throw error;
      }
      return response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['cases'] });
      // Refresh entities if entity status was updated
      if (data.entityStatusUpdated) {
        queryClient.invalidateQueries({ queryKey: ['entities'] });
      }
      setReportDialogOpen(false);
      setSelectedCase(null);
      
      // Show success message with completion details
      let message = 'قضیه با موفقیت تکمیل شد';
      if (data.completedBy) {
        const completedByUser = users.find(u => u.id === data.completedBy);
        if (completedByUser) {
          message += ` توسط ${completedByUser.fullName}`;
        }
      }
      if (data.completedAt) {
        message += ` در ${new Date(data.completedAt).toLocaleDateString('fa-IR')}`;
      }
      if (data.entityStatusUpdated) {
        message += ' و وضعیت نهاد بروز رسانی شد';
      }
      
      toast({
        title: 'موفق',
        description: message,
      });
    },
    onError: (error: any) => {
      const missingFields = error.missingFields || [];
      const canOverride = error.canOverride || false;
      
      let errorMessage = error.message || 'تکمیل قضیه با مشکل مواجه شد';
      
      if (missingFields.length > 0) {
        errorMessage += `\n\nفیلدهای ناقص:\n${missingFields.map((field: string, idx: number) => `${idx + 1}. ${field}`).join('\n')}`;
        
        if (canOverride) {
          errorMessage += '\n\nتوجه: با توجه به دسترسی شما، می‌توانید این قضیه را تکمیل کنید، اما توصیه می‌شود ابتدا تمام فیلدها را تکمیل کنید.';
        } else {
          errorMessage += '\n\nلطفاً تمام فیلدهای گزارش را تکمیل کنید و سپس دوباره تلاش کنید.';
        }
      }
      
      toast({
        title: 'خطا در تکمیل قضیه',
        description: errorMessage,
        variant: 'destructive',
        duration: 10000, // Show longer for validation errors
      });
    },
  });

  const handleCompleteCase = (case_: Case) => {
    setSelectedCase(case_);
    setReportDialogOpen(true);
  };

  const handleSaveReport = async (reportData: any) => {
    if (!selectedCase) return;
    
    await saveCaseReportMutation.mutateAsync({
      caseId: selectedCase.id,
      reportData,
    });
    
    // After saving report, complete the case
    completeCaseMutation.mutate(selectedCase.id);
  };


  // Fetch full case data with metrics, installments, flags when viewing
  const { data: fullCaseData, refetch: refetchFullCase } = useQuery({
    queryKey: ['case', selectedCase?.id],
    queryFn: async () => {
      if (!selectedCase?.id) return null;
      const response = await fetch(`/api/cases/${selectedCase.id}`, {
        credentials: 'include',
      });
      if (!response.ok) return null;
      return response.json();
    },
    enabled: !!selectedCase?.id && viewDialogOpen,
  });

  const handleViewCase = async (case_: Case) => {
    setSelectedCase(case_);
    setViewDialogOpen(true);
    // Removed auto-status change - auditor must click "Start Audit Process" button instead
    // The fullCaseData query will automatically fetch the latest case data when viewDialogOpen becomes true
  };

  const handleUploadDocument = (case_: Case) => {
    setSelectedCase(case_);
    setUploadForm({ docType: '', docDate: '', description: '', isFinal: false });
    setSelectedFile(null);
    setUploadDialogOpen(true);
  };

  const handleAssignCase = (case_: Case) => {
    setSelectedCase(case_);
    setSelectedGroupId(null);
    setAssignDialogOpen(true);
    // If case has a receivingGroup, it will be automatically fetched by the query
  };

  // Check if user can assign to groups (system admin or coordinator)
  const canAssignToGroup = currentUser?.role === 'system_admin' || 
                           currentUser?.permissionPackages?.includes('acting_coordinator');

  const uploadDocumentMutation = useMutation({
    mutationFn: async (formData: FormData) => {
      const response = await fetch('/api/documents/upload', {
        method: 'POST',
        body: formData,
        credentials: 'include',
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to upload document');
      }
      return response.json();
    },
    onSuccess: () => {
      // Invalidate documents query with the specific caseId to refresh the counter
      queryClient.invalidateQueries({ queryKey: ['documents', selectedCase?.caseId] });
      queryClient.invalidateQueries({ queryKey: ['documents'] }); // Also invalidate general query
      setUploadDialogOpen(false);
      setUploadForm({ docType: '', docDate: '', description: '', isFinal: false });
      setSelectedFile(null);
      toast({
        title: 'موفق',
        description: 'سند با موفقیت آپلود شد',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'خطا',
        description: error.message || 'آپلود سند با مشکل مواجه شد',
        variant: 'destructive',
      });
    },
  });

  const assignCaseMutation = useMutation({
    mutationFn: async ({ caseId, userId, groupId }: { caseId: string; userId?: string; groupId?: string }) => {
      const response = await fetch(`/api/cases/${caseId}/assign`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId, groupId }),
        credentials: 'include',
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to assign case');
      }
      return response.json();
    },
    onSuccess: (data) => {
      // Invalidate and refetch cases to get updated assigned user info
      queryClient.invalidateQueries({ queryKey: ['cases'] });
      // Also invalidate the specific case query if it exists
      queryClient.invalidateQueries({ queryKey: ['case', data.id] });
      
      setAssignDialogOpen(false);
      setSelectedCase(null);
      setSelectedGroupId(null);
      
      // Show success message with assigned user name if available
      let message = 'قضیه با موفقیت واگذار شد';
      if (data.assignedUser?.fullName) {
        message = `مورد با موفقیت واگذار شد — بررس: ${data.assignedUser.fullName}`;
      } else if (data.groupMembers) {
        message = `قضیه با موفقیت واگذار شد. ${data.groupMembers.length} عضو فعال در گروه.`;
      }
      
      toast({
        title: 'موفق',
        description: message,
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'خطا',
        description: error.message || 'واگذاری قضیه با مشکل مواجه شد',
        variant: 'destructive',
      });
    },
  });

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const ALLOWED_FILE_TYPES = ['application/pdf', 'image/jpeg', 'image/png'];
    const MAX_FILE_SIZE = 25 * 1024 * 1024;

    if (!ALLOWED_FILE_TYPES.includes(file.type)) {
      toast({
        title: 'خطا',
        description: 'نوع فایل مجاز نیست. فقط PDF، JPG و PNG مجاز است',
        variant: 'destructive',
      });
      return;
    }

    if (file.size > MAX_FILE_SIZE) {
      toast({
        title: 'خطا',
        description: `حجم فایل بیش از حد مجاز است (حداکثر 25MB)`,
        variant: 'destructive',
      });
      return;
    }

    setSelectedFile(file);
  };

  const handleUploadSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedFile || !selectedCase) {
      toast({
        title: 'خطا',
        description: 'لطفا فایل و قضیه را انتخاب کنید',
        variant: 'destructive',
      });
      return;
    }

    if (!uploadForm.docType || !uploadForm.docDate) {
      toast({
        title: 'خطا',
        description: 'لطفا نوع سند و تاریخ را وارد کنید',
        variant: 'destructive',
      });
      return;
    }

    const formData = new FormData();
    formData.append('file', selectedFile);
    formData.append('caseId', selectedCase.caseId);
    formData.append('docType', uploadForm.docType);
    formData.append('docDate', uploadForm.docDate);
    formData.append('description', uploadForm.description);
    formData.append('isFinal', uploadForm.isFinal.toString());

    uploadDocumentMutation.mutate(formData);
  };


  // Remove handleEntityChange - now handled by TIN autocomplete

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate that a valid entity is selected via TIN
    if (!selectedEntity || !formData.entityId) {
      toast({
        title: 'خطا',
        description: 'لطفا نمبر تشخیصیه (TIN) را جستجو کرده و یک نهاد را انتخاب کنید',
        variant: 'destructive',
      });
      return;
    }

    // Validate TIN matches selected entity
    if (selectedEntity.tin !== formData.tin || selectedEntity.id !== formData.entityId) {
      toast({
        title: 'خطا',
        description: 'نمبر تشخیصیه انتخاب شده معتبر نیست. لطفا دوباره جستجو کنید',
        variant: 'destructive',
      });
      return;
    }

    // Validate that audit record is selected ONLY if audit records exist for this entity
    // If entity has no audit records (count = 0), audit record is optional
    if (entityAuditRecords.length > 0 && (!formData.auditRecordId || formData.auditRecordId.trim() === '')) {
      toast({
        title: 'خطا',
        description: 'لطفاً یک سابقه بررسی موجود را انتخاب کنید',
        variant: 'destructive',
      });
      return;
    }

    // Validate that referring group is explicitly selected
    if (!formData.groupReferrer || formData.groupReferrer.trim() === '') {
      toast({
        title: 'خطا',
        description: 'لطفاً گروه ارجاع‌دهنده را انتخاب کنید',
        variant: 'destructive',
      });
      return;
    }

    // Validate that year range is selected
    if (!startYear || !endYear) {
      toast({
        title: 'خطا',
        description: 'لطفاً سال شروع و سال پایان بررسی را انتخاب کنید',
        variant: 'destructive',
      });
      return;
    }

    const selectedEntityObj = selectedEntity;
    
    createCaseMutation.mutate({
      entityId: formData.entityId,
      // Only include auditRecordId if it's provided (optional when entity has no audit records)
      ...(formData.auditRecordId && formData.auditRecordId.trim() !== '' ? { auditRecordId: formData.auditRecordId } : {}),
      companyName: selectedEntityObj.companyName,
      tin: selectedEntityObj.tin,
      businessNature: selectedEntityObj.businessNature,
      auditYearRange: formData.auditYearRange || null,
      committeeId: formData.committeeId || null,
      referralDate: formData.referralDate,
      groupReferrer: formData.groupReferrer, // گروه ارجاع‌دهنده (explicitly selected by user)
      receivingGroup: formData.receivingGroup, // گروه دریافت‌کننده (audit group)
      notes: formData.notes,
    } as any); // Type assertion needed as auditRecordId is validated by backend but not in InsertCase type
  };

  return (
    <div className="p-8 space-y-6" dir="rtl" style={{ direction: 'rtl', textAlign: 'right' }}>
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-semibold">مدیریت قضایا</h1>
          <p className="text-muted-foreground">مدیریت و پیگیری قضایای بررسی</p>
        </div>
        {/* Only show create button if user has entities:create permission (not auditors) */}
        {currentUser && userHasPermission(currentUser, 'entities:create') && (
          <Dialog open={dialogOpen} onOpenChange={(open) => {
            setDialogOpen(open);
            if (!open) {
              // Reset form when dialog closes
              setFormData({ entityId: '', tin: '', auditRecordId: '', groupReferrer: '', receivingGroup: '', auditYearRange: '', committeeId: '', referralDate: '', notes: '' });
      setStartYear('');
      setEndYear('');
              setTinInput('');
              setSelectedEntity(null);
              setTinSuggestions([]);
              setShowTinSuggestions(false);
              setTinSearchQuery('');
              setPreSelectedEntityId(null);
              setPreSelectedAuditRecordIdState(null);
              setAuditRecordSelectorDisabled(false);
              setEntityLoadError(null);
            }
          }}>
            <DialogTrigger asChild>
              <Button data-testid="button-create-case">
                <Plus className="ml-2 h-4 w-4" />
                قضیه جدید
              </Button>
            </DialogTrigger>
          <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>ایجاد قضیه جدید</DialogTitle>
              <DialogDescription>
                اطلاعات قضیه جدید را وارد کنید. شماره قضیه به صورت خودکار ایجاد می‌شود.
              </DialogDescription>
            </DialogHeader>
            
            {/* UI Feedback / Pre-selection - Show selected entity */}
            {selectedEntity && (
              <div className="p-4 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg mb-4">
                <div className="flex items-start gap-3">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <Badge variant="default" className="bg-blue-600">
                        نهاد انتخاب شده
                      </Badge>
                    </div>
                    <div className="text-sm space-y-1">
                      <div className="font-semibold text-blue-900 dark:text-blue-100">
                        {selectedEntity.companyName}
                      </div>
                      <div className="text-blue-700 dark:text-blue-300">
                        نمبر تشخیصیه: {selectedEntity.tin}
                      </div>
                      {selectedEntity.businessNature && (
                        <div className="text-blue-600 dark:text-blue-400">
                          ماهیت تشبث: {selectedEntity.businessNature}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Error message for entity loading */}
            {entityLoadError && (
              <div className="p-4 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg mb-4">
                <div className="text-sm text-red-800 dark:text-red-200">
                  <strong>خطا:</strong> {entityLoadError}
                </div>
                <p className="text-xs text-red-600 dark:text-red-400 mt-2">
                  لطفا نهاد را به صورت دستی انتخاب کنید یا دوباره تلاش کنید.
                </p>
              </div>
            )}

            {/* Loading indicator for entity */}
            {isLoadingPreSelectedEntity && (
              <div className="p-4 bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 rounded-lg mb-4">
                <div className="text-sm text-yellow-800 dark:text-yellow-200">
                  در حال بارگذاری اطلاعات نهاد...
                </div>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="tin">نمبر تشخیصیه (TIN) *</Label>
                  <div className="relative">
                    <Input
                      ref={tinInputRef}
                      id="tin"
                      value={tinInput}
                      onChange={handleTinInputChange}
                      className="text-right"
                      placeholder="جستجو کنید (حداقل 1 کاراکتر)"
                      data-testid="input-tin-search"
                      required
                      autoComplete="off"
                      onFocus={() => {
                        if (tinSuggestions.length > 0 || tinSearchQuery.trim().length >= 1) {
                          setShowTinSuggestions(true);
                        }
                      }}
                    />
                    {showTinSuggestions && (tinSuggestions.length > 0 || (tinSearchQuery.trim().length >= 1 && !tinSearchLoading)) && (
                      <div
                        ref={suggestionsRef}
                        className="absolute z-50 w-full mt-1 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-md shadow-lg max-h-60 overflow-auto"
                        dir="rtl"
                      >
                        {tinSearchLoading ? (
                          <div className="p-3 text-sm text-muted-foreground text-center">در حال جستجو...</div>
                        ) : tinSuggestions.length === 0 ? (
                          <div className="p-3 text-sm text-muted-foreground text-center">
                            {tinSearchQuery.trim().length >= 1 ? 'نهاد یافت نشد' : 'جستجو کنید'}
                          </div>
                        ) : (
                          tinSuggestions.map((entity) => (
                            <div
                              key={entity.id}
                              className="p-3 hover:bg-gray-100 dark:hover:bg-gray-700 cursor-pointer border-b border-gray-200 dark:border-gray-700 last:border-b-0"
                              onClick={() => handleTinSelect(entity)}
                            >
                              <div className="font-medium text-right">{entity.companyName}</div>
                              <div className="text-sm text-muted-foreground text-right">TIN: {entity.tin}</div>
                              {entity.businessNature && (
                                <div className="text-xs text-muted-foreground text-right mt-1">{entity.businessNature}</div>
                              )}
                            </div>
                          ))
                        )}
                      </div>
                    )}
                  </div>
                  {selectedEntity && (
                    <p className="text-xs text-green-600">✓ نهاد انتخاب شده: {selectedEntity.companyName}</p>
                  )}
                  {tinInput && !selectedEntity && tinSearchQuery.trim().length >= 1 && !tinSearchLoading && tinSuggestions.length === 0 && (
                    <p className="text-xs text-red-600">نهاد با این نمبر تشخیصیه یافت نشد</p>
                  )}
                </div>
                <div className="space-y-2">
                  <Label htmlFor="companyName">نام شرکت</Label>
                  <Input
                    id="companyName"
                    value={selectedEntity?.companyName || ''}
                    disabled
                    className="text-right bg-muted"
                    placeholder="از TIN انتخاب شده پر می‌شود"
                    data-testid="input-company-name"
                  />
                </div>
              </div>
              
              {/* Audit Record Selector - Only show if entity has audit records */}
              {selectedEntity && formData.entityId && entityAuditRecords.length > 0 && (
                <div className="space-y-2">
                  <Label htmlFor="auditRecordId">سابقه بررسی *</Label>
                  {isLoadingEntityAuditRecords ? (
                    <div className="p-3 text-sm text-muted-foreground text-center border rounded-md">
                      در حال بارگذاری سوابق بررسی...
                    </div>
                  ) : (
                    <Select
                      value={formData.auditRecordId}
                      onValueChange={(v) => setFormData({ ...formData, auditRecordId: v })}
                      disabled={auditRecordSelectorDisabled}
                    >
                      <SelectTrigger 
                        id="auditRecordId" 
                        data-testid="select-audit-record" 
                        className="text-right" 
                        dir="rtl"
                      >
                        <SelectValue placeholder="انتخاب سابقه بررسی" />
                      </SelectTrigger>
                      <SelectContent dir="rtl">
                        {entityAuditRecords.length === 0 ? (
                          <SelectItem value="no-records" disabled>
                            هیچ سابقه بررسی یافت نشد
                          </SelectItem>
                        ) : (
                          entityAuditRecords.map((record: any) => {
                            const yearRange = record.auditYears || 
                              (record.yearFrom && record.yearTo 
                                ? (record.yearFrom === record.yearTo 
                                    ? record.yearFrom.toString() 
                                    : `${record.yearFrom}-${record.yearTo}`)
                                : '-');
                            const statusLabel = record.status === 'completed' ? 'تکمیل شده' :
                              record.status === 'in-progress' ? 'در جریان' :
                              record.status === 'archived' ? 'بایگانی شده' : record.status;
                            const groupName = record.auditGroupInfo?.name || record.assignedGroup || '-';
                            
                            // Check if completed - show warning but allow selection
                            const isCompleted = record.status === 'completed';
                            
                            return (
                              <SelectItem 
                                key={record.id} 
                                value={record.id}
                                disabled={isCompleted}
                              >
                                <div className="flex items-center justify-between w-full">
                                  <span>{yearRange}</span>
                                  <span className="text-xs text-muted-foreground mr-2">
                                    {groupName} - {statusLabel}
                                    {isCompleted && ' (تکمیل شده)'}
                                  </span>
                                </div>
                              </SelectItem>
                            );
                          })
                        )}
                      </SelectContent>
                    </Select>
                  )}
                  {entityAuditRecords.length === 0 && !isLoadingEntityAuditRecords && (
                    <div className="p-3 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-md">
                      <p className="text-sm text-blue-800 dark:text-blue-200">
                        این نهاد هنوز سابقه بررسی ندارد. می‌توانید قضیه را بدون انتخاب سابقه بررسی ایجاد کنید.
                      </p>
                      {formData.entityId && (
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            setLocation(`/entities?createAuditFor=${formData.entityId}`);
                            setDialogOpen(false);
                          }}
                          className="mt-2"
                        >
                          <Plus className="ml-2 h-4 w-4" />
                          ایجاد سابقه بررسی جدید (اختیاری)
                        </Button>
                      )}
                    </div>
                  )}
                  {auditRecordSelectorDisabled && (
                    <p className="text-xs text-muted-foreground">
                      سابقه بررسی از صفحه جزئیات انتخاب شده است
                    </p>
                  )}
                  {!auditRecordSelectorDisabled && entityAuditRecords.length > 0 && (
                    <p className="text-xs text-muted-foreground">
                      لطفاً یک سابقه بررسی موجود را انتخاب کنید
                    </p>
                  )}
                </div>
              )}

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>سال شروع بررسی *</Label>
                  <Select
                    value={startYear}
                    onValueChange={(value) => {
                      setStartYear(value);
                      // If endYear is less than new startYear, set endYear to startYear
                      if (endYear && parseInt(value) > parseInt(endYear)) {
                        setEndYear(value);
                      }
                    }}
                  >
                    <SelectTrigger className="text-right" dir="rtl">
                      <SelectValue placeholder="انتخاب سال شروع" />
                    </SelectTrigger>
                    <SelectContent dir="rtl">
                      {yearOptions.map((year) => (
                        <SelectItem key={year} value={year}>
                          {year}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>سال پایان بررسی *</Label>
                  <Select
                    value={endYear}
                    onValueChange={(value) => {
                      setEndYear(value);
                    }}
                    disabled={!startYear}
                  >
                    <SelectTrigger className="text-right" dir="rtl">
                      <SelectValue placeholder={startYear ? "انتخاب سال پایان" : "ابتدا سال شروع را انتخاب کنید"} />
                    </SelectTrigger>
                    <SelectContent dir="rtl">
                      {yearOptions
                        .filter((year) => !startYear || parseInt(year) >= parseInt(startYear))
                        .map((year) => (
                          <SelectItem key={year} value={year}>
                            {year}
                          </SelectItem>
                        ))}
                    </SelectContent>
                  </Select>
                  {startYear && endYear && (
                    <p className="text-xs text-muted-foreground">
                      {startYear === endYear ? startYear : `${startYear}–${endYear}`}
                    </p>
                  )}
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="committeeId">کمیته</Label>
                  <Select 
                    value={formData.committeeId || undefined} 
                    onValueChange={(v) => setFormData({ ...formData, committeeId: v || '' })}
                    disabled={committeesLoading}
                  >
                    <SelectTrigger id="committeeId" className="text-right" dir="rtl">
                      <SelectValue placeholder={
                        committeesLoading 
                          ? "در حال بارگذاری..." 
                          : committeesError 
                            ? "خطا در بارگذاری" 
                            : "انتخاب کمیته (اختیاری)"
                      } />
                    </SelectTrigger>
                    <SelectContent dir="rtl">
                      {committeesLoading ? (
                        <SelectItem value="__loading__" disabled>
                          در حال بارگذاری...
                        </SelectItem>
                      ) : committeesError ? (
                        <SelectItem value="__error__" disabled>
                          خطا در بارگذاری کمیته‌ها
                        </SelectItem>
                      ) : committees.filter(c => c.status === 'APPROVED' || c.status === 'DRAFT').length === 0 ? (
                        <SelectItem value="__empty__" disabled>
                          هیچ کمیته‌ای یافت نشد
                        </SelectItem>
                      ) : (
                        committees
                          .filter(c => c.status === 'APPROVED' || c.status === 'DRAFT')
                          .map((committee) => {
                            // Map month number to Afghan month name
                            const afghanMonths = ['حمل', 'ثور', 'جوزا', 'سرطان', 'اسد', 'سنبله', 'میزان', 'عقرب', 'قوس', 'جدی', 'دلو', 'حوت'];
                            const monthName = afghanMonths[committee.month - 1] || `ماه ${committee.month}`;
                            return (
                              <SelectItem key={committee.id} value={committee.id}>
                                {committee.title} ({monthName} {committee.year})
                              </SelectItem>
                            );
                          })
                      )}
                    </SelectContent>
                  </Select>
                  <p className="text-xs text-muted-foreground">کمیته مربوطه (اختیاری)</p>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="referralDate">تاریخ ارجاع *</Label>
                  <ShamsiDatePickerDDMMYYYY
                    value={formData.referralDate}
                    onChange={(date) => setFormData({ ...formData, referralDate: date })}
                    required
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="groupReferrer">گروه ارجاع‌دهنده *</Label>
                  <Select 
                    value={formData.groupReferrer} 
                    onValueChange={(v) => setFormData({ ...formData, groupReferrer: v })}
                  >
                    <SelectTrigger 
                      id="groupReferrer" 
                      data-testid="select-referral-group" 
                      className="text-right" 
                      dir="rtl"
                    >
                      <SelectValue placeholder="انتخاب کنید" />
                    </SelectTrigger>
                    <SelectContent dir="rtl">
                      {STATIC_REFERRAL_GROUPS.map((group) => (
                        <SelectItem key={group.id} value={group.name}>
                          {group.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <p className="text-xs text-muted-foreground">لطفاً گروه ارجاع‌دهنده را انتخاب کنید</p>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="receivingGroup">گروه دریافت‌کننده *</Label>
                  <Select value={formData.receivingGroup} onValueChange={(v) => setFormData({ ...formData, receivingGroup: v })}>
                    <SelectTrigger id="receivingGroup" data-testid="select-receiving-group" className="text-right" dir="rtl">
                      <SelectValue placeholder={isLoadingAuditGroups ? "در حال بارگذاری..." : "انتخاب کنید"} />
                    </SelectTrigger>
                    <SelectContent dir="rtl">
                      {isLoadingAuditGroups ? (
                        <SelectItem value="loading" disabled>در حال بارگذاری...</SelectItem>
                      ) : auditGroupsError ? (
                        <SelectItem value="error" disabled>خطا در بارگذاری گروه‌ها</SelectItem>
                      ) : auditGroups.length === 0 ? (
                        <SelectItem value="empty" disabled>گروه بررسی یافت نشد</SelectItem>
                      ) : (
                        auditGroups.map((group) => (
                          <SelectItem key={group.id} value={group.id}>
                            {group.name}
                          </SelectItem>
                        ))
                      )}
                    </SelectContent>
                  </Select>
                  <p className="text-xs text-muted-foreground">
                    {isLoadingAuditGroups ? "در حال بارگذاری گروه های بررسی..." : auditGroupsError ? "خطا در بارگذاری" : `فقط گروه های بررسی (${auditGroups.length} گروه)`}
                  </p>
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="notes">ملاحظات</Label>
                <Textarea
                  id="notes"
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  data-testid="textarea-notes"
                  className="text-right"
                />
              </div>
              <div className="flex gap-2 justify-end">
                <Button type="button" variant="outline" onClick={() => setDialogOpen(false)} data-testid="button-cancel">
                  لغو
                </Button>
                <Button 
                  type="submit" 
                  data-testid="button-submit-case"
                  disabled={
                    // Only require auditRecordId if audit records exist
                    (entityAuditRecords.length > 0 && !formData.auditRecordId) ||
                    isLoadingEntityAuditRecords ||
                    !formData.entityId ||
                    !selectedEntity
                  }
                >
                  ایجاد قضیه
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
        )}
      </div>

      <Card dir="rtl" style={{ direction: 'rtl' }}>
        <Tabs value={activeTab} onValueChange={(v) => {
          setActiveTab(v as 'all-cases' | 'newly-assigned' | 'completed' | 'committee-cases' | 'installment-cases' | 'law-enforcement-cases');
          setCurrentPage(1); // Reset pagination on tab change
        }}>
          <CardHeader className="space-y-4">
            {/* Tabs at the top - horizontal layout */}
            <div className="flex items-center justify-between w-full" dir="rtl" style={{ direction: 'rtl' }}>
              <TabsList dir="rtl" className="text-right">
                <TabsTrigger value="all-cases" className="text-right" dir="rtl">
                  همه قضایا
                  {(() => {
                    const count = cases.length;
                    return count > 0 ? <Badge variant="secondary" className="mr-2">{count}</Badge> : null;
                  })()}
                </TabsTrigger>
                <TabsTrigger value="newly-assigned" className="text-right" dir="rtl">
                  قضایای تازه اختصاص داده شده
                  {(() => {
                    const count = cases.filter(c => {
                      const status = c.status as string;
                      return status === CaseStatus.CREATED ||
                             status === CaseStatus.PENDING_SENIOR_REVIEW ||
                             status === CaseStatus.UNDER_REVIEW ||
                             status === CaseStatus.PENDING_DOCUMENTS ||
                             status === 'ایجاد شده' ||
                             status === 'در انتظار بررسی بازرس ارشد' ||
                             status === 'در حال بررسی' ||
                             status === 'در انتظار تکمیل مدارک';
                    }).length;
                    return count > 0 ? <Badge variant="secondary" className="mr-2">{count}</Badge> : null;
                  })()}
                </TabsTrigger>
                <TabsTrigger value="completed" className="text-right" dir="rtl">
                  قضایای تکمیل شده
                  {(() => {
                    const count = cases.filter(c => 
                      c.status === CaseStatus.COMPLETED || c.status === 'تکمیل شده'
                    ).length;
                    return count > 0 ? <Badge variant="secondary" className="mr-2">{count}</Badge> : null;
                  })()}
                </TabsTrigger>
                <TabsTrigger value="committee-cases" className="text-right" dir="rtl">
                  دوسیه‌های کمیته جدید
                  {(() => {
                    // NEW COMMITTEE MODULE: Count cases with status "در انتظار بررسی" and currentAuditGroupId
                    const count = cases.filter(c => {
                      const status = (c.status as string)?.toString().trim() || '';
                      const hasCurrentAuditGroup = (c as any).currentAuditGroupId || 
                                                  (c as any).current_assignment_id ||
                                                  c.receivingGroup;
                      const isCommitteeCase = status === 'در انتظار بررسی' && 
                                             !!hasCurrentAuditGroup;
                      return isCommitteeCase;
                    }).length;
                    return count > 0 ? <Badge variant="secondary" className="mr-2">{count}</Badge> : null;
                  })()}
                </TabsTrigger>
                <TabsTrigger value="installment-cases" className="text-right" dir="rtl">
                  قضایای در اقساط
                  {(() => {
                    // Filter by isTaxInstallment flag (not status)
                    const count = cases.filter(c => {
                      return (c as any).isTaxInstallment === true || (c as any).is_tax_installment === true;
                    }).length;
                    return count > 0 ? <Badge variant="secondary" className="mr-2">{count}</Badge> : null;
                  })()}
                </TabsTrigger>
                <TabsTrigger value="law-enforcement-cases" className="text-right" dir="rtl">
                  قضایای ارسال‌شده به تنفیذ قانون
                  {(() => {
                    // Filter by isLawEnforcement flag (not status)
                    const count = cases.filter(c => {
                      return (c as any).isLawEnforcement === true || (c as any).is_law_enforcement === true;
                    }).length;
                    return count > 0 ? <Badge variant="secondary" className="mr-2">{count}</Badge> : null;
                  })()}
                </TabsTrigger>
              </TabsList>
              {activeTab === 'completed' && (
                <div className="flex gap-2" dir="rtl">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={async () => {
                      try {
                        const response = await fetch('/api/cases/export/completed', {
                          method: 'POST',
                          headers: { 'Content-Type': 'application/json' },
                          credentials: 'include',
                          body: JSON.stringify({
                            filters: {
                              entityName: entityNameFilter,
                              tin: tinFilter,
                              assignedAuditor: assignedAuditorFilter,
                              createdDateFrom,
                              createdDateTo,
                              caseType: caseTypeFilter,
                            },
                          }),
                        });
                        if (!response.ok) throw new Error('Export failed');
                        const blob = await response.blob();
                        const url = window.URL.createObjectURL(blob);
                        const a = document.createElement('a');
                        a.href = url;
                        a.download = `completed-cases-${new Date().toISOString().split('T')[0]}.xlsx`;
                        document.body.appendChild(a);
                        a.click();
                        window.URL.revokeObjectURL(url);
                        document.body.removeChild(a);
                        toast({ title: 'موفق', description: 'گزارش با موفقیت دانلود شد' });
                      } catch (error: any) {
                        toast({ title: 'خطا', description: error.message || 'خطا در دانلود', variant: 'destructive' });
                      }
                    }}
                  >
                    <FileSpreadsheet className="ml-2 h-4 w-4" />
                    دانلود Excel
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={async () => {
                      try {
                        const response = await fetch('/api/cases/export/completed/pdf', {
                          method: 'POST',
                          headers: { 'Content-Type': 'application/json' },
                          credentials: 'include',
                          body: JSON.stringify({
                            filters: {
                              entityName: entityNameFilter,
                              tin: tinFilter,
                              assignedAuditor: assignedAuditorFilter,
                              createdDateFrom,
                              createdDateTo,
                              caseType: caseTypeFilter,
                            },
                          }),
                        });
                        if (!response.ok) throw new Error('Export failed');
                        const blob = await response.blob();
                        const url = window.URL.createObjectURL(blob);
                        const a = document.createElement('a');
                        a.href = url;
                        a.download = `completed-cases-${new Date().toISOString().split('T')[0]}.pdf`;
                        document.body.appendChild(a);
                        a.click();
                        window.URL.revokeObjectURL(url);
                        document.body.removeChild(a);
                        toast({ title: 'موفق', description: 'PDF با موفقیت دانلود شد' });
                      } catch (error: any) {
                        toast({ title: 'خطا', description: error.message || 'خطا در دانلود', variant: 'destructive' });
                      }
                    }}
                  >
                    <FileText className="ml-2 h-4 w-4" />
                    دانلود PDF
                  </Button>
                </div>
              )}
            </div>
            
            {/* Filters and Search at the top - horizontal layout */}
            <div className="flex items-center gap-4 w-full" dir="rtl" style={{ direction: 'rtl' }}>
              <Collapsible open={filtersOpen} onOpenChange={setFiltersOpen}>
                <CollapsibleTrigger asChild>
                  <Button variant="outline" size="sm" className="text-right">
                    <Filter className="ml-2 h-4 w-4" />
                    فیلترها
                  </Button>
                </CollapsibleTrigger>
                <CollapsibleContent className="mt-4 p-4 border rounded-lg bg-muted/50">
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <Label>نام نهاد</Label>
                      <Input
                        value={entityNameFilter}
                        onChange={(e) => {
                          setEntityNameFilter(e.target.value);
                          setCurrentPage(1);
                        }}
                        className="text-right"
                        placeholder="نام نهاد..."
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>نمبر تشخیصیه (TIN)</Label>
                      <Input
                        value={tinFilter}
                        onChange={(e) => {
                          setTinFilter(e.target.value);
                          setCurrentPage(1);
                        }}
                        className="text-right"
                        placeholder="TIN..."
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>بررس اختصاص داده شده</Label>
                      <Select value={assignedAuditorFilter || "all"} onValueChange={(v) => {
                        setAssignedAuditorFilter(v === "all" ? '' : v);
                        setCurrentPage(1);
                      }}>
                        <SelectTrigger className="text-right" dir="rtl">
                          <SelectValue placeholder="همه" />
                        </SelectTrigger>
                        <SelectContent dir="rtl">
                          <SelectItem value="all">همه</SelectItem>
                          {users.filter(u => u.role === 'auditor' || u.role === 'senior_auditor').map((user) => (
                            <SelectItem key={user.id} value={user.id}>
                              {user.fullName}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label>تاریخ ایجاد از</Label>
                      <ShamsiDatePickerDDMMYYYY
                        value={createdDateFrom}
                        onChange={(date) => {
                          setCreatedDateFrom(date);
                          setCurrentPage(1);
                        }}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>تاریخ ایجاد تا</Label>
                      <ShamsiDatePickerDDMMYYYY
                        value={createdDateTo}
                        onChange={(date) => {
                          setCreatedDateTo(date);
                          setCurrentPage(1);
                        }}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>سال های بررسی</Label>
                      <Input
                        value={caseTypeFilter}
                        onChange={(e) => {
                          setCaseTypeFilter(e.target.value);
                          setCurrentPage(1);
                        }}
                        className="text-right"
                        placeholder="سال های بررسی..."
                      />
                    </div>
                  </div>
                  <div className="flex justify-end mt-4">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => {
                        setEntityNameFilter('');
                        setTinFilter('');
                        setAssignedAuditorFilter('');
                        setCreatedDateFrom('');
                        setCreatedDateTo('');
                        setCaseTypeFilter('');
                        setCurrentPage(1);
                      }}
                    >
                      پاک کردن فیلترها
                    </Button>
                  </div>
                </CollapsibleContent>
              </Collapsible>
              <div className="relative flex-1">
                <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="جستجو بر اساس نمبر قضیه، نام شرکت یا نمبر تشخیصیه..."
                  value={searchQuery}
                  onChange={(e) => {
                    setSearchQuery(e.target.value);
                    setCurrentPage(1);
                  }}
                  className="pr-10 text-right"
                  dir="rtl"
                  data-testid="input-search-cases"
                />
              </div>
            </div>
          </CardHeader>
          <CardContent>
          {isLoading || (activeTab === 'installment-cases' && isLoadingUnpaid) ? (
            <div className="text-center py-8 text-muted-foreground">در حال بارگذاری...</div>
          ) : (() => {
            // Filter cases based on active tab
            // For installment-cases, use unpaidCases (already filtered by remaining balance)
            const baseCases = activeTab === 'installment-cases' ? unpaidCases : cases;
            let filteredCases = baseCases.filter((case_) => {
              const caseStatus: string = case_.status as string;
              const caseCommitteeId = (case_ as any).committeeId;
              const caseAuditYearRange = (case_ as any).auditYearRange;
              
              if (activeTab === 'all-cases') {
                // All Cases tab - apply universal filters
                // Status filter
                if (universalStatusFilter !== 'all' && caseStatus !== universalStatusFilter) {
                  return false;
                }
                // Group filter
                if (universalGroupFilter !== 'all' && case_.receivingGroup !== universalGroupFilter) {
                  return false;
                }
                // Committee filter
                if (universalCommitteeFilter !== 'all' && caseCommitteeId !== universalCommitteeFilter) {
                  return false;
                }
                // Entity type filter (business nature)
                if (universalEntityTypeFilter !== 'all' && case_.businessNature !== universalEntityTypeFilter) {
                  return false;
                }
                // Audit year filter
                if (universalAuditYearFilter && (!caseAuditYearRange || !caseAuditYearRange.includes(universalAuditYearFilter))) {
                  return false;
                }
                // Date filters
                if (universalDateFromFilter || universalDateToFilter) {
                  const caseDate = case_.createdAt ? new Date(case_.createdAt) : null;
                  if (universalDateFromFilter && caseDate && caseDate < new Date(universalDateFromFilter)) {
                    return false;
                  }
                  if (universalDateToFilter && caseDate && caseDate > new Date(universalDateToFilter)) {
                    return false;
                  }
                }
                // Continue with search and other filters below
              } else if (activeTab === 'newly-assigned') {
                // Newly assigned: new, assigned, in-progress, pending review by senior auditor, assigned to auditor (but not committee cases)
                // BUG FIX #1: Include ASSIGNED_TO_AUDITOR status so assigned auditors see cases after assignment
                // Exclude committee cases (status "Pending Group Assignment" with committeeId)
                if (caseStatus === 'Pending Group Assignment' && caseCommitteeId) {
                  return false;
                }
                const isNewlyAssigned = caseStatus === CaseStatus.CREATED ||
                                       caseStatus === CaseStatus.PENDING_SENIOR_REVIEW ||
                                       caseStatus === CaseStatus.UNDER_REVIEW ||
                                       caseStatus === CaseStatus.PENDING_DOCUMENTS ||
                                       caseStatus === 'ایجاد شده' ||
                                       caseStatus === 'در انتظار بررسی بازرس ارشد' ||
                                       caseStatus === 'در حال بررسی' ||
                                       caseStatus === 'در انتظار تکمیل مدارک';
                if (!isNewlyAssigned) return false;
              } else if (activeTab === 'committee-cases') {
                // NEW COMMITTEE MODULE: Cases assigned via committees
                // Cases have status "در انتظار بررسی" and currentAuditGroupId set
                const normalizedStatus = caseStatus?.toString().trim() || '';
                const hasCurrentAuditGroup = (case_ as any).currentAuditGroupId || 
                                            (case_ as any).current_assignment_id ||
                                            case_.receivingGroup;
                const isCommitteeCase = normalizedStatus === 'در انتظار بررسی' && 
                                       !!hasCurrentAuditGroup;
                if (!isCommitteeCase) return false;
              } else if (activeTab === 'installment-cases') {
                // Filter by isTaxInstallment flag (not status)
                const isInstallment = (case_ as any).isTaxInstallment === true || 
                                     (case_ as any).is_tax_installment === true;
                if (!isInstallment) return false;
              } else if (activeTab === 'law-enforcement-cases') {
                // Filter by isLawEnforcement flag (not status)
                const isLawEnforcement = (case_ as any).isLawEnforcement === true || 
                                        (case_ as any).is_law_enforcement === true;
                if (!isLawEnforcement) return false;
              } else {
                // Completed: only COMPLETED status
                const isCompleted = caseStatus === CaseStatus.COMPLETED || 
                                   caseStatus === 'تکمیل شده';
                if (!isCompleted) return false;
              }
              
              // Apply search query
              const matchesSearch = !searchQuery || 
                case_.caseId.toLowerCase().includes(searchQuery.toLowerCase()) ||
                case_.companyName?.toLowerCase().includes(searchQuery.toLowerCase()) ||
                case_.tin?.toLowerCase().includes(searchQuery.toLowerCase());
              
              // Apply filters
              const matchesEntityName = !entityNameFilter || 
                case_.companyName?.toLowerCase().includes(entityNameFilter.toLowerCase());
              
              const matchesTin = !tinFilter || 
                case_.tin?.toLowerCase().includes(tinFilter.toLowerCase());
              
              const matchesAuditor = !assignedAuditorFilter || 
                case_.assignedTo === assignedAuditorFilter;
              
              // Date filtering (simplified - would need proper date parsing)
              const matchesDateFrom = !createdDateFrom || true; // TODO: Implement date comparison
              const matchesDateTo = !createdDateTo || true; // TODO: Implement date comparison
              
              const matchesCaseType = !caseTypeFilter || 
                case_.periodsUnderReview?.toLowerCase().includes(caseTypeFilter.toLowerCase());
              
              return matchesSearch && matchesEntityName && matchesTin && 
                     matchesAuditor && matchesDateFrom && matchesDateTo && matchesCaseType;
            });
            
            // Sort cases
            filteredCases.sort((a, b) => {
              let comparison = 0;
              if (sortField === 'createdAt') {
                const dateA = new Date(a.createdAt || 0).getTime();
                const dateB = new Date(b.createdAt || 0).getTime();
                comparison = dateA - dateB;
              } else if (sortField === 'companyName') {
                comparison = (a.companyName || '').localeCompare(b.companyName || '');
              } else if (sortField === 'assignedTo') {
                const userA = users.find(u => u.id === a.assignedTo)?.fullName || '';
                const userB = users.find(u => u.id === b.assignedTo)?.fullName || '';
                comparison = userA.localeCompare(userB);
              }
              return sortDirection === 'asc' ? comparison : -comparison;
            });
            
            // Pagination
            const totalPages = Math.ceil(filteredCases.length / itemsPerPage);
            const startIndex = (currentPage - 1) * itemsPerPage;
            const endIndex = startIndex + itemsPerPage;
            const paginatedCases = filteredCases.slice(startIndex, endIndex);
            
            return (
              <>
                <TabsContent value="all-cases" className="mt-0">
                  {/* Universal Cases Tab - All Cases with Filters */}
                  <div className="space-y-4">
                    {/* Filters Section */}
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 p-4 bg-muted/50 rounded-lg border">
                      <div className="space-y-2">
                        <Label>وضعیت</Label>
                        <Select value={universalStatusFilter} onValueChange={setUniversalStatusFilter}>
                          <SelectTrigger dir="rtl">
                            <SelectValue placeholder="همه وضعیت‌ها" />
                          </SelectTrigger>
                          <SelectContent dir="rtl">
                            <SelectItem value="all">همه وضعیت‌ها</SelectItem>
                            <SelectItem value="جدید">جدید</SelectItem>
                            <SelectItem value="اختصاص داده شده">اختصاص داده شده</SelectItem>
                            <SelectItem value="منتظر بررسی بازرس ارشد">منتظر بررسی بازرس ارشد</SelectItem>
                            <SelectItem value="اختصاص داده شده به بازرس">اختصاص داده شده به بازرس</SelectItem>
                            <SelectItem value="در جریان بررسی">در جریان بررسی</SelectItem>
                            <SelectItem value="تکمیل شده">تکمیل شده</SelectItem>
                            <SelectItem value="در اقساط">در اقساط</SelectItem>
                            <SelectItem value="ارسال‌شده به تنفیذ قانون">ارسال‌شده به تنفیذ قانون</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label>گروه</Label>
                        <Select value={universalGroupFilter} onValueChange={setUniversalGroupFilter}>
                          <SelectTrigger dir="rtl">
                            <SelectValue placeholder="همه گروه‌ها" />
                          </SelectTrigger>
                          <SelectContent dir="rtl">
                            <SelectItem value="all">همه گروه‌ها</SelectItem>
                            {groups.map((group) => (
                              <SelectItem key={group.id} value={group.id}>{group.name}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label>کمیته</Label>
                        <Select value={universalCommitteeFilter} onValueChange={setUniversalCommitteeFilter}>
                          <SelectTrigger dir="rtl">
                            <SelectValue placeholder="همه کمیته‌ها" />
                          </SelectTrigger>
                          <SelectContent dir="rtl">
                            <SelectItem value="all">همه کمیته‌ها</SelectItem>
                            {/* Committees will be fetched separately */}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label>سال بررسی</Label>
                        <Input
                          value={universalAuditYearFilter}
                          onChange={(e) => setUniversalAuditYearFilter(e.target.value)}
                          placeholder="مثال: 1399"
                          dir="rtl"
                          className="text-right"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>از تاریخ</Label>
                        <ShamsiDatePickerDDMMYYYY
                          value={universalDateFromFilter}
                          onChange={setUniversalDateFromFilter}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>تا تاریخ</Label>
                        <ShamsiDatePickerDDMMYYYY
                          value={universalDateToFilter}
                          onChange={setUniversalDateToFilter}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>ماهیت تشبث</Label>
                        <Select value={universalEntityTypeFilter} onValueChange={setUniversalEntityTypeFilter}>
                          <SelectTrigger dir="rtl">
                            <SelectValue placeholder="همه انواع" />
                          </SelectTrigger>
                          <SelectContent dir="rtl">
                            <SelectItem value="all">همه انواع</SelectItem>
                            {/* Entity types will be populated from cases */}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="flex items-end">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            setUniversalStatusFilter('all');
                            setUniversalGroupFilter('all');
                            setUniversalCommitteeFilter('all');
                            setUniversalEntityTypeFilter('all');
                            setUniversalAuditYearFilter('');
                            setUniversalDateFromFilter('');
                            setUniversalDateToFilter('');
                          }}
                        >
                          پاک کردن فیلترها
                        </Button>
                      </div>
                    </div>
                    
                    {/* Cases Table */}
                    {filteredCases.length === 0 ? (
                      <div className="text-center py-8 text-muted-foreground">هیچ قضیه‌ای یافت نشد</div>
                    ) : (
                      <>
                        <Table dir="rtl">
                          <TableHeader>
                            <TableRow>
                              <TableHead className="text-right" dir="rtl">نمبر قضیه</TableHead>
                              <TableHead className="text-right" dir="rtl">نام نهاد</TableHead>
                              <TableHead className="text-right" dir="rtl">نمبر تشخیصیه</TableHead>
                              <TableHead className="text-right" dir="rtl">ماهیت تشبث</TableHead>
                              <TableHead className="text-right" dir="rtl">سال‌های بررسی</TableHead>
                              <TableHead className="text-right" dir="rtl">گروه</TableHead>
                              <TableHead className="text-right" dir="rtl">کمیته</TableHead>
                              <TableHead className="text-right" dir="rtl">وضعیت</TableHead>
                              <TableHead className="text-right" dir="rtl">عملیات</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {paginatedCases.map((case_) => (
                              <TableRow key={case_.id}>
                                <TableCell dir="rtl">{case_.caseId}</TableCell>
                                <TableCell className="font-medium" dir="rtl">{case_.companyName}</TableCell>
                                <TableCell dir="rtl">{case_.tin}</TableCell>
                                <TableCell dir="rtl">{case_.businessNature || '-'}</TableCell>
                                <TableCell dir="rtl">{(case_ as any).auditYearRange || case_.periodsUnderReview || '-'}</TableCell>
                                <TableCell dir="rtl">
                                  {case_.receivingGroup ? (
                                    groups.find(g => g.id === case_.receivingGroup)?.name || '-'
                                  ) : '-'}
                                </TableCell>
                                <TableCell dir="rtl">
                                  {(case_ as any).committeeId ? 'کمیته ' + (case_ as any).committeeId.substring(0, 8) : '-'}
                                </TableCell>
                                <TableCell dir="rtl"><StatusBadge status={case_.status} /></TableCell>
                                <TableCell dir="rtl">
                                  <div className="flex gap-2">
                                    <Button 
                                      size="icon" 
                                      variant="ghost" 
                                      onClick={() => handleViewCase(case_)}
                                    >
                                      <Eye className="h-4 w-4" />
                                    </Button>
                                  </div>
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                        {totalPages > 1 && (
                          <div className="mt-4 flex items-center justify-between" dir="rtl">
                            <div className="text-sm text-muted-foreground">
                              نمایش {startIndex + 1} تا {Math.min(endIndex, filteredCases.length)} از {filteredCases.length} قضیه
                            </div>
                            <Pagination>
                              <PaginationContent>
                                <PaginationItem>
                                  <PaginationPrevious
                                    href="#"
                                    onClick={(e) => {
                                      e.preventDefault();
                                      if (currentPage > 1) setCurrentPage(currentPage - 1);
                                    }}
                                    className={currentPage === 1 ? 'pointer-events-none opacity-50' : ''}
                                  />
                                </PaginationItem>
                                {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
                                  <PaginationItem key={page}>
                                    <PaginationLink
                                      href="#"
                                      onClick={(e) => {
                                        e.preventDefault();
                                        setCurrentPage(page);
                                      }}
                                      isActive={currentPage === page}
                                    >
                                      {page}
                                    </PaginationLink>
                                  </PaginationItem>
                                ))}
                                <PaginationItem>
                                  <PaginationNext
                                    href="#"
                                    onClick={(e) => {
                                      e.preventDefault();
                                      if (currentPage < totalPages) setCurrentPage(currentPage + 1);
                                    }}
                                    className={currentPage === totalPages ? 'pointer-events-none opacity-50' : ''}
                                  />
                                </PaginationItem>
                              </PaginationContent>
                            </Pagination>
                          </div>
                        )}
                      </>
                    )}
                  </div>
                </TabsContent>
                
                <TabsContent value="newly-assigned" className="mt-0">
                  {filteredCases.length === 0 ? (
                    <div className="text-center py-8 text-muted-foreground">هیچ قضیه تازه اختصاص داده شده‌ای یافت نشد</div>
                  ) : (
                    <>
                      <Table dir="rtl">
                        <TableHeader>
                          <TableRow>
                            <TableHead className="text-right" dir="rtl">
                              <Button
                                variant="ghost"
                                size="sm"
                                className="h-8 px-2"
                                onClick={() => {
                                  if (sortField === 'companyName') {
                                    setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
                                  } else {
                                    setSortField('companyName');
                                    setSortDirection('asc');
                                  }
                                }}
                              >
                                نام نهاد
                                {sortField === 'companyName' && (
                                  sortDirection === 'asc' ? <ArrowUp className="mr-1 h-3 w-3" /> : <ArrowDown className="mr-1 h-3 w-3" />
                                )}
                              </Button>
                            </TableHead>
                            <TableHead className="text-right" dir="rtl">نمبر تشخیصیه</TableHead>
                            <TableHead className="text-right" dir="rtl">سال های بررسی</TableHead>
                            <TableHead className="text-right" dir="rtl">
                              <Button
                                variant="ghost"
                                size="sm"
                                className="h-8 px-2"
                                onClick={() => {
                                  if (sortField === 'assignedTo') {
                                    setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
                                  } else {
                                    setSortField('assignedTo');
                                    setSortDirection('asc');
                                  }
                                }}
                              >
                                بررس اختصاص داده شده
                                {sortField === 'assignedTo' && (
                                  sortDirection === 'asc' ? <ArrowUp className="mr-1 h-3 w-3" /> : <ArrowDown className="mr-1 h-3 w-3" />
                                )}
                              </Button>
                            </TableHead>
                            <TableHead className="text-right" dir="rtl">وضعیت</TableHead>
                            <TableHead className="text-right" dir="rtl">
                              <Button
                                variant="ghost"
                                size="sm"
                                className="h-8 px-2"
                                onClick={() => {
                                  if (sortField === 'createdAt') {
                                    setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
                                  } else {
                                    setSortField('createdAt');
                                    setSortDirection('desc');
                                  }
                                }}
                              >
                                تاریخ ایجاد
                                {sortField === 'createdAt' && (
                                  sortDirection === 'asc' ? <ArrowUp className="mr-1 h-3 w-3" /> : <ArrowDown className="mr-1 h-3 w-3" />
                                )}
                              </Button>
                            </TableHead>
                            <TableHead className="text-right" dir="rtl">آخرین بروز رسانی</TableHead>
                            <TableHead className="text-right" dir="rtl">عملیات</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {paginatedCases.map((case_: any) => {
                            // Check if current user can complete this case
                            const canComplete = currentUser && userHasPermission(currentUser, 'cases:complete') && 
                              case_.status !== 'تکمیل شده' && 
                              case_.status !== 'تایید شده' && 
                              case_.status !== 'رد شده' &&
                              (currentUser.role === 'system_admin' ||
                               (currentUser.role === 'auditor' && case_.assignedTo === currentUser.id) ||
                               (currentUser.role === 'senior_auditor' && currentUser.groupId === case_.groupReferrer));
                            
                            // Check if user can assign cases - auditors cannot assign
                            const canAssign = currentUser && 
                              currentUser.role !== 'auditor' &&
                              (userHasPermission(currentUser, 'cases:assign_to_auditor') || 
                               userHasPermission(currentUser, 'cases:assign_to_group') ||
                               userHasPermission(currentUser, 'users:manage'));
                            
                            return (
                              <TableRow key={case_.id} className="hover-elevate">
                                <TableCell className="font-medium" dir="rtl">{case_.companyName}</TableCell>
                                <TableCell dir="rtl">{case_.tin}</TableCell>
                                <TableCell dir="rtl">{case_.periodsUnderReview}</TableCell>
                                <TableCell dir="rtl">
                                  {case_.assignedTo ? (
                                    users.find(u => u.id === case_.assignedTo)?.fullName || 'نامشخص'
                                  ) : '-'}
                                </TableCell>
                                <TableCell dir="rtl"><StatusBadge status={case_.status} /></TableCell>
                                <TableCell dir="rtl">
                                  {case_.createdAt ? new Date(case_.createdAt).toLocaleDateString('fa-IR') : '-'}
                                </TableCell>
                                <TableCell dir="rtl">
                                  {case_.completedAt ? new Date(case_.completedAt).toLocaleDateString('fa-IR') : 
                                   case_.approvedAt ? new Date(case_.approvedAt).toLocaleDateString('fa-IR') :
                                   case_.rejectedAt ? new Date(case_.rejectedAt).toLocaleDateString('fa-IR') : '-'}
                                </TableCell>
                                <TableCell dir="rtl">
                                  <div className="flex gap-2">
                                    <Button 
                                      size="icon" 
                                      variant="ghost" 
                                      onClick={() => handleViewCase(case_)}
                                      data-testid={`button-view-${case_.id}`}
                                    >
                                      <Eye className="h-4 w-4" />
                                    </Button>
                                    {canAssign && (
                                      <Button 
                                        size="icon" 
                                        variant="ghost" 
                                        onClick={() => handleAssignCase(case_)}
                                        data-testid={`button-assign-${case_.id}`}
                                      >
                                        <UserPlus className="h-4 w-4" />
                                      </Button>
                                    )}
                                    {canUploadDocuments && (
                                      <Button 
                                        size="icon" 
                                        variant="ghost" 
                                        onClick={() => handleUploadDocument(case_)}
                                        data-testid={`button-upload-${case_.id}`}
                                      >
                                        <Upload className="h-4 w-4" />
                                      </Button>
                                    )}
                                    {canComplete && (
                                      <Button 
                                        size="icon" 
                                        variant="ghost" 
                                        onClick={() => handleCompleteCase(case_)}
                                        data-testid={`button-complete-${case_.id}`}
                                        className="text-blue-600 hover:text-blue-700 hover:bg-blue-50"
                                        disabled={completeCaseMutation.isPending || saveCaseReportMutation.isPending}
                                        title="تکمیل قضیه"
                                      >
                                        <CheckCircle className="h-4 w-4" />
                                      </Button>
                                    )}
                                  </div>
                                </TableCell>
                              </TableRow>
                            );
                          })}
                        </TableBody>
                      </Table>
                      {totalPages > 1 && (
                        <div className="mt-4 flex items-center justify-between" dir="rtl">
                          <div className="text-sm text-muted-foreground">
                            نمایش {startIndex + 1} تا {Math.min(endIndex, filteredCases.length)} از {filteredCases.length} قضیه
                          </div>
                          <Pagination>
                            <PaginationContent>
                              <PaginationItem>
                                <PaginationPrevious
                                  href="#"
                                  onClick={(e) => {
                                    e.preventDefault();
                                    if (currentPage > 1) setCurrentPage(currentPage - 1);
                                  }}
                                  className={currentPage === 1 ? 'pointer-events-none opacity-50' : ''}
                                />
                              </PaginationItem>
                              {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
                                <PaginationItem key={page}>
                                  <PaginationLink
                                    href="#"
                                    onClick={(e) => {
                                      e.preventDefault();
                                      setCurrentPage(page);
                                    }}
                                    isActive={currentPage === page}
                                  >
                                    {page}
                                  </PaginationLink>
                                </PaginationItem>
                              ))}
                              <PaginationItem>
                                <PaginationNext
                                  href="#"
                                  onClick={(e) => {
                                    e.preventDefault();
                                    if (currentPage < totalPages) setCurrentPage(currentPage + 1);
                                  }}
                                  className={currentPage === totalPages ? 'pointer-events-none opacity-50' : ''}
                                />
                              </PaginationItem>
                            </PaginationContent>
                          </Pagination>
                        </div>
                      )}
                    </>
                  )}
                </TabsContent>
                
                <TabsContent value="completed" className="mt-0">
                  {filteredCases.length === 0 ? (
                    <div className="text-center py-8 text-muted-foreground">هیچ قضیه تکمیل شده‌ای یافت نشد</div>
                  ) : (() => {
                    // Group completed cases by year and month
                    const monthNames = ['', 'حمل', 'ثور', 'جوزا', 'سرطان', 'اسد', 'سنبله', 'میزان', 'عقرب', 'قوس', 'جدی', 'دلو', 'حوت'];
                    const groupedByYear: Record<number, Record<number, any[]>> = {};
                    
                    filteredCases.forEach((case_: any) => {
                      // Use completedAt, approvedAt, or rejectedAt - whichever is available
                      const completionDate = case_.completedAt || case_.approvedAt || case_.rejectedAt || case_.createdAt;
                      if (!completionDate) return;
                      
                      const date = new Date(completionDate);
                      const shamsi = jalaali.toJalaali(date.getFullYear(), date.getMonth() + 1, date.getDate());
                      const year = shamsi.jy;
                      const month = shamsi.jm;
                      
                      if (!groupedByYear[year]) {
                        groupedByYear[year] = {};
                      }
                      if (!groupedByYear[year][month]) {
                        groupedByYear[year][month] = [];
                      }
                      groupedByYear[year][month].push(case_);
                    });
                    
                    // Sort years descending
                    const sortedYears = Object.keys(groupedByYear).map(Number).sort((a, b) => b - a);
                    
                    const toggleYear = (year: number) => {
                      setExpandedYears(prev => {
                        const newSet = new Set(prev);
                        if (newSet.has(year)) {
                          newSet.delete(year);
                        } else {
                          newSet.add(year);
                        }
                        return newSet;
                      });
                    };
                    
                    const toggleMonth = (year: number, month: number) => {
                      const key = `${year}-${month}`;
                      setExpandedMonths(prev => {
                        const newSet = new Set(prev);
                        if (newSet.has(key)) {
                          newSet.delete(key);
                        } else {
                          newSet.add(key);
                        }
                        return newSet;
                      });
                    };
                    
                    return (
                      <div className="space-y-4" dir="rtl">
                        {sortedYears.length === 0 ? (
                          <div className="text-center py-8 text-muted-foreground">هیچ قضیه تکمیل شده‌ای یافت نشد</div>
                        ) : (
                          sortedYears.map(year => {
                            const yearCases = groupedByYear[year];
                            const sortedMonths = Object.keys(yearCases).map(Number).sort((a, b) => a - b);
                            const totalCasesInYear = sortedMonths.reduce((sum, month) => sum + yearCases[month].length, 0);
                            const yearExpanded = expandedYears.has(year);
                            
                            return (
                                              <Collapsible key={year} open={yearExpanded} onOpenChange={() => toggleYear(year)}>
                                <Card>
                                  <CollapsibleTrigger asChild>
                                    <CardHeader className="cursor-pointer hover:bg-muted/50 transition-colors">
                                      <div className="flex items-center justify-between">
                                        <CardTitle className="text-lg">
                                          <div className="flex items-center gap-2">
                                            {yearExpanded ? (
                                              <ChevronDown className="h-5 w-5" />
                                            ) : (
                                              <ChevronRight className="h-5 w-5" />
                                            )}
                                            سال {year}
                                          </div>
                                        </CardTitle>
                                        <Badge variant="secondary">{totalCasesInYear} قضیه</Badge>
                                      </div>
                                    </CardHeader>
                                  </CollapsibleTrigger>
                                  <CollapsibleContent>
                                    <CardContent className="pt-0">
                                      {sortedMonths.length === 0 ? (
                                        <div className="text-center py-4 text-muted-foreground">هیچ قضیه‌ای برای این سال وجود ندارد</div>
                                      ) : (
                                        <div className="space-y-3">
                                          {sortedMonths.map(month => {
                                            const monthCases = yearCases[month];
                                            const monthKey = `${year}-${month}`;
                                            const monthExpanded = expandedMonths.has(monthKey);
                                            
                                            return (
                                              <Collapsible key={month} open={monthExpanded} onOpenChange={() => toggleMonth(year, month)}>
                                                <div className="border rounded-lg">
                                                  <CollapsibleTrigger asChild>
                                                    <div className="p-3 cursor-pointer hover:bg-muted/50 transition-colors flex items-center justify-between">
                                                      <div className="flex items-center gap-2">
                                                        {monthExpanded ? (
                                                          <ChevronDown className="h-4 w-4" />
                                                        ) : (
                                                          <ChevronRight className="h-4 w-4" />
                                                        )}
                                                        <span className="font-medium">{monthNames[month]} ({monthCases.length} قضیه)</span>
                                                      </div>
                                                    </div>
                                                  </CollapsibleTrigger>
                                                  <CollapsibleContent>
                                                    <div className="border-t">
                                                      <Table dir="rtl">
                                                        <TableHeader>
                                                          <TableRow>
                                                            <TableHead className="text-right">نمبر قضیه</TableHead>
                                                            <TableHead className="text-right">نام نهاد</TableHead>
                                                            <TableHead className="text-right">نمبر تشخیصیه</TableHead>
                                                            <TableHead className="text-right">دوره بررسی</TableHead>
                                                            <TableHead className="text-right">بررس</TableHead>
                                                            <TableHead className="text-right">تاریخ تکمیل</TableHead>
                                                            <TableHead className="text-right">وضعیت</TableHead>
                                                            <TableHead className="text-right">عملیات</TableHead>
                                                          </TableRow>
                                                        </TableHeader>
                                                        <TableBody>
                                                          {monthCases.map((case_: any) => (
                                                            <TableRow key={case_.id}>
                                                              <TableCell dir="rtl">{case_.caseId}</TableCell>
                                                              <TableCell className="font-medium" dir="rtl">{case_.companyName}</TableCell>
                                                              <TableCell dir="rtl">{case_.tin}</TableCell>
                                                              <TableCell dir="rtl">{case_.periodsUnderReview}</TableCell>
                                                              <TableCell dir="rtl">
                                                                {case_.assignedTo ? (
                                                                  users.find(u => u.id === case_.assignedTo)?.fullName || 'نامشخص'
                                                                ) : '-'}
                                                              </TableCell>
                                                              <TableCell dir="rtl">
                                                                {case_.completedAt ? new Date(case_.completedAt).toLocaleDateString('fa-IR') : 
                                                                 case_.approvedAt ? new Date(case_.approvedAt).toLocaleDateString('fa-IR') :
                                                                 case_.rejectedAt ? new Date(case_.rejectedAt).toLocaleDateString('fa-IR') : '-'}
                                                              </TableCell>
                                                              <TableCell dir="rtl"><StatusBadge status={case_.status} /></TableCell>
                                                              <TableCell dir="rtl">
                                                                <div className="flex gap-2">
                                                                  <Button 
                                                                    size="icon" 
                                                                    variant="ghost" 
                                                                    onClick={() => handleViewCase(case_)}
                                                                    data-testid={`button-view-${case_.id}`}
                                                                  >
                                                                    <Eye className="h-4 w-4" />
                                                                  </Button>
                                                                  <Button
                                                                    size="icon"
                                                                    variant="ghost"
                                                                    onClick={async () => {
                                                                      try {
                                                                        const response = await fetch(`/api/cases/${case_.id}/report/v2/pdf`, {
                                                                          credentials: 'include',
                                                                        });
                                                                        if (!response.ok) throw new Error('Failed to generate PDF');
                                                                        const blob = await response.blob();
                                                                        const url = window.URL.createObjectURL(blob);
                                                                        const a = document.createElement('a');
                                                                        a.href = url;
                                                                        a.download = `report-${case_.caseId}.pdf`;
                                                                        document.body.appendChild(a);
                                                                        a.click();
                                                                        window.URL.revokeObjectURL(url);
                                                                        document.body.removeChild(a);
                                                                        toast({ title: 'موفق', description: 'PDF با موفقیت دانلود شد' });
                                                                      } catch (error: any) {
                                                                        toast({ title: 'خطا', description: error.message || 'خطا در دانلود PDF', variant: 'destructive' });
                                                                      }
                                                                    }}
                                                                  >
                                                                    <FileText className="h-4 w-4" />
                                                                  </Button>
                                                                </div>
                                                              </TableCell>
                                                            </TableRow>
                                                          ))}
                                                        </TableBody>
                                                      </Table>
                                                    </div>
                                                  </CollapsibleContent>
                                                </div>
                                              </Collapsible>
                                            );
                                          })}
                                        </div>
                                      )}
                                    </CardContent>
                                  </CollapsibleContent>
                                </Card>
                              </Collapsible>
                            );
                          })
                        )}
                      </div>
                    );
                  })()}
                </TabsContent>
                
                <TabsContent value="committee-cases" className="mt-0">
                  {filteredCases.length === 0 ? (
                    <div className="text-center py-8 text-muted-foreground">هیچ قضیه کمیته جدیدی یافت نشد</div>
                  ) : (
                    <>
                      <Table dir="rtl">
                        <TableHeader>
                          <TableRow>
                            <TableHead className="text-right" dir="rtl">نام نهاد</TableHead>
                            <TableHead className="text-right" dir="rtl">نمبر تشخیصیه</TableHead>
                            <TableHead className="text-right" dir="rtl">دوره بررسی</TableHead>
                            <TableHead className="text-right" dir="rtl">گروه دریافت‌کننده</TableHead>
                            <TableHead className="text-right" dir="rtl">وضعیت</TableHead>
                            <TableHead className="text-right" dir="rtl">تاریخ ایجاد</TableHead>
                            <TableHead className="text-right" dir="rtl">عملیات</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {paginatedCases.map((case_: any) => {
                            // Check if user can assign cases - only senior auditors can assign committee cases
                            const canAssign = currentUser && 
                              ((currentUser.role === 'senior_auditor' as any) || 
                               (currentUser.role === 'coordinator' as any) ||
                               currentUser.role === 'director' ||
                               currentUser.role === 'system_admin') &&
                              (userHasPermission(currentUser, 'cases:assign_to_auditor') || 
                               userHasPermission(currentUser, 'cases:assign_to_group') ||
                               userHasPermission(currentUser, 'users:manage'));
                            
                            return (
                              <TableRow key={case_.id} className="hover-elevate">
                                <TableCell className="font-medium" dir="rtl">{case_.companyName}</TableCell>
                                <TableCell dir="rtl">{case_.tin}</TableCell>
                                <TableCell dir="rtl">{case_.periodsUnderReview}</TableCell>
                                <TableCell dir="rtl">
                                  {case_.receivingGroup || (case_ as any).currentAuditGroupId ? (
                                    groups.find(g => g.id === (case_.receivingGroup || (case_ as any).currentAuditGroupId))?.name || 
                                    (case_.receivingGroup || (case_ as any).currentAuditGroupId)
                                  ) : '-'}
                                </TableCell>
                                <TableCell dir="rtl"><StatusBadge status={case_.status} /></TableCell>
                                <TableCell dir="rtl">
                                  {/* Show assignment date if available, otherwise creation date */}
                                  {(case_ as any).assignedAt ? 
                                    new Date((case_ as any).assignedAt).toLocaleDateString('fa-IR') :
                                    case_.createdAt ? new Date(case_.createdAt).toLocaleDateString('fa-IR') : '-'}
                                </TableCell>
                                <TableCell dir="rtl">
                                  <div className="flex gap-2">
                                    <Button 
                                      size="icon" 
                                      variant="ghost" 
                                      onClick={() => handleViewCase(case_)}
                                      data-testid={`button-view-${case_.id}`}
                                    >
                                      <Eye className="h-4 w-4" />
                                    </Button>
                                    {canAssign && (
                                      <Button 
                                        size="icon" 
                                        variant="ghost" 
                                        onClick={() => handleAssignCase(case_)}
                                        data-testid={`button-assign-${case_.id}`}
                                        title="اختصاص به بررس"
                                      >
                                        <UserPlus className="h-4 w-4" />
                                      </Button>
                                    )}
                                  </div>
                                </TableCell>
                              </TableRow>
                            );
                          })}
                        </TableBody>
                      </Table>
                      {totalPages > 1 && (
                        <div className="mt-4 flex items-center justify-between" dir="rtl">
                          <div className="text-sm text-muted-foreground">
                            نمایش {startIndex + 1} تا {Math.min(endIndex, filteredCases.length)} از {filteredCases.length} قضیه
                          </div>
                          <Pagination>
                            <PaginationContent>
                              <PaginationItem>
                                <PaginationPrevious
                                  href="#"
                                  onClick={(e) => {
                                    e.preventDefault();
                                    if (currentPage > 1) setCurrentPage(currentPage - 1);
                                  }}
                                  className={currentPage === 1 ? 'pointer-events-none opacity-50' : ''}
                                />
                              </PaginationItem>
                              {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
                                <PaginationItem key={page}>
                                  <PaginationLink
                                    href="#"
                                    onClick={(e) => {
                                      e.preventDefault();
                                      setCurrentPage(page);
                                    }}
                                    isActive={currentPage === page}
                                  >
                                    {page}
                                  </PaginationLink>
                                </PaginationItem>
                              ))}
                              <PaginationItem>
                                <PaginationNext
                                  href="#"
                                  onClick={(e) => {
                                    e.preventDefault();
                                    if (currentPage < totalPages) setCurrentPage(currentPage + 1);
                                  }}
                                  className={currentPage === totalPages ? 'pointer-events-none opacity-50' : ''}
                                />
                              </PaginationItem>
                            </PaginationContent>
                          </Pagination>
                        </div>
                      )}
                    </>
                  )}
                </TabsContent>
                
                <TabsContent value="installment-cases" className="mt-0">
                  {isLoadingUnpaid ? (
                    <div className="text-center py-8 text-muted-foreground">در حال بارگذاری...</div>
                  ) : filteredCases.length === 0 ? (
                    <div className="text-center py-8 text-muted-foreground">هیچ قضیه با مانده بدهی یافت نشد</div>
                  ) : (
                    <>
                      <Table dir="rtl">
                        <TableHeader>
                          <TableRow>
                            <TableHead className="text-right" dir="rtl">نام نهاد</TableHead>
                            <TableHead className="text-right" dir="rtl">نمبر تشخیصیه</TableHead>
                            <TableHead className="text-right" dir="rtl">مبلغ تثبیت شده</TableHead>
                            <TableHead className="text-right" dir="rtl">جمع پرداخت شده</TableHead>
                            <TableHead className="text-right" dir="rtl">مانده باقی‌مانده</TableHead>
                            <TableHead className="text-right" dir="rtl">آخرین پرداخت</TableHead>
                            <TableHead className="text-right" dir="rtl">نوع پرداخت</TableHead>
                            <TableHead className="text-right" dir="rtl">عملیات</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {paginatedCases.map((case_: any) => {
                            const financialInfo = case_.financialInfo || {};
                            const formatCurrency = (amount: number) => {
                              return new Intl.NumberFormat('fa-IR').format(amount || 0);
                            };
                            const formatDate = (dateStr: string | null) => {
                              if (!dateStr) return '-';
                              try {
                                const date = new Date(dateStr);
                                const jDate = jalaali.toJalaali(date);
                                const monthNames = ['حمل', 'ثور', 'جوزا', 'سرطان', 'اسد', 'سنبله', 'میزان', 'عقرب', 'قوس', 'جدی', 'دلو', 'حوت'];
                                return `${jDate.jd} ${monthNames[jDate.jm - 1]} ${jDate.jy}`;
                              } catch {
                                return '-';
                              }
                            };
                            const paymentTypeLabel = financialInfo.lastPaymentType === 'installment' 
                              ? 'قسط' 
                              : financialInfo.lastPaymentType === 'normal' 
                                ? 'عادی' 
                                : '-';
                            
                            return (
                            <TableRow key={case_.id} className="hover-elevate">
                              <TableCell className="font-medium" dir="rtl">{case_.companyName}</TableCell>
                              <TableCell dir="rtl">{case_.tin}</TableCell>
                                <TableCell dir="rtl" className="font-medium">
                                  {formatCurrency(financialInfo.confirmedAmount || 0)} افغانی
                                </TableCell>
                              <TableCell dir="rtl">
                                  {formatCurrency(financialInfo.totalPaid || 0)} افغانی
                              </TableCell>
                                <TableCell dir="rtl" className="font-semibold text-destructive">
                                  {formatCurrency(financialInfo.remainingBalance || 0)} افغانی
                                </TableCell>
                              <TableCell dir="rtl">
                                  {formatDate(financialInfo.lastPaymentDate)}
                                </TableCell>
                                <TableCell dir="rtl">
                                  {financialInfo.hasInstallmentPlan && (
                                    <Badge variant="secondary">اقساط</Badge>
                                  )}
                                  {paymentTypeLabel !== '-' && (
                                    <span className="mr-1">{paymentTypeLabel}</span>
                                  )}
                              </TableCell>
                              <TableCell dir="rtl">
                                <div className="flex gap-2">
                                  <Button 
                                    size="icon" 
                                    variant="ghost" 
                                    onClick={() => handleViewCase(case_)}
                                    data-testid={`button-view-${case_.id}`}
                                      title="مشاهده قضیه"
                                  >
                                    <Eye className="h-4 w-4" />
                                  </Button>
                                    <Button 
                                      size="icon" 
                                      variant="ghost" 
                                      onClick={() => {
                                        setSelectedCase(case_);
                                        setFinancialFollowUpOpen(true);
                                      }}
                                      title="پیگیری مالی"
                                    >
                                      <DollarSign className="h-4 w-4" />
                                    </Button>
                                </div>
                              </TableCell>
                            </TableRow>
                            );
                          })}
                        </TableBody>
                      </Table>
                      {totalPages > 1 && (
                        <div className="mt-4 flex items-center justify-between" dir="rtl">
                          <div className="text-sm text-muted-foreground">
                            نمایش {startIndex + 1} تا {Math.min(endIndex, filteredCases.length)} از {filteredCases.length} قضیه
                          </div>
                          <Pagination>
                            <PaginationContent>
                              <PaginationItem>
                                <PaginationPrevious
                                  href="#"
                                  onClick={(e) => {
                                    e.preventDefault();
                                    if (currentPage > 1) setCurrentPage(currentPage - 1);
                                  }}
                                  className={currentPage === 1 ? 'pointer-events-none opacity-50' : ''}
                                />
                              </PaginationItem>
                              {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
                                <PaginationItem key={page}>
                                  <PaginationLink
                                    href="#"
                                    onClick={(e) => {
                                      e.preventDefault();
                                      setCurrentPage(page);
                                    }}
                                    isActive={currentPage === page}
                                  >
                                    {page}
                                  </PaginationLink>
                                </PaginationItem>
                              ))}
                              <PaginationItem>
                                <PaginationNext
                                  href="#"
                                  onClick={(e) => {
                                    e.preventDefault();
                                    if (currentPage < totalPages) setCurrentPage(currentPage + 1);
                                  }}
                                  className={currentPage === totalPages ? 'pointer-events-none opacity-50' : ''}
                                />
                              </PaginationItem>
                            </PaginationContent>
                          </Pagination>
                        </div>
                      )}
                    </>
                  )}
                </TabsContent>
                
                <TabsContent value="law-enforcement-cases" className="mt-0">
                  {filteredCases.length === 0 ? (
                    <div className="text-center py-8 text-muted-foreground">هیچ قضیه ارسال‌شده به تنفیذ قانونی یافت نشد</div>
                  ) : (
                    <>
                      <Table dir="rtl">
                        <TableHeader>
                          <TableRow>
                            <TableHead className="text-right" dir="rtl">نام نهاد</TableHead>
                            <TableHead className="text-right" dir="rtl">نمبر تشخیصیه</TableHead>
                            <TableHead className="text-right" dir="rtl">دوره بررسی</TableHead>
                            <TableHead className="text-right" dir="rtl">بررس</TableHead>
                            <TableHead className="text-right" dir="rtl">وضعیت</TableHead>
                            <TableHead className="text-right" dir="rtl">تاریخ ایجاد</TableHead>
                            <TableHead className="text-right" dir="rtl">عملیات</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {paginatedCases.map((case_) => (
                            <TableRow key={case_.id} className="hover-elevate">
                              <TableCell className="font-medium" dir="rtl">{case_.companyName}</TableCell>
                              <TableCell dir="rtl">{case_.tin}</TableCell>
                              <TableCell dir="rtl">{case_.periodsUnderReview}</TableCell>
                              <TableCell dir="rtl">
                                {case_.assignedTo ? (
                                  users.find(u => u.id === case_.assignedTo)?.fullName || '-'
                                ) : '-'}
                              </TableCell>
                              <TableCell dir="rtl"><StatusBadge status={case_.status} /></TableCell>
                              <TableCell dir="rtl">
                                {case_.createdAt ? new Date(case_.createdAt).toLocaleDateString('fa-IR') : '-'}
                              </TableCell>
                              <TableCell dir="rtl">
                                <div className="flex gap-2">
                                  <Button 
                                    size="icon" 
                                    variant="ghost" 
                                    onClick={() => handleViewCase(case_)}
                                    data-testid={`button-view-${case_.id}`}
                                  >
                                    <Eye className="h-4 w-4" />
                                  </Button>
                                </div>
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                      {totalPages > 1 && (
                        <div className="mt-4 flex items-center justify-between" dir="rtl">
                          <div className="text-sm text-muted-foreground">
                            نمایش {startIndex + 1} تا {Math.min(endIndex, filteredCases.length)} از {filteredCases.length} قضیه
                          </div>
                          <Pagination>
                            <PaginationContent>
                              <PaginationItem>
                                <PaginationPrevious
                                  href="#"
                                  onClick={(e) => {
                                    e.preventDefault();
                                    if (currentPage > 1) setCurrentPage(currentPage - 1);
                                  }}
                                  className={currentPage === 1 ? 'pointer-events-none opacity-50' : ''}
                                />
                              </PaginationItem>
                              {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
                                <PaginationItem key={page}>
                                  <PaginationLink
                                    href="#"
                                    onClick={(e) => {
                                      e.preventDefault();
                                      setCurrentPage(page);
                                    }}
                                    isActive={currentPage === page}
                                  >
                                    {page}
                                  </PaginationLink>
                                </PaginationItem>
                              ))}
                              <PaginationItem>
                                <PaginationNext
                                  href="#"
                                  onClick={(e) => {
                                    e.preventDefault();
                                    if (currentPage < totalPages) setCurrentPage(currentPage + 1);
                                  }}
                                  className={currentPage === totalPages ? 'pointer-events-none opacity-50' : ''}
                                />
                              </PaginationItem>
                            </PaginationContent>
                          </Pagination>
                        </div>
                      )}
                    </>
                  )}
                </TabsContent>
              </>
            );
          })()}
          </CardContent>
        </Tabs>
      </Card>


      {/* View Case Details Dialog */}
      <Dialog open={viewDialogOpen} onOpenChange={setViewDialogOpen}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>جزئیات قضیه: {selectedCase?.caseId}</DialogTitle>
            <DialogDescription>
              مشاهده اطلاعات کامل قضیه
            </DialogDescription>
          </DialogHeader>
          {selectedCase && (() => {
            // Use fullCaseData if available (most up-to-date), otherwise fall back to selectedCase
            const displayCase = fullCaseData || selectedCase;
            return (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>نمبر قضیه</Label>
                  <p className="text-sm font-medium">{displayCase.caseId}</p>
                </div>
                <div>
                  <Label>نام شرکت</Label>
                  <p className="text-sm">{displayCase.companyName}</p>
                </div>
                <div>
                  <Label>نمبر تشخیصیه</Label>
                  <p className="text-sm">{displayCase.tin}</p>
                </div>
                <div>
                  <Label>سال‌های بررسی</Label>
                  <p className="text-sm">{displayCase.periodsUnderReview}</p>
                </div>
                <div>
                  <Label>تاریخ ارجاع</Label>
                  <p className="text-sm">{displayCase.referralDate}</p>
                </div>
                <div>
                  <Label>وضعیت</Label>
                  <div className="text-sm"><StatusBadge status={displayCase.status} /></div>
                </div>
                <div>
                  <Label>گروه ارجاع‌دهنده</Label>
                  <p className="text-sm">{displayCase.groupReferrer || 'نامشخص'}</p>
                </div>
                {displayCase.receivingGroup && (
                  <div>
                    <Label>گروه دریافت‌کننده</Label>
                    <p className="text-sm">
                      {groups.find(g => g.id === displayCase.receivingGroup)?.name || displayCase.receivingGroup}
                    </p>
                  </div>
                )}
                {displayCase.assignedTo && (
                  <div>
                    <Label>اختصاص داده شده به</Label>
                    <p className="text-sm">
                      {users.find(u => u.id === displayCase.assignedTo)?.fullName || displayCase.assignedTo}
                    </p>
                  </div>
                )}
              </div>
              {/* Case Assignment State Tracking */}
              <div className="p-3 bg-muted rounded-lg">
                <Label className="text-sm font-semibold mb-2 block">وضعیت اختصاص</Label>
                <div className="space-y-2 text-sm">
                  {displayCase.receivingGroup ? (
                    <div className="flex flex-row-reverse justify-between items-center gap-2">
                      <span className="font-medium text-right">
                        {groups.find(g => g.id === displayCase.receivingGroup)?.name || displayCase.receivingGroup}
                      </span>
                      <span className="text-muted-foreground text-right">گروه:</span>
                    </div>
                  ) : (
                    <div className="text-muted-foreground text-right">قضیه هنوز به گروهی اختصاص داده نشده است</div>
                  )}
                  {displayCase.assignedTo ? (
                    <div className="flex flex-row-reverse justify-between items-center gap-2">
                      <span className="font-medium text-right">
                        {users.find(u => u.id === displayCase.assignedTo)?.fullName || displayCase.assignedTo}
                      </span>
                      <span className="text-muted-foreground text-right">بررس:</span>
                    </div>
                  ) : displayCase.receivingGroup ? (
                    <div className="text-muted-foreground text-right">قضیه به گروه اختصاص داده شده اما هنوز به بررس خاصی واگذار نشده است</div>
                  ) : null}
                </div>
              </div>
              {displayCase.notes && (
                <div>
                  <Label>ملاحظات</Label>
                  <p className="text-sm text-muted-foreground whitespace-pre-wrap">{displayCase.notes}</p>
                </div>
              )}
              
              {/* Case Completion Details Section - Only for completed cases */}
              {displayCase.status === 'تکمیل شده' && (
                <CaseCompletionDetails caseId={displayCase.id} caseData={displayCase} users={users} />
              )}
              
              <div>
                <Label>اسناد ({caseDocuments.length})</Label>
                {caseDocuments.length === 0 ? (
                  <p className="text-sm text-muted-foreground">هیچ سندی وجود ندارد</p>
                ) : (
                  <div className="mt-2 space-y-2">
                    {caseDocuments.map((doc) => (
                      <div key={doc.id} className="flex items-center justify-between p-2 border rounded">
                        <div className="flex items-center gap-2">
                          <FileText className="h-4 w-4" />
                          <span className="text-sm">{doc.docType}</span>
                          <Badge variant="outline" className="text-xs">{doc.docDate}</Badge>
                        </div>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => window.open(`/api/documents/${doc.id}/download`, '_blank')}
                        >
                          <Download className="h-4 w-4" />
                        </Button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
              
              {/* Start Audit Process Button - For auditors on assigned cases */}
              {currentUser && 
               (currentUser.role === 'auditor' || currentUser.role === 'senior_auditor' || currentUser.role === 'system_admin') && 
               (displayCase.assignedTo === currentUser.id || displayCase.assignedAuditor === currentUser.id) && 
               (displayCase.status === CaseStatus.PENDING_SENIOR_REVIEW ||
                displayCase.status === CaseStatus.UNDER_REVIEW ||
                displayCase.status === 'در انتظار بررسی بازرس ارشد' ||
                displayCase.status === 'در حال بررسی') && (
                <div className="mt-6">
                  <Button
                    onClick={async () => {
                      try {
                        const response = await fetch(`/api/cases/${displayCase.id}/start-audit`, {
                          method: 'POST',
                          headers: { 'Content-Type': 'application/json' },
                          credentials: 'include',
                        });
                        if (response.ok) {
                          const updatedCase = await response.json();
                          // Refresh cases list and selected case
                          queryClient.invalidateQueries({ queryKey: ['cases'] });
                          queryClient.invalidateQueries({ queryKey: ['case', displayCase.id] });
                          setSelectedCase(updatedCase);
                          refetchFullCase();
                          toast({
                            title: 'موفق',
                            description: 'روند بررسی آغاز شد.',
                          });
                        } else {
                          const error = await response.json();
                          toast({
                            title: 'خطا',
                            description: error.message || 'خطا در آغاز روند بررسی',
                            variant: 'destructive',
                          });
                        }
                      } catch (error) {
                        console.error('Failed to start audit process:', error);
                        toast({
                          title: 'خطا',
                          description: 'خطا در آغاز روند بررسی',
                          variant: 'destructive',
                        });
                      }
                    }}
                    className="w-full"
                  >
                    شروع بررسی
                  </Button>
                </div>
              )}

              {/* Reopen Button - Only for senior auditors on completed cases */}
              {currentUser && (currentUser.role === 'senior_auditor' || currentUser.role === 'system_admin') && 
               (displayCase.status === CaseStatus.COMPLETED || displayCase.status === 'تکمیل شده') && (
                <div className="mt-6">
                  <ReopenCaseButton 
                    caseId={displayCase.id}
                    onReopen={() => {
                      queryClient.invalidateQueries({ queryKey: ['cases'] });
                      refetchFullCase();
                    }}
                  />
                </div>
              )}

              {/* Non-responsive Workflow - For auditors and senior auditors */}
              {currentUser && (currentUser.role === 'auditor' || currentUser.role === 'senior_auditor' || currentUser.role === 'system_admin') && (
                <div className="mt-6">
                  <NonResponsiveWorkflow 
                    caseId={displayCase.id}
                    flags={fullCaseData?.flags || []}
                    onUpdate={() => {
                      refetchFullCase();
                      // After escalation, check if case status changed to SENT_TO_LAW_ENFORCEMENT
                      // and switch to law-enforcement-cases tab
                      queryClient.invalidateQueries({ queryKey: ['case', displayCase.id] }).then(() => {
                        // Fetch updated case to check status
                        fetch(`/api/cases/${displayCase.id}`, { credentials: 'include' })
                          .then(res => res.json())
                          .then(updatedCase => {
                            if ((updatedCase as any).isLawEnforcement === true || (updatedCase as any).is_law_enforcement === true) {
                              setActiveTab('law-enforcement-cases');
                            }
                          })
                          .catch(err => console.error('Error checking case status:', err));
                      });
                    }}
                  />
                </div>
              )}

              {/* Set as Tax Installment Case Button - For auditors */}
              {currentUser && 
               (currentUser.role === 'auditor' || currentUser.role === 'senior_auditor' || currentUser.role === 'system_admin') && 
               !(displayCase as any).isTaxInstallment && !(displayCase as any).is_tax_installment && (
                <div className="mt-6">
                  <Button
                    variant="outline"
                    onClick={async () => {
                      try {
                        // Update isTaxInstallment flag (not status)
                        try {
                          const response = await fetch(`/api/cases/${selectedCase.id}`, {
                            method: 'PUT',
                            headers: { 'Content-Type': 'application/json' },
                            credentials: 'include',
                            body: JSON.stringify({
                              isTaxInstallment: true,
                            }),
                          });
                          
                          if (response.ok) {
                            const updatedCase = await response.json();
                            queryClient.invalidateQueries({ queryKey: ['cases'] });
                            queryClient.invalidateQueries({ queryKey: ['case', selectedCase.id] });
                            setSelectedCase(updatedCase);
                            refetchFullCase();
                            setActiveTab('installment-cases');
                            toast({
                              title: 'موفق',
                              description: 'قضیه به عنوان قضیه قسط تنظیم شد و به تب "قضایای در اقساط" منتقل شد.',
                            });
                          } else {
                            const error = await response.json();
                            toast({
                              title: 'خطا',
                              description: error.message || 'خطا در تنظیم قضیه به عنوان قضیه قسط',
                              variant: 'destructive',
                            });
                          }
                        } catch (err) {
                          console.error('Failed to set case as installment:', err);
                          toast({
                            title: 'خطا',
                            description: 'خطا در تنظیم قضیه به عنوان قضیه قسط',
                            variant: 'destructive',
                          });
                        }
                      } catch (error) {
                        console.error('Failed to set case as installment:', error);
                        toast({
                          title: 'خطا',
                          description: 'خطا در تنظیم قضیه به عنوان قضیه قسط',
                          variant: 'destructive',
                        });
                      }
                    }}
                    className="w-full"
                  >
                    تنظیم به عنوان قضیه قسط
                  </Button>
                </div>
              )}

              {/* Installment Payments - Show when isTaxInstallment flag is true */}
              {currentUser && 
               (currentUser.role === 'auditor' || currentUser.role === 'senior_auditor' || currentUser.role === 'system_admin') && 
               ((displayCase as any).isTaxInstallment === true || (displayCase as any).is_tax_installment === true) && (
                <div className="mt-6">
                  <InstallmentPayments caseId={displayCase.id} />
                </div>
              )}
            </div>
            );
          })()}
        </DialogContent>
      </Dialog>

      {/* Upload Document Dialog */}
      <Dialog open={uploadDialogOpen} onOpenChange={setUploadDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>آپلود سند برای قضیه: {selectedCase?.caseId}</DialogTitle>
            <DialogDescription>
              اطلاعات سند را وارد کرده و فایل را آپلود کنید.
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleUploadSubmit}>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="upload-file">فایل *</Label>
                <Input
                  id="upload-file"
                  type="file"
                  accept=".pdf,.jpg,.jpeg,.png"
                  onChange={handleFileSelect}
                  required
                />
                {selectedFile && (
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <FileText className="h-4 w-4" />
                    <span>{selectedFile.name}</span>
                    <span>({(selectedFile.size / 1024 / 1024).toFixed(2)} MB)</span>
                  </div>
                )}
              </div>
              <div className="space-y-2">
                <Label htmlFor="upload-doc-type">نوع سند *</Label>
                <Select
                  value={uploadForm.docType}
                  onValueChange={(value) => setUploadForm({ ...uploadForm, docType: value })}
                >
                  <SelectTrigger id="upload-doc-type" className="text-right" dir="rtl">
                    <SelectValue placeholder="انتخاب نوع سند" />
                  </SelectTrigger>
                  <SelectContent dir="rtl">
                    <SelectItem value="مکتوب">مکتوب</SelectItem>
                    <SelectItem value="استعلام">استعلام</SelectItem>
                    <SelectItem value="اسناد حمایوی">اسناد حمایوی</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="upload-doc-date">تاریخ سند *</Label>
                <ShamsiDatePickerDDMMYYYY
                  value={uploadForm.docDate}
                  onChange={(date) => setUploadForm({ ...uploadForm, docDate: date })}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="upload-description">توضیحات</Label>
                <Textarea
                  id="upload-description"
                  value={uploadForm.description}
                  onChange={(e) => setUploadForm({ ...uploadForm, description: e.target.value })}
                  placeholder="توضیحات اختیاری"
                  rows={3}
                  className="text-right"
                />
              </div>
              <div className="flex items-center space-x-2 space-x-reverse">
                <Checkbox
                  id="upload-is-final"
                  checked={uploadForm.isFinal}
                  onCheckedChange={(checked) => setUploadForm({ ...uploadForm, isFinal: checked === true })}
                />
                <Label htmlFor="upload-is-final" className="cursor-pointer">
                  سند نهایی است
                </Label>
              </div>
            </div>
            <DialogFooter className="mt-6">
              <Button
                type="button"
                variant="outline"
                onClick={() => {
                  setUploadDialogOpen(false);
                  setUploadForm({ docType: '', docDate: '', description: '', isFinal: false });
                  setSelectedFile(null);
                }}
              >
                لغو
              </Button>
              <Button type="submit" disabled={uploadDocumentMutation.isPending}>
                {uploadDocumentMutation.isPending ? 'در حال آپلود...' : 'آپلود'}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Assign Case Dialog */}
      <Dialog open={assignDialogOpen} onOpenChange={setAssignDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>واگذاری قضیه: {selectedCase?.caseId}</DialogTitle>
            <DialogDescription>
              قضیه را به یک بررس  یا گروه اختصاص دهید.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-6">
            <Tabs defaultValue="user" className="w-full">
              <TabsList className={`grid w-full ${canAssignToGroup ? 'grid-cols-2' : 'grid-cols-1'}`}>
                <TabsTrigger value="user">اختصاص به بررس</TabsTrigger>
                {/* Only show group assignment tab for system admin or coordinators */}
                {canAssignToGroup && (
                  <TabsTrigger value="group">اختصاص به گروه</TabsTrigger>
                )}
              </TabsList>
              
              <TabsContent value="user" className="space-y-4 mt-4">
                <div className="space-y-4">
                  {/* Group selector for Senior Auditors - allows them to select a group first to see its members */}
                  {currentUser?.role === 'senior_auditor' && 
                   !currentUser?.permissionPackages?.includes('acting_coordinator') && (
                    <div className="space-y-2">
                      <Label htmlFor="select-group-for-auditors">انتخاب گروه (برای مشاهده اعضا)</Label>
                      <Select
                        value={selectedGroupId || selectedCase?.receivingGroup || currentUser?.groupId || ''}
                        onValueChange={(groupId) => {
                          setSelectedGroupId(groupId);
                          // Refetch group auditors when group is selected
                          if (groupId) {
                            refetchGroupAuditors();
                            refetchGroupMembers();
                          }
                        }}
                      >
                        <SelectTrigger id="select-group-for-auditors" className="text-right" dir="rtl">
                          <SelectValue placeholder="انتخاب گروه" />
                        </SelectTrigger>
                        <SelectContent dir="rtl">
                          {groups.filter(g => g.isActive && (g.id === currentUser?.groupId || canAssignToGroup)).map((group) => {
                            if (!group.id) return null;
                            return (
                              <SelectItem key={group.id} value={group.id}>
                                {group.name} {group.code ? `(${group.code})` : ''}
                              </SelectItem>
                            );
                          }).filter(Boolean)}
                        </SelectContent>
                      </Select>
                    </div>
                  )}
                  
                  <div className="space-y-2">
                    <Label htmlFor="assign-user">انتخاب کاربر</Label>
                    {/* Show group members if case is assigned to a group */}
                    {selectedCase?.receivingGroup && groupMembers.length > 0 && (
                      <div className="mb-3 p-2 bg-muted rounded text-xs">
                        این قضیه به گروه اختصاص داده شده است. اعضای گروه:
                      </div>
                    )}
                    <Select
                      onValueChange={(userId) => {
                        if (selectedCase) {
                          assignCaseMutation.mutate({ caseId: selectedCase.id, userId });
                        }
                      }}
                    >
                      <SelectTrigger id="assign-user" className="text-right" dir="rtl">
                        <SelectValue placeholder="انتخاب کاربر" />
                      </SelectTrigger>
                      <SelectContent dir="rtl">
                        {/* Priority 1: Use auditors endpoint (includes both auditors and senior_auditors for self-assignment) */}
                        {availableAuditors.length > 0 ? (
                          availableAuditors.map((auditor: any) => {
                            if (!auditor || !auditor.id) return null;
                            return (
                              <SelectItem key={auditor.id} value={auditor.id}>
                                {auditor.fullName || 'نامشخص'} {auditor.auditId ? `(${auditor.auditId})` : ''}
                              </SelectItem>
                            );
                          }).filter(Boolean) // Remove null entries
                        ) : (
                          // Priority 2: No group members available - show all eligible users based on permissions
                          // For Coordinators/SysAdmins: show all auditors
                          // For Senior Auditors: show only their group members (already handled above, but fallback)
                          users.length > 0 ? (
                            users
                              .filter(u => {
                                if (!u.isActive) return false;
                                if (u.role !== 'auditor' && u.role !== 'senior_auditor') return false;
                                // Senior auditor without coordinator package can only assign to their own group members
                                if (currentUser?.role === 'senior_auditor' && 
                                    !currentUser?.permissionPackages?.includes('acting_coordinator') &&
                                    currentUser?.groupId) {
                                  return u.groupId === currentUser.groupId;
                                }
                                // Coordinators and SysAdmins can see all auditors
                                return true;
                              })
                              .map((user) => {
                                if (!user.id) return null; // Skip if no valid user ID
                                return (
                                  <SelectItem key={user.id} value={user.id}>
                                    {user.fullName || 'نامشخص'} {user.auditId ? `(${user.auditId})` : ''}
                                  </SelectItem>
                                );
                              })
                              .filter(Boolean) // Remove null entries
                          ) : (
                            <SelectItem value="__no_users__" disabled>
                              هیچ کاربری یافت نشد
                            </SelectItem>
                          )
                        )}
                      </SelectContent>
                    </Select>
                    {groupIdToFetch && availableAuditors.length === 0 && (
                      <p className="text-xs text-muted-foreground mt-2">
                        {groupIdToFetch ? 'در حال بارگذاری بررس‌های گروه...' : 'در حال بارگذاری کاربران...'}
                      </p>
                    )}
                    {!groupIdToFetch && users.length === 0 && (
                      <p className="text-xs text-muted-foreground mt-2">
                        در حال بارگذاری کاربران...
                      </p>
                    )}
                    {currentUser?.role === 'senior_auditor' && 
                     !currentUser?.permissionPackages?.includes('acting_coordinator') && (
                      <p className="text-xs text-muted-foreground mt-2">
                        شما فقط می‌توانید قضایا را به اعضای گروه خود اختصاص دهید.
                      </p>
                    )}
                  </div>
                </div>
              </TabsContent>
              
              <TabsContent value="group" className="space-y-4 mt-4">
                <div className="space-y-2">
                  <Label htmlFor="assign-group">انتخاب گروه</Label>
                  <Select
                    value={selectedGroupId || ''}
                    onValueChange={(groupId) => {
                      setSelectedGroupId(groupId);
                      // Refetch group members when group is selected
                      if (groupId) {
                        refetchGroupMembers();
                      }
                    }}
                  >
                    <SelectTrigger id="assign-group" className="text-right" dir="rtl">
                      <SelectValue placeholder="انتخاب گروه" />
                    </SelectTrigger>
                    <SelectContent dir="rtl">
                      {groups.filter(g => g.isActive).map((group) => {
                        if (!group.id) return null; // Skip if no valid group ID
                        return (
                          <SelectItem key={group.id} value={group.id}>
                            {group.name} {group.code ? `(${group.code})` : ''}
                          </SelectItem>
                        );
                      }).filter(Boolean)}
                    </SelectContent>
                  </Select>
                  {selectedGroupId && groupMembers && groupMembers.length > 0 && (
                    <div className="mt-4 p-3 bg-muted rounded-lg">
                      <Label className="text-sm font-semibold mb-2 block">اعضای فعال گروه ({groupMembers.length})</Label>
                      <div className="space-y-1 max-h-40 overflow-y-auto">
                        {groupMembers.map((member: any) => (
                          <div key={member.id || member.userId} className="text-sm flex items-center justify-between py-1">
                            <span>{member.user?.fullName || 'نامشخص'}</span>
                            <Badge variant="outline" className="text-xs">
                              {member.user?.role === 'senior_auditor' ? 'مدیر عمومی گروه' : 
                               member.user?.role === 'auditor' ? 'بررس' : 
                               member.user?.role || 'نامشخص'}
                            </Badge>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                  {selectedGroupId && groupMembers && groupMembers.length === 0 && (
                    <p className="text-xs text-muted-foreground mt-2">
                      این گروه هیچ عضو فعالی ندارد.
                    </p>
                  )}
                  <p className="text-xs text-muted-foreground mt-2">
                    با اختصاص به گروه، تمام اعضای فعال گروه می‌توانند قضیه را مشاهده کنند.
                  </p>
                  {selectedGroupId && (
                    <Button
                      onClick={() => {
                        if (selectedCase && selectedGroupId) {
                          assignCaseMutation.mutate({ caseId: selectedCase.id, groupId: selectedGroupId });
                        }
                      }}
                      className="w-full mt-2"
                      disabled={assignCaseMutation.isPending}
                    >
                      {assignCaseMutation.isPending ? 'در حال واگذاری...' : 'واگذاری به گروه'}
                    </Button>
                  )}
                </div>
              </TabsContent>
            </Tabs>
            
            <DialogFooter>
              <Button
                variant="outline"
                onClick={() => {
                  setAssignDialogOpen(false);
                  setSelectedCase(null);
                }}
              >
                لغو
              </Button>
            </DialogFooter>
          </div>
        </DialogContent>
      </Dialog>

      {/* Financial Follow-Up Form Dialog */}
      {selectedCase && (
        <FinancialFollowUpForm
          caseId={selectedCase.id}
          caseData={selectedCase}
          open={financialFollowUpOpen}
          onOpenChange={(open) => {
            setFinancialFollowUpOpen(open);
            if (!open) {
              setSelectedCase(null);
            }
          }}
        />
      )}

      {/* Case Report Dialog - Shown before completing case */}
      <Dialog open={reportDialogOpen} onOpenChange={setReportDialogOpen}>
        <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto" dir="rtl">
          <DialogHeader>
            <DialogTitle>تکمیل گزارش قضیه: {selectedCase?.caseId}</DialogTitle>
            <DialogDescription>
              لطفاً تمام بخش‌های گزارش را تکمیل کنید. گزارش به صورت خودکار ذخیره می‌شود.
            </DialogDescription>
          </DialogHeader>
          {selectedCase && (
            <CaseReportFormV2
              caseData={selectedCase}
              onComplete={async () => {
                // After report is completed, complete the case using state machine
                try {
                  const response = await fetch(`/api/cases/${selectedCase.id}/transition`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    credentials: 'include',
                    body: JSON.stringify({ transition: 'complete' }),
                  });

                  if (!response.ok) {
                    const error = await response.json();
                    throw new Error(error.error?.message || 'Failed to complete case');
                  }

                  queryClient.invalidateQueries({ queryKey: ['cases'] });
                  setReportDialogOpen(false);
                  setSelectedCase(null);
                  
                  toast({
                    title: 'موفق',
                    description: 'گزارش و قضیه با موفقیت تکمیل شدند',
                  });
                } catch (error: any) {
                  toast({
                    title: 'خطا',
                    description: error.message || 'خطا در تکمیل قضیه',
                    variant: 'destructive',
                  });
                }
              }}
              onCancel={() => {
                setReportDialogOpen(false);
                setSelectedCase(null);
              }}
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
