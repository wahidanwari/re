import { createContext, useContext, useState, useEffect, useRef, ReactNode } from 'react';

type UserRole = 'system_admin' | 'director' | 'senior_auditor' | 'auditor';

interface AuthUser {
  id: string;
  auditId: string;
  fullName: string;
  role: UserRole;
  groupId?: string;
  permissionPackages?: string[];
  phoneNumber?: string;
  mustChangePassword?: boolean;
  permissionsVersion?: number; // Version stamp for permission changes
  effectivePermissions?: string[]; // Array of permission names from server
}

interface AuthContextType {
  user: AuthUser | null;
  loading: boolean;
  login: (auditId: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
  refresh: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [loading, setLoading] = useState(true);
  const refreshRef = useRef<() => Promise<void>>();
  
  // Inactivity detection state
  const [showInactivityWarning, setShowInactivityWarning] = useState(false);
  const [timeUntilLogout, setTimeUntilLogout] = useState(0);
  const lastActivityRef = useRef<number>(Date.now());
  const inactivityWarningTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const inactivityLogoutTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const heartbeatIntervalRef = useRef<NodeJS.Timeout | null>(null);
  
  // Session timeout configuration (90 minutes inactivity default, 1 minute warning before)
  // Matches server SESSION_INACTIVITY_TIMEOUT (default: 90 minutes = 5400000ms)
  const SESSION_TIMEOUT_MS = 90 * 60 * 1000; // 90 minutes inactivity timeout
  const WARNING_BEFORE_MS = 60 * 1000; // 1 minute before logout

  // Handle session expiration
  const handleSessionExpired = async () => {
    setShowInactivityWarning(false);
    setUser(null);
    // Clear permissions cache
    try {
      const { clearPermissionsCache } = await import('../utils/permissions');
      clearPermissionsCache();
    } catch (error) {
      console.error('Failed to clear permissions cache:', error);
    }
    // Redirect to login if not already there
    if (window.location.pathname !== '/login') {
      window.location.href = '/login';
    }
  };
  
  // Reset inactivity detection timers
  const resetInactivityTimers = () => {
    // Clear existing timers
    if (inactivityWarningTimeoutRef.current) {
      clearTimeout(inactivityWarningTimeoutRef.current);
    }
    if (inactivityLogoutTimeoutRef.current) {
      clearTimeout(inactivityLogoutTimeoutRef.current);
    }
    
    setShowInactivityWarning(false);
    
    if (!user) return;
    
    const now = Date.now();
    const timeSinceLastActivity = now - lastActivityRef.current;
    const timeUntilExpiration = SESSION_TIMEOUT_MS - timeSinceLastActivity;
    
    // Set warning timer (1 minute before expiration)
    if (timeUntilExpiration > WARNING_BEFORE_MS) {
      inactivityWarningTimeoutRef.current = setTimeout(() => {
        setShowInactivityWarning(true);
        const remaining = SESSION_TIMEOUT_MS - (Date.now() - lastActivityRef.current);
        setTimeUntilLogout(Math.max(0, remaining));
        
        // Update countdown every second
        const countdownInterval = setInterval(() => {
          const remaining = SESSION_TIMEOUT_MS - (Date.now() - lastActivityRef.current);
          setTimeUntilLogout(Math.max(0, remaining));
          
          if (remaining <= 0) {
            clearInterval(countdownInterval);
            handleSessionExpired();
          }
        }, 1000);
        
        // Set logout timer
        inactivityLogoutTimeoutRef.current = setTimeout(() => {
          clearInterval(countdownInterval);
          handleSessionExpired();
        }, remaining);
      }, timeUntilExpiration - WARNING_BEFORE_MS);
    } else {
      // Already past warning time, show warning immediately
      setShowInactivityWarning(true);
      setTimeUntilLogout(Math.max(0, timeUntilExpiration));
    }
  };

  // Heartbeat function to keep session alive
  const sendHeartbeat = async () => {
    if (!user) return;
    
    try {
      const response = await fetch('/api/session/heartbeat', {
        method: 'POST',
        credentials: 'include',
      });
      
      if (response.ok) {
        const data = await response.json();
        lastActivityRef.current = Date.now();
        // Reset inactivity timers
        resetInactivityTimers();
      } else if (response.status === 401) {
        // Session expired
        handleSessionExpired();
      }
    } catch (error) {
      console.error('Heartbeat failed:', error);
      // Don't logout on network errors - might be temporary
    }
  };
  
  // Extend session (called when user clicks "Stay Logged In")
  const extendSession = async () => {
    await sendHeartbeat();
    setShowInactivityWarning(false);
  };
  
  // Track user activity (mouse, keyboard, touch)
  useEffect(() => {
    if (!user) return;
    
    const activityEvents = ['mousedown', 'mousemove', 'keypress', 'scroll', 'touchstart', 'click'];
    const handleActivity = () => {
      lastActivityRef.current = Date.now();
      resetInactivityTimers();
    };
    
    activityEvents.forEach(event => {
      document.addEventListener(event, handleActivity, true);
    });
    
    return () => {
      activityEvents.forEach(event => {
        document.removeEventListener(event, handleActivity, true);
      });
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user]); // resetInactivityTimers is stable, no need to include
  
  // Initial auth check on mount (session persistence)
  useEffect(() => {
    const checkAuth = async () => {
      try {
        const response = await fetch('/api/auth/me', {
          credentials: 'include',
          cache: 'no-store', // Prevent browser cache
        });
        
        if (response.ok) {
          const data = await response.json();
          // CRITICAL: Ensure permissionPackages is always an array
          const userData = {
            ...data.user,
            permissionPackages: Array.isArray(data.user?.permissionPackages) 
              ? data.user.permissionPackages 
              : (data.user?.permissionPackages ? [data.user.permissionPackages] : []),
            permissionsVersion: data.permissionsVersion,
            modules: data.modules || [], // Include modules from server
          };
          setUser(userData);
          
          // Initialize last activity
          lastActivityRef.current = Date.now();
          
          // Preload permissions after auth check
          if (data.user) {
            try {
              const { getUserPermissions, clearPermissionsCache } = await import('../utils/permissions');
              clearPermissionsCache(); // Clear stale cache
              await getUserPermissions(data.user);
            } catch (error) {
              console.warn('Failed to preload permissions:', error);
            }
          }
        } else if (response.status === 401) {
          // Session expired or invalid - but don't redirect on initial load
          // Let the app handle it naturally
          setUser(null);
        }
      } catch (error) {
        console.error('Failed to check authentication:', error);
        // Don't clear user on network errors - might be temporary
      } finally {
        setLoading(false);
      }
    };
    
    checkAuth();
  }, []); // Only run on mount

  // Heartbeat and inactivity detection - separate effect that depends on user
  useEffect(() => {
    if (!user) {
      // Clean up timers when user logs out
      if (heartbeatIntervalRef.current) {
        clearInterval(heartbeatIntervalRef.current);
        heartbeatIntervalRef.current = null;
      }
      if (inactivityWarningTimeoutRef.current) {
        clearTimeout(inactivityWarningTimeoutRef.current);
        inactivityWarningTimeoutRef.current = null;
      }
      if (inactivityLogoutTimeoutRef.current) {
        clearTimeout(inactivityLogoutTimeoutRef.current);
        inactivityLogoutTimeoutRef.current = null;
      }
      return;
    }
    
    // Set up periodic heartbeat (every 5 minutes)
    heartbeatIntervalRef.current = setInterval(() => {
      sendHeartbeat();
    }, 5 * 60 * 1000); // 5 minutes
    
    // Initialize inactivity timers
    resetInactivityTimers();
    
    return () => {
      if (heartbeatIntervalRef.current) {
        clearInterval(heartbeatIntervalRef.current);
      }
      if (inactivityWarningTimeoutRef.current) {
        clearTimeout(inactivityWarningTimeoutRef.current);
      }
      if (inactivityLogoutTimeoutRef.current) {
        clearTimeout(inactivityLogoutTimeoutRef.current);
      }
    };
  }, [user]);
  
  // WebSocket and periodic permission check - separate effect that depends on user
  useEffect(() => {
    if (!user) return; // Don't set up if no user
    
    // Set up WebSocket connection for real-time permission updates
    let ws: WebSocket | null = null;
    let reconnectTimeout: NodeJS.Timeout | null = null;
    
    const connectWebSocket = () => {
      // CRITICAL: In development, WebSocket must connect to backend server, not Vite dev server
      // Vite proxies /api/* but not /ws/*, so we need to construct the backend URL
      // NOTE: Browser will log WebSocket connection failures automatically - this cannot be suppressed
      // This is expected behavior and harmless - WebSocket is optional, failures are handled gracefully
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      
      // Determine backend host and port
      let backendHost: string;
      let backendPort: string | number = '';
      
      if (import.meta.env.DEV) {
        // Development: Backend is typically on localhost:3000 or same host as API
        // Try to extract from API calls or use default
        const apiUrl = import.meta.env.VITE_API_URL;
        if (apiUrl) {
          try {
            const url = new URL(apiUrl);
            backendHost = url.hostname;
            backendPort = url.port || (protocol === 'wss:' ? 443 : 80);
          } catch {
            // Fallback: Use same hostname as current page, port 3000
            backendHost = window.location.hostname;
            backendPort = 3000;
          }
        } else {
          // Default: Use same hostname as current page, port 3000
          // This handles both localhost and network access (e.g., 192.168.5.130)
          backendHost = window.location.hostname;
          backendPort = 3000;
        }
      } else {
        // Production: Use same host as the page
        backendHost = window.location.hostname;
        backendPort = window.location.port || (protocol === 'wss:' ? 443 : 80);
      }
      
      const wsUrl = backendPort 
        ? `${protocol}//${backendHost}:${backendPort}/ws/notifications`
        : `${protocol}//${backendHost}/ws/notifications`;
      
      // NOTE: Browser will automatically log WebSocket connection failures to console
      // This is a browser security feature and cannot be suppressed programmatically
      // The error is harmless - WebSocket is optional and failures are handled gracefully
      try {
        ws = new WebSocket(wsUrl);
        
        ws.onopen = () => {
          // Only log WebSocket connections in debug mode
          // Use import.meta.env for Vite (client-side), not process.env
          if (import.meta.env.VITE_DEBUG_WEBSOCKET === 'true') {
            console.log('[WebSocket] Connected for notifications at', wsUrl);
          }
          if (reconnectTimeout) {
            clearTimeout(reconnectTimeout);
            reconnectTimeout = null;
          }
        };
        
        ws.onmessage = async (event) => {
          try {
            const message = JSON.parse(event.data);
            
            if (message.type === 'permission_change') {
              console.log('Permission change notification received, refreshing session...');
              // Clear all caches and refresh session
              try {
                const { clearPermissionsCache } = await import('../utils/permissions');
                clearPermissionsCache();
                
                // Use refresh-session endpoint to regenerate session with latest data
                const refreshResponse = await fetch('/api/auth/refresh-session', {
                  method: 'POST',
                  credentials: 'include',
                  cache: 'no-store',
                  headers: {
                    'Cache-Control': 'no-cache',
                    'Pragma': 'no-cache',
                  },
                });
                
                if (refreshResponse.ok) {
                  const data = await refreshResponse.json();
                  // CRITICAL: Ensure permissionPackages is always an array and create a NEW array reference
                  const permissionPackagesArray = Array.isArray(data.user?.permissionPackages) 
                    ? [...data.user.permissionPackages] // Create new array reference
                    : (data.user?.permissionPackages ? [data.user.permissionPackages] : []);
                  
                  // CRITICAL: Use effectivePermissions from server response
                  const effectivePermissionsList = data.user?.effectivePermissions || 
                                                   data.effectivePermissionsList || 
                                                   [];
                  
                  const userData = {
                    ...data.user,
                    permissionPackages: permissionPackagesArray, // New array reference ensures React detects change
                    permissionsVersion: data.permissionsVersion || 1,
                    effectivePermissions: effectivePermissionsList, // Server-computed permissions
                    modules: data.modules || [], // Server-provided modules list
                  };
                  
                  console.log('Session refreshed with new permissions:', {
                    permissionsVersion: userData.permissionsVersion,
                    permissionPackages: userData.permissionPackages,
                    role: userData.role,
                    effectivePermissions: userData.effectivePermissions,
                    modules: userData.modules,
                  });
                  
                  // Update user state - this will trigger re-renders
                  setUser({ ...userData });
                  
                  // Small delay to ensure state update, then refresh permissions with force refresh
                  setTimeout(async () => {
                    try {
                      const { getUserPermissions, clearPermissionsCache: clearCache } = await import('../utils/permissions');
                      clearCache(); // Clear cache again to force fresh fetch
                      // Force refresh to bypass any cache
                      await getUserPermissions(userData, true);
                    } catch (permError) {
                      console.error('Failed to refresh permissions:', permError);
                    }
                  }, 100);
                } else {
                  // Fallback to /api/auth/me if refresh-session fails
                  console.warn('refresh-session failed, falling back to /api/auth/me');
                  const response = await fetch('/api/auth/me', {
                    credentials: 'include',
                    cache: 'no-store',
                    headers: {
                      'Cache-Control': 'no-cache',
                      'Pragma': 'no-cache',
                    },
                  });
                  
                  if (response.ok) {
                    const data = await response.json();
                    const permissionPackagesArray = Array.isArray(data.user?.permissionPackages) 
                      ? [...data.user.permissionPackages]
                      : (data.user?.permissionPackages ? [data.user.permissionPackages] : []);
                    
                    const effectivePermissionsList = data.user?.effectivePermissions || 
                                                     data.effectivePermissionsList || 
                                                     [];
                    
                    const userData = {
                      ...data.user,
                      permissionPackages: permissionPackagesArray,
                      permissionsVersion: data.permissionsVersion || 1,
                      effectivePermissions: effectivePermissionsList,
                      modules: data.modules || [],
                    };
                    
                    setUser({ ...userData });
                  }
                }
              } catch (error) {
                console.error('Failed to refresh session on permission change:', error);
              }
            }
            
            if (message.type === 'session_invalidated') {
              console.log('Session invalidated notification received, logging out...');
              // Clear user data and permissions cache
              setUser(null);
              try {
                const { clearPermissionsCache } = await import('../utils/permissions');
                clearPermissionsCache();
              } catch (error) {
                console.error('Failed to clear permissions cache:', error);
              }
              // Redirect to login
              if (window.location.pathname !== '/login') {
                window.location.href = '/login';
              }
            }
            
            if (message.type === 'notification') {
              // Handle other notifications if needed
              console.log('Notification received:', message.data);
            }
          } catch (error) {
            // Only log parsing errors in debug mode
            if (import.meta.env.VITE_DEBUG_WEBSOCKET === 'true') {
              console.error('Error parsing WebSocket message:', error);
            }
          }
        };
        
        ws.onerror = (error) => {
          // CRITICAL: Suppress WebSocket errors to prevent UI freezing
          // WebSocket connection failures should not block the application
          // WebSocket is optional for real-time updates - failures are expected in development
          // Only log if explicitly debugging
          // Use import.meta.env for Vite (client-side), not process.env
          if (import.meta.env.VITE_DEBUG_WEBSOCKET === 'true') {
            console.error('[WebSocket] Connection error:', error);
          }
          // Silently handle error - WebSocket is optional, don't log to console
        };
        
        ws.onclose = (event) => {
          // Only log disconnections in debug mode to reduce noise
          // Use import.meta.env for Vite (client-side), not process.env
          if (import.meta.env.VITE_DEBUG_WEBSOCKET === 'true') {
            console.log('[WebSocket] Disconnected (code:', event.code, '), will reconnect...');
          }
          ws = null;
          // Reconnect after 5 seconds (only if user is still logged in)
          if (user) {
            reconnectTimeout = setTimeout(connectWebSocket, 5000);
          }
        };
      } catch (error) {
        // CRITICAL: Catch and suppress WebSocket connection errors
        // Don't let WebSocket failures block the UI
        if (import.meta.env.VITE_DEBUG_WEBSOCKET === 'true') {
          console.error('Failed to connect WebSocket:', error);
        }
        // Schedule retry only if user is still logged in
        if (user && !reconnectTimeout) {
          reconnectTimeout = setTimeout(connectWebSocket, 5000);
        }
      }
    };
    
    // CRITICAL: Connect WebSocket only if user is logged in
    // Make it non-blocking - don't let WebSocket failures freeze the UI
    // Use setTimeout to make WebSocket connection non-blocking
    setTimeout(() => {
      try {
        connectWebSocket();
      } catch (error) {
        // Silently fail - WebSocket is optional
        if (import.meta.env.VITE_DEBUG_WEBSOCKET === 'true') {
          console.error('WebSocket connection failed (non-blocking):', error);
        }
      }
    }, 0);
    
    // Set up periodic permission check (every 30 seconds) as fallback
    const permissionCheckInterval = setInterval(async () => {
      try {
        const response = await fetch('/api/auth/me', {
          credentials: 'include',
          cache: 'no-store',
        });
        
        if (response.ok) {
          const data = await response.json();
          const newVersion = data.permissionsVersion;
          const currentVersion = user?.permissionsVersion;
          
          // If permissions version changed, refresh user and permissions
          if (newVersion !== undefined && currentVersion !== undefined && newVersion !== currentVersion) {
            console.log('Permissions changed (detected via polling), refreshing...');
            
            // CRITICAL: Ensure permissionPackages is always an array
            const userData = {
              ...data.user,
              permissionPackages: Array.isArray(data.user?.permissionPackages) 
                ? data.user.permissionPackages 
                : (data.user?.permissionPackages ? [data.user.permissionPackages] : []),
              permissionsVersion: newVersion,
            };
            
            // Update user state with new permissions version
            setUser(userData);
            
            const { getUserPermissions, clearPermissionsCache } = await import('../utils/permissions');
            clearPermissionsCache();
            await getUserPermissions(userData);
            
            // Invalidate all query caches to force refresh
            const { queryClient } = await import('../lib/queryClient');
            queryClient.invalidateQueries();
            
            // Try to show a user-friendly notification
            try {
              const event = new CustomEvent('permissions-updated', {
                detail: { message: 'دسترسی‌های شما بروز رسانی شد' }
              });
              window.dispatchEvent(event);
            } catch (e) {
              // Toast might not be available, that's okay
            }
          }
        }
      } catch (error) {
        // Silent fail for background checks
        console.debug('Background permission check failed:', error);
      }
    }, 30000); // 30 seconds
    
    return () => {
      if (ws) {
        try {
          ws.close();
        } catch (error) {
          // Ignore errors during cleanup - WebSocket might already be closed
        }
        ws = null;
      }
      if (reconnectTimeout) {
        clearTimeout(reconnectTimeout);
        reconnectTimeout = null;
      }
      clearInterval(permissionCheckInterval);
    };
  }, [user?.id]); // Re-run if user ID changes

  const login = async (auditId: string, password: string) => {
    const response = await fetch('/api/auth/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ auditId, password }),
      credentials: 'include',
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.message || 'ورود ناموفق بود');
    }

    const data = await response.json();
    
    // CRITICAL: Use effectivePermissions from login response if available
    const effectivePermissionsList = data.effectivePermissions || data.user?.effectivePermissions || [];
    
    // Immediately fetch fresh user data with permissions
    const meResponse = await fetch('/api/auth/me', { 
      credentials: 'include',
      cache: 'no-store',
    });
    if (meResponse.ok) {
      const meData = await meResponse.json();
      // CRITICAL: Ensure permissionPackages is always an array
      const userData = {
        ...meData.user,
        permissionPackages: Array.isArray(meData.user?.permissionPackages) 
          ? meData.user.permissionPackages 
          : (meData.user?.permissionPackages ? [meData.user.permissionPackages] : []),
        permissionsVersion: meData.permissionsVersion,
        effectivePermissions: effectivePermissionsList.length > 0 
          ? effectivePermissionsList 
          : (meData.effectivePermissions || []), // Use from /me if login didn't have it
      };
      setUser(userData);
      
      // Preload permissions after login
      try {
        const { getUserPermissions, clearPermissionsCache } = await import('../utils/permissions');
        clearPermissionsCache(); // Clear any stale cache
        await getUserPermissions(userData);
      } catch (error) {
        console.warn('Failed to preload permissions:', error);
      }
    } else {
      // Fallback to login response data - ensure array
      const fallbackUser = {
        ...data.user,
        permissionPackages: Array.isArray(data.user?.permissionPackages) 
          ? data.user.permissionPackages 
          : (data.user?.permissionPackages ? [data.user.permissionPackages] : []),
        effectivePermissions: effectivePermissionsList,
      };
      setUser(fallbackUser);
    }
  };

  const logout = async () => {
    try {
      await fetch('/api/auth/logout', {
        method: 'POST',
        credentials: 'include',
      });
    } catch (error) {
      console.error('Logout error:', error);
    } finally {
      setUser(null);
      // Clear permissions cache on logout
      const { clearPermissionsCache } = await import('../utils/permissions');
      clearPermissionsCache();
    }
  };

  const refresh = async () => {
    try {
      const response = await fetch('/api/auth/me', {
        credentials: 'include',
        cache: 'no-store', // Force fresh data
      });
      
      if (response.ok) {
        const data = await response.json();
        // CRITICAL: Ensure permissionPackages is always an array
        const userData = {
          ...data.user,
          permissionPackages: Array.isArray(data.user?.permissionPackages) 
            ? data.user.permissionPackages 
            : (data.user?.permissionPackages ? [data.user.permissionPackages] : []),
          permissionsVersion: data.permissionsVersion,
        };
        setUser(userData);
        
        // Refresh permissions cache
        if (userData) {
          try {
            const { getUserPermissions, clearPermissionsCache } = await import('../utils/permissions');
            clearPermissionsCache(); // Clear old cache
            await getUserPermissions(userData);
            
            // Invalidate all query caches to force refresh
            const { queryClient } = await import('../lib/queryClient');
            queryClient.invalidateQueries();
          } catch (error) {
            console.warn('Failed to refresh permissions:', error);
          }
        }
      } else if (response.status === 401) {
        // Session expired
        setUser(null);
      }
    } catch (error) {
      console.error('Failed to refresh user:', error);
    }
  };

  // Update ref whenever refresh function changes
  refreshRef.current = refresh;

  return (
    <AuthContext.Provider value={{ user, loading, login, logout, refresh }}>
      {children}
      {/* Inactivity Warning Modal */}
      {showInactivityWarning && user && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-md w-full mx-4 shadow-xl">
            <h2 className="text-xl font-bold mb-4">نشست شما در حال منقضی شدن است</h2>
            <p className="mb-4">
              شما برای {Math.ceil(timeUntilLogout / 1000)} ثانیه غیرفعال بوده‌اید. 
              نشست شما به زودی منقضی خواهد شد.
            </p>
            <div className="flex gap-4">
              <button
                onClick={extendSession}
                className="flex-1 bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
              >
                ادامه کار
              </button>
              <button
                onClick={handleSessionExpired}
                className="flex-1 bg-gray-300 text-gray-800 px-4 py-2 rounded hover:bg-gray-400"
              >
                خروج
              </button>
            </div>
          </div>
        </div>
      )}
    </AuthContext.Provider>
  );
}

// Export hook separately to avoid Fast Refresh issues
// eslint-disable-next-line react-refresh/only-export-components
export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within AuthProvider');
  return context;
}
