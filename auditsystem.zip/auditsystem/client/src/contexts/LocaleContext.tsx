import { createContext, useContext, useState, ReactNode } from 'react';

type Locale = 'dari' | 'pashto' | 'english';

interface LocaleContextType {
  locale: Locale;
  setLocale: (locale: Locale) => void;
  t: (dari: string, pashto?: string, english?: string) => string;
}

const LocaleContext = createContext<LocaleContextType | undefined>(undefined);

export function LocaleProvider({ children }: { children: ReactNode }) {
  const [locale, setLocale] = useState<Locale>('dari');

  const t = (dari: string, pashto?: string, english?: string) => {
    if (locale === 'pashto' && pashto) return pashto;
    if (locale === 'english' && english) return english;
    return dari;
  };

  return (
    <LocaleContext.Provider value={{ locale, setLocale, t }}>
      {children}
    </LocaleContext.Provider>
  );
}

export function useLocale() {
  const context = useContext(LocaleContext);
  if (!context) throw new Error('useLocale must be used within LocaleProvider');
  return context;
}
