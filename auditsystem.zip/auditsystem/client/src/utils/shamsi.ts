export function toShamsi(date: Date): string {
  const year = date.getFullYear();
  const month = date.getMonth() + 1;
  const day = date.getDate();
  
  const shamsiYear = year - 621;
  const shamsiMonth = month;
  const shamsiDay = day;
  
  return `${shamsiYear}/${String(shamsiMonth).padStart(2, '0')}/${String(shamsiDay).padStart(2, '0')}`;
}

export function fromShamsi(shamsiDate: string): Date {
  const [year, month, day] = shamsiDate.split('/').map(Number);
  const gregorianYear = year + 621;
  return new Date(gregorianYear, month - 1, day);
}

export function formatShamsiDate(dateString: string): string {
  return dateString;
}

export function getCurrentShamsiDate(): string {
  return toShamsi(new Date());
}
