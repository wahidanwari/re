// Client-side permission utilities
// Uses the API endpoint for effective permissions

import type { User } from '@shared/schema';

// Type for user objects that have the minimal properties needed for permission checks
type UserLike = {
  id: string;
  role: string;
  permissionPackages?: string[] | null;
};

export type Permission = 
  | 'entities:view'
  | 'entities:create'
  | 'cases:view'
  | 'cases:assign_to_auditor'
  | 'cases:assign_to_group'
  | 'cases:complete'
  | 'reports:generate'
  | 'users:manage'
  | 'groups:manage'
  | 'groups:set_targets'
  | 'tickets:submit'
  | 'tickets:approve'
  | 'documents:download'
  | 'documents:upload'
  | 'logs:view'
  | 'settings:manage';

export type EffectivePermissions = Record<Permission, boolean>;

// Cache for permissions (refreshed on user change)
let permissionsCache: EffectivePermissions | null = null;
let cachedUserId: string | null = null;

/**
 * Clear permission cache - call this when user permissions change
 */
export function clearPermissionCache() {
  permissionsCache = null;
  cachedUserId = null;
}

/**
 * Get effective permissions for a user from API (client-side)
 * @param forceRefresh - If true, bypasses cache and fetches fresh permissions
 */
export async function getUserPermissions(user: UserLike | null, forceRefresh: boolean = false): Promise<EffectivePermissions> {
  if (!user) {
    return getEmptyPermissions();
  }

  // If force refresh is requested, clear cache first
  if (forceRefresh) {
    permissionsCache = null;
    cachedUserId = null;
  }

  // Return cached permissions only if user hasn't changed AND permissionsVersion hasn't changed
  // This ensures permissions refresh when permissionsVersion is incremented
  if (permissionsCache && cachedUserId === user.id && !forceRefresh) {
    // Check if permissionsVersion has changed (if available)
    const currentVersion = (user as any).permissionsVersion;
    const cachedVersion = (permissionsCache as any).__version;
    if (currentVersion !== undefined && cachedVersion === currentVersion) {
      return permissionsCache;
    }
    // Version changed, clear cache
    permissionsCache = null;
    cachedUserId = null;
  }

  try {
    // Add cache-busting query parameter to ensure fresh fetch
    const cacheBuster = forceRefresh ? `?t=${Date.now()}` : '';
    const response = await fetch(`/api/auth/effective-permissions${cacheBuster}`, { 
      credentials: 'include',
      cache: 'no-store',
      headers: {
        'Cache-Control': 'no-cache',
        'Pragma': 'no-cache',
      },
    });
    if (!response.ok) {
      return getEmptyPermissions();
    }
    const permissions = await response.json() as EffectivePermissions;
    // Store permissionsVersion with cache for comparison
    (permissions as any).__version = (user as any).permissionsVersion;
    permissionsCache = permissions;
    cachedUserId = user.id;
    return permissions;
  } catch (error) {
    // Silently handle errors - return empty permissions
    return getEmptyPermissions();
  }
}

/**
 * Check if user has a specific permission (client-side)
 * Uses cached permissions if available, otherwise fetches from API
 */
export async function userHasPermissionAsync(user: UserLike | null, permission: Permission): Promise<boolean> {
  if (!user) return false;
  const perms = await getUserPermissions(user);
  return perms[permission] === true;
}

/**
 * Synchronous version - uses cached permissions or falls back to role-based calculation
 * For immediate checks, use this. It will use cache if available, otherwise fall back.
 * IMPORTANT: This fallback ensures UI works even before API permissions are loaded
 */
export function userHasPermission(user: UserLike | null, permission: Permission): boolean {
  if (!user) return false;
  
  // System admin always has all permissions
  if (user.role === 'system_admin') {
    return true;
  }
  
  // If cache is available and for current user, use it
  if (permissionsCache && cachedUserId === user.id) {
    return permissionsCache[permission] === true;
  }
  
  // Fallback to role-based calculation (matches shared/permissions.ts exactly)
  // This ensures frontend and backend use the same permission calculation
  const role = user.role as 'system_admin' | 'director' | 'senior_auditor' | 'auditor';
  // CRITICAL: Ensure permissionPackages is always an array
  const packages = Array.isArray(user.permissionPackages) 
    ? (user.permissionPackages as ('acting_coordinator' | 'approval_authority')[])
    : (user.permissionPackages ? [user.permissionPackages] : []) as ('acting_coordinator' | 'approval_authority')[];
  
  // System admin always has all permissions
  if (role === 'system_admin') {
    return true;
  }
  
  // Permission mapping (matches shared/permissions.ts exactly)
  const rolePermissions: Record<string, Permission[]> = {
    system_admin: ['entities:view', 'entities:create', 'cases:view', 'cases:assign_to_auditor', 'cases:assign_to_group', 'cases:complete', 'reports:generate', 'users:manage', 'groups:manage', 'groups:set_targets', 'tickets:submit', 'tickets:approve', 'documents:download', 'documents:upload', 'logs:view', 'settings:manage'],
    director: ['entities:view', 'cases:view', 'documents:download', 'reports:generate', 'groups:set_targets'],
    senior_auditor: ['entities:view', 'entities:create', 'cases:view', 'cases:assign_to_auditor', 'cases:complete', 'documents:upload', 'reports:generate', 'tickets:submit'],
    auditor: ['cases:view', 'cases:complete', 'documents:upload', 'tickets:submit'],
  };
  
  const packagePermissions: Record<string, Permission[]> = {
    acting_coordinator: ['cases:assign_to_group', 'reports:generate', 'entities:create', 'cases:view'],
    approval_authority: ['tickets:approve'],
  };
  
  const basePerms = rolePermissions[role] || [];
  const pkgPerms = packages.flatMap(pkg => packagePermissions[pkg] || []);
  const allPerms = [...new Set([...basePerms, ...pkgPerms])]; // Remove duplicates
  
  return allPerms.includes(permission);
}

/**
 * Get list of permissions user has (client-side)
 */
export async function getUserPermissionList(user: UserLike | null): Promise<Permission[]> {
  if (!user) return [];
  const perms = await getUserPermissions(user);
  return Object.entries(perms)
    .filter(([_, has]) => has)
    .map(([perm]) => perm as Permission);
}

/**
 * Clear permissions cache (call when user logs out or changes)
 */
export function clearPermissionsCache() {
  permissionsCache = null;
  cachedUserId = null;
}

/**
 * Get empty permissions object
 */
function getEmptyPermissions(): EffectivePermissions {
  return {
    'entities:view': false,
    'entities:create': false,
    'cases:view': false,
    'cases:assign_to_auditor': false,
    'cases:assign_to_group': false,
    'cases:complete': false,
    'reports:generate': false,
    'users:manage': false,
    'groups:manage': false,
    'groups:set_targets': false,
    'tickets:submit': false,
    'tickets:approve': false,
    'documents:download': false,
    'documents:upload': false,
    'logs:view': false,
    'settings:manage': false,
  };
}
