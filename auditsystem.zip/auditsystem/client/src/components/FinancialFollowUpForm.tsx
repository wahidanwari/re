/**
 * Financial Follow-Up Form
 * Dedicated form for tracking and managing tax collection independently from audit workflow
 * Used for cases appearing in قضایای در اقساط (Cases with unpaid balance)
 */

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import ShamsiDatePickerDDMMYYYY, { shamsiToGregorian } from '@/components/ShamsiDatePickerDDMMYYYY';
import { Loader2, DollarSign, Calendar, FileText, CheckCircle, XCircle } from 'lucide-react';
import jalaali from 'jalaali-js';
import StatusBadge from '@/components/StatusBadge';

interface FinancialFollowUpFormProps {
  caseId: string;
  caseData: any;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

interface PaymentRecord {
  id: string;
  paymentDate: string | Date;
  paymentAmount: string | number;
  paymentType: string;
  createdAt: string | Date;
}

export default function FinancialFollowUpForm({
  caseId,
  caseData,
  open,
  onOpenChange,
}: FinancialFollowUpFormProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [paymentForm, setPaymentForm] = useState({
    payment_date: '',
    payment_amount: '',
    payment_type: 'normal' as 'normal' | 'installment',
    notes: '',
  });

  // Fetch financial information
  const { data: financialInfo, isLoading: isLoadingFinancial } = useQuery<any>({
    queryKey: ['case-financial', caseId],
    queryFn: async () => {
      const response = await fetch(`/api/cases/${caseId}/financial`, {
        credentials: 'include',
      });
      if (!response.ok) {
        throw new Error('Failed to fetch financial information');
      }
      return response.json();
    },
    enabled: open && !!caseId,
  });

  // Fetch payment history
  const { data: payments = [], refetch: refetchPayments } = useQuery<PaymentRecord[]>({
    queryKey: ['case-payments', caseId],
    queryFn: async () => {
      const response = await fetch(`/api/cases/${caseId}/payments`, {
        credentials: 'include',
      });
      if (!response.ok) {
        return [];
      }
      return response.json();
    },
    enabled: open && !!caseId,
  });

  // Record new payment mutation
  const recordPaymentMutation = useMutation({
    mutationFn: async (data: typeof paymentForm) => {
      // Convert Shamsi date (DD-MM-YYYY) to ISO format (YYYY-MM-DD) for backend
      const isoDate = shamsiToGregorian(data.payment_date);
      if (!isoDate) {
        throw new Error('تاریخ پرداخت نامعتبر است');
      }
      
      const response = await fetch(`/api/cases/${caseId}/payments`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({
          payment_date: isoDate, // Send ISO format (YYYY-MM-DD)
          payment_amount: parseFloat(data.payment_amount) || 0,
          payment_type: data.payment_type,
          notes: data.notes || null,
        }),
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to record payment');
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['case-financial', caseId] });
      queryClient.invalidateQueries({ queryKey: ['case-payments', caseId] });
      queryClient.invalidateQueries({ queryKey: ['cases', 'unpaid'] });
      refetchPayments();
      setPaymentForm({
        payment_date: '',
        payment_amount: '',
        payment_type: 'normal',
        notes: '',
      });
      toast({
        title: 'موفق',
        description: 'پرداخت با موفقیت ثبت شد',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'خطا',
        description: error.message || 'خطا در ثبت پرداخت',
        variant: 'destructive',
      });
    },
  });

  const handleSubmitPayment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!paymentForm.payment_date || !paymentForm.payment_amount) {
      toast({
        title: 'خطا',
        description: 'لطفاً تاریخ پرداخت و مبلغ را وارد کنید',
        variant: 'destructive',
      });
      return;
    }
    const amount = parseFloat(paymentForm.payment_amount);
    if (isNaN(amount) || amount <= 0) {
      toast({
        title: 'خطا',
        description: 'مبلغ پرداخت باید بیشتر از صفر باشد',
        variant: 'destructive',
      });
      return;
    }
    recordPaymentMutation.mutate(paymentForm);
  };

  const formatCurrency = (amount: number | string | null | undefined) => {
    const num = typeof amount === 'string' ? parseFloat(amount) || 0 : (typeof amount === 'number' ? amount : 0);
    return new Intl.NumberFormat('fa-IR').format(num);
  };

  const formatDate = (dateStr: string | Date | null) => {
    if (!dateStr) return '-';
    try {
      const date = dateStr instanceof Date ? dateStr : new Date(dateStr);
      const jDate = jalaali.toJalaali(date);
      const monthNames = ['حمل', 'ثور', 'جوزا', 'سرطان', 'اسد', 'سنبله', 'میزان', 'عقرب', 'قوس', 'جدی', 'دلو', 'حوت'];
      return `${jDate.jd} ${monthNames[jDate.jm - 1]} ${jDate.jy}`;
    } catch {
      return '-';
    }
  };

  const confirmedAmount = financialInfo?.confirmedAmount || 0;
  const totalPaid = financialInfo?.totalPaid || 0;
  const remainingBalance = financialInfo?.remainingBalance || 0;

  // Calculate running balance for payment history
  const paymentHistoryWithBalance = payments
    .map((payment, index) => {
      const amount = typeof payment.paymentAmount === 'string'
        ? parseFloat(payment.paymentAmount) || 0
        : (typeof payment.paymentAmount === 'number' ? payment.paymentAmount : 0);
      
      // Calculate balance before this payment
      const paymentsBefore = payments.slice(0, index);
      const totalPaidBefore = paymentsBefore.reduce((sum, p) => {
        const pAmount = typeof p.paymentAmount === 'string'
          ? parseFloat(p.paymentAmount) || 0
          : (typeof p.paymentAmount === 'number' ? p.paymentAmount : 0);
        return sum + pAmount;
      }, 0);
      
      const balanceBefore = Math.max(0, confirmedAmount - totalPaidBefore);
      const balanceAfter = Math.max(0, balanceBefore - amount);
      
      return {
        ...payment,
        amount,
        balanceBefore,
        balanceAfter,
      };
    })
    .reverse(); // Show most recent first

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto" dir="rtl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <DollarSign className="h-5 w-5" />
            پیگیری مالی - {caseData?.companyName || caseData?.caseId}
          </DialogTitle>
          <DialogDescription>
            ثبت و پیگیری پرداخت‌های مالیاتی (مستقل از جریان بررسی)
          </DialogDescription>
        </DialogHeader>

        {isLoadingFinancial ? (
          <div className="flex items-center justify-center py-8">
            <Loader2 className="h-6 w-6 animate-spin" />
            <span className="mr-2">در حال بارگذاری...</span>
          </div>
        ) : (
          <div className="space-y-6">
            {/* Read-only Financial Information */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">اطلاعات مالی (فقط خواندنی)</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label className="text-muted-foreground">مبلغ تثبیت شده</Label>
                    <div className="text-2xl font-bold mt-1">
                      {formatCurrency(confirmedAmount)} افغانی
                    </div>
                  </div>
                  <div>
                    <Label className="text-muted-foreground">جمع پرداخت شده</Label>
                    <div className="text-2xl font-semibold text-green-600 dark:text-green-400 mt-1">
                      {formatCurrency(totalPaid)} افغانی
                    </div>
                  </div>
                  <div>
                    <Label className="text-muted-foreground">مانده باقی‌مانده</Label>
                    <div className={`text-2xl font-bold mt-1 ${remainingBalance > 0 ? 'text-destructive' : 'text-green-600 dark:text-green-400'}`}>
                      {formatCurrency(remainingBalance)} افغانی
                    </div>
                  </div>
                  <div>
                    <Label className="text-muted-foreground">وضعیت بررسی (اطلاعاتی)</Label>
                    <div className="mt-1">
                      <StatusBadge status={caseData?.status || ''} />
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Record New Payment Form */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">ثبت پرداخت جدید</CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmitPayment} className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="payment_date">تاریخ پرداخت *</Label>
                      <ShamsiDatePickerDDMMYYYY
                        value={paymentForm.payment_date}
                        onChange={(date) => setPaymentForm({ ...paymentForm, payment_date: date })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="payment_amount">مبلغ پرداخت (افغانی) *</Label>
                      <Input
                        id="payment_amount"
                        type="number"
                        step="0.01"
                        value={paymentForm.payment_amount}
                        onChange={(e) => setPaymentForm({ ...paymentForm, payment_amount: e.target.value })}
                        className="text-right"
                        dir="ltr"
                        placeholder="0.00"
                        required
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="payment_type">نوع پرداخت *</Label>
                    <Select
                      value={paymentForm.payment_type}
                      onValueChange={(value: 'normal' | 'installment') =>
                        setPaymentForm({ ...paymentForm, payment_type: value })
                      }
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="normal">پرداخت عادی</SelectItem>
                        <SelectItem value="installment">پرداخت قسط</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="notes">یادداشت (اختیاری)</Label>
                    <Textarea
                      id="notes"
                      value={paymentForm.notes}
                      onChange={(e) => setPaymentForm({ ...paymentForm, notes: e.target.value })}
                      className="text-right"
                      dir="rtl"
                      placeholder="یادداشت اضافی..."
                      rows={3}
                    />
                  </div>
                  <Button
                    type="submit"
                    disabled={recordPaymentMutation.isPending}
                    className="w-full"
                  >
                    {recordPaymentMutation.isPending ? (
                      <>
                        <Loader2 className="h-4 w-4 ml-2 animate-spin" />
                        در حال ثبت...
                      </>
                    ) : (
                      <>
                        <CheckCircle className="h-4 w-4 ml-2" />
                        ثبت پرداخت
                      </>
                    )}
                  </Button>
                </form>
              </CardContent>
            </Card>

            {/* Payment History */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <FileText className="h-5 w-5" />
                  تاریخچه پرداخت‌ها
                </CardTitle>
              </CardHeader>
              <CardContent>
                {paymentHistoryWithBalance.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    هیچ پرداختی ثبت نشده است
                  </div>
                ) : (
                  <div className="space-y-3">
                    {paymentHistoryWithBalance.map((payment) => (
                      <div
                        key={payment.id}
                        className="border rounded-lg p-4 space-y-2"
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <Calendar className="h-4 w-4 text-muted-foreground" />
                            <span className="font-medium">
                              {formatDate(payment.paymentDate)}
                            </span>
                            <Badge variant={payment.paymentType === 'installment' ? 'secondary' : 'default'}>
                              {payment.paymentType === 'installment' ? 'قسط' : 'عادی'}
                            </Badge>
                          </div>
                          <div className="text-lg font-bold">
                            {formatCurrency(payment.amount)} افغانی
                          </div>
                        </div>
                        <div className="grid grid-cols-2 gap-4 text-sm text-muted-foreground">
                          <div>
                            مانده قبل از پرداخت: {formatCurrency(payment.balanceBefore)} افغانی
                          </div>
                          <div>
                            مانده بعد از پرداخت: {formatCurrency(payment.balanceAfter)} افغانی
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        )}

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            بستن
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

