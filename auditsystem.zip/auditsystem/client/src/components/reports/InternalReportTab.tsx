/**
 * Internal Report Tab
 * Internal reporting feature with data from completed case report forms
 * Preview matches Ministry report layout style
 */

import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { FileSpreadsheet, Eye } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useQuery } from '@tanstack/react-query';
import { userHasPermission } from '@/utils/permissions';
import InternalReportPeriodSelector, { 
  type ReportType, 
  getQuarterMonths, 
  getQuarterLabel,
} from './InternalReportPeriodSelector';
import jalaali from 'jalaali-js';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

interface InternalReportTabProps {
  user: any;
}

interface InternalReportRow {
  companyName: string;
  tin: string;
  businessNature: string | null;
  groupReferrer: string;
  periodsUnderReview: string;
  capitalPeriod: string | null;
  salaryTax: string | number | null;
  rentTax: string | number | null;
  contractTax: string | number | null;
  profitTransactionTax: string | number | null;
  incomeTax: string | number | null;
  reducedLoss: string | number | null;
  reducedRemainingAmount: string | number | null;
  confirmedAmount: string | number | null;
  collectedCurrentMonth: string | number | null;
  remainingCollectible: string | number | null;
  activityStatus: string | null;
  attachmentNumber: string | null;
  attachmentDate: string | null;
  groupId: string;
  groupName: string;
  caseId: string;
}

export default function InternalReportTab({ user }: InternalReportTabProps) {
  const { toast } = useToast();
  
  // Check access: Director, System Admin, or Coordinator
  const isDirector = user?.role === 'director';
  const isSystemAdmin = user?.role === 'system_admin';
  const isCoordinator = user?.permissionPackages && 
    Array.isArray(user.permissionPackages) && 
    user.permissionPackages.includes('acting_coordinator');
  
  const hasAccess = isDirector || isSystemAdmin || isCoordinator;
  
  // Get current Shamsi date
  const currentShamsi = jalaali.toJalaali(new Date());
  const [reportType, setReportType] = useState<ReportType>('monthly');
  const [year, setYear] = useState<string>(currentShamsi.jy.toString());
  const [month, setMonth] = useState<string | null>(currentShamsi.jm.toString());
  const [quarter, setQuarter] = useState<string | null>(null);
  const [selectedGroupId, setSelectedGroupId] = useState<string>('all');
  const [reportData, setReportData] = useState<InternalReportRow[]>([]);
  const [totals, setTotals] = useState<{
    salaryTax: number;
    rentTax: number;
    contractTax: number;
    profitTransactionTax: number;
    incomeTax: number;
    reducedLoss: number;
    reducedRemainingAmount: number;
    confirmedAmount: number;
    collectedCurrentMonth: number;
    remainingCollectible: number;
  } | null>(null);
  const [isExporting, setIsExporting] = useState(false);
  const [isAllGroups, setIsAllGroups] = useState(false);
  const [activeSubTab, setActiveSubTab] = useState<'performance' | 'tax-installment' | 'law-enforcement'>('performance');
  
  // Fetch groups
  const { data: groups = [] } = useQuery({
    queryKey: ['groups'],
    queryFn: async () => {
      const response = await fetch('/api/groups', { credentials: 'include' });
      if (!response.ok) throw new Error('Failed to fetch groups');
      return response.json();
    },
  });
  
  // Validation: Year is required, Month is required for Monthly, Quarter is required for 3-Month
  const isValid = year && (
    reportType === 'monthly' ? month : 
    reportType === '3-month' ? quarter : 
    reportType === 'yearly'
  );
  
  // Fetch internal report data
  const { refetch, isLoading } = useQuery({
    queryKey: ['internal-report', reportType, year, month, quarter, selectedGroupId === 'all' ? '' : selectedGroupId],
    queryFn: async () => {
      if (!isValid) {
        throw new Error('لطفاً تمام فیلدهای الزامی را پر کنید');
      }
      
      const actualGroupId = selectedGroupId === 'all' || !selectedGroupId ? '' : selectedGroupId;
      
      // Build URL based on report type
      let url = `/api/reports/internal?reportType=${reportType}&year=${year}`;
      if (reportType === 'monthly' && month) {
        url += `&month=${month}`;
      } else if (reportType === '3-month' && quarter) {
        url += `&quarter=${quarter}`;
      }
      // Yearly reports don't need additional parameters
      if (actualGroupId) {
        url += `&groupId=${actualGroupId}`;
      }
      
      const response = await fetch(url, {
        credentials: 'include',
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to fetch internal report');
      }
      const data = await response.json();
      
      // Debug logging
      console.log('Internal report data received:', data);
      
      // Update state with the fetched data
      if (data.allGroups) {
        // All groups report
        setIsAllGroups(true);
        // Flatten all groups data into single array for preview
        const allRows: InternalReportRow[] = [];
        for (const [groupId, rows] of Object.entries(data.data || {})) {
          if (Array.isArray(rows)) {
            allRows.push(...(rows as InternalReportRow[]));
          }
        }
        console.log('All groups rows:', allRows);
        setReportData(allRows);
        setTotals(data.totals || null);
        
        // Show success message
        if (allRows.length > 0) {
          toast({
            title: 'موفق',
            description: `گزارش با ${allRows.length} ردیف بارگذاری شد`,
          });
        } else {
          toast({
            title: 'اطلاع',
            description: 'هیچ داده‌ای برای نمایش وجود ندارد',
            variant: 'default',
          });
        }
      } else {
        // Single group report
        setIsAllGroups(false);
        const reportRows = Array.isArray(data.data) ? data.data : [];
        console.log('Single group rows:', reportRows);
        setReportData(reportRows);
        setTotals(data.totals || null);
        
        // Show success message
        if (reportRows.length > 0) {
          toast({
            title: 'موفق',
            description: `گزارش با ${reportRows.length} ردیف بارگذاری شد`,
          });
        } else {
          toast({
            title: 'اطلاع',
            description: 'هیچ داده‌ای برای نمایش وجود ندارد',
            variant: 'default',
          });
        }
      }
      
      return data;
    },
    enabled: false, // Manual fetch
    onError: (error: any) => {
      toast({
        title: 'خطا',
        description: error.message || 'خطا در دریافت گزارش',
        variant: 'destructive',
      });
    },
  });
  
  const handleExport = async () => {
    if (!isValid) {
      toast({
        title: 'خطا',
        description: 'لطفاً تمام فیلدهای الزامی را پر کنید',
        variant: 'destructive',
      });
      return;
    }
    
    setIsExporting(true);
    try {
      const actualGroupId = selectedGroupId === 'all' || !selectedGroupId ? '' : selectedGroupId;
      
      // Build URL based on report type
      let url = `/api/reports/internal/export?reportType=${reportType}&year=${year}`;
      if (reportType === 'monthly' && month) {
        url += `&month=${month}`;
      } else if (reportType === '3-month' && quarter) {
        url += `&quarter=${quarter}`;
      }
      // Yearly reports don't need additional parameters
      if (actualGroupId) {
        url += `&groupId=${actualGroupId}`;
      }
      
      const response = await fetch(url, {
        credentials: 'include',
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to export');
      }
      
      const contentDisposition = response.headers.get('Content-Disposition');
      let filename = `internal-report-${year}`;
      if (reportType === 'monthly' && month) {
        filename += `-month-${month}`;
      } else if (reportType === '3-month' && quarter) {
        filename += `-quarter-${quarter}`;
      } else {
        filename += '-yearly';
      }
      filename += '.xlsx';
      if (contentDisposition) {
        const filenameMatch = contentDisposition.match(/filename="?(.+)"?/);
        if (filenameMatch) {
          filename = filenameMatch[1];
        }
      }
      
      const blob = await response.blob();
      const url_blob = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url_blob;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url_blob);
      document.body.removeChild(a);
      
      toast({
        title: 'موفق',
        description: 'گزارش با موفقیت دانلود شد',
      });
    } catch (error: any) {
      toast({
        title: 'خطا',
        description: error.message || 'خطا در دانلود گزارش',
        variant: 'destructive',
      });
    } finally {
      setIsExporting(false);
    }
  };
  
  const canExport = hasAccess;
  
  // Get period display text
  const getPeriodDisplay = () => {
    if (reportType === 'monthly' && month) {
      const monthNames = ['', 'حمل', 'ثور', 'جوزا', 'سرطان', 'اسد', 'سنبله', 'میزان', 'عقرب', 'قوس', 'جدی', 'دلو', 'حوت'];
      return `برج ${monthNames[parseInt(month)]} سال مالی ${year}`;
    } else if (reportType === 'yearly') {
      return `سال مالی ${year}`;
    } else if (reportType === '3-month' && quarter) {
      return `${getQuarterLabel(quarter)} سال مالی ${year}`;
    }
    return '';
  };
  
  // Format numeric values for display
  const formatValue = (value: string | number | null): string => {
    if (value === null || value === undefined) return '';
    if (typeof value === 'number') {
      return value.toLocaleString('fa-IR');
    }
    const num = parseFloat(String(value));
    if (!isNaN(num)) {
      return num.toLocaleString('fa-IR');
    }
    return String(value);
  };
  
  // Show access denied message if user doesn't have access
  if (!hasAccess) {
    return (
      <div className="space-y-6" dir="rtl">
        <Card>
          <CardHeader>
            <CardTitle>دسترسی محدود</CardTitle>
            <CardDescription>
              شما دسترسی به این بخش را ندارید. فقط مدیر، مدیر سیستم و هماهنگ‌کننده می‌توانند به گزارشات داخلی دسترسی داشته باشند.
            </CardDescription>
          </CardHeader>
        </Card>
      </div>
    );
  }
  
  return (
    <div className="space-y-6" dir="rtl">
      {/* Period Selector */}
      <InternalReportPeriodSelector
        reportType={reportType}
        year={year}
        month={month}
        quarter={quarter}
        onReportTypeChange={setReportType}
        onYearChange={setYear}
        onMonthChange={setMonth}
        onQuarterChange={setQuarter}
      />
      
      {/* Group Selector */}
      <Card>
        <CardHeader>
          <CardTitle>انتخاب گروه</CardTitle>
          <CardDescription>
            برای مشاهده گزارش یک گروه خاص، آن را انتخاب کنید. برای مشاهده همه گروه‌ها، هیچ گروهی انتخاب نکنید.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Select 
            value={selectedGroupId} 
            onValueChange={(value) => setSelectedGroupId(value)}
          >
            <SelectTrigger className="w-full max-w-md">
              <SelectValue placeholder="همه گروه‌ها" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">همه گروه‌ها</SelectItem>
              {groups.map((group: any) => (
                <SelectItem key={group.id} value={group.id}>
                  {group.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </CardContent>
      </Card>

      {/* Sub-tabs for different report types */}
      <Tabs value={activeSubTab} onValueChange={(v) => setActiveSubTab(v as any)} className="w-full" dir="rtl">
        <TabsList className="grid w-full grid-cols-3" dir="rtl">
          <TabsTrigger value="performance">خلاصه عملکرد</TabsTrigger>
          <TabsTrigger value="tax-installment">قضایای اقساط</TabsTrigger>
          <TabsTrigger value="law-enforcement">قضایای تنفیذ قانون</TabsTrigger>
        </TabsList>

        {/* Performance Summary Tab */}
        <TabsContent value="performance" className="space-y-4">
          {/* Actions */}
          <div className="flex gap-2" dir="rtl">
            <Button
              onClick={async () => {
                if (!isValid) {
                  toast({
                    title: 'خطا',
                    description: 'لطفاً تمام فیلدهای الزامی را پر کنید',
                    variant: 'destructive',
                  });
                  return;
                }
                try {
                  await refetch();
                } catch (error) {
                  // Error is already handled in onError
                }
              }}
              disabled={isLoading || !isValid}
            >
              <Eye className="mr-2 h-4 w-4" />
              {isLoading ? 'در حال بارگذاری...' : 'مشاهده گزارش'}
            </Button>
            {canExport && (
              <Button
                onClick={handleExport}
                disabled={isExporting || !isValid || reportData.length === 0}
                variant="outline"
              >
                <FileSpreadsheet className="mr-2 h-4 w-4" />
                {isExporting ? 'در حال دانلود...' : 'دریافت فایل اکسل'}
              </Button>
            )}
          </div>

          {/* Report Preview */}
      {isLoading && (
        <Card>
          <CardContent className="py-8">
            <div className="text-center text-muted-foreground">
              در حال بارگذاری گزارش...
            </div>
          </CardContent>
        </Card>
      )}
      
      {!isLoading && reportData.length === 0 && (
        <Card>
          <CardHeader>
            <CardTitle>گزارش داخلی</CardTitle>
          </CardHeader>
          <CardContent className="py-8">
            <div className="text-center text-muted-foreground space-y-2">
              <p className="font-medium">هیچ داده‌ای برای نمایش وجود ندارد.</p>
              <p className="text-sm">هیچ پرونده تکمیل شده‌ای با گزارش کامل برای {getPeriodDisplay()} یافت نشد.</p>
              <div className="mt-4 p-4 bg-muted rounded-lg text-right text-sm space-y-1">
                <p className="font-semibold">توجه:</p>
                <p>• فقط پرونده‌های با وضعیت "تکمیل شده" در این گزارش نمایش داده می‌شوند</p>
                <p>• پرونده باید دارای گزارش کامل (case report) باشد</p>
                <p>• تاریخ تکمیل پرونده باید در برج و سال انتخاب شده باشد</p>
                {selectedGroupId !== 'all' && (
                  <p>• فقط پرونده‌های گروه انتخاب شده نمایش داده می‌شوند</p>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      )}
      
      {!isLoading && reportData.length > 0 && (
        <Card key={`report-${reportData.length}-${selectedGroupId}`}>
          <CardHeader>
            <CardTitle className="text-xl font-bold">
              گزارش ماهوار مدیریت عمومی بررسی گروپ {selectedGroupId !== 'all' ? `(${groups.find((g: any) => g.id === selectedGroupId)?.name || selectedGroupId})` : '(همه گروه‌ها)'} بابت {getPeriodDisplay()}
            </CardTitle>
            <CardDescription>
              تعداد ردیف‌ها: {reportData.length}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-8">
              {/* Section 1: مشخصات نهاد */}
              <div>
                <h3 className="text-lg font-semibold mb-4 text-gray-700">بخش اول - مشخصات نهاد</h3>
                <div className="overflow-x-auto border rounded-lg" dir="rtl">
                  <Table>
                    <TableHeader>
                      <TableRow className="bg-gray-200 hover:bg-gray-200">
                        <TableHead className="text-right font-bold h-12">نام نهاد</TableHead>
                        <TableHead className="text-right font-bold h-12">نمبر تشخیصیه</TableHead>
                        <TableHead className="text-right font-bold h-12">نوع تشبث</TableHead>
                        <TableHead className="text-right font-bold h-12">آمریت ارجاع کننده</TableHead>
                        <TableHead className="text-right font-bold h-12">سالهای بررسی</TableHead>
                        <TableHead className="text-right font-bold h-12">دوران سرمایه</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {reportData.map((row, idx) => (
                        <TableRow key={`section1-${row.caseId}-${idx}`} className="hover:bg-gray-50">
                          <TableCell className="text-right py-3">{row.companyName}</TableCell>
                          <TableCell className="text-right py-3">{row.tin}</TableCell>
                          <TableCell className="text-right py-3">{row.businessNature || ''}</TableCell>
                          <TableCell className="text-right py-3">{row.groupReferrer}</TableCell>
                          <TableCell className="text-right py-3">{row.periodsUnderReview}</TableCell>
                          <TableCell className="text-right py-3">{row.capitalPeriod || ''}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </div>
              
              {/* Section 2: بیرون‌نویسی‌ها */}
              <div>
                <h3 className="text-lg font-semibold mb-4 text-gray-700">بخش دوم - بیرون‌نویسی‌ها</h3>
                <div className="overflow-x-auto border rounded-lg" dir="rtl">
                  <Table>
                    <TableHeader>
                      <TableRow className="bg-gray-200 hover:bg-gray-200">
                        <TableHead className="text-right font-bold h-12">نام نهاد</TableHead>
                        <TableHead className="text-right font-bold h-12">مالیه موضوعی معاشات</TableHead>
                        <TableHead className="text-right font-bold h-12">مالیه موضوعی بر کرایه</TableHead>
                        <TableHead className="text-right font-bold h-12">مالیه موضوعی قراردادی</TableHead>
                        <TableHead className="text-right font-bold h-12">مالیات معاملات انتفاعی</TableHead>
                        <TableHead className="text-right font-bold h-12">مالیات بر عایدات</TableHead>
                        <TableHead className="text-right font-bold h-12">ضرر کاهش یافته</TableHead>
                        <TableHead className="text-right font-bold h-12">مبلغ فاضل تحویل کاهش یافته</TableHead>
                        <TableHead className="text-right font-bold h-12">مبلغ تثبیت شده</TableHead>
                        <TableHead className="text-right font-bold h-12">مبلغ تحصیل شده طی برج جاری</TableHead>
                        <TableHead className="text-right font-bold h-12">الباقی مبلغ قابل تحصیل</TableHead>
                        <TableHead className="text-right font-bold h-12">وضعیت فعالیت</TableHead>
                        <TableHead className="text-right font-bold h-12">نمبر آویز</TableHead>
                        <TableHead className="text-right font-bold h-12">تاریخ آویز</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {reportData.map((row, idx) => (
                        <TableRow key={`section2-${row.caseId}-${idx}`} className="hover:bg-gray-50">
                          <TableCell className="text-right py-3">{row.companyName}</TableCell>
                          <TableCell className="text-right py-3">{formatValue(row.salaryTax)}</TableCell>
                          <TableCell className="text-right py-3">{formatValue(row.rentTax)}</TableCell>
                          <TableCell className="text-right py-3">{formatValue(row.contractTax)}</TableCell>
                          <TableCell className="text-right py-3">{formatValue(row.profitTransactionTax)}</TableCell>
                          <TableCell className="text-right py-3">{formatValue(row.incomeTax)}</TableCell>
                          <TableCell className="text-right py-3">{formatValue(row.reducedLoss)}</TableCell>
                          <TableCell className="text-right py-3">{formatValue(row.reducedRemainingAmount)}</TableCell>
                          <TableCell className="text-right py-3">{formatValue(row.confirmedAmount)}</TableCell>
                          <TableCell className="text-right py-3">{formatValue(row.collectedCurrentMonth)}</TableCell>
                          <TableCell className="text-right py-3">{formatValue(row.remainingCollectible)}</TableCell>
                          <TableCell className="text-right py-3">{row.activityStatus || ''}</TableCell>
                          <TableCell className="text-right py-3">{row.attachmentNumber || ''}</TableCell>
                          <TableCell className="text-right py-3">{row.attachmentDate || ''}</TableCell>
                        </TableRow>
                      ))}
                      {totals && (
                        <TableRow className="bg-gray-300 hover:bg-gray-300 font-bold">
                          <TableCell className="text-right py-3 font-bold">مجموع کل</TableCell>
                          <TableCell className="text-right py-3 font-bold">{formatValue(totals.salaryTax)}</TableCell>
                          <TableCell className="text-right py-3 font-bold">{formatValue(totals.rentTax)}</TableCell>
                          <TableCell className="text-right py-3 font-bold">{formatValue(totals.contractTax)}</TableCell>
                          <TableCell className="text-right py-3 font-bold">{formatValue(totals.profitTransactionTax)}</TableCell>
                          <TableCell className="text-right py-3 font-bold">{formatValue(totals.incomeTax)}</TableCell>
                          <TableCell className="text-right py-3 font-bold">{formatValue(totals.reducedLoss)}</TableCell>
                          <TableCell className="text-right py-3 font-bold">{formatValue(totals.reducedRemainingAmount)}</TableCell>
                          <TableCell className="text-right py-3 font-bold">{formatValue(totals.confirmedAmount)}</TableCell>
                          <TableCell className="text-right py-3 font-bold">{formatValue(totals.collectedCurrentMonth)}</TableCell>
                          <TableCell className="text-right py-3 font-bold">{formatValue(totals.remainingCollectible)}</TableCell>
                          <TableCell className="text-right py-3"></TableCell>
                          <TableCell className="text-right py-3"></TableCell>
                          <TableCell className="text-right py-3"></TableCell>
                        </TableRow>
                      )}
                    </TableBody>
                  </Table>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
        </TabsContent>

        {/* Tax Installment Report Tab */}
        <TabsContent value="tax-installment" className="space-y-4">
          <TaxInstallmentReportSection
            reportType={reportType}
            year={year}
            month={month}
            quarter={quarter}
            selectedGroupId={selectedGroupId}
            isValid={isValid}
            user={user}
          />
        </TabsContent>

        {/* Law Enforcement Report Tab */}
        <TabsContent value="law-enforcement" className="space-y-4">
          <LawEnforcementReportSection
            reportType={reportType}
            year={year}
            month={month}
            quarter={quarter}
            selectedGroupId={selectedGroupId}
            isValid={isValid}
            user={user}
          />
        </TabsContent>
      </Tabs>
    </div>
  );
}

// Tax Installment Report Section Component
function TaxInstallmentReportSection({
  reportType,
  year,
  month,
  quarter,
  selectedGroupId,
  isValid,
  user,
}: {
  reportType: ReportType;
  year: string;
  month: string | null;
  quarter: string | null;
  selectedGroupId: string;
  isValid: boolean;
  user: any;
}) {
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const [reportData, setReportData] = useState<any>(null);

  const fetchReport = async () => {
    if (!isValid) {
      toast({
        title: 'خطا',
        description: 'لطفاً تمام فیلدهای الزامی را پر کنید',
        variant: 'destructive',
      });
      return;
    }

    setIsLoading(true);
    try {
      let url = `/api/reports/tax-installment-law-enforcement?reportType=${reportType}&year=${year}`;
      if (reportType === 'monthly' && month) {
        url += `&month=${month}`;
      } else if (reportType === '3-month' && quarter) {
        url += `&quarter=${quarter}`;
      }
      if (selectedGroupId !== 'all') {
        url += `&groupId=${selectedGroupId}`;
      }

      const response = await fetch(url, { credentials: 'include' });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to fetch report');
      }
      const data = await response.json();
      setReportData(data);
    } catch (error: any) {
      toast({
        title: 'خطا',
        description: error.message || 'خطا در دریافت گزارش',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleExport = async () => {
    if (!isValid) {
      toast({
        title: 'خطا',
        description: 'لطفاً تمام فیلدهای الزامی را پر کنید',
        variant: 'destructive',
      });
      return;
    }

    setIsExporting(true);
    try {
      let url = `/api/reports/tax-installment-law-enforcement/export?reportType=${reportType}&year=${year}`;
      if (reportType === 'monthly' && month) {
        url += `&month=${month}`;
      } else if (reportType === '3-month' && quarter) {
        url += `&quarter=${quarter}`;
      }
      if (selectedGroupId !== 'all') {
        url += `&groupId=${selectedGroupId}`;
      }

      const response = await fetch(url, { credentials: 'include' });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to export');
      }

      const blob = await response.blob();
      const url_blob = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url_blob;
      a.download = `tax-installment-report-${year}.xlsx`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url_blob);
      document.body.removeChild(a);

      toast({
        title: 'موفق',
        description: 'گزارش با موفقیت دانلود شد',
      });
    } catch (error: any) {
      toast({
        title: 'خطا',
        description: error.message || 'خطا در دانلود گزارش',
        variant: 'destructive',
      });
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <div className="space-y-4" dir="rtl">
      <div className="flex gap-2" dir="rtl">
        <Button onClick={fetchReport} disabled={isLoading || !isValid}>
          <Eye className="mr-2 h-4 w-4" />
          {isLoading ? 'در حال بارگذاری...' : 'مشاهده گزارش'}
        </Button>
        <Button
          onClick={handleExport}
          disabled={isExporting || !isValid || !reportData}
          variant="outline"
        >
          <FileSpreadsheet className="mr-2 h-4 w-4" />
          {isExporting ? 'در حال دانلود...' : 'دریافت فایل اکسل'}
        </Button>
      </div>

      {isLoading && (
        <Card>
          <CardContent className="py-8">
            <div className="text-center text-muted-foreground">در حال بارگذاری گزارش...</div>
          </CardContent>
        </Card>
      )}

      {!isLoading && reportData && (
        <Card>
          <CardHeader>
            <CardTitle>گزارش قضایای اقساط</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 bg-muted rounded-lg">
                  <div className="text-sm text-muted-foreground">کل قضایا</div>
                  <div className="text-2xl font-bold">{reportData.summary?.totalInstallmentCases || 0}</div>
                </div>
                <div className="p-4 bg-muted rounded-lg">
                  <div className="text-sm text-muted-foreground">تکمیل شده</div>
                  <div className="text-2xl font-bold">{reportData.summary?.completedInstallmentCases || 0}</div>
                </div>
                <div className="p-4 bg-muted rounded-lg">
                  <div className="text-sm text-muted-foreground">در انتظار</div>
                  <div className="text-2xl font-bold">{reportData.summary?.pendingInstallmentCases || 0}</div>
                </div>
                <div className="p-4 bg-muted rounded-lg">
                  <div className="text-sm text-muted-foreground">مبلغ تثبیت شده</div>
                  <div className="text-2xl font-bold">
                    {(reportData.summary?.totalInstallmentAmountFixed || 0).toLocaleString('fa-IR')}
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

// Law Enforcement Report Section Component
function LawEnforcementReportSection({
  reportType,
  year,
  month,
  quarter,
  selectedGroupId,
  isValid,
  user,
}: {
  reportType: ReportType;
  year: string;
  month: string | null;
  quarter: string | null;
  selectedGroupId: string;
  isValid: boolean;
  user: any;
}) {
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const [reportData, setReportData] = useState<any>(null);

  const fetchReport = async () => {
    if (!isValid) {
      toast({
        title: 'خطا',
        description: 'لطفاً تمام فیلدهای الزامی را پر کنید',
        variant: 'destructive',
      });
      return;
    }

    setIsLoading(true);
    try {
      let url = `/api/reports/tax-installment-law-enforcement?reportType=${reportType}&year=${year}`;
      if (reportType === 'monthly' && month) {
        url += `&month=${month}`;
      } else if (reportType === '3-month' && quarter) {
        url += `&quarter=${quarter}`;
      }
      if (selectedGroupId !== 'all') {
        url += `&groupId=${selectedGroupId}`;
      }

      const response = await fetch(url, { credentials: 'include' });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to fetch report');
      }
      const data = await response.json();
      setReportData(data);
    } catch (error: any) {
      toast({
        title: 'خطا',
        description: error.message || 'خطا در دریافت گزارش',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleExport = async () => {
    if (!isValid) {
      toast({
        title: 'خطا',
        description: 'لطفاً تمام فیلدهای الزامی را پر کنید',
        variant: 'destructive',
      });
      return;
    }

    setIsExporting(true);
    try {
      let url = `/api/reports/tax-installment-law-enforcement/export?reportType=${reportType}&year=${year}`;
      if (reportType === 'monthly' && month) {
        url += `&month=${month}`;
      } else if (reportType === '3-month' && quarter) {
        url += `&quarter=${quarter}`;
      }
      if (selectedGroupId !== 'all') {
        url += `&groupId=${selectedGroupId}`;
      }

      const response = await fetch(url, { credentials: 'include' });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to export');
      }

      const blob = await response.blob();
      const url_blob = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url_blob;
      a.download = `law-enforcement-report-${year}.xlsx`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url_blob);
      document.body.removeChild(a);

      toast({
        title: 'موفق',
        description: 'گزارش با موفقیت دانلود شد',
      });
    } catch (error: any) {
      toast({
        title: 'خطا',
        description: error.message || 'خطا در دانلود گزارش',
        variant: 'destructive',
      });
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <div className="space-y-4" dir="rtl">
      <div className="flex gap-2" dir="rtl">
        <Button onClick={fetchReport} disabled={isLoading || !isValid}>
          <Eye className="mr-2 h-4 w-4" />
          {isLoading ? 'در حال بارگذاری...' : 'مشاهده گزارش'}
        </Button>
        <Button
          onClick={handleExport}
          disabled={isExporting || !isValid || !reportData}
          variant="outline"
        >
          <FileSpreadsheet className="mr-2 h-4 w-4" />
          {isExporting ? 'در حال دانلود...' : 'دریافت فایل اکسل'}
        </Button>
      </div>

      {isLoading && (
        <Card>
          <CardContent className="py-8">
            <div className="text-center text-muted-foreground">در حال بارگذاری گزارش...</div>
          </CardContent>
        </Card>
      )}

      {!isLoading && reportData && (
        <Card>
          <CardHeader>
            <CardTitle>گزارش قضایای تنفیذ قانون</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 bg-muted rounded-lg">
                  <div className="text-sm text-muted-foreground">کل قضایا</div>
                  <div className="text-2xl font-bold">{reportData.summary?.totalLawEnforcementCases || 0}</div>
                </div>
                <div className="p-4 bg-muted rounded-lg">
                  <div className="text-sm text-muted-foreground">تکمیل شده</div>
                  <div className="text-2xl font-bold">{reportData.summary?.completedLawEnforcementCases || 0}</div>
                </div>
                <div className="p-4 bg-muted rounded-lg">
                  <div className="text-sm text-muted-foreground">در انتظار</div>
                  <div className="text-2xl font-bold">{reportData.summary?.pendingLawEnforcementCases || 0}</div>
                </div>
                <div className="p-4 bg-muted rounded-lg">
                  <div className="text-sm text-muted-foreground">مبلغ تثبیت شده</div>
                  <div className="text-2xl font-bold">
                    {(reportData.summary?.totalLawEnforcementAmountFixed || 0).toLocaleString('fa-IR')}
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

