/**
 * Monthly Group Report Tab
 * Displays monthly aggregated KPIs per group with breakdown and manual override capabilities
 */

import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { 
  FileSpreadsheet, 
  Calculator, 
  AlertTriangle, 
  CheckCircle, 
  Eye,
  Edit,
  Download,
  Settings
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { userHasPermission } from '@/utils/permissions';
import type { Group, User } from '@shared/schema';
import jalaali from 'jalaali-js';

// Afghan months: حمل، ثور، جوزا، سرطان، اسد، سنبله، میزان، عقرب، قوس، جدی، دلو، حوت
const AFGHAN_MONTHS = [
  { value: 1, label: 'حمل' },
  { value: 2, label: 'ثور' },
  { value: 3, label: 'جوزا' },
  { value: 4, label: 'سرطان' },
  { value: 5, label: 'اسد' },
  { value: 6, label: 'سنبله' },
  { value: 7, label: 'میزان' },
  { value: 8, label: 'عقرب' },
  { value: 9, label: 'قوس' },
  { value: 10, label: 'جدی' },
  { value: 11, label: 'دلو' },
  { value: 12, label: 'حوت' },
];

interface MonthlyGroupReportTabProps {
  user: User | null;
  groups: Group[];
}

interface MonthlyReportBreakdown {
  report: {
    id: string;
    groupId: string;
    monthNumber: number;
    yearNumber: number;
    distributedCount: number;
    finalizedCount: number;
    underReviewCount: number;
    collectedAmount: string;
    installmentsCount: number;
    nonresponsiveCount: number;
    percentOfTarget: string | null;
    monthlyTaxTarget?: string | null;
  };
  distributedCases: Array<{ id: string; caseId: string; companyName: string; createdAt: Date }>;
  finalizedCases: Array<{ id: string; caseId: string; companyName: string; completedAt: Date; collectedAmount: number }>;
  installmentPayments: Array<{ id: string; caseId: string; amountPaid: number; paymentDate: Date }>;
  nonresponsiveCases: Array<{ id: string; caseId: string; companyName: string; transitionedAt: Date }>;
  anomalies: Array<{
    id: string;
    anomalyType: string;
    severity: string;
    description: string;
    resolved: boolean;
  }>;
}

export default function MonthlyGroupReportTab({ user, groups }: MonthlyGroupReportTabProps) {
  const [selectedGroupId, setSelectedGroupId] = useState<string>('');
  const [selectedMonth, setSelectedMonth] = useState<number>(() => {
    const now = new Date();
    const shamsi = jalaali.toJalaali(now);
    return shamsi.jm; // Current month
  });
  const [selectedYear, setSelectedYear] = useState<number>(() => {
    const now = new Date();
    const shamsi = jalaali.toJalaali(now);
    return shamsi.jy; // Current year
  });
  const [breakdownDialogOpen, setBreakdownDialogOpen] = useState(false);
  const [overrideDialogOpen, setOverrideDialogOpen] = useState(false);
  const [targetDialogOpen, setTargetDialogOpen] = useState(false);
  const [overrideField, setOverrideField] = useState<string>('');
  const [overrideValue, setOverrideValue] = useState<string>('');
  const [overrideReason, setOverrideReason] = useState<string>('');
  const [newTarget, setNewTarget] = useState<string>('');

  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Filter groups based on user permissions
  const availableGroups = groups.filter(g => {
    if (!user) return false;
    if (user.role === 'system_admin' || user.role === 'director') return true;
    if (user.role === 'senior_auditor' && user.groupId === g.id) return true;
    return false;
  });

  // Fetch monthly report
  const { data: reportData, isLoading, error, refetch } = useQuery<MonthlyReportBreakdown>({
    queryKey: ['monthly-report', selectedGroupId, selectedMonth, selectedYear],
    queryFn: async () => {
      if (!selectedGroupId) throw new Error('Group not selected');
      const response = await fetch(
        `/api/reports/monthly?groupId=${selectedGroupId}&year=${selectedYear}&month=${selectedMonth}`,
        { credentials: 'include' }
      );
      if (!response.ok) {
        if (response.status === 404) {
          return null; // Report not computed yet
        }
        throw new Error('Failed to fetch monthly report');
      }
      return response.json();
    },
    enabled: !!selectedGroupId && !!selectedMonth && !!selectedYear,
  });

  // Compute report mutation
  const computeMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch('/api/reports/monthly/compute', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({
          groupId: selectedGroupId,
          year: selectedYear,
          month: selectedMonth,
        }),
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to compute report');
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['monthly-report', selectedGroupId, selectedMonth, selectedYear] });
      toast({
        title: 'موفقیت',
        description: 'گزارش ماهانه با موفقیت محاسبه شد',
      });
    },
    onError: (error: any) => {
      toast({
        title: 'خطا',
        description: error.message || 'خطا در محاسبه گزارش',
        variant: 'destructive',
      });
    },
  });

  // Manual override mutation
  const overrideMutation = useMutation({
    mutationFn: async ({ field, value, reason }: { field: string; value: string; reason: string }) => {
      if (!reportData?.report?.id) throw new Error('Report not found');
      const response = await fetch(`/api/reports/monthly/${reportData.report.id}/manual-override`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ field, value, reason }),
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to update report');
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['monthly-report', selectedGroupId, selectedMonth, selectedYear] });
      setOverrideDialogOpen(false);
      setOverrideField('');
      setOverrideValue('');
      setOverrideReason('');
      toast({
        title: 'موفقیت',
        description: 'گزارش با موفقیت به‌روزرسانی شد',
      });
    },
    onError: (error: any) => {
      toast({
        title: 'خطا',
        description: error.message || 'خطا در به‌روزرسانی گزارش',
        variant: 'destructive',
      });
    },
  });

  // Update target mutation
  const updateTargetMutation = useMutation({
    mutationFn: async (target: number | null) => {
      const response = await fetch(`/api/reports/monthly/groups/${selectedGroupId}/monthly-tax-target`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ monthlyTaxTarget: target }),
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to update target');
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['groups'] });
      queryClient.invalidateQueries({ queryKey: ['monthly-report', selectedGroupId, selectedMonth, selectedYear] });
      setTargetDialogOpen(false);
      setNewTarget('');
      toast({
        title: 'موفقیت',
        description: 'هدف مالی ماهانه با موفقیت به‌روزرسانی شد',
      });
    },
    onError: (error: any) => {
      toast({
        title: 'خطا',
        description: error.message || 'خطا در به‌روزرسانی هدف',
        variant: 'destructive',
      });
    },
  });

  // Check permissions - using existing permission checks
  const canOverride = user && (user.role === 'system_admin' || user.role === 'director' || 
    (user.permissionPackages && Array.isArray(user.permissionPackages) && user.permissionPackages.includes('acting_coordinator')));
  const canManageGroups = user && (user.role === 'system_admin' || user.role === 'director');
  const canGenerate = user && (user.role === 'system_admin' || user.role === 'director' || 
    (user.permissionPackages && Array.isArray(user.permissionPackages) && user.permissionPackages.includes('acting_coordinator')));

  const handleOverride = () => {
    if (!overrideField || !overrideValue) {
      toast({
        title: 'خطا',
        description: 'لطفاً فیلد و مقدار را وارد کنید',
        variant: 'destructive',
      });
      return;
    }
    overrideMutation.mutate({
      field: overrideField,
      value: overrideValue,
      reason: overrideReason || 'Manual adjustment',
    });
  };

  const handleUpdateTarget = () => {
    const target = newTarget.trim() === '' ? null : parseFloat(newTarget);
    if (target !== null && (isNaN(target) || target < 0)) {
      toast({
        title: 'خطا',
        description: 'مقدار هدف نامعتبر است',
        variant: 'destructive',
      });
      return;
    }
    updateTargetMutation.mutate(target);
  };

  const formatCurrency = (amount: string | number | null) => {
    if (amount === null || amount === undefined) return '0';
    const num = typeof amount === 'string' ? parseFloat(amount) : amount;
    return new Intl.NumberFormat('fa-IR').format(num);
  };

  const formatDate = (date: Date | string) => {
    const d = typeof date === 'string' ? new Date(date) : date;
    const shamsi = jalaali.toJalaali(d);
    return `${String(shamsi.jd).padStart(2, '0')}-${String(shamsi.jm).padStart(2, '0')}-${shamsi.jy}`;
  };

  return (
    <div className="space-y-6" dir="rtl">
      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle>فیلترهای گزارش</CardTitle>
          <CardDescription>گروه، ماه و سال را انتخاب کنید</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <Label>گروه</Label>
              <Select value={selectedGroupId} onValueChange={setSelectedGroupId}>
                <SelectTrigger>
                  <SelectValue placeholder="انتخاب گروه" />
                </SelectTrigger>
                <SelectContent>
                  {availableGroups.map((group) => (
                    <SelectItem key={group.id} value={group.id}>
                      {group.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>ماه</Label>
              <Select value={selectedMonth.toString()} onValueChange={(v) => setSelectedMonth(parseInt(v, 10))}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {AFGHAN_MONTHS.map((month) => (
                    <SelectItem key={month.value} value={month.value.toString()}>
                      {month.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>سال</Label>
              <Input
                type="number"
                value={selectedYear}
                onChange={(e) => setSelectedYear(parseInt(e.target.value, 10) || 1404)}
                min="1300"
                max="1500"
              />
            </div>
            <div className="flex items-end gap-2">
              {canGenerate && (
                <Button
                  onClick={() => computeMutation.mutate()}
                  disabled={!selectedGroupId || computeMutation.isPending}
                  className="flex-1"
                >
                  <Calculator className="ml-2 h-4 w-4" />
                  {computeMutation.isPending ? 'در حال محاسبه...' : 'محاسبه گزارش'}
                </Button>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Report Display */}
      {isLoading && (
        <Card>
          <CardContent className="py-8 text-center text-muted-foreground">
            در حال بارگذاری...
          </CardContent>
        </Card>
      )}

      {error && (
        <Alert variant="destructive">
          <AlertTriangle className="h-4 w-4" />
          <AlertTitle>خطا</AlertTitle>
          <AlertDescription>
            {(error as Error).message || 'خطا در دریافت گزارش'}
          </AlertDescription>
        </Alert>
      )}

      {!isLoading && !error && !reportData && selectedGroupId && (
        <Alert>
          <AlertTriangle className="h-4 w-4" />
          <AlertTitle>گزارش یافت نشد</AlertTitle>
          <AlertDescription>
            گزارش ماهانه برای این گروه و دوره محاسبه نشده است. لطفاً دکمه "محاسبه گزارش" را کلیک کنید.
          </AlertDescription>
        </Alert>
      )}

      {reportData && (
        <>
          {/* Anomalies/Warnings */}
          {reportData.anomalies.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  هشدارها و ناهنجاری‌ها
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {reportData.anomalies.map((anomaly) => (
                    <Alert
                      key={anomaly.id}
                      variant={anomaly.severity === 'error' ? 'destructive' : 'default'}
                    >
                      <AlertTriangle className="h-4 w-4" />
                      <AlertDescription>{anomaly.description}</AlertDescription>
                    </Alert>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Main Report Card */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>گزارش ماهانه گروه</CardTitle>
                  <CardDescription>
                    {groups.find(g => g.id === selectedGroupId)?.name} - {AFGHAN_MONTHS.find(m => m.value === selectedMonth)?.label} {selectedYear}
                  </CardDescription>
                </div>
                <div className="flex gap-2">
                  {canManageGroups && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        const group = groups.find(g => g.id === selectedGroupId);
                        setNewTarget(group?.monthlyTaxTarget || '');
                        setTargetDialogOpen(true);
                      }}
                    >
                      <Settings className="ml-2 h-4 w-4" />
                      تنظیم هدف
                    </Button>
                  )}
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setBreakdownDialogOpen(true)}
                  >
                    <Eye className="ml-2 h-4 w-4" />
                    مشاهده جزئیات
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="space-y-1">
                  <Label className="text-muted-foreground">تعداد نهاد/شرکت های تحت بررسی</Label>
                  <div className="text-2xl font-bold">{reportData.report.underReviewCount}</div>
                  <div className="text-sm text-muted-foreground">
                    توزیع شده: {reportData.report.distributedCount} | نهائی شده: {reportData.report.finalizedCount}
                  </div>
                </div>
                <div className="space-y-1">
                  <Label className="text-muted-foreground">عواید جمع آوری شده</Label>
                  <div className="text-2xl font-bold">{formatCurrency(reportData.report.collectedAmount)} افغانی</div>
                </div>
                <div className="space-y-1">
                  <Label className="text-muted-foreground">فیصدی تنقیص/تزئید</Label>
                  <div className="text-2xl font-bold">
                    {reportData.report.percentOfTarget !== null
                      ? `${parseFloat(reportData.report.percentOfTarget).toFixed(2)}%`
                      : 'تعریف نشده'}
                  </div>
                  {reportData.report.percentOfTarget === null && (
                    <div className="text-sm text-yellow-600">
                      هدف مالی ماهانه تنظیم نشده است
                    </div>
                  )}
                </div>
                <div className="space-y-1">
                  <Label className="text-muted-foreground">قضایای قسط شده</Label>
                  <div className="text-2xl font-bold">{reportData.report.installmentsCount}</div>
                </div>
              </div>

              {canOverride && (
                <div className="mt-6 pt-6 border-t">
                  <Button
                    variant="outline"
                    onClick={() => {
                      setOverrideField('');
                      setOverrideValue('');
                      setOverrideReason('');
                      setOverrideDialogOpen(true);
                    }}
                  >
                    <Edit className="ml-2 h-4 w-4" />
                    ویرایش دستی
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </>
      )}

      {/* Breakdown Dialog */}
      <Dialog open={breakdownDialogOpen} onOpenChange={setBreakdownDialogOpen}>
        <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>جزئیات گزارش ماهانه</DialogTitle>
            <DialogDescription>
              لیست قضایا و پرداخت‌های مؤثر در محاسبه
            </DialogDescription>
          </DialogHeader>
          {reportData && (
            <div className="space-y-6">
              <div>
                <h3 className="font-semibold mb-2">قضایای توزیع شده ({reportData.distributedCases.length})</h3>
                <div className="border rounded-md max-h-40 overflow-y-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>شماره قضیه</TableHead>
                        <TableHead>نام نهاد</TableHead>
                        <TableHead>تاریخ ایجاد</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {reportData.distributedCases.map((c) => (
                        <TableRow key={c.id}>
                          <TableCell>{c.caseId}</TableCell>
                          <TableCell>{c.companyName}</TableCell>
                          <TableCell>{formatDate(c.createdAt)}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </div>

              <div>
                <h3 className="font-semibold mb-2">قضایای نهائی شده ({reportData.finalizedCases.length})</h3>
                <div className="border rounded-md max-h-40 overflow-y-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>شماره قضیه</TableHead>
                        <TableHead>نام نهاد</TableHead>
                        <TableHead>مبلغ جمع آوری شده</TableHead>
                        <TableHead>تاریخ تکمیل</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {reportData.finalizedCases.map((c) => (
                        <TableRow key={c.id}>
                          <TableCell>{c.caseId}</TableCell>
                          <TableCell>{c.companyName}</TableCell>
                          <TableCell>{formatCurrency(c.collectedAmount)}</TableCell>
                          <TableCell>{formatDate(c.completedAt)}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </div>

              <div>
                <h3 className="font-semibold mb-2">پرداخت‌های اقساط ({reportData.installmentPayments.length})</h3>
                <div className="border rounded-md max-h-40 overflow-y-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>شماره قضیه</TableHead>
                        <TableHead>مبلغ</TableHead>
                        <TableHead>تاریخ پرداخت</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {reportData.installmentPayments.map((p) => (
                        <TableRow key={p.id}>
                          <TableCell>{p.caseId}</TableCell>
                          <TableCell>{formatCurrency(p.amountPaid)}</TableCell>
                          <TableCell>{formatDate(p.paymentDate)}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </div>

              {reportData.nonresponsiveCases.length > 0 && (
                <div>
                  <h3 className="font-semibold mb-2">قضایای عدم اطاعت پذیر ({reportData.nonresponsiveCases.length})</h3>
                  <div className="border rounded-md max-h-40 overflow-y-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>شماره قضیه</TableHead>
                          <TableHead>نام نهاد</TableHead>
                          <TableHead>تاریخ ارسال</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {reportData.nonresponsiveCases.map((c) => (
                          <TableRow key={c.id}>
                            <TableCell>{c.caseId}</TableCell>
                            <TableCell>{c.companyName}</TableCell>
                            <TableCell>{formatDate(c.transitionedAt)}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Manual Override Dialog */}
      <Dialog open={overrideDialogOpen} onOpenChange={setOverrideDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>ویرایش دستی گزارش</DialogTitle>
            <DialogDescription>
              تغییر دستی فیلدهای گزارش (با ثبت در سابقه)
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>فیلد</Label>
              <Select value={overrideField} onValueChange={setOverrideField}>
                <SelectTrigger>
                  <SelectValue placeholder="انتخاب فیلد" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="distributedCount">تعداد توزیع شده</SelectItem>
                  <SelectItem value="finalizedCount">تعداد نهائی شده</SelectItem>
                  <SelectItem value="underReviewCount">تعداد تحت بررسی</SelectItem>
                  <SelectItem value="collectedAmount">مبلغ جمع آوری شده</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>مقدار جدید</Label>
              <Input
                type="number"
                value={overrideValue}
                onChange={(e) => setOverrideValue(e.target.value)}
                placeholder="مقدار جدید را وارد کنید"
              />
            </div>
            <div>
              <Label>دلیل تغییر</Label>
              <Textarea
                value={overrideReason}
                onChange={(e) => setOverrideReason(e.target.value)}
                placeholder="دلیل تغییر را توضیح دهید..."
                rows={3}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOverrideDialogOpen(false)}>
              انصراف
            </Button>
            <Button onClick={handleOverride} disabled={overrideMutation.isPending}>
              {overrideMutation.isPending ? 'در حال ذخیره...' : 'ذخیره'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Target Configuration Dialog */}
      <Dialog open={targetDialogOpen} onOpenChange={setTargetDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>تنظیم هدف مالی ماهانه</DialogTitle>
            <DialogDescription>
              هدف مالی ماهانه برای این گروه را تنظیم کنید
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>هدف مالی ماهانه (افغانی)</Label>
              <Input
                type="number"
                value={newTarget}
                onChange={(e) => setNewTarget(e.target.value)}
                placeholder="مقدار هدف را وارد کنید"
                min="0"
              />
              <p className="text-sm text-muted-foreground mt-1">
                برای حذف هدف، فیلد را خالی بگذارید
              </p>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setTargetDialogOpen(false)}>
              انصراف
            </Button>
            <Button onClick={handleUpdateTarget} disabled={updateTargetMutation.isPending}>
              {updateTargetMutation.isPending ? 'در حال ذخیره...' : 'ذخیره'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

