/**
 * Shared Report Filters Component
 * RTL-aligned filter bar for all report types
 */

import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import type { Group, User } from '@shared/schema';

interface ReportFiltersProps {
  month: string;
  year: string;
  onMonthChange: (month: string) => void;
  onYearChange: (year: string) => void;
  groups?: Group[];
  selectedGroupId?: string;
  onGroupChange?: (groupId: string) => void;
  auditors?: User[];
  selectedAuditorId?: string;
  onAuditorChange?: (auditorId: string) => void;
  showGroup?: boolean;
  showAuditor?: boolean;
}

const monthNames = [
  { value: '1', label: 'حمل' },
  { value: '2', label: 'ثور' },
  { value: '3', label: 'جوزا' },
  { value: '4', label: 'سرطان' },
  { value: '5', label: 'اسد' },
  { value: '6', label: 'سنبله' },
  { value: '7', label: 'میزان' },
  { value: '8', label: 'عقرب' },
  { value: '9', label: 'قوس' },
  { value: '10', label: 'جدی' },
  { value: '11', label: 'دلو' },
  { value: '12', label: 'حوت' },
];

export default function ReportFilters({
  month,
  year,
  onMonthChange,
  onYearChange,
  groups = [],
  selectedGroupId,
  onGroupChange,
  auditors = [],
  selectedAuditorId,
  onAuditorChange,
  showGroup = false,
  showAuditor = false,
}: ReportFiltersProps) {
  // Generate year options (current year and 5 previous years)
  // Note: This is a simplified calculation. For accurate Shamsi dates, import jalaali
  const currentShamsi = new Date().getFullYear() - 621;
  const yearOptions = [];
  for (let i = 0; i < 6; i++) {
    yearOptions.push((currentShamsi - i).toString());
  }

  return (
    <div className="flex flex-wrap items-end gap-4 p-4 bg-muted/50 rounded-lg border" dir="rtl">
      <div className="space-y-2 min-w-[120px]">
        <Label htmlFor="filter-month" className="text-sm font-medium">
          ماه (برج)
        </Label>
        <Select value={month} onValueChange={onMonthChange}>
          <SelectTrigger id="filter-month" dir="rtl" className="w-full">
            <SelectValue placeholder="انتخاب ماه" />
          </SelectTrigger>
          <SelectContent dir="rtl">
            {monthNames.map((m) => (
              <SelectItem key={m.value} value={m.value}>
                {m.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2 min-w-[120px]">
        <Label htmlFor="filter-year" className="text-sm font-medium">
          سال مالی (شمسی)
        </Label>
        <Select value={year} onValueChange={onYearChange}>
          <SelectTrigger id="filter-year" dir="rtl" className="w-full">
            <SelectValue placeholder="انتخاب سال" />
          </SelectTrigger>
          <SelectContent dir="rtl">
            {yearOptions.map((y) => (
              <SelectItem key={y} value={y}>
                {y}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {showGroup && onGroupChange && (
        <div className="space-y-2 min-w-[180px]">
          <Label htmlFor="filter-group" className="text-sm font-medium">
            گروه
          </Label>
          <Select
            value={selectedGroupId || 'all'}
            onValueChange={(value) => onGroupChange(value === 'all' ? '' : value)}
          >
            <SelectTrigger id="filter-group" dir="rtl" className="w-full">
              <SelectValue placeholder="همه گروه‌ها" />
            </SelectTrigger>
            <SelectContent dir="rtl">
              <SelectItem value="all">همه گروه‌ها</SelectItem>
              {groups.map((group) => (
                <SelectItem key={group.id} value={group.id}>
                  {group.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      )}

      {showAuditor && onAuditorChange && (
        <div className="space-y-2 min-w-[180px]">
          <Label htmlFor="filter-auditor" className="text-sm font-medium">
            ممیز
          </Label>
          <Select
            value={selectedAuditorId || 'all'}
            onValueChange={(value) => onAuditorChange(value === 'all' ? '' : value)}
          >
            <SelectTrigger id="filter-auditor" dir="rtl" className="w-full">
              <SelectValue placeholder="همه ممیزین" />
            </SelectTrigger>
            <SelectContent dir="rtl">
              <SelectItem value="all">همه ممیزین</SelectItem>
              {auditors.map((auditor) => (
                <SelectItem key={auditor.id} value={auditor.id}>
                  {auditor.fullName}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      )}
    </div>
  );
}

