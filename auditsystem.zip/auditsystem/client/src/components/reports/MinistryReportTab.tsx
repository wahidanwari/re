/**
 * Report Type 2: Ministry Reporting
 * Ministry of Finance Detailed Audit Report
 * RTL table with system + manual fields
 * 
 * Features:
 * - Batch editing mode for four manual fields
 * - Role-based access control
 * - Group filtering based on user role
 */

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
  TableFooter,
} from '@/components/ui/table';
import { FileSpreadsheet, Eye, Edit2, Save, X } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useQuery, useMutation } from '@tanstack/react-query';
import { userHasPermission } from '@/utils/permissions';
import ReportFilters from './ReportFilters';
import jalaali from 'jalaali-js';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import InternalReportPeriodSelector, { type ReportType } from './InternalReportPeriodSelector';

interface MinistryReportTabProps {
  user: any;
}

interface EditableFields {
  lettersReceived: number;
  lettersSent: number;
  inquiriesReceived: number;
  inquiriesSent: number;
}

export default function MinistryReportTab({ user }: MinistryReportTabProps) {
  const { toast } = useToast();
  
  // Get current Shamsi date
  const currentShamsi = jalaali.toJalaali(new Date());
  const [month, setMonth] = useState<string>(currentShamsi.jm.toString());
  const [year, setYear] = useState<string>(currentShamsi.jy.toString());
  const [reportData, setReportData] = useState<any[]>([]);
  const [isEditing, setIsEditing] = useState<Record<string, boolean>>({}); // Track which groups are in edit mode
  const [editValues, setEditValues] = useState<Record<string, EditableFields>>({}); // Store edited values per group
  const [isExporting, setIsExporting] = useState(false);
  const [activeSubTab, setActiveSubTab] = useState<'performance' | 'tax-installment' | 'law-enforcement'>('performance');
  const [reportType, setReportType] = useState<ReportType>('monthly');
  const [quarter, setQuarter] = useState<string | null>(null);
  
  // Check permissions
  const checkCanEdit = async (groupId: string): Promise<boolean> => {
    if (user?.role === 'system_admin' || user?.role === 'director') {
      return true;
    }
    
    // Check if user is coordinator
    try {
      const response = await fetch('/api/users/me', { credentials: 'include' });
      if (response.ok) {
        const userData = await response.json();
        // Coordinator check would be done via permission service
        // For now, check if senior_auditor with coordinator package
        if (userData.role === 'senior_auditor') {
          // Check if coordinator or same group
          const isCoordinator = userHasPermission(user, 'cases:assign_to_group');
          if (isCoordinator) return true;
          if (userData.groupId === groupId) return true;
        }
      }
    } catch (error) {
      console.error('Error checking permissions:', error);
    }
    
    return false;
  };
  
  // Determine if user can edit any group
  const canEditAny = user?.role === 'system_admin' || user?.role === 'director' || 
    (user?.role === 'senior_auditor' && userHasPermission(user, 'cases:assign_to_group'));
  
  // Determine if user can edit their own group
  const canEditOwnGroup = user?.role === 'senior_auditor' || user?.role === 'system_admin' || user?.role === 'director';
  
  // Determine if user can export
  const canExport = user?.role === 'system_admin' || user?.role === 'director' || 
    (user?.role === 'senior_auditor' && (userHasPermission(user, 'cases:assign_to_group') || true)); // Senior auditor can export their group
  
  // Fetch ministry report data
  const { refetch, isLoading } = useQuery({
    queryKey: ['ministry-report', month, year],
    queryFn: async () => {
      const response = await fetch(`/api/reports/ministry?month=${month}&year=${year}`, {
        credentials: 'include',
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to fetch ministry report');
      }
      const data = await response.json();
      
      // Filter groups based on user role
      let filteredData = data;
      if (user?.role !== 'system_admin' && user?.role !== 'director') {
        const isCoordinator = userHasPermission(user, 'cases:assign_to_group');
        if (!isCoordinator) {
          if (user?.role === 'senior_auditor' && user?.groupId) {
            // Senior Auditor can only see their own group
            filteredData = data.filter((r: any) => r.groupId === user.groupId);
          } else if (user?.role === 'auditor') {
            // Auditor cannot see ministry reports
            filteredData = [];
          }
        }
      }
      
      setReportData(filteredData);
      
      // Initialize edit values with current data
      const initialEditValues: Record<string, EditableFields> = {};
      filteredData.forEach((row: any) => {
        initialEditValues[row.groupId] = {
          lettersReceived: row.lettersReceived ?? 0,
          lettersSent: row.lettersSent ?? 0,
          inquiriesReceived: row.inquiriesReceived ?? 0,
          inquiriesSent: row.inquiriesSent ?? 0,
        };
      });
      setEditValues(initialEditValues);
      
      return filteredData;
    },
    enabled: false, // Manual fetch
  });
  
  // Save all four fields for a group
  const saveMutation = useMutation({
    mutationFn: async ({ groupId, fields }: { groupId: string; fields: EditableFields }) => {
      const response = await fetch(`/api/reports/ministry/${groupId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({
          month: parseInt(month),
          year: parseInt(year),
          lettersReceived: fields.lettersReceived,
          lettersSent: fields.lettersSent,
          inquiriesReceived: fields.inquiriesReceived,
          inquiriesSent: fields.inquiriesSent,
        }),
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to save');
      }
      
      return response.json();
    },
    onSuccess: (_, variables) => {
      toast({
        title: 'موفق',
        description: 'فیلدها با موفقیت ذخیره شدند',
      });
      setIsEditing(prev => ({ ...prev, [variables.groupId]: false }));
      refetch();
    },
    onError: (error: any) => {
      toast({
        title: 'خطا',
        description: error.message || 'خطا در ذخیره',
        variant: 'destructive',
      });
    },
  });
  
  const handleStartEdit = (groupId: string) => {
    setIsEditing(prev => ({ ...prev, [groupId]: true }));
    // Initialize edit values if not already set
    if (!editValues[groupId]) {
      const row = reportData.find(r => r.groupId === groupId);
      if (row) {
        setEditValues(prev => ({
          ...prev,
          [groupId]: {
            lettersReceived: row.lettersReceived ?? 0,
            lettersSent: row.lettersSent ?? 0,
            inquiriesReceived: row.inquiriesReceived ?? 0,
            inquiriesSent: row.inquiriesSent ?? 0,
          },
        }));
      }
    }
  };
  
  const handleCancelEdit = (groupId: string) => {
    setIsEditing(prev => ({ ...prev, [groupId]: false }));
    // Reset edit values to original
    const row = reportData.find(r => r.groupId === groupId);
    if (row) {
      setEditValues(prev => ({
        ...prev,
        [groupId]: {
          lettersReceived: row.lettersReceived ?? 0,
          lettersSent: row.lettersSent ?? 0,
          inquiriesReceived: row.inquiriesReceived ?? 0,
          inquiriesSent: row.inquiriesSent ?? 0,
        },
      }));
    }
  };
  
  const handleSave = (groupId: string) => {
    const fields = editValues[groupId];
    if (fields) {
      saveMutation.mutate({ groupId, fields });
    }
  };
  
  const handleFieldChange = (groupId: string, field: keyof EditableFields, value: string) => {
    setEditValues(prev => ({
      ...prev,
      [groupId]: {
        ...prev[groupId],
        [field]: parseInt(value) || 0,
      },
    }));
  };
  
  const handleExport = async () => {
    setIsExporting(true);
    try {
      const response = await fetch(`/api/reports/ministry/export?month=${month}&year=${year}`, {
        credentials: 'include',
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to export');
      }
      
      const contentDisposition = response.headers.get('Content-Disposition');
      let filename = `ministry-report-${year}-${month}.xlsx`;
      if (contentDisposition) {
        const filenameMatch = contentDisposition.match(/filename="?(.+)"?/);
        if (filenameMatch) {
          filename = filenameMatch[1];
        }
      }
      
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      
      toast({
        title: 'موفق',
        description: 'گزارش با موفقیت دانلود شد',
      });
    } catch (error: any) {
      toast({
        title: 'خطا',
        description: error.message || 'خطا در دانلود گزارش',
        variant: 'destructive',
      });
    } finally {
      setIsExporting(false);
    }
  };
  
  // Check if user can edit a specific group
  const canEditGroup = (groupId: string): boolean => {
    if (user?.role === 'system_admin' || user?.role === 'director') {
      return true;
    }
    if (userHasPermission(user, 'cases:assign_to_group')) {
      return true; // Coordinator
    }
    if (user?.role === 'senior_auditor' && user?.groupId === groupId) {
      return true; // Senior Auditor can edit their own group
    }
    return false;
  };
  
  // Calculate totals
  const totals = reportData.reduce((acc, row) => {
    acc.distributed += row.casesDistributed || 0;
    acc.completed += row.casesCompleted || 0;
    acc.installments += row.casesWithInstallments || 0;
    acc.nonCompliant += row.nonCompliantCases || 0;
    acc.underReview += row.casesUnderReview || 0;
    acc.revenueTarget += row.monthlyRevenueTarget || 0;
    acc.collected += row.collectedRevenue || 0;
    return acc;
  }, {
    distributed: 0,
    completed: 0,
    installments: 0,
    nonCompliant: 0,
    underReview: 0,
    revenueTarget: 0,
    collected: 0,
  });
  
  const monthNames = ['', 'حمل', 'ثور', 'جوزا', 'سرطان', 'اسد', 'سنبله', 'میزان', 'عقرب', 'قوس', 'جدی', 'دلو', 'حوت'];
  const monthName = monthNames[parseInt(month)] || month;
  
  return (
    <div className="space-y-6" dir="rtl">
      {/* Period Selector - Shared across all sub-tabs */}
      <InternalReportPeriodSelector
        reportType={reportType}
        year={year}
        month={month}
        quarter={quarter}
        onReportTypeChange={setReportType}
        onYearChange={setYear}
        onMonthChange={setMonth}
        onQuarterChange={setQuarter}
      />

      {/* Sub-tabs for different report types */}
      <Tabs value={activeSubTab} onValueChange={(v) => setActiveSubTab(v as any)} className="w-full" dir="rtl">
        <TabsList className="grid w-full grid-cols-3" dir="rtl">
          <TabsTrigger value="performance">خلاصه عملکرد</TabsTrigger>
          <TabsTrigger value="tax-installment">قضایای اقساط</TabsTrigger>
          <TabsTrigger value="law-enforcement">قضایای تنفیذ قانون</TabsTrigger>
        </TabsList>

        {/* Performance Summary Tab */}
        <TabsContent value="performance" className="space-y-4">
          {/* Filters - Only for monthly performance reports */}
          {reportType === 'monthly' && (
            <ReportFilters
              month={month}
              year={year}
              onMonthChange={setMonth}
              onYearChange={setYear}
            />
          )}

          {/* Actions */}
          <div className="flex gap-2" dir="rtl">
            <Button
              onClick={() => refetch()}
              disabled={isLoading || !month || !year}
            >
              <Eye className="mr-2 h-4 w-4" />
              مشاهده گزارش
            </Button>
            {canExport && (
              <Button
                onClick={handleExport}
                disabled={isExporting || !month || !year || reportData.length === 0}
                variant="outline"
              >
                <FileSpreadsheet className="mr-2 h-4 w-4" />
                {isExporting ? 'در حال دانلود...' : 'دریافت فایل اکسل'}
              </Button>
            )}
          </div>

          {/* Report Table */}
          {reportData.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>
              جدول گزارش تفصیلی آمریت بررسی مستوفیت ولایت هرات بابت برج {monthName} سال مالی {year}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto" dir="rtl">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="text-right">شماره</TableHead>
                    <TableHead className="text-right">گروپ مربوطه</TableHead>
                    <TableHead className="text-right">تعداد نهاد/شرکت های توزیع شده طی برج جاری</TableHead>
                    <TableHead className="text-right">تعداد نهاد/شرکت های نهائی شده طی برج جاری</TableHead>
                    <TableHead className="text-right">تعداد نهاد/شرکت های قسط شده طی برج جاری</TableHead>
                    <TableHead className="text-right">تعداد نهاد/شرکت های عدم اطاعت پذیر</TableHead>
                    <TableHead className="text-right">تعداد نهاد/شرکت های تحت بررسی</TableHead>
                    <TableHead className="text-right">هدف ماهوار عوایدی</TableHead>
                    <TableHead className="text-right">عواید جمع آوری شده طی برج جاری</TableHead>
                    <TableHead className="text-right">فیصدی تنقیص/تزئید</TableHead>
                    <TableHead className="text-right">تعداد مکتوب های وارده</TableHead>
                    <TableHead className="text-right">تعداد مکتوب های صادره</TableHead>
                    <TableHead className="text-right">تعداد استعلام های وارده</TableHead>
                    <TableHead className="text-right">تعداد استعلام های صادره</TableHead>
                    <TableHead className="text-right">عملیات</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {reportData.map((row) => {
                    const isRowEditing = isEditing[row.groupId] || false;
                    const canEditThisGroup = canEditGroup(row.groupId);
                    const rowEditValues = editValues[row.groupId] || {
                      lettersReceived: row.lettersReceived ?? 0,
                      lettersSent: row.lettersSent ?? 0,
                      inquiriesReceived: row.inquiriesReceived ?? 0,
                      inquiriesSent: row.inquiriesSent ?? 0,
                    };
                    
                    return (
                      <TableRow key={row.groupId}>
                        <TableCell className="text-right">{row.groupNumber}</TableCell>
                        <TableCell className="text-right">{row.groupName}</TableCell>
                        <TableCell className="text-right">{row.casesDistributed.toLocaleString()}</TableCell>
                        <TableCell className="text-right">{row.casesCompleted.toLocaleString()}</TableCell>
                        <TableCell className="text-right">{row.casesWithInstallments.toLocaleString()}</TableCell>
                        <TableCell className="text-right">{row.nonCompliantCases.toLocaleString()}</TableCell>
                        <TableCell className="text-right">{row.casesUnderReview.toLocaleString()}</TableCell>
                        <TableCell className="text-right">{row.monthlyRevenueTarget.toLocaleString()}</TableCell>
                        <TableCell className="text-right">{row.collectedRevenue.toLocaleString()}</TableCell>
                        <TableCell className="text-right">
                          {row.revenueChangePercent >= 0 ? '+' : ''}{row.revenueChangePercent.toFixed(2)}%
                        </TableCell>
                        <TableCell className="text-right">
                          {isRowEditing ? (
                            <Input
                              type="number"
                              value={rowEditValues.lettersReceived}
                              onChange={(e) => handleFieldChange(row.groupId, 'lettersReceived', e.target.value)}
                              className="w-20"
                              dir="ltr"
                            />
                          ) : (
                            <div>{row.lettersReceived ?? 0}</div>
                          )}
                        </TableCell>
                        <TableCell className="text-right">
                          {isRowEditing ? (
                            <Input
                              type="number"
                              value={rowEditValues.lettersSent}
                              onChange={(e) => handleFieldChange(row.groupId, 'lettersSent', e.target.value)}
                              className="w-20"
                              dir="ltr"
                            />
                          ) : (
                            <div>{row.lettersSent ?? 0}</div>
                          )}
                        </TableCell>
                        <TableCell className="text-right">
                          {isRowEditing ? (
                            <Input
                              type="number"
                              value={rowEditValues.inquiriesReceived}
                              onChange={(e) => handleFieldChange(row.groupId, 'inquiriesReceived', e.target.value)}
                              className="w-20"
                              dir="ltr"
                            />
                          ) : (
                            <div>{row.inquiriesReceived ?? 0}</div>
                          )}
                        </TableCell>
                        <TableCell className="text-right">
                          {isRowEditing ? (
                            <Input
                              type="number"
                              value={rowEditValues.inquiriesSent}
                              onChange={(e) => handleFieldChange(row.groupId, 'inquiriesSent', e.target.value)}
                              className="w-20"
                              dir="ltr"
                            />
                          ) : (
                            <div>{row.inquiriesSent ?? 0}</div>
                          )}
                        </TableCell>
                        <TableCell className="text-right">
                          {canEditThisGroup ? (
                            isRowEditing ? (
                              <div className="flex gap-2" dir="rtl">
                                <Button
                                  size="sm"
                                  onClick={() => handleSave(row.groupId)}
                                  disabled={saveMutation.isPending}
                                >
                                  <Save className="mr-1 h-3 w-3" />
                                  ذخیره
                                </Button>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => handleCancelEdit(row.groupId)}
                                  disabled={saveMutation.isPending}
                                >
                                  <X className="mr-1 h-3 w-3" />
                                  لغو
                                </Button>
                              </div>
                            ) : (
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => handleStartEdit(row.groupId)}
                              >
                                <Edit2 className="mr-1 h-3 w-3" />
                                ویرایش گزارش این گروه
                              </Button>
                            )
                          ) : (
                            <span className="text-muted-foreground text-sm">غیرقابل ویرایش</span>
                          )}
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
                <TableFooter>
                  <TableRow>
                    <TableCell className="text-right font-bold">مجموع</TableCell>
                    <TableCell className="text-right"></TableCell>
                    <TableCell className="text-right font-bold">{totals.distributed.toLocaleString()}</TableCell>
                    <TableCell className="text-right font-bold">{totals.completed.toLocaleString()}</TableCell>
                    <TableCell className="text-right font-bold">{totals.installments.toLocaleString()}</TableCell>
                    <TableCell className="text-right font-bold">{totals.nonCompliant.toLocaleString()}</TableCell>
                    <TableCell className="text-right font-bold">{totals.underReview.toLocaleString()}</TableCell>
                    <TableCell className="text-right font-bold">{totals.revenueTarget.toLocaleString()}</TableCell>
                    <TableCell className="text-right font-bold">{totals.collected.toLocaleString()}</TableCell>
                    <TableCell className="text-right"></TableCell>
                    <TableCell className="text-right"></TableCell>
                    <TableCell className="text-right"></TableCell>
                    <TableCell className="text-right"></TableCell>
                    <TableCell className="text-right"></TableCell>
                    <TableCell className="text-right"></TableCell>
                  </TableRow>
                </TableFooter>
              </Table>
            </div>
          </CardContent>
        </Card>
      )}
        </TabsContent>

        {/* Tax Installment Report Tab */}
        <TabsContent value="tax-installment" className="space-y-4">
          <TaxInstallmentReportSection
            reportType={reportType}
            year={year}
            month={month}
            quarter={quarter}
            isValid={true}
            user={user}
          />
        </TabsContent>

        {/* Law Enforcement Report Tab */}
        <TabsContent value="law-enforcement" className="space-y-4">
          <LawEnforcementReportSection
            reportType={reportType}
            year={year}
            month={month}
            quarter={quarter}
            isValid={true}
            user={user}
          />
        </TabsContent>
      </Tabs>
    </div>
  );
}

// Tax Installment Report Section Component (reused from InternalReportTab)
function TaxInstallmentReportSection({
  reportType,
  year,
  month,
  quarter,
  isValid,
  user,
}: {
  reportType: ReportType;
  year: string;
  month: string | null;
  quarter: string | null;
  isValid: boolean;
  user: any;
}) {
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const [reportData, setReportData] = useState<any>(null);

  const fetchReport = async () => {
    if (!isValid) {
      toast({
        title: 'خطا',
        description: 'لطفاً تمام فیلدهای الزامی را پر کنید',
        variant: 'destructive',
      });
      return;
    }

    setIsLoading(true);
    try {
      let url = `/api/reports/tax-installment-law-enforcement?reportType=${reportType}&year=${year}`;
      if (reportType === 'monthly' && month) {
        url += `&month=${month}`;
      } else if (reportType === '3-month' && quarter) {
        url += `&quarter=${quarter}`;
      }

      const response = await fetch(url, { credentials: 'include' });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to fetch report');
      }
      const data = await response.json();
      setReportData(data);
    } catch (error: any) {
      toast({
        title: 'خطا',
        description: error.message || 'خطا در دریافت گزارش',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleExport = async () => {
    if (!isValid) {
      toast({
        title: 'خطا',
        description: 'لطفاً تمام فیلدهای الزامی را پر کنید',
        variant: 'destructive',
      });
      return;
    }

    setIsExporting(true);
    try {
      let url = `/api/reports/tax-installment-law-enforcement/export?reportType=${reportType}&year=${year}`;
      if (reportType === 'monthly' && month) {
        url += `&month=${month}`;
      } else if (reportType === '3-month' && quarter) {
        url += `&quarter=${quarter}`;
      }

      const response = await fetch(url, { credentials: 'include' });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to export');
      }

      const blob = await response.blob();
      const url_blob = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url_blob;
      a.download = `tax-installment-report-${year}.xlsx`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url_blob);
      document.body.removeChild(a);

      toast({
        title: 'موفق',
        description: 'گزارش با موفقیت دانلود شد',
      });
    } catch (error: any) {
      toast({
        title: 'خطا',
        description: error.message || 'خطا در دانلود گزارش',
        variant: 'destructive',
      });
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <div className="space-y-4" dir="rtl">
      <div className="flex gap-2" dir="rtl">
        <Button onClick={fetchReport} disabled={isLoading || !isValid}>
          <Eye className="mr-2 h-4 w-4" />
          {isLoading ? 'در حال بارگذاری...' : 'مشاهده گزارش'}
        </Button>
        <Button
          onClick={handleExport}
          disabled={isExporting || !isValid || !reportData}
          variant="outline"
        >
          <FileSpreadsheet className="mr-2 h-4 w-4" />
          {isExporting ? 'در حال دانلود...' : 'دریافت فایل اکسل'}
        </Button>
      </div>

      {isLoading && (
        <Card>
          <CardContent className="py-8">
            <div className="text-center text-muted-foreground">در حال بارگذاری گزارش...</div>
          </CardContent>
        </Card>
      )}

      {!isLoading && reportData && (
        <Card>
          <CardHeader>
            <CardTitle>گزارش قضایای اقساط</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 bg-muted rounded-lg">
                  <div className="text-sm text-muted-foreground">کل قضایا</div>
                  <div className="text-2xl font-bold">{reportData.summary?.totalInstallmentCases || 0}</div>
                </div>
                <div className="p-4 bg-muted rounded-lg">
                  <div className="text-sm text-muted-foreground">تکمیل شده</div>
                  <div className="text-2xl font-bold">{reportData.summary?.completedInstallmentCases || 0}</div>
                </div>
                <div className="p-4 bg-muted rounded-lg">
                  <div className="text-sm text-muted-foreground">در انتظار</div>
                  <div className="text-2xl font-bold">{reportData.summary?.pendingInstallmentCases || 0}</div>
                </div>
                <div className="p-4 bg-muted rounded-lg">
                  <div className="text-sm text-muted-foreground">مبلغ تثبیت شده</div>
                  <div className="text-2xl font-bold">
                    {(reportData.summary?.totalInstallmentAmountFixed || 0).toLocaleString('fa-IR')}
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

// Law Enforcement Report Section Component (reused from InternalReportTab)
function LawEnforcementReportSection({
  reportType,
  year,
  month,
  quarter,
  isValid,
  user,
}: {
  reportType: ReportType;
  year: string;
  month: string | null;
  quarter: string | null;
  isValid: boolean;
  user: any;
}) {
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const [reportData, setReportData] = useState<any>(null);

  const fetchReport = async () => {
    if (!isValid) {
      toast({
        title: 'خطا',
        description: 'لطفاً تمام فیلدهای الزامی را پر کنید',
        variant: 'destructive',
      });
      return;
    }

    setIsLoading(true);
    try {
      let url = `/api/reports/tax-installment-law-enforcement?reportType=${reportType}&year=${year}`;
      if (reportType === 'monthly' && month) {
        url += `&month=${month}`;
      } else if (reportType === '3-month' && quarter) {
        url += `&quarter=${quarter}`;
      }

      const response = await fetch(url, { credentials: 'include' });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to fetch report');
      }
      const data = await response.json();
      setReportData(data);
    } catch (error: any) {
      toast({
        title: 'خطا',
        description: error.message || 'خطا در دریافت گزارش',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleExport = async () => {
    if (!isValid) {
      toast({
        title: 'خطا',
        description: 'لطفاً تمام فیلدهای الزامی را پر کنید',
        variant: 'destructive',
      });
      return;
    }

    setIsExporting(true);
    try {
      let url = `/api/reports/tax-installment-law-enforcement/export?reportType=${reportType}&year=${year}`;
      if (reportType === 'monthly' && month) {
        url += `&month=${month}`;
      } else if (reportType === '3-month' && quarter) {
        url += `&quarter=${quarter}`;
      }

      const response = await fetch(url, { credentials: 'include' });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to export');
      }

      const blob = await response.blob();
      const url_blob = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url_blob;
      a.download = `law-enforcement-report-${year}.xlsx`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url_blob);
      document.body.removeChild(a);

      toast({
        title: 'موفق',
        description: 'گزارش با موفقیت دانلود شد',
      });
    } catch (error: any) {
      toast({
        title: 'خطا',
        description: error.message || 'خطا در دانلود گزارش',
        variant: 'destructive',
      });
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <div className="space-y-4" dir="rtl">
      <div className="flex gap-2" dir="rtl">
        <Button onClick={fetchReport} disabled={isLoading || !isValid}>
          <Eye className="mr-2 h-4 w-4" />
          {isLoading ? 'در حال بارگذاری...' : 'مشاهده گزارش'}
        </Button>
        <Button
          onClick={handleExport}
          disabled={isExporting || !isValid || !reportData}
          variant="outline"
        >
          <FileSpreadsheet className="mr-2 h-4 w-4" />
          {isExporting ? 'در حال دانلود...' : 'دریافت فایل اکسل'}
        </Button>
      </div>

      {isLoading && (
        <Card>
          <CardContent className="py-8">
            <div className="text-center text-muted-foreground">در حال بارگذاری گزارش...</div>
          </CardContent>
        </Card>
      )}

      {!isLoading && reportData && (
        <Card>
          <CardHeader>
            <CardTitle>گزارش قضایای تنفیذ قانون</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 bg-muted rounded-lg">
                  <div className="text-sm text-muted-foreground">کل قضایا</div>
                  <div className="text-2xl font-bold">{reportData.summary?.totalLawEnforcementCases || 0}</div>
                </div>
                <div className="p-4 bg-muted rounded-lg">
                  <div className="text-sm text-muted-foreground">تکمیل شده</div>
                  <div className="text-2xl font-bold">{reportData.summary?.completedLawEnforcementCases || 0}</div>
                </div>
                <div className="p-4 bg-muted rounded-lg">
                  <div className="text-sm text-muted-foreground">در انتظار</div>
                  <div className="text-2xl font-bold">{reportData.summary?.pendingLawEnforcementCases || 0}</div>
                </div>
                <div className="p-4 bg-muted rounded-lg">
                  <div className="text-sm text-muted-foreground">مبلغ تثبیت شده</div>
                  <div className="text-2xl font-bold">
                    {(reportData.summary?.totalLawEnforcementAmountFixed || 0).toLocaleString('fa-IR')}
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
