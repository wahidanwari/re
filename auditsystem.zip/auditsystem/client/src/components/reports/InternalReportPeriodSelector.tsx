/**
 * Internal Report Period Selector
 * Allows selecting report type (Yearly | 3-Month), year, and quarter
 * Restricted to Director, System Admin, and Coordinator
 */

import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import jalaali from 'jalaali-js';

export type ReportType = 'monthly' | '3-month' | 'yearly';

export interface PeriodSelection {
  reportType: ReportType;
  year: string;
  month?: string | null; // For monthly reports
  quarter: string | null; // null for yearly/monthly, '1' | '2' | '3' | '4' for 3-month
}

interface InternalReportPeriodSelectorProps {
  reportType: ReportType;
  year: string;
  month?: string | null;
  quarter: string | null;
  onReportTypeChange: (type: ReportType) => void;
  onYearChange: (year: string) => void;
  onMonthChange?: (month: string | null) => void;
  onQuarterChange: (quarter: string | null) => void;
}

// Solar Hijri month names
const monthNames = [
  { value: '1', label: 'حمل' },
  { value: '2', label: 'ثور' },
  { value: '3', label: 'جوزا' },
  { value: '4', label: 'سرطان' },
  { value: '5', label: 'اسد' },
  { value: '6', label: 'سنبله' },
  { value: '7', label: 'میزان' },
  { value: '8', label: 'عقرب' },
  { value: '9', label: 'قوس' },
  { value: '10', label: 'جدی' },
  { value: '11', label: 'دلو' },
  { value: '12', label: 'حوت' },
];

// Quarter definitions mapping to Solar Hijri months
const quarters = [
  {
    value: '1',
    label: 'سه‌ماهه اول',
    months: ['1', '2', '3'],
    monthNames: 'حمل، ثور، جوزا',
  },
  {
    value: '2',
    label: 'سه‌ماهه دوم',
    months: ['4', '5', '6'],
    monthNames: 'سرطان، اسد، سنبله',
  },
  {
    value: '3',
    label: 'سه‌ماهه سوم',
    months: ['7', '8', '9'],
    monthNames: 'میزان، عقرب، قوس',
  },
  {
    value: '4',
    label: 'سه‌ماهه چهارم',
    months: ['10', '11', '12'],
    monthNames: 'جدی، دلو، حوت',
  },
];

export default function InternalReportPeriodSelector({
  reportType,
  year,
  month,
  quarter,
  onReportTypeChange,
  onYearChange,
  onMonthChange,
  onQuarterChange,
}: InternalReportPeriodSelectorProps) {
  // Get current Shamsi year and month
  const currentShamsi = jalaali.toJalaali(new Date());
  const currentYear = currentShamsi.jy;
  const currentMonth = currentShamsi.jm;
  
  // Generate year options (current year and 5 previous years)
  const yearOptions = [];
  for (let i = 0; i < 6; i++) {
    yearOptions.push((currentYear - i).toString());
  }

  // When report type changes, clear quarter/month appropriately
  const handleReportTypeChange = (newType: ReportType) => {
    onReportTypeChange(newType);
    if (newType === 'yearly') {
      onQuarterChange(null);
      if (onMonthChange) onMonthChange(null);
    } else if (newType === '3-month') {
      if (onMonthChange) onMonthChange(null);
      if (!quarter) {
        // Set default quarter if switching to 3-month and no quarter selected
        onQuarterChange('1');
      }
    } else if (newType === 'monthly') {
      onQuarterChange(null);
      if (onMonthChange && !month) {
        // Set default month if switching to monthly and no month selected
        onMonthChange(currentMonth.toString());
      }
    }
  };

  return (
    <div className="flex flex-wrap items-end gap-4 p-4 bg-muted/50 rounded-lg border" dir="rtl">
      {/* Report Type Selector */}
      <div className="space-y-2 min-w-[140px]">
        <Label htmlFor="report-type" className="text-sm font-medium">
          نوع گزارش
        </Label>
        <Select value={reportType} onValueChange={handleReportTypeChange}>
          <SelectTrigger id="report-type" dir="rtl" className="w-full">
            <SelectValue placeholder="انتخاب نوع گزارش" />
          </SelectTrigger>
          <SelectContent dir="rtl">
            <SelectItem value="monthly">ماهوار</SelectItem>
            <SelectItem value="3-month">سه‌ماهه</SelectItem>
            <SelectItem value="yearly">سالانه</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Year Selector - Required */}
      <div className="space-y-2 min-w-[120px]">
        <Label htmlFor="period-year" className="text-sm font-medium">
          سال مالی (شمسی) <span className="text-red-500">*</span>
        </Label>
        <Select value={year} onValueChange={onYearChange} required>
          <SelectTrigger id="period-year" dir="rtl" className="w-full">
            <SelectValue placeholder="انتخاب سال" />
          </SelectTrigger>
          <SelectContent dir="rtl">
            {yearOptions.map((y) => (
              <SelectItem key={y} value={y}>
                {y}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Month Selector - Only shown for Monthly type */}
      {reportType === 'monthly' && onMonthChange && (
        <div className="space-y-2 min-w-[120px]">
          <Label htmlFor="period-month" className="text-sm font-medium">
            ماه (برج) <span className="text-red-500">*</span>
          </Label>
          <Select
            value={month || ''}
            onValueChange={(value) => onMonthChange(value)}
            required
          >
            <SelectTrigger id="period-month" dir="rtl" className="w-full">
              <SelectValue placeholder="انتخاب ماه" />
            </SelectTrigger>
            <SelectContent dir="rtl">
              {monthNames.map((m) => (
                <SelectItem key={m.value} value={m.value}>
                  {m.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      )}

      {/* Quarter Selector - Only shown for 3-Month type */}
      {reportType === '3-month' && (
        <div className="space-y-2 min-w-[160px]">
          <Label htmlFor="period-quarter" className="text-sm font-medium">
            سه‌ماهه <span className="text-red-500">*</span>
          </Label>
          <Select
            value={quarter || ''}
            onValueChange={(value) => onQuarterChange(value)}
            required
          >
            <SelectTrigger id="period-quarter" dir="rtl" className="w-full">
              <SelectValue placeholder="انتخاب سه‌ماهه" />
            </SelectTrigger>
            <SelectContent dir="rtl">
              {quarters.map((q) => (
                <SelectItem key={q.value} value={q.value}>
                  {q.label} ({q.monthNames})
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      )}
    </div>
  );
}

/**
 * Get the months for a given quarter
 */
export function getQuarterMonths(quarter: string): string[] {
  const quarterDef = quarters.find((q) => q.value === quarter);
  return quarterDef ? quarterDef.months : [];
}

/**
 * Get quarter label for display
 */
export function getQuarterLabel(quarter: string): string {
  const quarterDef = quarters.find((q) => q.value === quarter);
  return quarterDef ? quarterDef.label : '';
}

