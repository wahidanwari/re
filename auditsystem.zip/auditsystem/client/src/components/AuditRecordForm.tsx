import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { useQuery } from '@tanstack/react-query';
import jalaali from 'jalaali-js';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { AlertCircle } from 'lucide-react';
import ShamsiDatePickerDDMMYYYY, { shamsiToGregorian } from '@/components/ShamsiDatePickerDDMMYYYY';

interface AuditRecord {
  id: string;
  entityId: string;
  auditYears?: string; // سال‌های بررسی - text field
  yearFrom?: number; // Parsed from auditYears
  yearTo?: number; // Parsed from auditYears
  referringGroup?: string; // گروه ارجاع‌دهنده
  referralDate?: string; // تاریخ ارجاع به بررسی
  status: 'in-progress' | 'completed' | 'archived';
  assignedGroup?: string; // گروه اختصاص داده شده
  responsibleEvaluator?: string;
  notes?: string;
}

interface AuditRecordFormProps {
  entityId: string;
  entityName?: string;
  existingRecord?: AuditRecord | null;
  onSuccess: () => void;
  onCancel: () => void;
}

export default function AuditRecordForm({
  entityId,
  entityName,
  existingRecord,
  onSuccess,
  onCancel,
}: AuditRecordFormProps) {
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [overlapWarning, setOverlapWarning] = useState<string | null>(null);
  const [checkingOverlap, setCheckingOverlap] = useState(false);
  
  // Get current Shamsi year
  const currentShamsiYear = jalaali.toJalaali(new Date()).jy;
  
  // Parse auditYears to get yearFrom/yearTo for display
  const parseAuditYears = (auditYears?: string): { yearFrom: number; yearTo: number } => {
    if (!auditYears) {
      return { yearFrom: currentShamsiYear, yearTo: currentShamsiYear };
    }
    // Support formats: "1400", "1400-1402", "1392–1400" (with en-dash or hyphen)
    const cleaned = auditYears.replace(/[–—]/g, '-');
    if (cleaned.includes('-')) {
      const parts = cleaned.split('-').map(s => s.trim());
      const from = parseInt(parts[0], 10);
      const to = parseInt(parts[1] || parts[0], 10);
      return { yearFrom: from || currentShamsiYear, yearTo: to || currentShamsiYear };
    } else {
      const year = parseInt(cleaned, 10);
      return { yearFrom: year || currentShamsiYear, yearTo: year || currentShamsiYear };
    }
  };

  const initialYears = existingRecord?.auditYears 
    ? parseAuditYears(existingRecord.auditYears)
    : { yearFrom: currentShamsiYear, yearTo: currentShamsiYear };

  // Format referral date for display
  const formatReferralDate = (date?: string): string => {
    if (!date) return '';
    try {
      const d = new Date(date);
      const j = jalaali.toJalaali(d);
      return `${String(j.jd).padStart(2, '0')}-${String(j.jm).padStart(2, '0')}-${j.jy}`;
    } catch {
      return '';
    }
  };

  const [formData, setFormData] = useState({
    auditYears: existingRecord?.auditYears || currentShamsiYear.toString(),
    referringGroup: existingRecord?.referringGroup || '',
    referralDate: formatReferralDate(existingRecord?.referralDate),
    assignedGroup: existingRecord?.assignedGroup || '',
    responsibleEvaluator: existingRecord?.responsibleEvaluator || '',
    notes: existingRecord?.notes || '',
  });

  // Fetch users for evaluator selection
  const { data: users = [] } = useQuery({
    queryKey: ['users'],
    queryFn: async () => {
      const response = await fetch('/api/users', {
        credentials: 'include',
      });
      if (!response.ok) throw new Error('Failed to fetch users');
      return response.json();
    },
  });

  // Fetch groups for audit group selection
  const { data: groups = [] } = useQuery({
    queryKey: ['groups'],
    queryFn: async () => {
      const response = await fetch('/api/groups', {
        credentials: 'include',
      });
      if (!response.ok) throw new Error('Failed to fetch groups');
      return response.json();
    },
  });

  // Parse auditYears and check for overlaps when it changes
  useEffect(() => {
    const checkOverlap = async () => {
      if (!entityId || !formData.auditYears) return;
      
      const parsed = parseAuditYears(formData.auditYears);
      const { yearFrom: yearFromNum, yearTo: yearToNum } = parsed;
      
      if (isNaN(yearFromNum) || isNaN(yearToNum) || yearFromNum > yearToNum) {
        setOverlapWarning(null);
        return;
      }
      
      // Skip check if editing and range hasn't changed
      if (existingRecord) {
        const existingParsed = parseAuditYears(existingRecord.auditYears);
        if (existingParsed.yearFrom === yearFromNum && existingParsed.yearTo === yearToNum) {
          setOverlapWarning(null);
          return;
        }
      }
      
      setCheckingOverlap(true);
      
      try {
        // Pre-check overlap via API
        const response = await fetch(
          `/api/audit-records/entities/${entityId}/audits?yearFrom=${yearFromNum}&yearTo=${yearToNum}`,
          { credentials: 'include' }
        );
        
        if (response.ok) {
          const data = await response.json();
          const overlappingRecords = data.records?.filter((r: any) => 
            !existingRecord || r.id !== existingRecord.id
          ) || [];
          
          if (overlappingRecords.length > 0) {
            const ranges = overlappingRecords.map((r: any) => 
              r.auditYears || (r.yearFrom === r.yearTo ? r.yearFrom : `${r.yearFrom}-${r.yearTo}`)
            ).join(', ');
            setOverlapWarning(`بازه سالی تداخل دارد با: ${ranges}`);
          } else {
            setOverlapWarning(null);
          }
        }
      } catch (error) {
        // Silently fail - server will validate on submit
        console.error('Error checking overlap:', error);
      } finally {
        setCheckingOverlap(false);
      }
    };
    
    // Debounce overlap check
    const timeoutId = setTimeout(checkOverlap, 500);
    return () => clearTimeout(timeoutId);
  }, [entityId, formData.auditYears, existingRecord]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      // Validate auditYears
      if (!formData.auditYears || formData.auditYears.trim() === '') {
        throw new Error('سال‌های بررسی الزامی است');
      }

      const parsed = parseAuditYears(formData.auditYears);
      const { yearFrom: yearFromNum, yearTo: yearToNum } = parsed;
      
      if (isNaN(yearFromNum) || isNaN(yearToNum)) {
        throw new Error('سال‌های بررسی نامعتبر است. فرمت صحیح: "1400" یا "1392-1400"');
      }
      
      if (yearFromNum > yearToNum) {
        throw new Error('سال شروع باید کمتر یا مساوی سال پایان باشد');
      }

      // Convert referral date to Gregorian
      let referralDateGregorian: string | null = null;
      if (formData.referralDate) {
        const converted = shamsiToGregorian(formData.referralDate);
        if (!converted) {
          throw new Error('تاریخ ارجاع به بررسی نامعتبر است. لطفا تاریخ را به فرمت DD-MM-YYYY وارد کنید');
        }
        referralDateGregorian = converted;
      }

      const payload: any = {
        auditYears: formData.auditYears.trim(),
        yearFrom: yearFromNum,
        yearTo: yearToNum,
        referringGroup: formData.referringGroup || null,
        referralDate: referralDateGregorian,
        assignedGroup: formData.assignedGroup || null,
        responsibleEvaluator: formData.responsibleEvaluator || null,
        notes: formData.notes || null,
      };

      let response;
      
      if (existingRecord) {
        // Update existing record
        response = await fetch(`/api/audit-records/${existingRecord.id}`, {
          method: 'PATCH',
          headers: {
            'Content-Type': 'application/json',
          },
          credentials: 'include',
          body: JSON.stringify(payload),
        });
      } else {
        // Create new record
        response = await fetch(`/api/audit-records/entities/${entityId}/audits`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          credentials: 'include',
          body: JSON.stringify(payload),
        });
      }

      if (!response.ok) {
        const error = await response.json();
        
        // Handle overlap conflicts with detailed info
        if (response.status === 409 && error.conflicts) {
          const conflictDetails = error.conflicts.map((c: any) => 
            c.yearFrom === c.yearTo ? c.yearFrom : `${c.yearFrom}-${c.yearTo}`
          ).join(', ');
          throw new Error(`بازه سالی تداخل دارد با سوابق موجود: ${conflictDetails}`);
        }
        
        throw new Error(error.message || 'خطا در ذخیره سابقه بررسی');
      }

      toast({
        title: 'موفقیت',
        description: existingRecord
          ? 'سابقه بررسی با موفقیت بروزرسانی شد'
          : 'سابقه بررسی با موفقیت ایجاد شد',
      });

      onSuccess();
    } catch (error: any) {
      toast({
        title: 'خطا',
        description: error.message || 'خطا در ذخیره سابقه بررسی',
        variant: 'destructive',
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4" dir="rtl">
      <div>
        <Label htmlFor="entityName">نام نهاد</Label>
        <Input
          id="entityName"
          value={entityName || ''}
          disabled
          className="mt-1"
        />
      </div>

      <div>
        <Label htmlFor="auditYears">سال‌های بررسی *</Label>
        <Input
          id="auditYears"
          value={formData.auditYears}
          onChange={(e) => setFormData({ ...formData, auditYears: e.target.value })}
          placeholder="مثال: 1400 یا 1392-1400"
          className="mt-1 text-right"
          required
        />
        <p className="text-xs text-muted-foreground mt-1">
          می‌توانید یک سال (مثال: 1400) یا بازه سالی (مثال: 1392-1400) وارد کنید
        </p>
      </div>

      {(() => {
        const parsed = parseAuditYears(formData.auditYears);
        if (parsed.yearFrom > parsed.yearTo) {
          return (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                سال شروع باید کمتر یا مساوی سال پایان باشد
              </AlertDescription>
            </Alert>
          );
        }
        return null;
      })()}

      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="referringGroup">گروه ارجاع‌دهنده *</Label>
          <Select
            value={formData.referringGroup}
            onValueChange={(value) =>
              setFormData({ ...formData, referringGroup: value })
            }
          >
            <SelectTrigger className="mt-1 text-right" dir="rtl">
              <SelectValue placeholder="گروه را انتخاب کنید" />
            </SelectTrigger>
            <SelectContent dir="rtl">
              {[
                { id: 'group-1', name: 'گروه اول سنجش ابتدایی' },
                { id: 'group-2', name: 'گروه دوم سنجش ابتدایی' },
                { id: 'group-3', name: 'گروه سوم سنجش ابتدایی' },
                { id: 'group-4', name: 'گروه چهارم سنجش ابتدایی' },
                { id: 'group-5', name: 'گروه پنجم سنجش ابتدایی' },
                { id: 'group-6', name: 'گروه ششم سنجش ابتدایی' },
                { id: 'group-7', name: 'گروه هفتم سنجش ابتدایی' },
                { id: 'group-8', name: 'گروه هشتم سنجش ابتدایی' },
                { id: 'group-9', name: 'گروه نهم سنجش ابتدایی' },
                { id: 'group-10', name: 'مدیریت عمومی تشخیص مالیه دهنده' },
              ].map((group) => (
                <SelectItem key={group.id} value={group.name}>
                  {group.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div>
          <Label htmlFor="referralDate">تاریخ ارجاع به بررسی *</Label>
          <ShamsiDatePickerDDMMYYYY
            value={formData.referralDate || ''}
            onChange={(date) => setFormData({ ...formData, referralDate: date })}
            required
          />
        </div>
      </div>

      {overlapWarning && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{overlapWarning}</AlertDescription>
        </Alert>
      )}

      {checkingOverlap && (
        <div className="text-sm text-muted-foreground">در حال بررسی تداخل...</div>
      )}

      <div>
        <Label htmlFor="assignedGroup">گروه اختصاص داده شده</Label>
        <Select
          value={formData.assignedGroup}
          onValueChange={(value) =>
            setFormData({ ...formData, assignedGroup: value })
          }
        >
          <SelectTrigger className="mt-1 text-right" dir="rtl">
            <SelectValue placeholder="گروه را انتخاب کنید (اختیاری)" />
          </SelectTrigger>
          <SelectContent dir="rtl">
            <SelectItem value="">بدون گروه</SelectItem>
            {groups
              .filter((g: any) => g.isActive)
              .map((group: any) => (
                <SelectItem key={group.id} value={group.id}>
                  {group.name}
                </SelectItem>
              ))}
          </SelectContent>
        </Select>
      </div>

      <div>
        <Label htmlFor="responsibleEvaluator">بررس مسئول</Label>
        <Select
          value={formData.responsibleEvaluator}
          onValueChange={(value) =>
            setFormData({ ...formData, responsibleEvaluator: value })
          }
        >
          <SelectTrigger className="mt-1">
            <SelectValue placeholder="بررس را انتخاب کنید (اختیاری)" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="">بدون اختصاص</SelectItem>
            {users
              .filter((u: any) => u.role === 'auditor' || u.role === 'senior_auditor')
              .map((user: any) => (
                <SelectItem key={user.id} value={user.id}>
                  {user.fullName} ({user.auditId})
                </SelectItem>
              ))}
          </SelectContent>
        </Select>
      </div>

      <div>
        <Label htmlFor="notes">یادداشت‌ها</Label>
        <Textarea
          id="notes"
          value={formData.notes}
          onChange={(e) =>
            setFormData({ ...formData, notes: e.target.value })
          }
          className="mt-1"
          rows={4}
          placeholder="یادداشت‌های مربوط به این سابقه بررسی را وارد کنید..."
        />
      </div>

      <div className="flex justify-end gap-2 pt-4">
        <Button type="button" variant="outline" onClick={onCancel}>
          انصراف
        </Button>
        <Button 
          type="submit" 
          disabled={
            isSubmitting || 
            checkingOverlap || 
            overlapWarning !== null ||
            !formData.auditYears ||
            !formData.referringGroup ||
            !formData.referralDate
          }
        >
          {isSubmitting ? 'در حال ذخیره...' : existingRecord ? 'بروزرسانی' : 'ایجاد'}
        </Button>
      </div>
    </form>
  );
}
