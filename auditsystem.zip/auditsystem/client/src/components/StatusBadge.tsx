import { Badge } from '@/components/ui/badge';

interface StatusBadgeProps {
  status: string;
}

const statusConfig: Record<string, { variant: 'default' | 'secondary' | 'destructive' | 'outline'; className: string }> = {
  'ایجاد شده': { variant: 'default', className: 'bg-blue-500 hover:bg-blue-600 text-white' },
  'در انتظار بررسی بازرس ارشد': { variant: 'default', className: 'bg-blue-400 hover:bg-blue-500 text-white' },
  'در حال بررسی': { variant: 'secondary', className: 'bg-amber-500 hover:bg-amber-600 text-white' },
  'در انتظار تکمیل مدارک': { variant: 'default', className: 'bg-yellow-500 hover:bg-yellow-600 text-white' },
  'تعلیق شده': { variant: 'secondary', className: 'bg-gray-500 hover:bg-gray-600 text-white' },
  'تکمیل شده': { variant: 'default', className: 'bg-green-500 hover:bg-green-600 text-white' },
};

export default function StatusBadge({ status }: StatusBadgeProps) {
  const config = statusConfig[status] || statusConfig['ایجاد شده'];
  
  return (
    <Badge 
      variant={config.variant} 
      className={config.className}
      data-testid={`badge-status-${status}`}
    >
      {status}
    </Badge>
  );
}
