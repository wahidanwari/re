import { Home, Building2, FileText, Users, UsersRound, Ticket, Settings, FileStack, LogOut, FileSearch, Target, BarChart3, ClipboardList, Archive } from 'lucide-react';
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarFooter,
} from '@/components/ui/sidebar';
import { Link, useLocation } from 'wouter';
import RoleBadge from './RoleBadge';
import { useAuth } from '@/contexts/AuthContext';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { usePermissions } from '@/hooks/usePermissions';
import type { Permission } from '@shared/permissions';
import { useEffect, useMemo } from 'react';

const menuItems: Array<{
  title: string;
  url: string;
  icon: any;
  testId: string;
  permission?: Permission;
  requireAny?: Permission[];
}> = [
  { title: 'داشبورد', url: '/', icon: Home, testId: 'link-dashboard' },
  { 
    title: 'مدیریت نهادها', 
    url: '/entities', 
    icon: Building2, 
    testId: 'link-entities',
    permission: 'entities:view'
  },
  { title: 'مدیریت قضایا', url: '/cases', icon: FileText, testId: 'link-cases', permission: 'cases:view' },
  { 
    title: 'کمیته‌ها', 
    url: '/committees-new', 
    icon: ClipboardList, 
    testId: 'link-committees-new',
    // Only directors, coordinators, and system admins can access - check in component
  },
  { title: 'کاربران', url: '/users', icon: Users, testId: 'link-users', permission: 'users:manage' },
  { 
    title: 'گروه ها', 
    url: '/groups', 
    icon: UsersRound, 
    testId: 'link-groups', 
    permission: 'groups:manage'
  },
  { 
    title: 'تنظیم اهداف', 
    url: '/target-settings', 
    icon: Target, 
    testId: 'link-target-settings', 
    permission: 'groups:set_targets'
  },
  { title: 'تکت ها', url: '/tickets', icon: Ticket, testId: 'link-tickets', requireAny: ['tickets:submit', 'tickets:approve'] },
  { title: 'اسناد', url: '/documents', icon: FileStack, testId: 'link-documents', permission: 'cases:view' },
  { title: 'بایگانی داده‌های Excel قدیمی', url: '/archives', icon: Archive, testId: 'link-archives', permission: 'archives:view' },
  { title: 'گزارش‌ها', url: '/reports', icon: BarChart3, testId: 'link-reports', permission: 'reports:generate' },
  { title: 'تنظیمات', url: '/settings', icon: Settings, testId: 'link-settings', permission: 'settings:manage' },
  { title: 'لاگ‌های بررسی', url: '/audit-logs', icon: FileSearch, testId: 'link-audit-logs', permission: 'logs:view' },
];

export function AppSidebar() {
  const [location, setLocation] = useLocation();
  const { user, logout } = useAuth();
  const { hasPermission, loading: permissionsLoading, permissions } = usePermissions();

  // Filter menu items based on permissions - use useMemo to ensure it recalculates when permissions change
  const visibleMenuItems = useMemo(() => {
    return menuItems.filter((item) => {
      if (!user) return false;
      
      // If permissions are still loading, show all items (will be filtered once loaded)
      if (permissionsLoading) {
        return true;
      }
      
      // System admin bypasses all permission checks
      if (user.role === 'system_admin') {
        return true;
      }
      
      // PRIORITY 1: Use server-provided modules list if available
      // This ensures consistency with server-side module calculation
      if (user.modules && Array.isArray(user.modules)) {
        // Map module names to menu item URLs
        const moduleMap: Record<string, string> = {
          'entities': '/entities',
          'cases': '/cases',
          'users': '/users',
          'groups': '/groups',
          'target-settings': '/target-settings',
          'tickets': '/tickets',
          'documents': '/documents',
          'archives': '/archives',
          'settings': '/settings',
          'audit-logs': '/audit-logs',
          'reports': '/reports',
        };
        
        // Check if this menu item's URL matches any module
        const moduleName = Object.keys(moduleMap).find(key => moduleMap[key] === item.url);
        if (moduleName) {
          return user.modules.includes(moduleName);
        }
        
        // Dashboard and other items without modules are always visible
        if (!item.permission && !item.requireAny) return true;
      }
      
      // PRIORITY 2: If effectivePermissions array is available from server, use it
      // This ensures we use server-computed permissions (role + packages + overrides)
      if (user.effectivePermissions && Array.isArray(user.effectivePermissions)) {
        // OLD COMMITTEE MODULE - DISABLED
        // Special case: Committees page - only directors
        // if (item.url === '/committees') {
        //   return user.role === 'director';
        // }
        if (!item.permission && !item.requireAny) return true; // No permission required
        if (item.permission) {
          return user.effectivePermissions.includes(item.permission);
        }
        if (item.requireAny) {
          return item.requireAny.some(perm => user.effectivePermissions!.includes(perm));
        }
        return true;
      }
      
      // PRIORITY 3: Fallback to permissions object from usePermissions hook
      // Check permissions directly from permissions object
      // OLD COMMITTEE MODULE - DISABLED
      // Special case: Committees page - only directors
      // if (item.url === '/committees') {
      //   return user.role === 'director';
      // }
      if (!item.permission && !item.requireAny) return true; // No permission required
      if (item.permission) {
        return permissions?.[item.permission] === true;
      }
      if (item.requireAny) {
        return item.requireAny.some(perm => permissions?.[perm] === true);
      }
      return true;
    });
  }, [user, user?.modules, user?.effectivePermissions, permissionsLoading, permissions]); // Re-compute when modules or permissions change

  // Modules are automatically recalculated via useMemo when permissions change
  // No additional effect needed

  return (
    <Sidebar side="right" collapsible="icon">
      <SidebarHeader className="p-4 border-b">
        <div className="flex flex-col gap-4">
          <div className="text-center group-data-[state=collapsed]:hidden">
            <h2 className="text-lg font-semibold">سیستم آمریت بررسی</h2>
            <p className="text-sm text-muted-foreground">وزارت مالیه</p>
          </div>
          {user && (
            <div className="group-data-[state=collapsed]:hidden">
              <RoleBadge role={user.role} permissionPackages={user.permissionPackages} />
            </div>
          )}
        </div>
      </SidebarHeader>
      <SidebarContent className="p-2">
        <SidebarGroup>
          <SidebarGroupLabel className="px-2">منو</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {visibleMenuItems.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton asChild isActive={location === item.url}>
                    <Link href={item.url} data-testid={item.testId}>
                      <item.icon className="ml-2 h-4 w-4" />
                      <span>{item.title}</span>
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
      <SidebarFooter className="p-4 border-t">
        {user && (
          <div className="space-y-3">
            <div className="flex items-center gap-3">
              <Avatar className="h-8 w-8">
                <AvatarFallback>{user.fullName.charAt(0)}</AvatarFallback>
              </Avatar>
              <div className="flex-1 min-w-0 group-data-[state=collapsed]:hidden">
                <p className="text-sm font-medium truncate">{user.fullName}</p>
                <p className="text-xs text-muted-foreground truncate">{user.auditId}</p>
              </div>
            </div>
            <SidebarMenuButton
              onClick={async () => {
                try {
                  await logout();
                  setLocation('/login');
                } catch (error) {
                  // Silently handle logout errors
                  setLocation('/login');
                }
              }}
              className="w-full justify-start group-data-[state=collapsed]:justify-center hover:bg-destructive/10 hover:text-destructive"
              data-testid="button-logout"
              title="خروج از سیستم"
            >
              <LogOut className="ml-2 h-4 w-4 group-data-[state=collapsed]:ml-0" />
              <span className="group-data-[state=collapsed]:hidden">خروج</span>
            </SidebarMenuButton>
          </div>
        )}
      </SidebarFooter>
    </Sidebar>
  );
}
