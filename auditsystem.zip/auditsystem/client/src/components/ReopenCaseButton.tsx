/**
 * Reopen Case Button - Allows senior auditors to reopen completed cases
 */

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { RotateCcw } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';

interface ReopenCaseButtonProps {
  caseId: string;
  onReopen?: () => void;
}

export default function ReopenCaseButton({ caseId, onReopen }: ReopenCaseButtonProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [reason, setReason] = useState('');

  const reopenMutation = useMutation({
    mutationFn: async (reopenReason: string) => {
      const response = await fetch(`/api/cases/${caseId}/reopen`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ reason: reopenReason }),
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to reopen case');
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['cases'] });
      queryClient.invalidateQueries({ queryKey: ['case', caseId] });
      if (onReopen) onReopen();
      setDialogOpen(false);
      setReason('');
      toast({
        title: 'موفق',
        description: 'قضیه با موفقیت باز شد',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'خطا',
        description: error.message || 'خطا در باز کردن قضیه',
        variant: 'destructive',
      });
    },
  });

  const handleReopen = () => {
    if (!reason.trim()) {
      toast({
        title: 'خطا',
        description: 'لطفاً دلیل باز کردن قضیه را وارد کنید',
        variant: 'destructive',
      });
      return;
    }
    reopenMutation.mutate(reason);
  };

  return (
    <>
      <Button
        variant="outline"
        onClick={() => setDialogOpen(true)}
        className="w-full"
      >
        <RotateCcw className="h-4 w-4 mr-2" />
        ویرایش گزارش تکمیل‌شده (بازکردن برای ویرایش)
      </Button>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>باز کردن قضیه برای ویرایش</DialogTitle>
            <DialogDescription>
              با باز کردن این قضیه، وضعیت آن به "در جریان بررسی" تغییر می‌کند و می‌توانید آن را ویرایش کنید.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="reopen-reason">دلیل باز کردن *</Label>
              <Textarea
                id="reopen-reason"
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                className="text-right"
                rows={4}
                placeholder="لطفاً دلیل باز کردن قضیه را توضیح دهید..."
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setDialogOpen(false);
                setReason('');
              }}
              disabled={reopenMutation.isPending}
            >
              لغو
            </Button>
            <Button
              onClick={handleReopen}
              disabled={reopenMutation.isPending || !reason.trim()}
            >
              {reopenMutation.isPending ? 'در حال باز کردن...' : 'باز کردن قضیه'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}

