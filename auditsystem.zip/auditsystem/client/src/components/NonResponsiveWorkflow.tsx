/**
 * Non-responsive Workflow - Handles marking cases as non-responsive and escalation
 */

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { AlertTriangle, ArrowRight, Clock } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';

interface NonResponsiveWorkflowProps {
  caseId: string;
  flags?: Array<{
    id: string;
    type: string;
    details: any;
    created_at: string;
    created_by: string;
  }>;
  onUpdate?: () => void;
}

export default function NonResponsiveWorkflow({ caseId, flags = [], onUpdate }: NonResponsiveWorkflowProps) {
  const { toast } = useToast();
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [markDialogOpen, setMarkDialogOpen] = useState(false);
  const [escalateDialogOpen, setEscalateDialogOpen] = useState(false);
  const [attemptCount, setAttemptCount] = useState(1);
  const [notes, setNotes] = useState('');
  const [escalationNotes, setEscalationNotes] = useState('');

  const nonresponsiveFlags = flags.filter(f => f.type === 'nonresponsive_attempt' || f.type === 'nonresponsive_mark');
  const totalAttempts = nonresponsiveFlags.length;

  const createFlagMutation = useMutation({
    mutationFn: async ({ type, details }: { type: string; details: any }) => {
      const response = await fetch(`/api/cases/${caseId}/flags`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ type, details }),
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to create flag');
      }
      return response.json();
    },
    onSuccess: (data, variables) => {
      queryClient.invalidateQueries({ queryKey: ['case', caseId] });
      if (onUpdate) onUpdate();
      if (variables.type === 'nonresponsive_mark') {
        setMarkDialogOpen(false);
        setAttemptCount(1);
        setNotes('');
        toast({
          title: 'موفق',
          description: 'قضیه به عنوان عدم پاسخگو نشانه‌گذاری شد',
        });
      } else if (variables.type === 'escalation_to_enforcement') {
        setEscalateDialogOpen(false);
        setEscalationNotes('');
        // Invalidate queries to refresh case data
        queryClient.invalidateQueries({ queryKey: ['cases'] });
        queryClient.invalidateQueries({ queryKey: ['case', caseId] });
        toast({
          title: 'موفق',
          description: 'قضیه به "ارسال‌شده به تنفیذ قانون" ارجاع داده شد و به تب مربوطه منتقل شد',
        });
      }
    },
    onError: (error: Error) => {
      toast({
        title: 'خطا',
        description: error.message || 'خطا در ثبت عملیات',
        variant: 'destructive',
      });
    },
  });

  const handleMarkNonresponsive = () => {
    createFlagMutation.mutate({
      type: 'nonresponsive_mark',
      details: {
        attempts: attemptCount,
        notes: notes,
        timestamp: new Date().toISOString(),
      },
    });
  };

  const handleEscalate = () => {
    createFlagMutation.mutate({
      type: 'escalation_to_enforcement',
      details: {
        notes: escalationNotes,
        timestamp: new Date().toISOString(),
      },
    });
  };

  const isSeniorAuditor = user?.role === 'senior_auditor' || user?.role === 'system_admin';

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <AlertTriangle className="h-5 w-5" />
          عدم پاسخگو
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Attempt History */}
        {totalAttempts > 0 && (
          <div className="space-y-2">
            <Label>تاریخچه تلاش‌ها</Label>
            <div className="space-y-1">
              {nonresponsiveFlags.map((flag) => (
                <div key={flag.id} className="flex items-center justify-between p-2 bg-muted rounded">
                  <div className="flex items-center gap-2">
                    <Clock className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm">
                      {flag.type === 'nonresponsive_mark' ? 'نشانه‌گذاری شده' : 'تلاش'}
                    </span>
                    {flag.details?.attempts && (
                      <Badge variant="outline">{flag.details.attempts} تلاش</Badge>
                    )}
                  </div>
                  <span className="text-xs text-muted-foreground">
                    {new Date(flag.created_at).toLocaleDateString('fa-IR')}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Actions */}
        <div className="flex gap-2">
          <Button
            variant="outline"
            onClick={() => {
              setAttemptCount(totalAttempts + 1);
              setMarkDialogOpen(true);
            }}
          >
            <AlertTriangle className="h-4 w-4 mr-2" />
            نشانه‌گذاری عدم پاسخگو
          </Button>

          {isSeniorAuditor && (
            <Button
              variant="destructive"
              onClick={() => setEscalateDialogOpen(true)}
            >
              <ArrowRight className="h-4 w-4 mr-2" />
              ارسال‌ شده به تنفیذ قانون
            </Button>
          )}
        </div>
      </CardContent>

      {/* Mark Non-responsive Dialog */}
      <Dialog open={markDialogOpen} onOpenChange={setMarkDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>نشانه‌گذاری عدم پاسخگو</DialogTitle>
            <DialogDescription>
              آیا از نشانه‌گذاری این مورد به‌عنوان «عدم پاسخگو» اطمینان دارید؟
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="attempt-count">تعداد تلاش‌ها</Label>
              <Input
                id="attempt-count"
                type="number"
                value={attemptCount}
                onChange={(e) => setAttemptCount(parseInt(e.target.value) || 1)}
                className="text-right"
                dir="ltr"
                min={1}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="nonresponsive-notes">ملاحظات</Label>
              <Textarea
                id="nonresponsive-notes"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                className="text-right"
                rows={3}
                placeholder="توضیحات در مورد تلاش‌ها و عدم پاسخ..."
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setMarkDialogOpen(false);
                setNotes('');
              }}
              disabled={createFlagMutation.isPending}
            >
              لغو
            </Button>
            <Button
              onClick={handleMarkNonresponsive}
              disabled={createFlagMutation.isPending}
            >
              {createFlagMutation.isPending ? 'در حال ثبت...' : 'تایید'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Escalate Dialog */}
      <Dialog open={escalateDialogOpen} onOpenChange={setEscalateDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>ارسال‌ شده به تنفیذ قانون</DialogTitle>
            <DialogDescription>
              ارسال‌ شده به تنفیذ قانون — این عملیات قابل بازگشت نیست. آیا ادامه می‌دهید؟
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="p-4 bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 rounded-lg">
              <p className="text-sm text-yellow-800 dark:text-yellow-200">
                <strong>هشدار:</strong> با ارجاع این قضیه به تنفیذ قانون، وضعیت قضیه تغییر می‌کند و این عملیات قابل بازگشت نیست.
              </p>
            </div>
            <div className="space-y-2">
              <Label htmlFor="escalation-notes">ملاحظات</Label>
              <Textarea
                id="escalation-notes"
                value={escalationNotes}
                onChange={(e) => setEscalationNotes(e.target.value)}
                className="text-right"
                rows={3}
                placeholder="دلیل ارسال‌ شده به تنفیذ قانون..."
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setEscalateDialogOpen(false);
                setEscalationNotes('');
              }}
              disabled={createFlagMutation.isPending}
            >
              لغو
            </Button>
            <Button
              variant="destructive"
              onClick={handleEscalate}
              disabled={createFlagMutation.isPending}
            >
              {createFlagMutation.isPending ? 'در حال ارجاع...' : 'ارسال‌ شده به تنفیذ قانون'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  );
}

