import Entities from '../../pages/Entities';

export default function EntitiesExample() {
  return <Entities />;
}
