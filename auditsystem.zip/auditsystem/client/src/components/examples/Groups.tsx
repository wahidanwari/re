import Groups from '../../pages/Groups';

export default function GroupsExample() {
  return <Groups />;
}
