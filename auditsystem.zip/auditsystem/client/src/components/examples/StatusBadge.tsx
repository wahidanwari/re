import StatusBadge from '../StatusBadge';

export default function StatusBadgeExample() {
  return (
    <div className="flex flex-wrap gap-2 p-4">
      <StatusBadge status="جدید" />
      <StatusBadge status="در جریان بررسی" />
      <StatusBadge status="تکمیل شده" />
      <StatusBadge status="تایید شده" />
      <StatusBadge status="رد شده" />
      <StatusBadge status="منتظر تایید" />
    </div>
  );
}
