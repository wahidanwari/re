import { useState } from 'react';
import ShamsiDatePicker from '../ShamsiDatePicker';

export default function ShamsiDatePickerExample() {
  const [date, setDate] = useState('');

  return (
    <div className="p-4 max-w-md">
      <ShamsiDatePicker value={date} onChange={setDate} />
      {date && <p className="mt-2 text-sm text-muted-foreground">تاریخ انتخاب شده: {date}</p>}
    </div>
  );
}
