import Tickets from '../../pages/Tickets';

export default function TicketsExample() {
  return <Tickets />;
}
