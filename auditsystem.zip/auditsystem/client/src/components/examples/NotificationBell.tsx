import NotificationBell from '../NotificationBell';

export default function NotificationBellExample() {
  return (
    <div className="p-4 flex justify-center">
      <NotificationBell />
    </div>
  );
}
