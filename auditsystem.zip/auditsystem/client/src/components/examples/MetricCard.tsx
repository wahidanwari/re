import MetricCard from '../MetricCard';
import { FileText, Users, CheckCircle, Clock } from 'lucide-react';

export default function MetricCardExample() {
  return (
    <div className="p-4 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
      <MetricCard title="قضایای فعال" value="24" icon={FileText} trend="+3 از هفته گذشته" />
      <MetricCard title="کاربران فعال" value="12" icon={Users} />
      <MetricCard title="قضایای تکمیل شده" value="156" icon={CheckCircle} trend="این ماه: 23" />
      <MetricCard title="منتظر تایید" value="8" icon={Clock} />
    </div>
  );
}
