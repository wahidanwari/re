import Users from '../../pages/Users';

export default function UsersExample() {
  return <Users />;
}
