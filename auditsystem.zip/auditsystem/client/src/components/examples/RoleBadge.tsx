import RoleBadge from '../RoleBadge';

export default function RoleBadgeExample() {
  return (
    <div className="p-4 space-y-4">
      <RoleBadge role="system_admin" />
      <RoleBadge role="director" />
      <RoleBadge role="senior_auditor" permissionPackages={['acting_coordinator']} />
      <RoleBadge role="auditor" permissionPackages={['approval_authority']} />
    </div>
  );
}
