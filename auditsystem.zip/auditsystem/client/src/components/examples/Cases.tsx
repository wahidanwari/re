import Cases from '../../pages/Cases';

export default function CasesExample() {
  return <Cases />;
}
