import Settings from '../../pages/Settings';

export default function SettingsExample() {
  return <Settings />;
}
