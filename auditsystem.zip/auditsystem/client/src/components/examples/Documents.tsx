import Documents from '../../pages/Documents';

export default function DocumentsExample() {
  return <Documents />;
}
