import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar } from 'lucide-react';
import { Input } from '@/components/ui/input';
import jalaali from 'jalaali-js';
import { cn } from '@/lib/utils';

interface ShamsiDatePickerDDMMYYYYProps {
  value?: string; // DD-MM-YYYY format (Shamsi) for display
  onChange: (date: string) => void; // Returns DD-MM-YYYY (Shamsi) format
  placeholder?: string;
  className?: string;
  disabled?: boolean;
  required?: boolean;
  error?: string;
}

/**
 * Converts DD-MM-YYYY (Shamsi) to YYYY-MM-DD (Gregorian) for backend
 */
export function shamsiToGregorian(shamsiDate: string): string | null {
  if (!shamsiDate || !shamsiDate.trim()) return null;
  
  try {
    // Parse DD-MM-YYYY format
    const parts = shamsiDate.trim().split('-');
    if (parts.length !== 3) return null;
    
    const day = parseInt(parts[0], 10);
    const month = parseInt(parts[1], 10);
    const year = parseInt(parts[2], 10);
    
    if (isNaN(day) || isNaN(month) || isNaN(year)) return null;
    if (day < 1 || day > 31 || month < 1 || month > 12 || year < 1300 || year > 1500) return null;
    
    // Convert to Gregorian
    const gregorian = jalaali.toGregorian(year, month, day);
    const gYear = gregorian.gy;
    const gMonth = String(gregorian.gm).padStart(2, '0');
    const gDay = String(gregorian.gd).padStart(2, '0');
    
    return `${gYear}-${gMonth}-${gDay}`;
  } catch (error) {
    console.error('Error converting Shamsi to Gregorian:', error);
    return null;
  }
}

/**
 * Converts YYYY-MM-DD (Gregorian) to DD-MM-YYYY (Shamsi) for display
 */
export function gregorianToShamsi(gregorianDate: string): string | null {
  if (!gregorianDate || !gregorianDate.trim()) return null;
  
  try {
    // Parse YYYY-MM-DD format
    const parts = gregorianDate.trim().split('-');
    if (parts.length !== 3) return null;
    
    const year = parseInt(parts[0], 10);
    const month = parseInt(parts[1], 10);
    const day = parseInt(parts[2], 10);
    
    if (isNaN(year) || isNaN(month) || isNaN(day)) return null;
    
    // Convert to Shamsi
    const shamsi = jalaali.toJalaali(year, month, day);
    const sDay = String(shamsi.jd).padStart(2, '0');
    const sMonth = String(shamsi.jm).padStart(2, '0');
    const sYear = shamsi.jy;
    
    return `${sDay}-${sMonth}-${sYear}`;
  } catch (error) {
    console.error('Error converting Gregorian to Shamsi:', error);
    return null;
  }
}

/**
 * Validates DD-MM-YYYY format (Shamsi)
 */
export function validateShamsiDate(date: string): { valid: boolean; error?: string } {
  if (!date || !date.trim()) {
    return { valid: false, error: 'تاریخ الزامی است' };
  }
  
  const parts = date.trim().split('-');
  if (parts.length !== 3) {
    return { valid: false, error: 'فرمت تاریخ نامعتبر است. فرمت صحیح: DD-MM-YYYY' };
  }
  
  const day = parseInt(parts[0], 10);
  const month = parseInt(parts[1], 10);
  const year = parseInt(parts[2], 10);
  
  if (isNaN(day) || isNaN(month) || isNaN(year)) {
    return { valid: false, error: 'تاریخ باید عدد باشد' };
  }
  
  if (day < 1 || day > 31) {
    return { valid: false, error: 'روز باید بین 1 تا 31 باشد' };
  }
  
  if (month < 1 || month > 12) {
    return { valid: false, error: 'ماه باید بین 1 تا 12 باشد' };
  }
  
  if (year < 1300 || year > 1500) {
    return { valid: false, error: 'سال باید بین 1300 تا 1500 باشد' };
  }
  
  // Validate day is valid for the month
  const daysInMonth = jalaali.jalaaliMonthLength(year, month);
  if (day > daysInMonth) {
    return { valid: false, error: `روز ${day} برای ماه ${month} معتبر نیست` };
  }
  
  return { valid: true };
}

/**
 * Formats input to DD-MM-YYYY as user types
 */
function formatDateInput(input: string): string {
  // Remove all non-digits
  const digits = input.replace(/\D/g, '');
  
  if (digits.length === 0) return '';
  if (digits.length <= 2) return digits;
  if (digits.length <= 4) return `${digits.slice(0, 2)}-${digits.slice(2)}`;
  return `${digits.slice(0, 2)}-${digits.slice(2, 4)}-${digits.slice(4, 8)}`;
}

export default function ShamsiDatePickerDDMMYYYY({
  value,
  onChange,
  placeholder = 'DD-MM-YYYY',
  className,
  disabled = false,
  required = false,
  error,
}: ShamsiDatePickerDDMMYYYYProps) {
  const [open, setOpen] = useState(false);
  const [tempValue, setTempValue] = useState(value || '');
  const [validationError, setValidationError] = useState<string | undefined>(error);

  // Sync tempValue with value prop
  useEffect(() => {
    if (value !== undefined) {
      setTempValue(value);
    }
  }, [value]);

  // Sync error prop
  useEffect(() => {
    setValidationError(error);
  }, [error]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const formatted = formatDateInput(e.target.value);
    setTempValue(formatted);
    setValidationError(undefined);
  };

  const handleSelect = () => {
    const validation = validateShamsiDate(tempValue);
    if (!validation.valid) {
      setValidationError(validation.error);
      return;
    }
    
    onChange(tempValue);
    setOpen(false);
    setValidationError(undefined);
  };

  const handleClear = () => {
    setTempValue('');
    onChange('');
    setValidationError(undefined);
  };

  return (
    <div className="space-y-1">
      <Popover open={open} onOpenChange={setOpen}>
        <PopoverTrigger asChild>
          <Button
            type="button"
            variant="outline"
            className={cn(
              "w-full justify-between text-right",
              error || validationError ? "border-destructive" : "",
              className
            )}
            disabled={disabled}
            data-testid="button-shamsi-date-picker"
          >
            <Calendar className="ml-2 h-4 w-4" />
            <span className={cn(!value && "text-muted-foreground")}>
              {value || placeholder}
            </span>
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-auto p-4" align="start" dir="rtl">
          <div className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">تاریخ شمسی (DD-MM-YYYY)</label>
              <Input
                type="text"
                placeholder="13-11-1403"
                value={tempValue}
                onChange={handleInputChange}
                className="text-right font-mono"
                data-testid="input-shamsi-date"
                maxLength={10}
                dir="ltr"
              />
              <p className="text-xs text-muted-foreground">
                مثال: 13-11-1403 (روز-ماه-سال)
              </p>
            </div>
            {validationError && (
              <p className="text-xs text-destructive" data-testid="date-validation-error">
                {validationError}
              </p>
            )}
            <div className="flex gap-2 justify-end">
              <Button
                type="button"
                onClick={handleClear}
                variant="ghost"
                size="sm"
                data-testid="button-clear-date"
              >
                پاک کردن
              </Button>
              <Button
                type="button"
                onClick={handleSelect}
                size="sm"
                data-testid="button-confirm-date"
              >
                تایید
              </Button>
              <Button
                type="button"
                onClick={() => setOpen(false)}
                variant="outline"
                size="sm"
                data-testid="button-cancel-date"
              >
                لغو
              </Button>
            </div>
          </div>
        </PopoverContent>
      </Popover>
      {(error || validationError) && (
        <p className="text-xs text-destructive mt-1">
          {error || validationError}
        </p>
      )}
    </div>
  );
}

