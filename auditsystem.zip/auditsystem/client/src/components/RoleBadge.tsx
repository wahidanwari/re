import { Badge } from '@/components/ui/badge';
import { Shield, UserCog, Users, User } from 'lucide-react';
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from '@/components/ui/tooltip';

interface RoleBadgeProps {
  role: string;
  permissionPackages?: string[];
}

const roleNames: Record<string, { dari: string; icon: any }> = {
  system_admin: { dari: 'مدیر سیستم', icon: Shield },
  director: { dari: 'آمر بررسی', icon: UserCog },
  senior_auditor: { dari: 'مدیر عمومی گروه', icon: Users },
  auditor: { dari: 'بررس', icon: User },
};

const packageNames: Record<string, string> = {
  acting_coordinator: 'هماهنگ کننده موقت',
  approval_authority: 'صلاحیت منظوری',
};

export default function RoleBadge({ role, permissionPackages = [] }: RoleBadgeProps) {
  const roleInfo = roleNames[role] || roleNames.auditor;
  const Icon = roleInfo.icon;

  return (
    <div className="flex flex-col gap-2">
      <Tooltip>
        <TooltipTrigger asChild>
          <Badge variant="default" className="w-fit" data-testid="badge-role">
            <Icon className="ml-1 h-3 w-3" />
            {roleInfo.dari}
          </Badge>
        </TooltipTrigger>
        <TooltipContent>
          <p>نقش اصلی</p>
        </TooltipContent>
      </Tooltip>
      {permissionPackages.length > 0 && (
        <div className="flex flex-wrap gap-1">
          {permissionPackages.map((pkg) => (
            <Badge key={pkg} variant="secondary" className="text-xs" data-testid={`badge-package-${pkg}`}>
              {packageNames[pkg] || pkg}
            </Badge>
          ))}
        </div>
      )}
    </div>
  );
}
