/**
 * Installment Payments Component - Records and displays installment payments
 */

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Plus, Calendar, DollarSign } from 'lucide-react';
import ShamsiDatePickerDDMMYYYY, { shamsiToGregorian } from '@/components/ShamsiDatePickerDDMMYYYY';
import { Textarea } from '@/components/ui/textarea';
import jalaali from 'jalaali-js';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';

interface InstallmentPaymentsProps {
  caseId: string;
}


export default function InstallmentPayments({ caseId }: InstallmentPaymentsProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [formData, setFormData] = useState({
    payment_date: '',
    amount_paid: '',
    remaining_balance: '',
    notes: '',
  });

  // Fetch installment payments
  const { data: payments = [], refetch } = useQuery({
    queryKey: ['installments', caseId],
    queryFn: async () => {
      const response = await fetch(`/api/cases/${caseId}/installments`, {
        credentials: 'include',
      });
      if (!response.ok) return [];
      return response.json();
    },
    enabled: !!caseId,
  });

  const createPaymentMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      // Convert Shamsi date (DD-MM-YYYY) to ISO format (YYYY-MM-DD) for backend
      const isoDate = shamsiToGregorian(data.payment_date);
      if (!isoDate) {
        throw new Error('تاریخ پرداخت نامعتبر است');
      }
      
      const response = await fetch(`/api/cases/${caseId}/installments`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({
          payment_date: isoDate, // Send ISO format (YYYY-MM-DD)
          amount_paid: parseFloat(data.amount_paid) || 0,
          remaining_balance: parseFloat(data.remaining_balance) || 0,
          notes: data.notes || null,
        }),
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to create payment');
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['installments', caseId] });
      queryClient.invalidateQueries({ queryKey: ['case', caseId] });
      refetch();
      setDialogOpen(false);
      setFormData({
        payment_date: '',
        amount_paid: '',
        remaining_balance: '',
        notes: '',
      });
      toast({
        title: 'موفق',
        description: 'پرداخت قسط با موفقیت ثبت شد',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'خطا',
        description: error.message || 'خطا در ثبت پرداخت قسط',
        variant: 'destructive',
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.payment_date || !formData.amount_paid) {
      toast({
        title: 'خطا',
        description: 'لطفاً تاریخ پرداخت و مبلغ پرداخت شده را وارد کنید',
        variant: 'destructive',
      });
      return;
    }
    createPaymentMutation.mutate(formData);
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <DollarSign className="h-5 w-5" />
            پرداخت‌های قسط
          </CardTitle>
          <Button
            size="sm"
            onClick={() => setDialogOpen(true)}
          >
            <Plus className="h-4 w-4 mr-2" />
            ثبت پرداخت جدید
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {payments.length === 0 ? (
          <p className="text-sm text-muted-foreground text-center py-4">
            هیچ پرداخت قسطی ثبت نشده است
          </p>
        ) : (
          <div className="space-y-2">
            {payments.map((payment: any) => {
              // Handle both camelCase and snake_case field names
              const amountPaid = payment.amountPaid || payment.amount_paid || '0';
              const remainingBalance = payment.remainingBalance || payment.remaining_balance || '0';
              const paymentDate = payment.paymentDate || payment.payment_date;
              
              // Parse date - handle Date object, ISO string, or timestamp
              let dateDisplay = 'تاریخ نامعتبر';
              if (paymentDate) {
                try {
                  const date = paymentDate instanceof Date 
                    ? paymentDate 
                    : new Date(paymentDate);
                  if (!isNaN(date.getTime())) {
                    // Use jalaali-js for proper Shamsi date formatting
                    const jDate = jalaali.toJalaali(date);
                    const monthNames = ['حمل', 'ثور', 'جوزا', 'سرطان', 'اسد', 'سنبله', 'میزان', 'عقرب', 'قوس', 'جدی', 'دلو', 'حوت'];
                    dateDisplay = `${jDate.jd} ${monthNames[jDate.jm - 1]} ${jDate.jy}`;
                  }
                } catch (e) {
                  console.error('Error parsing payment date:', e);
                }
              }
              
              // Parse numeric values - handle string or number
              const amountPaidNum = typeof amountPaid === 'string' 
                ? parseFloat(amountPaid) 
                : (typeof amountPaid === 'number' ? amountPaid : 0);
              const remainingBalanceNum = typeof remainingBalance === 'string'
                ? parseFloat(remainingBalance)
                : (typeof remainingBalance === 'number' ? remainingBalance : 0);
              
              return (
                <div
                  key={payment.id}
                  className="flex items-start justify-between p-3 border rounded-lg"
                >
                  <div className="flex items-start gap-3 flex-1">
                    <Calendar className="h-4 w-4 text-muted-foreground mt-1" />
                    <div className="flex-1">
                      <p className="text-sm font-medium">
                        {dateDisplay}
                      </p>
                      <div className="mt-1 space-y-1">
                        <p className="text-xs text-muted-foreground">
                          مبلغ پرداخت شده: {isNaN(amountPaidNum) ? '۰' : amountPaidNum.toLocaleString('fa-IR')} افغانی
                        </p>
                        {remainingBalanceNum > 0 && (
                          <p className="text-xs text-muted-foreground">
                            مانده باقی‌مانده: {remainingBalanceNum.toLocaleString('fa-IR')} افغانی
                          </p>
                        )}
                        {payment.notes && (
                          <p className="text-xs text-muted-foreground mt-1">
                            یادداشت: {payment.notes}
                          </p>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </CardContent>

      {/* Add Payment Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>ثبت پرداخت قسط جدید</DialogTitle>
            <DialogDescription>
              اطلاعات پرداخت قسط را وارد کنید
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSubmit}>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="payment-date">تاریخ پرداخت *</Label>
                <ShamsiDatePickerDDMMYYYY
                  value={formData.payment_date}
                  onChange={(date) => setFormData({ ...formData, payment_date: date })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="amount_paid">مبلغ پرداخت شده (افغانی) *</Label>
                <Input
                  id="amount_paid"
                  type="number"
                  step="0.01"
                  value={formData.amount_paid}
                  onChange={(e) => setFormData({ ...formData, amount_paid: e.target.value })}
                  className="text-right"
                  dir="ltr"
                  placeholder="0.00"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="remaining_balance">مانده باقی‌مانده (افغانی)</Label>
                <Input
                  id="remaining_balance"
                  type="number"
                  step="0.01"
                  value={formData.remaining_balance}
                  onChange={(e) => setFormData({ ...formData, remaining_balance: e.target.value })}
                  className="text-right"
                  dir="ltr"
                  placeholder="0.00"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="notes">یادداشت (اختیاری)</Label>
                <Textarea
                  id="notes"
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  className="text-right"
                  dir="rtl"
                  placeholder="یادداشت اضافی..."
                  rows={3}
                />
              </div>
            </div>
            <DialogFooter className="mt-6">
              <Button
                type="button"
                variant="outline"
                onClick={() => {
                  setDialogOpen(false);
                  setFormData({
                    payment_date: '',
                    amount_paid: '',
                    remaining_balance: '',
                    notes: '',
                  });
                }}
                disabled={createPaymentMutation.isPending}
              >
                لغو
              </Button>
              <Button
                type="submit"
                disabled={createPaymentMutation.isPending}
              >
                {createPaymentMutation.isPending ? 'در حال ثبت...' : 'ثبت پرداخت'}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </Card>
  );
}

