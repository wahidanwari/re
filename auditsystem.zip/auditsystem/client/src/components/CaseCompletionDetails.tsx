/**
 * Case Completion Details Component
 * Displays completion information for completed cases
 */

import { useQuery } from '@tanstack/react-query';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Loader2, CheckCircle, DollarSign, Calendar, User, FileText } from 'lucide-react';
import jalaali from 'jalaali-js';
import type { Case, User as UserType } from '@shared/schema';

interface CaseCompletionDetailsProps {
  caseId: string;
  caseData: Case;
  users: UserType[];
}

export default function CaseCompletionDetails({
  caseId,
  caseData,
  users,
}: CaseCompletionDetailsProps) {
  // Fetch financial information
  const { data: financialInfo, isLoading: isLoadingFinancial } = useQuery<any>({
    queryKey: ['case-financial', caseId],
    queryFn: async () => {
      const response = await fetch(`/api/cases/${caseId}/financial`, {
        credentials: 'include',
      });
      if (!response.ok) {
        throw new Error('Failed to fetch financial information');
      }
      return response.json();
    },
    enabled: !!caseId,
  });

  // Fetch payment history to check for installments
  const { data: payments = [] } = useQuery<any[]>({
    queryKey: ['case-payments', caseId],
    queryFn: async () => {
      const response = await fetch(`/api/cases/${caseId}/payments`, {
        credentials: 'include',
      });
      if (!response.ok) {
        return [];
      }
      return response.json();
    },
    enabled: !!caseId,
  });

  // Get completed by user
  const completedByUser = caseData.completedBy
    ? users.find(u => u.id === caseData.completedBy)
    : null;

  // Format date
  const formatDate = (date: Date | string | null | undefined) => {
    if (!date) return '-';
    try {
      const dateObj = date instanceof Date ? date : new Date(date);
      if (isNaN(dateObj.getTime())) return '-';
      const jDate = jalaali.toJalaali(dateObj);
      const monthNames = ['حمل', 'ثور', 'جوزا', 'سرطان', 'اسد', 'سنبله', 'میزان', 'عقرب', 'قوس', 'جدی', 'دلو', 'حوت'];
      return `${jDate.jd} ${monthNames[jDate.jm - 1]} ${jDate.jy}`;
    } catch {
      return '-';
    }
  };

  // Format currency
  const formatCurrency = (amount: number | string | null | undefined) => {
    const num = typeof amount === 'string' ? parseFloat(amount) || 0 : (typeof amount === 'number' ? amount : 0);
    return new Intl.NumberFormat('fa-IR').format(num);
  };

  // Determine completion type
  const getCompletionType = () => {
    if (!financialInfo) return null;
    
    const confirmedAmount = financialInfo.confirmedAmount || 0;
    const totalPaid = financialInfo.totalPaid || 0;
    const remainingBalance = financialInfo.remainingBalance || 0;

    // Check if there are installment payments
    const hasInstallmentPayments = payments.some(p => p.paymentType === 'installment');

    // If no remaining balance, it's fully paid
    if (remainingBalance === 0 || remainingBalance < 0.01) {
      return 'تکمیل با پرداخت کامل';
    }
    
    // If there are installment payments, it's completed with installments
    if (hasInstallmentPayments) {
      return 'تکمیل با اقساط';
    }
    
    // Otherwise, it's completed with remaining debt
    return 'تکمیل با بدهی باقی‌مانده';
  };

  // Determine financial follow-up status
  const getFinancialFollowUpStatus = () => {
    if (!financialInfo) return null;
    
    const remainingBalance = financialInfo.remainingBalance || 0;

    // If no remaining balance, financial follow-up is complete
    if (remainingBalance === 0 || remainingBalance < 0.01) {
      return { status: 'تکمیل مالی', hasLink: false };
    }
    
    // Otherwise, it's in installments/follow-up
    return { status: 'در اقساط', hasLink: true };
  };

  const completionType = getCompletionType();
  const followUpStatus = getFinancialFollowUpStatus();

  if (isLoadingFinancial) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <CheckCircle className="h-5 w-5" />
            جزئیات تکمیل قضیه
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center p-4">
            <Loader2 className="h-5 w-5 animate-spin" />
            <span className="mr-2">در حال بارگذاری...</span>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <CheckCircle className="h-5 w-5" />
          جزئیات تکمیل قضیه
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Completion Date */}
        <div className="grid grid-cols-2 gap-4">
          <div>
            <Label className="flex items-center gap-2 mb-2">
              <Calendar className="h-4 w-4" />
              تاریخ تکمیل قضیه
            </Label>
            <p className="text-sm font-medium">
              {formatDate(caseData.completedAt)}
            </p>
          </div>

          {/* Completed By */}
          <div>
            <Label className="flex items-center gap-2 mb-2">
              <User className="h-4 w-4" />
              تکمیل‌شده توسط
            </Label>
            <p className="text-sm font-medium">
              {completedByUser ? (
                <span>
                  {completedByUser.fullName}
                  {completedByUser.role && (
                    <Badge variant="outline" className="mr-2 text-xs">
                      {completedByUser.role === 'auditor' ? 'بررس' : 
                       completedByUser.role === 'senior_auditor' ? 'بررس ارشد' :
                       completedByUser.role === 'system_admin' ? 'مدیر سیستم' :
                       completedByUser.role}
                    </Badge>
                  )}
                </span>
              ) : (
                '-'
              )}
            </p>
          </div>
        </div>

        {/* Completion Type */}
        <div>
          <Label className="flex items-center gap-2 mb-2">
            <FileText className="h-4 w-4" />
            نوع تکمیل
          </Label>
          <p className="text-sm font-medium">
            {completionType || '-'}
          </p>
        </div>

        {/* Financial Status at Completion */}
        {financialInfo && (
          <div>
            <Label className="flex items-center gap-2 mb-2">
              <DollarSign className="h-4 w-4" />
              وضعیت مالی هنگام تکمیل
            </Label>
            <div className="space-y-2 p-3 bg-muted rounded-lg">
              <div className="flex flex-row-reverse justify-between items-center">
                <span className="text-sm font-medium">
                  {formatCurrency(financialInfo.confirmedAmount || 0)} افغانی
                </span>
                <span className="text-sm text-muted-foreground">مبلغ تثبیت شده:</span>
              </div>
              <div className="flex flex-row-reverse justify-between items-center">
                <span className="text-sm font-medium">
                  {formatCurrency(financialInfo.totalPaid || 0)} افغانی
                </span>
                <span className="text-sm text-muted-foreground">مبلغ تحصیل‌شده تا زمان تکمیل:</span>
              </div>
              <div className="flex flex-row-reverse justify-between items-center">
                <span className={`text-sm font-medium ${(financialInfo.remainingBalance || 0) > 0 ? 'text-orange-600 dark:text-orange-400' : 'text-green-600 dark:text-green-400'}`}>
                  {formatCurrency(financialInfo.remainingBalance || 0)} افغانی
                </span>
                <span className="text-sm text-muted-foreground">مبلغ باقی‌مانده:</span>
              </div>
            </div>
          </div>
        )}

        {/* Financial Follow-Up Status */}
        {followUpStatus && (
          <div>
            <Label className="flex items-center gap-2 mb-2">
              <DollarSign className="h-4 w-4" />
              وضعیت پیگیری مالی
            </Label>
            <div className="flex items-center gap-2">
              <Badge 
                variant={followUpStatus.status === 'تکمیل مالی' ? 'default' : 'secondary'}
                className="text-sm"
              >
                {followUpStatus.status}
              </Badge>
              {followUpStatus.hasLink && (
                <span className="text-xs text-muted-foreground">
                  (قابل مشاهده در تب "قضایای در اقساط")
                </span>
              )}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

