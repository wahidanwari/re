import { useState, useEffect } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { AlertCircle } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';

interface ChangePasswordDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess?: (newPassword: string) => void;
  required?: boolean;
  currentPasswordValue?: string;
}

export default function ChangePasswordDialog({ 
  open, 
  onOpenChange, 
  onSuccess,
  required = false,
  currentPasswordValue = '' 
}: ChangePasswordDialogProps) {
  const [currentPassword, setCurrentPassword] = useState(currentPasswordValue);
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  // Sync current password state with prop value
  useEffect(() => {
    if (currentPasswordValue) {
      setCurrentPassword(currentPasswordValue);
    }
  }, [currentPasswordValue]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (newPassword !== confirmPassword) {
      toast({
        title: 'خطا',
        description: 'رمز عبور جدید و تایید آن مطابقت ندارند',
        variant: 'destructive',
      });
      return;
    }

    if (newPassword.length < 8) {
      toast({
        title: 'خطا',
        description: 'رمز عبور جدید باید حداقل ۸ کاراکتر باشد',
        variant: 'destructive',
      });
      return;
    }

    setLoading(true);

    try {
      const response = await fetch('/api/auth/change-password', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ currentPassword, newPassword }),
        credentials: 'include',
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'تغییر رمز عبور با مشکل مواجه شد');
      }

      toast({
        title: 'موفق',
        description: 'رمز عبور با موفقیت تغییر یافت',
      });

      const passwordToReturn = newPassword;
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
      onOpenChange(false);
      
      if (onSuccess) {
        onSuccess(passwordToReturn);
      }
    } catch (error: any) {
      toast({
        title: 'خطا',
        description: error.message || 'تغییر رمز عبور با مشکل مواجه شد',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={required ? undefined : onOpenChange}>
      <DialogContent className="max-w-md" onPointerDownOutside={(e) => required && e.preventDefault()}>
        <DialogHeader>
          <DialogTitle>تغییر رمز عبور</DialogTitle>
          {required && (
            <DialogDescription>
              شما باید رمز عبور خود را تغییر دهید تا بتوانید ادامه دهید.
            </DialogDescription>
          )}
        </DialogHeader>

        {required && (
          <Alert>
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              رمز عبور شما منقضی شده است یا باید تغییر یابد. لطفا یک رمز عبور جدید انتخاب کنید.
            </AlertDescription>
          </Alert>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          {!currentPasswordValue && (
            <div className="space-y-2">
              <Label htmlFor="currentPassword">رمز عبور فعلی *</Label>
              <Input
                id="currentPassword"
                type="password"
                value={currentPassword}
                onChange={(e) => setCurrentPassword(e.target.value)}
                className="text-right"
                required
                autoComplete="current-password"
              />
            </div>
          )}

          <div className="space-y-2">
            <Label htmlFor="newPassword">رمز عبور جدید *</Label>
            <Input
              id="newPassword"
              type="password"
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              className="text-right"
              required
              minLength={8}
              autoComplete="new-password"
            />
            <p className="text-xs text-muted-foreground">حداقل ۸ کاراکتر</p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="confirmPassword">تایید رمز عبور جدید *</Label>
            <Input
              id="confirmPassword"
              type="password"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              className="text-right"
              required
              minLength={8}
              autoComplete="new-password"
            />
          </div>

          <div className="flex gap-2 justify-end pt-4">
            {!required && (
              <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
                لغو
              </Button>
            )}
            <Button type="submit" disabled={loading}>
              {loading ? 'در حال تغییر...' : 'تغییر رمز عبور'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
