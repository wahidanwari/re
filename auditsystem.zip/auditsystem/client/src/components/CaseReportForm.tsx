import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import ShamsiDatePickerDDMMYYYY from '@/components/ShamsiDatePickerDDMMYYYY';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import type { Case } from '@shared/schema';

interface CaseReportFormProps {
  caseData: Case;
  onSave: (reportData: any) => Promise<void>;
  onCancel: () => void;
  initialData?: any;
}

export default function CaseReportForm({ caseData, onSave, onCancel, initialData }: CaseReportFormProps) {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    // Section 1: Entity Details
    companyName: initialData?.companyName || caseData.companyName || '',
    tin: initialData?.tin || caseData.tin || '',
    businessNature: initialData?.businessNature || caseData.businessNature || '',
    groupReferrer: initialData?.groupReferrer || caseData.groupReferrer || '',
    referralDate: initialData?.referralDate || caseData.referralDate || '',
    periodsUnderReview: initialData?.periodsUnderReview || caseData.periodsUnderReview || '',
    finalDocumentDate: initialData?.finalDocumentDate || '',
    capitalPeriod: initialData?.capitalPeriod || '',
    
    // Section 2: Extractions
    salaryTax: initialData?.salaryTax || '',
    rentTax: initialData?.rentTax || '',
    contractTax: initialData?.contractTax || '',
    profitTransactionTax: initialData?.profitTransactionTax || '',
    incomeTax: initialData?.incomeTax || '',
    reducedLoss: initialData?.reducedLoss || '',
    reducedRemainingAmount: initialData?.reducedRemainingAmount || '',
    confirmedAmount: initialData?.confirmedAmount || '',
    collectedCurrentMonth: initialData?.collectedCurrentMonth || '',
    remainingCollectible: initialData?.remainingCollectible || '',
    activityStatus: initialData?.activityStatus || '',
    attachmentNumber: initialData?.attachmentNumber || caseData.transactionId || '',
    attachmentDate: initialData?.attachmentDate || '',
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      // Validate required fields
      const requiredFields = [
        { key: 'companyName', label: 'نام نهاد' },
        { key: 'tin', label: 'نمبر تشخیصیه' },
        { key: 'businessNature', label: 'نوع تشبث' },
        { key: 'groupReferrer', label: 'آمریت ارجاع کننده' },
        { key: 'referralDate', label: 'تاریخ ارجاع شده' },
        { key: 'periodsUnderReview', label: 'سال‌های بررسی' },
        { key: 'finalDocumentDate', label: 'تاریخ صادره مکتوب نهایی' },
        { key: 'capitalPeriod', label: 'دوران سرمایه' },
        { key: 'salaryTax', label: 'مالیه موضوعی معاشات' },
        { key: 'rentTax', label: 'مالیه موضوعی بر کرایه' },
        { key: 'contractTax', label: 'مالیه موضوعی قراردادی' },
        { key: 'profitTransactionTax', label: 'مالیات معاملات انتفاعی' },
        { key: 'incomeTax', label: 'مالیات بر عایدات' },
        { key: 'reducedLoss', label: 'ضرر کاهش یافته' },
        { key: 'reducedRemainingAmount', label: 'مبلغ فاضل تحویل کاهش یافته' },
        { key: 'confirmedAmount', label: 'مبلغ تثبیت شده' },
        { key: 'collectedCurrentMonth', label: 'مبلغ تحصیل شده طی برج جاری' },
        { key: 'remainingCollectible', label: 'الباقی مبلغ قابل تحصیل' },
        { key: 'activityStatus', label: 'وضعیت فعالیت' },
        { key: 'attachmentNumber', label: 'نمبر آویز' },
        { key: 'attachmentDate', label: 'تاریخ آویز' },
      ];

      const missingFields = requiredFields.filter(
        field => !formData[field.key as keyof typeof formData] || 
        String(formData[field.key as keyof typeof formData]).trim() === ''
      );

      if (missingFields.length > 0) {
        toast({
          title: 'خطا',
          description: `لطفاً تمام فیلدهای الزامی را پر کنید:\n${missingFields.map(f => f.label).join('، ')}`,
          variant: 'destructive',
        });
        setLoading(false);
        return;
      }

      await onSave(formData);
      toast({
        title: 'موفق',
        description: 'گزارش قضیه با موفقیت ذخیره شد',
      });
    } catch (error: any) {
      toast({
        title: 'خطا',
        description: error.message || 'ذخیره گزارش با مشکل مواجه شد',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6" dir="rtl">
      {/* Section 1: مشخصات نهاد */}
      <Card>
        <CardHeader>
          <CardTitle className="text-xl font-bold">مشخصات نهاد</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="companyName">نام نهاد *</Label>
              <Input
                id="companyName"
                value={formData.companyName}
                onChange={(e) => setFormData({ ...formData, companyName: e.target.value })}
                className="text-right"
                required
                disabled
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="tin">نمبر تشخیصیه *</Label>
              <Input
                id="tin"
                value={formData.tin}
                onChange={(e) => setFormData({ ...formData, tin: e.target.value })}
                className="text-right"
                required
                disabled
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="businessNature">نوع تشبث *</Label>
              <Input
                id="businessNature"
                value={formData.businessNature}
                onChange={(e) => setFormData({ ...formData, businessNature: e.target.value })}
                className="text-right"
                required
                disabled
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="groupReferrer">آمریت ارجاع کننده *</Label>
              <Input
                id="groupReferrer"
                value={formData.groupReferrer}
                onChange={(e) => setFormData({ ...formData, groupReferrer: e.target.value })}
                className="text-right"
                required
                disabled
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="referralDate">تاریخ ارجاع شده *</Label>
              <Input
                id="referralDate"
                value={formData.referralDate}
                className="text-right"
                required
                disabled
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="periodsUnderReview">سال‌های بررسی *</Label>
              <Input
                id="periodsUnderReview"
                value={formData.periodsUnderReview}
                onChange={(e) => setFormData({ ...formData, periodsUnderReview: e.target.value })}
                className="text-right"
                required
                disabled
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="finalDocumentDate">تاریخ صادره مکتوب نهایی *</Label>
              <ShamsiDatePickerDDMMYYYY
                value={formData.finalDocumentDate}
                onChange={(date) => setFormData({ ...formData, finalDocumentDate: date })}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="capitalPeriod">دوران سرمایه *</Label>
              <Input
                id="capitalPeriod"
                value={formData.capitalPeriod}
                onChange={(e) => setFormData({ ...formData, capitalPeriod: e.target.value })}
                className="text-right"
                placeholder="مثال: دوران سرمایه اظهارنامه خودی"
                required
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Section 2: بیرون‌نویسی‌ها */}
      <Card>
        <CardHeader>
          <CardTitle className="text-xl font-bold">بیرون‌نویسی‌ها</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="salaryTax">مالیه موضوعی معاشات *</Label>
              <Input
                id="salaryTax"
                type="text"
                value={formData.salaryTax}
                onChange={(e) => setFormData({ ...formData, salaryTax: e.target.value })}
                className="text-right"
                placeholder="0"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="rentTax">مالیه موضوعی بر کرایه *</Label>
              <Input
                id="rentTax"
                type="text"
                value={formData.rentTax}
                onChange={(e) => setFormData({ ...formData, rentTax: e.target.value })}
                className="text-right"
                placeholder="0"
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="contractTax">مالیه موضوعی قراردادی *</Label>
              <Input
                id="contractTax"
                type="text"
                value={formData.contractTax}
                onChange={(e) => setFormData({ ...formData, contractTax: e.target.value })}
                className="text-right"
                placeholder="0"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="profitTransactionTax">مالیات معاملات انتفاعی *</Label>
              <Input
                id="profitTransactionTax"
                type="text"
                value={formData.profitTransactionTax}
                onChange={(e) => setFormData({ ...formData, profitTransactionTax: e.target.value })}
                className="text-right"
                placeholder="0"
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="incomeTax">مالیات بر عایدات *</Label>
              <Input
                id="incomeTax"
                type="text"
                value={formData.incomeTax}
                onChange={(e) => setFormData({ ...formData, incomeTax: e.target.value })}
                className="text-right"
                placeholder="0"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="reducedLoss">ضرر کاهش یافته *</Label>
              <Input
                id="reducedLoss"
                type="text"
                value={formData.reducedLoss}
                onChange={(e) => setFormData({ ...formData, reducedLoss: e.target.value })}
                className="text-right"
                placeholder="0"
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="reducedRemainingAmount">مبلغ فاضل تحویل کاهش یافته *</Label>
              <Input
                id="reducedRemainingAmount"
                type="text"
                value={formData.reducedRemainingAmount}
                onChange={(e) => setFormData({ ...formData, reducedRemainingAmount: e.target.value })}
                className="text-right"
                placeholder="0"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="confirmedAmount">مبلغ تثبیت شده *</Label>
              <Input
                id="confirmedAmount"
                type="text"
                value={formData.confirmedAmount}
                onChange={(e) => setFormData({ ...formData, confirmedAmount: e.target.value })}
                className="text-right"
                placeholder="0"
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="collectedCurrentMonth">مبلغ تحصیل شده طی برج جاری *</Label>
              <Input
                id="collectedCurrentMonth"
                type="text"
                value={formData.collectedCurrentMonth}
                onChange={(e) => setFormData({ ...formData, collectedCurrentMonth: e.target.value })}
                className="text-right"
                placeholder="0"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="remainingCollectible">الباقی مبلغ قابل تحصیل *</Label>
              <Input
                id="remainingCollectible"
                type="text"
                value={formData.remainingCollectible}
                onChange={(e) => setFormData({ ...formData, remainingCollectible: e.target.value })}
                className="text-right"
                placeholder="0"
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="activityStatus">وضعیت فعالیت *</Label>
              <Select
                value={formData.activityStatus}
                onValueChange={(value) => setFormData({ ...formData, activityStatus: value })}
                required
              >
                <SelectTrigger id="activityStatus" className="text-right">
                  <SelectValue placeholder="انتخاب کنید" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="فعال">فعال</SelectItem>
                  <SelectItem value="عدم فعالیت">عدم فعالیت</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="attachmentNumber">نمبر آویز *</Label>
              <Input
                id="attachmentNumber"
                value={formData.attachmentNumber}
                onChange={(e) => setFormData({ ...formData, attachmentNumber: e.target.value })}
                className="text-right"
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="attachmentDate">تاریخ آویز *</Label>
              <ShamsiDatePickerDDMMYYYY
                value={formData.attachmentDate}
                onChange={(date) => setFormData({ ...formData, attachmentDate: date })}
                required
              />
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="flex gap-2 justify-end">
        <Button type="button" variant="outline" onClick={onCancel} disabled={loading}>
          لغو
        </Button>
        <Button type="submit" disabled={loading}>
          {loading ? 'در حال ذخیره...' : 'ذخیره و ادامه'}
        </Button>
      </div>
    </form>
  );
}

