import { useState } from 'react';
import { Bell } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';

interface Notification {
  id: string;
  message: string;
  timestamp: string;
  isRead: boolean;
}

export default function NotificationBell() {
  const [notifications] = useState<Notification[]>([
    {
      id: '1',
      message: 'قضیه جدید AUDCASE-00123 به شما اختصاص داده شد',
      timestamp: '۱۴۰۳/۱۱/۱۳ - ۱۰:۳۰',
      isRead: false,
    },
    {
      id: '2',
      message: 'تکت تاییدیه TKT-00456 منتظر بررسی شماست',
      timestamp: '۱۴۰۳/۱۱/۱۲ - ۱۵:۲۰',
      isRead: false,
    },
    {
      id: '3',
      message: 'گزارش ماهانه گروه پنجم آماده شد',
      timestamp: '۱۴۰۳/۱۱/۱۱ - ۰۹:۱۵',
      isRead: true,
    },
  ]);

  const unreadCount = notifications.filter(n => !n.isRead).length;

  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button variant="ghost" size="icon" className="relative" data-testid="button-notifications">
          <Bell className="h-5 w-5" />
          {unreadCount > 0 && (
            <span className="absolute top-1 left-1 h-2 w-2 rounded-full bg-destructive" />
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-96" align="start">
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-medium">اعلانات</h3>
            <Button variant="ghost" size="sm" data-testid="button-mark-all-read">
              علامت زدن همه به عنوان خوانده شده
            </Button>
          </div>
          <ScrollArea className="h-[300px]">
            <div className="space-y-2">
              {notifications.map((notif) => (
                <div
                  key={notif.id}
                  className={`flex gap-3 p-3 rounded-md hover-elevate ${
                    !notif.isRead ? 'bg-muted/50' : ''
                  }`}
                  data-testid={`notification-${notif.id}`}
                >
                  {!notif.isRead && (
                    <div className="h-2 w-2 mt-2 rounded-full bg-primary flex-shrink-0" />
                  )}
                  <div className="flex-1 min-w-0">
                    <p className="text-sm">{notif.message}</p>
                    <p className="text-xs text-muted-foreground mt-1">
                      {notif.timestamp}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </ScrollArea>
        </div>
      </PopoverContent>
    </Popover>
  );
}
