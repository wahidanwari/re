/**
 * Case Report Print View Component
 * Professional print-optimized layout matching official MoF reports
 * 100% RTL accurate
 */

import { useQuery } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { Loader2, Download, Printer } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import type { Case } from '@shared/schema';
import jalaali from 'jalaali-js';

interface CaseReportPrintViewProps {
  caseData: Case;
  onClose?: () => void;
}

/**
 * Format number with thousand separators (Persian)
 */
function formatNumber(num: number | string | null | undefined): string {
  if (num === null || num === undefined) return '0';
  const numValue = typeof num === 'string' ? parseFloat(num) : num;
  if (isNaN(numValue)) return '0';
  return numValue.toLocaleString('fa-IR');
}

/**
 * Format date to Shamsi (DD-MM-YYYY)
 */
function formatShamsiDate(date: string | Date | null | undefined): string {
  if (!date) return '';
  const dateObj = typeof date === 'string' ? new Date(date) : date;
  if (isNaN(dateObj.getTime())) return '';
  const j = jalaali.toJalaali(dateObj);
  return `${String(j.jd).padStart(2, '0')}-${String(j.jm).padStart(2, '0')}-${j.jy}`;
}

export default function CaseReportPrintView({ caseData, onClose }: CaseReportPrintViewProps) {
  const { toast } = useToast();

  // Fetch report data
  const { data: reportData, isLoading } = useQuery({
    queryKey: ['case-report-v2', caseData.id],
    queryFn: async () => {
      const response = await fetch(`/api/cases/${caseData.id}/report/v2`, {
        credentials: 'include',
      });
      if (!response.ok) throw new Error('Failed to fetch report');
      return response.json();
    },
    enabled: !!caseData.id,
  });

  // Download PDF
  const handleDownloadPDF = async () => {
    try {
      const response = await fetch(`/api/cases/${caseData.id}/report/v2/pdf`, {
        credentials: 'include',
      });

      if (!response.ok) {
        throw new Error('Failed to generate PDF');
      }

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `report-${caseData.caseId}.pdf`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);

      toast({
        title: 'موفق',
        description: 'PDF با موفقیت دانلود شد',
      });
    } catch (error) {
      toast({
        title: 'خطا',
        description: 'خطا در دانلود PDF',
        variant: 'destructive',
      });
    }
  };

  // Print
  const handlePrint = () => {
    window.print();
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center p-8">
        <Loader2 className="h-6 w-6 animate-spin" />
        <span className="mr-2">در حال بارگذاری...</span>
      </div>
    );
  }

  if (!reportData) {
    return (
      <div className="text-center p-8 text-muted-foreground">
        گزارش یافت نشد
      </div>
    );
  }

  const totalTax = Number(reportData.salaryTax || 0) + Number(reportData.rentTax || 0) +
    Number(reportData.contractTax || 0) + Number(reportData.profitTransactionTax || 0) +
    Number(reportData.incomeTax || 0) + Number(reportData.withholdingTax || 0) +
    Number(reportData.penaltyTax || 0) + Number(reportData.interest || 0) +
    Number(reportData.otherTaxes || 0);

  const documentsReviewed = Array.isArray(reportData.documentsReviewed) ? reportData.documentsReviewed : [];

  return (
    <div className="space-y-6 print:space-y-4" dir="rtl">
      {/* Print-only header with actions */}
      <div className="flex items-center justify-between print:hidden mb-6">
        <div className="flex items-center gap-2">
          <Badge variant={reportData.status === 'completed' ? 'default' : 'secondary'}>
            {reportData.status === 'completed' ? 'تکمیل شده' : reportData.status === 'locked' ? 'قفل شده' : 'پیش‌ نویس'}
          </Badge>
          <span className="text-sm text-muted-foreground">
            نسخه: {reportData.version}
          </span>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={handleDownloadPDF}>
            <Download className="ml-2 h-4 w-4" />
            دانلود PDF
          </Button>
          <Button variant="outline" onClick={handlePrint}>
            <Printer className="ml-2 h-4 w-4" />
            چاپ
          </Button>
          {onClose && (
            <Button variant="outline" onClick={onClose}>
              بستن
            </Button>
          )}
        </div>
      </div>

      {/* Report Content - Print Optimized */}
      <div className="print:bg-white print:p-8">
        {/* Header */}
        <div className="text-center mb-8 print:mb-6">
          <h1 className="text-2xl font-bold mb-2 print:text-xl">گزارش بررسی قضیه</h1>
          <div className="text-sm space-y-1">
            <p>نمبر قضیه: {caseData.caseId}</p>
            <p>تاریخ ارجاع: {formatShamsiDate(caseData.referralDate)}</p>
            <p>سال‌های بررسی: {caseData.periodsUnderReview}</p>
          </div>
        </div>

        {/* Section 1: Entity Details */}
        <section className="mb-8 print:mb-6">
          <h2 className="text-lg font-bold mb-4 print:text-base print:mb-2 border-b pb-2">
            بخش اول: مشخصات نهاد
          </h2>
          <div className="grid grid-cols-2 gap-4 print:gap-2 text-sm">
            <div>
              <span className="font-semibold">نام نهاد:</span> {reportData.companyName}
            </div>
            <div>
              <span className="font-semibold">نمبر تشخیصیه:</span> {reportData.tin}
            </div>
            {reportData.businessNature && (
              <div>
                <span className="font-semibold">نوع تشبث:</span> {reportData.businessNature}
              </div>
            )}
            <div>
              <span className="font-semibold">آمریت ارجاع کننده:</span> {reportData.groupReferrer}
            </div>
            <div>
              <span className="font-semibold">تاریخ ارجاع:</span> {formatShamsiDate(reportData.referralDate)}
            </div>
            <div>
              <span className="font-semibold">سال‌های بررسی:</span> {reportData.periodsUnderReview}
            </div>
            <div>
              <span className="font-semibold">تاریخ صادره مکتوب نهایی:</span> {formatShamsiDate(reportData.finalDocumentDate)}
            </div>
            {reportData.capitalPeriod && (
              <div>
                <span className="font-semibold">دوران سرمایه:</span> {reportData.capitalPeriod}
              </div>
            )}
          </div>

          {/* Address Information */}
          {(reportData.province || reportData.district || reportData.streetAddress) && (
            <div className="mt-4 print:mt-2">
              <h3 className="font-semibold mb-2 print:text-sm">اطلاعات آدرس:</h3>
              <div className="grid grid-cols-2 gap-4 print:gap-2 text-sm">
                {reportData.province && (
                  <div><span className="font-semibold">ولایت:</span> {reportData.province}</div>
                )}
                {reportData.district && (
                  <div><span className="font-semibold">ولسوالی:</span> {reportData.district}</div>
                )}
                {reportData.streetAddress && (
                  <div className="col-span-2">
                    <span className="font-semibold">آدرس:</span> {reportData.streetAddress}
                  </div>
                )}
                {reportData.postalCode && (
                  <div><span className="font-semibold">کد پستی:</span> {reportData.postalCode}</div>
                )}
                {reportData.phone && (
                  <div><span className="font-semibold">شماره تماس:</span> {reportData.phone}</div>
                )}
                {reportData.email && (
                  <div><span className="font-semibold">ایمیل:</span> {reportData.email}</div>
                )}
              </div>
            </div>
          )}

          {/* Registration Details */}
          {(reportData.registrationNumber || reportData.businessLicenseNumber) && (
            <div className="mt-4 print:mt-2">
              <h3 className="font-semibold mb-2 print:text-sm">جزئیات ثبت:</h3>
              <div className="grid grid-cols-2 gap-4 print:gap-2 text-sm">
                {reportData.registrationNumber && (
                  <div><span className="font-semibold">نمبر ثبت:</span> {reportData.registrationNumber}</div>
                )}
                {reportData.registrationDate && (
                  <div><span className="font-semibold">تاریخ ثبت:</span> {formatShamsiDate(reportData.registrationDate)}</div>
                )}
                {reportData.businessLicenseNumber && (
                  <div><span className="font-semibold">نمبر جواز فعالیت:</span> {reportData.businessLicenseNumber}</div>
                )}
                {reportData.businessLicenseDate && (
                  <div><span className="font-semibold">تاریخ جواز فعالیت:</span> {formatShamsiDate(reportData.businessLicenseDate)}</div>
                )}
              </div>
            </div>
          )}

          {/* Additional Entity Information (Read-only for historical accuracy) */}
          {(reportData.representative || reportData.representativeContactNumber || reportData.entityAddress) && (
            <div className="mt-4 print:mt-2">
              <h3 className="font-semibold mb-2 print:text-sm">اطلاعات تکمیلی نهاد:</h3>
              <div className="grid grid-cols-1 gap-4 print:gap-2 text-sm">
                {reportData.representative && (
                  <div><span className="font-semibold">نماینده:</span> {reportData.representative}</div>
                )}
                {reportData.representativeContactNumber && (
                  <div><span className="font-semibold">شماره تماس نماینده:</span> {reportData.representativeContactNumber}</div>
                )}
                {reportData.entityAddress && (
                  <div><span className="font-semibold">آدرس نهاد:</span> {reportData.entityAddress}</div>
                )}
              </div>
            </div>
          )}

          {/* Tax Information */}
          {(reportData.taxOffice || reportData.taxOfficeCode) && (
            <div className="mt-4 print:mt-2">
              <h3 className="font-semibold mb-2 print:text-sm">اطلاعات مالیاتی:</h3>
              <div className="grid grid-cols-2 gap-4 print:gap-2 text-sm">
                {reportData.taxOffice && (
                  <div><span className="font-semibold">دفتر مالیاتی:</span> {reportData.taxOffice}</div>
                )}
                {reportData.taxOfficeCode && (
                  <div><span className="font-semibold">کد دفتر مالیاتی:</span> {reportData.taxOfficeCode}</div>
                )}
                {reportData.taxRegistrationDate && (
                  <div><span className="font-semibold">تاریخ ثبت مالیاتی:</span> {formatShamsiDate(reportData.taxRegistrationDate)}</div>
                )}
              </div>
            </div>
          )}
        </section>

        <Separator className="print:hidden" />

        {/* Section 2: Extractions */}
        <section className="mb-8 print:mb-6">
          <h2 className="text-lg font-bold mb-4 print:text-base print:mb-2 border-b pb-2">
            بخش دوم: بیرون‌نویسی‌ها
          </h2>

          {/* Tax Types */}
          <div className="mb-4 print:mb-2">
            <h3 className="font-semibold mb-2 print:text-sm">انواع مالیات:</h3>
            <div className="grid grid-cols-2 gap-4 print:gap-2 text-sm">
              <div>مالیه موضوعی معاشات: <span className="font-semibold">{formatNumber(reportData.salaryTax)} افغانی</span></div>
              <div>مالیه موضوعی بر کرایه: <span className="font-semibold">{formatNumber(reportData.rentTax)} افغانی</span></div>
              <div>مالیه موضوعی قراردادی: <span className="font-semibold">{formatNumber(reportData.contractTax)} افغانی</span></div>
              <div>مالیات معاملات انتفاعی: <span className="font-semibold">{formatNumber(reportData.profitTransactionTax)} افغانی</span></div>
              <div>مالیات بر عایدات: <span className="font-semibold">{formatNumber(reportData.incomeTax)} افغانی</span></div>
              <div>مالیات کسر شده: <span className="font-semibold">{formatNumber(reportData.withholdingTax)} افغانی</span></div>
              <div>مالیات جریمه: <span className="font-semibold">{formatNumber(reportData.penaltyTax)} افغانی</span></div>
              <div>سود: <span className="font-semibold">{formatNumber(reportData.interest)} افغانی</span></div>
              <div>سایر مالیات‌ها: <span className="font-semibold">{formatNumber(reportData.otherTaxes)} افغانی</span></div>
            </div>
            <div className="mt-2 print:mt-1 text-sm font-bold">
              مجموع مالیات‌ها: {formatNumber(totalTax)} افغانی
            </div>
          </div>

          {/* Financial Calculations */}
          <div className="mb-4 print:mb-2">
            <h3 className="font-semibold mb-2 print:text-sm">محاسبات مالی:</h3>
            <div className="grid grid-cols-2 gap-4 print:gap-2 text-sm">
              <div>ضرر کاهش یافته: <span className="font-semibold">{formatNumber(reportData.reducedLoss)} افغانی</span></div>
              <div>مبلغ فاضل تحویل کاهش یافته: <span className="font-semibold">{formatNumber(reportData.reducedRemainingAmount)} افغانی</span></div>
              <div>مبلغ تثبیت شده: <span className="font-semibold">{formatNumber(reportData.confirmedAmount)} افغانی</span></div>
              <div>مبلغ تحصیل شده طی برج جاری: <span className="font-semibold">{formatNumber(reportData.collectedCurrentMonth)} افغانی</span></div>
              <div>الباقی مبلغ قابل تحصیل: <span className="font-semibold">{formatNumber(reportData.remainingCollectible)} افغانی</span></div>
            </div>
          </div>

          {/* Calculation Details */}
          {(reportData.taxBase || reportData.taxRate || reportData.calculationMethod) && (
            <div className="mb-4 print:mb-2">
              <h3 className="font-semibold mb-2 print:text-sm">جزئیات محاسبه:</h3>
              <div className="grid grid-cols-2 gap-4 print:gap-2 text-sm">
                {reportData.taxBase && (
                  <div>مبنا مالیاتی: <span className="font-semibold">{formatNumber(reportData.taxBase)} افغانی</span></div>
                )}
                {reportData.taxRate && (
                  <div>نرخ مالیاتی: <span className="font-semibold">{reportData.taxRate}%</span></div>
                )}
                {reportData.calculationMethod && (
                  <div className="col-span-2">روش محاسبه: <span className="font-semibold">{reportData.calculationMethod}</span></div>
                )}
              </div>
            </div>
          )}

          {/* Payment Information */}
          {(reportData.paymentMethod || reportData.paymentReferenceNumber) && (
            <div className="mb-4 print:mb-2">
              <h3 className="font-semibold mb-2 print:text-sm">اطلاعات پرداخت:</h3>
              <div className="grid grid-cols-2 gap-4 print:gap-2 text-sm">
                {reportData.paymentMethod && (
                  <div>روش پرداخت: <span className="font-semibold">{reportData.paymentMethod}</span></div>
                )}
                {reportData.paymentReferenceNumber && (
                  <div>نمبر مرجع پرداخت: <span className="font-semibold">{reportData.paymentReferenceNumber}</span></div>
                )}
                {reportData.paymentDate && (
                  <div>تاریخ پرداخت: <span className="font-semibold">{formatShamsiDate(reportData.paymentDate)}</span></div>
                )}
                {reportData.bankName && (
                  <div>نام بانک: <span className="font-semibold">{reportData.bankName}</span></div>
                )}
                {reportData.bankAccountNumber && (
                  <div>شماره حساب بانکی: <span className="font-semibold">{reportData.bankAccountNumber}</span></div>
                )}
                {reportData.bankBranch && (
                  <div>شعبه بانک: <span className="font-semibold">{reportData.bankBranch}</span></div>
                )}
              </div>
            </div>
          )}

          {/* Status & Attachment */}
          <div>
            <h3 className="font-semibold mb-2 print:text-sm">وضعیت و ضمیمه:</h3>
            <div className="grid grid-cols-2 gap-4 print:gap-2 text-sm">
              {reportData.activityStatus && (
                <div>وضعیت فعالیت: <span className="font-semibold">{reportData.activityStatus}</span></div>
              )}
              {reportData.attachmentNumber && (
                <div>نمبر آویز: <span className="font-semibold">{reportData.attachmentNumber}</span></div>
              )}
              {reportData.attachmentDate && (
                <div>تاریخ آویز: <span className="font-semibold">{formatShamsiDate(reportData.attachmentDate)}</span></div>
              )}
            </div>
          </div>
        </section>

        <Separator className="print:hidden" />

        {/* Section 3: Findings & Recommendations - Only show if any field has data */}
        {(reportData.findingsSummary || reportData.detailedFindings || reportData.riskAssessment || 
          reportData.recommendations || reportData.actionItems || reportData.followUpRequired) && (
          <>
            <section className="mb-8 print:mb-6">
              <h2 className="text-lg font-bold mb-4 print:text-base print:mb-2 border-b pb-2">
                بخش سوم: یافته‌ها و توصیه‌ها
              </h2>
              <div className="space-y-4 print:space-y-2 text-sm">
                {reportData.findingsSummary && (
                  <div>
                    <h3 className="font-semibold mb-2 print:text-sm">خلاصه یافته‌ها:</h3>
                    <p className="whitespace-pre-wrap">{reportData.findingsSummary}</p>
                  </div>
                )}
                {reportData.detailedFindings && (
                  <div>
                    <h3 className="font-semibold mb-2 print:text-sm">یافته‌های تفصیلی:</h3>
                    <p className="whitespace-pre-wrap">{reportData.detailedFindings}</p>
                  </div>
                )}
                {reportData.riskAssessment && (
                  <div>
                    <h3 className="font-semibold mb-2 print:text-sm">ارزیابی ریسک:</h3>
                    <p>{reportData.riskAssessment}</p>
                  </div>
                )}
                {reportData.recommendations && (
                  <div>
                    <h3 className="font-semibold mb-2 print:text-sm">توصیه‌ها:</h3>
                    <p className="whitespace-pre-wrap">{reportData.recommendations}</p>
                  </div>
                )}
                {reportData.actionItems && (
                  <div>
                    <h3 className="font-semibold mb-2 print:text-sm">اقدامات لازم:</h3>
                    <p className="whitespace-pre-wrap">{reportData.actionItems}</p>
                  </div>
                )}
                {reportData.followUpRequired && (
                  <div>
                    <h3 className="font-semibold mb-2 print:text-sm">نیاز به پیگیری:</h3>
                    <p>بله {reportData.followUpDate && `- تاریخ: ${formatShamsiDate(reportData.followUpDate)}`}</p>
                  </div>
                )}
              </div>
            </section>
            <Separator className="print:hidden" />
          </>
        )}

        {/* Section 4: Supporting Documents - Only show if any field has data */}
        {(reportData.documentReviewDate || documentsReviewed.length > 0 || reportData.missingDocuments || reportData.documentReviewNotes) && (
          <>
            <section className="mb-8 print:mb-6">
              <h2 className="text-lg font-bold mb-4 print:text-base print:mb-2 border-b pb-2">
                بخش چهارم: اسناد حمایوی
              </h2>
              <div className="space-y-4 print:space-y-2 text-sm">
                {reportData.documentReviewDate && (
                  <div>
                    <span className="font-semibold">تاریخ بررسی اسناد:</span> {formatShamsiDate(reportData.documentReviewDate)}
                  </div>
                )}
                {documentsReviewed.length > 0 && (
                  <div>
                    <h3 className="font-semibold mb-2 print:text-sm">اسناد بررسی شده:</h3>
                    <ul className="list-disc list-inside space-y-1">
                      {documentsReviewed.map((doc: any, index: number) => (
                        <li key={index}>{doc.name || doc}</li>
                      ))}
                    </ul>
                  </div>
                )}
                {reportData.missingDocuments && (
                  <div>
                    <h3 className="font-semibold mb-2 print:text-sm">اسناد ناقص:</h3>
                    <p className="whitespace-pre-wrap">{reportData.missingDocuments}</p>
                  </div>
                )}
                {reportData.documentReviewNotes && (
                  <div>
                    <h3 className="font-semibold mb-2 print:text-sm">ملاحظات بررسی اسناد:</h3>
                    <p className="whitespace-pre-wrap">{reportData.documentReviewNotes}</p>
                  </div>
                )}
              </div>
            </section>
            <Separator className="print:hidden" />
          </>
        )}

        {/* Section 5: Approval & Signatures */}
        <section className="mb-8 print:mb-6">
          <h2 className="text-lg font-bold mb-4 print:text-base print:mb-2 border-b pb-2">
            بخش پنجم: تایید و امضا
          </h2>
          <div className="space-y-4 print:space-y-2 text-sm">
            <div>
              <h3 className="font-semibold mb-2 print:text-sm">تهیه شده توسط:</h3>
              <p>نقش: {reportData.preparedByRole || 'نامشخص'}</p>
              {reportData.preparedAt && (
                <p>تاریخ: {formatShamsiDate(reportData.preparedAt)}</p>
              )}
            </div>
            {(reportData.reviewedBy || reportData.reviewedAt) && (
              <div>
                <h3 className="font-semibold mb-2 print:text-sm">بررسی شده توسط:</h3>
                {reportData.reviewedByRole && <p>نقش: {reportData.reviewedByRole}</p>}
                {reportData.reviewedAt && <p>تاریخ: {formatShamsiDate(reportData.reviewedAt)}</p>}
                {reportData.reviewNotes && (
                  <p className="mt-1">ملاحظات: {reportData.reviewNotes}</p>
                )}
              </div>
            )}
            {(reportData.approvedBy || reportData.approvedAt) && (
              <div>
                <h3 className="font-semibold mb-2 print:text-sm">تایید شده توسط:</h3>
                {reportData.approvedByRole && <p>نقش: {reportData.approvedByRole}</p>}
                {reportData.approvedAt && <p>تاریخ: {formatShamsiDate(reportData.approvedAt)}</p>}
              </div>
            )}
          </div>
        </section>
      </div>

      {/* Print Styles */}
      <style>{`
        @media print {
          body {
            background: white;
          }
          .print\\:hidden {
            display: none !important;
          }
          .print\\:bg-white {
            background: white !important;
          }
          .print\\:p-8 {
            padding: 2rem !important;
          }
          .print\\:mb-6 {
            margin-bottom: 1.5rem !important;
          }
          .print\\:mb-2 {
            margin-bottom: 0.5rem !important;
          }
          .print\\:mt-2 {
            margin-top: 0.5rem !important;
          }
          .print\\:gap-2 {
            gap: 0.5rem !important;
          }
          .print\\:text-xl {
            font-size: 1.25rem !important;
          }
          .print\\:text-base {
            font-size: 1rem !important;
          }
          .print\\:text-sm {
            font-size: 0.875rem !important;
          }
          .print\\:space-y-2 > * + * {
            margin-top: 0.5rem !important;
          }
          .print\\:space-y-4 > * + * {
            margin-top: 1rem !important;
          }
        }
      `}</style>
    </div>
  );
}

