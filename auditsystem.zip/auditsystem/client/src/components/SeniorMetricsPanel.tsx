/**
 * Senior Metrics Panel - Displays and allows editing of senior auditor reporting metrics
 * Only visible to senior_auditor and system_admin roles
 */

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Edit2, Save, X, History } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';

interface SeniorMetricsPanelProps {
  caseId: string;
  metrics?: {
    installments_this_month?: number;
    nonresponsive_count?: number;
    incoming_documents?: number;
    outgoing_documents?: number;
    incoming_inquiries?: number;
    outgoing_inquiries?: number;
    remarks?: string;
    last_updated_by?: string;
    last_updated_at?: string;
  } | null;
  onUpdate?: () => void;
}

export default function SeniorMetricsPanel({ caseId, metrics, onUpdate }: SeniorMetricsPanelProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isEditing, setIsEditing] = useState(false);
  const [showHistory, setShowHistory] = useState(false);
  const [formData, setFormData] = useState({
    installments_this_month: metrics?.installments_this_month || 0,
    nonresponsive_count: metrics?.nonresponsive_count || 0,
    incoming_documents: metrics?.incoming_documents || 0,
    outgoing_documents: metrics?.outgoing_documents || 0,
    incoming_inquiries: metrics?.incoming_inquiries || 0,
    outgoing_inquiries: metrics?.outgoing_inquiries || 0,
    remarks: metrics?.remarks || '',
  });

  const updateMetricsMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      const response = await fetch(`/api/cases/${caseId}/metrics`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(data),
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to update metrics');
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['case', caseId] });
      if (onUpdate) onUpdate();
      setIsEditing(false);
      toast({
        title: 'موفق',
        description: 'آمار با موفقیت بروزرسانی شد',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'خطا',
        description: error.message || 'خطا در بروزرسانی آمار',
        variant: 'destructive',
      });
    },
  });

  const handleSave = () => {
    updateMetricsMutation.mutate(formData);
  };

  const handleCancel = () => {
    setFormData({
      installments_this_month: metrics?.installments_this_month || 0,
      nonresponsive_count: metrics?.nonresponsive_count || 0,
      incoming_documents: metrics?.incoming_documents || 0,
      outgoing_documents: metrics?.outgoing_documents || 0,
      incoming_inquiries: metrics?.incoming_inquiries || 0,
      outgoing_inquiries: metrics?.outgoing_inquiries || 0,
      remarks: metrics?.remarks || '',
    });
    setIsEditing(false);
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>آمار و گزارش ویژه بازرس ارشد</CardTitle>
          <div className="flex gap-2">
            {!isEditing && (
              <>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => setIsEditing(true)}
                >
                  <Edit2 className="h-4 w-4 mr-2" />
                  ویرایش
                </Button>
                {metrics?.last_updated_at && (
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => setShowHistory(true)}
                  >
                    <History className="h-4 w-4 mr-2" />
                    تاریخچه
                  </Button>
                )}
              </>
            )}
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {isEditing ? (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="installments_this_month">تعداد نهاد/شرکت های قسط شده طی برج جاری</Label>
                <Input
                  id="installments_this_month"
                  type="number"
                  value={formData.installments_this_month}
                  onChange={(e) => setFormData({ ...formData, installments_this_month: parseInt(e.target.value) || 0 })}
                  className="text-right"
                  dir="ltr"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="nonresponsive_count">تعداد نهاد/شرکت های عدم اطاعت پذیر</Label>
                <Input
                  id="nonresponsive_count"
                  type="number"
                  value={formData.nonresponsive_count}
                  onChange={(e) => setFormData({ ...formData, nonresponsive_count: parseInt(e.target.value) || 0 })}
                  className="text-right"
                  dir="ltr"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="incoming_documents">تعداد مکتوب های وارده</Label>
                <Input
                  id="incoming_documents"
                  type="number"
                  value={formData.incoming_documents}
                  onChange={(e) => setFormData({ ...formData, incoming_documents: parseInt(e.target.value) || 0 })}
                  className="text-right"
                  dir="ltr"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="outgoing_documents">تعداد مکتوب های صادره</Label>
                <Input
                  id="outgoing_documents"
                  type="number"
                  value={formData.outgoing_documents}
                  onChange={(e) => setFormData({ ...formData, outgoing_documents: parseInt(e.target.value) || 0 })}
                  className="text-right"
                  dir="ltr"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="incoming_inquiries">تعداد استعلام های وارده</Label>
                <Input
                  id="incoming_inquiries"
                  type="number"
                  value={formData.incoming_inquiries}
                  onChange={(e) => setFormData({ ...formData, incoming_inquiries: parseInt(e.target.value) || 0 })}
                  className="text-right"
                  dir="ltr"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="outgoing_inquiries">تعداد استعلام های صادره</Label>
                <Input
                  id="outgoing_inquiries"
                  type="number"
                  value={formData.outgoing_inquiries}
                  onChange={(e) => setFormData({ ...formData, outgoing_inquiries: parseInt(e.target.value) || 0 })}
                  className="text-right"
                  dir="ltr"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="remarks">ملاحظات</Label>
              <Textarea
                id="remarks"
                value={formData.remarks}
                onChange={(e) => setFormData({ ...formData, remarks: e.target.value })}
                className="text-right"
                rows={3}
              />
            </div>
            <div className="flex gap-2 justify-end">
              <Button
                variant="outline"
                onClick={handleCancel}
                disabled={updateMetricsMutation.isPending}
              >
                <X className="h-4 w-4 mr-2" />
                لغو
              </Button>
              <Button
                onClick={handleSave}
                disabled={updateMetricsMutation.isPending}
              >
                <Save className="h-4 w-4 mr-2" />
                ذخیره
              </Button>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-muted-foreground">تعداد نهاد/شرکت های قسط شده طی برج جاری</Label>
                <p className="text-lg font-semibold">{metrics?.installments_this_month || 0}</p>
              </div>
              <div>
                <Label className="text-muted-foreground">تعداد نهاد/شرکت های عدم اطاعت پذیر</Label>
                <p className="text-lg font-semibold">{metrics?.nonresponsive_count || 0}</p>
              </div>
              <div>
                <Label className="text-muted-foreground">تعداد مکتوب های وارده</Label>
                <p className="text-lg font-semibold">{metrics?.incoming_documents || 0}</p>
              </div>
              <div>
                <Label className="text-muted-foreground">تعداد مکتوب های صادره</Label>
                <p className="text-lg font-semibold">{metrics?.outgoing_documents || 0}</p>
              </div>
              <div>
                <Label className="text-muted-foreground">تعداد استعلام های وارده</Label>
                <p className="text-lg font-semibold">{metrics?.incoming_inquiries || 0}</p>
              </div>
              <div>
                <Label className="text-muted-foreground">تعداد استعلام های صادره</Label>
                <p className="text-lg font-semibold">{metrics?.outgoing_inquiries || 0}</p>
              </div>
            </div>
            {metrics?.remarks && (
              <div>
                <Label className="text-muted-foreground">ملاحظات</Label>
                <p className="text-sm whitespace-pre-wrap">{metrics.remarks}</p>
              </div>
            )}
            {metrics?.last_updated_at && (
              <div className="text-xs text-muted-foreground">
                آخرین بروزرسانی: {new Date(metrics.last_updated_at).toLocaleDateString('fa-IR')}
              </div>
            )}
          </div>
        )}
      </CardContent>

      {/* History Dialog */}
      <Dialog open={showHistory} onOpenChange={setShowHistory}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>تاریخچه تغییرات آمار</DialogTitle>
            <DialogDescription>
              تاریخچه تغییرات آمار این قضیه
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-2">
            <p className="text-sm text-muted-foreground">
              تاریخچه تغییرات از طریق لاگ‌های سیستم قابل مشاهده است.
            </p>
            {metrics?.last_updated_at && (
              <div className="p-3 bg-muted rounded-lg">
                <p className="text-sm">
                  <strong>آخرین بروزرسانی:</strong> {new Date(metrics.last_updated_at).toLocaleDateString('fa-IR')}
                </p>
                {metrics.last_updated_by && (
                  <p className="text-sm text-muted-foreground">
                    توسط: {metrics.last_updated_by}
                  </p>
                )}
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowHistory(false)}>
              بستن
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  );
}

