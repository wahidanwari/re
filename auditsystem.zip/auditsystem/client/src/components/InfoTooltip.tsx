"use client"

import * as React from "react"
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip"
import { useLocale } from "@/contexts/LocaleContext"
import { Info } from "lucide-react"

interface InfoTooltipProps {
  content: {
    dari: string
    pashto?: string
    english?: string
  }
  side?: "top" | "right" | "bottom" | "left"
  align?: "start" | "center" | "end"
  children?: React.ReactNode
  iconOnly?: boolean
  className?: string
}

/**
 * Reusable tooltip component with multi-language support
 * Supports Dari, Pashto, and English based on current locale
 */
export function InfoTooltip({
  content,
  side = "top",
  align = "center",
  children,
  iconOnly = false,
  className = "",
}: InfoTooltipProps) {
  const { locale, t } = useLocale()

  // Determine which language to use
  let tooltipText = content.dari
  if (locale === "pashto" && content.pashto) {
    tooltipText = content.pashto
  } else if (locale === "english" && content.english) {
    tooltipText = content.english
  } else {
    // Fallback to Dari if specific language not available
    tooltipText = content.dari
  }

  // If iconOnly is true, show just an info icon
  const triggerContent = iconOnly ? (
    <Info className={`h-4 w-4 text-muted-foreground ${className}`} />
  ) : (
    children || <Info className={`h-4 w-4 text-muted-foreground ${className}`} />
  )

  return (
    <Tooltip>
      <TooltipTrigger asChild>
        {triggerContent}
      </TooltipTrigger>
      <TooltipContent side={side} align={align} className="max-w-xs">
        <p className="text-sm">{tooltipText}</p>
      </TooltipContent>
    </Tooltip>
  )
}

/**
 * Simple wrapper for tooltip on buttons/icons
 */
export function ButtonTooltip({
  content,
  side = "top",
  align = "center",
  children,
}: Omit<InfoTooltipProps, "iconOnly" | "className">) {
  return (
    <InfoTooltip content={content} side={side} align={align}>
      {children}
    </InfoTooltip>
  )
}

