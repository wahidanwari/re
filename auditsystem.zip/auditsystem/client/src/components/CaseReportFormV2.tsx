/**
 * Case Report Form V2 - Structured reporting with sections
 * Professional layout matching official MoF reports
 * 100% RTL accurate
 */

import { useState, useEffect, useCallback, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { useToast } from '@/hooks/use-toast';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import type { Case } from '@shared/schema';
import ShamsiDatePickerDDMMYYYY from '@/components/ShamsiDatePickerDDMMYYYY';
import { Save, CheckCircle, AlertCircle, Loader2, Eye, FileText } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import CaseReportPrintView from '@/components/CaseReportPrintView';
import { userHasPermission } from '@/utils/permissions';

interface CaseReportFormV2Props {
  caseData: Case;
  onSave?: (reportData: any) => Promise<void>;
  onCancel?: () => void;
  onComplete?: () => void;
}

interface ReportData {
  [key: string]: any;
}

export default function CaseReportFormV2({ caseData, onSave, onCancel, onComplete }: CaseReportFormV2Props) {
  const { toast } = useToast();
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [activeSection, setActiveSection] = useState('section_1');
  const [saveStatus, setSaveStatus] = useState<'idle' | 'saving' | 'saved' | 'error'>('idle');
  const [formData, setFormData] = useState<ReportData>({});
  const [validationErrors, setValidationErrors] = useState<Record<string, string>>({});
  const [sectionCompletion, setSectionCompletion] = useState<Record<string, boolean>>({});
  const [showPrintView, setShowPrintView] = useState(false);
  
  // Local state for number input fields to handle typing properly
  const [profitTransactionTaxInput, setProfitTransactionTaxInput] = useState<string>('');
  const [incomeTaxInput, setIncomeTaxInput] = useState<string>('');
  const [collectedCurrentMonthInput, setCollectedCurrentMonthInput] = useState<string>('');
  
  // Override fields state for entity data overrides
  const [overrideFields, setOverrideFields] = useState<{
    institutionInfo: { original: string; manual: string; editing: boolean };
    representativeName: { original: string; manual: string; editing: boolean };
    representativePhone: { original: string; manual: string; editing: boolean };
    institutionAddress: { original: string; manual: string; editing: boolean };
  }>({
    institutionInfo: { original: '', manual: '', editing: false },
    representativeName: { original: '', manual: '', editing: false },
    representativePhone: { original: '', manual: '', editing: false },
    institutionAddress: { original: '', manual: '', editing: false },
  });
  
  // Override metadata state
  const [overrideMetadata, setOverrideMetadata] = useState<{
    institutionInfo?: { by?: string; at?: string };
    representativeName?: { by?: string; at?: string };
    representativePhone?: { by?: string; at?: string };
    institutionAddress?: { by?: string; at?: string };
  }>({});

  // Fetch report schema for dynamic validation (Suggestion C - Auto-sync required fields)
  const { data: reportSchema } = useQuery({
    queryKey: ['report-schema-v2'],
    queryFn: async () => {
      const response = await fetch('/api/cases/schema/report/v2', {
        credentials: 'include',
      });
      if (!response.ok) return null;
      return response.json();
    },
    staleTime: 5 * 60 * 1000, // Cache for 5 minutes
  });

  // Fetch report data
  const { data: reportData, isLoading } = useQuery({
    queryKey: ['case-report-v2', caseData.id],
    queryFn: async () => {
      const response = await fetch(`/api/cases/${caseData.id}/report/v2`, {
        credentials: 'include',
      });
      if (!response.ok) throw new Error('Failed to fetch report');
      return response.json();
    },
    enabled: !!caseData.id,
  });

  // Fetch full case data to get override fields
  const { data: fullCaseData, refetch: refetchCase } = useQuery({
    queryKey: ['case', caseData.id],
    queryFn: async () => {
      const response = await fetch(`/api/cases/${caseData.id}`, {
        credentials: 'include',
      });
      if (!response.ok) throw new Error('Failed to fetch case');
      return response.json();
    },
    enabled: !!caseData.id,
  });


  // Fetch assigned user details for auto-filling reviewedByRole
  const { data: assignedUser } = useQuery({
    queryKey: ['user', caseData.assignedTo],
    queryFn: async () => {
      if (!caseData.assignedTo) return null;
      const response = await fetch(`/api/users/${caseData.assignedTo}`, {
        credentials: 'include',
      });
      if (!response.ok) return null;
      return response.json();
    },
    enabled: !!caseData.assignedTo,
  });

  // Track if formData has been initialized to prevent overwriting user input
  const formDataInitializedRef = useRef<string | null>(null);
  // Track if user has manually edited the three critical fields
  const userHasEditedFieldsRef = useRef<{
    profitTransactionTax: boolean;
    incomeTax: boolean;
    collectedCurrentMonth: boolean;
  }>({
    profitTransactionTax: false,
    incomeTax: false,
    collectedCurrentMonth: false,
  });
  
  // Initialize form data (only once per case, or when case changes)
  useEffect(() => {
    // Reset initialization flag when case changes
    if (formDataInitializedRef.current !== caseData.id) {
      formDataInitializedRef.current = null;
      // Reset edit flags when case changes
      userHasEditedFieldsRef.current = {
        profitTransactionTax: false,
        incomeTax: false,
        collectedCurrentMonth: false,
      };
    }
    
    if (reportData && formDataInitializedRef.current !== caseData.id) {
      setFormData(reportData);
      formDataInitializedRef.current = caseData.id;
      
      // Initialize local input states for number fields (always strings for input)
      // Only initialize if user hasn't manually edited these fields
      if (!userHasEditedFieldsRef.current.profitTransactionTax) {
        const profitTaxValue = reportData.profitTransactionTax != null ? String(reportData.profitTransactionTax) : '';
        const profitTaxDisplay = profitTaxValue === '0' || profitTaxValue === '0.00' ? '' : profitTaxValue;
        setProfitTransactionTaxInput(profitTaxDisplay);
        profitTransactionTaxInputRef.current = profitTaxDisplay; // Also update ref
      }
      if (!userHasEditedFieldsRef.current.incomeTax) {
        const incomeTaxValue = reportData.incomeTax != null ? String(reportData.incomeTax) : '';
        const incomeTaxDisplay = incomeTaxValue === '0' || incomeTaxValue === '0.00' ? '' : incomeTaxValue;
        setIncomeTaxInput(incomeTaxDisplay);
        incomeTaxInputRef.current = incomeTaxDisplay; // Also update ref
      }
      if (!userHasEditedFieldsRef.current.collectedCurrentMonth) {
        const collectedValue = reportData.collectedCurrentMonth != null ? String(reportData.collectedCurrentMonth) : '';
        const collectedDisplay = collectedValue === '0' || collectedValue === '0.00' ? '' : collectedValue;
        setCollectedCurrentMonthInput(collectedDisplay);
        collectedCurrentMonthInputRef.current = collectedDisplay; // Also update ref
      }
      
      // If report is completed, mark all sections as complete for UI
      if (reportData.status === 'completed') {
        setSectionCompletion({
          section_1: true,
          section_2: true,
          section_3: true,
          section_4: true,
          section_5: true,
        });
      }
    }
  }, [reportData, caseData.id]);

  // Initialize override fields from case data
  useEffect(() => {
    if (fullCaseData) {
      // Get entity data for original values
      const entity = fullCaseData.entity || {};
      
      setOverrideFields({
        institutionInfo: {
          original: fullCaseData.institutionInfoOriginal || 
                   (entity.registeredAddress ? `${entity.registeredAddress}\n${entity.contactPerson || ''}\n${entity.phone || ''}` : '') || '',
          manual: fullCaseData.institutionInfoManual || '',
          editing: false,
        },
        representativeName: {
          original: entity.contactPerson || formData.representative || '',
          manual: fullCaseData.representativeNameManual || '',
          editing: false,
        },
        representativePhone: {
          original: entity.phone || formData.representativeContactNumber || '',
          manual: fullCaseData.representativePhoneManual || '',
          editing: false,
        },
        institutionAddress: {
          original: entity.registeredAddress || formData.entityAddress || '',
          manual: fullCaseData.institutionAddressManual || '',
          editing: false,
        },
      });

      // Set override metadata
      if (fullCaseData.institutionInfoOverriddenBy || fullCaseData.institutionInfoOverriddenAt) {
        setOverrideMetadata(prev => ({
          ...prev,
          institutionInfo: {
            by: fullCaseData.institutionInfoOverriddenBy,
            at: fullCaseData.institutionInfoOverriddenAt,
          },
        }));
      }
    }
  }, [fullCaseData, formData]);
  
  // Check if report is completed (for editing)
  const isCompleted = reportData?.status === 'completed';
  const isLocked = reportData?.status === 'locked';

  // Auto-fill reviewedByRole from assigned user
  useEffect(() => {
    if (assignedUser && !formData.reviewedByRole) {
      setFormData(prev => ({
        ...prev,
        reviewedByRole: assignedUser.fullName || assignedUser.auditId || '',
      }));
    }
  }, [assignedUser, formData.reviewedByRole]);


  // Autosave with debouncing
  const autosaveTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  
  // Use refs to store the latest local state values to avoid stale closures
  const profitTransactionTaxInputRef = useRef<string>('');
  const incomeTaxInputRef = useRef<string>('');
  const collectedCurrentMonthInputRef = useRef<string>('');
  
  // Update refs whenever local state changes
  useEffect(() => {
    profitTransactionTaxInputRef.current = profitTransactionTaxInput;
  }, [profitTransactionTaxInput]);
  
  useEffect(() => {
    incomeTaxInputRef.current = incomeTaxInput;
  }, [incomeTaxInput]);
  
  useEffect(() => {
    collectedCurrentMonthInputRef.current = collectedCurrentMonthInput;
  }, [collectedCurrentMonthInput]);
  
  const debouncedSave = useCallback((data: ReportData, section?: string) => {
    if (autosaveTimeoutRef.current) {
      clearTimeout(autosaveTimeoutRef.current);
    }

    const timeout = setTimeout(async () => {
      setSaveStatus('saving');
      try {
        // Sync local input states to formData before saving
        // For required numeric fields, send 0 instead of null to pass validation
        // Always use ref values (latest local state) as source of truth for these three fields
        const profitTaxValue = profitTransactionTaxInputRef.current === '' ? 0 : (isNaN(parseFloat(profitTransactionTaxInputRef.current)) ? 0 : parseFloat(profitTransactionTaxInputRef.current));
        const incomeTaxValue = incomeTaxInputRef.current === '' ? 0 : (isNaN(parseFloat(incomeTaxInputRef.current)) ? 0 : parseFloat(incomeTaxInputRef.current));
        const collectedValue = collectedCurrentMonthInputRef.current === '' ? 0 : (isNaN(parseFloat(collectedCurrentMonthInputRef.current)) ? 0 : parseFloat(collectedCurrentMonthInputRef.current));
        
        const dataToSave = {
          ...data,
          // Always override with ref values (source of truth - always latest)
          profitTransactionTax: profitTaxValue,
          incomeTax: incomeTaxValue,
          collectedCurrentMonth: collectedValue,
        };
        
        // Debug logging
        console.log('[SAVE] Saving report with values:', {
          profitTransactionTax: profitTaxValue,
          incomeTax: incomeTaxValue,
          collectedCurrentMonth: collectedValue,
          profitTransactionTaxInput: profitTransactionTaxInputRef.current,
          incomeTaxInput: incomeTaxInputRef.current,
          collectedCurrentMonthInput: collectedCurrentMonthInputRef.current,
        });
        
        const response = await fetch(`/api/cases/${caseData.id}/report/v2/draft`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          credentials: 'include',
          body: JSON.stringify({ ...dataToSave, section }),
        });

        if (!response.ok) throw new Error('Failed to save');

        setSaveStatus('saved');
        // Don't invalidate query immediately - this causes useEffect to reset local state
        // The data is already saved, so we don't need to refetch immediately
        // This prevents overwriting user input that's still being typed
        // queryClient.invalidateQueries({ queryKey: ['case-report-v2', caseData.id] });
        
        // Hide "saved" indicator after 3 seconds
        setTimeout(() => setSaveStatus('idle'), 3000);
      } catch (error) {
        setSaveStatus('error');
        console.error('Autosave error:', error);
      }
    }, 2000); // 2 second debounce

    autosaveTimeoutRef.current = timeout;
  }, [caseData.id, queryClient]);

  // Immediate save function (for Confirm button)
  const saveImmediately = useCallback(async (data: ReportData, section?: string) => {
    setSaveStatus('saving');
    try {
      // Sync local input states to formData before saving
      // For required numeric fields, send 0 instead of null to pass validation
      // Use ref values to ensure we have the latest local state
      const dataToSave = {
        ...data,
        // Ensure number fields are synced from local state (use refs for latest values)
        // Required fields must be numbers (0 is valid, null is not)
        profitTransactionTax: profitTransactionTaxInputRef.current === '' ? 0 : (isNaN(parseFloat(profitTransactionTaxInputRef.current)) ? 0 : parseFloat(profitTransactionTaxInputRef.current)),
        incomeTax: incomeTaxInputRef.current === '' ? 0 : (isNaN(parseFloat(incomeTaxInputRef.current)) ? 0 : parseFloat(incomeTaxInputRef.current)),
        collectedCurrentMonth: collectedCurrentMonthInputRef.current === '' ? 0 : (isNaN(parseFloat(collectedCurrentMonthInputRef.current)) ? 0 : parseFloat(collectedCurrentMonthInputRef.current)),
      };
      
      const response = await fetch(`/api/cases/${caseData.id}/report/v2/draft`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ ...dataToSave, section }),
      });

      if (!response.ok) throw new Error('Failed to save');

        setSaveStatus('saved');
        // Don't invalidate query immediately - this causes useEffect to reset local state
        // Instead, let the next manual refresh or navigation handle the update
        // This prevents overwriting user input that hasn't been saved yet
        // queryClient.invalidateQueries({ queryKey: ['case-report-v2', caseData.id] });
        
        // Hide "saved" indicator after 3 seconds
        setTimeout(() => setSaveStatus('idle'), 3000);
      return true;
    } catch (error) {
      setSaveStatus('error');
      console.error('Save error:', error);
      return false;
    }
  }, [caseData.id, queryClient]);

  // Helper function to recalculate confirmedAmount and remainingCollectible
  // Formula: confirmedAmount = profitTransactionTax + incomeTax + salaryTax + rentTax + contractTax
  // Formula: remainingCollectible = confirmedAmount - collectedCurrentMonth
  // Accepts optional parameters to use latest values, otherwise reads from formData/refs
  // Uses functional update to ensure we read the latest formData state
  const recalculateConfirmedAmount = (updatedSalaryTax?: number, updatedRentTax?: number, updatedContractTax?: number) => {
    // Use functional update to get the latest formData state
    setFormData(prev => {
      const profitTax = parseFloat(profitTransactionTaxInputRef.current || '0') || 0;
      const income = parseFloat(incomeTaxInputRef.current || '0') || 0;
      const salary = updatedSalaryTax !== undefined ? updatedSalaryTax : (parseFloat(String(prev.salaryTax || 0)) || 0);
      const rent = updatedRentTax !== undefined ? updatedRentTax : (parseFloat(String(prev.rentTax || 0)) || 0);
      const contract = updatedContractTax !== undefined ? updatedContractTax : (parseFloat(String(prev.contractTax || 0)) || 0);
      const collected = parseFloat(collectedCurrentMonthInputRef.current || '0') || 0;
      
      const confirmed = profitTax + income + salary + rent + contract;
      const remaining = Math.max(0, confirmed - collected);
      
      // Return updated formData with calculated values
      return {
        ...prev,
        confirmedAmount: confirmed,
        remainingCollectible: remaining,
      };
    });
  };

  // Handle field change
  const handleFieldChange = (field: string, value: any, section?: string) => {
    const newData = { ...formData, [field]: value };
    setFormData(newData);
    
    // Clear validation error for this field
    if (validationErrors[field]) {
      setValidationErrors({ ...validationErrors, [field]: '' });
    }

    // Trigger autosave
    debouncedSave(newData, section || activeSection);
  };

  // Validate section (section-scoped validation)
  const validateSection = async (section: string) => {
    try {
      // First, save the current section data
      await saveImmediately(formData, section);
      
      // Use the new section-scoped validation endpoint
      const response = await fetch(`/api/cases/${caseData.id}/sections/${section}/complete`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ sectionData: formData }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        // Only show errors for fields in the current section
        const sectionErrors: Record<string, string> = {};
        if (errorData.errors && Array.isArray(errorData.errors)) {
          errorData.errors.forEach((err: any) => {
            // Only add error if it's for a field in the current section
            sectionErrors[err.field] = err.message;
          });
        }
        setValidationErrors(prev => ({ ...prev, ...sectionErrors }));
        
        toast({
          title: 'خطا در اعتبارسنجی',
          description: errorData.message || 'لطفاً فیلدهای الزامی این بخش را پر کنید',
          variant: 'destructive',
        });
        return { isValid: false, errors: sectionErrors };
      }
      
      const result = await response.json();
      
      // Clear validation errors for this section
      setValidationErrors(prev => {
        const newErrors = { ...prev };
        // Remove errors for fields that are now valid
        Object.keys(newErrors).forEach(key => {
          // This is a simplified approach - in production, you'd map fields to sections
          if (result.success) {
            delete newErrors[key];
          }
        });
        return newErrors;
      });

      // Mark section as completed
      setSectionCompletion((prev) => ({
        ...prev,
        [section]: true,
      }));

      return { isValid: true, result };
    } catch (error) {
      console.error('Validation error:', error);
      toast({
        title: 'خطا',
        description: 'خطا در اعتبارسنجی بخش',
        variant: 'destructive',
      });
      return { isValid: false, error };
    }
  };

  // Save override fields mutation
  const saveOverrideFieldsMutation = useMutation({
    mutationFn: async (updates: {
      institution_info_manual?: string;
      representative_name_manual?: string;
      representative_phone_manual?: string;
      institution_address_manual?: string;
    }) => {
      const response = await fetch(`/api/cases/${caseData.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(updates),
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to save override fields');
      }
      return response.json();
    },
    onSuccess: () => {
      refetchCase();
      toast({
        title: 'موفق',
        description: 'فیلدهای بازگشتی با موفقیت ذخیره شدند',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'خطا',
        description: error.message || 'خطا در ذخیره فیلدهای بازگشتی',
        variant: 'destructive',
      });
    },
  });

  // Complete report
  const completeMutation = useMutation({
    mutationFn: async () => {
      // Ensure latest data is saved before completing
      await saveImmediately(formData, 'section_5');
      
      // Log request for debugging (Suggestion A - Network Debug Logging)
      console.debug('[DEBUG] Completing report:', {
        caseId: caseData.id,
        formDataKeys: Object.keys(formData),
        formData: formData, // Full payload for debugging
        sectionCompletion,
        reportSchema: reportSchema, // Include schema for reference
      });

      const response = await fetch(`/api/cases/${caseData.id}/report/v2/complete`, {
        method: 'POST',
        credentials: 'include',
      });
      
      const responseData = await response.json();
      
      // Log response for debugging (Suggestion A - Network Debug Logging)
      console.debug('[DEBUG] Complete response:', {
        status: response.status,
        ok: response.ok,
        data: responseData,
        validation: responseData.validation,
        errors: responseData.errors,
      });

      if (!response.ok) {
        // Extract detailed error messages - only use errors from required sections
        // The backend now filters out section_3 and section_4 errors, so we only use responseData.errors
        const errorMessages = responseData.errors?.map((e: any) => e.message) || [];
        
        // Also check validation.errors if available (but backend should have filtered these)
        // Only use validation.errors if responseData.errors is empty
        const validationErrors = (errorMessages.length === 0 && responseData.validation?.errors) 
          ? responseData.validation.errors
            .filter((e: any) => {
              // Filter out section_3 and section_4 errors
              const section3Fields = ['findingsSummary', 'riskAssessment', 'recommendations', 'detailedFindings', 'actionItems', 'followUpDate'];
              const section4Fields = ['documentsReviewed', 'documentReviewDate', 'missingDocuments', 'documentReviewNotes'];
              return !section3Fields.includes(e.field) && !section4Fields.includes(e.field);
            })
            .map((e: any) => e.message)
          : [];
        
        const allErrors = [...errorMessages, ...validationErrors];
        
        const errorMessage = allErrors.length > 0
          ? allErrors.join('; ')
          : responseData.message || 'Failed to complete report';
        
        throw new Error(errorMessage);
      }
      return responseData;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['case-report-v2', caseData.id] });
      toast({
        title: 'موفق',
        description: 'گزارش با موفقیت تکمیل شد',
      });
      if (onComplete) onComplete();
    },
    onError: (error: Error) => {
      // Display detailed error message
      const errorMessage = error.message || 'خطا در تکمیل گزارش';
      toast({
        title: 'خطا',
        description: errorMessage,
        variant: 'destructive',
        duration: 5000, // Show longer for detailed errors
      });
    },
  });

  // Calculate completion percentage (3 sections: section_1, section_2, section_5)
  const completionPercentage = Math.round((Object.values(sectionCompletion).filter(Boolean).length / 3) * 100);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center p-8">
        <Loader2 className="h-6 w-6 animate-spin" />
        <span className="mr-2">در حال بارگذاری...</span>
      </div>
    );
  }

  return (
    <div className="space-y-6" dir="rtl">
      {/* Status Banner for Completed Reports */}
      {isCompleted && (
        <div className="bg-blue-50 dark:bg-blue-950 border border-blue-200 dark:border-blue-800 rounded-lg p-4">
          <div className="flex items-center gap-2">
            <CheckCircle className="h-5 w-5 text-blue-600 dark:text-blue-400" />
            <div>
              <p className="font-medium text-blue-900 dark:text-blue-100">
                گزارش تکمیل شده است
              </p>
              <p className="text-sm text-blue-700 dark:text-blue-300 mt-1">
                می‌توانید گزارش تکمیل شده را ویرایش کنید. تغییرات به طور خودکار ذخیره می‌شوند.
              </p>
            </div>
          </div>
        </div>
      )}
      
      {isLocked && (
        <div className="bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-lg p-4">
          <div className="flex items-center gap-2">
            <AlertCircle className="h-5 w-5 text-gray-600 dark:text-gray-400" />
            <div>
              <p className="font-medium text-gray-900 dark:text-gray-100">
                گزارش قفل شده است
              </p>
              <p className="text-sm text-gray-700 dark:text-gray-300 mt-1">
                این گزارش قفل شده و قابل ویرایش نیست.
              </p>
            </div>
          </div>
        </div>
      )}
      {/* Header with progress */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>گزارش بررسی قضیه: {caseData.caseId}</CardTitle>
            <div className="flex items-center gap-4">
              {saveStatus === 'saving' && (
                <Badge variant="outline" className="gap-1">
                  <Loader2 className="h-3 w-3 animate-spin" />
                  در حال ذخیره...
                </Badge>
              )}
              {saveStatus === 'saved' && (
                <Badge variant="outline" className="gap-1 text-green-600">
                  <CheckCircle className="h-3 w-3" />
                  ذخیره شد
                </Badge>
              )}
              {saveStatus === 'error' && (
                <Badge variant="destructive" className="gap-1">
                  <AlertCircle className="h-3 w-3" />
                  خطا در ذخیره
                </Badge>
              )}
              <Badge variant="secondary">
                {completionPercentage}% تکمیل شده
              </Badge>
            </div>
          </div>
          <Progress value={completionPercentage} className="mt-4" />
        </CardHeader>
      </Card>

      {/* Section Tabs */}
      <Tabs value={activeSection} onValueChange={setActiveSection} dir="rtl">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="section_1" className="flex items-center gap-2">
            مشخصات نهاد
            {sectionCompletion.section_1 && <CheckCircle className="h-4 w-4 text-green-600" />}
          </TabsTrigger>
          <TabsTrigger value="section_2" className="flex items-center gap-2">
            بیرون‌نویسی‌ها
            {sectionCompletion.section_2 && <CheckCircle className="h-4 w-4 text-green-600" />}
          </TabsTrigger>
          <TabsTrigger value="section_5" className="flex items-center gap-2">
            تایید
            {sectionCompletion.section_5 && <CheckCircle className="h-4 w-4 text-green-600" />}
          </TabsTrigger>
        </TabsList>

        {/* Section 1: Entity Details */}
        <TabsContent value="section_1" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>مشخصات نهاد</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Basic Information (Read-only) */}
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>نام نهاد</Label>
                  <Input value={formData.companyName || ''} disabled className="text-right bg-muted" />
                </div>
                <div className="space-y-2">
                  <Label>نمبر تشخیصیه</Label>
                  <Input value={formData.tin || ''} disabled className="text-right bg-muted" />
                </div>
                <div className="space-y-2">
                  <Label>نوع تشبث</Label>
                  <Input value={formData.businessNature || ''} disabled className="text-right bg-muted" />
                </div>
                <div className="space-y-2">
                  <Label>آمریت ارجاع کننده</Label>
                  <Input value={formData.groupReferrer || ''} disabled className="text-right bg-muted" />
                </div>
                <div className="space-y-2">
                  <Label>تاریخ ارجاع شده</Label>
                  <Input value={formData.referralDate || ''} disabled className="text-right bg-muted" />
                </div>
                <div className="space-y-2">
                  <Label>سال‌های بررسی</Label>
                  <Input value={formData.periodsUnderReview || ''} disabled className="text-right bg-muted" />
                </div>
              </div>

              <Separator className="my-4" />

              {/* Editable Fields */}
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="capitalPeriod">دوران سرمایه *</Label>
                  <Input
                    id="capitalPeriod"
                    value={formData.capitalPeriod || ''}
                    onChange={(e) => handleFieldChange('capitalPeriod', e.target.value, 'section_1')}
                    className="text-right"
                    placeholder="مثال:  دوران سرمایه اظهارنامه خودی"
                    disabled={isCompleted || isLocked}
                    required
                  />
                  {validationErrors.capitalPeriod && (
                    <p className="text-sm text-destructive">{validationErrors.capitalPeriod}</p>
                  )}
                </div>
              </div>

              <div className="flex justify-end gap-2">
                <Button
                  type="button"
                  variant="outline"
                  onClick={async () => {
                    const validation = await validateSection('section_1');
                    if (validation && validation.isValid) {
                      // Section is valid - allow progression to next section
                      setTimeout(() => {
                        setActiveSection('section_2');
                      }, 300);
                    }
                    // If validation fails, errors are already shown in validateSection
                  }}
                >
                  تایید
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Section 2: Extractions */}
        <TabsContent value="section_2" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>بیرون‌نویسی‌ها</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Tax Types */}
              <div>
                <h3 className="text-lg font-semibold mb-4">انواع مالیات</h3>
                <div className="grid grid-cols-2 gap-4">
                  {/* Salary Tax - Editable, triggers confirmedAmount recalculation */}
                  <div className="space-y-2">
                    <Label htmlFor="salaryTax">
                      مالیه موضوعی معاشات <span className="text-destructive">*</span>
                    </Label>
                    <Input
                      id="salaryTax"
                      type="number"
                      step="0.01"
                      value={formData.salaryTax || 0}
                      onChange={(e) => {
                        const value = parseFloat(e.target.value) || 0;
                        // Update formData and recalculate in a single state update
                        setFormData(prev => {
                          const newData = { ...prev, salaryTax: value };
                          // Clear validation error
                          if (validationErrors.salaryTax) {
                            setValidationErrors({ ...validationErrors, salaryTax: '' });
                          }
                          // Calculate confirmedAmount and remainingCollectible
                          const profitTax = parseFloat(profitTransactionTaxInputRef.current || '0') || 0;
                          const income = parseFloat(incomeTaxInputRef.current || '0') || 0;
                          const salary = value;
                          const rent = parseFloat(String(prev.rentTax || 0)) || 0;
                          const contract = parseFloat(String(prev.contractTax || 0)) || 0;
                          const collected = parseFloat(collectedCurrentMonthInputRef.current || '0') || 0;
                          const confirmed = profitTax + income + salary + rent + contract;
                          const remaining = Math.max(0, confirmed - collected);
                          const updatedData = {
                            ...newData,
                            confirmedAmount: confirmed,
                            remainingCollectible: remaining,
                          };
                          // Trigger autosave with updated data
                          debouncedSave(updatedData, 'section_2');
                          return updatedData;
                        });
                      }}
                      className="text-right"
                      dir="ltr"
                    />
                    {validationErrors.salaryTax && (
                      <p className="text-sm text-destructive">{validationErrors.salaryTax}</p>
                    )}
                  </div>

                  {/* Rent Tax - Editable, triggers confirmedAmount recalculation */}
                  <div className="space-y-2">
                    <Label htmlFor="rentTax">
                      مالیه موضوعی بر کرایه <span className="text-destructive">*</span>
                    </Label>
                    <Input
                      id="rentTax"
                      type="number"
                      step="0.01"
                      value={formData.rentTax || 0}
                      onChange={(e) => {
                        const value = parseFloat(e.target.value) || 0;
                        // Update formData and recalculate in a single state update
                        setFormData(prev => {
                          const newData = { ...prev, rentTax: value };
                          // Clear validation error
                          if (validationErrors.rentTax) {
                            setValidationErrors({ ...validationErrors, rentTax: '' });
                          }
                          // Calculate confirmedAmount and remainingCollectible
                          const profitTax = parseFloat(profitTransactionTaxInputRef.current || '0') || 0;
                          const income = parseFloat(incomeTaxInputRef.current || '0') || 0;
                          const salary = parseFloat(String(prev.salaryTax || 0)) || 0;
                          const rent = value;
                          const contract = parseFloat(String(prev.contractTax || 0)) || 0;
                          const collected = parseFloat(collectedCurrentMonthInputRef.current || '0') || 0;
                          const confirmed = profitTax + income + salary + rent + contract;
                          const remaining = Math.max(0, confirmed - collected);
                          const updatedData = {
                            ...newData,
                            confirmedAmount: confirmed,
                            remainingCollectible: remaining,
                          };
                          // Trigger autosave with updated data
                          debouncedSave(updatedData, 'section_2');
                          return updatedData;
                        });
                      }}
                      className="text-right"
                      dir="ltr"
                    />
                    {validationErrors.rentTax && (
                      <p className="text-sm text-destructive">{validationErrors.rentTax}</p>
                    )}
                  </div>

                  {/* Contract Tax - Editable, triggers confirmedAmount recalculation */}
                  <div className="space-y-2">
                    <Label htmlFor="contractTax">
                      مالیه موضوعی قراردادی <span className="text-destructive">*</span>
                    </Label>
                    <Input
                      id="contractTax"
                      type="number"
                      step="0.01"
                      value={formData.contractTax || 0}
                      onChange={(e) => {
                        const value = parseFloat(e.target.value) || 0;
                        // Update formData and recalculate in a single state update
                        setFormData(prev => {
                          const newData = { ...prev, contractTax: value };
                          // Clear validation error
                          if (validationErrors.contractTax) {
                            setValidationErrors({ ...validationErrors, contractTax: '' });
                          }
                          // Calculate confirmedAmount and remainingCollectible
                          const profitTax = parseFloat(profitTransactionTaxInputRef.current || '0') || 0;
                          const income = parseFloat(incomeTaxInputRef.current || '0') || 0;
                          const salary = parseFloat(String(prev.salaryTax || 0)) || 0;
                          const rent = parseFloat(String(prev.rentTax || 0)) || 0;
                          const contract = value;
                          const collected = parseFloat(collectedCurrentMonthInputRef.current || '0') || 0;
                          const confirmed = profitTax + income + salary + rent + contract;
                          const remaining = Math.max(0, confirmed - collected);
                          const updatedData = {
                            ...newData,
                            confirmedAmount: confirmed,
                            remainingCollectible: remaining,
                          };
                          // Trigger autosave with updated data
                          debouncedSave(updatedData, 'section_2');
                          return updatedData;
                        });
                      }}
                      className="text-right"
                      dir="ltr"
                    />
                    {validationErrors.contractTax && (
                      <p className="text-sm text-destructive">{validationErrors.contractTax}</p>
                    )}
                  </div>
                  
                  {/* Profit Transaction Tax - Editable, triggers confirmedAmount recalculation */}
                  <div className="space-y-2">
                    <Label htmlFor="profitTransactionTax">
                      مالیات معاملات انتفاعی <span className="text-destructive">*</span>
                    </Label>
                    <Input
                      id="profitTransactionTax"
                      type="number"
                      step="0.01"
                      value={profitTransactionTaxInput}
                      onChange={(e) => {
                        const inputValue = e.target.value;
                        // Mark that user has edited this field
                        userHasEditedFieldsRef.current.profitTransactionTax = true;
                        // Update local state immediately for responsive UI
                        setProfitTransactionTaxInput(inputValue);
                        
                        // Parse and update formData
                        // Always use 0 instead of null for required fields
                        if (inputValue === '' || inputValue === null || inputValue === undefined) {
                          handleFieldChange('profitTransactionTax', 0, 'section_2');
                          // Trigger recalculation with all fields
                          recalculateConfirmedAmount();
                          return;
                        }
                        const value = parseFloat(inputValue);
                        if (!isNaN(value)) {
                          handleFieldChange('profitTransactionTax', value, 'section_2');
                          // Auto-recalculate confirmedAmount and remainingCollectible with all fields
                          recalculateConfirmedAmount();
                        }
                      }}
                      className="text-right"
                      dir="ltr"
                    />
                    {validationErrors.profitTransactionTax && (
                      <p className="text-sm text-destructive">{validationErrors.profitTransactionTax}</p>
                    )}
                  </div>

                  {/* Income Tax - Editable, triggers confirmedAmount recalculation */}
                  <div className="space-y-2">
                    <Label htmlFor="incomeTax">
                      مالیات بر عایدات <span className="text-destructive">*</span>
                    </Label>
                    <Input
                      id="incomeTax"
                      type="number"
                      step="0.01"
                      value={incomeTaxInput}
                      onChange={(e) => {
                        const inputValue = e.target.value;
                        // Mark that user has edited this field
                        userHasEditedFieldsRef.current.incomeTax = true;
                        // Update local state immediately for responsive UI
                        setIncomeTaxInput(inputValue);
                        
                        // Parse and update formData
                        if (inputValue === '' || inputValue === null || inputValue === undefined) {
                          handleFieldChange('incomeTax', 0, 'section_2');
                          // Trigger recalculation with all fields
                          recalculateConfirmedAmount();
                          return;
                        }
                        const value = parseFloat(inputValue);
                        if (!isNaN(value)) {
                          handleFieldChange('incomeTax', value, 'section_2');
                          // Auto-recalculate confirmedAmount and remainingCollectible with all fields
                          recalculateConfirmedAmount();
                        }
                      }}
                      className="text-right"
                      dir="ltr"
                    />
                    {validationErrors.incomeTax && (
                      <p className="text-sm text-destructive">{validationErrors.incomeTax}</p>
                    )}
                  </div>
                </div>
              </div>

              <Separator />

              {/* Financial Calculations */}
              <div>
                <h3 className="text-lg font-semibold mb-4">محاسبات مالی</h3>
                <div className="grid grid-cols-2 gap-4">
                  {/* Reduced Loss - Editable */}
                  <div className="space-y-2">
                    <Label htmlFor="reducedLoss">
                      ضرر کاهش یافته <span className="text-destructive">*</span>
                    </Label>
                    <Input
                      id="reducedLoss"
                      type="number"
                      step="0.01"
                      value={formData.reducedLoss || 0}
                      onChange={(e) => handleFieldChange('reducedLoss', parseFloat(e.target.value) || 0, 'section_2')}
                      className="text-right"
                      dir="ltr"
                    />
                    {validationErrors.reducedLoss && (
                      <p className="text-sm text-destructive">{validationErrors.reducedLoss}</p>
                    )}
                  </div>

                  {/* Reduced Remaining Amount - Editable */}
                  <div className="space-y-2">
                    <Label htmlFor="reducedRemainingAmount">
                      مبلغ فاضل تحویل کاهش یافته <span className="text-destructive">*</span>
                    </Label>
                    <Input
                      id="reducedRemainingAmount"
                      type="number"
                      step="0.01"
                      value={formData.reducedRemainingAmount || 0}
                      onChange={(e) => handleFieldChange('reducedRemainingAmount', parseFloat(e.target.value) || 0, 'section_2')}
                      className="text-right"
                      dir="ltr"
                    />
                    {validationErrors.reducedRemainingAmount && (
                      <p className="text-sm text-destructive">{validationErrors.reducedRemainingAmount}</p>
                    )}
                  </div>

                  {/* Confirmed Amount - Auto-calculated (Read-only) */}
                  <div className="space-y-2">
                    <Label htmlFor="confirmedAmount">
                      مبلغ تثبیت شده <span className="text-muted-foreground text-xs">(محاسبه خودکار)</span>
                    </Label>
                    <Input
                      id="confirmedAmount"
                      type="number"
                      step="0.01"
                      value={formData.confirmedAmount != null ? Number(formData.confirmedAmount).toFixed(2) : (() => {
                        // Fallback calculation if confirmedAmount not set yet
                        // Auto-calculate: profitTransactionTax + incomeTax + salaryTax + rentTax + contractTax
                        // Use refs for profitTransactionTax and incomeTax (they use local state)
                        // Use formData for the three new fields (they update formData directly)
                        const profitTax = parseFloat(profitTransactionTaxInputRef.current || '0') || 0;
                        const income = parseFloat(incomeTaxInputRef.current || '0') || 0;
                        const salary = parseFloat(formData.salaryTax?.toString() || '0') || 0;
                        const rent = parseFloat(formData.rentTax?.toString() || '0') || 0;
                        const contract = parseFloat(formData.contractTax?.toString() || '0') || 0;
                        return (profitTax + income + salary + rent + contract).toFixed(2);
                      })()}
                      disabled
                      className="text-right bg-muted"
                      dir="ltr"
                    />
                    <p className="text-xs text-muted-foreground">
                      = مالیات معاملات انتفاعی + مالیات بر عایدات + مالیه موضوعی معاشات + مالیه موضوعی بر کرایه + مالیه موضوعی قراردادی
                    </p>
                  </div>

                  {/* Collected Current Month - Editable */}
                  <div className="space-y-2">
                    <Label htmlFor="collectedCurrentMonth">
                      مبلغ تحصیل شده طی برج جاری <span className="text-destructive">*</span>
                    </Label>
                    <Input
                      id="collectedCurrentMonth"
                      type="number"
                      step="0.01"
                      value={collectedCurrentMonthInput}
                      onChange={(e) => {
                        const inputValue = e.target.value;
                        // Mark that user has edited this field
                        userHasEditedFieldsRef.current.collectedCurrentMonth = true;
                        // Update local state immediately for responsive UI
                        setCollectedCurrentMonthInput(inputValue);
                        
                        // Parse and update formData
                        if (inputValue === '' || inputValue === null || inputValue === undefined) {
                          handleFieldChange('collectedCurrentMonth', 0, 'section_2');
                          // Trigger recalculation with all fields
                          recalculateConfirmedAmount();
                          return;
                        }
                        const value = parseFloat(inputValue);
                        if (!isNaN(value)) {
                          handleFieldChange('collectedCurrentMonth', value, 'section_2');
                          // Auto-recalculate remainingCollectible with all fields
                          recalculateConfirmedAmount();
                        }
                      }}
                      className="text-right"
                      dir="ltr"
                    />
                    {validationErrors.collectedCurrentMonth && (
                      <p className="text-sm text-destructive">{validationErrors.collectedCurrentMonth}</p>
                    )}
                  </div>

                  {/* Remaining Collectible - Auto-calculated (Read-only) */}
                  <div className="space-y-2">
                    <Label htmlFor="remainingCollectible">
                      الباقی مبلغ قابل تحصیل <span className="text-muted-foreground text-xs">(محاسبه خودکار)</span>
                    </Label>
                    <Input
                      id="remainingCollectible"
                      type="number"
                      step="0.01"
                      value={formData.remainingCollectible != null ? Number(formData.remainingCollectible).toFixed(2) : (() => {
                        // Fallback calculation if remainingCollectible not set yet
                        // Auto-calculate: confirmedAmount - collectedCurrentMonth
                        // confirmedAmount = profitTransactionTax + incomeTax + salaryTax + rentTax + contractTax
                        // Use refs for profitTransactionTax, incomeTax, and collectedCurrentMonth (they use local state)
                        // Use formData for the three new fields (they update formData directly)
                        const profitTax = parseFloat(profitTransactionTaxInputRef.current || '0') || 0;
                        const income = parseFloat(incomeTaxInputRef.current || '0') || 0;
                        const salary = parseFloat(formData.salaryTax?.toString() || '0') || 0;
                        const rent = parseFloat(formData.rentTax?.toString() || '0') || 0;
                        const contract = parseFloat(formData.contractTax?.toString() || '0') || 0;
                        const confirmed = profitTax + income + salary + rent + contract;
                        const collected = parseFloat(collectedCurrentMonthInputRef.current || '0') || 0;
                        return Math.max(0, confirmed - collected).toFixed(2);
                      })()}
                      disabled
                      className="text-right bg-muted"
                      dir="ltr"
                    />
                    <p className="text-xs text-muted-foreground">
                      = مبلغ تثبیت شده - مبلغ تحصیل شده طی برج جاری
                    </p>
                  </div>
                </div>
              </div>

              <div className="flex justify-end gap-2">
                <Button
                  type="button"
                  variant="outline"
                  onClick={async () => {
                    const validation = await validateSection('section_2');
                    if (validation && validation.isValid) {
                      // Section is valid - allow progression to next section
                      setTimeout(() => {
                        setActiveSection('section_5');
                      }, 300);
                    }
                    // If validation fails, errors are already shown in validateSection
                  }}
                >
                  تایید
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Section 5: Approval & Document Upload */}
        <TabsContent value="section_5" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>تایید</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">

              {/* Final Completion Fields - At the end of section_5 */}
              <div>
                <h3 className="text-lg font-semibold mb-4">اطلاعات تکمیل نهایی</h3>
                <p className="text-sm text-muted-foreground mb-4">
                  این بخش در پایان تکمیل تمام بخش‌های گزارش پر می‌شود
                </p>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="finalDocumentDate">
                      تاریخ صادره مکتوب نهایی <span className="text-destructive">*</span>
                    </Label>
                    <ShamsiDatePickerDDMMYYYY
                      value={formData.finalDocumentDate || ''}
                      onChange={(date) => handleFieldChange('finalDocumentDate', date, 'section_5')}
                    />
                    {validationErrors.finalDocumentDate && (
                      <p className="text-sm text-destructive">{validationErrors.finalDocumentDate}</p>
                    )}
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="activityStatus">
                      وضعیت فعالیت <span className="text-destructive">*</span>
                    </Label>
                    <Select
                      value={formData.activityStatus || ''}
                      onValueChange={(value) => handleFieldChange('activityStatus', value, 'section_5')}
                    >
                      <SelectTrigger id="activityStatus" className="text-right">
                        <SelectValue placeholder="انتخاب کنید" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="فعال">فعال</SelectItem>
                        <SelectItem value="عدم فعالیت">عدم فعالیت</SelectItem>
                      </SelectContent>
                    </Select>
                    {validationErrors.activityStatus && (
                      <p className="text-sm text-destructive">{validationErrors.activityStatus}</p>
                    )}
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="attachmentNumber">
                      نمبر آویز <span className="text-destructive">*</span>
                    </Label>
                    <Input
                      id="attachmentNumber"
                      value={formData.attachmentNumber || ''}
                      onChange={(e) => handleFieldChange('attachmentNumber', e.target.value, 'section_5')}
                      className="text-right"
                    />
                    {validationErrors.attachmentNumber && (
                      <p className="text-sm text-destructive">{validationErrors.attachmentNumber}</p>
                    )}
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="attachmentDate">
                      تاریخ آویز <span className="text-destructive">*</span>
                    </Label>
                    <ShamsiDatePickerDDMMYYYY
                      value={formData.attachmentDate || ''}
                      onChange={(date) => handleFieldChange('attachmentDate', date, 'section_5')}
                    />
                    {validationErrors.attachmentDate && (
                      <p className="text-sm text-destructive">{validationErrors.attachmentDate}</p>
                    )}
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="reviewedByRole">بررسی شده توسط</Label>
                    <Input
                      id="reviewedByRole"
                      value={formData.reviewedByRole || (assignedUser ? (assignedUser.fullName || assignedUser.auditId || '') : '')}
                      disabled
                      className="text-right bg-muted"
                      placeholder="به صورت خودکار از کاربر اختصاص داده شده پر می‌شود"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="reviewedAt">تاریخ بررسی</Label>
                    <Input
                      id="reviewedAt"
                      value={formData.reviewedAt ? new Date(formData.reviewedAt).toLocaleDateString('fa-IR') : ''}
                      disabled
                      className="text-right bg-muted"
                      placeholder="به صورت خودکار هنگام تکمیل قضیه پر می‌شود"
                    />
                  </div>
                </div>
              </div>

              {/* Additional Entity Information - Editable Override Fields */}
              <div className="mt-6 pt-6 border-t">
                <h3 className="text-lg font-semibold mb-4">اطلاعات نهاد (قابل ویرایش)</h3>
                <p className="text-sm text-muted-foreground mb-4">
                  این اطلاعات از نهاد مرتبط با قضیه استخراج شده است. می‌توانید در صورت نیاز مقادیر را ویرایش کنید.
                </p>
                <div className="grid grid-cols-1 gap-4">
                  {/* Institution Info Override */}
                  <div className="space-y-2">
                    <Label htmlFor="institutionInfo">اطلاعات نهاد</Label>
                    {overrideFields.institutionInfo.editing ? (
                      <div className="space-y-2">
                        <div className="text-xs text-muted-foreground mb-1">
                          مقدار استخراج‌شده: {overrideFields.institutionInfo.original || 'نامشخص'}
                        </div>
                        <Textarea
                          id="institutionInfo"
                          value={overrideFields.institutionInfo.manual || overrideFields.institutionInfo.original}
                          onChange={(e) => setOverrideFields(prev => ({
                            ...prev,
                            institutionInfo: { ...prev.institutionInfo, manual: e.target.value }
                          }))}
                          className="text-right"
                          rows={3}
                          placeholder="اطلاعات نهاد"
                        />
                        <div className="flex gap-2">
                          <Button
                            type="button"
                            size="sm"
                            onClick={async () => {
                              await saveOverrideFieldsMutation.mutateAsync({
                                institution_info_manual: overrideFields.institutionInfo.manual || overrideFields.institutionInfo.original,
                              });
                              setOverrideFields(prev => ({
                                ...prev,
                                institutionInfo: { ...prev.institutionInfo, editing: false }
                              }));
                            }}
                            disabled={saveOverrideFieldsMutation.isPending}
                          >
                            ذخیره
                          </Button>
                          <Button
                            type="button"
                            size="sm"
                            variant="outline"
                            onClick={() => setOverrideFields(prev => ({
                              ...prev,
                              institutionInfo: { ...prev.institutionInfo, editing: false }
                            }))}
                          >
                            لغو
                          </Button>
                        </div>
                      </div>
                    ) : (
                      <div className="space-y-1">
                        <Textarea
                          value={overrideFields.institutionInfo.manual || overrideFields.institutionInfo.original || ''}
                          disabled
                          className="text-right bg-muted"
                          rows={3}
                          placeholder="اطلاعات نهاد از نهاد استخراج می‌شود"
                        />
                        {overrideFields.institutionInfo.manual && overrideMetadata.institutionInfo && (
                          <div className="text-xs text-muted-foreground">
                            مقدار بازگشتی: ویرایش شده توسط {overrideMetadata.institutionInfo.by || 'نامشخص'} در{' '}
                            {overrideMetadata.institutionInfo.at ? new Date(overrideMetadata.institutionInfo.at).toLocaleDateString('fa-IR') : ''}
                          </div>
                        )}
                        {(user?.role === 'auditor' || user?.role === 'senior_auditor' || user?.role === 'system_admin') && (
                          <Button
                            type="button"
                            size="sm"
                            variant="outline"
                            onClick={() => setOverrideFields(prev => ({
                              ...prev,
                              institutionInfo: { ...prev.institutionInfo, editing: true }
                            }))}
                            className="mt-1"
                          >
                            ویرایش
                          </Button>
                        )}
                      </div>
                    )}
                  </div>

                  {/* Representative Name Override */}
                  <div className="space-y-2">
                    <Label htmlFor="representative">نماینده</Label>
                    {overrideFields.representativeName.editing ? (
                      <div className="space-y-2">
                        <div className="text-xs text-muted-foreground mb-1">
                          مقدار استخراج‌شده: {overrideFields.representativeName.original || 'نامشخص'}
                        </div>
                        <Input
                          id="representative"
                          value={overrideFields.representativeName.manual || overrideFields.representativeName.original}
                          onChange={(e) => setOverrideFields(prev => ({
                            ...prev,
                            representativeName: { ...prev.representativeName, manual: e.target.value }
                          }))}
                          className="text-right"
                          placeholder="نام نماینده"
                        />
                        <div className="flex gap-2">
                          <Button
                            type="button"
                            size="sm"
                            onClick={async () => {
                              await saveOverrideFieldsMutation.mutateAsync({
                                representative_name_manual: overrideFields.representativeName.manual || overrideFields.representativeName.original,
                              });
                              setOverrideFields(prev => ({
                                ...prev,
                                representativeName: { ...prev.representativeName, editing: false }
                              }));
                            }}
                            disabled={saveOverrideFieldsMutation.isPending}
                          >
                            ذخیره
                          </Button>
                          <Button
                            type="button"
                            size="sm"
                            variant="outline"
                            onClick={() => setOverrideFields(prev => ({
                              ...prev,
                              representativeName: { ...prev.representativeName, editing: false }
                            }))}
                          >
                            لغو
                          </Button>
                        </div>
                      </div>
                    ) : (
                      <div className="space-y-1">
                        <Input
                          value={overrideFields.representativeName.manual || overrideFields.representativeName.original || ''}
                          disabled
                          className="text-right bg-muted"
                          placeholder="اطلاعات نماینده از نهاد استخراج می‌شود"
                        />
                        {(user?.role === 'auditor' || user?.role === 'senior_auditor' || user?.role === 'system_admin') && (
                          <Button
                            type="button"
                            size="sm"
                            variant="outline"
                            onClick={() => setOverrideFields(prev => ({
                              ...prev,
                              representativeName: { ...prev.representativeName, editing: true }
                            }))}
                            className="mt-1"
                          >
                            ویرایش
                          </Button>
                        )}
                      </div>
                    )}
                  </div>

                  {/* Representative Phone Override */}
                  <div className="space-y-2">
                    <Label htmlFor="representativeContactNumber">شماره تماس نماینده</Label>
                    {overrideFields.representativePhone.editing ? (
                      <div className="space-y-2">
                        <div className="text-xs text-muted-foreground mb-1">
                          مقدار استخراج‌شده: {overrideFields.representativePhone.original || 'نامشخص'}
                        </div>
                        <Input
                          id="representativeContactNumber"
                          value={overrideFields.representativePhone.manual || overrideFields.representativePhone.original}
                          onChange={(e) => setOverrideFields(prev => ({
                            ...prev,
                            representativePhone: { ...prev.representativePhone, manual: e.target.value }
                          }))}
                          className="text-right"
                          placeholder="شماره تماس نماینده"
                        />
                        <div className="flex gap-2">
                          <Button
                            type="button"
                            size="sm"
                            onClick={async () => {
                              await saveOverrideFieldsMutation.mutateAsync({
                                representative_phone_manual: overrideFields.representativePhone.manual || overrideFields.representativePhone.original,
                              });
                              setOverrideFields(prev => ({
                                ...prev,
                                representativePhone: { ...prev.representativePhone, editing: false }
                              }));
                            }}
                            disabled={saveOverrideFieldsMutation.isPending}
                          >
                            ذخیره
                          </Button>
                          <Button
                            type="button"
                            size="sm"
                            variant="outline"
                            onClick={() => setOverrideFields(prev => ({
                              ...prev,
                              representativePhone: { ...prev.representativePhone, editing: false }
                            }))}
                          >
                            لغو
                          </Button>
                        </div>
                      </div>
                    ) : (
                      <div className="space-y-1">
                        <Input
                          value={overrideFields.representativePhone.manual || overrideFields.representativePhone.original || ''}
                          disabled
                          className="text-right bg-muted"
                          placeholder="شماره تماس نماینده از نهاد استخراج می‌شود"
                        />
                        {(user?.role === 'auditor' || user?.role === 'senior_auditor' || user?.role === 'system_admin') && (
                          <Button
                            type="button"
                            size="sm"
                            variant="outline"
                            onClick={() => setOverrideFields(prev => ({
                              ...prev,
                              representativePhone: { ...prev.representativePhone, editing: true }
                            }))}
                            className="mt-1"
                          >
                            ویرایش
                          </Button>
                        )}
                      </div>
                    )}
                  </div>

                  {/* Institution Address Override */}
                  <div className="space-y-2">
                    <Label htmlFor="entityAddress">آدرس نهاد</Label>
                    {overrideFields.institutionAddress.editing ? (
                      <div className="space-y-2">
                        <div className="text-xs text-muted-foreground mb-1">
                          مقدار استخراج‌شده: {overrideFields.institutionAddress.original || 'نامشخص'}
                        </div>
                        <Textarea
                          id="entityAddress"
                          value={overrideFields.institutionAddress.manual || overrideFields.institutionAddress.original}
                          onChange={(e) => setOverrideFields(prev => ({
                            ...prev,
                            institutionAddress: { ...prev.institutionAddress, manual: e.target.value }
                          }))}
                          className="text-right"
                          rows={3}
                          placeholder="آدرس نهاد"
                        />
                        <div className="flex gap-2">
                          <Button
                            type="button"
                            size="sm"
                            onClick={async () => {
                              await saveOverrideFieldsMutation.mutateAsync({
                                institution_address_manual: overrideFields.institutionAddress.manual || overrideFields.institutionAddress.original,
                              });
                              setOverrideFields(prev => ({
                                ...prev,
                                institutionAddress: { ...prev.institutionAddress, editing: false }
                              }));
                            }}
                            disabled={saveOverrideFieldsMutation.isPending}
                          >
                            ذخیره
                          </Button>
                          <Button
                            type="button"
                            size="sm"
                            variant="outline"
                            onClick={() => setOverrideFields(prev => ({
                              ...prev,
                              institutionAddress: { ...prev.institutionAddress, editing: false }
                            }))}
                          >
                            لغو
                          </Button>
                        </div>
                      </div>
                    ) : (
                      <div className="space-y-1">
                        <Textarea
                          value={overrideFields.institutionAddress.manual || overrideFields.institutionAddress.original || ''}
                          disabled
                          className="text-right bg-muted"
                          rows={3}
                          placeholder="آدرس نهاد از نهاد استخراج می‌شود"
                        />
                        {(user?.role === 'auditor' || user?.role === 'senior_auditor' || user?.role === 'system_admin') && (
                          <Button
                            type="button"
                            size="sm"
                            variant="outline"
                            onClick={() => setOverrideFields(prev => ({
                              ...prev,
                              institutionAddress: { ...prev.institutionAddress, editing: true }
                            }))}
                            className="mt-1"
                          >
                            ویرایش
                          </Button>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              </div>

              <div className="flex justify-end gap-2 mt-6">
                <Button
                  type="button"
                  variant="outline"
                  onClick={async () => {
                    const validation = await validateSection('section_5');
                    if (validation && validation.isValid) {
                      // Last section validated - ready for final completion
                      toast({
                        title: 'موفق',
                        description: 'تمام بخش‌ها تایید شد. می‌توانید گزارش را تکمیل کنید.',
                      });
                    }
                    // If validation fails, errors are already shown in validateSection
                  }}
                >
                  تایید
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Additional Read-Only Fields (from Entity) - Shown at bottom for completed cases */}
      {isCompleted && (
        <Card className="mt-6">
          <CardHeader>
            <CardTitle>اطلاعات تکمیلی نهاد</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label>نماینده</Label>
                <Input 
                  value={formData.contactPerson || ''} 
                  disabled 
                  className="text-right bg-muted" 
                />
              </div>
              <div className="space-y-2">
                <Label>شماره تماس نماینده</Label>
                <Input 
                  value={formData.phone || ''} 
                  disabled 
                  className="text-right bg-muted" 
                />
              </div>
              <div className="space-y-2 md:col-span-1">
                <Label>آدرس نهاد</Label>
                <Input 
                  value={formData.registeredAddress || ''} 
                  disabled 
                  className="text-right bg-muted" 
                />
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Action Buttons */}
      <div className="flex justify-end gap-2">
        <Button
          type="button"
          variant="outline"
          onClick={() => setShowPrintView(true)}
        >
          <FileText className="ml-2 h-4 w-4" />
          مشاهده چاپ
        </Button>
        {onCancel && (
          <Button type="button" variant="outline" onClick={onCancel}>
            لغو
          </Button>
        )}
        {!isCompleted && !isLocked && (
          <Button
            type="button"
            onClick={() => completeMutation.mutate()}
            disabled={completeMutation.isPending || completionPercentage < 100}
          >
            {completeMutation.isPending ? (
              <>
                <Loader2 className="ml-2 h-4 w-4 animate-spin" />
                در حال تکمیل...
              </>
            ) : (
              <>
                <CheckCircle className="ml-2 h-4 w-4" />
                تکمیل گزارش
              </>
            )}
          </Button>
        )}
        
        {isCompleted && (
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <CheckCircle className="h-4 w-4 text-green-600" />
            <span>گزارش تکمیل شده - تغییرات به صورت خودکار ذخیره می‌شوند</span>
          </div>
        )}
      </div>

      {/* Print View Dialog */}
      {showPrintView && (
        <div className="fixed inset-0 z-50 bg-background/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-background border rounded-lg shadow-lg w-full max-w-5xl max-h-[90vh] overflow-y-auto">
            <div className="p-4 border-b flex items-center justify-between">
              <h2 className="text-lg font-semibold">نمایش چاپ</h2>
              <Button variant="ghost" size="sm" onClick={() => setShowPrintView(false)}>
                بستن
              </Button>
            </div>
            <div className="p-6">
              <CaseReportPrintView caseData={caseData} onClose={() => setShowPrintView(false)} />
            </div>
          </div>
        </div>
      )}

    </div>
  );
}

