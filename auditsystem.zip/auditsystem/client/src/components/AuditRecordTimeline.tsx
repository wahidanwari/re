import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Calendar, User, Users, FileText, Plus, Edit, Eye, AlertCircle } from 'lucide-react';
import StatusBadge from '@/components/StatusBadge';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { useState } from 'react';
import AuditRecordForm from './AuditRecordForm';
import { useLocation } from 'wouter';
import { Alert, AlertDescription } from '@/components/ui/alert';

interface AuditRecord {
  id: string;
  entityId: string;
  auditYears?: string; // سال‌های بررسی
  yearFrom?: number;
  yearTo?: number;
  referringGroup?: string; // گروه ارجاع‌دهنده
  referralDate?: string; // تاریخ ارجاع به بررسی
  status: 'in-progress' | 'completed' | 'archived';
  assignedGroup?: string; // گروه اختصاص داده شده
  assignedAt?: string;
  createdByUserId?: string;
  notes?: string;
  responsibleEvaluator?: string;
  createdAt: string;
  updatedAt: string;
  completedAt?: string;
  responsibleEvaluatorUser?: {
    id: string;
    fullName: string;
    auditId: string;
  };
  auditGroupInfo?: {
    id: string;
    name: string;
    code?: string;
  };
  createdByUser?: {
    id: string;
    fullName: string;
  };
}

interface AuditRecordTimelineProps {
  entityId: string;
  entityName?: string;
  onRefresh?: () => void;
}

export default function AuditRecordTimeline({ entityId, entityName, onRefresh }: AuditRecordTimelineProps) {
  const [createDialogOpen, setCreateDialogOpen] = useState(false);
  const [editingRecord, setEditingRecord] = useState<AuditRecord | null>(null);
  const [, setLocation] = useLocation();

  const { data: auditRecordsData, isLoading, refetch } = useQuery<{
    records: AuditRecord[];
    pagination?: {
      page: number;
      limit: number;
      total: number;
      totalPages: number;
    };
  }>({
    queryKey: ['audit-records', entityId],
    queryFn: async () => {
      const response = await fetch(`/api/audit-records/entities/${entityId}/audits`, {
        credentials: 'include',
      });
      if (!response.ok) {
        throw new Error('Failed to fetch audit records');
      }
      return response.json();
    },
  });

  const auditRecords = auditRecordsData?.records || [];

  const handleRefresh = () => {
    refetch();
    onRefresh?.();
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200';
      case 'in-progress':
        return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200';
      case 'archived':
        return 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-200';
      default:
        return 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-200';
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'completed':
        return 'تکمیل شده';
      case 'in-progress':
        return 'در جریان';
      case 'archived':
        return 'بایگانی شده';
      default:
        return status;
    }
  };

  const formatYearRange = (record: AuditRecord) => {
    if (record.auditYears) {
      return record.auditYears;
    }
    if (record.yearFrom && record.yearTo) {
      if (record.yearFrom === record.yearTo) {
        return `سال ${record.yearFrom}`;
      }
      return `${record.yearFrom}-${record.yearTo}`;
    }
    return '-';
  };

  // Detect gaps in year coverage
  const detectGaps = () => {
    if (auditRecords.length === 0) return [];
    
    const sortedRecords = [...auditRecords].sort((a, b) => {
      const aFrom = a.yearFrom || 0;
      const bFrom = b.yearFrom || 0;
      return aFrom - bFrom;
    });
    const gaps: Array<{ from: number; to: number }> = [];
    
    // Check gaps between records
    for (let i = 0; i < sortedRecords.length - 1; i++) {
      const currentEnd = sortedRecords[i].yearTo || 0;
      const nextStart = sortedRecords[i + 1].yearFrom || 0;
      
      if (nextStart > currentEnd + 1) {
        gaps.push({
          from: currentEnd + 1,
          to: nextStart - 1,
        });
      }
    }
    
    return gaps;
  };

  const gaps = detectGaps();

  if (isLoading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="text-center text-muted-foreground">در حال بارگذاری...</div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>سوابق بررسی</CardTitle>
          <Dialog open={createDialogOpen} onOpenChange={setCreateDialogOpen}>
            <DialogTrigger asChild>
              <Button size="sm">
                <Plus className="ml-2 h-4 w-4" />
                سابقه جدید
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>ایجاد سابقه بررسی جدید</DialogTitle>
              </DialogHeader>
              <AuditRecordForm
                entityId={entityId}
                entityName={entityName}
                onSuccess={() => {
                  setCreateDialogOpen(false);
                  handleRefresh();
                }}
                onCancel={() => setCreateDialogOpen(false)}
              />
            </DialogContent>
          </Dialog>
        </div>
      </CardHeader>
      <CardContent>
        {gaps.length > 0 && (
          <Alert className="mb-4">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              <strong>توجه:</strong> بازه‌های سالی بدون سابقه بررسی: {gaps.map(g => 
                g.from === g.to ? g.from : `${g.from}-${g.to}`
              ).join(', ')}
            </AlertDescription>
          </Alert>
        )}
        
        {auditRecords.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <FileText className="mx-auto h-12 w-12 mb-4 opacity-50" />
            <p>هیچ سابقه بررسی ثبت نشده است</p>
            <p className="text-sm mt-2">برای شروع، یک سابقه بررسی جدید ایجاد کنید</p>
          </div>
        ) : (
          <div className="space-y-4">
            {auditRecords.map((record) => (
              <div
                key={record.id}
                className="border rounded-lg p-4 hover:bg-accent/50 transition-colors"
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2 flex-wrap">
                      <Calendar className="h-4 w-4 text-muted-foreground" />
                      <span className="font-semibold">
                        سال‌های بررسی: {formatYearRange(record)}
                      </span>
                      <Badge className={getStatusColor(record.status)}>
                        {getStatusLabel(record.status)}
                      </Badge>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2 mt-3 text-sm">
                      {record.referringGroup && (
                        <div className="flex items-center gap-2">
                          <Users className="h-4 w-4 text-muted-foreground" />
                          <span className="text-muted-foreground">گروه ارجاع‌دهنده:</span>
                          <span>{record.referringGroup}</span>
                        </div>
                      )}
                      
                      {record.referralDate && (
                        <div className="flex items-center gap-2">
                          <Calendar className="h-4 w-4 text-muted-foreground" />
                          <span className="text-muted-foreground">تاریخ ارجاع:</span>
                          <span>{new Date(record.referralDate).toLocaleDateString('fa-IR')}</span>
                        </div>
                      )}
                      
                      {record.auditGroupInfo && (
                        <div className="flex items-center gap-2">
                          <Users className="h-4 w-4 text-muted-foreground" />
                          <span className="text-muted-foreground">گروه اختصاص داده شده:</span>
                          <span>{record.auditGroupInfo.name}</span>
                        </div>
                      )}
                      
                      {record.responsibleEvaluatorUser && (
                        <div className="flex items-center gap-2">
                          <User className="h-4 w-4 text-muted-foreground" />
                          <span className="text-muted-foreground">بررس مسئول:</span>
                          <span>{record.responsibleEvaluatorUser.fullName}</span>
                        </div>
                      )}
                      
                      {record.assignedAt && (
                        <div className="flex items-center gap-2">
                          <span className="text-muted-foreground">تاریخ اختصاص:</span>
                          <span>{new Date(record.assignedAt).toLocaleDateString('fa-IR')}</span>
                        </div>
                      )}
                      
                      {record.completedAt && (
                        <div className="flex items-center gap-2">
                          <span className="text-muted-foreground">تاریخ تکمیل:</span>
                          <span>{new Date(record.completedAt).toLocaleDateString('fa-IR')}</span>
                        </div>
                      )}
                    </div>
                    
                    {record.notes && (
                      <div className="mt-2 text-sm text-muted-foreground">
                        <p className="line-clamp-2">{record.notes}</p>
                      </div>
                    )}
                  </div>
                  
                  <div className="flex gap-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setLocation(`/audit-records/${record.id}`)}
                    >
                      <Eye className="h-4 w-4" />
                    </Button>
                    {record.status !== 'completed' && record.status !== 'archived' && (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setEditingRecord(record)}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
      
      {editingRecord && (
        <Dialog open={!!editingRecord} onOpenChange={(open) => !open && setEditingRecord(null)}>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>ویرایش سابقه بررسی</DialogTitle>
            </DialogHeader>
            <AuditRecordForm
              entityId={entityId}
              entityName={entityName}
              existingRecord={editingRecord}
              onSuccess={() => {
                setEditingRecord(null);
                handleRefresh();
              }}
              onCancel={() => setEditingRecord(null)}
            />
          </DialogContent>
        </Dialog>
      )}
    </Card>
  );
}
