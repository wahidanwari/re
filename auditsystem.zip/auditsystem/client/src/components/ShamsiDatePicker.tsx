import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar } from 'lucide-react';
import { Input } from '@/components/ui/input';

interface ShamsiDatePickerProps {
  value?: string;
  onChange: (date: string) => void;
  placeholder?: string;
}

export default function ShamsiDatePicker({ value, onChange, placeholder = 'انتخاب تاریخ' }: ShamsiDatePickerProps) {
  const [open, setOpen] = useState(false);
  const [tempValue, setTempValue] = useState(value || '');

  const handleSelect = () => {
    onChange(tempValue);
    setOpen(false);
  };

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button 
          variant="outline" 
          className="w-full justify-between text-right"
          data-testid="button-date-picker"
        >
          <Calendar className="ml-2 h-4 w-4" />
          <span>{value || placeholder}</span>
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-auto p-4" align="start">
        <div className="space-y-4">
          <Input
            type="text"
            placeholder="۱۴۰۳/۱۱/۱۳"
            value={tempValue}
            onChange={(e) => setTempValue(e.target.value)}
            className="text-right"
            data-testid="input-shamsi-date"
          />
          <div className="flex gap-2">
            <Button onClick={handleSelect} size="sm" data-testid="button-confirm-date">
              تایید
            </Button>
            <Button onClick={() => setOpen(false)} variant="outline" size="sm" data-testid="button-cancel-date">
              لغو
            </Button>
          </div>
        </div>
      </PopoverContent>
    </Popover>
  );
}
