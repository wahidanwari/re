import { Switch, Route, Redirect, useLocation } from 'wouter';
import { queryClient } from './lib/queryClient';
import { QueryClientProvider } from '@tanstack/react-query';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import { SidebarProvider, SidebarTrigger, SidebarInset } from '@/components/ui/sidebar';
import { AuthProvider, useAuth } from '@/contexts/AuthContext';
import { LocaleProvider } from '@/contexts/LocaleContext';
import { ThemeProvider } from 'next-themes';
import { AppSidebar } from '@/components/AppSidebar';
import NotificationBell from '@/components/NotificationBell';
import { Moon, Sun, LogOut } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useTheme } from 'next-themes';
import Login from '@/pages/Login';
import Dashboard from '@/pages/Dashboard';
import Entities from '@/pages/Entities';
import Cases from '@/pages/Cases';
import Users from '@/pages/Users';
import Groups from '@/pages/Groups';
import TargetSettings from '@/pages/TargetSettings';
import Tickets from '@/pages/Tickets';
import Documents from '@/pages/Documents';
import Settings from '@/pages/Settings';
import AuditLogs from '@/pages/AuditLogs';
import AuditRecordDetail from '@/pages/AuditRecordDetail';
import Reports from '@/pages/Reports';
// OLD COMMITTEE MODULE - DISABLED
// import Committees from '@/pages/Committees';
import CommitteesNew from '@/pages/CommitteesNew';
import CreateCommittee from '@/pages/CreateCommittee';
import CommitteeDetails from '@/pages/CommitteeDetails';
import Archives from '@/pages/Archives';
import NotFound from '@/pages/not-found';

function ProtectedRoute({ component: Component }: { component: () => JSX.Element }) {
  const { user } = useAuth();
  const [location] = useLocation();

  if (!user && location !== '/login') {
    return <Redirect to="/login" />;
  }

  if (user && location === '/login') {
    return <Redirect to="/" />;
  }

  return <Component />;
}

function ThemeToggle() {
  const { theme, setTheme } = useTheme();

  return (
    <Button
      variant="ghost"
      size="icon"
      onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
      data-testid="button-theme-toggle"
    >
      <Sun className="h-5 w-5 rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0" />
      <Moon className="absolute h-5 w-5 rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100" />
      <span className="sr-only">تبدیل تم</span>
    </Button>
  );
}

function AppContent() {
  const { user, logout } = useAuth();
  const [location, setLocation] = useLocation();

  if (location === '/login' || !user) {
    return (
      <Switch>
        <Route path="/login" component={Login} />
        <Route>
          <Redirect to="/login" />
        </Route>
      </Switch>
    );
  }

  const handleLogout = async () => {
    try {
      await logout();
      setLocation('/login');
    } catch (error) {
      console.error('Logout error:', error);
    }
  };

  return (
    <SidebarProvider>
      <AppSidebar />
      <SidebarInset>
        <header className="sticky top-0 z-20 flex items-center justify-between h-16 px-4 border-b bg-background shrink-0">
          <SidebarTrigger data-testid="button-sidebar-toggle" />
          <div className="flex items-center gap-4">
            <ThemeToggle />
            <NotificationBell />
            <Button
              variant="ghost"
              size="icon"
              onClick={handleLogout}
              data-testid="button-logout-header"
              title="خروج از سیستم"
            >
              <LogOut className="h-5 w-5" />
            </Button>
          </div>
        </header>
        <div className="flex-1 overflow-auto p-4 md:p-6 lg:p-8">
          <Switch>
            <Route path="/" component={() => <ProtectedRoute component={Dashboard} />} />
            <Route path="/entities" component={() => <ProtectedRoute component={Entities} />} />
            <Route path="/cases" component={() => <ProtectedRoute component={Cases} />} />
            <Route path="/users" component={() => <ProtectedRoute component={Users} />} />
            <Route path="/groups" component={() => <ProtectedRoute component={Groups} />} />
            <Route path="/target-settings" component={() => <ProtectedRoute component={TargetSettings} />} />
            <Route path="/tickets" component={() => <ProtectedRoute component={Tickets} />} />
            <Route path="/documents" component={() => <ProtectedRoute component={Documents} />} />
            <Route path="/reports" component={() => <ProtectedRoute component={Reports} />} />
            <Route path="/settings" component={() => <ProtectedRoute component={Settings} />} />
            <Route path="/audit-logs" component={() => <ProtectedRoute component={AuditLogs} />} />
            <Route path="/audit-records/:id" component={() => <ProtectedRoute component={AuditRecordDetail} />} />
            {/* OLD COMMITTEE MODULE - DISABLED */}
            {/* <Route path="/committees" component={() => <ProtectedRoute component={Committees} />} /> */}
            <Route path="/committees" component={() => <ProtectedRoute component={() => (
              <div className="p-8 text-center">
                <h2 className="text-2xl font-semibold mb-4">ماژول کمیته غیرفعال شده است</h2>
                <p className="text-muted-foreground">ماژول کمیته قدیمی غیرفعال شده است و با پیاده‌سازی جدید جایگزین خواهد شد.</p>
              </div>
            )} />} />
            {/* NEW COMMITTEE MODULE */}
            <Route path="/committees-new" component={() => <ProtectedRoute component={CommitteesNew} />} />
            <Route path="/committees-new/create" component={() => <ProtectedRoute component={CreateCommittee} />} />
            <Route path="/committees-new/:id" component={() => <ProtectedRoute component={CommitteeDetails} />} />
            <Route path="/archives" component={() => <ProtectedRoute component={Archives} />} />
            <Route component={NotFound} />
          </Switch>
        </div>
      </SidebarInset>
    </SidebarProvider>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider attribute="class" defaultTheme="light" enableSystem>
        <TooltipProvider>
          <AuthProvider>
            <LocaleProvider>
              <AppContent />
              <Toaster />
            </LocaleProvider>
          </AuthProvider>
        </TooltipProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
