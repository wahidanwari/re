# Runbook - Audit System Operations Guide
## Daily Operations, Backup/Restore, Upgrades, and Troubleshooting

This runbook provides step-by-step operational procedures for managing the Audit System in production.

---

## Table of Contents

1. [Daily Operations](#daily-operations)
2. [Starting and Stopping the Service](#starting-and-stopping-the-service)
3. [Backup and Restore](#backup-and-restore)
4. [Upgrades and Rollbacks](#upgrades-and-rollbacks)
5. [Health Checks](#health-checks)
6. [Monitoring and Logs](#monitoring-and-logs)
7. [Troubleshooting](#troubleshooting)
8. [Emergency Procedures](#emergency-procedures)

---

## Daily Operations

### Morning Checklist

1. **Check Application Health**
   ```bash
   curl http://SERVER_IP:3000/api/health
   ```
   Expected response: `{"status":"healthy","checks":{"server":"ok","database":"ok"}}`

2. **Check Application Logs**
   ```bash
   # If using PM2
   pm2 logs audit-system --lines 50
   
   # If using direct start
   tail -f /path/to/auditsystem/logs/app.log
   ```

3. **Check Disk Space**
   ```bash
   df -h  # Linux/macOS
   Get-PSDrive C  # Windows PowerShell
   ```

4. **Verify Backups**
   ```bash
   ls -lh /path/to/auditsystem/backups/
   ```

### Evening Checklist

1. **Review Audit Logs**
   - Navigate to Audit Logs page in application
   - Review critical events (login failures, permission changes, deletions)

2. **Check Disk Usage**
   - Monitor document storage (`docvault/`)
   - Monitor backup storage (`backups/`)

3. **Verify Database Size**
   ```bash
   psql $DATABASE_URL -c "SELECT pg_size_pretty(pg_database_size('audit_system'));"
   ```

---

## Starting and Stopping the Service

### Starting the Service

#### Using PM2 (Linux/macOS - Recommended)

```bash
cd /path/to/auditsystem

# Start application
pm2 start dist/index.js --name audit-system

# Or if already configured
pm2 start audit-system

# Verify status
pm2 status

# View logs
pm2 logs audit-system
```

#### Using Node.js Directly

```bash
cd /path/to/auditsystem

# Load environment variables
export $(cat .env | xargs)

# Start server
npm start
```

#### Using Windows Service

```bash
# Start service
net start "Audit System"

# Or using PowerShell
Start-Service -Name "Audit System"
```

### Stopping the Service

#### Using PM2

```bash
# Stop application
pm2 stop audit-system

# Stop and remove from PM2
pm2 delete audit-system

# Verify stopped
pm2 status
```

#### Using Node.js Directly

Press `Ctrl+C` in the terminal running the server.

#### Using Windows Service

```bash
# Stop service
net stop "Audit System"

# Or using PowerShell
Stop-Service -Name "Audit System"
```

### Restarting the Service

#### Using PM2

```bash
# Restart application
pm2 restart audit-system

# Graceful reload (zero downtime)
pm2 reload audit-system
```

#### Using Windows Service

```bash
# Restart service
Restart-Service -Name "Audit System"
```

---

## Backup and Restore

### Creating Backups

#### Manual Backup

**Via API (requires admin authentication)**:
```bash
# Create backup
curl -X POST http://SERVER_IP:3000/api/backup/create \
  -H "Cookie: audit.sid=YOUR_SESSION_COOKIE" \
  -H "Content-Type: application/json" \
  -d '{"includeDocuments": false}'
```

**Via Script**:
```bash
# Create backup script (backup.sh or backup.ps1)
cd /path/to/auditsystem
node -e "
const { createBackup } = require('./server/utils/backup');
createBackup(false).then(result => {
  console.log('Backup created:', result);
}).catch(err => {
  console.error('Backup failed:', err);
});
"
```

#### Scheduled Backups

**Linux/macOS - Cron Job**:
```bash
# Edit crontab
crontab -e

# Daily backup at 2 AM
0 2 * * * cd /path/to/auditsystem && /usr/bin/node dist/index.js backup --schedule >> /var/log/audit-backup.log 2>&1
```

**Windows - Task Scheduler**:
1. Open Task Scheduler
2. Create Basic Task
3. Trigger: Daily at 2:00 AM
4. Action: Start a program
   - Program: `node`
   - Arguments: `dist/index.js backup --schedule`
   - Start in: `C:\path\to\auditsystem`

### Listing Backups

```bash
# Via API
curl http://SERVER_IP:3000/api/backup/list \
  -H "Cookie: audit.sid=YOUR_SESSION_COOKIE"

# Via file system
ls -lh /path/to/auditsystem/backups/
```

### Restoring from Backup

**⚠️ WARNING: Restore will overwrite existing data!**

#### Pre-Restore Checklist

1. **Create Current Backup**
   ```bash
   # Backup current state before restore
   curl -X POST http://SERVER_IP:3000/api/backup/create
   ```

2. **Stop Application**
   ```bash
   pm2 stop audit-system  # or stop service
   ```

3. **Verify Backup File**
   ```bash
   # Check backup file exists
   ls -lh /path/to/auditsystem/backups/db-backup-YYYY-MM-DD.sql
   
   # Verify metadata file exists
   ls -lh /path/to/auditsystem/backups/db-backup-YYYY-MM-DD.sql.meta.json
   ```

#### Restore Process

**Via API**:
```bash
# Restore backup (requires confirmation)
curl -X POST http://SERVER_IP:3000/api/backup/restore \
  -H "Cookie: audit.sid=YOUR_SESSION_COOKIE" \
  -H "Content-Type: application/json" \
  -d '{
    "backupPath": "/path/to/auditsystem/backups/db-backup-YYYY-MM-DD.sql",
    "confirm": "RESTORE"
  }'
```

**Via Script**:
```bash
# Restore script
cd /path/to/auditsystem
node -e "
const { restoreBackup } = require('./server/utils/backup');
restoreBackup('/path/to/backups/db-backup-YYYY-MM-DD.sql').then(result => {
  console.log('Restore result:', result);
}).catch(err => {
  console.error('Restore failed:', err);
});
"
```

#### Post-Restore Verification

1. **Start Application**
   ```bash
   pm2 start audit-system
   ```

2. **Verify Health**
   ```bash
   curl http://SERVER_IP:3000/api/health
   ```

3. **Test Login**
   - Login with a test user
   - Verify data is restored correctly

4. **Check Audit Logs**
   - Verify restore operation is logged

### Backup Maintenance

#### Cleaning Old Backups

**Manual Cleanup**:
```bash
# List backups older than 30 days
find /path/to/auditsystem/backups -name "db-backup-*.sql" -mtime +30

# Delete old backups (after verification)
find /path/to/auditsystem/backups -name "db-backup-*.sql" -mtime +30 -delete
find /path/to/auditsystem/backups -name "db-backup-*.sql.meta.json" -mtime +30 -delete
```

**Automated Cleanup Script**:
```bash
#!/bin/bash
# cleanup-old-backups.sh
BACKUP_DIR="/path/to/auditsystem/backups"
RETENTION_DAYS=30

find "$BACKUP_DIR" -name "db-backup-*.sql" -mtime +$RETENTION_DAYS -delete
find "$BACKUP_DIR" -name "db-backup-*.sql.meta.json" -mtime +$RETENTION_DAYS -delete

echo "Old backups cleaned up (older than $RETENTION_DAYS days)"
```

---

## Upgrades and Rollbacks

### Pre-Upgrade Checklist

1. **Create Full Backup**
   ```bash
   curl -X POST http://SERVER_IP:3000/api/backup/create
   ```

2. **Document Current Version**
   ```bash
   # Check current version
   cat package.json | grep version
   ```

3. **Verify Database Schema**
   ```bash
   psql $DATABASE_URL -c "\d users"
   psql $DATABASE_URL -c "\d cases"
   ```

4. **Notify Users**
   - Schedule maintenance window
   - Inform users of downtime

### Upgrade Process

1. **Stop Application**
   ```bash
   pm2 stop audit-system
   ```

2. **Backup Application Files**
   ```bash
   # Backup current application
   tar -czf audit-system-backup-$(date +%Y%m%d).tar.gz /path/to/auditsystem
   ```

3. **Update Code**
   ```bash
   cd /path/to/auditsystem
   
   # Option A: Git pull (if using Git)
   git pull origin main
   
   # Option B: Manual file replacement
   # Extract new files to temporary location
   # Compare with existing files
   # Replace files as needed
   ```

4. **Install Dependencies**
   ```bash
   npm install --production
   ```

5. **Run Database Migrations**
   ```bash
   # Check for new migrations
   ls -la migrations/
   
   # Run migrations if needed
   psql $DATABASE_URL -f migrations/004_production_indexes.sql
   ```

6. **Build Application**
   ```bash
   npm run build
   ```

7. **Verify Build**
   ```bash
   # Check dist/ directory
   ls -la dist/
   ls -la dist/public/
   ```

8. **Start Application**
   ```bash
   pm2 start audit-system
   ```

9. **Verify Health**
   ```bash
   curl http://SERVER_IP:3000/api/health
   ```

10. **Test Application**
    - Login with test user
    - Verify critical functions work
    - Check audit logs

### Rollback Process

**⚠️ Rollback should only be performed if upgrade fails or causes issues**

1. **Stop Application**
   ```bash
   pm2 stop audit-system
   ```

2. **Restore Application Files**
   ```bash
   # Restore from backup
   tar -xzf audit-system-backup-YYYYMMDD.tar.gz -C /
   ```

3. **Restore Database** (if database schema changed)
   ```bash
   # Restore database from backup created before upgrade
   curl -X POST http://SERVER_IP:3000/api/backup/restore \
     -H "Cookie: audit.sid=YOUR_SESSION_COOKIE" \
     -H "Content-Type: application/json" \
     -d '{
       "backupPath": "/path/to/backups/db-backup-PRE-UPGRADE.sql",
       "confirm": "RESTORE"
     }'
   ```

4. **Start Application**
   ```bash
   pm2 start audit-system
   ```

5. **Verify Rollback**
   ```bash
   curl http://SERVER_IP:3000/api/health
   ```

---

## Health Checks

### Application Health Check

```bash
# Basic health check
curl http://SERVER_IP:3000/api/health

# Expected response:
# {
#   "status": "healthy",
#   "timestamp": "2024-01-01T00:00:00.000Z",
#   "uptime": 3600,
#   "checks": {
#     "server": "ok",
#     "database": "ok"
#   }
# }

# Readiness check (more thorough)
curl http://SERVER_IP:3000/api/health/ready

# Liveness check (minimal)
curl http://SERVER_IP:3000/api/health/live
```

### Automated Health Monitoring

**Script** (`health-check.sh`):
```bash
#!/bin/bash
HEALTH_URL="http://SERVER_IP:3000/api/health"
ALERT_EMAIL="admin@example.com"

response=$(curl -s -o /dev/null -w "%{http_code}" $HEALTH_URL)

if [ "$response" != "200" ]; then
  echo "Health check failed: HTTP $response"
  # Send alert (email, SMS, etc.)
  # mail -s "Audit System Health Check Failed" $ALERT_EMAIL <<< "Health check returned HTTP $response"
  exit 1
fi

echo "Health check passed"
exit 0
```

**Cron Job** (every 5 minutes):
```bash
*/5 * * * * /path/to/health-check.sh
```

### Database Health Check

```bash
# Check database connection
psql $DATABASE_URL -c "SELECT 1;"

# Check database size
psql $DATABASE_URL -c "SELECT pg_size_pretty(pg_database_size('audit_system'));"

# Check table counts
psql $DATABASE_URL -c "SELECT schemaname, tablename, n_live_tup FROM pg_stat_user_tables ORDER BY n_live_tup DESC;"

# Check active connections
psql $DATABASE_URL -c "SELECT count(*) FROM pg_stat_activity WHERE datname='audit_system';"
```

---

## Monitoring and Logs

### Application Logs

#### Using PM2

```bash
# View logs
pm2 logs audit-system

# View last 100 lines
pm2 logs audit-system --lines 100

# Follow logs
pm2 logs audit-system --raw

# Clear logs
pm2 flush audit-system
```

#### Log Files

**Application Logs**:
- Location: Check `process.env.LOG_DIR` or console output
- Format: Timestamp, Level, Message

**Audit Logs**:
- Stored in database (`audit_logs` table)
- Access via application UI: Audit Logs page
- Or via API: `GET /api/audit-logs`

### Log Rotation

#### PM2 Log Rotation

```bash
# Install PM2 log rotation
pm2 install pm2-logrotate

# Configure rotation
pm2 set pm2-logrotate:max_size 10M
pm2 set pm2-logrotate:retain 30
pm2 set pm2-logrotate:compress true
```

#### Manual Log Rotation

**Linux/macOS** (`/etc/logrotate.d/audit-system`):
```
/path/to/auditsystem/logs/*.log {
    daily
    rotate 30
    compress
    delaycompress
    missingok
    notifempty
    create 0644 audit audit
}
```

### Event Log Rotation

**Via Application**:
- Navigate to Audit Logs page
- Use "Clear Filtered Logs" to remove old logs (admin only)

**Via Script**:
```bash
# Delete audit logs older than 90 days
psql $DATABASE_URL -c "
DELETE FROM audit_logs 
WHERE created_at < NOW() - INTERVAL '90 days';
"
```

---

## Troubleshooting

### Common Issues

#### 1. Application Won't Start

**Symptoms**: Service fails to start, returns error

**Diagnosis**:
```bash
# Check logs
pm2 logs audit-system --err

# Check environment variables
pm2 env audit-system

# Verify port is available
netstat -an | grep 3000
```

**Solutions**:
- Change `PORT` in `.env` if port is in use
- Verify `DATABASE_URL` is correct
- Check file permissions
- Verify Node.js version compatibility

#### 2. Database Connection Errors

**Symptoms**: "Connection refused", "authentication failed"

**Diagnosis**:
```bash
# Test database connection
psql $DATABASE_URL -c "SELECT 1;"

# Check PostgreSQL status
systemctl status postgresql  # Linux
brew services list | grep postgresql  # macOS
```

**Solutions**:
- Verify PostgreSQL is running
- Check `DATABASE_URL` in `.env`
- Verify database user has correct permissions
- Check firewall rules

#### 3. High Memory Usage

**Symptoms**: Application slows down, memory usage high

**Diagnosis**:
```bash
# Check memory usage
pm2 monit

# Check database connections
psql $DATABASE_URL -c "SELECT count(*) FROM pg_stat_activity WHERE datname='audit_system';"
```

**Solutions**:
- Restart application: `pm2 restart audit-system`
- Increase server RAM
- Optimize database queries
- Check for memory leaks in logs

#### 4. Session Issues

**Symptoms**: Users logged out frequently, session not persisting

**Diagnosis**:
```bash
# Check session table
psql $DATABASE_URL -c "SELECT count(*) FROM session;"

# Check SESSION_SECRET in .env
grep SESSION_SECRET .env
```

**Solutions**:
- Verify `SESSION_SECRET` is set and consistent
- Check session table exists
- Verify cookie settings in browser
- Check session timeout configuration

#### 5. Permission Denied Errors

**Symptoms**: Users cannot access expected resources

**Diagnosis**:
- Check audit logs for permission denials
- Verify user roles and packages in database
- Check permission calculation logic

**Solutions**:
- Verify RBAC setup is correct
- Check user permissions via `/api/auth/me`
- Review permission service logs

---

## Emergency Procedures

### Application Down

1. **Assess Situation**
   ```bash
   # Check if process is running
   pm2 status
   ```

2. **Restart Application**
   ```bash
   pm2 restart audit-system
   ```

3. **If Restart Fails**
   ```bash
   # Check logs for errors
   pm2 logs audit-system --err --lines 50
   
   # Check database connectivity
   psql $DATABASE_URL -c "SELECT 1;"
   
   # Check disk space
   df -h
   ```

4. **Restore from Backup** (last resort)
   - Follow rollback procedure above

### Database Corruption

1. **Stop Application**
   ```bash
   pm2 stop audit-system
   ```

2. **Create Current Backup** (if possible)
   ```bash
   pg_dump -U audit_user audit_system > emergency-backup.sql
   ```

3. **Restore from Latest Backup**
   - Follow restore procedure above

4. **Verify Data Integrity**
   ```bash
   psql $DATABASE_URL -c "SELECT count(*) FROM users;"
   psql $DATABASE_URL -c "SELECT count(*) FROM cases;"
   ```

### Security Incident

1. **Immediate Actions**
   - Change all admin passwords
   - Revoke affected user sessions
   - Review audit logs for suspicious activity

2. **Notify Stakeholders**
   - Inform management
   - Document incident

3. **Investigation**
   - Review audit logs
   - Check for unauthorized access
   - Review system logs

4. **Remediation**
   - Apply security patches
   - Update credentials
   - Review security configurations

---

## Support Contacts

- **Technical Support**: [Contact Information]
- **Database Administrator**: [Contact Information]
- **Security Team**: [Contact Information]

---

## Appendices

### A. Quick Reference Commands

```bash
# Start/Stop
pm2 start audit-system
pm2 stop audit-system
pm2 restart audit-system

# Health Check
curl http://SERVER_IP:3000/api/health

# Backup
curl -X POST http://SERVER_IP:3000/api/backup/create -H "Cookie: audit.sid=..."

# Logs
pm2 logs audit-system --lines 50
```

### B. File Locations

- Application: `/path/to/auditsystem`
- Backups: `/path/to/auditsystem/backups`
- Documents: `/path/to/auditsystem/docvault`
- Logs: Check PM2 or application configuration
- Environment: `/path/to/auditsystem/.env`

### C. Important URLs

- Application: `http://SERVER_IP:3000`
- Health Check: `http://SERVER_IP:3000/api/health`
- API Documentation: Check application code

