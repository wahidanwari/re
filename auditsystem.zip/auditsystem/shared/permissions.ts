// New RBAC System - Shared between client and server

export type Permission =
  | 'entities:view'
  | 'entities:create'
  | 'cases:view'
  | 'cases:assign_to_auditor'
  | 'cases:assign_to_group'
  | 'cases:complete'
  | 'reports:generate'
  | 'users:manage'
  | 'groups:manage'
  | 'groups:set_targets'
  | 'tickets:submit'
  | 'tickets:approve'
  | 'documents:download'
  | 'documents:upload'
  | 'logs:view'
  | 'settings:manage'
  | 'reports:override_complete'
  | 'archives:view'
  | 'archives:upload'
  | 'archives:delete';

export type Role = 'system_admin' | 'director' | 'senior_auditor' | 'auditor';
export type PermissionPackage = 'acting_coordinator' | 'approval_authority';

// Base role permissions
const baseRolePermissions: Record<Role, Permission[]> = {
  system_admin: [
    'entities:view',
    'entities:create',
    'cases:view',
    'cases:assign_to_auditor',
    'cases:assign_to_group',
    'cases:complete',
    'reports:generate',
    'users:manage',
    'groups:manage',
    'tickets:submit',
    'tickets:approve',
    'documents:download',
    'documents:upload',
    'logs:view',
    'settings:manage',
    'archives:view',
    'archives:upload',
    'archives:delete',
  ],
  director: [
    'entities:view',
    'cases:view',
    'documents:download',
    'reports:generate',
    'groups:set_targets',
    'reports:override_complete',
    'archives:view',
    'archives:upload',
  ],
  senior_auditor: [
    'entities:view',
    'entities:create',
    'cases:view',
    'cases:assign_to_auditor',
    'cases:complete',
    'documents:upload',
    'reports:generate',
    'tickets:submit',
    'reports:override_complete',
  ],
  auditor: [
    'cases:view',
    'cases:complete',
    'documents:upload',
    'tickets:submit',
  ],
};

// Package permissions - These MERGE with base role permissions
const packagePermissions: Record<PermissionPackage, Permission[]> = {
  acting_coordinator: [
    // View permissions - Coordinator can view all data
    'entities:view',
    'cases:view',
    'documents:download', // Coordinator can download documents
    // Management permissions
    'cases:assign_to_group',
    'entities:create',
    'reports:generate',
    'archives:view',
    'archives:upload',
    // Note: Coordinator does NOT get users:manage or groups:manage by default
    // These are reserved for system_admin and senior_auditor roles
  ],
  approval_authority: [
    'tickets:approve',
  ],
};

/**
 * Calculate effective permissions for a user
 * Combines base role permissions with package permissions
 * Packages MERGE with base role (add permissions, don't remove)
 */
export function getEffectivePermissions(
  role: Role,
  packages: PermissionPackage[] = []
): Record<Permission, boolean> {
  // Start with base role permissions
  const basePerms = baseRolePermissions[role] || [];
  const effective: Record<Permission, boolean> = {
    'entities:view': false,
    'entities:create': false,
    'cases:view': false,
    'cases:assign_to_auditor': false,
    'cases:assign_to_group': false,
    'cases:complete': false,
    'reports:generate': false,
    'users:manage': false,
    'groups:manage': false,
    'groups:set_targets': false,
    'tickets:submit': false,
    'tickets:approve': false,
    'documents:download': false,
    'documents:upload': false,
    'logs:view': false,
    'settings:manage': false,
    'reports:override_complete': false,
    'archives:view': false,
    'archives:upload': false,
    'archives:delete': false,
  };

  // Set base role permissions
  basePerms.forEach(perm => {
    effective[perm] = true;
  });

  // Apply package permissions (merge/add)
  packages.forEach(pkg => {
    const pkgPerms = packagePermissions[pkg] || [];
    pkgPerms.forEach(perm => {
      effective[perm] = true;
    });
  });

  return effective;
}

/**
 * Check if user has a specific permission
 */
export function hasPermission(
  role: Role,
  packages: PermissionPackage[],
  permission: Permission
): boolean {
  const effective = getEffectivePermissions(role, packages);
  return effective[permission] === true;
}

/**
 * Get list of permissions user has
 */
export function getUserPermissionList(
  role: Role,
  packages: PermissionPackage[] = []
): Permission[] {
  const effective = getEffectivePermissions(role, packages);
  return Object.entries(effective)
    .filter(([_, has]) => has)
    .map(([perm]) => perm as Permission);
}
