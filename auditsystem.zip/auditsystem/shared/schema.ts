import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, boolean, jsonb, integer, numeric } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  // auditId: Unique constraint is enforced at DB level via partial unique index
  // (users_audit_id_active_unique) - only active users must have unique auditIds
  // This allows deleted users' auditIds to be reused
  auditId: text("audit_id").notNull(),
  password: text("password").notNull(),
  fullName: text("full_name").notNull(),
  role: text("role").notNull(),
  groupId: varchar("group_id"),
  permissionPackages: text("permission_packages").array(),
  phoneNumber: text("phone_number"),
  mustChangePassword: boolean("must_change_password").default(false),
  passwordExpiresAt: timestamp("password_expires_at"),
  passwordChangedAt: timestamp("password_changed_at"),
  lastLoginAt: timestamp("last_login_at"),
  isActive: boolean("is_active").default(true),
  emailNotifications: boolean("email_notifications").default(true),
  mobileNotifications: boolean("mobile_notifications").default(true),
  preferredLanguage: text("preferred_language").default('dari'),
  permissionsVersion: integer("permissions_version").default(1),
  createdAt: timestamp("created_at").defaultNow(),
});

export const groups = pgTable("groups", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  code: text("code").notNull().unique(),
  name: text("name").notNull(),
  namePashto: text("name_pashto"),
  description: text("description"),
  isActive: boolean("is_active").default(true),
  monthlyTaxTarget: numeric("monthly_tax_target", { precision: 15, scale: 2 }), // Optional monthly tax collection target
  createdAt: timestamp("created_at").defaultNow(),
});

export const groupMembers = pgTable("group_members", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  groupId: varchar("group_id").notNull(),
  userId: varchar("user_id").notNull(),
  assignedRole: text("assigned_role").notNull(),
  joinedAt: timestamp("joined_at").defaultNow(),
  isActive: boolean("is_active").default(true),
});

export const groupTargets = pgTable("group_targets", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  groupId: varchar("group_id").notNull(),
  yearShamsi: text("year_shamsi").notNull(),
  targetCaseCount: integer("target_case_count"),
  targetMonetary: text("target_monetary"),
  setBy: varchar("set_by").notNull(),
  setAt: timestamp("set_at").defaultNow(),
});

export const entities = pgTable("entities", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  companyName: text("company_name").notNull(), // نام نهاد
  tin: text("tin").notNull().unique(), // نمبر تشخیصیه
  businessNature: text("business_nature").notNull(), // ماهیت تشبث
  // Additional fields for entity details (not audit-related)
  registeredAddress: text("registered_address"), // آدرس نهاد
  contactPerson: text("contact_person"), // نماینده
  phone: text("phone"), // شماره تماس نماینده
  notes: text("notes"),
  importBatchId: integer("import_batch_id"),
  createdByImport: boolean("created_by_import").default(false),
  status: text("status").default("Active"), // Entity lifecycle status: Active, Under Audit, Dormant, Deleted/Archived
  createdAt: timestamp("created_at").defaultNow(),
});

// Case Status Enum - FINAL 6 STATUSES ONLY
// NOTE: Status values must match database constraint cases_status_check
export const CaseStatus = {
  CREATED: 'ایجاد شده',
  PENDING_SENIOR_REVIEW: 'در انتظار بررسی بازرس ارشد', // Must match database constraint
  UNDER_REVIEW: 'در حال بررسی',
  PENDING_DOCUMENTS: 'در انتظار تکمیل مدارک',
  SUSPENDED: 'تعلیق شده',
  COMPLETED: 'تکمیل شده',
} as const;

export type CaseStatus = typeof CaseStatus[keyof typeof CaseStatus];

// Case Status Keys (English keys for internal logic, mapped to Dari labels in UI)
export const CaseStatusKey = {
  CREATED: 'created',
  PENDING_SENIOR_REVIEW: 'pending_senior_review',
  UNDER_REVIEW: 'under_review',
  PENDING_DOCUMENTS: 'pending_documents',
  SUSPENDED: 'suspended',
  COMPLETED: 'completed',
} as const;

export type CaseStatusKey = typeof CaseStatusKey[keyof typeof CaseStatusKey];

// Status key to Dari label mapping
export const statusKeyToLabel: Record<CaseStatusKey, string> = {
  [CaseStatusKey.CREATED]: CaseStatus.CREATED,
  [CaseStatusKey.PENDING_SENIOR_REVIEW]: CaseStatus.PENDING_SENIOR_REVIEW,
  [CaseStatusKey.UNDER_REVIEW]: CaseStatus.UNDER_REVIEW,
  [CaseStatusKey.PENDING_DOCUMENTS]: CaseStatus.PENDING_DOCUMENTS,
  [CaseStatusKey.SUSPENDED]: CaseStatus.SUSPENDED,
  [CaseStatusKey.COMPLETED]: CaseStatus.COMPLETED,
};

export const cases = pgTable("cases", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  caseId: text("case_id").notNull().unique(),
  caseNumber: integer("case_number").unique(), // Manual numeric case number
  entityId: varchar("entity_id").notNull(),
  companyName: text("company_name").notNull(),
  tin: text("tin").notNull(),
  businessNature: text("business_nature"),
  periodsUnderReview: text("periods_under_review").notNull(),
  auditYearRange: text("audit_year_range"), // سال‌های بررسی (e.g., "1399–1401") - kept for backward compatibility
  auditYearStart: integer("audit_year_start"), // سال شروع بررسی (numeric, e.g., 1399)
  auditYearEnd: integer("audit_year_end"), // سال پایان بررسی (numeric, e.g., 1401)
  referralDate: text("referral_date").notNull(),
  groupReferrer: varchar("group_referrer").notNull(), // گروه ارجاع‌دهنده (sender group - inherited from entity)
  receivingGroup: varchar("receiving_group"), // گروه دریافت‌کننده (receiving audit group - PHASE 1)
  assignedTo: varchar("assigned_to"),
  assignedAuditor: varchar("assigned_auditor"), // بازرس اختصاص داده شده (explicit auditor assignment)
  assignedBy: varchar("assigned_by").references(() => users.id, { onDelete: "set null" }),
  assignedAt: timestamp("assigned_at"),
  status: text("status").notNull().default("ایجاد شده"),
  notes: text("notes"),
  approvedBy: varchar("approved_by"),
  approvedAt: timestamp("approved_at"),
  rejectedBy: varchar("rejected_by"),
  rejectedAt: timestamp("rejected_at"),
  rejectionReason: text("rejection_reason"),
  completedBy: varchar("completed_by"),
  completedAt: timestamp("completed_at"),
  reopenedBy: varchar("reopened_by").references(() => users.id, { onDelete: "set null" }),
  reopenedAt: timestamp("reopened_at"),
  reopenReason: text("reopen_reason"),
  transactionId: text("transaction_id"), // نمبر آویز
  paymentDate: text("payment_date"), // تاریخ پرداخت مالیات (DD-MM-YYYY format)
  committeeId: varchar("committee_id"), // Committee ID if case was created through committee intake (OLD - deprecated)
  // New Committee Module Fields
  currentAssignmentId: varchar("current_assignment_id").references(() => committeeCaseAssignments.id, { onDelete: "set null" }),
  currentAuditGroupId: varchar("current_audit_group_id").references(() => groups.id, { onDelete: "set null" }),
  // Case Flags (replaces old lifecycle statuses)
  isLawEnforcement: boolean("is_law_enforcement").default(false), // ارسال‌شده به تنفیذ قانون
  isTaxInstallment: boolean("is_tax_installment").default(false), // در اقساط
  isCancelled: boolean("is_cancelled").default(false), // لغو شده
  // Override fields - original values
  institutionInfoOriginal: text("institution_info_original"), // Original extracted اطلاعات نهاد
  // Override fields - manual values
  institutionInfoManual: text("institution_info_manual"), // Manual override
  institutionInfoOverriddenBy: varchar("institution_info_overridden_by").references(() => users.id, { onDelete: "set null" }),
  institutionInfoOverriddenAt: timestamp("institution_info_overridden_at"),
  representativeNameManual: varchar("representative_name_manual"), // Manual override نماینده
  representativePhoneManual: varchar("representative_phone_manual"), // Manual override شماره تماس نماینده
  institutionAddressManual: text("institution_address_manual"), // Manual override آدرس نهاد
  createdAt: timestamp("created_at").defaultNow(),
});

// Case Status Transitions Table
export const caseStatusTransitions = pgTable("case_status_transitions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  caseId: varchar("case_id").notNull().references(() => cases.id, { onDelete: "cascade" }),
  fromStatus: text("from_status").notNull(),
  toStatus: text("to_status").notNull(),
  transitionName: text("transition_name").notNull(),
  transitionedBy: varchar("transitioned_by").notNull().references(() => users.id, { onDelete: "set null" }),
  transitionedAt: timestamp("transitioned_at").notNull().defaultNow(),
  notes: text("notes"),
  rejectionReason: text("rejection_reason"),
  metadata: jsonb("metadata"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Case Metrics Table - Senior auditor reporting metrics
export const caseMetrics = pgTable("case_metrics", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  caseId: varchar("case_id").notNull().unique().references(() => cases.id, { onDelete: "cascade" }),
  installmentsThisMonth: integer("installments_this_month").default(0),
  nonresponsiveCount: integer("nonresponsive_count").default(0),
  incomingDocuments: integer("incoming_documents").default(0),
  outgoingDocuments: integer("outgoing_documents").default(0),
  incomingInquiries: integer("incoming_inquiries").default(0),
  outgoingInquiries: integer("outgoing_inquiries").default(0),
  remarks: text("remarks"),
  lastUpdatedBy: varchar("last_updated_by").references(() => users.id, { onDelete: "set null" }),
  lastUpdatedAt: timestamp("last_updated_at").defaultNow(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Installment Payments Table
export const installmentPayments = pgTable("installment_payments", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  caseId: varchar("case_id").notNull().references(() => cases.id, { onDelete: "cascade" }),
  amountPaid: numeric("amount_paid", { precision: 15, scale: 2 }).notNull().default("0"),
  paymentDate: timestamp("payment_date", { mode: "date" }).notNull(),
  remainingBalance: numeric("remaining_balance", { precision: 15, scale: 2 }).notNull().default("0"),
  notes: text("notes"),
  createdBy: varchar("created_by").notNull().references(() => users.id, { onDelete: "set null" }),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Payments Table - Traceable payment ledger for all tax payments
// PHASE 1: Payment Traceability Foundation
export const payments = pgTable("payments", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  caseId: varchar("case_id").notNull().references(() => cases.id, { onDelete: "cascade" }),
  paymentDate: timestamp("payment_date", { mode: "date" }).notNull(),
  paymentAmount: numeric("payment_amount", { precision: 15, scale: 2 }).notNull(),
  paymentType: varchar("payment_type", { length: 20 }).notNull(), // 'normal' | 'installment'
  createdAt: timestamp("created_at").defaultNow(),
});

// Case Monthly Snapshots Table - Monthly remaining balance snapshots per case
// PHASE 2: Monthly Remaining Balance Snapshot
export const caseMonthlySnapshots = pgTable("case_monthly_snapshots", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  caseId: varchar("case_id").notNull().references(() => cases.id, { onDelete: "cascade" }),
  reportMonth: varchar("report_month", { length: 7 }).notNull(), // YYYY-MM format (e.g., "1404-03")
  remainingBalanceEndOfMonth: numeric("remaining_balance_end_of_month", { precision: 15, scale: 2 }).notNull(),
  totalPaidInMonth: numeric("total_paid_in_month", { precision: 15, scale: 2 }).notNull().default("0"),
  confirmedAmount: numeric("confirmed_amount", { precision: 15, scale: 2 }), // Store confirmedAmount for reference
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Case Flags Table - Track nonresponsive attempts, escalations, etc.
export const caseFlags = pgTable("case_flags", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  caseId: varchar("case_id").notNull().references(() => cases.id, { onDelete: "cascade" }),
  type: varchar("type").notNull(), // 'nonresponsive_attempt', 'nonresponsive_mark', 'escalation_to_enforcement', 'assignment', 'override', etc.
  details: jsonb("details"), // Flexible storage for attempt count, notes, etc.
  createdBy: varchar("created_by").notNull().references(() => users.id, { onDelete: "set null" }),
  createdAt: timestamp("created_at").defaultNow(),
});

// Case Section Status Table - Track section completion
export const caseSectionStatus = pgTable("case_section_status", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  caseId: varchar("case_id").notNull().references(() => cases.id, { onDelete: "cascade" }),
  sectionId: varchar("section_id").notNull(), // 'section_1', 'section_2', etc.
  isCompleted: boolean("is_completed").default(false),
  completedBy: varchar("completed_by").references(() => users.id, { onDelete: "set null" }),
  completedAt: timestamp("completed_at"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const tickets = pgTable("tickets", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  ticketId: text("ticket_id").notNull().unique(),
  type: text("type").notNull(),
  caseId: varchar("case_id"),
  requestedBy: varchar("requested_by").notNull(),
  status: text("status").notNull().default("منتظر تایید"),
  description: text("description"),
  auditId: text("audit_id"),
  groupId: varchar("group_id"),
  phoneNumber: text("phone_number"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const notifications = pgTable("notifications", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  message: text("message").notNull(),
  messagePashto: text("message_pashto"),
  type: text("type").notNull(),
  isRead: boolean("is_read").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const auditLogs = pgTable("audit_logs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id"),
  action: text("action").notNull(),
  entityType: text("entity_type"),
  entityId: varchar("entity_id"),
  details: jsonb("details"), // Consolidated JSONB field
  ipAddress: text("ip_address"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Canonical RBAC Tables
export const roles = pgTable("roles", {
  id: integer("id").primaryKey(),
  name: varchar("name", { length: 64 }).notNull().unique(),
  description: text("description"),
});

export const permissions = pgTable("permissions", {
  id: integer("id").primaryKey(),
  name: varchar("name", { length: 128 }).notNull().unique(),
  description: text("description"),
});

export const rolePermissions = pgTable("role_permissions", {
  id: integer("id").primaryKey(),
  roleId: integer("role_id").notNull().references(() => roles.id, { onDelete: "cascade" }),
  permissionId: integer("permission_id").notNull().references(() => permissions.id, { onDelete: "cascade" }),
  allow: boolean("allow").notNull().default(true),
});

export const packages = pgTable("packages", {
  id: integer("id").primaryKey(),
  name: varchar("name", { length: 64 }).notNull().unique(),
  description: text("description"),
});

export const packagePermissions = pgTable("package_permissions", {
  id: integer("id").primaryKey(),
  packageId: integer("package_id").notNull().references(() => packages.id, { onDelete: "cascade" }),
  permissionId: integer("permission_id").notNull().references(() => permissions.id, { onDelete: "cascade" }),
  allow: boolean("allow").notNull().default(true),
});

export const userRoles = pgTable("user_roles", {
  id: integer("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  roleId: integer("role_id").notNull().references(() => roles.id, { onDelete: "cascade" }),
  assignedAt: timestamp("assigned_at").defaultNow(),
});

export const userPackages = pgTable("user_packages", {
  id: integer("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  packageId: integer("package_id").notNull().references(() => packages.id, { onDelete: "cascade" }),
  assignedAt: timestamp("assigned_at").defaultNow(),
  expiresAt: timestamp("expires_at"),
});

export const documents = pgTable("documents", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  caseId: varchar("case_id").notNull(),
  uploaderId: varchar("uploader_id").notNull(),
  storagePath: text("storage_path").notNull(),
  mimeType: text("mime_type").notNull(),
  sizeBytes: integer("size_bytes").notNull(),
  docType: text("doc_type").notNull(),
  docDate: text("doc_date").notNull(),
  isFinal: boolean("is_final").default(false),
  description: text("description"),
  isRevoked: boolean("is_revoked").default(false),
  revokedBy: varchar("revoked_by"),
  revokedAt: timestamp("revoked_at"),
  revocationReason: text("revocation_reason"),
  uploadedAt: timestamp("uploaded_at").defaultNow(),
});

export const systemSettings = pgTable("system_settings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  key: text("key").notNull().unique(),
  value: jsonb("value").notNull(),
  category: text("category").notNull(),
  description: text("description"),
  updatedBy: varchar("updated_by"),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Entity Types (PHASE 2 - Dynamic entity type management)
export const entityTypes = pgTable("entity_types", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: varchar("name", { length: 128 }).notNull().unique(),
  status: varchar("status", { length: 20 }).notNull().default("active"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Case Reports - Comprehensive reporting data for case completion
export const caseReports = pgTable("case_reports", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  caseId: varchar("case_id").notNull().unique().references(() => cases.id, { onDelete: "cascade" }),
  
  // Section 1: مشخصات نهاد (Entity Details)
  // Most fields auto-populate from case/entity, but some need manual entry:
  finalDocumentDate: text("final_document_date"), // تاریخ صادره مکتوب نهایی
  capitalPeriod: text("capital_period"), // دوران سرمایه
  
  // Section 2: بیرون‌نویسی‌ها (Extractions)
  salaryTax: text("salary_tax"), // مالیه موضوعی معاشات
  rentTax: text("rent_tax"), // مالیه موضوعی بر کرایه
  contractTax: text("contract_tax"), // مالیه موضوعی قراردادی
  profitTransactionTax: text("profit_transaction_tax"), // مالیات معاملات انتفاعی
  incomeTax: text("income_tax"), // مالیات بر عایدات
  reducedLoss: text("reduced_loss"), // ضرر کاهش یافته
  reducedRemainingAmount: text("reduced_remaining_amount"), // مبلغ فاضل تحویل کاهش یافته
  confirmedAmount: text("confirmed_amount"), // مبلغ تثبیت شده
  collectedCurrentMonth: text("collected_current_month"), // مبلغ تحصیل شده طی برج جاری
  remainingCollectible: text("remaining_collectible"), // الباقی مبلغ قابل تحصیل
  activityStatus: text("activity_status"), // وضعیت فعالیت
  attachmentNumber: text("attachment_number"), // نمبر آویز
  attachmentDate: text("attachment_date"), // تاریخ آویز
  
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Case Reports V2 - Structured reporting with sections
export const caseReportsV2 = pgTable("case_reports_v2", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  caseId: varchar("case_id").notNull().unique().references(() => cases.id, { onDelete: "cascade" }),
  
  // Report Status
  status: text("status").notNull().default("draft"), // 'draft', 'completed', 'locked'
  version: integer("version").notNull().default(1),
  
  // Section 1: Entity Details - Basic
  companyName: text("company_name").notNull(),
  tin: text("tin").notNull(),
  businessNature: text("business_nature"),
  groupReferrer: text("group_referrer").notNull(),
  referralDate: text("referral_date").notNull(),
  periodsUnderReview: text("periods_under_review").notNull(),
  finalDocumentDate: text("final_document_date"),
  capitalPeriod: text("capital_period"),
  
  // Section 1: Address Information
  province: text("province"),
  district: text("district"),
  streetAddress: text("street_address"),
  postalCode: text("postal_code"),
  phone: text("phone"),
  email: text("email"),
  
  // Section 1: Registration Details
  registrationNumber: text("registration_number"),
  registrationDate: text("registration_date"),
  businessLicenseNumber: text("business_license_number"),
  businessLicenseDate: text("business_license_date"),
  
  // Section 1: Tax Information
  taxOffice: text("tax_office"),
  taxRegistrationDate: text("tax_registration_date"),
  taxOfficeCode: text("tax_office_code"),
  
  // Section 2: Tax Types
  salaryTax: numeric("salary_tax", { precision: 15, scale: 2 }).default("0"),
  rentTax: numeric("rent_tax", { precision: 15, scale: 2 }).default("0"),
  contractTax: numeric("contract_tax", { precision: 15, scale: 2 }).default("0"),
  profitTransactionTax: numeric("profit_transaction_tax", { precision: 15, scale: 2 }).default("0"),
  incomeTax: numeric("income_tax", { precision: 15, scale: 2 }).default("0"),
  withholdingTax: numeric("withholding_tax", { precision: 15, scale: 2 }).default("0"),
  penaltyTax: numeric("penalty_tax", { precision: 15, scale: 2 }).default("0"),
  interest: numeric("interest", { precision: 15, scale: 2 }).default("0"),
  otherTaxes: numeric("other_taxes", { precision: 15, scale: 2 }).default("0"),
  
  // Section 2: Financial Calculations
  reducedLoss: numeric("reduced_loss", { precision: 15, scale: 2 }).default("0"),
  reducedRemainingAmount: numeric("reduced_remaining_amount", { precision: 15, scale: 2 }).default("0"),
  confirmedAmount: numeric("confirmed_amount", { precision: 15, scale: 2 }).default("0"),
  collectedCurrentMonth: numeric("collected_current_month", { precision: 15, scale: 2 }).default("0"),
  remainingCollectible: numeric("remaining_collectible", { precision: 15, scale: 2 }).default("0"),
  
  // Section 2: Calculation Details
  taxBase: numeric("tax_base", { precision: 15, scale: 2 }),
  taxRate: numeric("tax_rate", { precision: 5, scale: 2 }),
  calculationMethod: text("calculation_method"),
  
  // Section 2: Payment Information
  paymentMethod: text("payment_method"),
  paymentReferenceNumber: text("payment_reference_number"),
  paymentDate: text("payment_date"),
  bankName: text("bank_name"),
  bankAccountNumber: text("bank_account_number"),
  bankBranch: text("bank_branch"),
  
  // Section 2: Status & Attachment
  activityStatus: text("activity_status"),
  attachmentNumber: text("attachment_number"),
  attachmentDate: text("attachment_date"),
  
  // Section 3: Findings & Recommendations
  findingsSummary: text("findings_summary"),
  detailedFindings: text("detailed_findings"),
  riskAssessment: text("risk_assessment"), // 'کم', 'متوسط', 'زیاد'
  recommendations: text("recommendations"),
  actionItems: text("action_items"),
  followUpRequired: boolean("follow_up_required").default(false),
  followUpDate: text("follow_up_date"),
  
  // Section 4: Supporting Documents
  documentsReviewed: jsonb("documents_reviewed").default(sql`'[]'::jsonb`),
  documentsAttached: jsonb("documents_attached").default(sql`'[]'::jsonb`),
  missingDocuments: text("missing_documents"),
  documentReviewDate: text("document_review_date"),
  documentReviewNotes: text("document_review_notes"),
  
  // Section 5: Approval & Signatures
  preparedBy: varchar("prepared_by").references(() => users.id, { onDelete: "set null" }),
  preparedAt: timestamp("prepared_at"),
  preparedByRole: text("prepared_by_role"),
  reviewedBy: varchar("reviewed_by").references(() => users.id, { onDelete: "set null" }),
  reviewedAt: timestamp("reviewed_at"),
  reviewedByRole: text("reviewed_by_role"),
  reviewNotes: text("review_notes"),
  approvedBy: varchar("approved_by").references(() => users.id, { onDelete: "set null" }),
  approvedAt: timestamp("approved_at"),
  approvedByRole: text("approved_by_role"),
  
  // Metadata
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
  lastSavedBy: varchar("last_saved_by").references(() => users.id, { onDelete: "set null" }),
  lastSavedAt: timestamp("last_saved_at"),
});

// Case Report History - Track all changes
export const caseReportHistory = pgTable("case_report_history", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  reportId: varchar("report_id").notNull().references(() => caseReportsV2.id, { onDelete: "cascade" }),
  version: integer("version").notNull(),
  changedBy: varchar("changed_by").notNull().references(() => users.id, { onDelete: "set null" }),
  changedAt: timestamp("changed_at").notNull().defaultNow(),
  changeType: text("change_type").notNull(), // 'create', 'update', 'status_change', 'section_complete'
  section: text("section"), // 'section_1', 'section_2', etc.
  changes: jsonb("changes"),
  snapshot: jsonb("snapshot"),
  notes: text("notes"),
});

// Ministry Reports - Manual input fields for Ministry of Finance Detailed Audit Reports
export const ministryReports = pgTable("ministry_reports", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  groupId: varchar("group_id").notNull().references(() => groups.id, { onDelete: "cascade" }),
  monthShamsi: integer("month_shamsi").notNull(), // 1-12
  yearShamsi: integer("year_shamsi").notNull(), // Shamsi year (e.g., 1404)
  
  // Manual input fields (filled by Senior Auditor)
  lettersReceived: integer("letters_received").default(0), // تعداد مکتوب های وارده
  lettersSent: integer("letters_sent").default(0), // تعداد مکتوب های صادره
  inquiriesReceived: integer("inquiries_received").default(0), // تعداد استعلام های وارده
  inquiriesSent: integer("inquiries_sent").default(0), // تعداد استعلام های صادره
  notes: text("notes"), // ملاحظات
  
  // Metadata
  lastUpdatedBy: varchar("last_updated_by").references(() => users.id, { onDelete: "set null" }),
  lastUpdatedAt: timestamp("last_updated_at").defaultNow(),
  createdAt: timestamp("created_at").defaultNow(),
});

// WORKFLOW TABLES: Temporary tables for audit reporting workflow calculations
// These tables link to the master entities table via TIN ( نمبر تشخیصیه)
// They are read-only from entities and used for workflow calculations and reporting
// DO NOT modify or overwrite any data in the master entity table

// Monthly Transactions - Per-entity monthly transaction data
// Purpose: Store per-entity monthly audit data without modifying the master entity table
export const monthlyTransactions = pgTable("monthly_transactions", {
  // TransactionID: Workflow-generated unique ID
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  
  // EntityTIN: Link to master entity table ( نمبر تشخیصیه)
  entityTin: text("entity_tin").notNull(), //  نمبر تشخیصیه - links to entities.tin
  
  // Time Period (Shamsi Calendar)
  monthShamsi: integer("month_shamsi").notNull(), // برج (1-12)
  yearShamsi: integer("year_shamsi").notNull(), // سال (Shamsi year, e.g., 1404)
  
  // Tax Fields (مالیات‌ها)
  taxSalary: numeric("tax_salary", { precision: 15, scale: 2 }).default("0"), // مالیه موضوعی معاشات
  taxRent: numeric("tax_rent", { precision: 15, scale: 2 }).default("0"), // مالیه موضوعی بر کرایه
  taxContract: numeric("tax_contract", { precision: 15, scale: 2 }).default("0"), // مالیه موضوعی قراردادی
  taxProfit: numeric("tax_profit", { precision: 15, scale: 2 }).default("0"), // مالیه موضوعی معاملات انتفاعی
  incomeTax: numeric("income_tax", { precision: 15, scale: 2 }).default("0"), // مالیات بر عایدات
  
  // Financial Amounts (مبالغ مالی)
  lossReduction: numeric("loss_reduction", { precision: 15, scale: 2 }).default("0"), // ضرر کاهش یافته
  collectedAmount: numeric("collected_amount", { precision: 15, scale: 2 }).default("0"), // مبلغ تحصیل شده طی برج جاری
  remainingAmount: numeric("remaining_amount", { precision: 15, scale: 2 }).default("0"), // الباقی مبلغ قابل تحصیل
  stabilizedAmount: numeric("stabilized_amount", { precision: 15, scale: 2 }).default("0"), // مبلغ تثبیت شده
  
  // Correspondence Data (مکاتبات)
  correspondencesIn: integer("correspondences_in").default(0), // تعداد مکتوب های وارده
  correspondencesOut: integer("correspondences_out").default(0), // تعداد مکتوب های صادره
  
  // Inquiry Data (استعلامات)
  inquiriesIn: integer("inquiries_in").default(0), // تعداد استعلام های وارده
  inquiriesOut: integer("inquiries_out").default(0), // تعداد استعلام های صادره
  
  // Notes (ملاحظات)
  notes: text("notes"), // ملاحظات
  
  // Metadata
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Internal Report - Aggregated per-entity monthly data for internal reporting
// Purpose: Aggregate per-entity monthly data from monthly_transactions for internal reporting
export const internalReport = pgTable("internal_report", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  
  // Entity Link (via TIN -  نمبر تشخیصیه)
  entityTin: text("entity_tin").notNull(), // EntityTIN:  نمبر تشخیصیه - links to entities.tin
  entityName: text("entity_name").notNull(), // EntityName: نام نهاد - from entities.company_name
  
  // Time Period (Shamsi Calendar)
  monthShamsi: integer("month_shamsi").notNull(), // Month: برج (1-12)
  yearShamsi: integer("year_shamsi").notNull(), // Year: سال (Shamsi year, e.g., 1404)
  
  // Calculated Tax Amounts
  totalTaxableAmount: numeric("total_taxable_amount", { precision: 15, scale: 2 }).default("0"), // TotalTaxableAmount: Sum of all tax types
  // Calculated as: TaxSalary + TaxRent + TaxContract + TaxProfit + IncomeTax
  
  // Financial Amounts
  collectedAmount: numeric("collected_amount", { precision: 15, scale: 2 }).default("0"), // CollectedAmount: مبلغ تحصیل شده
  remainingAmount: numeric("remaining_amount", { precision: 15, scale: 2 }).default("0"), // RemainingAmount: Calculated as TotalTaxableAmount - CollectedAmount
  stabilizedAmount: numeric("stabilized_amount", { precision: 15, scale: 2 }).default("0"), // StabilizedAmount: مبلغ تثبیت شده
  
  // Additional Fields from MonthlyTransactions
  taxSalary: numeric("tax_salary", { precision: 15, scale: 2 }).default("0"), // مالیه موضوعی معاشات
  taxRent: numeric("tax_rent", { precision: 15, scale: 2 }).default("0"), // مالیه موضوعی بر کرایه
  taxContract: numeric("tax_contract", { precision: 15, scale: 2 }).default("0"), // مالیه موضوعی قراردادی
  taxProfit: numeric("tax_profit", { precision: 15, scale: 2 }).default("0"), // مالیه موضوعی معاملات انتفاعی
  incomeTax: numeric("income_tax", { precision: 15, scale: 2 }).default("0"), // مالیات بر عایدات
  lossReduction: numeric("loss_reduction", { precision: 15, scale: 2 }).default("0"), // ضرر کاهش یافته
  
  // Correspondence & Inquiry Data
  correspondencesIn: integer("correspondences_in").default(0), // تعداد مکتوب های وارده
  correspondencesOut: integer("correspondences_out").default(0), // تعداد مکتوب های صادره
  inquiriesIn: integer("inquiries_in").default(0), // تعداد استعلام های وارده
  inquiriesOut: integer("inquiries_out").default(0), // تعداد استعلام های صادره
  
  // Status
  status: text("status").notNull().default("active"), // Status: 'active' or 'inactive'
  
  // Notes
  notes: text("notes"), // Notes: ملاحظات
  
  // Metadata
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Ministry Summary - Aggregated per-group monthly summaries for ministry reporting
// Purpose: Aggregate per-group monthly summaries from internal_report for ministry reporting
export const ministrySummary = pgTable("ministry_summary", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  
  // Group Link (گروه ارجاع‌دهنده)
  groupId: varchar("group_id"), // Group ID - links to groups.id (can be NULL for static groups)
  groupName: text("group_name").notNull(), // Group Name: نام گروه - from groups.name or static group name
  groupCode: text("group_code"), // Group Code: کد گروه - from groups.code (if exists)
  
  // Time Period (Shamsi Calendar)
  monthShamsi: integer("month_shamsi").notNull(), // Month: برج (1-12)
  yearShamsi: integer("year_shamsi").notNull(), // Year: سال (Shamsi year, e.g., 1404)
  
  // Entity Counts
  totalEntities: integer("total_entities").default(0), // TotalEntities: Count of entities in the group
  finalizedEntities: integer("finalized_entities").default(0), // FinalizedEntities: Entities with RemainingAmount = 0
  partiallyCompliantEntities: integer("partially_compliant_entities").default(0), // PartiallyCompliantEntities: Entities with 0 < RemainingAmount < TotalTaxableAmount
  nonCompliantEntities: integer("non_compliant_entities").default(0), // NonCompliantEntities: Entities with RemainingAmount = TotalTaxableAmount
  
  // Revenue Data
  revenueCollected: numeric("revenue_collected", { precision: 15, scale: 2 }).default("0"), // RevenueCollected: Sum of CollectedAmount
  monthlyRevenueTarget: numeric("monthly_revenue_target", { precision: 15, scale: 2 }), // MonthlyRevenueTarget: Target revenue for the month (from group_targets)
  percentVariation: numeric("percent_variation", { precision: 5, scale: 2 }), // PercentVariation: (RevenueCollected / MonthlyRevenueTarget) * 100
  
  // Correspondence & Inquiry Data
  incomingLetters: integer("incoming_letters").default(0), // IncomingLetters: Sum of CorrespondencesIn
  outgoingLetters: integer("outgoing_letters").default(0), // OutgoingLetters: Sum of CorrespondencesOut
  incomingInquiries: integer("incoming_inquiries").default(0), // IncomingInquiries: Sum of InquiriesIn
  outgoingInquiries: integer("outgoing_inquiries").default(0), // OutgoingInquiries: Sum of InquiriesOut
  
  // Status
  status: text("status").notNull().default("active"), // Status: 'active' or 'inactive'
  
  // Notes
  notes: text("notes"), // Notes: ملاحظات
  
  // Metadata
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Workflow Alerts - Temporary table for storing underperformance alerts
// Flags entities and groups that need attention based on performance thresholds
export const workflowAlerts = pgTable("workflow_alerts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  
  // Alert Target (either EntityTIN or GroupName)
  entityTin: text("entity_tin"), // EntityTIN:  نمبر تشخیصیه (NULL if group alert)
  groupName: text("group_name"), // GroupName: نام گروه (NULL if entity alert)
  
  // Alert Type
  alertType: text("alert_type").notNull(), // AlertType: 'entity_remaining_amount', 'group_revenue_target', etc.
  
  // Alert Message
  message: text("message").notNull(), // Message: Human-readable alert message
  
  // Time Period
  monthShamsi: integer("month_shamsi").notNull(), // Month: برج (1-12)
  yearShamsi: integer("year_shamsi").notNull(), // Year: سال (Shamsi year, e.g., 1404)
  
  // Alert Severity
  severity: text("severity").notNull().default("medium"), // 'low', 'medium', 'high', 'critical'
  
  // Alert Status
  status: text("status").notNull().default("active"), // 'active', 'acknowledged', 'resolved', 'dismissed'
  
  // Alert Details (JSONB for flexible data storage)
  details: jsonb("details"), // Additional alert details (threshold, actual value, target value, etc.)
  
  // Metadata
  acknowledgedBy: varchar("acknowledged_by").references(() => users.id, { onDelete: "set null" }),
  acknowledgedAt: timestamp("acknowledged_at"),
  resolvedAt: timestamp("resolved_at"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Workflow Configuration - Stores configuration for automated workflow processing
export const workflowConfig = pgTable("workflow_config", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  
  // Configuration Name
  configName: text("config_name").notNull().unique(), // Name of the configuration
  
  // Target Month/Year
  monthShamsi: integer("month_shamsi").notNull(), // Month: برج (1-12)
  yearShamsi: integer("year_shamsi").notNull(), // Year: سال (Shamsi year, e.g., 1404)
  
  // Automation Settings
  autoRun: boolean("auto_run").default(false), // Whether to automatically run this workflow
  runOnDay: integer("run_on_day"), // Day of month to run (for scheduling)
  lastRunAt: timestamp("last_run_at"), // Last time this workflow was run
  nextRunAt: timestamp("next_run_at"), // Next scheduled run time
  
  // Processing Options
  appendMode: boolean("append_mode").default(true), // Append new transactions (true) or overwrite (false)
  regenerateReports: boolean("regenerate_reports").default(true), // Automatically regenerate InternalReport
  regenerateSummaries: boolean("regenerate_summaries").default(true), // Automatically regenerate MinistrySummary
  generateAlerts: boolean("generate_alerts").default(true), // Automatically generate alerts
  
  // Status
  status: text("status").notNull().default("pending"), // 'pending', 'running', 'completed', 'failed'
  lastStatusMessage: text("last_status_message"), // Last status message or error
  
  // Metadata
  createdBy: varchar("created_by").references(() => users.id, { onDelete: "set null" }),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Audit Records - Track audits linked to entities with year ranges
// Supports multiple non-overlapping audit records per entity
export const auditRecords = pgTable("audit_records", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  entityId: varchar("entity_id").notNull().references(() => entities.id, { onDelete: "cascade" }),
  auditYears: text("audit_years").notNull(), // سال‌های بررسی - Supports single year or ranges (e.g., "1392–1400")
  referringGroup: varchar("referring_group"), // گروه ارجاع‌دهنده
  referralDate: timestamp("referral_date"), // تاریخ ارجاع به بررسی
  // Internal year fields for querying/validation (derived from auditYears)
  yearFrom: integer("year_from"), // Start year in Shamsi calendar (e.g., 1400) - parsed from auditYears
  yearTo: integer("year_to"), // End year in Shamsi calendar (e.g., 1402) - parsed from auditYears
  assignedGroup: varchar("assigned_group").references(() => groups.id, { onDelete: "set null" }), // گروه اختصاص داده شده (the group performing the audit)
  assignedAt: timestamp("assigned_at"),
  createdByUserId: varchar("created_by_user_id").references(() => users.id, { onDelete: "set null" }),
  status: text("status").notNull().default("in-progress"), // 'in-progress', 'completed', 'archived'
  notes: text("notes"),
  responsibleEvaluator: varchar("responsible_evaluator").references(() => users.id, { onDelete: "set null" }),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
  completedAt: timestamp("completed_at"),
});

// Audit Record History - Track all changes to audit records for versioning
export const auditRecordHistory = pgTable("audit_record_history", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  auditRecordId: varchar("audit_record_id").notNull().references(() => auditRecords.id, { onDelete: "cascade" }),
  version: integer("version").notNull().default(1),
  changedBy: varchar("changed_by").notNull().references(() => users.id, { onDelete: "set null" }),
  changedAt: timestamp("changed_at").notNull().defaultNow(),
  changeType: text("change_type").notNull(), // 'create', 'update', 'status_change', 'assignment_change'
  fieldName: text("field_name"), // Name of the field that changed (if applicable)
  oldValue: jsonb("old_value"), // Previous value
  newValue: jsonb("new_value"), // New value
  changes: jsonb("changes"), // Full change details
  snapshot: jsonb("snapshot"), // Full snapshot of audit record at this version
  notes: text("notes"),
});

// Committees - Periodic audit committees for batch entity intake
// Uses Afghan months: حمل، ثور، جوزا، سرطان، اسد، سنبله، میزان، عقرب، قوس، جدی، دلو، حوت
export const committees = pgTable("committees", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(), // Committee Name
  month: text("month").notNull(), // Afghan month name (حمل، ثور، جوزا، ...)
  year: integer("year").notNull(), // Year (Shamsi, e.g., 1404)
  period: text("period").notNull(), // Period (Month/Year) - legacy field, kept for compatibility
  startDate: timestamp("start_date").notNull(), // Start Date
  endDate: timestamp("end_date").notNull(), // End Date
  notes: text("notes"), // Optional notes
  status: text("status").notNull().default("Active"), // Active / Closed
  locked: boolean("locked").default(false), // Locked after approval - no new cases can be added
  createdBy: varchar("created_by").notNull().references(() => users.id, { onDelete: "set null" }),
  createdAt: timestamp("created_at").defaultNow(),
});

// Monthly Group Reports - Aggregated monthly KPIs per group
export const monthlyGroupReports = pgTable("monthly_group_reports", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  groupId: varchar("group_id").notNull().references(() => groups.id, { onDelete: "cascade" }),
  monthNumber: integer("month_number").notNull(), // Afghan month number (1-12)
  yearNumber: integer("year_number").notNull(), // Shamsi year
  monthStartDate: timestamp("month_start_date", { mode: "date" }).notNull(),
  monthEndDate: timestamp("month_end_date", { mode: "date" }).notNull(),
  
  // Count fields
  distributedCount: integer("distributed_count").notNull().default(0),
  finalizedCount: integer("finalized_count").notNull().default(0),
  underReviewCount: integer("under_review_count").notNull().default(0),
  
  // Financial fields
  collectedAmount: numeric("collected_amount", { precision: 15, scale: 2 }).notNull().default("0"),
  
  // Additional metrics
  installmentsCount: integer("installments_count").notNull().default(0),
  nonresponsiveCount: integer("nonresponsive_count").notNull().default(0),
  
  // Target achievement
  percentOfTarget: numeric("percent_of_target", { precision: 5, scale: 2 }),
  
  // Manual overrides
  manualOverrides: jsonb("manual_overrides"),
  
  // Metadata
  computedBy: varchar("computed_by").references(() => users.id, { onDelete: "set null" }),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// Monthly Report Anomalies - Track data quality issues
export const monthlyReportAnomalies = pgTable("monthly_report_anomalies", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  reportId: varchar("report_id").notNull().references(() => monthlyGroupReports.id, { onDelete: "cascade" }),
  anomalyType: varchar("anomaly_type").notNull(), // 'negative_under_review', 'missing_target', 'high_percentage', 'data_inconsistency'
  severity: varchar("severity").notNull().default("warning"), // 'info', 'warning', 'error'
  description: text("description").notNull(),
  details: jsonb("details"),
  resolved: boolean("resolved").notNull().default(false),
  resolvedBy: varchar("resolved_by").references(() => users.id, { onDelete: "set null" }),
  resolvedAt: timestamp("resolved_at"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Committee Entities - Junction table linking committees to entities (OLD - deprecated)
export const committeeEntities = pgTable("committee_entities", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  committeeId: varchar("committee_id").notNull().references(() => committees.id, { onDelete: "cascade" }),
  entityId: varchar("entity_id").notNull().references(() => entities.id, { onDelete: "cascade" }),
  createdAt: timestamp("created_at").defaultNow(),
});

// ============================================================================
// NEW COMMITTEE MODULE - Clean Data Model
// ============================================================================
// Note: Old committees table is archived as committees_old by migration
// This is the new authoritative implementation
// The table name in database is "committees" (old one renamed to committees_old)

// New Committees Table - Monthly committees with approval workflow
// Forward declaration to avoid circular reference
export const committeesNew = pgTable("committees", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),                    // e.g. "کمیته حمل ۱۴۰۵"
  year: integer("year").notNull(),                   // e.g. 1405 (Shamsi)
  month: integer("month").notNull(),                 // 1-12 (Shamsi month number)
  status: text("status").notNull().default("DRAFT"), // DRAFT, APPROVED, CLOSED
  createdBy: varchar("created_by").notNull().references(() => users.id, { onDelete: "set null" }),
  createdAt: timestamp("created_at").defaultNow(),
  approvedBy: varchar("approved_by").references(() => users.id, { onDelete: "set null" }),
  approvedAt: timestamp("approved_at"),
});

// Committee Case Assignments - Immutable assignment records
// Tracks ALL case assignments with full history and traceability
export const committeeCaseAssignments = pgTable("committee_case_assignments", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  committeeId: varchar("committee_id").references(() => committeesNew.id, { onDelete: "set null" }),
  caseId: varchar("case_id").notNull().references(() => cases.id, { onDelete: "cascade" }),
  auditGroupId: varchar("audit_group_id").notNull().references(() => groups.id, { onDelete: "restrict" }),
  assignmentType: text("assignment_type").notNull(), // COMMITTEE, DIRECT, REASSIGNMENT
  previousAssignmentId: varchar("previous_assignment_id"), // Self-reference - FK constraint added in migration
  reason: text("reason"),                             // REQUIRED when assignment_type = DIRECT or REASSIGNMENT
  assignedBy: varchar("assigned_by").notNull().references(() => users.id, { onDelete: "set null" }),
  assignedAt: timestamp("assigned_at").notNull().defaultNow(),
});

// Legacy Excel Archives Tables
export const archivedFiles = pgTable("archived_files", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  fileName: text("file_name").notNull(),
  originalFileName: text("original_file_name").notNull(),
  year: integer("year").notNull(),
  category: text("category").notNull(),
  description: text("description"),
  path: text("path").notNull(),
  sizeBytes: integer("size_bytes").notNull(),
  uploadedBy: varchar("uploaded_by").references(() => users.id, { onDelete: "set null" }),
  uploadedAt: timestamp("uploaded_at").notNull().defaultNow(),
  isReadonly: boolean("is_readonly").notNull().default(true),
  currentVersion: integer("current_version").notNull().default(1),
  deletedAt: timestamp("deleted_at"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const archivedFileVersions = pgTable("archived_file_versions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  archivedFileId: varchar("archived_file_id").notNull().references(() => archivedFiles.id, { onDelete: "cascade" }),
  versionNumber: integer("version_number").notNull(),
  fileName: text("file_name").notNull(),
  path: text("path").notNull(),
  sizeBytes: integer("size_bytes").notNull(),
  uploadedBy: varchar("uploaded_by").references(() => users.id, { onDelete: "set null" }),
  uploadedAt: timestamp("uploaded_at").notNull().defaultNow(),
  notes: text("notes"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const archivedFileAccessLogs = pgTable("archived_file_access_logs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  archivedFileId: varchar("archived_file_id").notNull().references(() => archivedFiles.id, { onDelete: "cascade" }),
  userId: varchar("user_id").references(() => users.id, { onDelete: "set null" }),
  action: text("action").notNull(), // 'DOWNLOAD', 'UPLOAD', 'VIEW_METADATA'
  ipAddress: text("ip_address"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).omit({ id: true, createdAt: true });
export const insertGroupSchema = createInsertSchema(groups).omit({ id: true, createdAt: true });
export const insertGroupMemberSchema = createInsertSchema(groupMembers).omit({ id: true, joinedAt: true });
export const insertGroupTargetSchema = createInsertSchema(groupTargets).omit({ id: true, setAt: true });
export const insertEntitySchema = createInsertSchema(entities).omit({ id: true, createdAt: true });
export const insertCaseSchema = createInsertSchema(cases).omit({ id: true, createdAt: true });
export const insertTicketSchema = createInsertSchema(tickets).omit({ id: true, createdAt: true });
export const insertNotificationSchema = createInsertSchema(notifications).omit({ id: true, createdAt: true });
export const insertAuditLogSchema = createInsertSchema(auditLogs).omit({ id: true, createdAt: true });
export const insertDocumentSchema = createInsertSchema(documents).omit({ id: true, uploadedAt: true });
export const insertSystemSettingSchema = createInsertSchema(systemSettings).omit({ id: true, updatedAt: true });
export const insertEntityTypeSchema = createInsertSchema(entityTypes).omit({ id: true, createdAt: true, updatedAt: true });
export const insertCaseReportSchema = createInsertSchema(caseReports).omit({ id: true, createdAt: true, updatedAt: true });
export const insertCaseReportV2Schema = createInsertSchema(caseReportsV2).omit({ 
  id: true, 
  createdAt: true, 
  updatedAt: true,
  version: true, // Version is auto-incremented
});
export const insertCaseReportHistorySchema = createInsertSchema(caseReportHistory).omit({ id: true, changedAt: true });
export const insertMinistryReportSchema = createInsertSchema(ministryReports).omit({ id: true, createdAt: true, lastUpdatedAt: true });
export const insertMonthlyTransactionSchema = createInsertSchema(monthlyTransactions).omit({ id: true, createdAt: true, updatedAt: true });
export const insertInternalReportSchema = createInsertSchema(internalReport).omit({ id: true, createdAt: true, updatedAt: true });
export const insertMinistrySummarySchema = createInsertSchema(ministrySummary).omit({ id: true, createdAt: true, updatedAt: true });
export const insertWorkflowAlertSchema = createInsertSchema(workflowAlerts).omit({ id: true, createdAt: true, updatedAt: true });
export const insertWorkflowConfigSchema = createInsertSchema(workflowConfig).omit({ id: true, createdAt: true, updatedAt: true });
export const insertAuditRecordSchema = createInsertSchema(auditRecords).omit({ id: true, createdAt: true, updatedAt: true });
export const insertAuditRecordHistorySchema = createInsertSchema(auditRecordHistory).omit({ id: true, changedAt: true });
export const insertCommitteeSchema = createInsertSchema(committees).omit({ id: true, createdAt: true });
export const insertCommitteeEntitySchema = createInsertSchema(committeeEntities).omit({ id: true, createdAt: true });
export const insertArchivedFileSchema = createInsertSchema(archivedFiles).omit({ id: true, createdAt: true, uploadedAt: true });
export const insertArchivedFileVersionSchema = createInsertSchema(archivedFileVersions).omit({ id: true, createdAt: true, uploadedAt: true });
export const insertArchivedFileAccessLogSchema = createInsertSchema(archivedFileAccessLogs).omit({ id: true, createdAt: true });


export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertGroup = z.infer<typeof insertGroupSchema>;
export type Group = typeof groups.$inferSelect;
export type InsertGroupMember = z.infer<typeof insertGroupMemberSchema>;
export type GroupMember = typeof groupMembers.$inferSelect;
export type InsertGroupTarget = z.infer<typeof insertGroupTargetSchema>;
export type GroupTarget = typeof groupTargets.$inferSelect;
export type InsertEntity = z.infer<typeof insertEntitySchema>;
export type Entity = typeof entities.$inferSelect;
export type InsertCase = z.infer<typeof insertCaseSchema>;
export type Case = typeof cases.$inferSelect;
export type InsertTicket = z.infer<typeof insertTicketSchema>;
export type Ticket = typeof tickets.$inferSelect;
export type InsertNotification = z.infer<typeof insertNotificationSchema>;
export type Notification = typeof notifications.$inferSelect;
export type InsertAuditLog = z.infer<typeof insertAuditLogSchema>;
export type AuditLog = typeof auditLogs.$inferSelect;
export type InsertDocument = z.infer<typeof insertDocumentSchema>;
export type Document = typeof documents.$inferSelect;
export type InsertSystemSetting = z.infer<typeof insertSystemSettingSchema>;
export type SystemSetting = typeof systemSettings.$inferSelect;
export type InsertEntityType = z.infer<typeof insertEntityTypeSchema>;
export type EntityType = typeof entityTypes.$inferSelect;
export type InsertCaseReport = z.infer<typeof insertCaseReportSchema>;
export type CaseReport = typeof caseReports.$inferSelect;
export type InsertCaseReportV2 = z.infer<typeof insertCaseReportV2Schema>;
export type CaseReportV2 = typeof caseReportsV2.$inferSelect;
export type InsertCaseReportHistory = z.infer<typeof insertCaseReportHistorySchema>;
export type CaseReportHistory = typeof caseReportHistory.$inferSelect;
export type CaseStatusTransition = typeof caseStatusTransitions.$inferSelect;
export type InsertCaseStatusTransition = typeof caseStatusTransitions.$inferInsert;
export const insertCaseMetricsSchema = createInsertSchema(caseMetrics).omit({ id: true, createdAt: true, lastUpdatedAt: true });
export const insertInstallmentPaymentSchema = createInsertSchema(installmentPayments).omit({ id: true, createdAt: true });
export const insertPaymentSchema = createInsertSchema(payments).omit({ id: true, createdAt: true });
export const insertCaseMonthlySnapshotSchema = createInsertSchema(caseMonthlySnapshots).omit({ id: true, createdAt: true, updatedAt: true });
export const insertCaseFlagSchema = createInsertSchema(caseFlags).omit({ id: true, createdAt: true });
export const insertCaseSectionStatusSchema = createInsertSchema(caseSectionStatus).omit({ id: true, createdAt: true, updatedAt: true });
export type CaseMetrics = typeof caseMetrics.$inferSelect;
export type InsertCaseMetrics = z.infer<typeof insertCaseMetricsSchema>;
export type InstallmentPayment = typeof installmentPayments.$inferSelect;
export type InsertInstallmentPayment = z.infer<typeof insertInstallmentPaymentSchema>;
export type Payment = typeof payments.$inferSelect;
export type InsertPayment = z.infer<typeof insertPaymentSchema>;
export type CaseMonthlySnapshot = typeof caseMonthlySnapshots.$inferSelect;
export type InsertCaseMonthlySnapshot = z.infer<typeof insertCaseMonthlySnapshotSchema>;
export type CaseFlag = typeof caseFlags.$inferSelect;
export type InsertCaseFlag = z.infer<typeof insertCaseFlagSchema>;
export type CaseSectionStatus = typeof caseSectionStatus.$inferSelect;
export type InsertCaseSectionStatus = z.infer<typeof insertCaseSectionStatusSchema>;
export type MinistryReport = typeof ministryReports.$inferSelect;
export type InsertMinistryReport = z.infer<typeof insertMinistryReportSchema>;
export type MonthlyTransaction = typeof monthlyTransactions.$inferSelect;
export type InsertMonthlyTransaction = z.infer<typeof insertMonthlyTransactionSchema>;
export type InternalReport = typeof internalReport.$inferSelect;
export type InsertInternalReport = z.infer<typeof insertInternalReportSchema>;
export type MinistrySummary = typeof ministrySummary.$inferSelect;
export type InsertMinistrySummary = z.infer<typeof insertMinistrySummarySchema>;
export type WorkflowAlert = typeof workflowAlerts.$inferSelect;
export type InsertWorkflowAlert = z.infer<typeof insertWorkflowAlertSchema>;
export type WorkflowConfig = typeof workflowConfig.$inferSelect;
export type InsertWorkflowConfig = z.infer<typeof insertWorkflowConfigSchema>;
export type AuditRecord = typeof auditRecords.$inferSelect;
export type InsertAuditRecord = z.infer<typeof insertAuditRecordSchema>;
export type AuditRecordHistory = typeof auditRecordHistory.$inferSelect;
export type InsertAuditRecordHistory = z.infer<typeof insertAuditRecordHistorySchema>;
export type Committee = typeof committees.$inferSelect;
export type InsertCommittee = z.infer<typeof insertCommitteeSchema>;
export type CommitteeEntity = typeof committeeEntities.$inferSelect;
export type InsertCommitteeEntity = z.infer<typeof insertCommitteeEntitySchema>;

// New Committee Module Types
export const insertCommitteeNewSchema = createInsertSchema(committeesNew).omit({ id: true, createdAt: true });
export const insertCommitteeCaseAssignmentSchema = createInsertSchema(committeeCaseAssignments).omit({ id: true, assignedAt: true });
export type CommitteeNew = typeof committeesNew.$inferSelect;
export type InsertCommitteeNew = z.infer<typeof insertCommitteeNewSchema>;
export type CommitteeCaseAssignment = typeof committeeCaseAssignments.$inferSelect;
export type InsertCommitteeCaseAssignment = z.infer<typeof insertCommitteeCaseAssignmentSchema>;
export const insertMonthlyGroupReportSchema = createInsertSchema(monthlyGroupReports).omit({ id: true, createdAt: true, updatedAt: true });
export type MonthlyGroupReport = typeof monthlyGroupReports.$inferSelect;
export type InsertMonthlyGroupReport = z.infer<typeof insertMonthlyGroupReportSchema>;
export const insertMonthlyReportAnomalySchema = createInsertSchema(monthlyReportAnomalies).omit({ id: true, createdAt: true });
export type MonthlyReportAnomaly = typeof monthlyReportAnomalies.$inferSelect;
export type InsertMonthlyReportAnomaly = z.infer<typeof insertMonthlyReportAnomalySchema>;
export type ArchivedFile = typeof archivedFiles.$inferSelect;
export type InsertArchivedFile = z.infer<typeof insertArchivedFileSchema>;
export type ArchivedFileVersion = typeof archivedFileVersions.$inferSelect;
export type InsertArchivedFileVersion = z.infer<typeof insertArchivedFileVersionSchema>;
export type ArchivedFileAccessLog = typeof archivedFileAccessLogs.$inferSelect;
export type InsertArchivedFileAccessLog = z.infer<typeof insertArchivedFileAccessLogSchema>;
