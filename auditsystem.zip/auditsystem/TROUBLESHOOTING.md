# Troubleshooting Guide

## Common Errors and Solutions

### 1. PowerShell Execution Policy Error

**Error:**
```
File C:\Program Files\nodejs\npm.ps1 cannot be loaded because running scripts is disabled on this system.
```

**Solution:**
```powershell
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
```

### 2. TypeScript Compilation Errors

**If you see type errors related to `monthStartDate` or `monthEndDate`:**

The schema uses `timestamp` with `mode: "date"` which expects Date objects. The service now includes type assertions to handle this.

**If you see import errors:**

Make sure all files are saved and the TypeScript server has reloaded. Try:
- Restarting the TypeScript server in your IDE
- Running `npm install` to ensure dependencies are up to date

### 3. Database Migration Errors

**Error: Column already exists or table already exists**

The migration uses `DO $$ BEGIN ... END $$` blocks with `IF NOT EXISTS` checks, so it should be safe to run multiple times. If you still see errors:

```sql
-- Check if migration was already applied
SELECT column_name FROM information_schema.columns 
WHERE table_name = 'groups' AND column_name = 'monthly_tax_target';

SELECT table_name FROM information_schema.tables 
WHERE table_name = 'monthly_group_reports';
```

### 4. Missing Permission Errors

**Error: Permission 'reports:override' not found**

The permission is actually `reports:override_complete` (not `reports:override`). This has been fixed in the code.

### 5. Import/Export Errors

**If you see errors about missing exports:**

Check that all files are properly saved:
- `server/services/monthlyGroupReportService.ts`
- `server/routes/monthlyReports.ts`
- `shared/schema.ts`
- `client/src/components/reports/MonthlyGroupReportTab.tsx`

### 6. Runtime Errors

**Error: "Group not found" or "Report not found"**

- Ensure the group ID exists in the database
- Ensure the month/year are valid (month 1-12, year 1300-1500)
- Check that the migration has been run

**Error: "Cannot read property 'monthlyTaxTarget' of undefined"**

- Ensure the group exists before computing reports
- Check that the groups table has the `monthly_tax_target` column

## Quick Fixes

### Reset TypeScript Server
In VS Code: `Ctrl+Shift+P` → "TypeScript: Restart TS Server"

### Verify Database Schema
```sql
-- Check groups table
SELECT column_name, data_type 
FROM information_schema.columns 
WHERE table_name = 'groups' 
AND column_name LIKE '%monthly%';

-- Check monthly_group_reports table exists
SELECT table_name 
FROM information_schema.tables 
WHERE table_name = 'monthly_group_reports';
```

### Verify Imports
All required imports should be:
- ✅ `monthlyGroupReports` and `monthlyReportAnomalies` from `@shared/schema`
- ✅ `MonthlyGroupReport`, `InsertMonthlyGroupReport` types from `@shared/schema`
- ✅ `CaseStatus` from `@shared/schema`
- ✅ `storage` from `../storage`
- ✅ `db` from `../db`

## Still Having Issues?

Please provide:
1. The exact error message
2. Where it occurs (build time, runtime, which file)
3. The command you ran (if applicable)
4. Any relevant stack trace

