# Simple script to run migration 036
# Usage: .\run-migration-036.ps1
# 
# This script will try to use psql if available, otherwise it will suggest
# using the TypeScript migration script (recommended).

# Check if psql is available
$psqlPath = Get-Command psql -ErrorAction SilentlyContinue

if (-not $psqlPath) {
    Write-Host "⚠️  PostgreSQL client (psql) not found in PATH" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "💡 Recommended: Use TypeScript migration script instead:" -ForegroundColor Cyan
    Write-Host "   npm run db:migrate-case-lifecycle" -ForegroundColor Gray
    Write-Host ""
    Write-Host "   This method is more reliable and doesn't require psql in PATH." -ForegroundColor Gray
    Write-Host ""
    $useTypeScript = $true
} else {
    $useTypeScript = $false
}

if (-not $useTypeScript) {
    # Try to load DATABASE_URL from .env file if not set
    if (-not $env:DATABASE_URL) {
        if (Test-Path ".env") {
            Write-Host "Loading DATABASE_URL from .env file..." -ForegroundColor Gray
            Get-Content ".env" | ForEach-Object {
                if ($_ -match '^DATABASE_URL=(.+)') {
                    $env:DATABASE_URL = $matches[1].Trim()
                }
            }
        }
    }

    if (-not $env:DATABASE_URL) {
        Write-Host "ERROR: DATABASE_URL not set" -ForegroundColor Red
        Write-Host "Set it with: `$env:DATABASE_URL = 'postgresql://user:pass@host:port/dbname'" -ForegroundColor Yellow
        Write-Host "Or add it to your .env file" -ForegroundColor Yellow
        Write-Host ""
        Write-Host "💡 Alternative: Use TypeScript migration script:" -ForegroundColor Cyan
        Write-Host "   npm run db:migrate-case-lifecycle" -ForegroundColor Gray
        exit 1
    }

    $migrationFile = "migrations\036_case_lifecycle_redesign.sql"

    if (-not (Test-Path $migrationFile)) {
        Write-Host "ERROR: Migration file not found: $migrationFile" -ForegroundColor Red
        exit 1
    }

    Write-Host "Running migration 036 (Case Lifecycle Redesign)..." -ForegroundColor Cyan
    Write-Host ""

    # Set UTF-8 encoding for Persian text
    $env:PGCLIENTENCODING = "UTF8"

    # Run the migration
    psql $env:DATABASE_URL -f $migrationFile

    if ($LASTEXITCODE -eq 0) {
        Write-Host ""
        Write-Host "Migration completed successfully!" -ForegroundColor Green
    } else {
        Write-Host ""
        Write-Host "Migration failed. Check error messages above." -ForegroundColor Red
        Write-Host "Exit code: $LASTEXITCODE" -ForegroundColor Yellow
        Write-Host ""
        Write-Host "💡 Alternative: Use TypeScript migration script:" -ForegroundColor Cyan
        Write-Host "   npm run db:migrate-case-lifecycle" -ForegroundColor Gray
    }

    # Clear encoding
    Remove-Item Env:\PGCLIENTENCODING -ErrorAction SilentlyContinue
} else {
    # Use TypeScript migration script
    Write-Host "Running migration using TypeScript script..." -ForegroundColor Cyan
    Write-Host ""
    npm run db:migrate-case-lifecycle
}
