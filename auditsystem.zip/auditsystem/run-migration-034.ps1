# PowerShell script to run migration 034
# Adds numeric audit year columns and exclusion constraint

Write-Host "🚀 Running Migration 034: Add Audit Year Numeric Columns and Constraint" -ForegroundColor Cyan
Write-Host ""

# Check if DATABASE_URL is set
if (-not $env:DATABASE_URL) {
    Write-Host "❌ ERROR: DATABASE_URL environment variable is not set" -ForegroundColor Red
    Write-Host "Please set it using: `$env:DATABASE_URL = 'postgresql://user:pass@host:port/dbname'" -ForegroundColor Yellow
    exit 1
}

$migrationFile = "migrations\034_add_audit_year_numeric_columns_and_constraint.sql"

if (-not (Test-Path $migrationFile)) {
    Write-Host "❌ ERROR: Migration file not found: $migrationFile" -ForegroundColor Red
    exit 1
}

Write-Host "📁 Migration file: $migrationFile" -ForegroundColor Green
Write-Host "🔗 Database: $($env:DATABASE_URL -replace ':[^:@]+@', ':****@')" -ForegroundColor Gray
Write-Host ""

# Run migration using psql
Write-Host "⏳ Executing migration..." -ForegroundColor Yellow
Write-Host ""

try {
    # Use psql to run the migration
    $result = & psql $env:DATABASE_URL -f $migrationFile 2>&1
    
    if ($LASTEXITCODE -eq 0) {
        Write-Host ""
        Write-Host "✅ Migration completed successfully!" -ForegroundColor Green
        Write-Host ""
        Write-Host "📊 Summary:" -ForegroundColor Cyan
        Write-Host "  - Added audit_year_start and audit_year_end columns" -ForegroundColor Gray
        Write-Host "  - Migrated existing data from audit_year_range" -ForegroundColor Gray
        Write-Host "  - Created indexes on new columns" -ForegroundColor Gray
        Write-Host "  - Added exclusion constraint (if btree_gist extension available)" -ForegroundColor Gray
        Write-Host ""
        Write-Host "ℹ️  Note: If you see warnings about btree_gist extension," -ForegroundColor Yellow
        Write-Host "   the constraint requires superuser privileges. Application-level" -ForegroundColor Yellow
        Write-Host "   validation will still prevent overlaps." -ForegroundColor Yellow
    } else {
        Write-Host ""
        Write-Host "❌ Migration failed with exit code: $LASTEXITCODE" -ForegroundColor Red
        Write-Host ""
        Write-Host "Error output:" -ForegroundColor Red
        Write-Host $result -ForegroundColor Red
        Write-Host ""
        Write-Host "💡 Common issues:" -ForegroundColor Yellow
        Write-Host "  1. btree_gist extension requires superuser privileges" -ForegroundColor Gray
        Write-Host "  2. Existing overlapping data prevents constraint creation" -ForegroundColor Gray
        Write-Host "  3. Database connection issues" -ForegroundColor Gray
        Write-Host ""
        Write-Host "The migration will still add the columns and migrate data," -ForegroundColor Yellow
        Write-Host "but the exclusion constraint may be skipped." -ForegroundColor Yellow
        exit $LASTEXITCODE
    }
} catch {
    Write-Host ""
    Write-Host "❌ ERROR: Failed to run migration" -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Red
    Write-Host ""
    Write-Host "💡 Make sure psql is installed and in your PATH" -ForegroundColor Yellow
    Write-Host "   Or use: npm run db:migrate-all" -ForegroundColor Yellow
    exit 1
}

