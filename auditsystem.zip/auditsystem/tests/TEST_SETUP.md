# Test Setup Instructions

## Test Framework Options

The test files can work with different test frameworks. Choose one:

### Option 1: Node.js Built-in Test Runner (Recommended)

The tests are written to work with Node.js built-in test runner (available in Node 18+):

```bash
# Run tests with tsx (which supports Node.js test runner)
npm test
```

### Option 2: Jest

If you prefer Jest, install it first:

```bash
npm install --save-dev jest @jest/globals @types/jest ts-jest
```

Then update test files to use Jest imports:
```typescript
import { describe, it, expect, beforeAll, afterAll } from '@jest/globals';
```

And update package.json:
```json
{
  "scripts": {
    "test": "jest",
    "test:watch": "jest --watch"
  },
  "jest": {
    "preset": "ts-jest",
    "testEnvironment": "node"
  }
}
```

### Option 3: Vitest

For Vitest:

```bash
npm install --save-dev vitest
```

Update test files:
```typescript
import { describe, it, expect, beforeAll, afterAll } from 'vitest';
```

Update package.json:
```json
{
  "scripts": {
    "test": "vitest",
    "test:watch": "vitest --watch"
  }
}
```

## Current Setup

The tests are currently configured to work with Node.js built-in test runner via `tsx --test`. This requires:

- Node.js 18+ (for built-in test runner)
- tsx (already in devDependencies)

## Environment Variables

Set these before running tests:

```bash
export TEST_DATABASE_URL="postgresql://user:password@localhost:5432/test_db"
export TEST_BASE_URL="http://localhost:3000"
```

## Running Tests

```bash
# All tests
npm test

# Specific test file
tsx --test tests/audit-records-overlap.test.ts

# With coverage (if using Jest/Vitest)
npm test -- --coverage
```

