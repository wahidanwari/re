# Audit Records Testing Guide

This document describes the test suite for the Master Entity with Linked AuditRecord feature.

## Test Files

### Unit Tests

1. **`audit-records-overlap.test.ts`** - Tests overlap detection logic
   - Tests non-overlapping ranges
   - Tests overlapping ranges (various scenarios)
   - Tests contained/containing ranges
   - Tests update exclusion logic
   - Tests validation (yearFrom <= yearTo)

### Integration Tests

2. **`audit-records-api.test.ts`** - Tests API endpoints
   - POST /api/audit-records/entities/:entityId/audits (create)
   - GET /api/audit-records/entities/:entityId/audits (list)
   - GET /api/audit-records/:id (detail)
   - PATCH /api/audit-records/:id (update)
   - POST /api/audit-records/:id/complete (complete)
   - Error handling and validation

### E2E Tests

3. **`e2e/audit-records-ui.test.ts`** - UI test scenarios
   - Manual test scenarios
   - Test checklists
   - Performance test scenarios

## Running Tests

### Prerequisites

1. Set up test database:
```bash
export TEST_DATABASE_URL="postgresql://user:password@localhost:5432/test_db"
export TEST_BASE_URL="http://localhost:3000"
```

2. Ensure test database has migrations applied:
```bash
psql $TEST_DATABASE_URL -f migrations/023_audit_records_year_ranges.sql
```

### Run All Tests

```bash
npm test
```

### Run Specific Test Suites

```bash
# Overlap detection tests only
npm run test:overlap

# API integration tests only
npm run test:api

# All audit records tests
npm run test:audit-records
```

### Run Individual Test Files

```bash
# Using tsx directly
tsx tests/audit-records-overlap.test.ts
tsx tests/audit-records-api.test.ts
```

## Test Coverage

### Overlap Detection Tests

- ✅ Non-overlapping ranges
- ✅ Overlapping ranges (partial)
- ✅ Contained ranges
- ✅ Containing ranges
- ✅ Adjacent ranges (non-overlapping)
- ✅ Single year ranges
- ✅ Update exclusion logic
- ✅ Validation errors

### API Tests

- ✅ Create audit record (success)
- ✅ Create audit record (overlap rejection)
- ✅ Create audit record (validation errors)
- ✅ List audit records (pagination)
- ✅ List audit records (filtering)
- ✅ Get audit record detail
- ✅ Update audit record
- ✅ Update completed record (restrictions)
- ✅ Complete audit record
- ✅ Error handling

### E2E Test Scenarios

- ✅ Create audit record flow
- ✅ Overlap detection in UI
- ✅ View audit record detail
- ✅ Edit audit record
- ✅ Complete audit record
- ✅ Gap detection visualization
- ✅ Conflict resolution
- ✅ Pagination
- ✅ Status filtering

## Manual Testing Checklist

For comprehensive QA, use the manual test checklist in `e2e/audit-records-ui.test.ts`:

1. **Create Audit Record**
   - [ ] Can create with valid year range
   - [ ] Overlap detection works in real-time
   - [ ] Error messages are clear
   - [ ] Form validation prevents invalid inputs

2. **View Audit Records**
   - [ ] Timeline displays all records
   - [ ] Year ranges formatted correctly
   - [ ] Status badges show correct colors
   - [ ] Gap detection warnings appear

3. **Edit Audit Record**
   - [ ] Can edit planned/in_progress records
   - [ ] Cannot edit completed records (except notes)
   - [ ] Overlap detection works on update
   - [ ] Changes saved correctly

4. **Complete Audit Record**
   - [ ] Complete button visible for authorized users
   - [ ] Completion sets status and timestamp
   - [ ] Record becomes read-only after completion

5. **Error Handling**
   - [ ] Network errors handled gracefully
   - [ ] Validation errors shown clearly
   - [ ] Overlap conflicts detailed
   - [ ] 404 errors for non-existent records

## Performance Testing

Test scenarios for performance:

1. **Load Timeline with Many Records**
   - Create 100+ audit records
   - Measure page load time (target: < 2 seconds)

2. **Overlap Check Performance**
   - Create entity with 50 audit records
   - Check overlap for new range (target: < 500ms)

3. **Bulk Operations**
   - Create 10 audit records in sequence
   - Measure total time

## Troubleshooting

### Tests Fail with Database Connection Error

Ensure `TEST_DATABASE_URL` is set correctly:
```bash
export TEST_DATABASE_URL="postgresql://user:password@localhost:5432/test_db"
```

### Tests Fail with Server Connection Error

Ensure server is running and `TEST_BASE_URL` is correct:
```bash
export TEST_BASE_URL="http://localhost:3000"
npm run dev
```

### Tests Leave Test Data

Tests should clean up after themselves, but if data remains:
```bash
# Clean up test entities (adjust TIN pattern as needed)
psql $TEST_DATABASE_URL -c "DELETE FROM entities WHERE tin LIKE 'TEST-%';"
psql $TEST_DATABASE_URL -c "DELETE FROM audit_records WHERE entity_id IN (SELECT id FROM entities WHERE tin LIKE 'TEST-%');"
```

## Continuous Integration

For CI/CD pipelines, ensure:

1. Test database is set up
2. Migrations are applied
3. Server is started before API tests
4. Tests run in isolated environment
5. Cleanup happens after tests

Example CI configuration:
```yaml
- name: Setup test database
  run: |
    psql $TEST_DATABASE_URL -f migrations/023_audit_records_year_ranges.sql

- name: Run tests
  run: |
    npm run test:audit-records
  env:
    TEST_DATABASE_URL: ${{ secrets.TEST_DATABASE_URL }}
    TEST_BASE_URL: http://localhost:3000
```

## Contributing

When adding new tests:

1. Follow existing test patterns
2. Clean up test data in `afterAll`
3. Use descriptive test names
4. Add comments for complex scenarios
5. Update this README with new test scenarios

