/**
 * Integration Tests for Audit Records API Endpoints
 * 
 * Tests the API endpoints for creating, updating, and managing audit records
 * 
 * Usage:
 *   npm test -- audit-records-api.test.ts
 *   or: tsx tests/audit-records-api.test.ts
 */

import { describe, it, expect, beforeAll, afterAll } from '@jest/globals';
import fetch from 'node-fetch';
import { Pool } from 'pg';
import { db } from '../server/db';
import { entities, auditRecords, users, groups } from '@shared/schema';
import { eq } from 'drizzle-orm';

const BASE_URL = process.env.TEST_BASE_URL || 'http://localhost:3000';

interface TestContext {
  testEntityId: string;
  testUserId: string;
  testGroupId: string;
  sessionCookie: string;
  auditRecordIds: string[];
}

// Note: These tests require a running server and test database
// Set TEST_DATABASE_URL and TEST_BASE_URL environment variables

async function getSessionCookie(auditId: string, password: string): Promise<string> {
  const response = await fetch(`${BASE_URL}/api/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ auditId, password }),
  });

  if (!response.ok) {
    throw new Error(`Login failed: ${response.statusText}`);
  }

  const cookies = response.headers.get('set-cookie');
  if (!cookies) {
    throw new Error('No session cookie received');
  }

  const sessionCookie = cookies.split(';')[0];
  return sessionCookie;
}

async function setupTestContext(): Promise<TestContext> {
  if (!process.env.TEST_DATABASE_URL) {
    throw new Error('TEST_DATABASE_URL not set');
  }

  // Create test entity
  const [entity] = await db.insert(entities).values({
    companyName: 'Test Company API',
    tin: 'TEST-TIN-API-' + Date.now(),
    businessNature: 'تجارتی',
    status: 'NEW',
  }).returning();

  // Create test user (assuming admin user exists)
  // In real scenario, you'd create a test user
  const sessionCookie = await getSessionCookie('admin', 'admin123');

  // Get or create test group
  const [group] = await db.select().from(groups).limit(1);
  const testGroupId = group?.id || '';

  return {
    testEntityId: entity.id,
    testUserId: '', // Will be extracted from session if needed
    testGroupId,
    sessionCookie,
    auditRecordIds: [],
  };
}

async function cleanupTestContext(context: TestContext) {
  // Clean up audit records
  if (context.auditRecordIds.length > 0) {
    await db.delete(auditRecords).where(
      eq(auditRecords.entityId, context.testEntityId)
    );
  }

  // Clean up entity
  await db.delete(entities).where(eq(entities.id, context.testEntityId));
}

describe('Audit Records API', () => {
  let context: TestContext;

  beforeAll(async () => {
    if (!process.env.TEST_DATABASE_URL || !process.env.TEST_BASE_URL) {
      console.warn('TEST_DATABASE_URL or TEST_BASE_URL not set, skipping API tests');
      return;
    }

    try {
      context = await setupTestContext();
    } catch (error) {
      console.error('Failed to setup test context:', error);
      throw error;
    }
  });

  afterAll(async () => {
    if (context) {
      await cleanupTestContext(context);
    }
  });

  describe('POST /api/audit-records/entities/:entityId/audits', () => {
    it('should create a new audit record with valid year range', async () => {
      if (!process.env.TEST_DATABASE_URL) return;

      const response = await fetch(
        `${BASE_URL}/api/audit-records/entities/${context.testEntityId}/audits`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Cookie: context.sessionCookie,
          },
          body: JSON.stringify({
            yearFrom: 1400,
            yearTo: 1402,
            auditGroupId: context.testGroupId || null,
            notes: 'Test audit record',
          }),
        }
      );

      expect(response.status).toBe(201);
      const data = await response.json();
      expect(data.yearFrom).toBe(1400);
      expect(data.yearTo).toBe(1402);
      expect(data.status).toBe('planned');
      
      context.auditRecordIds.push(data.id);
    });

    it('should reject overlapping year ranges', async () => {
      if (!process.env.TEST_DATABASE_URL) return;

      const response = await fetch(
        `${BASE_URL}/api/audit-records/entities/${context.testEntityId}/audits`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Cookie: context.sessionCookie,
          },
          body: JSON.stringify({
            yearFrom: 1401,
            yearTo: 1403, // Overlaps with 1400-1402
            notes: 'Overlapping audit record',
          }),
        }
      );

      expect(response.status).toBe(409);
      const data = await response.json();
      expect(data.message).toContain('تداخل');
      expect(data.conflicts).toBeDefined();
      expect(Array.isArray(data.conflicts)).toBe(true);
    });

    it('should reject invalid year range (yearFrom > yearTo)', async () => {
      if (!process.env.TEST_DATABASE_URL) return;

      const response = await fetch(
        `${BASE_URL}/api/audit-records/entities/${context.testEntityId}/audits`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Cookie: context.sessionCookie,
          },
          body: JSON.stringify({
            yearFrom: 1405,
            yearTo: 1403, // Invalid: from > to
            notes: 'Invalid range',
          }),
        }
      );

      expect(response.status).toBe(400);
      const data = await response.json();
      expect(data.message).toContain('سال شروع');
    });

    it('should reject non-numeric years', async () => {
      if (!process.env.TEST_DATABASE_URL) return;

      const response = await fetch(
        `${BASE_URL}/api/audit-records/entities/${context.testEntityId}/audits`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Cookie: context.sessionCookie,
          },
          body: JSON.stringify({
            yearFrom: 'invalid',
            yearTo: 1405,
            notes: 'Invalid years',
          }),
        }
      );

      expect(response.status).toBe(400);
    });

    it('should require yearFrom and yearTo', async () => {
      if (!process.env.TEST_DATABASE_URL) return;

      const response = await fetch(
        `${BASE_URL}/api/audit-records/entities/${context.testEntityId}/audits`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Cookie: context.sessionCookie,
          },
          body: JSON.stringify({
            notes: 'Missing years',
          }),
        }
      );

      expect(response.status).toBe(400);
    });
  });

  describe('GET /api/audit-records/entities/:entityId/audits', () => {
    it('should retrieve audit records for an entity', async () => {
      if (!process.env.TEST_DATABASE_URL) return;

      const response = await fetch(
        `${BASE_URL}/api/audit-records/entities/${context.testEntityId}/audits`,
        {
          headers: {
            Cookie: context.sessionCookie,
          },
        }
      );

      expect(response.status).toBe(200);
      const data = await response.json();
      expect(data.records).toBeDefined();
      expect(Array.isArray(data.records)).toBe(true);
      expect(data.pagination).toBeDefined();
    });

    it('should support pagination', async () => {
      if (!process.env.TEST_DATABASE_URL) return;

      const response = await fetch(
        `${BASE_URL}/api/audit-records/entities/${context.testEntityId}/audits?page=1&limit=10`,
        {
          headers: {
            Cookie: context.sessionCookie,
          },
        }
      );

      expect(response.status).toBe(200);
      const data = await response.json();
      expect(data.pagination.page).toBe(1);
      expect(data.pagination.limit).toBe(10);
    });

    it('should filter by status', async () => {
      if (!process.env.TEST_DATABASE_URL) return;

      const response = await fetch(
        `${BASE_URL}/api/audit-records/entities/${context.testEntityId}/audits?status=planned`,
        {
          headers: {
            Cookie: context.sessionCookie,
          },
        }
      );

      expect(response.status).toBe(200);
      const data = await response.json();
      if (data.records.length > 0) {
        expect(data.records[0].status).toBe('planned');
      }
    });
  });

  describe('GET /api/audit-records/:id', () => {
    it('should retrieve a specific audit record', async () => {
      if (!process.env.TEST_DATABASE_URL || context.auditRecordIds.length === 0) return;

      const recordId = context.auditRecordIds[0];
      const response = await fetch(
        `${BASE_URL}/api/audit-records/${recordId}`,
        {
          headers: {
            Cookie: context.sessionCookie,
          },
        }
      );

      expect(response.status).toBe(200);
      const data = await response.json();
      expect(data.id).toBe(recordId);
      expect(data.entityId).toBe(context.testEntityId);
      expect(data.yearFrom).toBeDefined();
      expect(data.yearTo).toBeDefined();
    });

    it('should return 404 for non-existent record', async () => {
      if (!process.env.TEST_DATABASE_URL) return;

      const response = await fetch(
        `${BASE_URL}/api/audit-records/non-existent-id`,
        {
          headers: {
            Cookie: context.sessionCookie,
          },
        }
      );

      expect(response.status).toBe(404);
    });
  });

  describe('PATCH /api/audit-records/:id', () => {
    it('should update audit record fields', async () => {
      if (!process.env.TEST_DATABASE_URL || context.auditRecordIds.length === 0) return;

      const recordId = context.auditRecordIds[0];
      const response = await fetch(
        `${BASE_URL}/api/audit-records/${recordId}`,
        {
          method: 'PATCH',
          headers: {
            'Content-Type': 'application/json',
            Cookie: context.sessionCookie,
          },
          body: JSON.stringify({
            notes: 'Updated notes',
            status: 'in_progress',
          }),
        }
      );

      expect(response.status).toBe(200);
      const data = await response.json();
      expect(data.notes).toBe('Updated notes');
      expect(data.status).toBe('in_progress');
    });

    it('should prevent updating completed audit records', async () => {
      if (!process.env.TEST_DATABASE_URL || context.auditRecordIds.length === 0) return;

      const recordId = context.auditRecordIds[0];
      
      // First, complete the record
      await fetch(
        `${BASE_URL}/api/audit-records/${recordId}/complete`,
        {
          method: 'POST',
          headers: {
            Cookie: context.sessionCookie,
          },
        }
      );

      // Try to update year range (should fail)
      const response = await fetch(
        `${BASE_URL}/api/audit-records/${recordId}`,
        {
          method: 'PATCH',
          headers: {
            'Content-Type': 'application/json',
            Cookie: context.sessionCookie,
          },
          body: JSON.stringify({
            yearFrom: 1410,
            yearTo: 1412,
          }),
        }
      );

      expect(response.status).toBe(400);
      const data = await response.json();
      expect(data.message).toContain('تکمیل شده');
    });

    it('should allow updating notes on completed records', async () => {
      if (!process.env.TEST_DATABASE_URL || context.auditRecordIds.length === 0) return;

      const recordId = context.auditRecordIds[0];
      
      const response = await fetch(
        `${BASE_URL}/api/audit-records/${recordId}`,
        {
          method: 'PATCH',
          headers: {
            'Content-Type': 'application/json',
            Cookie: context.sessionCookie,
          },
          body: JSON.stringify({
            notes: 'Updated notes on completed record',
          }),
        }
      );

      expect(response.status).toBe(200);
      const data = await response.json();
      expect(data.notes).toBe('Updated notes on completed record');
    });

    it('should reject overlapping year ranges on update', async () => {
      if (!process.env.TEST_DATABASE_URL || context.auditRecordIds.length === 0) return;

      // Create another non-overlapping record first
      const createResponse = await fetch(
        `${BASE_URL}/api/audit-records/entities/${context.testEntityId}/audits`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Cookie: context.sessionCookie,
          },
          body: JSON.stringify({
            yearFrom: 1410,
            yearTo: 1412,
            status: 'planned',
          }),
        }
      );

      const newRecord = await createResponse.json();
      context.auditRecordIds.push(newRecord.id);

      // Try to update first record to overlap with second
      const updateResponse = await fetch(
        `${BASE_URL}/api/audit-records/${context.auditRecordIds[0]}`,
        {
          method: 'PATCH',
          headers: {
            'Content-Type': 'application/json',
            Cookie: context.sessionCookie,
          },
          body: JSON.stringify({
            yearFrom: 1411,
            yearTo: 1413, // Overlaps with 1410-1412
          }),
        }
      );

      expect(updateResponse.status).toBe(409);
    });
  });

  describe('POST /api/audit-records/:id/complete', () => {
    it('should complete an audit record', async () => {
      if (!process.env.TEST_DATABASE_URL || context.auditRecordIds.length === 0) return;

      // Create a new record to complete
      const createResponse = await fetch(
        `${BASE_URL}/api/audit-records/entities/${context.testEntityId}/audits`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Cookie: context.sessionCookie,
          },
          body: JSON.stringify({
            yearFrom: 1420,
            yearTo: 1422,
            status: 'in_progress',
          }),
        }
      );

      const record = await createResponse.json();
      context.auditRecordIds.push(record.id);

      const response = await fetch(
        `${BASE_URL}/api/audit-records/${record.id}/complete`,
        {
          method: 'POST',
          headers: {
            Cookie: context.sessionCookie,
          },
        }
      );

      expect(response.status).toBe(200);
      const data = await response.json();
      expect(data.status).toBe('completed');
      expect(data.completedAt).toBeDefined();
    });

    it('should not allow completing an already completed record', async () => {
      if (!process.env.TEST_DATABASE_URL || context.auditRecordIds.length === 0) return;

      const recordId = context.auditRecordIds[context.auditRecordIds.length - 1];
      
      const response = await fetch(
        `${BASE_URL}/api/audit-records/${recordId}/complete`,
        {
          method: 'POST',
          headers: {
            Cookie: context.sessionCookie,
          },
        }
      );

      expect(response.status).toBe(400);
    });
  });

  describe('GET /api/audit-records', () => {
    it('should list all audit records with filters', async () => {
      if (!process.env.TEST_DATABASE_URL) return;

      const response = await fetch(
        `${BASE_URL}/api/audit-records?entityId=${context.testEntityId}`,
        {
          headers: {
            Cookie: context.sessionCookie,
          },
        }
      );

      expect(response.status).toBe(200);
      const data = await response.json();
      expect(Array.isArray(data)).toBe(true);
    });

    it('should filter by year range', async () => {
      if (!process.env.TEST_DATABASE_URL) return;

      const response = await fetch(
        `${BASE_URL}/api/audit-records?entityId=${context.testEntityId}&yearFrom=1400&yearTo=1405`,
        {
          headers: {
            Cookie: context.sessionCookie,
          },
        }
      );

      expect(response.status).toBe(200);
      const data = await response.json();
      expect(Array.isArray(data)).toBe(true);
    });
  });
});

