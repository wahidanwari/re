/**
 * Case Report Completion Test (Suggestion B - Unit Tests)
 * 
 * Tests that a report can be marked as completed when all required fields are filled
 * 
 * Usage:
 *   npm run test:completion (or tsx tests/case-report-completion.test.ts)
 */

import fetch from 'node-fetch';

const BASE_URL = process.env.TEST_BASE_URL || 'http://localhost:3000';

interface TestResult {
  name: string;
  passed: boolean;
  message: string;
}

const results: TestResult[] = [];

async function getSessionCookie(auditId: string, password: string): Promise<string> {
  const response = await fetch(`${BASE_URL}/api/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ auditId, password }),
  });

  if (!response.ok) {
    throw new Error(`Login failed: ${response.statusText}`);
  }

  const cookies = response.headers.get('set-cookie');
  if (!cookies) {
    throw new Error('No session cookie received');
  }

  // Extract session cookie
  const sessionCookie = cookies.split(';')[0];
  return sessionCookie;
}

async function testReportSchema() {
  try {
    const cookie = await getSessionCookie('admin', 'admin123');
    const response = await fetch(`${BASE_URL}/api/cases/schema/report/v2`, {
      headers: { Cookie: cookie },
    });

    if (!response.ok) {
      results.push({
        name: 'Schema Endpoint',
        passed: false,
        message: `Failed to fetch schema: ${response.statusText}`,
      });
      return;
    }

    const schema = await response.json();
    const hasRequiredSections = schema.sections && 
      schema.sections.section_1 && 
      schema.sections.section_2 && 
      schema.sections.section_5;

    results.push({
      name: 'Schema Endpoint',
      passed: hasRequiredSections,
      message: hasRequiredSections 
        ? 'Schema endpoint returns required sections'
        : 'Schema endpoint missing required sections',
    });
  } catch (error: any) {
    results.push({
      name: 'Schema Endpoint',
      passed: false,
      message: `Error: ${error.message}`,
    });
  }
}

async function testReportCompletion(caseId: string) {
  try {
    const cookie = await getSessionCookie('admin', 'admin123');
    
    // First, validate the report
    const validateResponse = await fetch(`${BASE_URL}/api/cases/${caseId}/report/v2/validate`, {
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json',
        Cookie: cookie,
      },
      body: JSON.stringify({}),
    });

    if (!validateResponse.ok) {
      const error = await validateResponse.json();
      results.push({
        name: 'Report Validation',
        passed: false,
        message: `Validation failed: ${JSON.stringify(error)}`,
      });
      return;
    }

    const validation = await validateResponse.json();
    
    // Then try to complete
    const completeResponse = await fetch(`${BASE_URL}/api/cases/${caseId}/report/v2/complete`, {
      method: 'POST',
      headers: { Cookie: cookie },
    });

    const completeData = await completeResponse.json();

    if (!completeResponse.ok) {
      results.push({
        name: 'Report Completion',
        passed: false,
        message: `Completion failed: ${completeData.message || 'Unknown error'}. Errors: ${JSON.stringify(completeData.errors || [])}`,
      });
      return;
    }

    results.push({
      name: 'Report Completion',
      passed: true,
      message: 'Report completed successfully',
    });
  } catch (error: any) {
    results.push({
      name: 'Report Completion',
      passed: false,
      message: `Error: ${error.message}`,
    });
  }
}

async function runTests() {
  console.log('Running Case Report Completion Tests...\n');

  // Test 1: Schema endpoint
  await testReportSchema();

  // Test 2: Report completion (requires a valid case ID - will be skipped if not provided)
  const testCaseId = process.env.TEST_CASE_ID;
  if (testCaseId) {
    await testReportCompletion(testCaseId);
  } else {
    results.push({
      name: 'Report Completion',
      passed: true,
      message: 'Skipped - Set TEST_CASE_ID env var to test completion',
    });
  }

  // Print results
  console.log('\nTest Results:');
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
  results.forEach(result => {
    const status = result.passed ? '✓ PASS' : '✗ FAIL';
    console.log(`${status} - ${result.name}`);
    console.log(`  ${result.message}\n`);
  });

  const passed = results.filter(r => r.passed).length;
  const total = results.length;
  console.log(`\nTotal: ${passed}/${total} tests passed`);

  process.exit(passed === total ? 0 : 1);
}

// Run tests if executed directly
if (require.main === module) {
  runTests().catch(console.error);
}

export { runTests, testReportSchema, testReportCompletion };

