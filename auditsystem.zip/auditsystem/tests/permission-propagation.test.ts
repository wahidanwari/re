/**
 * Permission Propagation Test Script
 * 
 * Tests immediate permission propagation when admin changes user permissions
 * 
 * Usage:
 *   1. Start the server
 *   2. Have two users ready: one admin, one regular user
 *   3. Run: npm run test:permissions (or node tests/permission-propagation.test.ts)
 */

import fetch from 'node-fetch';
import WebSocket from 'ws';

const BASE_URL = process.env.TEST_BASE_URL || 'http://localhost:3000';
const WS_URL = process.env.TEST_WS_URL || 'ws://localhost:3000';

interface TestResult {
  name: string;
  passed: boolean;
  message: string;
}

const results: TestResult[] = [];

async function getSessionCookie(auditId: string, password: string): Promise<string> {
  const response = await fetch(`${BASE_URL}/api/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ auditId, password }),
  });

  if (!response.ok) {
    throw new Error(`Login failed for ${auditId}`);
  }

  const cookies = response.headers.get('set-cookie');
  if (!cookies) {
    throw new Error('No session cookie received');
  }

  return cookies;
}

async function getUserData(cookies: string) {
  const response = await fetch(`${BASE_URL}/api/auth/me`, {
    headers: { Cookie: cookies },
  });

  if (!response.ok) {
    throw new Error('Failed to get user data');
  }

  return response.json();
}

async function updateUserPermissions(
  adminCookies: string,
  userId: string,
  permissionPackages: string[]
) {
  const response = await fetch(`${BASE_URL}/api/users/${userId}`, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
      Cookie: adminCookies,
    },
    body: JSON.stringify({ permissionPackages }),
  });

  if (!response.ok) {
    throw new Error(`Failed to update user permissions: ${response.statusText}`);
  }

  return response.json();
}

async function testPermissionPropagation() {
  console.log('=== Permission Propagation Tests ===\n');

  const adminAuditId = process.env.TEST_ADMIN_AUDIT_ID || 'ADMIN001';
  const adminPassword = process.env.TEST_ADMIN_PASSWORD || 'admin123';
  const userAuditId = process.env.TEST_USER_AUDIT_ID || 'USER001';
  const userPassword = process.env.TEST_USER_PASSWORD || 'user123';

  try {
    // Step 1: Login as admin and regular user
    console.log('Step 1: Logging in as admin and user...');
    const adminCookies = await getSessionCookie(adminAuditId, adminPassword);
    const userCookies = await getSessionCookie(userAuditId, userPassword);

    // Step 2: Get initial user data
    console.log('Step 2: Getting initial user permissions...');
    const initialUserData = await getUserData(userCookies);
    const initialVersion = initialUserData.permissionsVersion || 1;
    const initialPackages = initialUserData.user.permissionPackages || [];

    console.log(`   Initial version: ${initialVersion}`);
    console.log(`   Initial packages: ${JSON.stringify(initialPackages)}`);

    results.push({
      name: 'Initial Permission State',
      passed: true,
      message: `Version: ${initialVersion}, Packages: ${JSON.stringify(initialPackages)}`,
    });

    // Step 3: Set up WebSocket to listen for permission changes
    console.log('Step 3: Setting up WebSocket connection...');
    let permissionChangeReceived = false;
    let ws: WebSocket | null = null;

    const wsPromise = new Promise<void>((resolve, reject) => {
      const protocol = WS_URL.startsWith('wss') ? 'wss:' : 'ws:';
      const host = WS_URL.replace(/^https?:\/\//, '').replace(/^wss?:\/\//, '');
      const wsUrl = `${protocol}//${host}/ws/notifications`;

      ws = new WebSocket(wsUrl, {
        headers: {
          Cookie: userCookies,
        },
      });

      ws.on('open', () => {
        console.log('   WebSocket connected');
      });

      ws.on('message', (data: WebSocket.Data) => {
        try {
          const message = JSON.parse(data.toString());
          if (message.type === 'permission_change') {
            console.log('   Permission change notification received!');
            permissionChangeReceived = true;
            resolve();
          }
        } catch (error) {
          // Ignore parse errors
        }
      });

      ws.on('error', (error) => {
        console.error('   WebSocket error:', error);
        reject(error);
      });

      // Timeout after 10 seconds
      setTimeout(() => {
        if (!permissionChangeReceived) {
          reject(new Error('WebSocket timeout - no permission change received'));
        }
      }, 10000);
    });

    // Step 4: Admin grants Coordinator package to user
    console.log('Step 4: Admin granting Coordinator package...');
    const userId = initialUserData.user.id;
    const updatedUser = await updateUserPermissions(adminCookies, userId, ['acting_coordinator']);

    console.log(`   Updated packages: ${JSON.stringify(updatedUser.permissionPackages)}`);

    // Step 5: Wait for WebSocket notification
    console.log('Step 5: Waiting for permission change notification...');
    try {
      await Promise.race([
        wsPromise,
        new Promise((_, reject) => setTimeout(() => reject(new Error('Timeout')), 10000)),
      ]);

      results.push({
        name: 'WebSocket Permission Change Notification',
        passed: true,
        message: 'Permission change notification received via WebSocket',
      });
    } catch (error: any) {
      results.push({
        name: 'WebSocket Permission Change Notification',
        passed: false,
        message: `Failed: ${error.message}`,
      });
    } finally {
      if (ws) {
        ws.close();
      }
    }

    // Step 6: Verify user's permissions were updated
    console.log('Step 6: Verifying updated permissions...');
    await new Promise((resolve) => setTimeout(resolve, 1000)); // Wait 1 second for propagation

    const updatedUserData = await getUserData(userCookies);
    const newVersion = updatedUserData.permissionsVersion || 1;
    const newPackages = updatedUserData.user.permissionPackages || [];

    console.log(`   New version: ${newVersion}`);
    console.log(`   New packages: ${JSON.stringify(newPackages)}`);

    const versionChanged = newVersion > initialVersion;
    const packagesChanged = JSON.stringify(newPackages) !== JSON.stringify(initialPackages);

    results.push({
      name: 'Permission Version Update',
      passed: versionChanged,
      message: versionChanged
        ? `Version incremented: ${initialVersion} → ${newVersion}`
        : `Version unchanged: ${initialVersion}`,
    });

    results.push({
      name: 'Permission Packages Update',
      passed: packagesChanged,
      message: packagesChanged
        ? `Packages updated: ${JSON.stringify(initialPackages)} → ${JSON.stringify(newPackages)}`
        : 'Packages unchanged',
    });

    // Step 7: Verify effective permissions include coordinator rights
    const effectivePerms = updatedUserData.effectivePermissions || {};
    const hasCoordinatorPerms =
      effectivePerms['cases:assign_to_group'] === true ||
      effectivePerms['entities:create'] === true;

    results.push({
      name: 'Effective Permissions Update',
      passed: hasCoordinatorPerms,
      message: hasCoordinatorPerms
        ? 'Coordinator permissions are active'
        : 'Coordinator permissions not found',
    });

    console.log('\n=== Test Results ===');
    results.forEach((result) => {
      const status = result.passed ? '✅ PASS' : '❌ FAIL';
      console.log(`${status}: ${result.name}`);
      console.log(`   ${result.message}\n`);
    });

    const allPassed = results.every((r) => r.passed);
    console.log(`\nOverall: ${allPassed ? '✅ ALL TESTS PASSED' : '❌ SOME TESTS FAILED'}`);
  } catch (error: any) {
    console.error('Test failed:', error.message);
    results.push({
      name: 'Test Execution',
      passed: false,
      message: error.message,
    });
  }
}

// Run tests if executed directly
if (require.main === module) {
  testPermissionPropagation()
    .then(() => process.exit(0))
    .catch((error) => {
      console.error('Fatal error:', error);
      process.exit(1);
    });
}

export { testPermissionPropagation };

