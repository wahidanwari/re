// Unit tests for permission service
// Run with: npm test or tsx tests/permissionService.test.ts

import { describe, it, expect, beforeAll, afterAll } from '@jest/globals';
import { Pool } from 'pg';
import { getEffectivePermissions, hasPermission } from '../server/services/permissionService';

// Note: These tests require a test database
// Set TEST_DATABASE_URL environment variable

describe('Permission Service', () => {
  let testUserId: string;
  let pool: Pool;

  beforeAll(async () => {
    if (!process.env.TEST_DATABASE_URL) {
      console.warn('TEST_DATABASE_URL not set, skipping permission service tests');
      return;
    }
    pool = new Pool({ connectionString: process.env.TEST_DATABASE_URL });
    
    // Create a test user
    const result = await pool.query(`
      INSERT INTO users (audit_id, password, full_name, role, is_active)
      VALUES ('TEST-AUD-001', 'hashed_password', 'Test User', 'auditor', true)
      RETURNING id
    `);
    testUserId = result.rows[0].id;
  });

  afterAll(async () => {
    if (pool) {
      if (testUserId) {
        await pool.query('DELETE FROM users WHERE id = $1', [testUserId]);
      }
      await pool.end();
    }
  });

  it('should return empty permissions for user without role', async () => {
    if (!process.env.TEST_DATABASE_URL) return;
    
    const perms = await getEffectivePermissions('non-existent-user-id');
    expect(perms['cases:read_all']).toBe(false);
    expect(perms['cases:read_assigned']).toBe(false);
  });

  it('should return correct permissions for auditor role', async () => {
    if (!process.env.TEST_DATABASE_URL) return;
    
    // Assign auditor role to test user
    const auditorRole = await pool.query("SELECT id FROM roles WHERE name = 'auditor'");
    if (auditorRole.rows.length > 0) {
      await pool.query(
        'INSERT INTO user_roles (user_id, role_id) VALUES ($1, $2) ON CONFLICT DO NOTHING',
        [testUserId, auditorRole.rows[0].id]
      );
      
      const perms = await getEffectivePermissions(testUserId);
      expect(perms['cases:read_assigned']).toBe(true);
      expect(perms['cases:update_progress']).toBe(true);
      expect(perms['approvals:create_tickets']).toBe(true);
      expect(perms['cases:read_all']).toBe(false);
      expect(perms['users:manage_all']).toBe(false);
    }
  });

  it('should add package permissions to base role', async () => {
    if (!process.env.TEST_DATABASE_URL) return;
    
    // Assign acting_coordinator package
    const packageId = await pool.query("SELECT id FROM packages WHERE name = 'acting_coordinator'");
    if (packageId.rows.length > 0) {
      await pool.query(
        'INSERT INTO user_packages (user_id, package_id) VALUES ($1, $2) ON CONFLICT DO NOTHING',
        [testUserId, packageId.rows[0].id]
      );
      
      const perms = await getEffectivePermissions(testUserId);
      // Auditor base permissions
      expect(perms['cases:read_assigned']).toBe(true);
      // Package adds these
      expect(perms['cases:assign_to_groups']).toBe(true);
      expect(perms['groups:manage_all']).toBe(true);
      expect(perms['reports:internal']).toBe(true);
    }
  });

  it('should respect expired packages', async () => {
    if (!process.env.TEST_DATABASE_URL) return;
    
    const packageId = await pool.query("SELECT id FROM packages WHERE name = 'approval_authority'");
    if (packageId.rows.length > 0) {
      const expiredDate = new Date();
      expiredDate.setDate(expiredDate.getDate() - 1); // Yesterday
      
      await pool.query(
        'INSERT INTO user_packages (user_id, package_id, expires_at) VALUES ($1, $2, $3) ON CONFLICT (user_id, package_id) DO UPDATE SET expires_at = $3',
        [testUserId, packageId.rows[0].id, expiredDate]
      );
      
      const perms = await getEffectivePermissions(testUserId);
      // Expired package should not grant permission
      expect(perms['approvals:approve_tickets']).toBe(false);
    }
  });
});

// Run tests if executed directly
if (require.main === module) {
  console.log('Run with: npm test');
}

