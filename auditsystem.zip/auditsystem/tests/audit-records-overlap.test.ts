/**
 * Unit Tests for Audit Records Overlap Detection
 * 
 * Tests the overlap detection logic for audit records with year ranges
 * 
 * Usage:
 *   npm test -- audit-records-overlap.test.ts
 *   or: tsx tests/audit-records-overlap.test.ts
 */

import { describe, it, expect, beforeAll, afterAll } from '@jest/globals';
import { Pool } from 'pg';
import { db } from '../server/db';
import { storage } from '../server/storage';
import { entities, auditRecords } from '@shared/schema';
import { eq } from 'drizzle-orm';

// Note: These tests require a test database
// Set TEST_DATABASE_URL environment variable

describe('Audit Records Overlap Detection', () => {
  let testEntityId: string;
  let pool: Pool;
  let testAuditRecordIds: string[] = [];

  beforeAll(async () => {
    if (!process.env.TEST_DATABASE_URL) {
      console.warn('TEST_DATABASE_URL not set, skipping overlap detection tests');
      return;
    }
    
    pool = new Pool({ connectionString: process.env.TEST_DATABASE_URL });
    
    // Create a test entity
    const [entity] = await db.insert(entities).values({
      companyName: 'Test Company for Overlap',
      tin: 'TEST-TIN-OVERLAP-' + Date.now(),
      businessNature: 'تجارتی',
      status: 'NEW',
    }).returning();
    
    testEntityId = entity.id;
  });

  afterAll(async () => {
    if (pool) {
      // Clean up test audit records
      if (testAuditRecordIds.length > 0) {
        await db.delete(auditRecords).where(
          eq(auditRecords.entityId, testEntityId)
        );
      }
      
      // Clean up test entity
      if (testEntityId) {
        await db.delete(entities).where(eq(entities.id, testEntityId));
      }
      
      await pool.end();
    }
  });

  it('should detect no overlap for non-overlapping ranges', async () => {
    if (!process.env.TEST_DATABASE_URL) return;
    
    // Create first audit record: 1400-1402
    const [record1] = await db.insert(auditRecords).values({
      entityId: testEntityId,
      yearFrom: 1400,
      yearTo: 1402,
      status: 'planned',
    }).returning();
    testAuditRecordIds.push(record1.id);
    
    // Check overlap for 1403-1405 (should not overlap)
    const overlaps = await storage.checkAuditRecordOverlap(
      testEntityId,
      1403,
      1405
    );
    
    expect(overlaps.length).toBe(0);
  });

  it('should detect overlap for overlapping ranges', async () => {
    if (!process.env.TEST_DATABASE_URL) return;
    
    // Check overlap for 1401-1403 (should overlap with 1400-1402)
    const overlaps = await storage.checkAuditRecordOverlap(
      testEntityId,
      1401,
      1403
    );
    
    expect(overlaps.length).toBeGreaterThan(0);
    expect(overlaps[0].yearFrom).toBe(1400);
    expect(overlaps[0].yearTo).toBe(1402);
  });

  it('should detect overlap for contained ranges', async () => {
    if (!process.env.TEST_DATABASE_URL) return;
    
    // Check overlap for 1401 (contained within 1400-1402)
    const overlaps = await storage.checkAuditRecordOverlap(
      testEntityId,
      1401,
      1401
    );
    
    expect(overlaps.length).toBeGreaterThan(0);
  });

  it('should detect overlap for containing ranges', async () => {
    if (!process.env.TEST_DATABASE_URL) return;
    
    // Check overlap for 1399-1403 (contains 1400-1402)
    const overlaps = await storage.checkAuditRecordOverlap(
      testEntityId,
      1399,
      1403
    );
    
    expect(overlaps.length).toBeGreaterThan(0);
  });

  it('should exclude current record when checking overlaps for update', async () => {
    if (!process.env.TEST_DATABASE_URL) return;
    
    // Check overlap excluding the record we just created
    const overlaps = await storage.checkAuditRecordOverlap(
      testEntityId,
      1400,
      1402,
      testAuditRecordIds[0]
    );
    
    expect(overlaps.length).toBe(0);
  });

  it('should prevent creating overlapping audit records', async () => {
    if (!process.env.TEST_DATABASE_URL) return;
    
    // Try to create overlapping record (should fail)
    await expect(
      storage.createAuditRecord({
        entityId: testEntityId,
        yearFrom: 1401,
        yearTo: 1403,
        status: 'planned',
      })
    ).rejects.toThrow();
  });

  it('should allow creating non-overlapping audit records', async () => {
    if (!process.env.TEST_DATABASE_URL) return;
    
    // Create non-overlapping record (should succeed)
    const record = await storage.createAuditRecord({
      entityId: testEntityId,
      yearFrom: 1405,
      yearTo: 1407,
      status: 'planned',
    });
    
    testAuditRecordIds.push(record.id);
    expect(record.yearFrom).toBe(1405);
    expect(record.yearTo).toBe(1407);
  });

  it('should validate year range (yearFrom <= yearTo)', async () => {
    if (!process.env.TEST_DATABASE_URL) return;
    
    // Try to create record with invalid range (should fail)
    await expect(
      storage.createAuditRecord({
        entityId: testEntityId,
        yearFrom: 1410,
        yearTo: 1408, // Invalid: from > to
        status: 'planned',
      })
    ).rejects.toThrow();
  });

  it('should detect adjacent ranges as non-overlapping', async () => {
    if (!process.env.TEST_DATABASE_URL) return;
    
    // Check overlap for 1403-1404 (adjacent to 1400-1402, should not overlap)
    const overlaps = await storage.checkAuditRecordOverlap(
      testEntityId,
      1403,
      1404
    );
    
    expect(overlaps.length).toBe(0);
  });

  it('should handle single year ranges correctly', async () => {
    if (!process.env.TEST_DATABASE_URL) return;
    
    // Create single year record
    const record = await storage.createAuditRecord({
      entityId: testEntityId,
      yearFrom: 1410,
      yearTo: 1410,
      status: 'planned',
    });
    
    testAuditRecordIds.push(record.id);
    
    // Check overlap with same year (should detect)
    const overlaps = await storage.checkAuditRecordOverlap(
      testEntityId,
      1410,
      1410
    );
    
    expect(overlaps.length).toBeGreaterThan(0);
  });
});

