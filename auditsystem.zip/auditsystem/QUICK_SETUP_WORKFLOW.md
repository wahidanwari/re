# Quick Setup Guide - Workflow System

## 🚀 Fast Setup (Copy & Paste)

### Prerequisites
```bash
# 1. Set your DATABASE_URL
# Windows PowerShell:
$env:DATABASE_URL="postgresql://user:password@localhost:5432/database_name"

# Linux/macOS:
export DATABASE_URL="postgresql://user:password@localhost:5432/database_name"
```

### Run All Migrations (One Command - Recommended)

**Using Node.js (Works on Windows, Linux, macOS):**

```bash
# Make sure DATABASE_URL is set in .env file
npm run db:migrate-workflow
```

**Using psql directly (If psql is in PATH):**

**Windows PowerShell:**
```powershell
psql $env:DATABASE_URL -f migrations/016_create_monthly_transactions_table.sql; psql $env:DATABASE_URL -f migrations/017_create_internal_report_table.sql; psql $env:DATABASE_URL -f migrations/018_create_ministry_summary_table.sql; psql $env:DATABASE_URL -f migrations/019_create_alerts_table.sql; psql $env:DATABASE_URL -f migrations/020_create_workflow_config_table.sql
```

**Linux/macOS:**
```bash
psql $DATABASE_URL -f migrations/016_create_monthly_transactions_table.sql && \
psql $DATABASE_URL -f migrations/017_create_internal_report_table.sql && \
psql $DATABASE_URL -f migrations/018_create_ministry_summary_table.sql && \
psql $DATABASE_URL -f migrations/019_create_alerts_table.sql && \
psql $DATABASE_URL -f migrations/020_create_workflow_config_table.sql
```

### Verify Setup

```bash
# Check all tables exist
psql $DATABASE_URL -c "\dt monthly_transactions internal_report ministry_summary workflow_alerts workflow_config"

# Check views exist
psql $DATABASE_URL -c "\dv internal_report_monthly_totals ministry_summary_monthly_totals"
```

---

## 📋 Step-by-Step Commands

### Step 1: MonthlyTransactions Table
```bash
psql $DATABASE_URL -f migrations/016_create_monthly_transactions_table.sql
```

### Step 2: InternalReport Table
```bash
psql $DATABASE_URL -f migrations/017_create_internal_report_table.sql
```

### Step 3: MinistrySummary Table
```bash
psql $DATABASE_URL -f migrations/018_create_ministry_summary_table.sql
```

### Step 4: Linking (No Migration - Code Only)
✅ Already implemented in `server/services/workflowService.ts`

### Step 5: Alerts Table
```bash
psql $DATABASE_URL -f migrations/019_create_alerts_table.sql
```

### Step 6: Exports (No Migration - Code Only)
✅ Already implemented in `server/services/workflowExportService.ts`

### Step 7: WorkflowConfig Table
```bash
psql $DATABASE_URL -f migrations/020_create_workflow_config_table.sql
```

---

## ✅ Verification Checklist

- [ ] All 5 tables created (monthly_transactions, internal_report, ministry_summary, workflow_alerts, workflow_config)
- [ ] 2 views created (internal_report_monthly_totals, ministry_summary_monthly_totals)
- [ ] All indexes created
- [ ] Foreign key constraints in place
- [ ] Unique constraints working

---

## 🧪 Test the System

```bash
# Start server
npm run dev

# Test workflow automation (replace with your session cookie)
curl -X POST http://localhost:3000/api/workflow/automate/10/1404 \
  -H "Content-Type: application/json" \
  -H "Cookie: audit.sid=YOUR_SESSION" \
  -d '{"appendMode": true, "regenerateReports": true, "regenerateSummaries": true, "generateAlerts": true}'
```

---

## 📚 Full Documentation

See `docs/WORKFLOW_SETUP_COMMANDS.md` for detailed setup instructions and troubleshooting.

