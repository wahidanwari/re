# Master Entity with Linked AuditRecord - Implementation Guide

## Overview

This implementation replaces the previous model that created one entity-per-audit with a normalized pattern:

- **Master Entity**: Single `entities` table entry per TIN (unique per TIN)
- **Audit Records**: New `audit_records` table that links to `entities` and stores audit year ranges, assigned group, status, and audit-specific metadata
- **Non-overlapping Ranges**: Enforces uniqueness/non-overlap per (entity_id, year range)

## Database Migration

### Step 1: Run the Database Schema Migration

```bash
# Windows PowerShell
npm run db:migrate-audit-records-year-ranges

# Linux/Mac or if DATABASE_URL is set
psql $DATABASE_URL -f migrations/023_audit_records_year_ranges.sql

# Or directly with connection string
psql "postgresql://user:password@localhost:5432/dbname" -f migrations/023_audit_records_year_ranges.sql
```

This migration:
- Creates new `audit_records` table with year ranges (`year_from`, `year_to`)
- Migrates existing single-year audit records to year ranges
- Adds overlap detection constraints and triggers
- Creates necessary indexes

### Step 2: Data Migration (Optional)

If you have existing entities that need to be converted to the new structure:

```bash
# Dry run to preview changes
npm run db:migrate-entity-audit-records -- --dry-run

# Apply migration (type "yes" or "y" when prompted)
npm run db:migrate-entity-audit-records
```

**Note**: When prompted for confirmation, type `yes` or `y` (case-insensitive).

The migration script will:
- Detect duplicate TINs (entities created per year)
- Create master entities for unique TINs
- Create `audit_records` for each year range found in existing entities
- Preserve all existing data

## API Endpoints

### Get Audit Records for Entity
```
GET /api/audit-records/entities/:entityId/audits
Query params:
  - page (default: 1)
  - limit (default: 50)
  - status (optional filter)
```

### Create Audit Record
```
POST /api/audit-records/entities/:entityId/audits
Body:
{
  yearFrom: number,
  yearTo: number,
  auditGroupId?: string,
  responsibleEvaluator?: string,
  notes?: string
}
```

### Get Audit Record by ID
```
GET /api/audit-records/:id
```

### Update Audit Record
```
PATCH /api/audit-records/:id
Body: (only allowed fields if status != 'completed')
{
  yearFrom?: number,
  yearTo?: number,
  auditGroupId?: string,
  responsibleEvaluator?: string,
  notes?: string,
  status?: string
}
```

### Complete Audit Record
```
POST /api/audit-records/:id/complete
```

### List All Audit Records (with filters)
```
GET /api/audit-records
Query params:
  - entityId (optional)
  - yearFrom (optional)
  - yearTo (optional)
  - status (optional)
  - auditGroupId (optional)
```

## Business Logic

### Overlap Detection

The system prevents overlapping year ranges for the same entity:

- **Database Level**: Trigger function `prevent_audit_record_overlap()` enforces non-overlapping ranges
- **Application Level**: `checkAuditRecordOverlap()` method validates before creation/update
- **UI Level**: Real-time overlap checking via AJAX before form submission

### Status Management

- **planned**: Initial state when audit is created
- **in_progress**: Audit is actively being worked on
- **completed**: Audit is finished (read-only, only notes can be updated)
- **closed**: Audit was closed/cancelled
- **transferred**: Audit was transferred to another group

### Field Locking

When `status === 'completed'`:
- All fields except `notes` are locked
- Only notes can be updated
- Year ranges cannot be changed
- Status cannot be changed back

## UI Components

### Entity Detail Page
- Shows audit timeline with all audit records for the entity
- Displays gaps in year coverage (years without audit records)
- "Create Audit" button to add new audit records
- Each audit record shows: year range, status, group, responsible evaluator, dates

### Create Audit Modal
- Step 1: Select year range (year_from and year_to)
- Step 2: Select audit group
- Step 3: Optional fields (responsible evaluator, notes)
- Real-time overlap detection with conflict warnings

### Audit Detail Page
- Read-only view for completed audits
- Editable for planned/in_progress audits
- Shows full history of changes
- Complete button (for coordinators/admins)

## Testing

### Unit Tests
```bash
# Test overlap detection logic
npm test -- overlap-detection.test.ts
```

### Integration Tests
```bash
# Test API endpoints
npm test -- audit-records-api.test.ts
```

### E2E Tests
```bash
# Test UI flows
npm test -- audit-records-e2e.test.ts
```

## Feature Flag (Optional)

To enable this feature behind a flag:

1. Add to system settings:
```sql
INSERT INTO system_settings (key, value, category, description)
VALUES ('audit_records_year_ranges_enabled', 'true', 'feature_flags', 'Enable year range audit records');
```

2. Check in code:
```typescript
const setting = await storage.getSetting('audit_records_year_ranges_enabled');
if (setting?.value !== true) {
  // Use old behavior
}
```

## Rollback Plan

If you need to rollback:

1. **Disable Feature Flag** (if using):
```sql
UPDATE system_settings SET value = 'false' WHERE key = 'audit_records_year_ranges_enabled';
```

2. **Restore Database**:
```bash
# Restore from backup taken before migration
psql $DATABASE_URL < backup.sql
```

3. **Revert Code**: Checkout previous version of code

## Known Limitations

1. **Year Range Validation**: Currently only validates at database and application level. UI validation is basic.
2. **Gap Detection**: Gap detection in timeline is visual only - no automatic alerts.
3. **Migration**: Migration script assumes year information is in `yearsUnderReview` or `periodsUnderReview` fields.

## Future Enhancements

- [ ] Add ability to split audit ranges into sub-ranges
- [ ] Add notifications on new audit creation to assigned group members
- [ ] Add admin page to resolve conflicts manually
- [ ] Add bulk operations for creating multiple audit records
- [ ] Add reporting/charts that aggregate audits by year and group

## Support

For issues or questions, please refer to:
- API Documentation: `/api/docs` (if available)
- Database Schema: `shared/schema.ts`
- Migration Scripts: `migrations/023_audit_records_year_ranges.sql`

