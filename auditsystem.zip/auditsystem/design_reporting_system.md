# Phase 2: Design - Case Completion + Full Reporting Form

## 1. Design Overview

This design proposes a complete, structured reporting system that:
1. Matches official MoF (Ministry of Finance) report format
2. Supports draft mode with autosave
3. Provides comprehensive validation per section
4. Locks completed reports while allowing draft editing
5. Generates PDF/print-ready exports
6. Maintains 100% RTL accuracy
7. Uses structured database schema for extensibility

## 2. Report Structure

### 2.1 Report Sections

**Section 1: مشخصات نهاد (Entity Details)**
- Basic Information (auto-populated, read-only)
- Address Information (NEW)
- Registration Details (NEW)
- Tax Information (NEW)

**Section 2: بیرون‌نویسی‌ها (Extractions)**
- Tax Calculations (existing + NEW fields)
- Payment Information (NEW)
- Calculation Details (NEW)

**Section 3: یافته‌ها و توصیه‌ها (Findings & Recommendations)** (NEW)
- Audit Findings
- Recommendations
- Action Items

**Section 4: اسناد حمایوی (Supporting Documents)** (NEW)
- Document Checklist
- Document Review Status

**Section 5: تایید و امضا (Approval & Signatures)** (NEW)
- Approval Chain
- Signatures

### 2.2 Complete Field List

#### Section 1: مشخصات نهاد (Entity Details)

**Subsection 1.1: Basic Information** (Auto-populated, Read-only)
- `companyName` - نام نهاد
- `tin` - نمبر تشخیصیه
- `businessNature` - نوع تشبث
- `groupReferrer` - آمریت ارجاع کننده
- `referralDate` - تاریخ ارجاع شده
- `periodsUnderReview` - سال‌های بررسی

**Subsection 1.2: Document Dates** (Editable)
- `finalDocumentDate` - تاریخ صادره مکتوب نهایی
- `capitalPeriod` - دوران سرمایه

**Subsection 1.3: Address Information** (NEW)
- `province` - ولایت
- `district` - ولسوالی
- `streetAddress` - آدرس
- `postalCode` - کد پستی
- `phone` - شماره تماس
- `email` - ایمیل

**Subsection 1.4: Registration Details** (NEW)
- `registrationNumber` - نمبر ثبت
- `registrationDate` - تاریخ ثبت
- `businessLicenseNumber` - نمبر جواز فعالیت
- `businessLicenseDate` - تاریخ جواز فعالیت

**Subsection 1.5: Tax Information** (NEW)
- `taxOffice` - دفتر مالیاتی
- `taxRegistrationDate` - تاریخ ثبت مالیاتی
- `taxOfficeCode` - کد دفتر مالیاتی

#### Section 2: بیرون‌نویسی‌ها (Extractions)

**Subsection 2.1: Tax Types** (Existing + NEW)
- `salaryTax` - مالیه موضوعی معاشات
- `rentTax` - مالیه موضوعی بر کرایه
- `contractTax` - مالیه موضوعی قراردادی
- `profitTransactionTax` - مالیات معاملات انتفاعی
- `incomeTax` - مالیات بر عایدات
- `withholdingTax` - مالیات کسر شده (NEW)
- `penaltyTax` - مالیات جریمه (NEW)
- `interest` - سود (NEW)
- `otherTaxes` - سایر مالیات‌ها (NEW)

**Subsection 2.2: Financial Calculations** (Existing)
- `reducedLoss` - ضرر کاهش یافته
- `reducedRemainingAmount` - مبلغ فاضل تحویل کاهش یافته
- `confirmedAmount` - مبلغ تثبیت شده
- `collectedCurrentMonth` - مبلغ تحصیل شده طی برج جاری
- `remainingCollectible` - الباقی مبلغ قابل تحصیل

**Subsection 2.3: Calculation Details** (NEW)
- `taxBase` - مبنا مالیاتی
- `taxRate` - نرخ مالیاتی
- `calculationMethod` - روش محاسبه
- `totalTaxAmount` - مجموع مالیات (calculated)
- `totalCollected` - مجموع تحصیل شده (calculated)
- `totalRemaining` - مجموع باقیمانده (calculated)

**Subsection 2.4: Payment Information** (NEW)
- `paymentMethod` - روش پرداخت
- `paymentReferenceNumber` - نمبر مرجع پرداخت
- `paymentDate` - تاریخ پرداخت
- `bankName` - نام بانک
- `bankAccountNumber` - شماره حساب بانکی
- `bankBranch` - شعبه بانک

**Subsection 2.5: Status & Attachment** (Existing)
- `activityStatus` - وضعیت فعالیت
- `attachmentNumber` - نمبر آویز
- `attachmentDate` - تاریخ آویز

#### Section 3: یافته‌ها و توصیه‌ها (Findings & Recommendations) (NEW)

**Subsection 3.1: Audit Findings**
- `findingsSummary` - خلاصه یافته‌ها (TEXTAREA, required)
- `detailedFindings` - یافته‌های تفصیلی (TEXTAREA, optional)
- `riskAssessment` - ارزیابی ریسک (SELECT: "کم", "متوسط", "زیاد", required)

**Subsection 3.2: Recommendations**
- `recommendations` - توصیه‌ها (TEXTAREA, required)
- `actionItems` - اقدامات لازم (TEXTAREA, optional)
- `followUpRequired` - نیاز به پیگیری (BOOLEAN, default: false)
- `followUpDate` - تاریخ پیگیری (DATE, conditional on followUpRequired)

#### Section 4: اسناد حمایوی (Supporting Documents) (NEW)

**Subsection 4.1: Document Checklist**
- `documentsReviewed` - اسناد بررسی شده (JSON array of document IDs)
- `documentsAttached` - اسناد ضمیمه (JSON array of document IDs)
- `missingDocuments` - اسناد ناقص (TEXTAREA, optional)
- `documentReviewDate` - تاریخ بررسی اسناد (DATE)

**Subsection 4.2: Document Status**
- `allDocumentsComplete` - تمام اسناد کامل است (BOOLEAN, calculated)
- `documentReviewNotes` - ملاحظات بررسی اسناد (TEXTAREA, optional)

#### Section 5: تایید و امضا (Approval & Signatures) (NEW)

**Subsection 5.1: Preparation**
- `preparedBy` - تهیه شده توسط (USER ID, auto-set on save)
- `preparedAt` - تاریخ تهیه (TIMESTAMP, auto-set on save)
- `preparedByRole` - نقش تهیه‌کننده (TEXT, auto-set)

**Subsection 5.2: Review**
- `reviewedBy` - بررسی شده توسط (USER ID, optional)
- `reviewedAt` - تاریخ بررسی (TIMESTAMP, optional)
- `reviewedByRole` - نقش بررسی‌کننده (TEXT, optional)
- `reviewNotes` - ملاحظات بررسی (TEXTAREA, optional)

**Subsection 5.3: Approval**
- `approvedBy` - تایید شده توسط (USER ID, set on case approval)
- `approvedAt` - تاریخ تایید (TIMESTAMP, set on case approval)
- `approvedByRole` - نقش تاییدکننده (TEXT, set on case approval)

## 3. Database Schema Design

### 3.1 New Structured Schema

**Table: `case_reports_v2`** (NEW - replaces flat `case_reports`)

```sql
CREATE TABLE case_reports_v2 (
  id VARCHAR PRIMARY KEY DEFAULT gen_random_uuid()::text,
  case_id VARCHAR UNIQUE NOT NULL REFERENCES cases(id) ON DELETE CASCADE,
  
  -- Report Status
  status VARCHAR NOT NULL DEFAULT 'draft', -- 'draft', 'completed', 'locked'
  version INTEGER NOT NULL DEFAULT 1,
  
  -- Section 1: Entity Details
  -- Basic (auto-populated, stored for snapshot)
  company_name TEXT NOT NULL,
  tin TEXT NOT NULL,
  business_nature TEXT,
  group_referrer TEXT NOT NULL,
  referral_date TEXT NOT NULL,
  periods_under_review TEXT NOT NULL,
  
  -- Document Dates
  final_document_date TEXT,
  capital_period TEXT,
  
  -- Address Information (NEW)
  province TEXT,
  district TEXT,
  street_address TEXT,
  postal_code TEXT,
  phone TEXT,
  email TEXT,
  
  -- Registration Details (NEW)
  registration_number TEXT,
  registration_date TEXT,
  business_license_number TEXT,
  business_license_date TEXT,
  
  -- Tax Information (NEW)
  tax_office TEXT,
  tax_registration_date TEXT,
  tax_office_code TEXT,
  
  -- Section 2: Extractions
  -- Tax Types
  salary_tax NUMERIC(15, 2) DEFAULT 0,
  rent_tax NUMERIC(15, 2) DEFAULT 0,
  contract_tax NUMERIC(15, 2) DEFAULT 0,
  profit_transaction_tax NUMERIC(15, 2) DEFAULT 0,
  income_tax NUMERIC(15, 2) DEFAULT 0,
  withholding_tax NUMERIC(15, 2) DEFAULT 0, -- NEW
  penalty_tax NUMERIC(15, 2) DEFAULT 0, -- NEW
  interest NUMERIC(15, 2) DEFAULT 0, -- NEW
  other_taxes NUMERIC(15, 2) DEFAULT 0, -- NEW
  
  -- Financial Calculations
  reduced_loss NUMERIC(15, 2) DEFAULT 0,
  reduced_remaining_amount NUMERIC(15, 2) DEFAULT 0,
  confirmed_amount NUMERIC(15, 2) DEFAULT 0,
  collected_current_month NUMERIC(15, 2) DEFAULT 0,
  remaining_collectible NUMERIC(15, 2) DEFAULT 0,
  
  -- Calculation Details (NEW)
  tax_base NUMERIC(15, 2),
  tax_rate NUMERIC(5, 2), -- Percentage (e.g., 20.00 for 20%)
  calculation_method TEXT,
  total_tax_amount NUMERIC(15, 2) GENERATED ALWAYS AS (
    COALESCE(salary_tax, 0) + 
    COALESCE(rent_tax, 0) + 
    COALESCE(contract_tax, 0) + 
    COALESCE(profit_transaction_tax, 0) + 
    COALESCE(income_tax, 0) + 
    COALESCE(withholding_tax, 0) + 
    COALESCE(penalty_tax, 0) + 
    COALESCE(interest, 0) + 
    COALESCE(other_taxes, 0)
  ) STORED,
  total_collected NUMERIC(15, 2) GENERATED ALWAYS AS (
    COALESCE(collected_current_month, 0)
  ) STORED,
  total_remaining NUMERIC(15, 2) GENERATED ALWAYS AS (
    COALESCE(total_tax_amount, 0) - COALESCE(total_collected, 0)
  ) STORED,
  
  -- Payment Information (NEW)
  payment_method TEXT,
  payment_reference_number TEXT,
  payment_date TEXT,
  bank_name TEXT,
  bank_account_number TEXT,
  bank_branch TEXT,
  
  -- Status & Attachment
  activity_status TEXT, -- 'فعال', 'عدم فعالیت'
  attachment_number TEXT,
  attachment_date TEXT,
  
  -- Section 3: Findings & Recommendations (NEW)
  findings_summary TEXT,
  detailed_findings TEXT,
  risk_assessment TEXT, -- 'کم', 'متوسط', 'زیاد'
  recommendations TEXT,
  action_items TEXT,
  follow_up_required BOOLEAN DEFAULT false,
  follow_up_date TEXT,
  
  -- Section 4: Supporting Documents (NEW)
  documents_reviewed JSONB DEFAULT '[]'::jsonb, -- Array of document IDs
  documents_attached JSONB DEFAULT '[]'::jsonb, -- Array of document IDs
  missing_documents TEXT,
  document_review_date TEXT,
  document_review_notes TEXT,
  
  -- Section 5: Approval & Signatures (NEW)
  prepared_by VARCHAR REFERENCES users(id) ON DELETE SET NULL,
  prepared_at TIMESTAMP,
  prepared_by_role TEXT,
  reviewed_by VARCHAR REFERENCES users(id) ON DELETE SET NULL,
  reviewed_at TIMESTAMP,
  reviewed_by_role TEXT,
  review_notes TEXT,
  approved_by VARCHAR REFERENCES users(id) ON DELETE SET NULL,
  approved_at TIMESTAMP,
  approved_by_role TEXT,
  
  -- Metadata
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
  last_saved_by VARCHAR REFERENCES users(id) ON DELETE SET NULL,
  last_saved_at TIMESTAMP,
  
  -- Constraints
  CONSTRAINT case_reports_v2_status_check CHECK (status IN ('draft', 'completed', 'locked')),
  CONSTRAINT case_reports_v2_risk_assessment_check CHECK (risk_assessment IN ('کم', 'متوسط', 'زیاد') OR risk_assessment IS NULL),
  CONSTRAINT case_reports_v2_activity_status_check CHECK (activity_status IN ('فعال', 'عدم فعالیت') OR activity_status IS NULL)
);

-- Indexes
CREATE INDEX idx_case_reports_v2_case_id ON case_reports_v2(case_id);
CREATE INDEX idx_case_reports_v2_status ON case_reports_v2(status);
CREATE INDEX idx_case_reports_v2_prepared_by ON case_reports_v2(prepared_by);
CREATE INDEX idx_case_reports_v2_created_at ON case_reports_v2(created_at);
```

### 3.2 Report History Table (NEW)

**Table: `case_report_history`** - Track all changes to reports

```sql
CREATE TABLE case_report_history (
  id VARCHAR PRIMARY KEY DEFAULT gen_random_uuid()::text,
  report_id VARCHAR NOT NULL REFERENCES case_reports_v2(id) ON DELETE CASCADE,
  version INTEGER NOT NULL,
  changed_by VARCHAR NOT NULL REFERENCES users(id) ON DELETE SET NULL,
  changed_at TIMESTAMP NOT NULL DEFAULT NOW(),
  change_type VARCHAR NOT NULL, -- 'create', 'update', 'status_change', 'section_complete'
  section VARCHAR, -- 'section_1', 'section_2', 'section_3', 'section_4', 'section_5', 'all'
  changes JSONB, -- JSON object with field names and old/new values
  snapshot JSONB, -- Full report snapshot at this version
  notes TEXT,
  
  CONSTRAINT case_report_history_change_type_check CHECK (change_type IN ('create', 'update', 'status_change', 'section_complete'))
);

CREATE INDEX idx_case_report_history_report_id ON case_report_history(report_id);
CREATE INDEX idx_case_report_history_changed_at ON case_report_history(changed_at);
CREATE INDEX idx_case_report_history_version ON case_report_history(report_id, version);
```

### 3.3 Migration Strategy

**Step 1: Create new tables**
- Create `case_reports_v2` table
- Create `case_report_history` table

**Step 2: Migrate existing data**
- Copy data from `case_reports` to `case_reports_v2`
- Convert TEXT fields to NUMERIC where appropriate
- Set status to 'completed' for existing reports
- Create initial history entries

**Step 3: Update application code**
- Update storage methods to use `case_reports_v2`
- Update API endpoints
- Update frontend components

**Step 4: Deprecate old table**
- Keep `case_reports` for backward compatibility
- Add migration script to move remaining data
- Remove `case_reports` after migration period

## 4. Autosave & Draft Management

### 4.1 Autosave Mechanism

**Frontend Implementation:**
- Debounced autosave (save after 2 seconds of inactivity)
- Save on field blur
- Save on section completion
- Visual indicator for save status (saving/saved/error)

**Backend Implementation:**
- `POST /api/cases/:id/report/draft` - Save draft (non-blocking)
- `POST /api/cases/:id/report/section/:sectionId` - Save specific section
- `GET /api/cases/:id/report/draft` - Get latest draft

**Autosave Flow:**
1. User types in field
2. After 2 seconds of inactivity, trigger autosave
3. Send only changed fields to backend
4. Backend updates report, creates history entry
5. Frontend shows "ذخیره شد" indicator
6. On error, show error message and retry

### 4.2 Draft Status Management

**Status Values:**
- `draft` - Report is being edited, can be modified
- `completed` - Report is complete, ready for case completion
- `locked` - Report is locked (case approved/rejected), cannot be modified

**Status Transitions:**
- `draft` → `completed` - When user clicks "Complete Report"
- `completed` → `locked` - When case is approved or rejected
- `locked` → `draft` - When case is reopened (if allowed)

**Locking Rules:**
- Reports are locked when case status is "تایید شده" or "رد شده"
- Locked reports cannot be edited
- Locked reports can be viewed and exported
- System admin can unlock reports (with audit log)

## 5. Validation System

### 5.1 Validation Levels

**Level 1: Field-Level Validation**
- Required field checks
- Data type validation (numeric, date, email, etc.)
- Format validation (phone, postal code, etc.)
- Range validation (dates, amounts)

**Level 2: Section-Level Validation**
- All required fields in section must be filled
- Section-specific business rules
- Cross-field validation within section

**Level 3: Report-Level Validation**
- All sections must be complete
- Cross-section validation
- Business rule validation (totals, dates, etc.)

### 5.2 Validation Rules by Section

#### Section 1: Entity Details

**Required Fields:**
- All basic information (auto-populated, always present)
- `finalDocumentDate` - Must be valid Shamsi date
- `capitalPeriod` - Must be non-empty

**Validation Rules:**
- `finalDocumentDate` must be after `referralDate`
- `registrationDate` must be valid date (if provided)
- `taxRegistrationDate` must be valid date (if provided)
- `email` must be valid email format (if provided)
- `phone` must be valid phone format (if provided)

#### Section 2: Extractions

**Required Fields:**
- All tax type fields (can be 0)
- All financial calculation fields (can be 0)
- `activityStatus` - Must be "فعال" or "عدم فعالیت"
- `attachmentNumber` - Must be non-empty
- `attachmentDate` - Must be valid Shamsi date

**Validation Rules:**
- All numeric fields must be >= 0
- `totalTaxAmount` (calculated) must match sum of tax types
- `totalRemaining` (calculated) must match `totalTaxAmount - totalCollected`
- `paymentDate` must be after `attachmentDate` (if provided)
- If `activityStatus` = "عدم فعالیت", some tax fields may be 0

**Business Rules:**
- `confirmedAmount` should equal sum of tax types (warning if not)
- `collectedCurrentMonth` + `remainingCollectible` should equal `confirmedAmount` (warning if not)

#### Section 3: Findings & Recommendations

**Required Fields:**
- `findingsSummary` - Must be non-empty, min 50 characters
- `riskAssessment` - Must be selected
- `recommendations` - Must be non-empty, min 50 characters

**Validation Rules:**
- `followUpDate` must be in future if `followUpRequired` = true
- `detailedFindings` recommended if `riskAssessment` = "زیاد"

#### Section 4: Supporting Documents

**Required Fields:**
- `documentsReviewed` - Must have at least 1 document
- `documentReviewDate` - Must be valid date

**Validation Rules:**
- `documentsAttached` should include all required documents
- `missingDocuments` should be filled if `allDocumentsComplete` = false

#### Section 5: Approval & Signatures

**Auto-populated:**
- `preparedBy`, `preparedAt`, `preparedByRole` - Set on first save
- `approvedBy`, `approvedAt`, `approvedByRole` - Set on case approval

**Validation Rules:**
- `reviewedBy` and `reviewedAt` must both be set or both be null
- `reviewedAt` must be after `preparedAt` (if provided)

### 5.3 Validation API

**Endpoint: `POST /api/cases/:id/report/validate`**

**Request:**
```json
{
  "section": "section_2", // Optional: validate specific section
  "reportData": { ... } // Optional: validate provided data
}
```

**Response:**
```json
{
  "isValid": false,
  "section": "section_2",
  "errors": [
    {
      "field": "salaryTax",
      "message": "مقدار باید عدد مثبت باشد",
      "code": "INVALID_NUMBER"
    }
  ],
  "warnings": [
    {
      "field": "confirmedAmount",
      "message": "مبلغ تثبیت شده با مجموع مالیات‌ها مطابقت ندارد",
      "code": "AMOUNT_MISMATCH"
    }
  ],
  "completionStatus": {
    "section_1": { "complete": true, "requiredFields": 8, "filledFields": 8 },
    "section_2": { "complete": false, "requiredFields": 15, "filledFields": 12 },
    "section_3": { "complete": false, "requiredFields": 3, "filledFields": 1 },
    "section_4": { "complete": false, "requiredFields": 2, "filledFields": 0 },
    "section_5": { "complete": true, "requiredFields": 1, "filledFields": 1 }
  }
}
```

## 6. Report Locking & Reopening

### 6.1 Locking Mechanism

**When Reports are Locked:**
1. Case status changes to "تایید شده"
2. Case status changes to "رد شده"
3. Manual lock by system admin

**Lock Behavior:**
- Report status set to "locked"
- All form fields become read-only
- Save buttons disabled
- History shows lock event
- Audit log entry created

**Unlocking (System Admin Only):**
- `POST /api/cases/:id/report/unlock` - Unlock report
- Requires `users:manage` permission
- Creates audit log entry
- Sets status back to "completed" or "draft"

### 6.2 Reopening Drafts

**When Reports can be Reopened:**
- Report status is "draft" or "completed"
- Case status allows editing (not approved/rejected)
- User has `cases:complete` permission

**Reopening Flow:**
1. User opens case report
2. If status is "completed", show "Edit Report" button
3. On click, set status to "draft"
4. Enable editing
5. Create history entry

## 7. PDF/Print Export

### 7.1 PDF Generation

**Endpoint: `GET /api/cases/:id/report/pdf`**

**Features:**
- Official MoF report format
- RTL layout
- All sections included
- Calculated totals
- Signatures section
- Watermark for drafts
- Page numbers
- Header/Footer with case info

**PDF Structure:**
1. Cover Page (Case info, dates, status)
2. Section 1: Entity Details
3. Section 2: Extractions (with tables)
4. Section 3: Findings & Recommendations
5. Section 4: Supporting Documents (checklist)
6. Section 6: Approval & Signatures

**Technology:**
- Use `pdfkit` library (already in dependencies)
- RTL text support via `pdfkit-rtl` or custom implementation
- Persian font embedding
- Table generation for financial data

### 7.2 Print-Ready View

**Component: `CaseReportPrintView`**
- Full-width layout
- No navigation/buttons
- Print-optimized styling
- RTL layout
- All sections visible
- Page breaks at appropriate points

**Print CSS:**
- Hide UI elements
- Show only report content
- Optimize for A4 paper
- Proper margins
- Page break controls

## 8. UI/UX Design

### 8.1 Form Layout

**Structure:**
- Tabbed interface for sections
- Progress indicator showing completion status
- Section-by-section navigation
- "Mark Section Complete" button per section
- Overall completion percentage

**RTL Considerations:**
- All text RTL-aligned
- Form fields RTL (text-align: right)
- Numbers RTL-formatted (Persian digits option)
- Date pickers RTL
- Tables RTL (header on right)
- Buttons positioned for RTL (Cancel on right, Save on left)

### 8.2 Professional Layout

**Header:**
- Official MoF logo (if available)
- Report title: "گزارش بررسی قضیه"
- Case ID and number
- Date and status

**Section Cards:**
- Each section in a card
- Section title with icon
- Completion indicator
- Collapsible for long sections
- Validation errors shown inline

**Form Fields:**
- Consistent spacing
- Clear labels
- Help text where needed
- Required field indicators (*)
- Validation messages below fields
- Success indicators for completed sections

### 8.3 Autosave Indicators

**Visual Feedback:**
- "در حال ذخیره..." - While saving
- "ذخیره شد" - After successful save (fades after 3s)
- "خطا در ذخیره" - On error (with retry button)
- Last saved timestamp

**Location:**
- Top-right of form (RTL: top-left)
- Non-intrusive
- Auto-hide after success

### 8.4 Validation Feedback

**Inline Validation:**
- Red border on invalid fields
- Error message below field
- Success checkmark on valid fields
- Warning icon for warnings

**Section-Level:**
- Section completion badge
- List of missing fields
- "Complete Section" button (disabled until valid)

**Report-Level:**
- Overall completion percentage
- List of incomplete sections
- "Complete Report" button (disabled until all sections valid)

## 9. API Contracts

### 9.1 Report Endpoints

**GET `/api/cases/:id/report`**
- Returns full report data (draft or completed)
- Auto-populates from case/entity/documents
- Includes completion status per section

**POST `/api/cases/:id/report/draft`**
- Saves draft (partial data allowed)
- Creates history entry
- Returns updated report

**POST `/api/cases/:id/report/section/:sectionId`**
- Saves specific section
- Validates section
- Returns section completion status

**POST `/api/cases/:id/report/complete`**
- Marks report as completed
- Validates all sections
- Locks report if case is approved/rejected
- Returns validation result

**POST `/api/cases/:id/report/validate`**
- Validates report or section
- Returns errors and warnings
- Returns completion status

**GET `/api/cases/:id/report/history`**
- Returns report change history
- Includes versions and snapshots

**GET `/api/cases/:id/report/pdf`**
- Generates and returns PDF
- Includes all sections
- Official format

**POST `/api/cases/:id/report/unlock`** (Admin only)
- Unlocks locked report
- Requires `users:manage` permission
- Creates audit log

### 9.2 Response Formats

**Report Data Response:**
```json
{
  "id": "report-123",
  "caseId": "case-456",
  "status": "draft",
  "version": 3,
  "sections": {
    "section_1": {
      "complete": true,
      "lastUpdated": "2024-01-15T10:00:00Z"
    },
    "section_2": {
      "complete": false,
      "lastUpdated": "2024-01-15T09:30:00Z"
    }
  },
  "data": {
    // All report fields
  },
  "completion": {
    "percentage": 60,
    "sectionsComplete": 3,
    "sectionsTotal": 5
  }
}
```

## 10. Acceptance Criteria

### 10.1 Core Functionality

✅ **AC1:** Auditor cannot complete case without valid report
- Validation blocks case completion if report is invalid
- All required sections must be complete
- All required fields must be filled

✅ **AC2:** Report saved atomically with case completion
- Report status set to "completed" when case is completed
- Report locked when case is approved/rejected
- Transaction ensures data consistency

✅ **AC3:** Full report retrievable through API
- `GET /api/cases/:id/report` returns complete report
- All sections included
- Auto-populated data included

### 10.2 Draft & Autosave

✅ **AC4:** Draft reports can be saved partially
- User can save report with incomplete sections
- Autosave works after 2 seconds of inactivity
- Draft status allows editing

✅ **AC5:** Completed reports can be reopened
- "Edit Report" button available for completed reports
- Status changes to "draft" on edit
- History entry created

✅ **AC6:** Locked reports cannot be edited
- Form fields read-only when locked
- Save buttons disabled
- Clear indication of locked status

### 10.3 Validation

✅ **AC7:** Field-level validation works
- Required fields validated
- Data types validated
- Formats validated (email, phone, etc.)

✅ **AC8:** Section-level validation works
- Sections validated independently
- Completion status tracked per section
- Missing fields identified

✅ **AC9:** Report-level validation works
- All sections validated together
- Cross-section validation (totals, dates)
- Business rules enforced

### 10.4 PDF Export

✅ **AC10:** PDF export generates official format
- Matches MoF report format
- All sections included
- RTL layout correct
- Calculated totals included

✅ **AC11:** Print view is optimized
- Print CSS hides UI elements
- Proper page breaks
- A4 paper size optimized

### 10.5 RTL Accuracy

✅ **AC12:** 100% RTL accurate
- All text RTL-aligned
- Form fields RTL
- Numbers RTL-formatted
- Date pickers RTL
- Tables RTL
- Buttons positioned for RTL

### 10.6 Database

✅ **AC13:** Structured schema supports all sections
- All fields stored in `case_reports_v2`
- Calculated fields use generated columns
- History tracked in `case_report_history`

✅ **AC14:** Migration preserves existing data
- Existing reports migrated to new schema
- No data loss
- Backward compatibility maintained

## 11. Implementation Plan

### 11.1 Phase 1: Database & Backend
1. Create migration for `case_reports_v2` and `case_report_history`
2. Migrate existing data
3. Update storage methods
4. Create new API endpoints
5. Implement validation service
6. Implement PDF generation

### 11.2 Phase 2: Frontend Components
1. Create structured form components
2. Implement section navigation
3. Implement autosave
4. Implement validation UI
5. Create PDF export component
6. Create print view

### 11.3 Phase 3: Integration & Testing
1. Integrate with case completion flow
2. Test all validation rules
3. Test autosave
4. Test PDF generation
5. Test RTL layout
6. End-to-end testing

## 12. Security Considerations

### 12.1 Access Control
- Report viewing requires `cases:view`
- Report editing requires `cases:complete`
- Report unlocking requires `users:manage`
- PDF export requires `cases:view`

### 12.2 Data Validation
- All inputs validated server-side
- SQL injection prevention
- XSS prevention in text fields
- File upload validation for documents

### 12.3 Audit Trail
- All report changes logged
- History table tracks all versions
- Audit logs for status changes
- Unlock actions logged

## 13. Performance Considerations

### 13.1 Autosave Optimization
- Debounce autosave requests
- Send only changed fields
- Batch multiple field changes
- Queue saves if network slow

### 13.2 PDF Generation
- Generate PDFs asynchronously
- Cache generated PDFs
- Stream large PDFs
- Optimize image compression

### 13.3 Database Queries
- Index on `case_id` and `status`
- Use JSONB indexes for document arrays
- Optimize history queries
- Paginate history if needed

## 14. Future Enhancements

### 14.1 Advanced Features
- Report templates
- Custom fields per case type
- Multi-language support
- Digital signatures
- Report comparison (diff view)

### 14.2 Integration
- Export to Excel
- Integration with MoF systems
- Automated report submission
- Report analytics dashboard

