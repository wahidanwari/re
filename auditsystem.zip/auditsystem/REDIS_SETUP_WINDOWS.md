# Redis Setup for Windows

The Entity Import feature requires Redis for background job processing. Here are several ways to install and run Redis on Windows:

## Option 1: Memurai (Recommended for Windows)

Memurai is a Redis-compatible server for Windows:

1. Download from: https://www.memurai.com/get-memurai
2. Install the MSI package
3. Redis will run as a Windows service automatically
4. Default port: 6379 (same as Redis)

## Option 2: WSL (Windows Subsystem for Linux)

If you have WSL installed:

```bash
# Install WSL if not already installed
wsl --install

# In WSL terminal, install Redis
sudo apt-get update
sudo apt-get install redis-server

# Start Redis
sudo service redis-server start

# Or run in foreground for testing
redis-server
```

## Option 3: Docker (Recommended if you have Docker)

```bash
# Run Redis in Docker container
docker run -d -p 6379:6379 --name redis redis:alpine

# Check if running
docker ps

# Stop Redis
docker stop redis

# Start Redis
docker start redis
```

## Option 4: Chocolatey Package Manager

If you have Chocolatey installed:

```powershell
# Install Redis via Chocolatey
choco install redis-64

# Start Redis service
Start-Service redis
```

## Option 5: Manual Installation (Legacy)

1. Download Redis for Windows from: https://github.com/microsoftarchive/redis/releases
2. Download the latest `.msi` file
3. Install it
4. Redis will run as a Windows service

## Verify Redis is Running

After installation, verify Redis is accessible:

```powershell
# Test connection (if redis-cli is available)
redis-cli ping
# Should return: PONG

# Or check if port 6379 is listening
netstat -an | findstr 6379
```

## Environment Variables

You can configure Redis connection in your `.env` file:

```env
REDIS_HOST=localhost
REDIS_PORT=6379
REDIS_PASSWORD=  # Leave empty if no password
```

## Troubleshooting

### Redis not starting

1. **Check if port 6379 is already in use:**
   ```powershell
   netstat -ano | findstr :6379
   ```

2. **Check Windows Firewall:**
   - Allow port 6379 through Windows Firewall if needed

3. **Check Redis logs:**
   - Look for Redis log files in the installation directory
   - Usually in `C:\Program Files\Redis\` or similar

### Connection refused errors

- Ensure Redis is actually running
- Check `REDIS_HOST` and `REDIS_PORT` in `.env`
- Try connecting with `redis-cli` to test

### For Development Only

If you just want to test the import feature without Redis, you can temporarily modify the code to process imports synchronously (not recommended for production).

## Quick Start (Docker - Easiest)

If you have Docker installed, this is the quickest way:

```bash
docker run -d -p 6379:6379 --name redis redis:alpine
```

That's it! Redis will be running on `localhost:6379`.

