# Case Management Enhancements - Implementation Summary

## Overview
This document summarizes the production-grade fixes and enhancements implemented for the Audit System case management module.

## Database Changes

### Migration: `migrations/027_case_management_enhancements.sql`

#### Cases Table Extensions
- `assigned_by` (VARCHAR) - User who assigned the case
- `assigned_at` (TIMESTAMP) - When the case was assigned
- `institution_info_original` (TEXT) - Original extracted institution information
- `institution_info_manual` (TEXT) - Manual override value
- `institution_info_overridden_by` (VARCHAR) - Who overrode the value
- `institution_info_overridden_at` (TIMESTAMP) - When it was overridden
- `representative_name_manual` (VARCHAR) - Manual override for representative name
- `representative_phone_manual` (VARCHAR) - Manual override for representative phone
- `institution_address_manual` (TEXT) - Manual override for institution address
- `reopened_by` (VARCHAR) - User who reopened the case
- `reopened_at` (TIMESTAMP) - When the case was reopened
- `reopen_reason` (TEXT) - Reason for reopening

#### New Tables

1. **case_metrics** - Senior auditor reporting metrics per case
   - `installments_this_month` (INTEGER)
   - `nonresponsive_count` (INTEGER)
   - `incoming_documents`, `outgoing_documents` (INTEGER)
   - `incoming_inquiries`, `outgoing_inquiries` (INTEGER)
   - `remarks` (TEXT)
   - `last_updated_by`, `last_updated_at`

2. **installment_payments** - Individual installment payment records
   - `case_id`, `taxpayer_id`
   - `payment_date`, `month_reference` (e.g., 'ثور', 'جوزا')
   - `amount` (NUMERIC)
   - `created_by`, `created_at`

3. **case_flags** - Case flags and events
   - `case_id`, `type` (nonresponsive_attempt, nonresponsive_mark, escalation_to_enforcement, etc.)
   - `details` (JSONB)
   - `created_by`, `created_at`

4. **case_section_status** - Tracks section completion per case
   - `case_id`, `section_id` (section_1, section_2, etc.)
   - `is_completed`, `completed_by`, `completed_at`

#### Status Updates
Added new status values:
- `عدم پاسخگو` (nonresponsive)
- `ارسال‌ شده به تنفیذ قانون` (referred_to_enforcement)

## Schema Updates (`shared/schema.ts`)

### New Types and Enums
- `CaseStatusKey` - English keys for internal logic
- `statusKeyToLabel` - Mapping from keys to Dari labels
- New table definitions: `caseMetrics`, `installmentPayments`, `caseFlags`, `caseSectionStatus`
- Type exports for all new tables

## Backend Changes

### Storage Layer (`server/storage.ts`)

#### New Methods
- `assignCaseToUserWithMetadata()` - Atomic assignment with status update and metadata
- `getCaseMetrics()`, `upsertCaseMetrics()` - Metrics management
- `getInstallmentPayments()`, `createInstallmentPayment()`, `deleteInstallmentPayment()`
- `getCaseFlags()`, `createCaseFlag()`
- `getCaseSectionStatus()`, `getCaseSectionStatusBySection()`, `upsertCaseSectionStatus()`

### API Endpoints (`server/routes/cases.ts`)

#### Enhanced Endpoints

1. **POST /api/cases/:id/assign** (Enhanced)
   - Now uses `assignCaseToUserWithMetadata()` for atomic updates
   - Status automatically changes to "در جریان بررسی"
   - Records `assignedBy` and `assignedAt`
   - Returns assigned user display name in response

2. **GET /api/cases/:id** (Enhanced)
   - Now includes:
     - `assignedUser` - Full name and audit ID of assigned auditor
     - `assignedByUser` - Full name and audit ID of user who assigned
     - `metrics` - Case metrics object
     - `installments` - Array of installment payments
     - `flags` - Array of case flags
     - `sectionStatuses` - Array of section completion statuses

#### New Endpoints

1. **POST /api/cases/:id/sections/:sectionId/complete**
   - Auth: auditor or senior_auditor
   - Marks a specific section as completed
   - Section-scoped validation (validates only fields in that section)
   - Creates audit log entry

2. **POST /api/cases/:id/metrics**
   - Auth: senior_auditor or admin only
   - Updates or creates case metrics
   - Fields: `installments_this_month`, `nonresponsive_count`, `incoming_documents`, `outgoing_documents`, `incoming_inquiries`, `outgoing_inquiries`, `remarks`
   - Logs all changes with old/new values

3. **POST /api/cases/:id/installments**
   - Auth: auditor or senior_auditor
   - Creates an installment payment record
   - Automatically updates `installments_this_month` in metrics
   - Body: `payment_date`, `month_reference`, `amount`, `taxpayer_id` (optional)

4. **POST /api/cases/:id/flags**
   - Auth: auditor or senior_auditor
   - Creates a case flag/event
   - Types: `nonresponsive_attempt`, `nonresponsive_mark`, `escalation_to_enforcement`, etc.
   - Special handling:
     - `nonresponsive_mark` → sets case status to "عدم پاسخگو"
     - `escalation_to_enforcement` → sets case status to "ارسال‌ شده به تنفیذ قانون"

5. **POST /api/cases/:id/reopen**
   - Auth: senior_auditor or admin only
   - Reopens a completed case
   - Sets status back to "در جریان بررسی"
   - Records `reopenedBy`, `reopenedAt`, `reopenReason`
   - Preserves completion history

6. **PATCH /api/cases/:id** (Enhanced)
   - Now handles override fields:
     - `institution_info_manual`
     - `representative_name_manual`
     - `representative_phone_manual`
     - `institution_address_manual`
   - Records override metadata (who/when)
   - Logs all override changes

## Frontend Changes (TODO)

### Assignment UI
- [ ] Update assignment dialog to show assigned auditor name immediately after assignment
- [ ] Display "بررس اختصاص داده شده" column in case table with auditor name or "نامشخص"
- [ ] Show loading spinner during assignment
- [ ] Disable duplicate assignments while request is pending

### Override Fields UI
- [ ] For fields: "اطلاعات نهاد", "نماینده", "شماره تماس نماینده", "آدرس نهاد":
  - Display original extracted value with label "مقدار استخراج‌شده: <value>"
  - Add "ویرایش" button to toggle editable input
  - After save, show manual value with badge "مقدار بازگشتی: ویرایش شده توسط <name> در <timestamp>"
  - Only show for auditor or senior_auditor roles

### Section Navigation & Validation
- [ ] Update form to validate only current section when clicking "Next"
- [ ] Map server validation errors to specific fields in current section
- [ ] Allow progression if only current section is valid (don't block on later sections)

### Complete Case Flow
- [ ] Update completion to call POST /api/cases/:id/complete
- [ ] Display field-level validation errors from server
- [ ] Show success message with completedBy/completedAt
- [ ] Update case row status immediately

### Senior Metrics Panel
- [ ] Add "آمار و گزارش ویژه بازرس ارشد" panel in case detail sidebar
- [ ] Visible only to senior_auditor role
- [ ] Display ministry fields and metrics
- [ ] Allow inline editing with confirmation modal
- [ ] Show history of metric edits (who/when, old/new values)

### Installment Payments UI
- [ ] Add modal/form to record installment payment
- [ ] Month selection with local month names (ثور, جوزا, etc.)
- [ ] Payment date and amount inputs
- [ ] On save, create payment and update aggregates
- [ ] Display list of payments in case detail

### Non-responsive Workflow UI
- [ ] Add "عدم پاسخگو" action in case detail timeline
- [ ] Modal to record attempt counts, notes, next attempt date
- [ ] Increment attempts counter and add flag entry
- [ ] Senior escalation: "ارسال‌ شده به تنفیذ قانون" button
- [ ] Confirmation modal: "ارسال‌ شده به تنفیذ قانون — این عملیات قابل بازگشت نیست. آیا ادامه می‌دهید؟"

### Reopen & Editing After Completion
- [ ] Add "ویرایش گزارش تکمیل‌شده (بازکردن برای ویرایش)" button for senior
- [ ] Add "ویرایش آمار ارشد" button for senior (edit metrics without full reopen)
- [ ] Reopen confirmation with reason input
- [ ] Update UI to show case is editable again after reopen

## Validation Rules

### Section-Scoped Validation
- Each form field has metadata representing its section ID
- Only fields in current section are validated on section completion
- Server accepts partial section saves

### Completion Validation
- Full validation across all sections plus mandatory override fields
- Server returns structured errors: `{ errors: [{ field: "fieldName", message: "..." }] }`
- Override fields validated if required for completion

## Authorization

### Role Permissions
- **senior_auditor**: Can assign, edit metrics, reopen cases, refer to enforcement, edit manual override fields, edit after completion
- **auditor**: Can edit data for assigned cases, log installment payments, mark nonresponsive attempts, progress sections, request completion
- **admin**: Full permissions for all actions

All permissions enforced on backend endpoints.

## Audit Logging

All actions logged to `audit_logs` table:
- Assignment (with assignedBy, assignedAt)
- Completion (with completedBy, completedAt)
- Reopen (with reopenedBy, reopenedAt, reason)
- Override field changes (with old/new values, who/when)
- Metric changes (with old/new values)
- Installment payment creation
- Nonresponsive marking and escalation

Each log entry includes:
- `actor_id` (userId)
- `case_id`
- `action_type`
- `timestamp`
- `old_value`, `new_value` (in details JSONB)
- `reason` (optional, in details)

## Concurrency & Safety

- DB transactions and row locks for assignment and completion operations
- Optimistic concurrency for metrics updates (version or last_updated_at)
- Conflict errors returned with current values if update conflicts occur

## Testing Requirements

### Unit Tests
- Assignment flow (atomic status update, metadata recording)
- Section-scoped validation
- Override field persistence
- Metrics updates
- Installment payment creation and aggregation

### Integration Tests
- Complete case flow with validation
- Reopen flow
- Nonresponsive marking and escalation
- Authorization checks (auditor cannot perform senior-only actions)

### E2E Tests
- Assignment UI updates table instantly
- Override fields show original value and allow manual edit
- Per-section Next validates only that section
- Mark complete works and changes status
- Senior metrics visible and editable only by senior
- Installment payments recorded and aggregated
- Nonresponsive flag increases attempts and history
- Reopen returns case to editable state

## Deployment Plan

### Migration Order
1. Run migration `027_case_management_enhancements.sql`
   - Adds nullable columns first
   - Creates new tables
   - Backfills `institution_info_original` from entities where possible
   - Adds constraints

2. Deploy backend
   - Backend tolerates new columns (nullable)
   - New endpoints available but not yet used by frontend

3. Deploy frontend
   - UI features enabled
   - Gradual rollout recommended

### Rollback Steps
1. Revert frontend deployment
2. Revert backend deployment
3. Migration rollback (if needed):
   ```sql
   -- Drop new tables
   DROP TABLE IF EXISTS case_section_status;
   DROP TABLE IF EXISTS case_flags;
   DROP TABLE IF EXISTS installment_payments;
   DROP TABLE IF EXISTS case_metrics;
   
   -- Remove new columns from cases
   ALTER TABLE cases DROP COLUMN IF EXISTS reopen_reason;
   ALTER TABLE cases DROP COLUMN IF EXISTS reopened_at;
   ALTER TABLE cases DROP COLUMN IF EXISTS reopened_by;
   ALTER TABLE cases DROP COLUMN IF EXISTS institution_address_manual;
   ALTER TABLE cases DROP COLUMN IF EXISTS representative_phone_manual;
   ALTER TABLE cases DROP COLUMN IF EXISTS representative_name_manual;
   ALTER TABLE cases DROP COLUMN IF EXISTS institution_info_overridden_at;
   ALTER TABLE cases DROP COLUMN IF EXISTS institution_info_overridden_by;
   ALTER TABLE cases DROP COLUMN IF EXISTS institution_info_manual;
   ALTER TABLE cases DROP COLUMN IF EXISTS institution_info_original;
   ALTER TABLE cases DROP COLUMN IF EXISTS assigned_at;
   ALTER TABLE cases DROP COLUMN IF EXISTS assigned_by;
   ```

## QA Checklist

### Assignment Flow
- [ ] Senior assigns case → status updates to "در جریان بررسی"
- [ ] Assigned auditor name appears in table immediately
- [ ] Audit log entry created with assignedBy and assignedAt
- [ ] Response includes assigned user display name

### Override Fields
- [ ] Original extracted values displayed
- [ ] Manual override fields editable
- [ ] Override metadata (who/when) recorded and displayed
- [ ] History preserved (original values not overwritten)

### Section Validation
- [ ] Moving from section 2→3 only validates section 2 fields
- [ ] Later section errors don't block current section progression
- [ ] Server returns section-scoped validation errors

### Complete Case Flow
- [ ] Server-side validation runs on completion
- [ ] Status changes to "تکمیل شده" if valid
- [ ] Field-level errors returned if invalid
- [ ] completedBy and completedAt set correctly

### Senior Metrics
- [ ] Metrics panel visible only to senior_auditor
- [ ] Metrics editable at any time (including after completion)
- [ ] Changes logged with old/new values
- [ ] Metrics included in exports

### Installment Payments
- [ ] Payments can be logged
- [ ] Aggregates update automatically
- [ ] Payment history visible in case detail

### Non-responsive Workflow
- [ ] Attempts tracked and incremented
- [ ] Marking as non-responsive sets status
- [ ] Escalation sets status to "ارسال‌ شده به تنفیذ قانون"
- [ ] All actions logged

### Reopen Flow
- [ ] Senior can reopen completed cases
- [ ] Status reverts to "در جریان بررسی"
- [ ] Reopen reason recorded
- [ ] History preserved

### Authorization
- [ ] Auditor cannot perform senior-only actions (403 errors)
- [ ] Senior can perform all senior actions
- [ ] Admin has full access

## API Documentation

### POST /api/cases/:id/assign
**Request:**
```json
{
  "userId": "user-id-here"
}
```

**Response:**
```json
{
  "id": "case-id",
  "caseId": "CASE-001",
  "assignedTo": "user-id",
  "assignedBy": "senior-user-id",
  "assignedAt": "2025-01-XX...",
  "status": "در جریان بررسی",
  "assignedUser": {
    "id": "user-id",
    "fullName": "نام بررس",
    "auditId": "AUDIT-001"
  }
}
```

### POST /api/cases/:id/metrics
**Request:**
```json
{
  "installments_this_month": 5,
  "nonresponsive_count": 2,
  "incoming_documents": 10,
  "outgoing_documents": 8,
  "incoming_inquiries": 3,
  "outgoing_inquiries": 2,
  "remarks": "ملاحظات..."
}
```

### POST /api/cases/:id/installments
**Request:**
```json
{
  "payment_date": "2025-01-15",
  "month_reference": "ثور",
  "amount": 100000,
  "taxpayer_id": "optional-id"
}
```

### POST /api/cases/:id/flags
**Request:**
```json
{
  "type": "nonresponsive_mark",
  "details": {
    "attempts": 3,
    "notes": "عدم پاسخ به سه تماس"
  }
}
```

### POST /api/cases/:id/reopen
**Request:**
```json
{
  "reason": "نیاز به بررسی بیشتر"
}
```

### PATCH /api/cases/:id (Override Fields)
**Request:**
```json
{
  "institution_info_manual": "اطلاعات جدید",
  "representative_name_manual": "نام نماینده",
  "representative_phone_manual": "0791234567",
  "institution_address_manual": "آدرس جدید"
}
```

## Notes

- All UI text is in Dari
- Status keys stored in English internally, mapped to Dari labels in UI
- Original extracted values are immutable
- All changes are auditable
- Zero-downtime migration approach used

## Next Steps

1. Complete frontend implementation for all UI components
2. Write comprehensive test suite
3. Perform QA testing using checklist
4. Deploy following migration order
5. Monitor for issues and gather feedback

