# Deployment Guide - Audit System
## Offline LAN Server Installation

This guide provides step-by-step instructions for deploying the Audit System on an offline LAN server without Docker or Nginx.

---

## Table of Contents

1. [Prerequisites](#prerequisites)
2. [Server Requirements](#server-requirements)
3. [Installation Steps](#installation-steps)
4. [Database Setup](#database-setup)
5. [Application Configuration](#application-configuration)
6. [Building and Deploying](#building-and-deploying)
7. [Starting the Application](#starting-the-application)
8. [Initial Setup](#initial-setup)
9. [Verification](#verification)
10. [Troubleshooting](#troubleshooting)
11. [Optional Enhancements](#optional-enhancements)

---

## Prerequisites

### Software Requirements

- **Operating System**: Windows Server 2016+, Linux (Ubuntu 20.04+), or macOS 12+
- **Node.js**: Version 18.x or higher
- **PostgreSQL**: Version 12 or higher
- **Git**: For cloning the repository (or manual file transfer)

### Network Requirements

- Server accessible on LAN
- Static IP address recommended
- Firewall configured to allow HTTP/HTTPS traffic on chosen port

---

## Server Requirements

### Minimum Hardware

- **CPU**: 2 cores
- **RAM**: 4 GB
- **Storage**: 20 GB free space
- **Network**: 100 Mbps LAN connection

### Recommended Hardware

- **CPU**: 4+ cores
- **RAM**: 8 GB
- **Storage**: 50 GB free space (for documents and backups)
- **Network**: 1 Gbps LAN connection

---

## Installation Steps

### 1. Prepare the Server

#### Windows Server

1. Install Node.js from [nodejs.org](https://nodejs.org/)
   - Choose LTS version (18.x or higher)
   - Add to PATH during installation
   - Verify: `node --version` and `npm --version`

2. Install PostgreSQL from [postgresql.org](https://www.postgresql.org/download/windows/)
   - Choose version 12 or higher
   - Set a strong password for `postgres` user
   - Note the port (default: 5432)

3. Install Git from [git-scm.com](https://git-scm.com/download/win)
   - Or download ZIP file and extract manually

#### Linux (Ubuntu/Debian)

```bash
# Update package list
sudo apt-get update

# Install Node.js 18.x
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs

# Install PostgreSQL
sudo apt-get install -y postgresql postgresql-contrib

# Install Git
sudo apt-get install -y git

# Verify installations
node --version
npm --version
psql --version
```

#### macOS

```bash
# Install Homebrew if not installed
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

# Install Node.js
brew install node@18

# Install PostgreSQL
brew install postgresql@12
brew services start postgresql@12

# Install Git (usually pre-installed)
git --version
```

### 2. Transfer Application Files

#### Option A: Using Git (if network allows)

```bash
git clone <repository-url> /path/to/auditsystem
cd /path/to/auditsystem
```

#### Option B: Manual File Transfer

1. Zip the project directory on a development machine
2. Transfer to server (USB drive, network share, etc.)
3. Extract to desired location, e.g., `C:\auditsystem` (Windows) or `/opt/auditsystem` (Linux)

### 3. Install Node.js Dependencies

```bash
cd /path/to/auditsystem

# Install all dependencies
npm install --production
```

**Note**: If `npm install` fails due to missing native modules, you may need to install build tools:

- **Windows**: Install "Visual Studio Build Tools" or "Windows Build Tools"
- **Linux**: `sudo apt-get install -y build-essential python3`
- **macOS**: Install Xcode Command Line Tools: `xcode-select --install`

---

## Database Setup

### 1. Create PostgreSQL Database

```bash
# Connect to PostgreSQL as superuser
psql -U postgres

# In PostgreSQL prompt, create database and user
CREATE DATABASE audit_system;
CREATE USER audit_user WITH PASSWORD 'CHANGE_THIS_STRONG_PASSWORD';
GRANT ALL PRIVILEGES ON DATABASE audit_system TO audit_user;

# For schema operations
\c audit_system
GRANT ALL ON SCHEMA public TO audit_user;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON TABLES TO audit_user;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON SEQUENCES TO audit_user;

# Exit PostgreSQL
\q
```

**Security Note**: Replace `CHANGE_THIS_STRONG_PASSWORD` with a strong password.

### 2. Run Database Migrations

```bash
cd /path/to/auditsystem

# Set DATABASE_URL environment variable
# Windows (PowerShell):
$env:DATABASE_URL="postgresql://audit_user:CHANGE_THIS_STRONG_PASSWORD@localhost:5432/audit_system"

# Linux/macOS:
export DATABASE_URL="postgresql://audit_user:CHANGE_THIS_STRONG_PASSWORD@localhost:5432/audit_system"

# Run migrations
npm run db:migrate-rbac

# Run additional migrations
psql $DATABASE_URL -f migrations/002_add_case_completed_by.sql
psql $DATABASE_URL -f migrations/003_add_permissions_version.sql
psql $DATABASE_URL -f migrations/004_production_indexes.sql
```

### 3. Create Initial Admin User

```bash
# Seed admin user (will prompt for password or use default)
npm run db:seed
```

Or manually create admin user:

```bash
# Connect to database
psql $DATABASE_URL

# Insert admin user (password will be hashed automatically)
# Password: admin123 (CHANGE IMMEDIATELY after first login)
INSERT INTO users (audit_id, password, full_name, role, is_active, must_change_password)
VALUES ('ADMIN001', '$2a$10$...', 'System Administrator', 'system_admin', true, true);
```

---

## Application Configuration

### 1. Create Environment File

Create `.env` file in project root:

```bash
# Database Configuration
DATABASE_URL=postgresql://audit_user:CHANGE_THIS_STRONG_PASSWORD@localhost:5432/audit_system

# Server Configuration
PORT=3000
HOST=0.0.0.0  # Listen on all interfaces, or use specific IP for LAN access
NODE_ENV=production

# Session Configuration
SESSION_SECRET=GENERATE_A_RANDOM_SECRET_HERE_MIN_32_CHARACTERS
SESSION_TIMEOUT=1800000  # 30 minutes in milliseconds
SLIDING_EXPIRATION=true

# Backup Configuration
BACKUP_DIR=./backups
BACKUP_ENCRYPTION_KEY=GENERATE_A_32_BYTE_HEX_KEY_HERE

# Security (Optional - for HTTPS)
# HTTPS_PORT=443
# SSL_CERT_PATH=/path/to/cert.pem
# SSL_KEY_PATH=/path/to/key.pem
```

**Security Notes**:
- Generate `SESSION_SECRET`: Use `openssl rand -hex 32` (Linux/macOS) or PowerShell: `[System.Convert]::ToBase64String([System.Security.Cryptography.RandomNumberGenerator]::GetBytes(32))`
- Generate `BACKUP_ENCRYPTION_KEY`: Use `openssl rand -hex 32` (Linux/macOS) or similar

### 2. Configure Server IP

Edit `.env` file and set `HOST` to:
- `0.0.0.0` - Listen on all interfaces (default)
- Specific IP address - Listen on specific interface (e.g., `192.168.1.100`)

---

## Building and Deploying

### 1. Build the Application

```bash
cd /path/to/auditsystem

# Build frontend and backend
npm run build
```

This will:
- Build the React frontend (`client/`) into `dist/public/`
- Bundle the Express backend (`server/`) into `dist/index.js`

### 2. Verify Build Output

Check that these files exist:
- `dist/index.js` - Backend server bundle
- `dist/public/index.html` - Frontend HTML
- `dist/public/assets/` - Frontend JavaScript and CSS

### 3. Create Required Directories

```bash
# Create directories for documents and backups
mkdir -p docvault
mkdir -p backups

# Set permissions (Linux/macOS)
chmod 755 docvault backups
```

---

## Starting the Application

### Option 1: Direct Start (Development/Testing)

```bash
cd /path/to/auditsystem

# Load environment variables
# Windows (PowerShell):
Get-Content .env | ForEach-Object { $line = $_ -split '='; Set-Item -Path "env:$($line[0])" -Value $($line[1]) }

# Linux/macOS:
export $(cat .env | xargs)

# Start server
npm start
```

### Option 2: Using PM2 (Recommended for Production)

```bash
# Install PM2 globally
npm install -g pm2

# Start application with PM2
pm2 start dist/index.js --name audit-system

# Save PM2 configuration
pm2 save

# Setup PM2 to start on system boot
pm2 startup
# Follow the instructions provided by PM2

# View logs
pm2 logs audit-system

# Monitor application
pm2 monit
```

### Option 3: Windows Service (Windows Server)

1. Install `node-windows`:
   ```bash
   npm install -g node-windows
   ```

2. Create service script (`install-service.js`):
   ```javascript
   const Service = require('node-windows').Service;
   const svc = new Service({
     name: 'Audit System',
     description: 'Audit System Web Application',
     script: require('path').join(__dirname, 'dist/index.js'),
     env: [{
       name: "NODE_ENV",
       value: "production"
     }]
   });
   
   svc.on('install', () => { svc.start(); });
   svc.install();
   ```

3. Run service installation:
   ```bash
   node install-service.js
   ```

---

## Initial Setup

### 1. Access the Application

Open a web browser and navigate to:
- `http://SERVER_IP:3000` (replace `SERVER_IP` with actual server IP)
- Or `http://localhost:3000` if accessing from server itself

### 2. First Login

1. Login with admin credentials:
   - **Audit ID**: `ADMIN001` (or the one you created)
   - **Password**: (The password set during seeding)

2. **IMPORTANT**: Change admin password immediately after first login

### 3. Configure System Settings

1. Navigate to Settings page
2. Configure:
   - System name
   - Default language (Dari/Pashto)
   - Session timeout
   - Password policy
   - Email/notification settings (if applicable)

### 4. Create User Groups

1. Navigate to Groups page
2. Create groups for your organization structure
3. Assign users to groups

### 5. Create Users

1. Navigate to Users page
2. Create users for each group
3. Assign roles (Auditor, Senior Auditor, Director)
4. Assign permission packages if needed (Acting Coordinator, Approval Authority)

---

## Verification

### 1. Health Check

```bash
# Check health endpoint
curl http://SERVER_IP:3000/api/health

# Should return:
# {
#   "status": "healthy",
#   "checks": {
#     "server": "ok",
#     "database": "ok"
#   }
# }
```

### 2. Test Login

1. Open application in browser
2. Login with a test user
3. Verify:
   - Dashboard loads correctly
   - Permissions are enforced
   - Navigation works
   - RTL (Dari/Pashto) display works

### 3. Test Backup

```bash
# Create a backup (requires admin authentication)
# Use a tool like Postman or curl with session cookie
curl -X POST http://SERVER_IP:3000/api/backup/create \
  -H "Cookie: audit.sid=YOUR_SESSION_COOKIE" \
  -H "Content-Type: application/json"

# List backups
curl http://SERVER_IP:3000/api/backup/list \
  -H "Cookie: audit.sid=YOUR_SESSION_COOKIE"
```

---

## Troubleshooting

### Common Issues

#### 1. Application Won't Start

**Error**: `Port 3000 is already in use`

**Solution**:
- Change `PORT` in `.env` file
- Or stop the process using port 3000:
  - Windows: `netstat -ano | findstr :3000`, then `taskkill /PID <PID> /F`
  - Linux: `sudo lsof -i :3000`, then `kill -9 <PID>`

#### 2. Database Connection Failed

**Error**: `Connection refused` or `authentication failed`

**Solution**:
- Verify PostgreSQL is running:
  - Windows: Check Services
  - Linux: `sudo systemctl status postgresql`
  - macOS: `brew services list`
- Verify `DATABASE_URL` in `.env` file is correct
- Verify database user has correct permissions

#### 3. Build Fails

**Error**: `Module not found` or build errors

**Solution**:
- Ensure all dependencies are installed: `npm install`
- Clear cache: `npm cache clean --force`
- Delete `node_modules` and `dist`, then reinstall: `rm -rf node_modules dist && npm install`

#### 4. Frontend Not Loading

**Error**: Blank page or 404 errors

**Solution**:
- Verify build completed successfully
- Check that `dist/public/index.html` exists
- Verify server is serving static files correctly
- Check browser console for errors

#### 5. Session Not Persisting

**Solution**:
- Verify `SESSION_SECRET` is set in `.env`
- Check that cookies are enabled in browser
- Verify session table exists in database
- Check browser console for cookie errors

#### 6. Permission Errors

**Solution**:
- Verify RBAC migrations ran successfully
- Check user roles and packages in database
- Verify permissions are calculated correctly
- Check audit logs for permission denials

---

## Optional Enhancements

### 1. HTTPS/SSL (Recommended for Production)

#### Option A: Self-Signed Certificate (Testing)

```bash
# Generate self-signed certificate
openssl req -x509 -newkey rsa:4096 -keyout key.pem -out cert.pem -days 365 -nodes

# Add to .env:
# HTTPS_PORT=443
# SSL_CERT_PATH=./cert.pem
# SSL_KEY_PATH=./key.pem
```

#### Option B: Let's Encrypt (Production)

Use Let's Encrypt for free SSL certificates (requires domain name and public access).

### 2. Reverse Proxy (Nginx - Optional)

If you want to use Nginx as reverse proxy:

```nginx
server {
    listen 80;
    server_name your-server-ip;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

### 3. Firewall Configuration

**Windows Firewall**:
1. Open Windows Firewall with Advanced Security
2. Create Inbound Rule for port 3000 (or your chosen port)
3. Allow TCP traffic

**Linux (iptables/ufw)**:
```bash
# Allow HTTP traffic
sudo ufw allow 3000/tcp
sudo ufw enable
```

### 4. Automatic Backups

Set up a cron job (Linux/macOS) or Task Scheduler (Windows) to run backups:

```bash
# Linux/macOS: Add to crontab
crontab -e

# Daily backup at 2 AM
0 2 * * * cd /path/to/auditsystem && /usr/bin/node dist/index.js backup --schedule
```

---

## Support

For additional support:
- Check `RUNBOOK.md` for operational procedures
- Review `SECURITY_CHECKLIST.md` for security hardening
- Check application logs: `pm2 logs audit-system` or check console output

---

## Next Steps

After successful deployment:
1. Review and implement security hardening checklist
2. Configure regular backups
3. Set up monitoring and health checks
4. Train users on system usage
5. Document any custom configurations

