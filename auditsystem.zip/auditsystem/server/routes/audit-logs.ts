import { Router, type Request, type Response } from "express";
import { storage } from "../storage";
import { requireAuth } from "../middleware/auth";
import { requirePermission } from "../middleware/permissions";
import { extractClientIp } from "../utils/ipExtractor";

const router = Router();

// Get all audit logs (requires logs:view permission)
router.get("/", requireAuth, requirePermission('logs:view'), async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    
    const { entityType, entityId, action, userId, startDate, endDate, page = '1', limit = '50' } = req.query;
    
    // Get all audit logs
    let logs = await storage.getAuditLogs();
    
    // Apply filters
    if (entityType) {
      logs = logs.filter(log => log.entityType === entityType);
    }
    
    if (entityId) {
      logs = logs.filter(log => log.entityId === entityId);
    }
    
    if (action) {
      logs = logs.filter(log => log.action === action);
    }
    
    if (userId) {
      logs = logs.filter(log => log.userId === userId);
    }
    
    // Date filtering
    if (startDate) {
      const start = new Date(startDate as string);
      logs = logs.filter(log => {
        if (!log.createdAt) return false;
        return new Date(log.createdAt) >= start;
      });
    }
    
    if (endDate) {
      const end = new Date(endDate as string);
      end.setHours(23, 59, 59, 999); // End of day
      logs = logs.filter(log => {
        if (!log.createdAt) return false;
        return new Date(log.createdAt) <= end;
      });
    }
    
    // Sort by createdAt descending (most recent first)
    logs.sort((a, b) => {
      const dateA = a.createdAt ? new Date(a.createdAt).getTime() : 0;
      const dateB = b.createdAt ? new Date(b.createdAt).getTime() : 0;
      return dateB - dateA;
    });
    
    // Pagination
    const pageNum = parseInt(page as string, 10) || 1;
    const limitNum = parseInt(limit as string, 10) || 50;
    const startIndex = (pageNum - 1) * limitNum;
    const endIndex = startIndex + limitNum;
    const paginatedLogs = logs.slice(startIndex, endIndex);
    
    // Get user details for each log
    const logsWithUserDetails = await Promise.all(
      paginatedLogs.map(async (log) => {
        let userDetails = null;
        if (log.userId) {
          try {
            const user = await storage.getUser(log.userId);
            if (user) {
              userDetails = {
                id: user.id,
                auditId: user.auditId,
                fullName: user.fullName,
                role: user.role,
              };
            }
          } catch (error) {
            // User might be deleted, ignore
          }
        }
        
        return {
          ...log,
          user: userDetails,
        };
      })
    );
    
    res.json({
      logs: logsWithUserDetails,
      pagination: {
        page: pageNum,
        limit: limitNum,
        total: logs.length,
        totalPages: Math.ceil(logs.length / limitNum),
      },
    });
  } catch (error) {
    console.error('Error fetching audit logs:', error);
    res.status(500).json({ message: "خطا در دریافت لاگ‌های بررسی" });
  }
});

// Get audit logs for a specific entity
router.get("/entity/:entityType/:entityId", requireAuth, requirePermission('logs:view'), async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    
    const { entityType, entityId } = req.params;
    const logs = await storage.getAuditLogs(entityType, entityId);
    
    // Get user details for each log
    const logsWithUserDetails = await Promise.all(
      logs.map(async (log) => {
        let userDetails = null;
        if (log.userId) {
          try {
            const user = await storage.getUser(log.userId);
            if (user) {
              userDetails = {
                id: user.id,
                auditId: user.auditId,
                fullName: user.fullName,
                role: user.role,
              };
            }
          } catch (error) {
            // User might be deleted, ignore
          }
        }
        
        return {
          ...log,
          user: userDetails,
        };
      })
    );
    
    res.json(logsWithUserDetails);
  } catch (error) {
    console.error('Error fetching audit logs for entity:', error);
    res.status(500).json({ message: "خطا در دریافت لاگ‌های بررسی" });
  }
});

// Clear all audit logs (requires logs:view permission - system admin only)
router.delete("/", requireAuth, requirePermission('logs:view'), async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    
    // Only system admin can clear all logs
    if (user.role !== 'system_admin') {
      return res.status(403).json({ message: 'فقط مدیر سیستم می‌تواند تمام لاگ‌ها را پاک کند' });
    }
    
    const deletedCount = await storage.deleteAllAuditLogs();
    
    // CRITICAL: Log the deletion action itself
    await storage.createAuditLog({
      userId: user.id,
      action: 'clear_all_audit_logs',
      entityType: 'audit_log',
      entityId: 'all',
      details: {
        deletedCount,
        deletedBy: user.id,
        deletedByRole: user.role,
        deletedAt: new Date().toISOString(),
      },
      ipAddress: extractClientIp(req),
    });
    
    res.json({ 
      message: `${deletedCount} لاگ با موفقیت پاک شد`,
      deletedCount 
    });
  } catch (error) {
    console.error('Error clearing audit logs:', error);
    res.status(500).json({ message: "خطا در پاک کردن لاگ‌ها" });
  }
});

// Clear audit logs by filters (date range, user, entity type)
router.delete("/filtered", requireAuth, requirePermission('logs:view'), async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    
    // Only system admin can clear filtered logs
    if (user.role !== 'system_admin') {
      return res.status(403).json({ message: 'فقط مدیر سیستم می‌تواند لاگ‌ها را پاک کند' });
    }
    
    const { userId, startDate, endDate, entityType, days } = req.body;
    
    const filters: any = {};
    
    if (userId) {
      filters.userId = userId;
    }
    
    if (entityType) {
      filters.entityType = entityType;
    }
    
    // Date range filtering
    if (days) {
      // Delete logs older than X days
      const cutoffDate = new Date();
      cutoffDate.setDate(cutoffDate.getDate() - parseInt(days as string, 10));
      filters.endDate = cutoffDate;
    } else {
      if (startDate) {
        filters.startDate = new Date(startDate as string);
      }
      if (endDate) {
        filters.endDate = new Date(endDate as string);
      }
    }
    
    const deletedCount = await storage.deleteAuditLogs(filters);
    
    // CRITICAL: Log the deletion action
    await storage.createAuditLog({
      userId: user.id,
      action: 'clear_filtered_audit_logs',
      entityType: 'audit_log',
      entityId: 'filtered',
      details: {
        deletedCount,
        filters,
        deletedBy: user.id,
        deletedByRole: user.role,
        deletedAt: new Date().toISOString(),
      },
      ipAddress: extractClientIp(req),
    });
    
    res.json({ 
      message: `${deletedCount} لاگ با موفقیت پاک شد`,
      deletedCount,
      filters 
    });
  } catch (error) {
    console.error('Error clearing filtered audit logs:', error);
    res.status(500).json({ message: "خطا در پاک کردن لاگ‌ها" });
  }
});

// Clear audit logs for a specific user
router.delete("/user/:userId", requireAuth, requirePermission('logs:view'), async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    
    // Only system admin can clear user logs
    if (user.role !== 'system_admin') {
      return res.status(403).json({ message: 'فقط مدیر سیستم می‌تواند لاگ‌های کاربر را پاک کند' });
    }
    
    const { userId } = req.params;
    
    // Verify user exists
    const targetUser = await storage.getUser(userId);
    if (!targetUser) {
      return res.status(404).json({ message: "کاربر یافت نشد" });
    }
    
    const deletedCount = await storage.deleteAuditLogs({ userId });
    
    // CRITICAL: Log the deletion action
    await storage.createAuditLog({
      userId: user.id,
      action: 'clear_user_audit_logs',
      entityType: 'audit_log',
      entityId: userId,
      details: {
        deletedCount,
        targetUserId: userId,
        targetUserAuditId: targetUser.auditId,
        deletedBy: user.id,
        deletedByRole: user.role,
        deletedAt: new Date().toISOString(),
      },
      ipAddress: extractClientIp(req),
    });
    
    res.json({ 
      message: `${deletedCount} لاگ کاربر ${targetUser.fullName} با موفقیت پاک شد`,
      deletedCount 
    });
  } catch (error) {
    console.error('Error clearing user audit logs:', error);
    res.status(500).json({ message: "خطا در پاک کردن لاگ‌های کاربر" });
  }
});

export default router;

