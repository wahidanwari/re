import { Router, type Request, type Response } from "express";
import { storage } from "../storage";
import { insertEntityTypeSchema } from "@shared/schema";
import { requireAuth } from "../middleware/auth";
import { requirePermission } from "../middleware/permissions";
import { extractClientIp } from "../utils/ipExtractor";

const router = Router();

// Get all entity types (active and inactive)
router.get("/", requireAuth, async (req: Request, res: Response) => {
  try {
    const types = await storage.getEntityTypes();
    res.json(types);
  } catch (error) {
    console.error("Error fetching entity types:", error);
    res.status(500).json({ message: "خطا در دریافت انواع نهادها" });
  }
});

// Get active entity types only (for dropdowns)
router.get("/active", requireAuth, async (req: Request, res: Response) => {
  try {
    const types = await storage.getActiveEntityTypes();
    res.json(types);
  } catch (error) {
    console.error("Error fetching active entity types:", error);
    res.status(500).json({ message: "خطا در دریافت انواع نهادها" });
  }
});

// Get entity type by ID
router.get("/:id", requireAuth, async (req: Request, res: Response) => {
  try {
    const type = await storage.getEntityType(req.params.id);
    if (!type) {
      return res.status(404).json({ message: "نوع نهاد یافت نشد" });
    }
    res.json(type);
  } catch (error) {
    console.error("Error fetching entity type:", error);
    res.status(500).json({ message: "خطا در دریافت نوع نهاد" });
  }
});

// Create entity type (requires settings:manage permission)
router.post("/", requireAuth, requirePermission("system:manage_settings"), async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    const validatedData = insertEntityTypeSchema.parse(req.body);
    
    const newType = await storage.createEntityType(validatedData);
    
    await storage.createAuditLog({
      userId: user.id,
      action: "create_entity_type",
      entityType: "entity_type",
      entityId: newType.id,
      details: { name: newType.name },
      ipAddress: extractClientIp(req),
    });
    
    res.status(201).json(newType);
  } catch (error: any) {
    console.error("Error creating entity type:", error);
    if (error.name === "ZodError") {
      return res.status(400).json({ message: "داده‌های نامعتبر", errors: error.errors });
    }
    res.status(500).json({ message: "خطا در ایجاد نوع نهاد" });
  }
});

// Update entity type (requires settings:manage permission)
router.put("/:id", requireAuth, requirePermission("system:manage_settings"), async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    const type = await storage.getEntityType(req.params.id);
    if (!type) {
      return res.status(404).json({ message: "نوع نهاد یافت نشد" });
    }
    
    const validatedData = insertEntityTypeSchema.partial().parse(req.body);
    const updatedType = await storage.updateEntityType(req.params.id, validatedData);
    
    if (!updatedType) {
      return res.status(500).json({ message: "خطا در بروز رسانی نوع نهاد" });
    }
    
    await storage.createAuditLog({
      userId: user.id,
      action: "update_entity_type",
      entityType: "entity_type",
      entityId: updatedType.id,
      details: { old: type, new: updatedType },
      ipAddress: extractClientIp(req),
    });
    
    res.json(updatedType);
  } catch (error: any) {
    console.error("Error updating entity type:", error);
    if (error.name === "ZodError") {
      return res.status(400).json({ message: "داده‌های نامعتبر", errors: error.errors });
    }
    res.status(500).json({ message: "خطا در بروز رسانی نوع نهاد" });
  }
});

// Delete entity type (soft delete - requires settings:manage permission)
router.delete("/:id", requireAuth, requirePermission("system:manage_settings"), async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    const type = await storage.getEntityType(req.params.id);
    if (!type) {
      return res.status(404).json({ message: "نوع نهاد یافت نشد" });
    }
    
    const deleted = await storage.deleteEntityType(req.params.id);
    if (!deleted) {
      return res.status(500).json({ message: "خطا در حذف نوع نهاد" });
    }
    
    await storage.createAuditLog({
      userId: user.id,
      action: "delete_entity_type",
      entityType: "entity_type",
      entityId: req.params.id,
      details: { name: type.name },
      ipAddress: extractClientIp(req),
    });
    
    res.json({ message: "نوع نهاد با موفقیت حذف شد" });
  } catch (error) {
    console.error("Error deleting entity type:", error);
    res.status(500).json({ message: "خطا در حذف نوع نهاد" });
  }
});

export default router;

