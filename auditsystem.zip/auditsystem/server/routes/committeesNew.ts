/**
 * New Committee Module Routes
 * Handles committee lifecycle: creation, approval, closure
 * Business logic only - no UI implementation
 */

import { Router, type Request, type Response } from "express";
import { requireAuth } from "../middleware/auth";
import { extractClientIp } from "../utils/ipExtractor";
import { storage } from "../storage";
import {
  createCommittee,
  approveCommittee,
  closeCommittee,
  hasCommitteeManagementPermission,
  getCommitteePermissions,
  validateCommitteeAssignment,
} from "../services/committeeService";
import {
  getEligibleCases,
  assignCasesViaCommittee,
  assignCaseDirectly,
  getCaseAssignmentHistory,
  reassignCaseViaCommittee,
} from "../services/caseAssignmentService";

const router = Router();

/**
 * GET /api/committees-new
 * List all committees (read-only for all authenticated users)
 */
router.get("/", requireAuth, async (req: Request, res: Response) => {
  try {
    const committees = await storage.getCommitteesNew();
    res.json(committees);
  } catch (error) {
    console.error('Error fetching committees:', error);
    res.status(500).json({ message: "خطا در دریافت لیست کمیته‌ها" });
  }
});

/**
 * GET /api/committees-new/:id
 * Get committee by ID (read-only for all authenticated users)
 */
router.get("/:id", requireAuth, async (req: Request, res: Response) => {
  try {
    const committee = await storage.getCommitteeNew(req.params.id);
    if (!committee) {
      return res.status(404).json({ message: "کمیته یافت نشد" });
    }
    res.json(committee);
  } catch (error) {
    console.error('Error fetching committee:', error);
    res.status(500).json({ message: "خطا در دریافت کمیته" });
  }
});

/**
 * POST /api/committees-new
 * Create a new committee (DRAFT status)
 * Requires: Director, Coordinator, or System Admin
 */
router.post("/", requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    
    // Check permissions
    if (!hasCommitteeManagementPermission(user)) {
      return res.status(403).json({
        message: "فقط مدیر سیستم، مدیر، و هماهنگ‌کننده می‌توانند کمیته ایجاد کنند",
      });
    }
    
    // Validate required fields
    const { title, year, month } = req.body;
    if (!title || !year || !month) {
      return res.status(400).json({
        message: "عنوان، سال و ماه کمیته الزامی است",
      });
    }
    
    // Validate month range
    if (month < 1 || month > 12) {
      return res.status(400).json({
        message: "ماه باید بین 1 تا 12 باشد",
      });
    }
    
    // Create committee
    const result = await createCommittee(
      { title, year: parseInt(year), month: parseInt(month) },
      user
    );
    
    if (!result.success) {
      return res.status(400).json({
        message: result.errorMessage || "خطا در ایجاد کمیته",
      });
    }
    
    // Audit logging
    await storage.createAuditLog({
      userId: user.id,
      action: 'create_committee_new',
      entityType: 'committee',
      entityId: result.committee!.id,
      details: {
        title: result.committee!.title,
        year: result.committee!.year,
        month: result.committee!.month,
        status: result.committee!.status,
      },
      ipAddress: extractClientIp(req),
    });
    
    res.status(201).json(result.committee);
  } catch (error: any) {
    console.error('[COMMITTEE ROUTE] Error creating committee:', error);
    res.status(400).json({
      message: error?.message || "خطا در ایجاد کمیته",
    });
  }
});

/**
 * POST /api/committees-new/:id/approve
 * Approve a committee (DRAFT → APPROVED)
 * Requires: Director, Coordinator, or System Admin
 */
router.post("/:id/approve", requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    
    // Check permissions
    if (!hasCommitteeManagementPermission(user)) {
      return res.status(403).json({
        message: "فقط مدیر سیستم، مدیر، و هماهنگ‌کننده می‌توانند کمیته را تایید کنند",
      });
    }
    
    // Approve committee
    const result = await approveCommittee(req.params.id, user);
    
    if (!result.success) {
      return res.status(400).json({
        message: result.errorMessage || "خطا در تایید کمیته",
      });
    }
    
    // Audit logging
    await storage.createAuditLog({
      userId: user.id,
      action: 'approve_committee_new',
      entityType: 'committee',
      entityId: req.params.id,
      details: {
        previousStatus: 'DRAFT',
        newStatus: 'APPROVED',
        title: result.committee!.title,
      },
      ipAddress: extractClientIp(req),
    });
    
    res.json(result.committee);
  } catch (error: any) {
    console.error('[COMMITTEE ROUTE] Error approving committee:', error);
    res.status(400).json({
      message: error?.message || "خطا در تایید کمیته",
    });
  }
});

/**
 * POST /api/committees-new/:id/close
 * Close a committee (APPROVED → CLOSED)
 * Requires: Director, Coordinator, or System Admin
 */
router.post("/:id/close", requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    
    // Check permissions
    if (!hasCommitteeManagementPermission(user)) {
      return res.status(403).json({
        message: "فقط مدیر سیستم، مدیر، و هماهنگ‌کننده می‌توانند کمیته را ببندند",
      });
    }
    
    // Close committee
    const result = await closeCommittee(req.params.id, user);
    
    if (!result.success) {
      return res.status(400).json({
        message: result.errorMessage || "خطا در بستن کمیته",
      });
    }
    
    // Audit logging
    await storage.createAuditLog({
      userId: user.id,
      action: 'close_committee_new',
      entityType: 'committee',
      entityId: req.params.id,
      details: {
        previousStatus: 'APPROVED',
        newStatus: 'CLOSED',
        title: result.committee!.title,
      },
      ipAddress: extractClientIp(req),
    });
    
    res.json(result.committee);
  } catch (error: any) {
    console.error('[COMMITTEE ROUTE] Error closing committee:', error);
    res.status(400).json({
      message: error?.message || "خطا در بستن کمیته",
    });
  }
});

/**
 * GET /api/committees-new/:id/permissions
 * Get user permissions for committee operations
 */
router.get("/:id/permissions", requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    const permissions = getCommitteePermissions(user);
    res.json(permissions);
  } catch (error) {
    console.error('Error fetching permissions:', error);
    res.status(500).json({ message: "خطا در دریافت مجوزها" });
  }
});

/**
 * GET /api/committees-new/:id/validate-assignment
 * Validate that assignment is allowed through this committee
 * Used before creating assignments
 */
router.get("/:id/validate-assignment", requireAuth, async (req: Request, res: Response) => {
  try {
    const validation = await validateCommitteeAssignment(req.params.id);
    if (!validation.isValid) {
      return res.status(400).json({
        valid: false,
        message: validation.errorMessage,
      });
    }
    res.json({ valid: true });
  } catch (error: any) {
    console.error('Error validating assignment:', error);
    res.status(500).json({
      valid: false,
      message: error?.message || "خطا در اعتبارسنجی",
    });
  }
});

/**
 * GET /api/committees-new/eligible-cases
 * Get all eligible cases for committee assignment
 * Returns cases with status "NEW" (جدید) or "در انتظار بررسی" that:
 * - Are NOT already assigned to an audit group (no receivingGroup, currentAuditGroupId, or currentAssignmentId)
 * - Are NOT under active audit by an auditor
 */
router.get("/eligible-cases", requireAuth, async (req: Request, res: Response) => {
  try {
    const eligibleCases = await getEligibleCases();
    res.json(eligibleCases);
  } catch (error: any) {
    console.error('Error fetching eligible cases:', error);
    res.status(500).json({
      message: error?.message || "خطا در دریافت قضایای واجد شرایط",
    });
  }
});

/**
 * POST /api/committees-new/:id/assign-cases
 * Assign cases to an audit group via committee
 * Requires: Director, Coordinator, or System Admin
 * Committee must be APPROVED
 */
router.post("/:id/assign-cases", requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    
    // Check permissions
    if (!hasCommitteeManagementPermission(user)) {
      return res.status(403).json({
        message: "فقط مدیر سیستم، مدیر، و هماهنگ‌کننده می‌توانند قضایا را اختصاص دهند",
      });
    }
    
    // Validate request body
    const { caseIds, auditGroupId } = req.body;
    
    // CRITICAL: Ensure caseIds is an array of strings (not objects)
    if (!caseIds || !Array.isArray(caseIds) || caseIds.length === 0) {
      return res.status(400).json({
        message: "لیست قضایا الزامی است",
      });
    }
    
    // Validate and normalize caseIds - ensure they are all strings
    const validCaseIds = caseIds
      .map(id => {
        // If it's an object, try to extract the id field
        if (typeof id === 'object' && id !== null) {
          return id.id || id.caseId || String(id);
        }
        return String(id).trim();
      })
      .filter(id => id && id.length > 0);
    
    if (validCaseIds.length === 0) {
      return res.status(400).json({
        message: "شناسه‌های قضایا نامعتبر است. لطفاً فقط شناسه‌های معتبر ارسال کنید.",
      });
    }
    
    if (validCaseIds.length !== caseIds.length) {
      console.warn('[COMMITTEE ROUTE] Some caseIds were invalid and filtered out', {
        original: caseIds,
        valid: validCaseIds,
      });
    }
    
    // CRITICAL: Ensure auditGroupId is present and is a string
    if (!auditGroupId || typeof auditGroupId !== 'string' || auditGroupId.trim() === '') {
      return res.status(400).json({
        message: "گروه بررسی الزامی است",
      });
    }
    
    const normalizedAuditGroupId = String(auditGroupId).trim();
    
    // Assign cases (use normalized IDs)
    console.log('[COMMITTEE ROUTE] Assigning cases:', {
      committeeId: req.params.id,
      caseIds: validCaseIds,
      auditGroupId: normalizedAuditGroupId,
      caseCount: validCaseIds.length,
    });
    
    const result = await assignCasesViaCommittee(
      req.params.id,
      validCaseIds,
      normalizedAuditGroupId,
      user
    );
    
    // Check if any assignments succeeded
    const successfulAssignments = result.assignments.filter(a => a.success);
    const failedAssignments = result.assignments.filter(a => !a.success);
    
    if (successfulAssignments.length === 0) {
      // All assignments failed
      return res.status(400).json({
        success: false,
        message: result.errorMessage || "خطا در اختصاص قضایا",
        assignments: result.assignments,
      });
    }
    
    // Audit logging (individual assignments logged in service)
    await storage.createAuditLog({
      userId: user.id,
      action: 'batch_assign_cases_via_committee',
      entityType: 'committee',
      entityId: req.params.id,
      details: {
        caseCount: validCaseIds.length,
        auditGroupId: normalizedAuditGroupId,
        successfulAssignments: successfulAssignments.length,
        failedAssignments: failedAssignments.length,
      },
      ipAddress: extractClientIp(req),
    });
    
    // Return response with assignment results
    // Include updated case data in successful assignments
    res.json({
      success: result.success,
      assignments: result.assignments,
      summary: {
        total: result.assignments.length,
        successful: successfulAssignments.length,
        failed: failedAssignments.length,
      },
    });
  } catch (error: any) {
    console.error('[COMMITTEE ROUTE] Error assigning cases:', error);
    res.status(400).json({
      message: error?.message || "خطا در اختصاص قضایا",
    });
  }
});

/**
 * POST /api/committees-new/:id/reassign-case
 * Reassign a case to a different audit group via committee
 * Requires: Director, Coordinator, or System Admin
 * Committee must be APPROVED
 */
router.post("/:id/reassign-case", requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    
    // Check permissions
    if (!hasCommitteeManagementPermission(user)) {
      return res.status(403).json({
        message: "فقط مدیر سیستم، مدیر، و هماهنگ‌کننده می‌توانند قضایا را مجدداً اختصاص دهند",
      });
    }
    
    // Validate request body
    const { caseId, auditGroupId, reason } = req.body;
    if (!caseId) {
      return res.status(400).json({
        message: "شناسه قضیه الزامی است",
      });
    }
    
    if (!auditGroupId) {
      return res.status(400).json({
        message: "گروه بررسی جدید الزامی است",
      });
    }
    
    if (!reason || reason.trim() === '') {
      return res.status(400).json({
        message: "دلیل اختصاص مجدد الزامی است",
      });
    }
    
    // Reassign case
    const result = await reassignCaseViaCommittee(
      req.params.id,
      caseId,
      auditGroupId,
      reason,
      user
    );
    
    if (!result.success) {
      return res.status(400).json({
        message: result.errorMessage || "خطا در اختصاص مجدد قضیه",
      });
    }
    
    res.json({
      success: true,
      assignmentId: result.assignmentId,
      case: result.case,
    });
  } catch (error: any) {
    console.error('[COMMITTEE ROUTE] Error reassigning case:', error);
    res.status(400).json({
      message: error?.message || "خطا در اختصاص مجدد قضیه",
    });
  }
});

/**
 * GET /api/committees-new/:id/assignments
 * Get all assignments for a committee
 */
router.get("/:id/assignments", requireAuth, async (req: Request, res: Response) => {
  try {
    const assignments = await storage.getCommitteeAssignments(req.params.id);
    res.json(assignments);
  } catch (error: any) {
    console.error('Error fetching committee assignments:', error);
    res.status(500).json({
      message: error?.message || "خطا در دریافت اختصاصات کمیته",
    });
  }
});

/**
 * POST /api/committees-new/direct-assign
 * Direct assignment of a case to an audit group (without committee)
 * Requires: Director, Coordinator, or System Admin
 */
router.post("/direct-assign", requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    
    // Check permissions
    if (!hasCommitteeManagementPermission(user)) {
      return res.status(403).json({
        message: "فقط مدیر سیستم، مدیر، و هماهنگ‌کننده می‌توانند قضایا را مستقیماً اختصاص دهند",
      });
    }
    
    // Validate request body
    const { caseId, auditGroupId, reason } = req.body;
    if (!caseId) {
      return res.status(400).json({
        message: "شناسه قضیه الزامی است",
      });
    }
    
    if (!auditGroupId) {
      return res.status(400).json({
        message: "گروه بررسی الزامی است",
      });
    }
    
    if (!reason || reason.trim() === '') {
      return res.status(400).json({
        message: "دلیل اختصاص الزامی است",
      });
    }
    
    // Assign case directly
    const result = await assignCaseDirectly(caseId, auditGroupId, reason, user);
    
    if (!result.success) {
      return res.status(400).json({
        message: result.errorMessage || "خطا در اختصاص قضیه",
      });
    }
    
    // Audit logging (done in service, but add IP here)
    await storage.createAuditLog({
      userId: user.id,
      action: 'direct_assign_case',
      entityType: 'case',
      entityId: caseId,
      details: {
        auditGroupId: auditGroupId,
        reason: reason,
        assignmentId: result.assignmentId,
      },
      ipAddress: extractClientIp(req),
    });
    
    res.json({
      success: true,
      assignmentId: result.assignmentId,
      case: result.case,
    });
  } catch (error: any) {
    console.error('[COMMITTEE ROUTE] Error in direct assignment:', error);
    res.status(400).json({
      message: error?.message || "خطا در اختصاص قضیه",
    });
  }
});

/**
 * GET /api/committees-new/cases/:caseId/assignment-history
 * Get full assignment history for a case
 */
router.get("/cases/:caseId/assignment-history", requireAuth, async (req: Request, res: Response) => {
  try {
    const history = await getCaseAssignmentHistory(req.params.caseId);
    res.json(history);
  } catch (error: any) {
    console.error('Error fetching assignment history:', error);
    res.status(500).json({
      message: error?.message || "خطا در دریافت تاریخچه اختصاص",
    });
  }
});

export default router;

