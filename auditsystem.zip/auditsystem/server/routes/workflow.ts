/**
 * Workflow Routes
 * API endpoints for audit reporting workflow operations
 * Handles MonthlyTransactions, InternalReport, and MinistrySummary
 */

import { Router, type Request, type Response } from "express";
import { requireAuth } from "../middleware/auth";
import { requirePermission } from "../middleware/permissions";
import {
  populateMonthlyTransactions,
  updateMonthlyTransaction,
  populateInternalReport,
  populateMinistrySummary,
  recalculateWorkflow,
  getMonthlyTransaction,
  getInternalReport,
  getMinistrySummary,
  getInternalReportsForMonth,
  getMinistrySummariesForMonth,
  generateAlerts,
  generateEntityAlerts,
  generateGroupAlerts,
  getAlerts,
  getEntityAlerts,
  getGroupAlerts,
  acknowledgeAlert,
  resolveAlert,
  executeAutomatedWorkflow,
  saveWorkflowConfig,
  getWorkflowConfig,
  getAllWorkflowConfigs,
  getScheduledWorkflowConfigs,
  updateWorkflowConfigStatus,
  runScheduledWorkflows,
} from "../services/workflowService";
import {
  exportInternalReportToExcel,
  exportInternalReportToPDF,
  exportMinistrySummaryToExcel,
  exportMinistrySummaryToPDF,
} from "../services/workflowExportService";
import { extractClientIp } from "../utils/ipExtractor";
import { storage } from "../storage";

const router = Router();

/**
 * GET /api/workflow/monthly-transactions/:entityTin/:month/:year
 * Get monthly transaction for a specific entity
 */
router.get(
  "/monthly-transactions/:entityTin/:month/:year",
  requireAuth,
  requirePermission("reports:generate"),
  async (req: Request, res: Response) => {
    try {
      const { entityTin, month, year } = req.params;
      const monthShamsi = parseInt(month, 10);
      const yearShamsi = parseInt(year, 10);

      if (isNaN(monthShamsi) || isNaN(yearShamsi) || monthShamsi < 1 || monthShamsi > 12) {
        return res.status(400).json({ message: "Invalid month or year" });
      }

      const transaction = await getMonthlyTransaction(entityTin, monthShamsi, yearShamsi);

      if (!transaction) {
        return res.status(404).json({ message: "Monthly transaction not found" });
      }

      res.json(transaction);
    } catch (error) {
      console.error("Error getting monthly transaction:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  }
);

/**
 * POST /api/workflow/monthly-transactions
 * Create or update a monthly transaction
 */
router.post(
  "/monthly-transactions",
  requireAuth,
  requirePermission("reports:generate"),
  async (req: Request, res: Response) => {
    try {
      const user = req.user as any;
      const { entityTin, monthShamsi, yearShamsi, ...data } = req.body;

      if (!entityTin || !monthShamsi || !yearShamsi) {
        return res.status(400).json({ message: "entityTin, monthShamsi, and yearShamsi are required" });
      }

      if (monthShamsi < 1 || monthShamsi > 12) {
        return res.status(400).json({ message: "monthShamsi must be between 1 and 12" });
      }

      const transaction = await updateMonthlyTransaction(
        entityTin,
        monthShamsi,
        yearShamsi,
        data
      );

      if (!transaction) {
        return res.status(500).json({ message: "Failed to create/update transaction" });
      }

      // Log the action
      await storage.createAuditLog({
        userId: user.id,
        action: "workflow:update_monthly_transaction",
        entityType: "monthly_transaction",
        entityId: transaction.id,
        details: {
          entityTin,
          monthShamsi,
          yearShamsi,
        },
        ipAddress: extractClientIp(req),
      });

      // Automatically recalculate InternalReport (which will trigger MinistrySummary update)
      await populateInternalReport(monthShamsi, yearShamsi);

      res.json(transaction);
    } catch (error) {
      console.error("Error updating monthly transaction:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  }
);

/**
 * GET /api/workflow/internal-report/:entityTin/:month/:year
 * Get internal report for a specific entity
 */
router.get(
  "/internal-report/:entityTin/:month/:year",
  requireAuth,
  requirePermission("reports:generate"),
  async (req: Request, res: Response) => {
    try {
      const { entityTin, month, year } = req.params;
      const monthShamsi = parseInt(month, 10);
      const yearShamsi = parseInt(year, 10);

      if (isNaN(monthShamsi) || isNaN(yearShamsi) || monthShamsi < 1 || monthShamsi > 12) {
        return res.status(400).json({ message: "Invalid month or year" });
      }

      const report = await getInternalReport(entityTin, monthShamsi, yearShamsi);

      if (!report) {
        return res.status(404).json({ message: "Internal report not found" });
      }

      res.json(report);
    } catch (error) {
      console.error("Error getting internal report:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  }
);

/**
 * GET /api/workflow/internal-reports/:month/:year
 * Get all internal reports for a specific month/year
 */
router.get(
  "/internal-reports/:month/:year",
  requireAuth,
  requirePermission("reports:generate"),
  async (req: Request, res: Response) => {
    try {
      const { month, year } = req.params;
      const monthShamsi = parseInt(month, 10);
      const yearShamsi = parseInt(year, 10);

      if (isNaN(monthShamsi) || isNaN(yearShamsi) || monthShamsi < 1 || monthShamsi > 12) {
        return res.status(400).json({ message: "Invalid month or year" });
      }

      const reports = await getInternalReportsForMonth(monthShamsi, yearShamsi);
      res.json(reports);
    } catch (error) {
      console.error("Error getting internal reports:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  }
);

/**
 * GET /api/workflow/ministry-summary/:groupName/:month/:year
 * Get ministry summary for a specific group
 */
router.get(
  "/ministry-summary/:groupName/:month/:year",
  requireAuth,
  requirePermission("reports:generate"),
  async (req: Request, res: Response) => {
    try {
      const { groupName, month, year } = req.params;
      const monthShamsi = parseInt(month, 10);
      const yearShamsi = parseInt(year, 10);

      if (isNaN(monthShamsi) || isNaN(yearShamsi) || monthShamsi < 1 || monthShamsi > 12) {
        return res.status(400).json({ message: "Invalid month or year" });
      }

      const summary = await getMinistrySummary(groupName, monthShamsi, yearShamsi);

      if (!summary) {
        return res.status(404).json({ message: "Ministry summary not found" });
      }

      res.json(summary);
    } catch (error) {
      console.error("Error getting ministry summary:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  }
);

/**
 * GET /api/workflow/ministry-summaries/:month/:year
 * Get all ministry summaries for a specific month/year
 */
router.get(
  "/ministry-summaries/:month/:year",
  requireAuth,
  requirePermission("reports:generate"),
  async (req: Request, res: Response) => {
    try {
      const { month, year } = req.params;
      const monthShamsi = parseInt(month, 10);
      const yearShamsi = parseInt(year, 10);

      if (isNaN(monthShamsi) || isNaN(yearShamsi) || monthShamsi < 1 || monthShamsi > 12) {
        return res.status(400).json({ message: "Invalid month or year" });
      }

      const summaries = await getMinistrySummariesForMonth(monthShamsi, yearShamsi);
      res.json(summaries);
    } catch (error) {
      console.error("Error getting ministry summaries:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  }
);

/**
 * POST /api/workflow/populate/:month/:year
 * Populate all workflow tables for a specific month/year
 */
router.post(
  "/populate/:month/:year",
  requireAuth,
  requirePermission("reports:generate"),
  async (req: Request, res: Response) => {
    try {
      const user = req.user as any;
      const { month, year } = req.params;
      const monthShamsi = parseInt(month, 10);
      const yearShamsi = parseInt(year, 10);

      if (isNaN(monthShamsi) || isNaN(yearShamsi) || monthShamsi < 1 || monthShamsi > 12) {
        return res.status(400).json({ message: "Invalid month or year" });
      }

      const result = await recalculateWorkflow(monthShamsi, yearShamsi);

      // Log the action
      await storage.createAuditLog({
        userId: user.id,
        action: "workflow:populate",
        entityType: "workflow",
        entityId: `${monthShamsi}/${yearShamsi}`,
        details: {
          monthShamsi,
          yearShamsi,
          result,
        },
        ipAddress: extractClientIp(req),
      });

      res.json({
        message: "Workflow populated successfully",
        result,
      });
    } catch (error) {
      console.error("Error populating workflow:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  }
);

/**
 * POST /api/workflow/recalculate/:month/:year
 * Recalculate all workflow tables for a specific month/year
 * This ensures data consistency across all workflow tables
 */
router.post(
  "/recalculate/:month/:year",
  requireAuth,
  requirePermission("reports:generate"),
  async (req: Request, res: Response) => {
    try {
      const user = req.user as any;
      const { month, year } = req.params;
      const monthShamsi = parseInt(month, 10);
      const yearShamsi = parseInt(year, 10);

      if (isNaN(monthShamsi) || isNaN(yearShamsi) || monthShamsi < 1 || monthShamsi > 12) {
        return res.status(400).json({ message: "Invalid month or year" });
      }

      const result = await recalculateWorkflow(monthShamsi, yearShamsi);

      // Log the action
      await storage.createAuditLog({
        userId: user.id,
        action: "workflow:recalculate",
        entityType: "workflow",
        entityId: `${monthShamsi}/${yearShamsi}`,
        details: {
          monthShamsi,
          yearShamsi,
          result,
        },
        ipAddress: extractClientIp(req),
      });

      res.json({
        message: "Workflow recalculated successfully",
        result,
      });
    } catch (error) {
      console.error("Error recalculating workflow:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  }
);

/**
 * GET /api/workflow/alerts/:month/:year
 * Get all alerts for a specific month/year
 */
router.get(
  "/alerts/:month/:year",
  requireAuth,
  requirePermission("reports:generate"),
  async (req: Request, res: Response) => {
    try {
      const { month, year, status } = req.query;
      const monthShamsi = parseInt(req.params.month, 10);
      const yearShamsi = parseInt(req.params.year, 10);

      if (isNaN(monthShamsi) || isNaN(yearShamsi) || monthShamsi < 1 || monthShamsi > 12) {
        return res.status(400).json({ message: "Invalid month or year" });
      }

      const alerts = await getAlerts(
        monthShamsi,
        yearShamsi,
        status as 'active' | 'acknowledged' | 'resolved' | 'dismissed' | undefined
      );

      res.json(alerts);
    } catch (error) {
      console.error("Error getting alerts:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  }
);

/**
 * GET /api/workflow/alerts/entity/:entityTin
 * Get alerts for a specific entity
 */
router.get(
  "/alerts/entity/:entityTin",
  requireAuth,
  requirePermission("reports:generate"),
  async (req: Request, res: Response) => {
    try {
      const { entityTin } = req.params;
      const { month, year } = req.query;

      const monthShamsi = month ? parseInt(month as string, 10) : undefined;
      const yearShamsi = year ? parseInt(year as string, 10) : undefined;

      if (monthShamsi !== undefined && (isNaN(monthShamsi) || monthShamsi < 1 || monthShamsi > 12)) {
        return res.status(400).json({ message: "Invalid month" });
      }

      const alerts = await getEntityAlerts(entityTin, monthShamsi, yearShamsi);

      res.json(alerts);
    } catch (error) {
      console.error("Error getting entity alerts:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  }
);

/**
 * GET /api/workflow/alerts/group/:groupName
 * Get alerts for a specific group
 */
router.get(
  "/alerts/group/:groupName",
  requireAuth,
  requirePermission("reports:generate"),
  async (req: Request, res: Response) => {
    try {
      const { groupName } = req.params;
      const { month, year } = req.query;

      const monthShamsi = month ? parseInt(month as string, 10) : undefined;
      const yearShamsi = year ? parseInt(year as string, 10) : undefined;

      if (monthShamsi !== undefined && (isNaN(monthShamsi) || monthShamsi < 1 || monthShamsi > 12)) {
        return res.status(400).json({ message: "Invalid month" });
      }

      const alerts = await getGroupAlerts(groupName, monthShamsi, yearShamsi);

      res.json(alerts);
    } catch (error) {
      console.error("Error getting group alerts:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  }
);

/**
 * POST /api/workflow/alerts/generate/:month/:year
 * Manually generate alerts for a specific month/year
 */
router.post(
  "/alerts/generate/:month/:year",
  requireAuth,
  requirePermission("reports:generate"),
  async (req: Request, res: Response) => {
    try {
      const user = req.user as any;
      const { month, year } = req.params;
      const monthShamsi = parseInt(month, 10);
      const yearShamsi = parseInt(year, 10);

      if (isNaN(monthShamsi) || isNaN(yearShamsi) || monthShamsi < 1 || monthShamsi > 12) {
        return res.status(400).json({ message: "Invalid month or year" });
      }

      const result = await generateAlerts(monthShamsi, yearShamsi);

      // Log the action
      await storage.createAuditLog({
        userId: user.id,
        action: "workflow:generate_alerts",
        entityType: "workflow_alerts",
        entityId: `${monthShamsi}/${yearShamsi}`,
        details: {
          monthShamsi,
          yearShamsi,
          result,
        },
        ipAddress: extractClientIp(req),
      });

      res.json({
        message: "Alerts generated successfully",
        result,
      });
    } catch (error) {
      console.error("Error generating alerts:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  }
);

/**
 * POST /api/workflow/alerts/:alertId/acknowledge
 * Acknowledge an alert
 */
router.post(
  "/alerts/:alertId/acknowledge",
  requireAuth,
  requirePermission("reports:generate"),
  async (req: Request, res: Response) => {
    try {
      const user = req.user as any;
      const { alertId } = req.params;

      const alert = await acknowledgeAlert(alertId, user.id);

      if (!alert) {
        return res.status(404).json({ message: "Alert not found" });
      }

      // Log the action
      await storage.createAuditLog({
        userId: user.id,
        action: "workflow:acknowledge_alert",
        entityType: "workflow_alert",
        entityId: alertId,
        details: {
          alertType: alert.alertType,
          entityTin: alert.entityTin,
          groupName: alert.groupName,
        },
        ipAddress: extractClientIp(req),
      });

      res.json(alert);
    } catch (error) {
      console.error("Error acknowledging alert:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  }
);

/**
 * POST /api/workflow/alerts/:alertId/resolve
 * Resolve an alert
 */
router.post(
  "/alerts/:alertId/resolve",
  requireAuth,
  requirePermission("reports:generate"),
  async (req: Request, res: Response) => {
    try {
      const user = req.user as any;
      const { alertId } = req.params;

      const alert = await resolveAlert(alertId);

      if (!alert) {
        return res.status(404).json({ message: "Alert not found" });
      }

      // Log the action
      await storage.createAuditLog({
        userId: user.id,
        action: "workflow:resolve_alert",
        entityType: "workflow_alert",
        entityId: alertId,
        details: {
          alertType: alert.alertType,
          entityTin: alert.entityTin,
          groupName: alert.groupName,
        },
        ipAddress: extractClientIp(req),
      });

      res.json(alert);
    } catch (error) {
      console.error("Error resolving alert:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  }
);

/**
 * GET /api/workflow/export/internal-report/:month/:year
 * Export InternalReport to Excel or PDF
 */
router.get(
  "/export/internal-report/:month/:year",
  requireAuth,
  requirePermission("reports:generate"),
  async (req: Request, res: Response) => {
    try {
      const user = req.user as any;
      const { month, year } = req.params;
      const { format = 'excel' } = req.query;
      const monthShamsi = parseInt(month, 10);
      const yearShamsi = parseInt(year, 10);

      if (isNaN(monthShamsi) || isNaN(yearShamsi) || monthShamsi < 1 || monthShamsi > 12) {
        return res.status(400).json({ message: "Invalid month or year" });
      }

      const monthNames = ['', 'حمل', 'ثور', 'جوزا', 'سرطان', 'اسد', 'سنبله', 'میزان', 'عقرب', 'قوس', 'جدی', 'دلو', 'حوت'];
      const monthName = monthNames[monthShamsi] || monthShamsi.toString();

      if (format === 'pdf') {
        const doc = await exportInternalReportToPDF(monthShamsi, yearShamsi);
        res.setHeader('Content-Type', 'application/pdf');
        res.setHeader('Content-Disposition', `attachment; filename=internal-report-${monthShamsi}-${yearShamsi}.pdf`);
        doc.pipe(res);
        doc.end();
      } else {
        const buffer = await exportInternalReportToExcel(monthShamsi, yearShamsi);
        res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        res.setHeader('Content-Disposition', `attachment; filename=internal-report-${monthShamsi}-${yearShamsi}.xlsx`);
        res.send(buffer);
      }

      // Log the action
      await storage.createAuditLog({
        userId: user.id,
        action: "workflow:export_internal_report",
        entityType: "workflow_export",
        entityId: `${monthShamsi}/${yearShamsi}`,
        details: {
          monthShamsi,
          yearShamsi,
          format,
        },
        ipAddress: extractClientIp(req),
      });
    } catch (error) {
      console.error("Error exporting internal report:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  }
);

/**
 * GET /api/workflow/export/ministry-summary/:month/:year
 * Export MinistrySummary to Excel or PDF
 */
router.get(
  "/export/ministry-summary/:month/:year",
  requireAuth,
  requirePermission("reports:generate"),
  async (req: Request, res: Response) => {
    try {
      const user = req.user as any;
      const { month, year } = req.params;
      const { format = 'excel' } = req.query;
      const monthShamsi = parseInt(month, 10);
      const yearShamsi = parseInt(year, 10);

      if (isNaN(monthShamsi) || isNaN(yearShamsi) || monthShamsi < 1 || monthShamsi > 12) {
        return res.status(400).json({ message: "Invalid month or year" });
      }

      const monthNames = ['', 'حمل', 'ثور', 'جوزا', 'سرطان', 'اسد', 'سنبله', 'میزان', 'عقرب', 'قوس', 'جدی', 'دلو', 'حوت'];
      const monthName = monthNames[monthShamsi] || monthShamsi.toString();

      if (format === 'pdf') {
        const doc = await exportMinistrySummaryToPDF(monthShamsi, yearShamsi);
        res.setHeader('Content-Type', 'application/pdf');
        res.setHeader('Content-Disposition', `attachment; filename=ministry-summary-${monthShamsi}-${yearShamsi}.pdf`);
        doc.pipe(res);
        doc.end();
      } else {
        const buffer = await exportMinistrySummaryToExcel(monthShamsi, yearShamsi);
        res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        res.setHeader('Content-Disposition', `attachment; filename=ministry-summary-${monthShamsi}-${yearShamsi}.xlsx`);
        res.send(buffer);
      }

      // Log the action
      await storage.createAuditLog({
        userId: user.id,
        action: "workflow:export_ministry_summary",
        entityType: "workflow_export",
        entityId: `${monthShamsi}/${yearShamsi}`,
        details: {
          monthShamsi,
          yearShamsi,
          format,
        },
        ipAddress: extractClientIp(req),
      });
    } catch (error) {
      console.error("Error exporting ministry summary:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  }
);

/**
 * POST /api/workflow/automate/:month/:year
 * Execute automated workflow for a specific month/year
 */
router.post(
  "/automate/:month/:year",
  requireAuth,
  requirePermission("reports:generate"),
  async (req: Request, res: Response) => {
    try {
      const user = req.user as any;
      const { month, year } = req.params;
      const {
        appendMode = true,
        regenerateReports = true,
        regenerateSummaries = true,
        generateAlerts: generateAlertsFlag = true,
      } = req.body;
      
      const monthShamsi = parseInt(month, 10);
      const yearShamsi = parseInt(year, 10);

      if (isNaN(monthShamsi) || isNaN(yearShamsi) || monthShamsi < 1 || monthShamsi > 12) {
        return res.status(400).json({ message: "Invalid month or year" });
      }

      const result = await executeAutomatedWorkflow(monthShamsi, yearShamsi, {
        appendMode,
        regenerateReports,
        regenerateSummaries,
        generateAlerts: generateAlertsFlag,
      });

      // Log the action
      await storage.createAuditLog({
        userId: user.id,
        action: "workflow:execute_automated",
        entityType: "workflow_automation",
        entityId: `${monthShamsi}/${yearShamsi}`,
        details: {
          monthShamsi,
          yearShamsi,
          options: {
            appendMode,
            regenerateReports,
            regenerateSummaries,
            generateAlerts: generateAlertsFlag,
          },
          result,
        },
        ipAddress: extractClientIp(req),
      });

      res.json({
        message: "Workflow executed successfully",
        result,
      });
    } catch (error) {
      console.error("Error executing automated workflow:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  }
);

/**
 * POST /api/workflow/config
 * Create or update workflow configuration
 */
router.post(
  "/config",
  requireAuth,
  requirePermission("reports:generate"),
  async (req: Request, res: Response) => {
    try {
      const user = req.user as any;
      const config = await saveWorkflowConfig({
        ...req.body,
        createdBy: user.id,
      });

      // Log the action
      await storage.createAuditLog({
        userId: user.id,
        action: "workflow:save_config",
        entityType: "workflow_config",
        entityId: config.id,
        details: {
          configName: config.configName,
          monthShamsi: config.monthShamsi,
          yearShamsi: config.yearShamsi,
        },
        ipAddress: extractClientIp(req),
      });

      res.json(config);
    } catch (error) {
      console.error("Error saving workflow config:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  }
);

/**
 * GET /api/workflow/config
 * Get all workflow configurations
 */
router.get(
  "/config",
  requireAuth,
  requirePermission("reports:generate"),
  async (req: Request, res: Response) => {
    try {
      const configs = await getAllWorkflowConfigs();
      res.json(configs);
    } catch (error) {
      console.error("Error getting workflow configs:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  }
);

/**
 * GET /api/workflow/config/:configName
 * Get workflow configuration by name
 */
router.get(
  "/config/:configName",
  requireAuth,
  requirePermission("reports:generate"),
  async (req: Request, res: Response) => {
    try {
      const { configName } = req.params;
      const config = await getWorkflowConfig(configName);
      
      if (!config) {
        return res.status(404).json({ message: "Configuration not found" });
      }
      
      res.json(config);
    } catch (error) {
      console.error("Error getting workflow config:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  }
);

/**
 * POST /api/workflow/scheduled/run
 * Manually trigger scheduled workflows
 */
router.post(
  "/scheduled/run",
  requireAuth,
  requirePermission("reports:generate"),
  async (req: Request, res: Response) => {
    try {
      const user = req.user as any;
      const result = await runScheduledWorkflows();

      // Log the action
      await storage.createAuditLog({
        userId: user.id,
        action: "workflow:run_scheduled",
        entityType: "workflow_automation",
        entityId: "scheduled",
        details: {
          executed: result.executed,
          results: result.results,
        },
        ipAddress: extractClientIp(req),
      });

      res.json({
        message: "Scheduled workflows executed",
        ...result,
      });
    } catch (error) {
      console.error("Error running scheduled workflows:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  }
);

export default router;

