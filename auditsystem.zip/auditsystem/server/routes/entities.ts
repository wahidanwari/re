import { Router, type Request, type Response } from "express";
import { storage } from "../storage";
import { insertEntitySchema } from "@shared/schema";
import { requireAuth } from "../middleware/auth";
import { extractClientIp } from "../utils/ipExtractor";
import { validateShamsiDate, parseDateString } from "../utils/shamsiDate";

const router = Router();

// Get all entities
router.get("/", requireAuth, async (req: Request, res: Response) => {
  try {
    // User data is already refreshed by refreshUserData middleware
    const user = req.user as any;
    if (!user || !user.id) {
      return res.status(401).json({ message: 'احراز هویت نشده' });
    }
    
    // CRITICAL RBAC ENFORCEMENT: Use unified permission helper
    const { getEntityVisibility } = await import('../utils/permissionHelpers');
    const visibility = await getEntityVisibility(user);
    
    // DEBUG LOGGING: Log visibility decision and result count
    if (process.env.DEBUG_LOGGING === 'true') {
      console.log(`[ENTITIES ROUTE] User: ${user.id} (${user.role}), Packages: ${JSON.stringify(user.permissionPackages || [])}, Visibility: canViewAll=${visibility.canViewAll}, requiresFiltering=${visibility.requiresFiltering}, filterByAssignee=${visibility.filterByAssignee}, filterByGroup=${visibility.filterByGroup}`);
    }
    
    let entities: Entity[] = [];
    
    if (visibility.canViewAll) {
      // User can see all entities (coordinator, director, admin)
      entities = await storage.getEntities();
      if (process.env.DEBUG_LOGGING === 'true') {
        console.log(`[ENTITIES ROUTE] Coordinator/Admin access - returning ${entities.length} entities`);
      }
    } else if (visibility.requiresFiltering) {
      if (visibility.filterByAssignee) {
        // Auditor: Get entities linked to assigned cases
        const assignedCases = await storage.getCasesByAssignee(user.id);
        const entityIds = new Set(assignedCases.map(c => c.entityId));
        if (entityIds.size > 0) {
          const allEntities = await storage.getEntities();
          entities = allEntities.filter(entity => entityIds.has(entity.id));
        } else {
          entities = [];
        }
      } else if (visibility.filterByGroup) {
        // Senior auditor: Filter by group
        const allEntities = await storage.getEntities();
        entities = allEntities.filter(entity => entity.referralGroup === visibility.filterByGroup);
      } else {
        // No access
        entities = [];
      }
    } else {
      // No access
      entities = [];
    }
    
    // Set cache control headers to prevent stale data
    res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, private');
    res.setHeader('Pragma', 'no-cache');
    res.setHeader('Expires', '0');
    
    // Log RBAC decision only in debug mode (removes user IDs from production logs)
    if (process.env.DEBUG_LOGGING === 'true') {
      console.log(`[RBAC] GET /entities - User: ${user.role}, GroupId: ${user.groupId ? 'set' : 'none'}, Entities returned: ${entities.length}`);
    }
    
    res.json(entities);
  } catch (error) {
    console.error('Error fetching entities:', error);
    res.status(500).json({ message: "خطا در دریافت لیست نهادها" });
  }
});

// Search entities by TIN (partial match, case-insensitive)
router.get("/search", requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    if (!user || !user.id) {
      return res.status(401).json({ message: 'احراز هویت نشده' });
    }

    const tinQuery = req.query.tin as string;
    if (!tinQuery || tinQuery.trim().length === 0) {
      return res.json([]);
    }

    // Minimum 1 character for search
    if (tinQuery.trim().length < 1) {
      return res.json([]);
    }

    // Apply RBAC filtering first
    const { getEntityVisibility } = await import('../utils/permissionHelpers');
    const visibility = await getEntityVisibility(user);

    let allEntities: Entity[] = [];
    
    if (visibility.canViewAll) {
      // User can see all entities - search all
      allEntities = await storage.searchEntitiesByTin(tinQuery.trim(), 20);
    } else if (visibility.requiresFiltering) {
      // Get filtered entities first, then search within them
      if (visibility.filterByAssignee) {
        const assignedCases = await storage.getCasesByAssignee(user.id);
        const entityIds = new Set(assignedCases.map(c => c.entityId));
        if (entityIds.size > 0) {
          const allEntitiesList = await storage.getEntities();
          const filteredEntities = allEntitiesList.filter(entity => entityIds.has(entity.id));
          // Search within filtered entities
          allEntities = filteredEntities.filter(e => 
            e.tin.toLowerCase().includes(tinQuery.trim().toLowerCase())
          ).slice(0, 20);
        }
      } else if (visibility.filterByGroup) {
        const allEntitiesList = await storage.getEntities();
        const filteredEntities = allEntitiesList.filter(entity => entity.referralGroup === visibility.filterByGroup);
        // Search within filtered entities
        allEntities = filteredEntities.filter(e => 
          e.tin.toLowerCase().includes(tinQuery.trim().toLowerCase())
        ).slice(0, 20);
      }
    } else {
      // No access
      allEntities = [];
    }

    // Return simplified results (TIN + company name for display)
    const results = allEntities.map(e => ({
      id: e.id,
      tin: e.tin,
      companyName: e.companyName,
      businessNature: e.businessNature,
      referralGroup: e.referralGroup,
      registeredAddress: e.registeredAddress,
      contactPerson: e.contactPerson,
      phone: e.phone,
    }));

    res.json(results);
  } catch (error) {
    console.error('Error searching entities:', error);
    res.status(500).json({ message: "خطا در جستجوی نهادها" });
  }
});

// Get entity by ID (with RBAC enforcement)
router.get("/:id", requireAuth, async (req: Request, res: Response) => {
  try {
    // User data is already refreshed by refreshUserData middleware
    const user = req.user as any;
    if (!user || !user.id) {
      return res.status(401).json({ message: 'احراز هویت نشده' });
    }
    
    const entity = await storage.getEntity(req.params.id);
    if (!entity) {
      return res.status(404).json({ message: "نهاد یافت نشد" });
    }
    
    // Use unified permission helper
    const { getEntityVisibility } = await import('../utils/permissionHelpers');
    const visibility = await getEntityVisibility(user);
    
    // RBAC enforcement: Check if user has permission to view entities
    if (user.role !== 'system_admin') {
      // Check effective permissions
      const { getEffectivePermissions } = await import('../services/permissionService');
      const effectivePermissions = await getEffectivePermissions(user.id);
      
      if (!effectivePermissions['entities:view']) {
        return res.status(403).json({ message: 'عدم دسترسی - شما مجوز لازم را ندارید' });
      }
      
      // If coordinator, can view all entities
      if (visibility.canViewAll) {
        // Access granted, continue
      } else if (visibility.filterByAssignee) {
        // Auditor: Check if entity is linked to assigned cases
        const assignedCases = await storage.getCasesByAssignee(user.id);
        const hasAccess = assignedCases.some(c => c.entityId === entity.id);
        if (!hasAccess) {
          return res.status(403).json({ message: 'عدم دسترسی - شما فقط می‌توانید نهادهای مرتبط با قضایای اختصاص داده شده به خود را مشاهده کنید' });
        }
      } else if (visibility.filterByGroup) {
        // Senior auditor: Check if entity belongs to their group
        if (entity.referralGroup !== visibility.filterByGroup) {
          return res.status(403).json({ message: 'عدم دسترسی - شما فقط می‌توانید نهادهای گروه خود را مشاهده کنید' });
        }
      } else {
        // No access
        return res.status(403).json({ message: 'عدم دسترسی' });
      }
    }
    
    res.json(entity);
  } catch (error) {
    res.status(500).json({ message: "خطا در دریافت اطلاعات نهاد" });
  }
});

// Create entity
router.post("/", requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    
    // System admin can create entities for any group, no permission check needed
    if (user.role === 'system_admin') {
      const existingEntity = await storage.getEntityByTin(req.body.tin);
      if (existingEntity) {
        return res.status(400).json({ message: "نهاد با این نمبر تشخیصیه (TIN) قبلاً ثبت شده است" });
      }
      
      // Convert createdDate from string (Gregorian YYYY-MM-DD or Shamsi YYYY/MM/DD) to timestamp if provided
      const entityData = { ...req.body };
      if (entityData.createdDate && typeof entityData.createdDate === 'string') {
        console.log('[DEBUG] Received createdDate:', entityData.createdDate, 'Type:', typeof entityData.createdDate);
        // Validate date (accepts both formats)
        const validation = validateShamsiDate(entityData.createdDate);
        if (!validation.valid) {
          console.log('[DEBUG] Validation failed:', validation.error);
          return res.status(400).json({ message: validation.error });
        }
        // Parse and convert to Date object for timestamp storage
        const { date: dateObj, format } = parseDateString(entityData.createdDate);
        console.log('[DEBUG] Parsed date:', dateObj, 'Format:', format);
        if (dateObj) {
          entityData.createdDate = dateObj;
        } else {
          return res.status(400).json({ message: 'خطا در تبدیل تاریخ' });
        }
      }
      
    let validatedData;
    try {
      validatedData = insertEntitySchema.parse(entityData);
    } catch (validationError: any) {
      // Handle Zod validation errors
      if (validationError.errors && Array.isArray(validationError.errors)) {
        const errorMessages = validationError.errors.map((err: any) => {
          const field = err.path?.join('.') || 'field';
          return `${field}: ${err.message}`;
        }).join(', ');
        return res.status(400).json({ 
          message: `خطا در اعتبارسنجی داده‌ها: ${errorMessages}`,
          errors: validationError.errors 
        });
      }
      return res.status(400).json({ 
        message: `خطا در اعتبارسنجی داده‌ها: ${validationError.message || 'داده‌های ارسالی نامعتبر است'}` 
      });
    }
    
    let newEntity;
    try {
      newEntity = await storage.createEntity(validatedData);
    } catch (dbError: any) {
      console.error('Database error creating entity:', dbError);
      
      // Check for duplicate TIN constraint
      if (dbError.code === '23505' || dbError.message?.includes('unique') || dbError.message?.includes('duplicate')) {
        if (dbError.message?.includes('tin') || dbError.constraint?.includes('tin')) {
          return res.status(400).json({ 
            message: 'نهاد با این نمبر تشخیصیه (TIN) قبلاً ثبت شده است' 
          });
        }
        return res.status(400).json({ 
          message: 'این نهاد قبلاً وجود دارد. لطفاً اطلاعات را بررسی کنید.' 
        });
      }
      
      // Check for foreign key constraint errors
      if (dbError.code === '23503' || dbError.message?.includes('foreign key')) {
        return res.status(400).json({ 
          message: 'خطا در ارتباط با داده‌های مرتبط. لطفاً اطلاعات را بررسی کنید.' 
        });
      }
      
      // Check for not null constraint errors
      if (dbError.code === '23502' || dbError.message?.includes('not null')) {
        const field = dbError.column || 'field';
        return res.status(400).json({ 
          message: `فیلد ${field} الزامی است و نمی‌تواند خالی باشد.` 
        });
      }
      
      // Generic database error
      return res.status(400).json({ 
        message: `خطا در ایجاد نهاد در پایگاه داده: ${dbError.message || 'خطای ناشناخته'}` 
      });
    }
    
    try {
      await storage.createAuditLog({
        userId: user.id,
        action: 'create_entity',
        entityType: 'entity',
        entityId: newEntity.id,
        newValue: newEntity,
        ipAddress: extractClientIp(req),
      });
    } catch (logError) {
      // Log error but don't fail entity creation
      console.error('Failed to create audit log for entity creation:', logError);
    }
    
    return res.status(201).json(newEntity);
    }
    
    const { userHasPermission } = await import('../middleware/permissions');
    
    // Check if user has entities:create permission
    const hasCreate = await userHasPermission(user, 'entities:create');
    if (!hasCreate) {
      return res.status(403).json({ message: 'عدم دسترسی - شما مجوز ایجاد نهاد را ندارید' });
    }
    
    // Apply restrictions for non-system-admin users
    if (user.role !== 'system_admin') {
      // Get effective permissions
      const { getEffectivePermissions } = await import('../services/permissionService');
      const effectivePermissions = await getEffectivePermissions(user.id);
      
      // Use unified permission helper to check coordinator status
      const { isCoordinator } = await import('../services/permissionService');
      const coordinatorCheck = await isCoordinator(user.id);
      
      // If senior_auditor (and not coordinator), ensure referralGroup matches their group
      if (user.role === 'senior_auditor' && user.groupId && !coordinatorCheck) {
        if (req.body.referralGroup !== user.groupId) {
          return res.status(403).json({ message: 'شما فقط می‌توانید نهاد برای گروه خود ایجاد کنید' });
        }
      }
    }
    
    const existingEntity = await storage.getEntityByTin(req.body.tin);
    if (existingEntity) {
      return res.status(400).json({ message: "نهاد با این نمبر تشخیصیه (TIN) قبلاً ثبت شده است" });
    }
    
    // Convert createdDate from string (Gregorian YYYY-MM-DD or Shamsi YYYY/MM/DD) to timestamp if provided
    const entityData = { ...req.body };
    if (entityData.createdDate && typeof entityData.createdDate === 'string') {
      console.log('[DEBUG] Received createdDate:', entityData.createdDate, 'Type:', typeof entityData.createdDate);
      // Validate date (accepts both formats)
      const validation = validateShamsiDate(entityData.createdDate);
      if (!validation.valid) {
        console.log('[DEBUG] Validation failed:', validation.error);
        return res.status(400).json({ message: validation.error });
      }
      // Parse and convert to Date object for timestamp storage
      const { date: dateObj, format } = parseDateString(entityData.createdDate);
      console.log('[DEBUG] Parsed date:', dateObj, 'Format:', format);
      if (dateObj) {
        entityData.createdDate = dateObj;
      } else {
        return res.status(400).json({ message: 'خطا در تبدیل تاریخ' });
      }
    }
    
    let validatedData;
    try {
      validatedData = insertEntitySchema.parse(entityData);
    } catch (validationError: any) {
      // Handle Zod validation errors
      if (validationError.errors && Array.isArray(validationError.errors)) {
        const errorMessages = validationError.errors.map((err: any) => {
          const field = err.path?.join('.') || 'field';
          return `${field}: ${err.message}`;
        }).join(', ');
        return res.status(400).json({ 
          message: `خطا در اعتبارسنجی داده‌ها: ${errorMessages}`,
          errors: validationError.errors 
        });
      }
      return res.status(400).json({ 
        message: `خطا در اعتبارسنجی داده‌ها: ${validationError.message || 'داده‌های ارسالی نامعتبر است'}` 
      });
    }
    
    let newEntity;
    try {
      newEntity = await storage.createEntity(validatedData);
    } catch (dbError: any) {
      console.error('Database error creating entity:', dbError);
      
      // Check for duplicate TIN constraint
      if (dbError.code === '23505' || dbError.message?.includes('unique') || dbError.message?.includes('duplicate')) {
        if (dbError.message?.includes('tin') || dbError.constraint?.includes('tin')) {
          return res.status(400).json({ 
            message: 'نهاد با این نمبر تشخیصیه (TIN) قبلاً ثبت شده است' 
          });
        }
        return res.status(400).json({ 
          message: 'این نهاد قبلاً وجود دارد. لطفاً اطلاعات را بررسی کنید.' 
        });
      }
      
      // Check for foreign key constraint errors
      if (dbError.code === '23503' || dbError.message?.includes('foreign key')) {
        return res.status(400).json({ 
          message: 'خطا در ارتباط با داده‌های مرتبط. لطفاً اطلاعات را بررسی کنید.' 
        });
      }
      
      // Check for not null constraint errors
      if (dbError.code === '23502' || dbError.message?.includes('not null')) {
        const field = dbError.column || 'field';
        return res.status(400).json({ 
          message: `فیلد ${field} الزامی است و نمی‌تواند خالی باشد.` 
        });
      }
      
      // Generic database error
      return res.status(400).json({ 
        message: `خطا در ایجاد نهاد در پایگاه داده: ${dbError.message || 'خطای ناشناخته'}` 
      });
    }
    
    try {
      await storage.createAuditLog({
        userId: user.id,
        action: 'create_entity',
        entityType: 'entity',
        entityId: newEntity.id,
        newValue: newEntity,
        ipAddress: extractClientIp(req),
      });
    } catch (logError) {
      // Log error but don't fail entity creation
      console.error('Failed to create audit log for entity creation:', logError);
    }
    
    res.status(201).json(newEntity);
  } catch (error: any) {
    console.error('Unexpected error creating entity:', error);
    res.status(500).json({ 
      message: `خطا در ایجاد نهاد: ${error.message || 'خطای ناشناخته'}` 
    });
  }
});

// Update entity
router.put("/:id", requireAuth, async (req: Request, res: Response) => {
  try {
    const oldEntity = await storage.getEntity(req.params.id);
    if (!oldEntity) {
      return res.status(404).json({ message: "نهاد یافت نشد" });
    }
    
    if (req.body.tin && req.body.tin !== oldEntity.tin) {
      const existingEntity = await storage.getEntityByTin(req.body.tin);
      if (existingEntity) {
        return res.status(400).json({ message: "نمبر تشخیصیه (TIN) قبلاً استفاده شده است" });
      }
    }
    
    const updatedEntity = await storage.updateEntity(req.params.id, req.body);
    if (!updatedEntity) {
      return res.status(404).json({ message: "نهاد یافت نشد" });
    }
    
    await storage.createAuditLog({
      userId: (req.user as any).id,
      action: 'update_entity',
      entityType: 'entity',
      entityId: updatedEntity.id,
      oldValue: oldEntity,
      newValue: updatedEntity,
      ipAddress: extractClientIp(req),
    });
    
    res.json(updatedEntity);
  } catch (error) {
    res.status(400).json({ message: "خطا در بروزرسانی نهاد" });
  }
});

// Delete entity
router.delete("/:id", requireAuth, async (req: Request, res: Response) => {
  try {
    const oldEntity = await storage.getEntity(req.params.id);
    if (!oldEntity) {
      return res.status(404).json({ message: "نهاد یافت نشد" });
    }
    
    await storage.deleteEntity(req.params.id);
    
    await storage.createAuditLog({
      userId: (req.user as any).id,
      action: 'delete_entity',
      entityType: 'entity',
      entityId: req.params.id,
      oldValue: oldEntity,
      ipAddress: extractClientIp(req),
    });
    
    res.json({ message: "نهاد با موفقیت حذف شد" });
  } catch (error: any) {
    console.error(error);
    res.status(400).json({ message: error.message || "خطا در حذف نهاد" });
  }
});

export default router;
