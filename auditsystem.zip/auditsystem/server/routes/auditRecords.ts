import { Router, type Request, type Response } from "express";
import { storage } from "../storage";
import { insertAuditRecordSchema, type AuditRecord, type Entity } from "@shared/schema";
import { requireAuth } from "../middleware/auth";
import { requirePermission } from "../middleware/permissions";
import { extractClientIp } from "../utils/ipExtractor";

const router = Router();

// Get all audit records (with optional filters)
router.get("/", requireAuth, async (req: Request, res: Response) => {
  try {
    const entityId = req.query.entityId as string | undefined;
    const yearFrom = req.query.yearFrom ? parseInt(req.query.yearFrom as string, 10) : undefined;
    const yearTo = req.query.yearTo ? parseInt(req.query.yearTo as string, 10) : undefined;
    const status = req.query.status as string | undefined;
    const auditGroupId = req.query.auditGroupId as string | undefined;
    
    const filters = {
      yearFrom,
      yearTo,
      status,
      auditGroupId,
    };
    
    const records = await storage.getAuditRecords(entityId, filters);
    
    // Enrich with entity and user details
    const enrichedRecords = await Promise.all(
      records.map(async (record) => {
        const entity = await storage.getEntity(record.entityId);
        const responsibleEvaluator = record.responsibleEvaluator ? await storage.getUser(record.responsibleEvaluator) : null;
        const auditGroup = record.auditGroupId ? await storage.getGroup(record.auditGroupId) : null;
        const createdByUser = record.createdByUserId ? await storage.getUser(record.createdByUserId) : null;
        
        return {
          ...record,
          entity: entity ? {
            id: entity.id,
            companyName: entity.companyName,
            tin: entity.tin,
          } : null,
          responsibleEvaluatorUser: responsibleEvaluator ? {
            id: responsibleEvaluator.id,
            fullName: responsibleEvaluator.fullName,
            auditId: responsibleEvaluator.auditId,
          } : null,
          auditGroupInfo: auditGroup ? {
            id: auditGroup.id,
            name: auditGroup.name,
            code: auditGroup.code,
          } : null,
          createdByUser: createdByUser ? {
            id: createdByUser.id,
            fullName: createdByUser.fullName,
          } : null,
        };
      })
    );
    
    res.json(enrichedRecords);
  } catch (error) {
    console.error('Error fetching audit records:', error);
    res.status(500).json({ message: "خطا در دریافت سوابق بررسی" });
  }
});

// Get audit records for a specific entity
router.get("/entities/:entityId/audits", requireAuth, async (req: Request, res: Response) => {
  try {
    const entityId = req.params.entityId;
    const page = parseInt(req.query.page as string || '1', 10);
    const limit = parseInt(req.query.limit as string || '50', 10);
    const status = req.query.status as string | undefined;
    
    // Validate entity exists
    const entity = await storage.getEntity(entityId);
    if (!entity) {
      return res.status(404).json({ message: "نهاد یافت نشد" });
    }
    
    const filters = status ? { status } : undefined;
    const records = await storage.getAuditRecordsByEntity(entityId);
    
    // Filter by status if provided
    const filteredRecords = status 
      ? records.filter(r => r.status === status)
      : records;
    
    // Apply pagination
    const startIndex = (page - 1) * limit;
    const endIndex = startIndex + limit;
    const paginatedRecords = filteredRecords.slice(startIndex, endIndex);
    
    // Enrich with user and group details
    const enrichedRecords = await Promise.all(
      paginatedRecords.map(async (record) => {
        const responsibleEvaluator = record.responsibleEvaluator ? await storage.getUser(record.responsibleEvaluator) : null;
        const auditGroup = record.auditGroupId ? await storage.getGroup(record.auditGroupId) : null;
        const createdByUser = record.createdByUserId ? await storage.getUser(record.createdByUserId) : null;
        
        return {
          ...record,
          responsibleEvaluatorUser: responsibleEvaluator ? {
            id: responsibleEvaluator.id,
            fullName: responsibleEvaluator.fullName,
            auditId: responsibleEvaluator.auditId,
          } : null,
          auditGroupInfo: auditGroup ? {
            id: auditGroup.id,
            name: auditGroup.name,
            code: auditGroup.code,
          } : null,
          createdByUser: createdByUser ? {
            id: createdByUser.id,
            fullName: createdByUser.fullName,
          } : null,
        };
      })
    );
    
    res.json({
      records: enrichedRecords,
      pagination: {
        page,
        limit,
        total: filteredRecords.length,
        totalPages: Math.ceil(filteredRecords.length / limit),
      },
    });
  } catch (error) {
    console.error('Error fetching audit records by entity:', error);
    res.status(500).json({ message: "خطا در دریافت سوابق بررسی" });
  }
});

// Get audit record by ID
router.get("/:id", requireAuth, async (req: Request, res: Response) => {
  try {
    const record = await storage.getAuditRecord(req.params.id);
    if (!record) {
      return res.status(404).json({ message: "سابقه بررسی یافت نشد" });
    }
    
    // Enrich with related data
    const entity = await storage.getEntity(record.entityId);
    const responsibleEvaluator = record.responsibleEvaluator ? await storage.getUser(record.responsibleEvaluator) : null;
    const auditGroup = record.auditGroupId ? await storage.getGroup(record.auditGroupId) : null;
    const createdByUser = record.createdByUserId ? await storage.getUser(record.createdByUserId) : null;
    const history = await storage.getAuditRecordHistory(record.id);
    
    // Enrich history with user details
    const enrichedHistory = await Promise.all(
      history.map(async (entry) => {
        const changedByUser = await storage.getUser(entry.changedBy);
        return {
          ...entry,
          changedByUser: changedByUser ? {
            id: changedByUser.id,
            fullName: changedByUser.fullName,
            role: changedByUser.role,
          } : null,
        };
      })
    );
    
    res.json({
      ...record,
      entity: entity || null,
      responsibleEvaluatorUser: responsibleEvaluator ? {
        id: responsibleEvaluator.id,
        fullName: responsibleEvaluator.fullName,
        auditId: responsibleEvaluator.auditId,
      } : null,
      auditGroupInfo: auditGroup ? {
        id: auditGroup.id,
        name: auditGroup.name,
        code: auditGroup.code,
      } : null,
      createdByUser: createdByUser ? {
        id: createdByUser.id,
        fullName: createdByUser.fullName,
      } : null,
      history: enrichedHistory,
    });
  } catch (error) {
    console.error('Error fetching audit record:', error);
    res.status(500).json({ message: "خطا در دریافت سابقه بررسی" });
  }
});

// Create audit record for an entity
router.post("/entities/:entityId/audits", requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    const entityId = req.params.entityId;
    const { auditYears, referringGroup, referralDate, yearFrom, yearTo, assignedGroup, responsibleEvaluator, notes } = req.body;
    
    // Validate required fields
    if (!auditYears || auditYears.trim() === '') {
      return res.status(400).json({ 
        message: "سال‌های بررسی الزامی است" 
      });
    }
    
    if (!referringGroup) {
      return res.status(400).json({ 
        message: "گروه ارجاع‌دهنده الزامی است" 
      });
    }
    
    if (!referralDate) {
      return res.status(400).json({ 
        message: "تاریخ ارجاع به بررسی الزامی است" 
      });
    }
    
    // Parse auditYears to extract yearFrom/yearTo
    let yearFromNum: number;
    let yearToNum: number;
    
    if (yearFrom !== undefined && yearTo !== undefined) {
      // Use provided yearFrom/yearTo if available
      yearFromNum = parseInt(yearFrom, 10);
      yearToNum = parseInt(yearTo, 10);
    } else {
      // Parse from auditYears text
      const cleaned = auditYears.replace(/[–—]/g, '-');
      if (cleaned.includes('-')) {
        const parts = cleaned.split('-').map(s => s.trim());
        yearFromNum = parseInt(parts[0], 10);
        yearToNum = parseInt(parts[1] || parts[0], 10);
      } else {
        const year = parseInt(cleaned, 10);
        yearFromNum = year;
        yearToNum = year;
      }
    }
    
    if (isNaN(yearFromNum) || isNaN(yearToNum)) {
      return res.status(400).json({ 
        message: "سال‌های بررسی نامعتبر است. فرمت صحیح: \"1400\" یا \"1392-1400\"" 
      });
    }
    
    // Validate year range
    if (yearFromNum > yearToNum) {
      return res.status(400).json({ 
        message: "سال شروع باید کمتر یا مساوی سال پایان باشد" 
      });
    }
    
    // Validate entity exists
    const entity = await storage.getEntity(entityId);
    if (!entity) {
      return res.status(404).json({ message: "نهاد یافت نشد" });
    }
    
    // Check for overlapping ranges
    const overlaps = await storage.checkAuditRecordOverlap(entityId, yearFromNum, yearToNum);
    if (overlaps.length > 0) {
      return res.status(409).json({ 
        message: "بازه سالی تداخل دارد",
        conflicts: overlaps.map(overlap => ({
          id: overlap.id,
          yearFrom: overlap.yearFrom,
          yearTo: overlap.yearTo,
          status: overlap.status,
          auditGroupId: overlap.auditGroupId,
        })),
        requestedRange: {
          yearFrom: yearFromNum,
          yearTo: yearToNum,
        }
      });
    }
    
    // Validate assigned group if provided
    if (assignedGroup) {
      const group = await storage.getGroup(assignedGroup);
      if (!group) {
        return res.status(400).json({ message: "گروه اختصاص داده شده یافت نشد" });
      }
    }
    
    // Validate responsible evaluator if provided
    if (responsibleEvaluator) {
      const evaluator = await storage.getUser(responsibleEvaluator);
      if (!evaluator) {
        return res.status(400).json({ message: "بررس مسئول یافت نشد" });
      }
    }
    
    // Create audit record
    const recordData = {
      entityId,
      auditYears: auditYears.trim(),
      referringGroup: referringGroup || null,
      referralDate: referralDate ? new Date(referralDate) : null,
      yearFrom: yearFromNum,
      yearTo: yearToNum,
      assignedGroup: assignedGroup || null,
      assignedAt: new Date(),
      createdByUserId: user.id,
      status: 'in-progress' as const,
      notes: notes || null,
      responsibleEvaluator: responsibleEvaluator || null,
    };
    
    const validatedData = insertAuditRecordSchema.parse(recordData);
    const newRecord = await storage.createAuditRecord(validatedData);
    
    // Create history entry
    await storage.createAuditRecordHistory({
      auditRecordId: newRecord.id,
      version: 1,
      changedBy: user.id,
      changeType: 'create',
      changes: { created: newRecord },
      snapshot: newRecord as any,
      notes: 'سابقه بررسی ایجاد شد',
    });
    
    // Create audit log
    await storage.createAuditLog({
      userId: user.id,
      action: 'create_audit_record',
      entityType: 'audit_record',
      entityId: newRecord.id,
        details: {
          auditRecord: newRecord,
          entity: {
            id: entity.id,
            companyName: entity.companyName,
            tin: entity.tin,
          },
          auditYears: auditYears,
          yearRange: `${yearFromNum}-${yearToNum}`,
        },
      ipAddress: extractClientIp(req),
    });
    
    // Notify assigned group members if group is assigned
    if (assignedGroup) {
      const groupMembers = await storage.getGroupMembers(assignedGroup);
      const activeMembers = groupMembers.filter(m => m.isActive);
      
      for (const member of activeMembers) {
        try {
          await storage.createNotification({
            userId: member.userId,
            message: `سابقه بررسی جدید برای نهاد ${entity.companyName} (${auditYears}) به گروه شما اختصاص داده شد`,
            messagePashto: `نوی بررسی سابقه د ${entity.companyName} نهاد لپاره (${auditYears}) ستاسو ډلې ته تعیین شوه`,
            type: 'audit_assignment',
          });
        } catch (error) {
          console.error(`Failed to notify group member ${member.userId}:`, error);
        }
      }
    }
    
    res.status(201).json(newRecord);
  } catch (error: any) {
    console.error('Error creating audit record:', error);
    if (error.message?.includes('Overlapping')) {
      return res.status(409).json({ 
        message: error.message 
      });
    }
    if (error.code === '23505') { // Unique constraint violation
      return res.status(409).json({ 
        message: "سابقه بررسی برای این نهاد و بازه سالی قبلاً ایجاد شده است" 
      });
    }
    res.status(400).json({ message: error.message || "خطا در ایجاد سابقه بررسی" });
  }
});

// Update audit record
router.patch("/:id", requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    const record = await storage.getAuditRecord(req.params.id);
    
    if (!record) {
      return res.status(404).json({ message: "سابقه بررسی یافت نشد" });
    }
    
    // Prevent edits to critical fields when status == completed
    if (record.status === 'completed') {
      // Only allow updating notes for completed audits
      const allowedFields = ['notes'];
      const updateData: any = {};
      for (const field of allowedFields) {
        if (req.body[field] !== undefined) {
          updateData[field] = req.body[field];
        }
      }
      
      if (Object.keys(updateData).length === 0) {
        return res.status(400).json({ 
          message: "نمی‌توان فیلدهای سابقه بررسی تکمیل شده را تغییر داد (به جز یادداشت‌ها)" 
        });
      }
      
      const updatedRecord = await storage.updateAuditRecord(req.params.id, updateData);
      return res.json(updatedRecord);
    }
    
    // Get old values for history
    const oldValues = { ...record };
    
    // Prepare update data
    const updateData: any = {};
    
    // Handle auditYears update
    if (req.body.auditYears !== undefined) {
      const auditYears = req.body.auditYears.trim();
      if (!auditYears) {
        return res.status(400).json({ 
          message: "سال‌های بررسی نمی‌تواند خالی باشد" 
        });
      }
      
      // Parse auditYears to extract yearFrom/yearTo
      let newYearFrom: number;
      let newYearTo: number;
      const cleaned = auditYears.replace(/[–—]/g, '-');
      if (cleaned.includes('-')) {
        const parts = cleaned.split('-').map(s => s.trim());
        newYearFrom = parseInt(parts[0], 10);
        newYearTo = parseInt(parts[1] || parts[0], 10);
      } else {
        const year = parseInt(cleaned, 10);
        newYearFrom = year;
        newYearTo = year;
      }
      
      if (isNaN(newYearFrom) || isNaN(newYearTo)) {
        return res.status(400).json({ 
          message: "سال‌های بررسی نامعتبر است. فرمت صحیح: \"1400\" یا \"1392-1400\"" 
        });
      }
      
      // Validate year range
      if (newYearFrom > newYearTo) {
        return res.status(400).json({ 
          message: "سال شروع باید کمتر یا مساوی سال پایان باشد" 
        });
      }
      
      // Check for overlaps
      const overlaps = await storage.checkAuditRecordOverlap(record.entityId, newYearFrom, newYearTo, record.id);
      if (overlaps.length > 0) {
        return res.status(409).json({ 
          message: "بازه سالی تداخل دارد",
          conflicts: overlaps.map(overlap => ({
            id: overlap.id,
            auditYears: overlap.auditYears || `${overlap.yearFrom}-${overlap.yearTo}`,
            status: overlap.status,
          })),
        });
      }
      
      updateData.auditYears = auditYears;
      updateData.yearFrom = newYearFrom;
      updateData.yearTo = newYearTo;
    } else if (req.body.yearFrom !== undefined || req.body.yearTo !== undefined) {
      // Legacy support: if yearFrom/yearTo provided without auditYears
      const newYearFrom = req.body.yearFrom ?? record.yearFrom;
      const newYearTo = req.body.yearTo ?? record.yearTo;
      
      // Validate year range
      if (newYearFrom > newYearTo) {
        return res.status(400).json({ 
          message: "سال شروع باید کمتر یا مساوی سال پایان باشد" 
        });
      }
      
      // Check for overlaps
      const overlaps = await storage.checkAuditRecordOverlap(record.entityId, newYearFrom, newYearTo, record.id);
      if (overlaps.length > 0) {
        return res.status(409).json({ 
          message: "بازه سالی تداخل دارد",
          conflicts: overlaps.map(overlap => ({
            id: overlap.id,
            auditYears: overlap.auditYears || `${overlap.yearFrom}-${overlap.yearTo}`,
            status: overlap.status,
          })),
        });
      }
      
      updateData.yearFrom = newYearFrom;
      updateData.yearTo = newYearTo;
      // Generate auditYears from yearFrom/yearTo if not provided
      if (!record.auditYears) {
        updateData.auditYears = newYearFrom === newYearTo ? newYearFrom.toString() : `${newYearFrom}-${newYearTo}`;
      }
    }
    
    if (req.body.referringGroup !== undefined) {
      updateData.referringGroup = req.body.referringGroup || null;
    }
    
    if (req.body.referralDate !== undefined) {
      updateData.referralDate = req.body.referralDate ? new Date(req.body.referralDate) : null;
    }
    
    if (req.body.status !== undefined) {
      updateData.status = req.body.status;
      // Update timestamps based on status
      if (req.body.status === 'in_progress' && !record.assignedAt) {
        updateData.assignedAt = new Date();
      }
      if (req.body.status === 'completed' && !record.completedAt) {
        updateData.completedAt = new Date();
      }
    }
    
    if (req.body.assignedGroup !== undefined) {
      if (req.body.assignedGroup) {
        const group = await storage.getGroup(req.body.assignedGroup);
        if (!group) {
          return res.status(400).json({ message: "گروه اختصاص داده شده یافت نشد" });
        }
      }
      updateData.assignedGroup = req.body.assignedGroup || null;
    }
    
    if (req.body.responsibleEvaluator !== undefined) {
      if (req.body.responsibleEvaluator) {
        const evaluator = await storage.getUser(req.body.responsibleEvaluator);
        if (!evaluator) {
          return res.status(400).json({ message: "بررس مسئول یافت نشد" });
        }
      }
      updateData.responsibleEvaluator = req.body.responsibleEvaluator || null;
    }
    
    if (req.body.notes !== undefined) {
      updateData.notes = req.body.notes;
    }
    
    // Update audit record
    const updatedRecord = await storage.updateAuditRecord(req.params.id, updateData);
    
    if (!updatedRecord) {
      return res.status(404).json({ message: "سابقه بررسی یافت نشد" });
    }
    
    // Create history entry
    const changes: any = {};
    if (updateData.auditYears !== undefined) {
      changes.auditYears = { 
        from: oldValues.auditYears || `${oldValues.yearFrom}-${oldValues.yearTo}`, 
        to: updateData.auditYears
      };
      changes.yearRange = { 
        from: `${oldValues.yearFrom}-${oldValues.yearTo}`, 
        to: `${updatedRecord.yearFrom}-${updatedRecord.yearTo}` 
      };
    } else if (updateData.yearFrom !== undefined || updateData.yearTo !== undefined) {
      changes.yearRange = { 
        from: `${oldValues.yearFrom}-${oldValues.yearTo}`, 
        to: `${updatedRecord.yearFrom}-${updatedRecord.yearTo}` 
      };
    }
    if (updateData.referringGroup !== undefined) {
      changes.referringGroup = { from: oldValues.referringGroup, to: updateData.referringGroup };
    }
    if (updateData.referralDate !== undefined) {
      changes.referralDate = { from: oldValues.referralDate, to: updateData.referralDate };
    }
    if (updateData.status !== undefined) {
      changes.status = { from: oldValues.status, to: updateData.status };
    }
    if (updateData.assignedGroup !== undefined) {
      changes.assignedGroup = { from: oldValues.assignedGroup, to: updateData.assignedGroup };
    }
    if (updateData.responsibleEvaluator !== undefined) {
      changes.responsibleEvaluator = { from: oldValues.responsibleEvaluator, to: updateData.responsibleEvaluator };
    }
    if (updateData.notes !== undefined) {
      changes.notes = { from: oldValues.notes, to: updateData.notes };
    }
    
    // Get current version
    const history = await storage.getAuditRecordHistory(req.params.id);
    const currentVersion = history.length > 0 ? Math.max(...history.map(h => h.version)) + 1 : 1;
    
    await storage.createAuditRecordHistory({
      auditRecordId: req.params.id,
      version: currentVersion,
      changedBy: user.id,
      changeType: Object.keys(changes).length === 1 && changes.status ? 'status_change' : 'update',
      changes,
      snapshot: updatedRecord as any,
      notes: req.body.changeNotes || null,
    });
    
    // Create audit log
    await storage.createAuditLog({
      userId: user.id,
      action: 'update_audit_record',
      entityType: 'audit_record',
      entityId: updatedRecord.id,
      details: {
        oldValues,
        newValues: updatedRecord,
        changes,
      },
      ipAddress: extractClientIp(req),
    });
    
    res.json(updatedRecord);
  } catch (error: any) {
    console.error('Error updating audit record:', error);
    if (error.message?.includes('Overlapping')) {
      return res.status(409).json({ 
        message: error.message 
      });
    }
    res.status(400).json({ message: error.message || "خطا در بروزرسانی سابقه بررسی" });
  }
});

// Complete audit record
router.post("/:id/complete", requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    const record = await storage.getAuditRecord(req.params.id);
    
    if (!record) {
      return res.status(404).json({ message: "سابقه بررسی یافت نشد" });
    }
    
    if (record.status === 'completed') {
      return res.status(400).json({ 
        message: "این سابقه بررسی قبلاً تکمیل شده است" 
      });
    }
    
    // Complete the audit record
    const completedRecord = await storage.completeAuditRecord(req.params.id, user.id);
    
    if (!completedRecord) {
      return res.status(404).json({ message: "سابقه بررسی یافت نشد" });
    }
    
    // Create history entry
    const history = await storage.getAuditRecordHistory(req.params.id);
    const currentVersion = history.length > 0 ? Math.max(...history.map(h => h.version)) + 1 : 1;
    
    await storage.createAuditRecordHistory({
      auditRecordId: req.params.id,
      version: currentVersion,
      changedBy: user.id,
      changeType: 'status_change',
      changes: { status: { from: record.status, to: 'completed' } },
      snapshot: completedRecord as any,
      notes: 'سابقه بررسی تکمیل شد',
    });
    
    // Create audit log
    await storage.createAuditLog({
      userId: user.id,
      action: 'complete_audit_record',
      entityType: 'audit_record',
      entityId: completedRecord.id,
      details: {
        oldStatus: record.status,
        newStatus: 'completed',
        completedAt: completedRecord.completedAt,
      },
      ipAddress: extractClientIp(req),
    });
    
    res.json(completedRecord);
  } catch (error) {
    console.error('Error completing audit record:', error);
    res.status(400).json({ message: "خطا در تکمیل سابقه بررسی" });
  }
});

// Delete audit record
router.delete("/:id", requireAuth, requirePermission('users:manage'), async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    const record = await storage.getAuditRecord(req.params.id);
    
    if (!record) {
      return res.status(404).json({ message: "سابقه بررسی یافت نشد" });
    }
    
    // Prevent deletion of completed audits
    if (record.status === 'completed') {
      return res.status(400).json({ 
        message: "نمی‌توان سابقه بررسی تکمیل شده را حذف کرد" 
      });
    }
    
    const deleted = await storage.deleteAuditRecord(req.params.id);
    
    if (!deleted) {
      return res.status(404).json({ message: "سابقه بررسی یافت نشد" });
    }
    
    // Create audit log
    await storage.createAuditLog({
      userId: user.id,
      action: 'delete_audit_record',
      entityType: 'audit_record',
      entityId: req.params.id,
      details: {
        deletedRecord: record,
      },
      ipAddress: extractClientIp(req),
    });
    
    res.json({ message: "سابقه بررسی حذف شد" });
  } catch (error) {
    console.error('Error deleting audit record:', error);
    res.status(500).json({ message: "خطا در حذف سابقه بررسی" });
  }
});

// Get audit record history
router.get("/:id/history", requireAuth, async (req: Request, res: Response) => {
  try {
    const record = await storage.getAuditRecord(req.params.id);
    if (!record) {
      return res.status(404).json({ message: "سابقه بررسی یافت نشد" });
    }
    
    const history = await storage.getAuditRecordHistory(req.params.id);
    
    // Enrich with user details
    const enrichedHistory = await Promise.all(
      history.map(async (entry) => {
        const changedByUser = await storage.getUser(entry.changedBy);
        return {
          ...entry,
          changedByUser: changedByUser ? {
            id: changedByUser.id,
            fullName: changedByUser.fullName,
            role: changedByUser.role,
            auditId: changedByUser.auditId,
          } : null,
        };
      })
    );
    
    res.json({
      auditRecordId: req.params.id,
      history: enrichedHistory,
    });
  } catch (error) {
    console.error('Error fetching audit record history:', error);
    res.status(500).json({ message: "خطا در دریافت تاریخچه سابقه بررسی" });
  }
});

export default router;
