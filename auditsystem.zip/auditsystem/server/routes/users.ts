import { Router, type Request, type Response } from "express";
import { storage } from "../storage";
import { insertUserSchema } from "@shared/schema";
import { requireAuth } from "../middleware/auth";
import { requirePermission } from "../middleware/permissions";
import { generateAuditId, generateRandomPassword } from "../utils/idGenerator";
import { extractClientIp } from "../utils/ipExtractor";
import { getWebSocketServer } from "../websocket";

const router = Router();

// Get all users (with role-based access)
router.get("/", requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    
    // System admin and director can see all users
    if (user.role === 'system_admin' || user.role === 'director') {
      const users = await storage.getUsers();
      const groups = await storage.getGroups();
      const groupsMap = new Map(groups.map(g => [g.id, g.name]));
      
      const usersWithoutPasswords = users.map(({ password, ...user }) => {
        const groupName = user.groupId ? groupsMap.get(user.groupId) : null;
        return {
          ...user,
          groupName: groupName || null,
        };
      });
      return res.json(usersWithoutPasswords);
    }
    
    // Senior auditor can see users in their own group
    if (user.role === 'senior_auditor' && user.groupId) {
      const { isCoordinator } = await import('../services/permissionService');
      const coordinatorCheck = await isCoordinator(user.id);
      
      // If coordinator, can see all users
      if (coordinatorCheck) {
        const users = await storage.getUsers();
        const groups = await storage.getGroups();
        const groupsMap = new Map(groups.map(g => [g.id, g.name]));
        
        const usersWithoutPasswords = users.map(({ password, ...user }) => {
          const groupName = user.groupId ? groupsMap.get(user.groupId) : null;
          return {
            ...user,
            groupName: groupName || null,
          };
        });
        return res.json(usersWithoutPasswords);
      }
      
      // Regular senior auditor: only users in their group
      const allUsers = await storage.getUsers();
      const groupUsers = allUsers.filter(u => u.groupId === user.groupId);
      const groups = await storage.getGroups();
      const groupsMap = new Map(groups.map(g => [g.id, g.name]));
      
      const usersWithoutPasswords = groupUsers.map(({ password, ...user }) => {
        const groupName = user.groupId ? groupsMap.get(user.groupId) : null;
        return {
          ...user,
          groupName: groupName || null,
        };
      });
      return res.json(usersWithoutPasswords);
    }
    
    // Auditor cannot access /api/users
    return res.status(403).json({ message: 'عدم دسترسی - شما مجوز مشاهده لیست کاربران را ندارید' });
  } catch (error) {
    console.error('Error fetching users:', error);
    res.status(500).json({ message: "خطا در دریافت لیست کاربران" });
  }
});

// Get user by ID
router.get("/:id", requireAuth, async (req: Request, res: Response) => {
  try {
    const user = await storage.getUser(req.params.id);
    if (!user) {
      return res.status(404).json({ message: "کاربر یافت نشد" });
    }
    const { password, ...userWithoutPassword } = user;
    res.json(userWithoutPassword);
  } catch (error) {
    res.status(500).json({ message: "خطا در دریافت اطلاعات کاربر" });
  }
});

// Get effective permissions for a specific user (requires users:manage permission)
router.get("/:id/effective-permissions", requireAuth, requirePermission('users:manage'), async (req: Request, res: Response) => {
  try {
    const { getEffectivePermissions, computeModulesFromPermissions } = await import('../services/permissionService');
    const permissions = await getEffectivePermissions(req.params.id);
    
    // Calculate modules list using helper function
    const modules = computeModulesFromPermissions(permissions);
    
    // Get user to include permissionsVersion
    const user = await storage.getUser(req.params.id);
    const permissionsVersion = user?.permissionsVersion || 1;
    
    res.json({
      permissions,
      modules,
      permissionsVersion,
      role: user?.role,
      packages: user?.permissionPackages || [],
      calculatedAt: new Date().toISOString(),
    });
  } catch (error) {
    console.error('Error getting effective permissions:', error);
    res.status(500).json({ message: 'خطا در دریافت مجوزها' });
  }
});

// Create user (requires users:manage permission)
router.post("/", requireAuth, requirePermission('users:manage'), async (req: Request, res: Response) => {
  try {
    const auditId = await generateAuditId();
    const generatedPassword = generateRandomPassword();
    
    // Set password to expire in 24 hours
    const passwordExpiresAt = new Date();
    passwordExpiresAt.setHours(passwordExpiresAt.getHours() + 24);
    
    const userData = {
      ...req.body,
      auditId,
      password: generatedPassword,
      mustChangePassword: true,
      passwordExpiresAt,
    };
    
    let validatedData;
    try {
      validatedData = insertUserSchema.parse(userData);
    } catch (validationError: any) {
      // Handle Zod validation errors
      if (validationError.errors && Array.isArray(validationError.errors)) {
        const errorMessages = validationError.errors.map((err: any) => {
          const field = err.path?.join('.') || 'field';
          return `${field}: ${err.message}`;
        }).join(', ');
        return res.status(400).json({ 
          message: `خطا در اعتبارسنجی داده‌ها: ${errorMessages}`,
          errors: validationError.errors 
        });
      }
      return res.status(400).json({ 
        message: `خطا در اعتبارسنجی داده‌ها: ${validationError.message || 'داده‌های ارسالی نامعتبر است'}` 
      });
    }
    
    let newUser;
    try {
      newUser = await storage.createUser(validatedData);
    } catch (dbError: any) {
      // Handle database constraint errors
      console.error('Database error creating user:', dbError);
      
      // Check for duplicate auditId constraint
      if (dbError.code === '23505' || dbError.message?.includes('unique') || dbError.message?.includes('duplicate')) {
        if (dbError.message?.includes('audit_id') || dbError.constraint?.includes('audit_id')) {
          return res.status(400).json({ 
            message: 'کاربر با این شناسه بررسی قبلاً وجود دارد. لطفاً شناسه دیگری انتخاب کنید.' 
          });
        }
        return res.status(400).json({ 
          message: 'این کاربر قبلاً وجود دارد. لطفاً اطلاعات را بررسی کنید.' 
        });
      }
      
      // Check for foreign key constraint errors
      if (dbError.code === '23503' || dbError.message?.includes('foreign key')) {
        if (dbError.message?.includes('group_id')) {
          return res.status(400).json({ 
            message: 'گروه انتخاب شده معتبر نیست یا وجود ندارد.' 
          });
        }
        return res.status(400).json({ 
          message: 'خطا در ارتباط با داده‌های مرتبط. لطفاً اطلاعات را بررسی کنید.' 
        });
      }
      
      // Check for not null constraint errors
      if (dbError.code === '23502' || dbError.message?.includes('not null')) {
        const field = dbError.column || 'field';
        return res.status(400).json({ 
          message: `فیلد ${field} الزامی است و نمی‌تواند خالی باشد.` 
        });
      }
      
      // Generic database error
      return res.status(400).json({ 
        message: `خطا در ایجاد کاربر در پایگاه داده: ${dbError.message || 'خطای ناشناخته'}` 
      });
    }
    
    const { password, ...userWithoutPassword } = newUser;
    
    try {
      await storage.createAuditLog({
        userId: (req.user as any).id,
        action: 'create_user',
        entityType: 'user',
        entityId: newUser.id,
        newValue: userWithoutPassword,
        ipAddress: extractClientIp(req),
      });
    } catch (logError) {
      // Log error but don't fail user creation
      console.error('Failed to create audit log for user creation:', logError);
    }
    
    res.status(201).json({
      user: userWithoutPassword,
      auditId,
      password: generatedPassword,
      message: `کاربر ایجاد شد. رمز عبور اولیه: ${generatedPassword}. لطفاً در اولین ورود رمز عبور را تغییر دهید.`,
    });
  } catch (error: any) {
    console.error('Unexpected error creating user:', error);
    res.status(500).json({ 
      message: `خطا در ایجاد کاربر: ${error.message || 'خطای ناشناخته'}` 
    });
  }
});

// Update user
router.put("/:id", requireAuth, requirePermission('users:manage'), async (req: Request, res: Response) => {
  try {
    const oldUser = await storage.getUser(req.params.id);
    if (!oldUser) {
      return res.status(404).json({ message: "کاربر یافت نشد" });
    }
    
    // Validate and sanitize input data
    const allowedFields = ['fullName', 'role', 'groupId', 'phoneNumber', 'permissionPackages', 'isActive', 'emailNotifications', 'mobileNotifications', 'preferredLanguage'];
    const updateData: any = {};
    
    // Only include allowed fields and validate them
    for (const field of allowedFields) {
      if (req.body[field] !== undefined) {
        // Validate role
        if (field === 'role' && req.body[field]) {
          const validRoles = ['system_admin', 'director', 'senior_auditor', 'auditor'];
          if (!validRoles.includes(req.body[field])) {
            return res.status(400).json({ 
              message: `نقش نامعتبر است. نقش باید یکی از موارد زیر باشد: ${validRoles.join(', ')}` 
            });
          }
        }
        
        // Validate permissionPackages is an array
        if (field === 'permissionPackages' && req.body[field] !== null) {
          if (!Array.isArray(req.body[field])) {
            return res.status(400).json({ 
              message: 'بسته‌های دسترسی باید به صورت آرایه ارسال شوند' 
            });
          }
        }
        
        // Validate groupId if provided (must be valid UUID or empty string)
        if (field === 'groupId' && req.body[field] !== null && req.body[field] !== '') {
          // Basic UUID validation
          const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
          if (!uuidRegex.test(req.body[field])) {
            return res.status(400).json({ 
              message: 'شناسه گروه نامعتبر است' 
            });
          }
        }
        
        // Validate fullName is not empty
        if (field === 'fullName' && req.body[field] !== null && req.body[field] !== undefined) {
          if (typeof req.body[field] !== 'string' || req.body[field].trim().length === 0) {
            return res.status(400).json({ 
              message: 'نام کامل نمی‌تواند خالی باشد' 
            });
          }
        }
        
        updateData[field] = req.body[field];
      }
    }
    
    // Check if role or permission packages are being changed
    const roleChanged = updateData.role && updateData.role !== oldUser.role;
    const packagesChanged = updateData.permissionPackages !== undefined && 
      JSON.stringify(updateData.permissionPackages) !== JSON.stringify(oldUser.permissionPackages);
    const groupIdChanged = updateData.groupId !== undefined && updateData.groupId !== oldUser.groupId;
    const permissionChanged = roleChanged || packagesChanged || groupIdChanged;
    
    // If permissions changed, increment permissions_version
    if (permissionChanged) {
      const currentVersion = oldUser.permissionsVersion || 1;
      updateData.permissionsVersion = currentVersion + 1;
    }
    
    // CRITICAL: Bi-directional sync - If groupId is being changed, sync with group_members table
    if (groupIdChanged) {
      const oldGroupId = oldUser.groupId;
      const newGroupId = req.body.groupId;
      
      // Remove user from old group's members (if exists)
      if (oldGroupId) {
        try {
          await storage.removeGroupMember(oldGroupId, req.params.id);
        } catch (error) {
          // Ignore if member doesn't exist
          console.log(`User ${req.params.id} was not a member of group ${oldGroupId}`);
        }
      }
      
      // Add user to new group's members (if new group is specified)
      if (newGroupId) {
        try {
          // Check if user is already a member
          const existingMembers = await storage.getGroupMembers(newGroupId);
          const isAlreadyMember = existingMembers.some(m => m.userId === req.params.id && m.isActive);
          
          if (!isAlreadyMember) {
            // Determine assigned role based on user's role (use new role if changed, otherwise old role)
            const userRole = req.body.role || oldUser.role;
            const assignedRole = userRole === 'senior_auditor' ? 'senior_auditor' : 'auditor';
            
            await storage.addGroupMember({
              groupId: newGroupId,
              userId: req.params.id,
              assignedRole: assignedRole,
            });
          }
        } catch (error) {
          console.error(`Failed to add user ${req.params.id} to group ${newGroupId}:`, error);
          // Continue with user update even if group member sync fails
        }
      }
    }
    
    let updatedUser;
    try {
      updatedUser = await storage.updateUser(req.params.id, updateData);
      if (!updatedUser) {
        return res.status(404).json({ message: "کاربر یافت نشد" });
      }
    } catch (dbError: any) {
      console.error('Database error updating user:', dbError);
      
      // Check for duplicate auditId constraint (if auditId was changed)
      if (dbError.code === '23505' || dbError.message?.includes('unique') || dbError.message?.includes('duplicate')) {
        if (dbError.message?.includes('audit_id') || dbError.constraint?.includes('audit_id')) {
          return res.status(400).json({ 
            message: 'کاربر با این شناسه بررسی قبلاً وجود دارد. لطفاً شناسه دیگری انتخاب کنید.' 
          });
        }
        return res.status(400).json({ 
          message: 'این کاربر قبلاً وجود دارد. لطفاً اطلاعات را بررسی کنید.' 
        });
      }
      
      // Check for foreign key constraint errors
      if (dbError.code === '23503' || dbError.message?.includes('foreign key')) {
        if (dbError.message?.includes('group_id')) {
          return res.status(400).json({ 
            message: 'گروه انتخاب شده معتبر نیست یا وجود ندارد.' 
          });
        }
        return res.status(400).json({ 
          message: 'خطا در ارتباط با داده‌های مرتبط. لطفاً اطلاعات را بررسی کنید.' 
        });
      }
      
      // Check for not null constraint errors
      if (dbError.code === '23502' || dbError.message?.includes('not null')) {
        const field = dbError.column || 'field';
        return res.status(400).json({ 
          message: `فیلد ${field} الزامی است و نمی‌تواند خالی باشد.` 
        });
      }
      
      // Generic database error
      return res.status(400).json({ 
        message: `خطا در بروز رسانی کاربر در پایگاه داده: ${dbError.message || 'خطای ناشناخته'}` 
      });
    }
    
    // CRITICAL: Get fresh user data with updated permissions
    const freshUser = await storage.getUser(updatedUser.id);
    if (!freshUser) {
      return res.status(404).json({ message: "کاربر یافت نشد" });
    }
    
    const { password: oldPassword, ...oldUserWithoutPassword } = oldUser;
    const { password, ...userWithoutPassword } = freshUser;
    
    // If permissions changed, get effective permissions and modules
    let effectivePermissions = null;
    let modules = null;
    if (permissionChanged) {
      try {
        const { getEffectivePermissions } = await import('../services/permissionService');
        effectivePermissions = await getEffectivePermissions(updatedUser.id);
        
        // Determine which modules should be visible based on permissions
        modules = [];
        if (effectivePermissions['entities:view']) modules.push('entities');
        if (effectivePermissions['cases:view']) modules.push('cases');
        if (effectivePermissions['users:manage']) modules.push('users');
        if (effectivePermissions['groups:manage']) modules.push('groups');
        if (effectivePermissions['groups:set_targets']) modules.push('target-settings');
        if (effectivePermissions['tickets:submit'] || effectivePermissions['tickets:approve']) modules.push('tickets');
        if (effectivePermissions['cases:view']) modules.push('documents');
        if (effectivePermissions['settings:manage']) modules.push('settings');
        if (effectivePermissions['logs:view']) modules.push('audit-logs');
      } catch (error) {
        console.error('Failed to get effective permissions:', error);
      }
      
      // Log the permission change for audit
      await storage.createAuditLog({
        userId: (req.user as any).id,
        action: 'update_user_permissions',
        entityType: 'user',
        entityId: updatedUser.id,
        details: {
          permissionChange: true,
          roleChanged: roleChanged ? { old: oldUser.role, new: updatedUser.role } : undefined,
          packagesChanged: packagesChanged ? { 
            old: oldUser.permissionPackages, 
            new: updatedUser.permissionPackages 
          } : undefined,
          groupIdChanged: groupIdChanged ? { old: oldUser.groupId, new: updatedUser.groupId } : undefined,
          permissionsVersion: {
            old: oldUser.permissionsVersion || 1,
            new: updatedUser.permissionsVersion || 1,
          },
          effectivePermissions: effectivePermissions,
          modules: modules,
          message: 'Permissions have been updated. User should refresh session to apply changes.',
        },
        ipAddress: extractClientIp(req),
      });
      
      // CRITICAL: Send real-time notification to user to refresh permissions
      // Get wsServer in function scope so it's accessible throughout
      let wsServer;
      try {
        wsServer = getWebSocketServer();
        if (wsServer) {
          wsServer.notifyPermissionChange(req.params.id);
        }
      } catch (error) {
        console.error('Failed to send permission change notification:', error);
      }
      
      // Handle session invalidation/regeneration based on who is being updated
      const currentUserId = (req.user as any)?.id;
      
      if (updatedUser.id === currentUserId) {
        // Current user updated their own permissions - regenerate session
        // This ensures they get updated permissions without re-login
        try {
          const { regenerateUserSession } = await import('../utils/sessionUtils');
          await regenerateUserSession(req);
          req.user = freshUser;
          req.session.save((err) => {
            if (err) {
              console.error('Failed to save session after permission update:', err);
            } else {
              console.log(`Session regenerated for current user ${updatedUser.id}`);
            }
          });
        } catch (error) {
          console.error('Failed to regenerate current user session:', error);
          // Fallback: just update req.user without regenerating session
          req.user = freshUser;
        }
      } else {
        // Another user's permissions were updated
        // Optionally invalidate their session (configurable via env var)
        const shouldInvalidate = process.env.INVALIDATE_SESSION_ON_PERMISSION_CHANGE === 'true';
        
        if (shouldInvalidate) {
          try {
            const { invalidateUserSession } = await import('../utils/sessionUtils');
            const invalidatedCount = await invalidateUserSession(updatedUser.id);
            console.log(`Invalidated ${invalidatedCount} session(s) for user ${updatedUser.id}`);
            
            // Send session invalidated notification
            if (wsServer) {
              wsServer.notifySessionInvalidated(updatedUser.id);
            }
          } catch (error) {
            console.error('Failed to invalidate user session:', error);
            // Continue with permission change notification even if invalidation fails
          }
        }
        
        // Always send permission change notification
        if (wsServer) {
          wsServer.notifyPermissionChange(updatedUser.id);
        }
        
        console.log(`Permissions updated for user ${updatedUser.id}. WebSocket notification sent.`);
      }
    }
    
    await storage.createAuditLog({
      userId: (req.user as any).id,
      action: 'update_user',
      entityType: 'user',
      entityId: updatedUser.id,
      oldValue: oldUserWithoutPassword,
      newValue: userWithoutPassword,
      ipAddress: extractClientIp(req),
    });
    
    // Return user data with effective permissions and modules if permissions changed
    // CRITICAL: Always return fresh user data with updated permissions
    if (permissionChanged && effectivePermissions && modules) {
      // Convert effectivePermissions to array for frontend
      const effectivePermissionsList = Object.entries(effectivePermissions)
        .filter(([_, has]) => has)
        .map(([perm]) => perm);
      
      res.json({
        ...userWithoutPassword,
        effectivePermissions: effectivePermissionsList, // Array format for frontend
        effectivePermissionsObject: effectivePermissions, // Object format for detailed checks
        modules,
        permissionsChanged: true,
        message: 'User updated successfully. Permissions have been refreshed.',
      });
    } else {
      res.json({
        ...userWithoutPassword,
        message: 'User updated successfully.',
      });
    }
  } catch (error: any) {
    console.error('Unexpected error updating user:', error);
    // If error is already handled (has status), don't override
    if (error.status) {
      throw error;
    }
    res.status(500).json({ 
      message: `خطا در بروزرسانی کاربر: ${error.message || 'خطای ناشناخته'}` 
    });
  }
});

// Reset password
router.post("/:id/reset-password", requireAuth, requirePermission('users:manage'), async (req: Request, res: Response) => {
  try {
    const newPassword = generateRandomPassword();
    
    // Set password to expire in 24 hours
    const passwordExpiresAt = new Date();
    passwordExpiresAt.setHours(passwordExpiresAt.getHours() + 24);
    
    const updatedUser = await storage.updateUser(req.params.id, {
      password: newPassword,
      mustChangePassword: true,
      passwordExpiresAt,
    });
    
    if (!updatedUser) {
      return res.status(404).json({ message: "کاربر یافت نشد" });
    }
    
    await storage.createAuditLog({
      userId: (req.user as any).id,
      action: 'reset_password',
      entityType: 'user',
      entityId: updatedUser.id,
      ipAddress: extractClientIp(req),
    });
    
    res.json({
      message: "رمز عبور بازنشانی شد. رمز جدید ظرف ۲۴ ساعت منقضی خواهد شد",
      password: newPassword,
    });
  } catch (error) {
    res.status(500).json({ message: "خطا در بازنشانی رمز عبور" });
  }
});

// Deactivate user
router.post("/:id/deactivate", requireAuth, requirePermission('users:manage'), async (req: Request, res: Response) => {
  try {
    const user = await storage.getUser(req.params.id);
    if (!user) {
      return res.status(404).json({ message: "کاربر یافت نشد" });
    }
    
    await storage.deactivateUser(req.params.id);
    
    await storage.createAuditLog({
      userId: (req.user as any).id,
      action: 'deactivate_user',
      entityType: 'user',
      entityId: req.params.id,
      ipAddress: extractClientIp(req),
    });
    
    res.json({ message: "کاربر غیرفعال شد" });
  } catch (error) {
    res.status(500).json({ message: "خطا در غیرفعال کردن کاربر" });
  }
});

// Activate user
router.post("/:id/activate", requireAuth, requirePermission('users:manage'), async (req: Request, res: Response) => {
  try {
    const user = await storage.getUser(req.params.id);
    if (!user) {
      return res.status(404).json({ message: "کاربر یافت نشد" });
    }
    
    await storage.activateUser(req.params.id);
    
    await storage.createAuditLog({
      userId: (req.user as any).id,
      action: 'activate_user',
      entityType: 'user',
      entityId: req.params.id,
      ipAddress: extractClientIp(req),
    });
    
    res.json({ message: "کاربر فعال شد" });
  } catch (error) {
    res.status(500).json({ message: "خطا در فعال کردن کاربر" });
  }
});

// Delete user (requires users:manage permission - only System Admin has this)
router.delete("/:id", requireAuth, requirePermission('users:manage'), async (req: Request, res: Response) => {
  try {
    const user = await storage.getUser(req.params.id);
    if (!user) {
      return res.status(404).json({ message: "کاربر یافت نشد" });
    }
    
    // Store user info for audit log before deletion
    const { password, ...userWithoutPassword } = user;
    
    await storage.deleteUser(req.params.id);
    
    await storage.createAuditLog({
      userId: (req.user as any).id,
      action: 'delete_user',
      entityType: 'user',
      entityId: req.params.id,
      details: {
        deletedUser: userWithoutPassword,
      },
      ipAddress: extractClientIp(req),
    });
    
    res.json({ message: "کاربر با موفقیت حذف شد" });
  } catch (error: any) {
    if (error.message && (error.message.includes('قضایای مرتبط') || error.message.includes('تکت‌های در حال بررسی'))) {
      return res.status(400).json({ message: error.message });
    }
    console.error('Error deleting user:', error);
    res.status(500).json({ message: error.message || "خطا در حذف کاربر" });
  }
});

// Clear all users except system admin (admin only - requires special permission)
// This deletes all non-admin users while preserving audit logs
router.post("/clear-all", requireAuth, requirePermission('users:manage'), async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    
    // Only system admin can clear all users
    if (user.role !== 'system_admin') {
      return res.status(403).json({ 
        message: 'فقط مدیر سیستم می‌تواند تمام کاربران را پاک کند' 
      });
    }
    
    // Get all users except system admin and the current user
    const allUsers = await storage.getUsers();
    const usersToDelete = allUsers.filter(u => 
      u.role !== 'system_admin' && u.id !== user.id
    );
    
    // Check for cases assigned to users
    const allCases = await storage.getCases();
    const casesWithUsers = allCases.filter(c => c.assignedTo);
    const assignedUserIds = new Set(casesWithUsers.map(c => c.assignedTo));
    
    // Filter out users with assigned cases
    const usersWithCases = usersToDelete.filter(u => assignedUserIds.has(u.id));
    
    if (usersWithCases.length > 0) {
      return res.status(400).json({ 
        message: `نمی‌توان ${usersWithCases.length} کاربر را پاک کرد زیرا دارای قضایای اختصاص داده شده هستند. لطفاً ابتدا قضایا را واگذار یا حذف کنید.`
      });
    }
    
    // Check for pending tickets created by users
    const allTickets = await storage.getTickets();
    const pendingTickets = allTickets.filter(t => 
      t.status === 'منتظر تایید' && usersToDelete.some(u => u.id === t.requestedBy)
    );
    
    if (pendingTickets.length > 0) {
      return res.status(400).json({ 
        message: `نمی‌توان کاربران را پاک کرد زیرا ${pendingTickets.length} تکت منتظر تایید وجود دارد. لطفاً ابتدا تکت‌ها را پردازش کنید.`
      });
    }
    
    // Delete each user (this will handle related data through deleteUser method)
    const deletedUsers = [];
    const errors = [];
    
    for (const userToDelete of usersToDelete) {
      try {
        await storage.deleteUser(userToDelete.id);
        deletedUsers.push({ id: userToDelete.id, auditId: userToDelete.auditId, fullName: userToDelete.fullName });
      } catch (error: any) {
        errors.push({ 
          user: userToDelete.auditId, 
          error: error.message || 'خطا در حذف کاربر'
        });
      }
    }
    
    // Log the action
    await storage.createAuditLog({
      userId: user.id,
      action: 'clear_all_users',
      entityType: 'user',
      entityId: 'all',
      details: {
        usersCleared: deletedUsers.length,
        usersDeleted: deletedUsers,
        errors: errors.length > 0 ? errors : undefined,
        clearedAt: new Date().toISOString(),
      },
      ipAddress: extractClientIp(req),
    });
    
    res.json({ 
      message: `${deletedUsers.length} کاربر با موفقیت پاک شد${errors.length > 0 ? ` (${errors.length} خطا)` : ''}`,
      usersCleared: deletedUsers.length,
      errors: errors.length > 0 ? errors : undefined
    });
  } catch (error) {
    console.error('Error clearing users:', error);
    res.status(500).json({ message: "خطا در پاک کردن کاربران" });
  }
});

// Recompute permissions for a user (requires users:manage permission or self)
router.post("/:id/recompute-permissions", requireAuth, async (req: Request, res: Response) => {
  try {
    const targetUserId = req.params.id;
    const currentUser = req.user as User;
    
    // Check permission: must be admin or self
    const { hasPermission } = await import('../services/permissionService');
    const isAdmin = await hasPermission(currentUser.id, 'users:manage');
    const isSelf = targetUserId === currentUser.id;
    
    if (!isAdmin && !isSelf) {
      return res.status(403).json({ message: 'عدم دسترسی' });
    }
    
    // Get current user data
    const user = await storage.getUser(targetUserId);
    if (!user) {
      return res.status(404).json({ message: 'کاربر یافت نشد' });
    }
    
    // Recompute permissions
    const { getEffectivePermissions, computeModulesFromPermissions } = await import('../services/permissionService');
    const effectivePermissions = await getEffectivePermissions(targetUserId);
    
    // Increment permissionsVersion
    const previousVersion = user.permissionsVersion || 1;
    await storage.updateUser(targetUserId, {
      permissionsVersion: previousVersion + 1
    });
    
    // Get fresh user data with updated version
    const updatedUser = await storage.getUser(targetUserId);
    if (!updatedUser) {
      return res.status(404).json({ message: 'کاربر یافت نشد' });
    }
    
    // Calculate modules list
    const modules = computeModulesFromPermissions(effectivePermissions);
    
    // Invalidate session if not self-update
    if (!isSelf) {
      const { invalidateUserSession } = await import('../utils/sessionUtils');
      await invalidateUserSession(targetUserId);
      
      // Send session invalidated notification
      const wsServer = getWebSocketServer();
      if (wsServer) {
        wsServer.notifySessionInvalidated(targetUserId);
      }
    } else {
      // Send permission change notification for self-update
      const wsServer = getWebSocketServer();
      if (wsServer) {
        wsServer.notifyPermissionChange(targetUserId);
      }
    }
    
    res.json({
      message: 'Permissions recomputed successfully',
      permissions: effectivePermissions,
      modules,
      permissionsVersion: updatedUser.permissionsVersion || previousVersion + 1,
      previousVersion,
    });
  } catch (error) {
    console.error('Error recomputing permissions:', error);
    res.status(500).json({ message: 'خطا در محاسبه مجدد مجوزها' });
  }
});

// Invalidate session for a user (requires users:manage permission, cannot invalidate own session)
router.post("/:id/invalidate-session", requireAuth, requirePermission('users:manage'), async (req: Request, res: Response) => {
  try {
    const targetUserId = req.params.id;
    const currentUser = req.user as User;
    
    // Cannot invalidate own session
    if (targetUserId === currentUser.id) {
      return res.status(400).json({ message: 'برای خروج از حساب خود از دکمه خروج استفاده کنید' });
    }
    
    // Invalidate all sessions for this user
    const { invalidateUserSession } = await import('../utils/sessionUtils');
    const invalidatedCount = await invalidateUserSession(targetUserId);
    
    // Send WebSocket notification
    const wsServer = getWebSocketServer();
    if (wsServer) {
      wsServer.notifySessionInvalidated(targetUserId);
    }
    
    res.json({
      message: 'Session invalidated successfully. User must re-login.',
      userId: targetUserId,
      sessionsInvalidated: invalidatedCount,
    });
  } catch (error) {
    console.error('Error invalidating session:', error);
    res.status(500).json({ message: 'خطا در باطل کردن نشست' });
  }
});

export default router;
