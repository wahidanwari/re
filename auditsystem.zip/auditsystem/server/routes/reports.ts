import { Router, type Request, type Response } from "express";
import { storage } from "../storage";
import { requireAuth } from "../middleware/auth";
import { requirePermission, requireAnyPermission } from "../middleware/permissions";
import ExcelJS from "exceljs";
import PDFDocument from "pdfkit";
import jalaali from "jalaali-js";
import { extractClientIp } from "../utils/ipExtractor";

const router = Router();

function toShamsiDate(date: Date): string {
  const j = jalaali.toJalaali(date);
  return `${j.jy}/${String(j.jm).padStart(2, '0')}/${String(j.jd).padStart(2, '0')}`;
}

// Helper function to safely encode filenames for Content-Disposition header
// Converts to ASCII-only to avoid header encoding issues
// Persian text is preserved in the Excel file content
function encodeFilename(filename: string): string {
  // Convert Persian text to ASCII equivalents
  const asciiFilename = filename
    .replace(/گزارش-داخلی/g, 'internal-report')
    .replace(/همه-گروپها/g, 'all-groups')
    .replace(/[^\x20-\x7E.-]/g, '-') // Replace any non-ASCII with dash
    .replace(/-+/g, '-') // Collapse multiple dashes
    .replace(/^-|-$/g, '') // Remove leading/trailing dashes
    .substring(0, 200); // Limit length
  
  return `attachment; filename="${asciiFilename}"`;
}

router.get("/completed-cases", requireAuth, requirePermission('reports:generate'), async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    const { startDate, endDate, groupId, format = 'excel' } = req.query;
    
    // RBAC enforcement: Use unified permission helper
    const { getCaseVisibility } = await import('../utils/permissionHelpers');
    const visibility = await getCaseVisibility(user);
    
    let allCases: any[] = [];
    if (visibility.canViewAll) {
      // Coordinator, director, or admin can see all cases
      allCases = await storage.getCases();
    } else if (visibility.requiresFiltering) {
      if (visibility.filterByAssignee) {
        // Auditor: Get cases assigned to them
        allCases = await storage.getCasesByAssignee(user.id);
      } else if (visibility.filterByGroup) {
        // Senior auditor: Get cases for their group
        allCases = await storage.getCasesByGroup(visibility.filterByGroup);
      } else {
        // No access
        allCases = [];
      }
    } else {
      // No access
      allCases = [];
    }
    const completedCases = allCases.filter(c => {
      if (c.status !== 'تکمیل شده' && c.status !== 'COMPLETED') return false;
      if (groupId && c.groupReferrer !== groupId) return false;
      if (c.completedAt) {
        if (startDate && new Date(c.completedAt) < new Date(startDate as string)) return false;
        if (endDate && new Date(c.completedAt) > new Date(endDate as string)) return false;
      } else if (!startDate && !endDate) {
        return true;
      } else {
        return false;
      }
      return true;
    });
    
    // Always export to Excel format
    {
      const workbook = new ExcelJS.Workbook();
      const worksheet = workbook.addWorksheet('پرونده‌های تکمیل شده');
      
      // Set RTL direction
      worksheet.views = [{ rightToLeft: true }];
      
      worksheet.columns = [
        { header: 'نمبر قضیه', key: 'caseId', width: 15 },
        { header: 'نام نهاد', key: 'companyName', width: 30 },
        { header: 'نمبر تشخیصیه', key: 'tin', width: 15 },
        { header: 'نوع کسب و کار', key: 'businessNature', width: 15 },
        { header: 'دوره‌های تحت بررسی', key: 'periodsUnderReview', width: 15 },
        { header: 'تاریخ ارجاع', key: 'referralDate', width: 15 },
        { header: 'گروه ارجاع‌دهنده', key: 'groupReferrer', width: 15 },
        { header: 'گروه دریافت‌ کننده', key: 'receivingGroup', width: 15 },
        { header: 'اختصاص داده شده به', key: 'assignedTo', width: 15 },
        { header: 'وضعیت', key: 'status', width: 15 },
        { header: 'تاریخ ایجاد', key: 'createdAt', width: 15 },
        { header: 'تاریخ تکمیل', key: 'completedAt', width: 15 },
        { header: 'تاریخ تایید', key: 'approvedAt', width: 15 },
        { header: 'توضیحات', key: 'notes', width: 15 },
      ];
      
      // Add header row with formatting
      const headerRow = worksheet.addRow([
        'نمبر قضیه',
        'نام نهاد',
        'نمبر تشخیصیه',
        'نوع کسب و کار',
        'دوره‌های تحت بررسی',
        'تاریخ ارجاع',
        'گروه ارجاع‌دهنده',
        'گروه دریافت‌ کننده',
        'اختصاص داده شده به',
        'وضعیت',
        'تاریخ ایجاد',
        'تاریخ تکمیل',
        'تاریخ تایید',
        'توضیحات',
      ]);
      headerRow.font = { name: 'Arial', size: 11, bold: true };
      headerRow.alignment = { horizontal: 'right', vertical: 'middle' };
      headerRow.fill = {
        type: 'pattern',
        pattern: 'solid',
        fgColor: { argb: 'FFD9D9D9' }
      };
      
      completedCases.forEach(caseItem => {
        const row = worksheet.addRow([
          caseItem.caseId,
          caseItem.companyName,
          caseItem.tin,
          caseItem.businessNature || '',
          caseItem.periodsUnderReview || '',
          caseItem.referralDate || '',
          caseItem.groupReferrer || '',
          caseItem.receivingGroup || '',
          caseItem.assignedTo || '',
          caseItem.status || '',
          caseItem.createdAt ? toShamsiDate(new Date(caseItem.createdAt)) : '',
          caseItem.completedAt ? toShamsiDate(new Date(caseItem.completedAt)) : '',
          caseItem.approvedAt ? toShamsiDate(new Date(caseItem.approvedAt)) : '',
          caseItem.notes || '',
        ]);
        // RTL alignment for all cells
        row.eachCell((cell) => {
          cell.alignment = { horizontal: 'right', vertical: 'middle' };
        });
      });
      
      // Encode filename to handle special characters properly
      const encodedFilename = encodeURIComponent(`completed-cases-${Date.now()}.xlsx`);
      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      res.setHeader('Content-Disposition', `attachment; filename="${encodedFilename}"; filename*=UTF-8''${encodedFilename}`);
      
      await workbook.xlsx.write(res);
      res.end();
    }
    
    // Log export action
    await storage.createAuditLog({
      userId: (req.user as any).id,
      action: 'export_report',
      entityType: 'report',
      entityId: 'completed-cases',
      details: {
        reportType: 'completed-cases',
        format: format,
        startDate: startDate,
        endDate: endDate,
        groupId: groupId,
        caseCount: completedCases.length,
      },
      ipAddress: (req as any).ip || req.headers['x-forwarded-for'] as string || req.socket.remoteAddress || 'unknown',
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "خطا در ایجاد گزارش پرونده‌های تکمیل شده" });
  }
});

// Enterprise Reporting Module Endpoints

// Get available report templates
router.get("/templates", requireAuth, requirePermission('reports:generate'), async (req: Request, res: Response) => {
  try {
    const { getReportTemplates } = await import('../services/reportingService');
    const templates = getReportTemplates();
    res.json(templates);
  } catch (error) {
    console.error('Error fetching report templates:', error);
    res.status(500).json({ message: "خطا در دریافت قالب‌های گزارش" });
  }
});

// Run an ad-hoc report
router.post("/run", requireAuth, requirePermission('reports:generate'), async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    const { query, format = 'json' } = req.body;

    if (!query) {
      return res.status(400).json({ message: "پرس‌وجوی گزارش الزامی است" });
    }

    const { buildReportQuery } = await import('../services/reportingService');
    const result = await buildReportQuery(user, query);

    // Log report generation
    await storage.createAuditLog({
      userId: user.id,
      action: 'generate_report',
      entityType: 'report',
      entityId: 'ad-hoc',
      details: {
        reportType: 'ad-hoc',
        format,
        filters: query.filters,
        fieldCount: query.fields.length,
        rowCount: result.data.length,
      },
      ipAddress: extractClientIp(req),
    });

    if (format === 'excel') {
      // Export to Excel
      const workbook = new ExcelJS.Workbook();
      const worksheet = workbook.addWorksheet('گزارش');

      // Set RTL
      worksheet.views = [{ rightToLeft: true }];

      // Add headers
      const headers = query.fields.map((f: any) => f.label);
      worksheet.addRow(headers);
      const headerRow = worksheet.getRow(1);
      headerRow.font = { bold: true };
      headerRow.fill = {
        type: 'pattern',
        pattern: 'solid',
        fgColor: { argb: 'FFD9D9D9' }
      };

      // Add data
      result.data.forEach((row: any) => {
        const values = query.fields.map((f: any) => row[f.key] || '');
        worksheet.addRow(values);
      });

      // Set column widths
      query.fields.forEach((field: any, idx: number) => {
        worksheet.getColumn(idx + 1).width = 20;
      });

      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      // Encode filename to handle special characters properly
      const encodedFilename = encodeURIComponent(`report-${Date.now()}.xlsx`);
      res.setHeader('Content-Disposition', `attachment; filename="${encodedFilename}"; filename*=UTF-8''${encodedFilename}`);
      await workbook.xlsx.write(res);
      res.end();
    } else {
      // Return JSON
      res.json(result);
    }
  } catch (error) {
    console.error('Error running report:', error);
    res.status(500).json({ message: "خطا در اجرای گزارش" });
  }
});

// Schedule a report (basic implementation - stores schedule info)
router.post("/schedule", requireAuth, requirePermission('reports:generate'), async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    const { query, schedule, name, description } = req.body;

    if (!query || !schedule) {
      return res.status(400).json({ message: "پرس‌وجو و زمان‌بندی الزامی است" });
    }

    // Store schedule in system settings (in a real implementation, use a dedicated table)
    const scheduleId = `schedule_${Date.now()}`;
    const scheduleData = {
      id: scheduleId,
      name: name || 'گزارش زمان‌بندی شده',
      description,
      query,
      schedule,
      createdBy: user.id,
      createdAt: new Date().toISOString(),
      enabled: true,
    };

    // For now, just log it (in production, store in DB and use a cron job)
    console.log('Report scheduled:', scheduleData);

    // Log schedule creation
    await storage.createAuditLog({
      userId: user.id,
      action: 'schedule_report',
      entityType: 'report',
      entityId: scheduleId,
      details: scheduleData,
      ipAddress: extractClientIp(req),
    });

    res.json({
      id: scheduleId,
      message: 'گزارش با موفقیت زمان‌بندی شد',
      schedule: scheduleData,
    });
  } catch (error) {
    console.error('Error scheduling report:', error);
    res.status(500).json({ message: "خطا در زمان‌بندی گزارش" });
  }
});

// Get scheduled reports
router.get("/schedules", requireAuth, requirePermission('reports:generate'), async (req: Request, res: Response) => {
  try {
    // In a real implementation, fetch from database
    // For now, return empty array
    res.json([]);
  } catch (error) {
    console.error('Error fetching schedules:', error);
    res.status(500).json({ message: "خطا در دریافت گزارش‌های زمان‌بندی شده" });
  }
});

// ============================================
// MINISTRY OF FINANCE DETAILED AUDIT REPORT
// ============================================

// Get ministry report data for a specific month
router.get("/ministry", requireAuth, requirePermission('reports:generate'), async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    const { month, year, groupId } = req.query;
    
    // RBAC: Director can see all, Senior Auditor only their group, Auditor cannot access
    if (user.role !== 'system_admin' && user.role !== 'director') {
      const { isCoordinator } = await import('../services/permissionService');
      const coordinatorCheck = await isCoordinator(user.id);
      
      if (!coordinatorCheck) {
        if (user.role === 'senior_auditor') {
          // Senior Auditor can only see their own group's ministry report
          if (groupId && groupId !== user.groupId) {
            return res.status(403).json({ 
              message: 'عدم دسترسی - شما فقط می‌توانید گزارش‌های گروه خود را مشاهده کنید' 
            });
          }
        } else if (user.role === 'auditor') {
          return res.status(403).json({ 
            message: 'عدم دسترسی - شما مجوز مشاهده گزارش‌های وزارتی را ندارید' 
          });
        } else {
          return res.status(403).json({ 
            message: 'عدم دسترسی - فقط مدیر و هماهنگ‌کننده می‌توانند این گزارش را مشاهده کنند' 
          });
        }
      }
    }
    
    if (!month || !year) {
      return res.status(400).json({ message: "ماه و سال الزامی است" });
    }
    
    const shamsiMonth = parseInt(month as string);
    const shamsiYear = parseInt(year as string);
    
    if (isNaN(shamsiMonth) || shamsiMonth < 1 || shamsiMonth > 12) {
      return res.status(400).json({ message: "ماه نامعتبر است" });
    }
    
    if (isNaN(shamsiYear) || shamsiYear < 1300 || shamsiYear > 1500) {
      return res.status(400).json({ message: "سال نامعتبر است" });
    }
    
    const { getMinistryReportForMonth } = await import('../services/ministryReportService');
    let reportData = await getMinistryReportForMonth(shamsiMonth, shamsiYear);
    
    // Filter groups based on user role
    if (user.role !== 'system_admin' && user.role !== 'director') {
      const { isCoordinator } = await import('../services/permissionService');
      const coordinatorCheck = await isCoordinator(user.id);
      
      if (!coordinatorCheck) {
        if (user.role === 'senior_auditor' && user.groupId) {
          // Senior Auditor can only see their own group
          reportData = reportData.filter(r => r.groupId === user.groupId);
        } else if (user.role === 'auditor') {
          // Auditor cannot see ministry reports
          reportData = [];
        }
      }
    }
    
    res.json(reportData);
  } catch (error) {
    console.error('Error fetching ministry report:', error);
    res.status(500).json({ message: "خطا در دریافت گزارش" });
  }
});

// Save manual fields for ministry report (PATCH endpoint - only updates provided fields)
router.patch("/ministry/:groupId", requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    const { groupId } = req.params;
    const { month, year, lettersReceived, lettersSent, inquiriesReceived, inquiriesSent, notes } = req.body;
    
    // Role-based access control
    const { isCoordinator } = await import('../services/permissionService');
    const coordinatorCheck = await isCoordinator(user.id);
    
    // Check if user can edit this group's report
    let canEdit = false;
    if (user.role === 'system_admin' || user.role === 'director') {
      canEdit = true; // System Admin and Director can edit any group
    } else if (user.role === 'senior_auditor') {
      // Senior Auditor can only edit their own group (unless coordinator)
      if (coordinatorCheck) {
        canEdit = true;
      } else if (user.groupId === groupId) {
        canEdit = true;
      }
    } else if (coordinatorCheck) {
      canEdit = true; // Coordinator can edit any group
    }
    
    if (!canEdit) {
      return res.status(403).json({ 
        message: 'عدم دسترسی - شما مجوز ویرایش گزارش این گروه را ندارید' 
      });
    }
    
    if (!month || !year) {
      return res.status(400).json({ message: "ماه و سال الزامی است" });
    }
    
    const shamsiMonth = parseInt(month.toString());
    const shamsiYear = parseInt(year.toString());
    
    if (isNaN(shamsiMonth) || shamsiMonth < 1 || shamsiMonth > 12) {
      return res.status(400).json({ message: "ماه نامعتبر است" });
    }
    
    if (isNaN(shamsiYear) || shamsiYear < 1300 || shamsiYear > 1500) {
      return res.status(400).json({ message: "سال نامعتبر است" });
    }
    
    // Verify group exists
    const group = await storage.getGroup(groupId);
    if (!group) {
      return res.status(404).json({ message: "گروه یافت نشد" });
    }
    
    // Get existing report to track old values for audit log
    const existingReport = await storage.getMinistryReport(groupId, shamsiMonth, shamsiYear);
    const oldValues = existingReport ? {
      lettersReceived: existingReport.lettersReceived,
      lettersSent: existingReport.lettersSent,
      inquiriesReceived: existingReport.inquiriesReceived,
      inquiriesSent: existingReport.inquiriesSent,
      notes: existingReport.notes,
    } : null;
    
    // Build update data - only include fields that are provided (PATCH semantics)
    const updateData: any = {
      groupId,
      monthShamsi: shamsiMonth,
      yearShamsi: shamsiYear,
      lastUpdatedBy: user.id,
    };
    
    // Only include fields that are explicitly provided in the request
    if (lettersReceived !== undefined) {
      updateData.lettersReceived = parseInt(lettersReceived.toString()) || 0;
    }
    if (lettersSent !== undefined) {
      updateData.lettersSent = parseInt(lettersSent.toString()) || 0;
    }
    if (inquiriesReceived !== undefined) {
      updateData.inquiriesReceived = parseInt(inquiriesReceived.toString()) || 0;
    }
    if (inquiriesSent !== undefined) {
      updateData.inquiriesSent = parseInt(inquiriesSent.toString()) || 0;
    }
    if (notes !== undefined) {
      updateData.notes = notes || null;
    }
    
    const savedReport = await storage.upsertMinistryReport(updateData);
    
    // Build audit log with old and new values
    const changes: any = {};
    if (lettersReceived !== undefined && oldValues?.lettersReceived !== savedReport.lettersReceived) {
      changes.lettersReceived = { old: oldValues?.lettersReceived ?? 0, new: savedReport.lettersReceived };
    }
    if (lettersSent !== undefined && oldValues?.lettersSent !== savedReport.lettersSent) {
      changes.lettersSent = { old: oldValues?.lettersSent ?? 0, new: savedReport.lettersSent };
    }
    if (inquiriesReceived !== undefined && oldValues?.inquiriesReceived !== savedReport.inquiriesReceived) {
      changes.inquiriesReceived = { old: oldValues?.inquiriesReceived ?? 0, new: savedReport.inquiriesReceived };
    }
    if (inquiriesSent !== undefined && oldValues?.inquiriesSent !== savedReport.inquiriesSent) {
      changes.inquiriesSent = { old: oldValues?.inquiriesSent ?? 0, new: savedReport.inquiriesSent };
    }
    if (notes !== undefined && oldValues?.notes !== savedReport.notes) {
      changes.notes = { old: oldValues?.notes ?? null, new: savedReport.notes };
    }
    
    // Log the action with old/new values
    await storage.createAuditLog({
      userId: user.id,
      action: 'update_ministry_report',
      entityType: 'ministry_report',
      entityId: savedReport.id,
      details: {
        groupId,
        groupName: group.name,
        monthShamsi: shamsiMonth,
        yearShamsi: shamsiYear,
        changes,
        timestamp: new Date().toISOString(),
      },
      ipAddress: extractClientIp(req),
    });
    
    res.json(savedReport);
  } catch (error) {
    console.error('Error saving ministry report:', error);
    res.status(500).json({ message: "خطا در ذخیره گزارش" });
  }
});

// Legacy POST endpoint for backward compatibility (uses same logic as PATCH)
router.post("/ministry/:groupId", requireAuth, async (req: Request, res: Response) => {
  // Call PATCH handler directly by creating a new request with PATCH method
  // We'll duplicate the PATCH logic here to avoid routing issues
  try {
    const user = req.user as any;
    const { groupId } = req.params;
    const { month, year, lettersReceived, lettersSent, inquiriesReceived, inquiriesSent, notes } = req.body;
    
    // Role-based access control (same as PATCH)
    const { isCoordinator } = await import('../services/permissionService');
    const coordinatorCheck = await isCoordinator(user.id);
    
    let canEdit = false;
    if (user.role === 'system_admin' || user.role === 'director') {
      canEdit = true;
    } else if (user.role === 'senior_auditor') {
      if (coordinatorCheck) {
        canEdit = true;
      } else if (user.groupId === groupId) {
        canEdit = true;
      }
    } else if (coordinatorCheck) {
      canEdit = true;
    }
    
    if (!canEdit) {
      return res.status(403).json({ 
        message: 'عدم دسترسی - شما مجوز ویرایش گزارش این گروه را ندارید' 
      });
    }
    
    if (!month || !year) {
      return res.status(400).json({ message: "ماه و سال الزامی است" });
    }
    
    const shamsiMonth = parseInt(month.toString());
    const shamsiYear = parseInt(year.toString());
    
    if (isNaN(shamsiMonth) || shamsiMonth < 1 || shamsiMonth > 12) {
      return res.status(400).json({ message: "ماه نامعتبر است" });
    }
    
    if (isNaN(shamsiYear) || shamsiYear < 1300 || shamsiYear > 1500) {
      return res.status(400).json({ message: "سال نامعتبر است" });
    }
    
    const group = await storage.getGroup(groupId);
    if (!group) {
      return res.status(404).json({ message: "گروه یافت نشد" });
    }
    
    const existingReport = await storage.getMinistryReport(groupId, shamsiMonth, shamsiYear);
    const oldValues = existingReport ? {
      lettersReceived: existingReport.lettersReceived,
      lettersSent: existingReport.lettersSent,
      inquiriesReceived: existingReport.inquiriesReceived,
      inquiriesSent: existingReport.inquiriesSent,
      notes: existingReport.notes,
    } : null;
    
    const updateData: any = {
      groupId,
      monthShamsi: shamsiMonth,
      yearShamsi: shamsiYear,
      lastUpdatedBy: user.id,
    };
    
    if (lettersReceived !== undefined) {
      updateData.lettersReceived = parseInt(lettersReceived.toString()) || 0;
    }
    if (lettersSent !== undefined) {
      updateData.lettersSent = parseInt(lettersSent.toString()) || 0;
    }
    if (inquiriesReceived !== undefined) {
      updateData.inquiriesReceived = parseInt(inquiriesReceived.toString()) || 0;
    }
    if (inquiriesSent !== undefined) {
      updateData.inquiriesSent = parseInt(inquiriesSent.toString()) || 0;
    }
    if (notes !== undefined) {
      updateData.notes = notes || null;
    }
    
    const savedReport = await storage.upsertMinistryReport(updateData);
    
    const changes: any = {};
    if (lettersReceived !== undefined && oldValues?.lettersReceived !== savedReport.lettersReceived) {
      changes.lettersReceived = { old: oldValues?.lettersReceived ?? 0, new: savedReport.lettersReceived };
    }
    if (lettersSent !== undefined && oldValues?.lettersSent !== savedReport.lettersSent) {
      changes.lettersSent = { old: oldValues?.lettersSent ?? 0, new: savedReport.lettersSent };
    }
    if (inquiriesReceived !== undefined && oldValues?.inquiriesReceived !== savedReport.inquiriesReceived) {
      changes.inquiriesReceived = { old: oldValues?.inquiriesReceived ?? 0, new: savedReport.inquiriesReceived };
    }
    if (inquiriesSent !== undefined && oldValues?.inquiriesSent !== savedReport.inquiriesSent) {
      changes.inquiriesSent = { old: oldValues?.inquiriesSent ?? 0, new: savedReport.inquiriesSent };
    }
    if (notes !== undefined && oldValues?.notes !== savedReport.notes) {
      changes.notes = { old: oldValues?.notes ?? null, new: savedReport.notes };
    }
    
    await storage.createAuditLog({
      userId: user.id,
      action: 'update_ministry_report',
      entityType: 'ministry_report',
      entityId: savedReport.id,
      details: {
        groupId,
        groupName: group.name,
        monthShamsi: shamsiMonth,
        yearShamsi: shamsiYear,
        changes,
        timestamp: new Date().toISOString(),
      },
      ipAddress: extractClientIp(req),
    });
    
    res.json(savedReport);
  } catch (error) {
    console.error('Error saving ministry report:', error);
    res.status(500).json({ message: "خطا در ذخیره گزارش" });
  }
});

// Export ministry report to Excel
router.get("/ministry/export", requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    const { month, year, groupId } = req.query;
    
    // Role-based access control for export
    const { isCoordinator } = await import('../services/permissionService');
    const coordinatorCheck = await isCoordinator(user.id);
    
    let canExport = false;
    let allowedGroupId: string | null = null;
    
    if (user.role === 'system_admin' || user.role === 'director') {
      canExport = true; // System Admin and Director can export all groups
    } else if (coordinatorCheck) {
      canExport = true; // Coordinator can export all groups
    } else if (user.role === 'senior_auditor') {
      // Senior Auditor can only export their own group
      if (user.groupId) {
        canExport = true;
        allowedGroupId = user.groupId;
        if (groupId && groupId !== user.groupId) {
          return res.status(403).json({ 
            message: 'عدم دسترسی - شما فقط می‌توانید گزارش‌های گروه خود را صادر کنید' 
          });
        }
      }
    } else if (user.role === 'auditor') {
      return res.status(403).json({ 
        message: 'عدم دسترسی - شما مجوز صادر کردن گزارش‌های وزارتی را ندارید' 
      });
    }
    
    if (!canExport) {
      return res.status(403).json({ 
        message: 'عدم دسترسی - شما مجوز صادر کردن گزارش را ندارید' 
      });
    }
    if (!month || !year) {
      return res.status(400).json({ message: "ماه و سال الزامی است" });
    }
    
    const shamsiMonth = parseInt(month as string);
    const shamsiYear = parseInt(year as string);
    
    if (isNaN(shamsiMonth) || shamsiMonth < 1 || shamsiMonth > 12) {
      return res.status(400).json({ message: "ماه نامعتبر است" });
    }
    
    if (isNaN(shamsiYear) || shamsiYear < 1300 || shamsiYear > 1500) {
      return res.status(400).json({ message: "سال نامعتبر است" });
    }
    
    const { getMinistryReportForMonth } = await import('../services/ministryReportService');
    let reportData = await getMinistryReportForMonth(shamsiMonth, shamsiYear);
    
    // Filter by groupId if user is limited to their group
    if (allowedGroupId) {
      reportData = reportData.filter(r => r.groupId === allowedGroupId);
    } else if (groupId) {
      // Filter by requested groupId if provided
      reportData = reportData.filter(r => r.groupId === groupId);
    }
    
    // Month names in Dari
    const monthNames = ['', 'حمل', 'ثور', 'جوزا', 'سرطان', 'اسد', 'سنبله', 'میزان', 'عقرب', 'قوس', 'جدی', 'دلو', 'حوت'];
    const monthName = monthNames[shamsiMonth] || shamsiMonth.toString();
    
    // Create workbook
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet('گزارش تفصیلی مرکز');
    
    // Set RTL direction
    worksheet.views = [{ rightToLeft: true }];
    
    // Main header
    const mainHeader = `جدول گزارش تفصیلی آمریت بررسی مستوفیت ولایت هرات بابت برج ${monthName} سال مالی ${shamsiYear}`;
    
    // Add main header (row 1)
    worksheet.mergeCells(1, 1, 1, 15);
    const headerCell = worksheet.getCell(1, 1);
    headerCell.value = mainHeader;
    headerCell.font = { name: 'Arial', size: 14, bold: true };
    headerCell.alignment = { horizontal: 'center', vertical: 'middle' };
    headerCell.fill = {
      type: 'pattern',
      pattern: 'solid',
      fgColor: { argb: 'FFE0E0E0' }
    };
    
    // Column headers
    const headers = [
      'شماره',
      'گروپ مربوطه',
      'تعداد نهاد/شرکت های توزیع شده طی برج جاری',
      'تعداد نهاد/شرکت های نهائی شده طی برج جاری',
      'تعداد نهاد/شرکت های قسط شده طی برج جاری',
      'تعداد نهاد/شرکت های عدم اطاعت پذیر',
      'تعداد نهاد/شرکت های تحت بررسی',
      'هدف ماهوار عوایدی',
      'عواید جمع آوری شده طی برج جاری',
      'فیصدی تنقیص/تزئید',
      'تعداد مکتوب های وارده',
      'تعداد مکتوب های صادره',
      'تعداد استعلام های وارده',
      'تعداد استعلام های صادره',
      'ملاحظات',
    ];
    
    // Add header row (row 2)
    const headerRow = worksheet.addRow(headers);
    headerRow.font = { name: 'Arial', size: 11, bold: true };
    headerRow.alignment = { horizontal: 'right', vertical: 'middle' };
    headerRow.fill = {
      type: 'pattern',
      pattern: 'solid',
      fgColor: { argb: 'FFD9D9D9' }
    };
    headerRow.height = 30;
    
    // Set column widths
    worksheet.getColumn(1).width = 10; // شماره
    worksheet.getColumn(2).width = 20; // گروپ مربوطه
    worksheet.getColumn(3).width = 25; // توزیع شده
    worksheet.getColumn(4).width = 25; // نهائی شده
    worksheet.getColumn(5).width = 25; // قسط شده
    worksheet.getColumn(6).width = 25; // عدم اطاعت
    worksheet.getColumn(7).width = 25; // تحت بررسی
    worksheet.getColumn(8).width = 20; // هدف عوایدی
    worksheet.getColumn(9).width = 25; // عواید جمع آوری شده
    worksheet.getColumn(10).width = 20; // فیصدی تنقیص/تزئید
    worksheet.getColumn(11).width = 20; // مکتوب های وارده
    worksheet.getColumn(12).width = 20; // مکتوب های صادره
    worksheet.getColumn(13).width = 20; // استعلام های وارده
    worksheet.getColumn(14).width = 20; // استعلام های صادره
    worksheet.getColumn(15).width = 30; // ملاحظات
    
    // Add data rows
    let totalDistributed = 0;
    let totalCompleted = 0;
    let totalInstallments = 0;
    let totalNonCompliant = 0;
    let totalUnderReview = 0;
    let totalRevenueTarget = 0;
    let totalCollected = 0;
    
    reportData.forEach((row) => {
      const dataRow = worksheet.addRow([
        row.groupNumber,
        row.groupName,
        row.casesDistributed,
        row.casesCompleted,
        row.casesWithInstallments,
        row.nonCompliantCases,
        row.casesUnderReview,
        row.monthlyRevenueTarget,
        row.collectedRevenue,
        `${row.revenueChangePercent >= 0 ? '+' : ''}${row.revenueChangePercent.toFixed(2)}%`,
        row.lettersReceived ?? 0,
        row.lettersSent ?? 0,
        row.inquiriesReceived ?? 0,
        row.inquiriesSent ?? 0,
        row.notes || '',
      ]);
      
      // RTL alignment for all cells
      dataRow.eachCell((cell) => {
        cell.alignment = { horizontal: 'right', vertical: 'middle' };
      });
      
      // Number formatting for numeric columns
      dataRow.getCell(3).numFmt = '#,##0'; // توزیع شده
      dataRow.getCell(4).numFmt = '#,##0'; // نهائی شده
      dataRow.getCell(5).numFmt = '#,##0'; // قسط شده
      dataRow.getCell(6).numFmt = '#,##0'; // عدم اطاعت
      dataRow.getCell(7).numFmt = '#,##0'; // تحت بررسی
      dataRow.getCell(8).numFmt = '#,##0'; // هدف عوایدی
      dataRow.getCell(9).numFmt = '#,##0'; // عواید جمع آوری شده
      dataRow.getCell(11).numFmt = '#,##0'; // مکتوب های وارده
      dataRow.getCell(12).numFmt = '#,##0'; // مکتوب های صادره
      dataRow.getCell(13).numFmt = '#,##0'; // استعلام های وارده
      dataRow.getCell(14).numFmt = '#,##0'; // استعلام های صادره
      
      // Accumulate totals
      totalDistributed += row.casesDistributed;
      totalCompleted += row.casesCompleted;
      totalInstallments += row.casesWithInstallments;
      totalNonCompliant += row.nonCompliantCases;
      totalUnderReview += row.casesUnderReview;
      totalRevenueTarget += row.monthlyRevenueTarget;
      totalCollected += row.collectedRevenue;
    });
    
    // Add total row
    const totalRow = worksheet.addRow([
      'مجموع',
      '',
      totalDistributed,
      totalCompleted,
      totalInstallments,
      totalNonCompliant,
      totalUnderReview,
      totalRevenueTarget,
      totalCollected,
      '', // Percentage doesn't sum
      '', // Manual fields don't sum
      '',
      '',
      '',
      '',
    ]);
    
    totalRow.font = { name: 'Arial', size: 11, bold: true };
    totalRow.alignment = { horizontal: 'right', vertical: 'middle' };
    totalRow.fill = {
      type: 'pattern',
      pattern: 'solid',
      fgColor: { argb: 'FFE0E0E0' }
    };
    
    // Number formatting for total row
    totalRow.getCell(3).numFmt = '#,##0';
    totalRow.getCell(4).numFmt = '#,##0';
    totalRow.getCell(5).numFmt = '#,##0';
    totalRow.getCell(6).numFmt = '#,##0';
    totalRow.getCell(7).numFmt = '#,##0';
    totalRow.getCell(8).numFmt = '#,##0';
    totalRow.getCell(9).numFmt = '#,##0';
    
    // Add "مبلغ الباقی تحصیل شده از برج قبلی" below total row
    // This is calculated across ALL cases (not per group) using monthly snapshots and payment dates
    const { calculateCollectedFromPreviousMonth } = await import('../services/ministryReportService');
    let totalCollectedFromPrevious = 0;
    
    try {
      // Calculate for ALL cases across all groups (system-wide calculation)
      totalCollectedFromPrevious = await calculateCollectedFromPreviousMonth(
        shamsiMonth,
        shamsiYear
      );
    } catch (error) {
      console.error(`[COLLECTED_FROM_PREVIOUS] Error calculating for month ${shamsiYear}-${shamsiMonth}:`, error);
      // Continue with 0 if calculation fails
      totalCollectedFromPrevious = 0;
    }
    
    // Add empty row for spacing
    worksheet.addRow([]);
    
    // Add "مبلغ الباقی تحصیل شده از برج قبلی" row
    const collectedFromPreviousRow = worksheet.addRow([
      'مبلغ الباقی تحصیل شده از برج قبلی',
      totalCollectedFromPrevious,
    ]);
    
    collectedFromPreviousRow.font = { name: 'Arial', size: 11, bold: true };
    collectedFromPreviousRow.alignment = { horizontal: 'right', vertical: 'middle' };
    collectedFromPreviousRow.fill = {
      type: 'pattern',
      pattern: 'solid',
      fgColor: { argb: 'FFE8E8E8' }
    };
    
    // Number formatting
    collectedFromPreviousRow.getCell(2).numFmt = '#,##0';
    
    // Set response headers
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    // Encode filename to handle special characters properly
    const encodedFilename = encodeURIComponent(`ministry-report-${shamsiYear}-${shamsiMonth}.xlsx`);
    res.setHeader('Content-Disposition', `attachment; filename="${encodedFilename}"; filename*=UTF-8''${encodedFilename}`);
    
    await workbook.xlsx.write(res);
    res.end();
    
    // Log export action
    await storage.createAuditLog({
      userId: user.id,
      action: 'export_ministry_report',
      entityType: 'ministry_report',
      entityId: 'export',
      details: {
        monthShamsi: shamsiMonth,
        yearShamsi: shamsiYear,
        groupCount: reportData.length,
      },
      ipAddress: extractClientIp(req),
    });
  } catch (error) {
    console.error('Error exporting ministry report:', error);
    res.status(500).json({ message: "خطا در صادر کردن گزارش" });
  }
});

// ============================================
// INTERNAL REPORT (Report Type 5)
// ============================================

// Get internal report data - supports Monthly, 3-Month, and Yearly periods
router.get("/internal", requireAuth, requirePermission('reports:generate'), async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    const { reportType, month, year, quarter, groupId } = req.query;
    
    // RBAC: Director can see all, Senior Auditor only their group, Auditor cannot access
    if (user.role !== 'system_admin' && user.role !== 'director') {
      const { isCoordinator } = await import('../services/permissionService');
      const coordinatorCheck = await isCoordinator(user.id);
      
      if (!coordinatorCheck) {
        if (user.role === 'senior_auditor') {
          // Senior Auditor can only see their own group's internal report
          if (groupId && groupId !== user.groupId) {
            return res.status(403).json({ 
              message: 'عدم دسترسی - شما فقط می‌توانید گزارش‌های گروه خود را مشاهده کنید' 
            });
          }
        } else if (user.role === 'auditor') {
          return res.status(403).json({ 
            message: 'عدم دسترسی - شما مجوز مشاهده گزارش‌های داخلی را ندارید' 
          });
        } else {
          return res.status(403).json({ 
            message: 'عدم دسترسی - فقط مدیر و هماهنگ‌کننده می‌توانند این گزارش را مشاهده کنند' 
          });
        }
      }
    }
    
    if (!year) {
      return res.status(400).json({ message: "سال الزامی است" });
    }
    
    const shamsiYear = parseInt(year as string);
    
    if (isNaN(shamsiYear) || shamsiYear < 1300 || shamsiYear > 1500) {
      return res.status(400).json({ message: "سال نامعتبر است" });
    }
    
    // Determine report type - default to 'monthly' for backward compatibility
    const reportTypeValue = (reportType as string) || (month ? 'monthly' : 'yearly');
    
    // Get months to process based on report type
    let monthsToProcess: number[] = [];
    
    if (reportTypeValue === 'monthly') {
      if (!month) {
        return res.status(400).json({ message: "ماه برای گزارش ماهوار الزامی است" });
      }
      const shamsiMonth = parseInt(month as string);
      if (isNaN(shamsiMonth) || shamsiMonth < 1 || shamsiMonth > 12) {
        return res.status(400).json({ message: "ماه نامعتبر است" });
      }
      monthsToProcess = [shamsiMonth];
    } else if (reportTypeValue === '3-month') {
      if (!quarter) {
        return res.status(400).json({ message: "سه‌ماهه برای گزارش سه‌ماهه الزامی است" });
      }
      const quarterNum = parseInt(quarter as string);
      if (isNaN(quarterNum) || quarterNum < 1 || quarterNum > 4) {
        return res.status(400).json({ message: "سه‌ماهه نامعتبر است" });
      }
      // Map quarter to months
      switch (quarterNum) {
        case 1: monthsToProcess = [1, 2, 3]; break;
        case 2: monthsToProcess = [4, 5, 6]; break;
        case 3: monthsToProcess = [7, 8, 9]; break;
        case 4: monthsToProcess = [10, 11, 12]; break;
      }
    } else if (reportTypeValue === 'yearly') {
      monthsToProcess = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12];
    } else {
      return res.status(400).json({ message: "نوع گزارش نامعتبر است" });
    }
    
    const { 
      getInternalReportForGroup, 
      getInternalReportForAllGroups, 
      calculateInternalReportTotals,
      getTaxInstallmentLawEnforcementForGroup
    } = await import('../services/internalReportService');
    
    // Process all months and aggregate data
    const allReportData: any[] = [];
    const reportsByGroup: Record<string, any[]> = {};
    const taxLawMetricsByGroup: Record<string, {
      installmentCases: { total: number; completed: number; pending: number; amountFixed: number };
      lawEnforcementCases: { total: number; completed: number; pending: number; amountFixed: number };
    }> = {};
    
    // Aggregate tax/law metrics
    const totalTaxLawMetrics = {
      installmentCases: { total: 0, completed: 0, pending: 0, amountFixed: 0 },
      lawEnforcementCases: { total: 0, completed: 0, pending: 0, amountFixed: 0 },
    };
    
    // Process each month
    for (const shamsiMonth of monthsToProcess) {
      if (groupId) {
        // Single group - aggregate across months
        const monthData = await getInternalReportForGroup(groupId as string, shamsiMonth, shamsiYear);
        allReportData.push(...monthData);
        
        // Get tax/law metrics for this month
        const monthTaxLaw = await getTaxInstallmentLawEnforcementForGroup(groupId as string, shamsiMonth, shamsiYear);
        totalTaxLawMetrics.installmentCases.total += monthTaxLaw.installmentCases.total;
        totalTaxLawMetrics.installmentCases.completed += monthTaxLaw.installmentCases.completed;
        totalTaxLawMetrics.installmentCases.pending += monthTaxLaw.installmentCases.pending;
        totalTaxLawMetrics.installmentCases.amountFixed += monthTaxLaw.installmentCases.amountFixed;
        totalTaxLawMetrics.lawEnforcementCases.total += monthTaxLaw.lawEnforcementCases.total;
        totalTaxLawMetrics.lawEnforcementCases.completed += monthTaxLaw.lawEnforcementCases.completed;
        totalTaxLawMetrics.lawEnforcementCases.pending += monthTaxLaw.lawEnforcementCases.pending;
        totalTaxLawMetrics.lawEnforcementCases.amountFixed += monthTaxLaw.lawEnforcementCases.amountFixed;
      } else {
        // All groups - aggregate across months
        const monthReportsByGroup = await getInternalReportForAllGroups(shamsiMonth, shamsiYear);
        
        for (const [gId, monthRows] of Object.entries(monthReportsByGroup)) {
          if (!reportsByGroup[gId]) {
            reportsByGroup[gId] = [];
          }
          reportsByGroup[gId].push(...monthRows);
          allReportData.push(...monthRows);
        }
        
        // Get tax/law metrics for all groups this month
        const allGroups = await storage.getGroups();
        for (const group of allGroups.filter(g => g.isActive)) {
          const monthTaxLaw = await getTaxInstallmentLawEnforcementForGroup(group.id, shamsiMonth, shamsiYear);
          
          if (!taxLawMetricsByGroup[group.id]) {
            taxLawMetricsByGroup[group.id] = {
              installmentCases: { total: 0, completed: 0, pending: 0, amountFixed: 0 },
              lawEnforcementCases: { total: 0, completed: 0, pending: 0, amountFixed: 0 },
            };
          }
          
          taxLawMetricsByGroup[group.id].installmentCases.total += monthTaxLaw.installmentCases.total;
          taxLawMetricsByGroup[group.id].installmentCases.completed += monthTaxLaw.installmentCases.completed;
          taxLawMetricsByGroup[group.id].installmentCases.pending += monthTaxLaw.installmentCases.pending;
          taxLawMetricsByGroup[group.id].installmentCases.amountFixed += monthTaxLaw.installmentCases.amountFixed;
          taxLawMetricsByGroup[group.id].lawEnforcementCases.total += monthTaxLaw.lawEnforcementCases.total;
          taxLawMetricsByGroup[group.id].lawEnforcementCases.completed += monthTaxLaw.lawEnforcementCases.completed;
          taxLawMetricsByGroup[group.id].lawEnforcementCases.pending += monthTaxLaw.lawEnforcementCases.pending;
          taxLawMetricsByGroup[group.id].lawEnforcementCases.amountFixed += monthTaxLaw.lawEnforcementCases.amountFixed;
          
          // Add to totals
          totalTaxLawMetrics.installmentCases.total += monthTaxLaw.installmentCases.total;
          totalTaxLawMetrics.installmentCases.completed += monthTaxLaw.installmentCases.completed;
          totalTaxLawMetrics.installmentCases.pending += monthTaxLaw.installmentCases.pending;
          totalTaxLawMetrics.installmentCases.amountFixed += monthTaxLaw.installmentCases.amountFixed;
          totalTaxLawMetrics.lawEnforcementCases.total += monthTaxLaw.lawEnforcementCases.total;
          totalTaxLawMetrics.lawEnforcementCases.completed += monthTaxLaw.lawEnforcementCases.completed;
          totalTaxLawMetrics.lawEnforcementCases.pending += monthTaxLaw.lawEnforcementCases.pending;
          totalTaxLawMetrics.lawEnforcementCases.amountFixed += monthTaxLaw.lawEnforcementCases.amountFixed;
        }
      }
    }
    
    // Calculate totals
    const totals = calculateInternalReportTotals(allReportData);
    
    // Build response
    if (groupId) {
      res.json({ 
        reportType: reportTypeValue,
        groupId, 
        data: allReportData, 
        totals,
        taxLawMetrics: totalTaxLawMetrics,
      });
    } else {
      res.json({ 
        reportType: reportTypeValue,
        allGroups: true, 
        data: reportsByGroup, 
        totals,
        taxLawMetrics: totalTaxLawMetrics,
        taxLawMetricsByGroup,
      });
    }
  } catch (error) {
    console.error('Error fetching internal report:', error);
    res.status(500).json({ message: "خطا در دریافت گزارش" });
  }
});

// Export internal report to Excel - supports Monthly, 3-Month, and Yearly
router.get("/internal/export", requireAuth, requirePermission('reports:generate'), async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    const { reportType, month, year, quarter, groupId } = req.query;
    
    // RBAC: Director can export all, Senior Auditor only their group, Auditor cannot export
    if (user.role === 'system_admin' || user.role === 'director') {
      // Director can export all groups - no restriction
    } else if (user.role === 'senior_auditor') {
      // Senior Auditor can only export their own group's internal report
      if (groupId && groupId !== user.groupId) {
        return res.status(403).json({ 
          message: 'عدم دسترسی - شما فقط می‌توانید گزارش‌های گروه خود را صادر کنید' 
        });
      }
    } else if (user.role === 'auditor') {
      return res.status(403).json({ 
        message: 'عدم دسترسی - شما مجوز صادر کردن گزارش‌های داخلی را ندارید' 
      });
    } else {
      // Check if user has coordinator package
      const { isCoordinator } = await import('../services/permissionService');
      const coordinatorCheck = await isCoordinator(user.id);
      if (!coordinatorCheck) {
        return res.status(403).json({ message: 'عدم دسترسی - فقط مدیر و هماهنگ‌کننده می‌توانند این گزارش را صادر کنند' });
      }
    }
    
    if (!year) {
      return res.status(400).json({ message: "سال الزامی است" });
    }
    
    const shamsiYear = parseInt(year as string);
    
    if (isNaN(shamsiYear) || shamsiYear < 1300 || shamsiYear > 1500) {
      return res.status(400).json({ message: "سال نامعتبر است" });
    }
    
    // Determine report type - default to 'monthly' for backward compatibility
    const reportTypeValue = (reportType as string) || (month ? 'monthly' : 'yearly');
    
    // Get months to process based on report type
    let monthsToProcess: number[] = [];
    let periodLabel = '';
    
    if (reportTypeValue === 'monthly') {
      if (!month) {
        return res.status(400).json({ message: "ماه برای گزارش ماهوار الزامی است" });
      }
      const shamsiMonth = parseInt(month as string);
      if (isNaN(shamsiMonth) || shamsiMonth < 1 || shamsiMonth > 12) {
        return res.status(400).json({ message: "ماه نامعتبر است" });
      }
      monthsToProcess = [shamsiMonth];
    } else if (reportTypeValue === '3-month') {
      if (!quarter) {
        return res.status(400).json({ message: "سه‌ماهه برای گزارش سه‌ماهه الزامی است" });
      }
      const quarterNum = parseInt(quarter as string);
      if (isNaN(quarterNum) || quarterNum < 1 || quarterNum > 4) {
        return res.status(400).json({ message: "سه‌ماهه نامعتبر است" });
      }
      const quarterLabels = ['', 'سه‌ماهه اول', 'سه‌ماهه دوم', 'سه‌ماهه سوم', 'سه‌ماهه چهارم'];
      periodLabel = `${quarterLabels[quarterNum]} سال مالی ${shamsiYear}`;
      // Map quarter to months
      switch (quarterNum) {
        case 1: monthsToProcess = [1, 2, 3]; break;
        case 2: monthsToProcess = [4, 5, 6]; break;
        case 3: monthsToProcess = [7, 8, 9]; break;
        case 4: monthsToProcess = [10, 11, 12]; break;
      }
    } else if (reportTypeValue === 'yearly') {
      monthsToProcess = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12];
      periodLabel = `سال مالی ${shamsiYear}`;
    } else {
      return res.status(400).json({ message: "نوع گزارش نامعتبر است" });
    }
    
    const { 
      getInternalReportForGroup, 
      getInternalReportForAllGroups, 
      calculateInternalReportTotals,
      getTaxInstallmentLawEnforcementForGroup
    } = await import('../services/internalReportService');
    
    // Month names in Dari
    const monthNames = ['', 'حمل', 'ثور', 'جوزا', 'سرطان', 'اسد', 'سنبله', 'میزان', 'عقرب', 'قوس', 'جدی', 'دلو', 'حوت'];
    
    // Aggregate data across all months
    const allReportData: any[] = [];
    const reportsByGroup: Record<string, any[]> = {};
    const taxLawMetricsByGroup: Record<string, {
      installmentCases: { total: number; completed: number; pending: number; amountFixed: number };
      lawEnforcementCases: { total: number; completed: number; pending: number; amountFixed: number };
    }> = {};
    
    // Aggregate tax/law metrics
    const totalTaxLawMetrics = {
      installmentCases: { total: 0, completed: 0, pending: 0, amountFixed: 0 },
      lawEnforcementCases: { total: 0, completed: 0, pending: 0, amountFixed: 0 },
    };
    
    // Process each month
    for (const shamsiMonth of monthsToProcess) {
      if (groupId) {
        // Single group - aggregate across months
        const monthData = await getInternalReportForGroup(groupId as string, shamsiMonth, shamsiYear);
        allReportData.push(...monthData);
        
        // Get tax/law metrics for this month
        const monthTaxLaw = await getTaxInstallmentLawEnforcementForGroup(groupId as string, shamsiMonth, shamsiYear);
        totalTaxLawMetrics.installmentCases.total += monthTaxLaw.installmentCases.total;
        totalTaxLawMetrics.installmentCases.completed += monthTaxLaw.installmentCases.completed;
        totalTaxLawMetrics.installmentCases.pending += monthTaxLaw.installmentCases.pending;
        totalTaxLawMetrics.installmentCases.amountFixed += monthTaxLaw.installmentCases.amountFixed;
        totalTaxLawMetrics.lawEnforcementCases.total += monthTaxLaw.lawEnforcementCases.total;
        totalTaxLawMetrics.lawEnforcementCases.completed += monthTaxLaw.lawEnforcementCases.completed;
        totalTaxLawMetrics.lawEnforcementCases.pending += monthTaxLaw.lawEnforcementCases.pending;
        totalTaxLawMetrics.lawEnforcementCases.amountFixed += monthTaxLaw.lawEnforcementCases.amountFixed;
      } else {
        // All groups - aggregate across months
        const monthReportsByGroup = await getInternalReportForAllGroups(shamsiMonth, shamsiYear);
        
        for (const [gId, monthRows] of Object.entries(monthReportsByGroup)) {
          if (!reportsByGroup[gId]) {
            reportsByGroup[gId] = [];
          }
          reportsByGroup[gId].push(...monthRows);
          allReportData.push(...monthRows);
        }
        
        // Get tax/law metrics for all groups this month
        const allGroups = await storage.getGroups();
        for (const group of allGroups.filter(g => g.isActive)) {
          const monthTaxLaw = await getTaxInstallmentLawEnforcementForGroup(group.id, shamsiMonth, shamsiYear);
          
          if (!taxLawMetricsByGroup[group.id]) {
            taxLawMetricsByGroup[group.id] = {
              installmentCases: { total: 0, completed: 0, pending: 0, amountFixed: 0 },
              lawEnforcementCases: { total: 0, completed: 0, pending: 0, amountFixed: 0 },
            };
          }
          
          taxLawMetricsByGroup[group.id].installmentCases.total += monthTaxLaw.installmentCases.total;
          taxLawMetricsByGroup[group.id].installmentCases.completed += monthTaxLaw.installmentCases.completed;
          taxLawMetricsByGroup[group.id].installmentCases.pending += monthTaxLaw.installmentCases.pending;
          taxLawMetricsByGroup[group.id].installmentCases.amountFixed += monthTaxLaw.installmentCases.amountFixed;
          taxLawMetricsByGroup[group.id].lawEnforcementCases.total += monthTaxLaw.lawEnforcementCases.total;
          taxLawMetricsByGroup[group.id].lawEnforcementCases.completed += monthTaxLaw.lawEnforcementCases.completed;
          taxLawMetricsByGroup[group.id].lawEnforcementCases.pending += monthTaxLaw.lawEnforcementCases.pending;
          taxLawMetricsByGroup[group.id].lawEnforcementCases.amountFixed += monthTaxLaw.lawEnforcementCases.amountFixed;
          
          // Add to totals
          totalTaxLawMetrics.installmentCases.total += monthTaxLaw.installmentCases.total;
          totalTaxLawMetrics.installmentCases.completed += monthTaxLaw.installmentCases.completed;
          totalTaxLawMetrics.installmentCases.pending += monthTaxLaw.installmentCases.pending;
          totalTaxLawMetrics.installmentCases.amountFixed += monthTaxLaw.installmentCases.amountFixed;
          totalTaxLawMetrics.lawEnforcementCases.total += monthTaxLaw.lawEnforcementCases.total;
          totalTaxLawMetrics.lawEnforcementCases.completed += monthTaxLaw.lawEnforcementCases.completed;
          totalTaxLawMetrics.lawEnforcementCases.pending += monthTaxLaw.lawEnforcementCases.pending;
          totalTaxLawMetrics.lawEnforcementCases.amountFixed += monthTaxLaw.lawEnforcementCases.amountFixed;
        }
      }
    }
    
    // Calculate totals
    const totals = calculateInternalReportTotals(allReportData);
    
    // Create workbook
    const workbook = new ExcelJS.Workbook();
    
    // For Monthly reports: preserve existing format (single sheet with case details)
    if (reportTypeValue === 'monthly') {
      const shamsiMonth = monthsToProcess[0];
      const monthName = monthNames[shamsiMonth] || shamsiMonth.toString();
      
      if (groupId) {
        // Single group report - one sheet
        const groupIdStr = typeof groupId === 'string' ? groupId : String(groupId);
        const group = await storage.getGroup(groupIdStr);
        const groupName = group?.name || groupIdStr;
        
        const worksheet = workbook.addWorksheet(groupName);
      
      // Set RTL direction
      worksheet.views = [{ rightToLeft: true }];
      
      // Main header
      const mainHeader = `گزارش ماهوار مدیریت عمومی بررسی گروپ (${groupName}) بابت برج (${monthName}) سال مالی ${shamsiYear}`;
      
      // Add main header (row 1) - merge across all columns
      const totalColumns = 6 + 14 + 4; // Section 1 (6) + Section 2 (14) + Summary (4) = 24 columns
      worksheet.mergeCells(1, 1, 1, totalColumns);
      const headerCell = worksheet.getCell(1, 1);
      headerCell.value = mainHeader;
      headerCell.font = { name: 'Arial', size: 14, bold: true };
      headerCell.alignment = { horizontal: 'center', vertical: 'middle' };
      headerCell.fill = {
        type: 'pattern',
        pattern: 'solid',
        fgColor: { argb: 'FFE0E0E0' }
      };
      
      // Row 2: Section headers side-by-side
      const section1HeaderCell = worksheet.getCell(2, 1);
      section1HeaderCell.value = 'بخش اول - مشخصات نهاد';
      section1HeaderCell.font = { name: 'Arial', size: 12, bold: true };
      section1HeaderCell.alignment = { horizontal: 'right', vertical: 'middle' };
      section1HeaderCell.fill = {
        type: 'pattern',
        pattern: 'solid',
        fgColor: { argb: 'FFD0D0D0' }
      };
      worksheet.mergeCells(2, 1, 2, 6); // Merge first 6 columns for Section 1 header
      
      const section2HeaderCell = worksheet.getCell(2, 7);
      section2HeaderCell.value = 'بخش دوم - بیرون‌نویسی‌ها';
      section2HeaderCell.font = { name: 'Arial', size: 12, bold: true };
      section2HeaderCell.alignment = { horizontal: 'right', vertical: 'middle' };
      section2HeaderCell.fill = {
        type: 'pattern',
        pattern: 'solid',
        fgColor: { argb: 'FFD0D0D0' }
      };
      worksheet.mergeCells(2, 7, 2, 20); // Merge columns 7-20 for Section 2 header (14 columns)
      
      // Row 3: All column headers in one row
      const { calculateSummaryFieldsForCase } = await import('../services/internalReportService');
      
      // All headers in one row: Section 1 (6) + Section 2 (14) + Summary (4) = 24 columns
      const allHeaders = [
        // Section 1 - مشخصات نهاد (6 columns)
        'نام نهاد',
        'نمبر تشخیصیه',
        'نوع تشبث',
        'آمریت ارجاع کننده',
        'سالهای بررسی',
        'دوران سرمایه',
        // Section 2 - بیرون‌نویسی‌ها (14 columns)
        'مالیه موضوعی معاشات',
        'مالیه موضوعی بر کرایه',
        'مالیه موضوعی قراردادی',
        'مالیات معاملات انتفاعی',
        'مالیات بر عایدات',
        'ضرر کاهش یافته',
        'مبلغ فاضل تحویل کاهش یافته',
        'مبلغ تثبیت شده',
        'مبلغ تحصیل شده طی برج جاری',
        'الباقی مبلغ قابل تحصیل',
        'وضعیت فعالیت',
        'نمبر آویز',
        'تاریخ آویز',
        // Summary fields (4 columns)
        'عواید تثبیت شده طی برج جاری',
        'عواید تحصیل شده طی برج جاری',
        'الباقی مبلغ قابل تحصیل',
        'مبلغ الباقی تحصیل شده از برج قبلی',
      ];
      
      const headerRow = worksheet.addRow(allHeaders);
      headerRow.font = { name: 'Arial', size: 11, bold: true };
      headerRow.alignment = { horizontal: 'right', vertical: 'middle' };
      headerRow.fill = {
        type: 'pattern',
        pattern: 'solid',
        fgColor: { argb: 'FFD9D9D9' }
      };
      headerRow.height = 25;
      
      // Define numeric columns for formatting (used in both data rows and totals row)
      const numericColumns = [
        7, 8, 9, 10, 11, 12, 13, 14, 15, 16, // Section 2 numeric fields (columns 7-16)
        21, 22, 23, 24 // Summary fields (columns 21-24)
      ];
      
      // Add data rows - each case in one row with all fields
      allReportData.forEach((row) => {
        const summaryFields = calculateSummaryFieldsForCase(row);
        
        const dataRow = worksheet.addRow([
          // Section 1 fields (6 columns)
          row.companyName,
          row.tin,
          row.businessNature || '',
          row.groupReferrer,
          row.periodsUnderReview,
          row.capitalPeriod || '',
          // Section 2 fields (14 columns)
          row.salaryTax || '',
          row.rentTax || '',
          row.contractTax || '',
          row.profitTransactionTax || '',
          row.incomeTax || '',
          row.reducedLoss || '',
          row.reducedRemainingAmount || '',
          row.confirmedAmount || '',
          row.collectedCurrentMonth || '',
          row.remainingCollectible || '',
          row.activityStatus || '',
          row.attachmentNumber || '',
          row.attachmentDate || '',
          // Summary fields (4 columns)
          summaryFields.confirmedRevenueCurrentMonth,
          summaryFields.collectedRevenueCurrentMonth,
          summaryFields.remainingCollectibleAmount,
          summaryFields.previousMonthRemainingCollected,
        ]);
        
        dataRow.eachCell((cell) => {
          cell.alignment = { horizontal: 'right', vertical: 'middle' };
        });
        
        // Number formatting for numeric columns
        numericColumns.forEach((colNum) => {
          const cell = dataRow.getCell(colNum);
          if (cell.value !== null && cell.value !== '') {
            const numValue = typeof cell.value === 'number' ? cell.value : parseFloat(String(cell.value));
            if (!isNaN(numValue)) {
              cell.numFmt = '#,##0';
            }
          }
        });
      });
      
      // Add totals row
      if (allReportData.length > 0) {
        worksheet.addRow([]); // Empty row before totals
        const totalsRow = worksheet.addRow([
          // Section 1 totals (empty for non-numeric fields)
          'مجموع کل',
          '', // tin
          '', // businessNature
          '', // groupReferrer
          '', // periodsUnderReview
          '', // capitalPeriod
          // Section 2 totals
          totals.salaryTax,
          totals.rentTax,
          totals.contractTax,
          totals.profitTransactionTax,
          totals.incomeTax,
          totals.reducedLoss,
          totals.reducedRemainingAmount,
          totals.confirmedAmount,
          totals.collectedCurrentMonth,
          totals.remainingCollectible,
          '', // activityStatus
          '', // attachmentNumber
          '', // attachmentDate
          // Summary totals (sum of summary fields)
          totals.confirmedAmount, // عواید تثبیت شده = sum of confirmedAmount
          totals.collectedCurrentMonth, // عواید تحصیل شده = sum of collectedCurrentMonth
          totals.remainingCollectible, // الباقی مبلغ قابل تحصیل = sum of remainingCollectible
          0, // مبلغ الباقی تحصیل شده از برج قبلی (would need previous month data)
        ]);
        
        // Format totals row
        totalsRow.font = { name: 'Arial', size: 11, bold: true };
        totalsRow.fill = {
          type: 'pattern',
          pattern: 'solid',
          fgColor: { argb: 'FFC0C0C0' }
        };
        totalsRow.eachCell((cell, colNumber) => {
          cell.alignment = { horizontal: 'right', vertical: 'middle' };
          // Number formatting for numeric columns
          if (numericColumns.includes(colNumber)) {
            cell.numFmt = '#,##0';
          }
        });
      }
      
      // Set column widths for all columns
      // Section 1 (columns 1-6)
      worksheet.getColumn(1).width = 30; // نام نهاد
      worksheet.getColumn(2).width = 20; // نمبر تشخیصیه
      worksheet.getColumn(3).width = 20; // نوع تشبث
      worksheet.getColumn(4).width = 20; // آمریت ارجاع کننده
      worksheet.getColumn(5).width = 20; // سالهای بررسی
      worksheet.getColumn(6).width = 20; // دوران سرمایه
      
      // Section 2 (columns 7-20)
      for (let col = 7; col <= 20; col++) {
        worksheet.getColumn(col).width = 25;
      }
      
      // Summary fields (columns 21-24)
      for (let col = 21; col <= 24; col++) {
        worksheet.getColumn(col).width = 30;
      }
      
      // Set response headers
      const filename = `گزارش-داخلی-${groupName}-${monthName}-${shamsiYear}.xlsx`;
      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      res.setHeader('Content-Disposition', encodeFilename(filename));
    } else {
      // All groups report - multiple sheets
      const allGroups = await storage.getGroups();
      
      for (const [groupId, reportData] of Object.entries(reportsByGroup)) {
        const group = allGroups.find(g => g.id === groupId);
        const groupName = group?.name || groupId;
        
        const worksheet = workbook.addWorksheet(groupName);
        
        // Set RTL direction
        worksheet.views = [{ rightToLeft: true }];
        
        // Main header
        const mainHeader = `گزارش ماهوار مدیریت عمومی بررسی گروپ (${groupName}) بابت برج (${monthName}) سال مالی ${shamsiYear}`;
        
        // Add main header (row 1) - merge across all columns
        const totalColumns = 6 + 14 + 4; // Section 1 (6) + Section 2 (14) + Summary (4) = 24 columns
        worksheet.mergeCells(1, 1, 1, totalColumns);
        const headerCell = worksheet.getCell(1, 1);
        headerCell.value = mainHeader;
        headerCell.font = { name: 'Arial', size: 14, bold: true };
        headerCell.alignment = { horizontal: 'center', vertical: 'middle' };
        headerCell.fill = {
          type: 'pattern',
          pattern: 'solid',
          fgColor: { argb: 'FFE0E0E0' }
        };
        
        // Row 2: Section headers side-by-side
        const section1HeaderCell = worksheet.getCell(2, 1);
        section1HeaderCell.value = 'بخش اول - مشخصات نهاد';
        section1HeaderCell.font = { name: 'Arial', size: 12, bold: true };
        section1HeaderCell.alignment = { horizontal: 'right', vertical: 'middle' };
        section1HeaderCell.fill = {
          type: 'pattern',
          pattern: 'solid',
          fgColor: { argb: 'FFD0D0D0' }
        };
        worksheet.mergeCells(2, 1, 2, 6); // Merge first 6 columns for Section 1 header
        
        const section2HeaderCell = worksheet.getCell(2, 7);
        section2HeaderCell.value = 'بخش دوم - بیرون‌نویسی‌ها';
        section2HeaderCell.font = { name: 'Arial', size: 12, bold: true };
        section2HeaderCell.alignment = { horizontal: 'right', vertical: 'middle' };
        section2HeaderCell.fill = {
          type: 'pattern',
          pattern: 'solid',
          fgColor: { argb: 'FFD0D0D0' }
        };
        worksheet.mergeCells(2, 7, 2, 20); // Merge columns 7-20 for Section 2 header (14 columns)
        
        // Row 3: All column headers in one row
        const { calculateSummaryFieldsForCase } = await import('../services/internalReportService');
        
        const allHeaders = [
          // Section 1 - مشخصات نهاد (6 columns)
          'نام نهاد',
          'نمبر تشخیصیه',
          'نوع تشبث',
          'آمریت ارجاع کننده',
          'سالهای بررسی',
          'دوران سرمایه',
          // Section 2 - بیرون‌نویسی‌ها (14 columns)
          'مالیه موضوعی معاشات',
          'مالیه موضوعی بر کرایه',
          'مالیه موضوعی قراردادی',
          'مالیات معاملات انتفاعی',
          'مالیات بر عایدات',
          'ضرر کاهش یافته',
          'مبلغ فاضل تحویل کاهش یافته',
          'مبلغ تثبیت شده',
          'مبلغ تحصیل شده طی برج جاری',
          'الباقی مبلغ قابل تحصیل',
          'وضعیت فعالیت',
          'نمبر آویز',
          'تاریخ آویز',
          // Summary fields (4 columns)
          'عواید تثبیت شده طی برج جاری',
          'عواید تحصیل شده طی برج جاری',
          'الباقی مبلغ قابل تحصیل',
          'مبلغ الباقی تحصیل شده از برج قبلی',
        ];
        
        const headerRow = worksheet.addRow(allHeaders);
        headerRow.font = { name: 'Arial', size: 11, bold: true };
        headerRow.alignment = { horizontal: 'right', vertical: 'middle' };
        headerRow.fill = {
          type: 'pattern',
          pattern: 'solid',
          fgColor: { argb: 'FFD9D9D9' }
        };
        headerRow.height = 25;
        
        // Define numeric columns for formatting (used in both data rows and totals row)
        const numericColumns = [
          7, 8, 9, 10, 11, 12, 13, 14, 15, 16, // Section 2 numeric fields (columns 7-16)
          21, 22, 23, 24 // Summary fields (columns 21-24)
        ];
        
        // Add data rows - each case in one row with all fields
        reportData.forEach((row) => {
          const summaryFields = calculateSummaryFieldsForCase(row);
          
          const dataRow = worksheet.addRow([
            // Section 1 fields (6 columns)
            row.companyName,
            row.tin,
            row.businessNature || '',
            row.groupReferrer,
            row.periodsUnderReview,
            row.capitalPeriod || '',
            // Section 2 fields (14 columns)
            row.salaryTax || '',
            row.rentTax || '',
            row.contractTax || '',
            row.profitTransactionTax || '',
            row.incomeTax || '',
            row.reducedLoss || '',
            row.reducedRemainingAmount || '',
            row.confirmedAmount || '',
            row.collectedCurrentMonth || '',
            row.remainingCollectible || '',
            row.activityStatus || '',
            row.attachmentNumber || '',
            row.attachmentDate || '',
            // Summary fields (4 columns)
            summaryFields.confirmedRevenueCurrentMonth,
            summaryFields.collectedRevenueCurrentMonth,
            summaryFields.remainingCollectibleAmount,
            summaryFields.previousMonthRemainingCollected,
          ]);
          
          dataRow.eachCell((cell) => {
            cell.alignment = { horizontal: 'right', vertical: 'middle' };
          });
          
          // Number formatting for numeric columns
          numericColumns.forEach((colNum) => {
            const cell = dataRow.getCell(colNum);
            if (cell.value !== null && cell.value !== '') {
              const numValue = typeof cell.value === 'number' ? cell.value : parseFloat(String(cell.value));
              if (!isNaN(numValue)) {
                cell.numFmt = '#,##0';
              }
            }
          });
        });
        
        // Add totals row for each group
        if (reportData.length > 0) {
          const groupTotals = calculateInternalReportTotals(reportData);
          worksheet.addRow([]); // Empty row before totals
          const totalsRow = worksheet.addRow([
            // Section 1 totals (empty for non-numeric fields)
            'مجموع کل',
            '', // tin
            '', // businessNature
            '', // groupReferrer
            '', // periodsUnderReview
            '', // capitalPeriod
            // Section 2 totals
            groupTotals.salaryTax,
            groupTotals.rentTax,
            groupTotals.contractTax,
            groupTotals.profitTransactionTax,
            groupTotals.incomeTax,
            groupTotals.reducedLoss,
            groupTotals.reducedRemainingAmount,
            groupTotals.confirmedAmount,
            groupTotals.collectedCurrentMonth,
            groupTotals.remainingCollectible,
            '', // activityStatus
            '', // attachmentNumber
            '', // attachmentDate
            // Summary totals
            groupTotals.confirmedAmount,
            groupTotals.collectedCurrentMonth,
            groupTotals.remainingCollectible,
            0, // مبلغ الباقی تحصیل شده از برج قبلی
          ]);
          
          // Format totals row
          totalsRow.font = { name: 'Arial', size: 11, bold: true };
          totalsRow.fill = {
            type: 'pattern',
            pattern: 'solid',
            fgColor: { argb: 'FFC0C0C0' }
          };
          totalsRow.eachCell((cell, colNumber) => {
            cell.alignment = { horizontal: 'right', vertical: 'middle' };
            if (numericColumns.includes(colNumber)) {
              cell.numFmt = '#,##0';
            }
          });
        }
        
        // Set column widths for all columns
        // Section 1 (columns 1-6)
        worksheet.getColumn(1).width = 30; // نام نهاد
        worksheet.getColumn(2).width = 20; // نمبر تشخیصیه
        worksheet.getColumn(3).width = 20; // نوع تشبث
        worksheet.getColumn(4).width = 20; // آمریت ارجاع کننده
        worksheet.getColumn(5).width = 20; // سالهای بررسی
        worksheet.getColumn(6).width = 20; // دوران سرمایه
        
        // Section 2 (columns 7-20)
        for (let col = 7; col <= 20; col++) {
          worksheet.getColumn(col).width = 25;
        }
        
        // Summary fields (columns 21-24)
        for (let col = 21; col <= 24; col++) {
          worksheet.getColumn(col).width = 30;
        }
      }
      
      // Set response headers for all groups
      const filename = `گزارش-داخلی-همه-گروپها-${monthName}-${shamsiYear}.xlsx`;
      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      res.setHeader('Content-Disposition', encodeFilename(filename));
    }
    } else {
      // For 3-Month and Yearly: Create multi-sheet Excel with Summary, Group Performance, Tax Installment, Law Enforcement
      // This will be implemented in a follow-up - for now, we'll use a simplified version
      // TODO: Implement full multi-sheet format for 3-Month and Yearly reports
      const summarySheet = workbook.addWorksheet('خلاصه');
      summarySheet.views = [{ rightToLeft: true }];
      
      summarySheet.mergeCells(1, 1, 1, 6);
      const header = summarySheet.getCell(1, 1);
      header.value = `گزارش داخلی - ${periodLabel}`;
      header.font = { name: 'Arial', size: 14, bold: true };
      header.alignment = { horizontal: 'center', vertical: 'middle' };
      header.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFE0E0E0' } };
      
      // Add summary data
      summarySheet.addRow(['کل قضایا', allReportData.length]);
      summarySheet.addRow(['کل مبلغ تثبیت شده', totals.confirmedAmount]);
      summarySheet.addRow(['کل مبلغ تحصیل شده', totals.collectedCurrentMonth]);
      summarySheet.addRow(['الباقی قابل تحصیل', totals.remainingCollectible]);
      
      // Tax/Law Enforcement summary
      summarySheet.addRow([]);
      summarySheet.addRow(['قضایای اقساط - کل', totalTaxLawMetrics.installmentCases.total]);
      summarySheet.addRow(['قضایای اقساط - تکمیل', totalTaxLawMetrics.installmentCases.completed]);
      summarySheet.addRow(['قضایای اقساط - انتظار', totalTaxLawMetrics.installmentCases.pending]);
      summarySheet.addRow(['قضایای اقساط - مبلغ', totalTaxLawMetrics.installmentCases.amountFixed]);
      summarySheet.addRow([]);
      summarySheet.addRow(['قضایای تنفیذ قانون - کل', totalTaxLawMetrics.lawEnforcementCases.total]);
      summarySheet.addRow(['قضایای تنفیذ قانون - تکمیل', totalTaxLawMetrics.lawEnforcementCases.completed]);
      summarySheet.addRow(['قضایای تنفیذ قانون - انتظار', totalTaxLawMetrics.lawEnforcementCases.pending]);
      summarySheet.addRow(['قضایای تنفیذ قانون - مبلغ', totalTaxLawMetrics.lawEnforcementCases.amountFixed]);
      
      // Set response headers
      const filename = reportTypeValue === 'yearly'
        ? `گزارش-داخلی-سالانه-${shamsiYear}.xlsx`
        : `گزارش-داخلی-سه-ماهه-${shamsiYear}.xlsx`;
      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      res.setHeader('Content-Disposition', encodeFilename(filename));
    }
    
    await workbook.xlsx.write(res);
    res.end();
    
    // Log export action
    await storage.createAuditLog({
      userId: user.id,
      action: 'export_internal_report',
      entityType: 'report',
      entityId: 'export',
      details: {
        reportType: reportTypeValue,
        yearShamsi: shamsiYear,
        month: reportTypeValue === 'monthly' ? monthsToProcess[0] : null,
        quarter: reportTypeValue === '3-month' ? quarter : null,
        groupId: groupId || 'all',
      },
      ipAddress: extractClientIp(req),
    });
  } catch (error) {
    console.error('Error exporting internal report:', error);
    res.status(500).json({ message: "خطا در صادر کردن گزارش" });
  }
});

// ============================================
// YEARLY GROUP PERFORMANCE REPORT
// ============================================

// Get yearly group performance report
router.get("/yearly-group-performance", requireAuth, requirePermission('reports:generate'), async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    const { year } = req.query;

    // Validate year parameter
    if (!year) {
      return res.status(400).json({ message: "سال الزامی است" });
    }

    const yearShamsi = parseInt(year as string);
    
    if (isNaN(yearShamsi) || yearShamsi < 1300 || yearShamsi > 1500) {
      return res.status(400).json({ message: "سال نامعتبر است" });
    }

    // Get yearly group performance data
    const { getYearlyGroupPerformance } = await import('../services/yearlyGroupPerformanceService');
    const report = await getYearlyGroupPerformance(yearShamsi);

    // Log report access
    await storage.createAuditLog({
      userId: user.id,
      action: 'view_yearly_group_performance',
      entityType: 'report',
      entityId: 'yearly-group-performance',
      details: {
        yearShamsi,
        groupCount: report.groupSummaries.length,
      },
      ipAddress: extractClientIp(req),
    });

    res.json(report);
  } catch (error) {
    console.error('Error fetching yearly group performance report:', error);
    res.status(500).json({ message: "خطا در دریافت گزارش" });
  }
});

// Export yearly group performance report to Excel
router.get("/yearly-group-performance/export", requireAuth, requirePermission('reports:generate'), async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    const { year } = req.query;

    if (!year) {
      return res.status(400).json({ message: "سال الزامی است" });
    }

    const yearShamsi = parseInt(year as string);
    
    if (isNaN(yearShamsi) || yearShamsi < 1300 || yearShamsi > 1500) {
      return res.status(400).json({ message: "سال نامعتبر است" });
    }

    const { getYearlyGroupPerformance } = await import('../services/yearlyGroupPerformanceService');
    const report = await getYearlyGroupPerformance(yearShamsi);

    // Month names in Dari
    const monthNames = ['', 'حمل', 'ثور', 'جوزا', 'سرطان', 'اسد', 'سنبله', 'میزان', 'عقرب', 'قوس', 'جدی', 'دلو', 'حوت'];

    // Create workbook
    const workbook = new ExcelJS.Workbook();
    
    // Sheet 1: Summary
    const summarySheet = workbook.addWorksheet('خلاصه');
    summarySheet.views = [{ rightToLeft: true }];
    
    // Summary header
    summarySheet.mergeCells(1, 1, 1, 6);
    const summaryHeader = summarySheet.getCell(1, 1);
    summaryHeader.value = `گزارش عملکرد سالانه گروه‌ها - سال مالی ${yearShamsi}`;
    summaryHeader.font = { name: 'Arial', size: 14, bold: true };
    summaryHeader.alignment = { horizontal: 'center', vertical: 'middle' };
    summaryHeader.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFE0E0E0' } };
    
    // Summary headers
    const summaryHeaders = ['گروه', 'کل قضایا', 'قضایای تکمیل شده', 'قضایای در انتظار', 'مبلغ تثبیت شده'];
    const summaryHeaderRow = summarySheet.addRow(summaryHeaders);
    summaryHeaderRow.font = { name: 'Arial', size: 11, bold: true };
    summaryHeaderRow.alignment = { horizontal: 'right', vertical: 'middle' };
    summaryHeaderRow.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFD9D9D9' } };
    
    // Summary data
    let totalCases = 0, totalCompleted = 0, totalPending = 0, totalAmount = 0;
    report.groupSummaries.forEach(group => {
      summarySheet.addRow([
        group.groupName,
        group.totalCases,
        group.completedCases,
        group.pendingCases,
        group.amountFixed,
      ]);
      totalCases += group.totalCases;
      totalCompleted += group.completedCases;
      totalPending += group.pendingCases;
      totalAmount += group.amountFixed;
    });
    
    // Summary totals
    const summaryTotalRow = summarySheet.addRow(['مجموع کل', totalCases, totalCompleted, totalPending, totalAmount]);
    summaryTotalRow.font = { name: 'Arial', size: 11, bold: true };
    summaryTotalRow.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFC0C0C0' } };
    summaryTotalRow.eachCell((cell, colNum) => {
      cell.alignment = { horizontal: 'right', vertical: 'middle' };
      if (colNum > 1) cell.numFmt = '#,##0';
    });
    
    // Set column widths
    summarySheet.getColumn(1).width = 30;
    for (let col = 2; col <= 5; col++) {
      summarySheet.getColumn(col).width = 20;
    }
    
    // Format numeric columns
    summarySheet.getColumn(2).numFmt = '#,##0';
    summarySheet.getColumn(3).numFmt = '#,##0';
    summarySheet.getColumn(4).numFmt = '#,##0';
    summarySheet.getColumn(5).numFmt = '#,##0';
    
    // Sheet 2: Group Performance
    const groupSheet = workbook.addWorksheet('عملکرد گروه‌ها');
    groupSheet.views = [{ rightToLeft: true }];
    
    // Group performance header
    groupSheet.mergeCells(1, 1, 1, 6);
    const groupHeader = groupSheet.getCell(1, 1);
    groupHeader.value = `عملکرد تفصیلی گروه‌ها - سال مالی ${yearShamsi}`;
    groupHeader.font = { name: 'Arial', size: 14, bold: true };
    groupHeader.alignment = { horizontal: 'center', vertical: 'middle' };
    groupHeader.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFE0E0E0' } };
    
    // Group performance headers
    const groupHeaders = ['گروه', 'ماه', 'کل قضایا', 'تکمیل شده', 'در انتظار', 'مبلغ تثبیت شده'];
    const groupHeaderRow = groupSheet.addRow(groupHeaders);
    groupHeaderRow.font = { name: 'Arial', size: 11, bold: true };
    groupHeaderRow.alignment = { horizontal: 'right', vertical: 'middle' };
    groupHeaderRow.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFD9D9D9' } };
    
    // Group performance data
    report.groupSummaries.forEach(group => {
      group.monthlyBreakdown.forEach(monthData => {
        groupSheet.addRow([
          group.groupName,
          monthNames[monthData.month],
          monthData.totalCases,
          monthData.completedCases,
          monthData.pendingCases,
          monthData.amountFixed,
        ]);
      });
    });
    
    // Set column widths and formatting
    groupSheet.getColumn(1).width = 30;
    groupSheet.getColumn(2).width = 15;
    for (let col = 3; col <= 6; col++) {
      groupSheet.getColumn(col).width = 18;
      groupSheet.getColumn(col).numFmt = '#,##0';
    }
    
    // Sheet 3: Monthly Breakdown
    const monthlySheet = workbook.addWorksheet('تفکیک ماهوار');
    monthlySheet.views = [{ rightToLeft: true }];
    
    // Monthly breakdown header
    monthlySheet.mergeCells(1, 1, 1, 5);
    const monthlyHeader = monthlySheet.getCell(1, 1);
    monthlyHeader.value = `تفکیک ماهوار - سال مالی ${yearShamsi}`;
    monthlyHeader.font = { name: 'Arial', size: 14, bold: true };
    monthlyHeader.alignment = { horizontal: 'center', vertical: 'middle' };
    monthlyHeader.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFE0E0E0' } };
    
    // Monthly breakdown headers
    const monthlyHeaders = ['ماه', 'کل قضایا', 'تکمیل شده', 'در انتظار', 'مبلغ تثبیت شده'];
    const monthlyHeaderRow = monthlySheet.addRow(monthlyHeaders);
    monthlyHeaderRow.font = { name: 'Arial', size: 11, bold: true };
    monthlyHeaderRow.alignment = { horizontal: 'right', vertical: 'middle' };
    monthlyHeaderRow.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFD9D9D9' } };
    
    // Monthly breakdown data
    report.monthlyData.forEach(monthData => {
      monthlySheet.addRow([
        monthNames[monthData.month],
        monthData.totalCases,
        monthData.completedCases,
        monthData.pendingCases,
        monthData.amountFixed,
      ]);
    });
    
    // Set column widths and formatting
    monthlySheet.getColumn(1).width = 20;
    for (let col = 2; col <= 5; col++) {
      monthlySheet.getColumn(col).width = 18;
      monthlySheet.getColumn(col).numFmt = '#,##0';
    }
    
    // Set response headers
    const encodedFilename = encodeURIComponent(`yearly-group-performance-${yearShamsi}.xlsx`);
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename="${encodedFilename}"; filename*=UTF-8''${encodedFilename}`);
    
    await workbook.xlsx.write(res);
    res.end();
    
    // Log export
    await storage.createAuditLog({
      userId: user.id,
      action: 'export_yearly_group_performance',
      entityType: 'report',
      entityId: 'yearly-group-performance',
      details: { yearShamsi },
      ipAddress: extractClientIp(req),
    });
  } catch (error) {
    console.error('Error exporting yearly group performance report:', error);
    res.status(500).json({ message: "خطا در صادر کردن گزارش" });
  }
});

// Get 3-month (quarter) group performance report
router.get("/three-month-group-performance", requireAuth, requirePermission('reports:generate'), async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    const { year, quarter } = req.query;

    // Validate year parameter
    if (!year) {
      return res.status(400).json({ message: "سال الزامی است" });
    }

    const yearShamsi = parseInt(year as string);
    
    if (isNaN(yearShamsi) || yearShamsi < 1300 || yearShamsi > 1500) {
      return res.status(400).json({ message: "سال نامعتبر است" });
    }

    // Validate quarter parameter
    if (!quarter) {
      return res.status(400).json({ message: "سه‌ماهه الزامی است" });
    }

    const quarterNum = parseInt(quarter as string);
    
    if (isNaN(quarterNum) || quarterNum < 1 || quarterNum > 4) {
      return res.status(400).json({ message: "سه‌ماهه نامعتبر است. باید بین 1 تا 4 باشد." });
    }

    // Get 3-month group performance data
    const { getThreeMonthGroupPerformance, validateQuarter } = await import('../services/yearlyGroupPerformanceService');
    
    // Additional validation using service function
    if (!validateQuarter(quarterNum)) {
      return res.status(400).json({ message: "سه‌ماهه نامعتبر است. باید بین 1 تا 4 باشد." });
    }

    const report = await getThreeMonthGroupPerformance(yearShamsi, quarterNum);

    // Log report access
    await storage.createAuditLog({
      userId: user.id,
      action: 'view_three_month_group_performance',
      entityType: 'report',
      entityId: 'three-month-group-performance',
      details: {
        yearShamsi,
        quarter: quarterNum,
        groupCount: report.groupSummaries.length,
      },
      ipAddress: extractClientIp(req),
    });

    res.json(report);
  } catch (error) {
    console.error('Error fetching 3-month group performance report:', error);
    if (error instanceof Error && error.message.includes('Invalid quarter')) {
      return res.status(400).json({ message: error.message });
    }
    res.status(500).json({ message: "خطا در دریافت گزارش" });
  }
});

// Export 3-month group performance report to Excel
router.get("/three-month-group-performance/export", requireAuth, requirePermission('reports:generate'), async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    const { year, quarter } = req.query;

    if (!year) {
      return res.status(400).json({ message: "سال الزامی است" });
    }

    const yearShamsi = parseInt(year as string);
    
    if (isNaN(yearShamsi) || yearShamsi < 1300 || yearShamsi > 1500) {
      return res.status(400).json({ message: "سال نامعتبر است" });
    }

    if (!quarter) {
      return res.status(400).json({ message: "سه‌ماهه الزامی است" });
    }

    const quarterNum = parseInt(quarter as string);
    
    if (isNaN(quarterNum) || quarterNum < 1 || quarterNum > 4) {
      return res.status(400).json({ message: "سه‌ماهه نامعتبر است" });
    }

    const { getThreeMonthGroupPerformance } = await import('../services/yearlyGroupPerformanceService');
    const report = await getThreeMonthGroupPerformance(yearShamsi, quarterNum);

    // Month names in Dari
    const monthNames = ['', 'حمل', 'ثور', 'جوزا', 'سرطان', 'اسد', 'سنبله', 'میزان', 'عقرب', 'قوس', 'جدی', 'دلو', 'حوت'];
    const quarterLabels = ['', 'سه‌ماهه اول', 'سه‌ماهه دوم', 'سه‌ماهه سوم', 'سه‌ماهه چهارم'];

    // Create workbook
    const workbook = new ExcelJS.Workbook();
    
    // Sheet 1: Summary
    const summarySheet = workbook.addWorksheet('خلاصه');
    summarySheet.views = [{ rightToLeft: true }];
    
    // Summary header
    summarySheet.mergeCells(1, 1, 1, 6);
    const summaryHeader = summarySheet.getCell(1, 1);
    summaryHeader.value = `گزارش عملکرد ${quarterLabels[quarterNum]} - سال مالی ${yearShamsi}`;
    summaryHeader.font = { name: 'Arial', size: 14, bold: true };
    summaryHeader.alignment = { horizontal: 'center', vertical: 'middle' };
    summaryHeader.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFE0E0E0' } };
    
    // Summary headers
    const summaryHeaders = ['گروه', 'کل قضایا', 'قضایای تکمیل شده', 'قضایای در انتظار', 'مبلغ تثبیت شده'];
    const summaryHeaderRow = summarySheet.addRow(summaryHeaders);
    summaryHeaderRow.font = { name: 'Arial', size: 11, bold: true };
    summaryHeaderRow.alignment = { horizontal: 'right', vertical: 'middle' };
    summaryHeaderRow.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFD9D9D9' } };
    
    // Summary data
    let totalCases = 0, totalCompleted = 0, totalPending = 0, totalAmount = 0;
    report.groupSummaries.forEach(group => {
      summarySheet.addRow([
        group.groupName,
        group.totalCases,
        group.completedCases,
        group.pendingCases,
        group.amountFixed,
      ]);
      totalCases += group.totalCases;
      totalCompleted += group.completedCases;
      totalPending += group.pendingCases;
      totalAmount += group.amountFixed;
    });
    
    // Summary totals
    const summaryTotalRow = summarySheet.addRow(['مجموع کل', totalCases, totalCompleted, totalPending, totalAmount]);
    summaryTotalRow.font = { name: 'Arial', size: 11, bold: true };
    summaryTotalRow.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFC0C0C0' } };
    summaryTotalRow.eachCell((cell, colNum) => {
      cell.alignment = { horizontal: 'right', vertical: 'middle' };
      if (colNum > 1) cell.numFmt = '#,##0';
    });
    
    // Set column widths
    summarySheet.getColumn(1).width = 30;
    for (let col = 2; col <= 5; col++) {
      summarySheet.getColumn(col).width = 20;
      summarySheet.getColumn(col).numFmt = '#,##0';
    }
    
    // Sheet 2: Group Performance
    const groupSheet = workbook.addWorksheet('عملکرد گروه‌ها');
    groupSheet.views = [{ rightToLeft: true }];
    
    // Group performance header
    groupSheet.mergeCells(1, 1, 1, 6);
    const groupHeader = groupSheet.getCell(1, 1);
    groupHeader.value = `عملکرد تفصیلی گروه‌ها - ${quarterLabels[quarterNum]} سال مالی ${yearShamsi}`;
    groupHeader.font = { name: 'Arial', size: 14, bold: true };
    groupHeader.alignment = { horizontal: 'center', vertical: 'middle' };
    groupHeader.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFE0E0E0' } };
    
    // Group performance headers
    const groupHeaders = ['گروه', 'ماه', 'کل قضایا', 'تکمیل شده', 'در انتظار', 'مبلغ تثبیت شده'];
    const groupHeaderRow = groupSheet.addRow(groupHeaders);
    groupHeaderRow.font = { name: 'Arial', size: 11, bold: true };
    groupHeaderRow.alignment = { horizontal: 'right', vertical: 'middle' };
    groupHeaderRow.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFD9D9D9' } };
    
    // Group performance data
    report.groupSummaries.forEach(group => {
      group.monthlyBreakdown.forEach(monthData => {
        groupSheet.addRow([
          group.groupName,
          monthNames[monthData.month],
          monthData.totalCases,
          monthData.completedCases,
          monthData.pendingCases,
          monthData.amountFixed,
        ]);
      });
    });
    
    // Set column widths and formatting
    groupSheet.getColumn(1).width = 30;
    groupSheet.getColumn(2).width = 15;
    for (let col = 3; col <= 6; col++) {
      groupSheet.getColumn(col).width = 18;
      groupSheet.getColumn(col).numFmt = '#,##0';
    }
    
    // Sheet 3: Monthly Breakdown
    const monthlySheet = workbook.addWorksheet('تفکیک ماهوار');
    monthlySheet.views = [{ rightToLeft: true }];
    
    // Monthly breakdown header
    monthlySheet.mergeCells(1, 1, 1, 5);
    const monthlyHeader = monthlySheet.getCell(1, 1);
    monthlyHeader.value = `تفکیک ماهوار - ${quarterLabels[quarterNum]} سال مالی ${yearShamsi}`;
    monthlyHeader.font = { name: 'Arial', size: 14, bold: true };
    monthlyHeader.alignment = { horizontal: 'center', vertical: 'middle' };
    monthlyHeader.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFE0E0E0' } };
    
    // Monthly breakdown headers
    const monthlyHeaders = ['ماه', 'کل قضایا', 'تکمیل شده', 'در انتظار', 'مبلغ تثبیت شده'];
    const monthlyHeaderRow = monthlySheet.addRow(monthlyHeaders);
    monthlyHeaderRow.font = { name: 'Arial', size: 11, bold: true };
    monthlyHeaderRow.alignment = { horizontal: 'right', vertical: 'middle' };
    monthlyHeaderRow.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFD9D9D9' } };
    
    // Monthly breakdown data
    report.monthlyData.forEach(monthData => {
      monthlySheet.addRow([
        monthNames[monthData.month],
        monthData.totalCases,
        monthData.completedCases,
        monthData.pendingCases,
        monthData.amountFixed,
      ]);
    });
    
    // Set column widths and formatting
    monthlySheet.getColumn(1).width = 20;
    for (let col = 2; col <= 5; col++) {
      monthlySheet.getColumn(col).width = 18;
      monthlySheet.getColumn(col).numFmt = '#,##0';
    }
    
    // Set response headers
    const encodedFilename = encodeURIComponent(`three-month-group-performance-${yearShamsi}-q${quarterNum}.xlsx`);
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename="${encodedFilename}"; filename*=UTF-8''${encodedFilename}`);
    
    await workbook.xlsx.write(res);
    res.end();
    
    // Log export
    await storage.createAuditLog({
      userId: user.id,
      action: 'export_three_month_group_performance',
      entityType: 'report',
      entityId: 'three-month-group-performance',
      details: { yearShamsi, quarter: quarterNum },
      ipAddress: extractClientIp(req),
    });
  } catch (error) {
    console.error('Error exporting 3-month group performance report:', error);
    res.status(500).json({ message: "خطا در صادر کردن گزارش" });
  }
});

// ============================================
// TAX INSTALLMENT AND LAW ENFORCEMENT REPORT
// ============================================

// Get tax installment and law enforcement report
router.get("/tax-installment-law-enforcement", requireAuth, requirePermission('reports:generate'), async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    const { reportType, year, quarter, month } = req.query;

    // Validate report type
    if (!reportType || (reportType !== 'yearly' && reportType !== '3-month' && reportType !== 'monthly')) {
      return res.status(400).json({ message: "نوع گزارش الزامی است و باید 'yearly'، '3-month' یا 'monthly' باشد" });
    }

    // Validate year parameter
    if (!year) {
      return res.status(400).json({ message: "سال الزامی است" });
    }

    const yearShamsi = parseInt(year as string);
    
    if (isNaN(yearShamsi) || yearShamsi < 1300 || yearShamsi > 1500) {
      return res.status(400).json({ message: "سال نامعتبر است" });
    }

    // Validate month for monthly reports
    let monthNum: number | undefined;
    if (reportType === 'monthly') {
      if (!month) {
        return res.status(400).json({ message: "ماه برای گزارش ماهوار الزامی است" });
      }

      monthNum = parseInt(month as string);
      
      if (isNaN(monthNum) || monthNum < 1 || monthNum > 12) {
        return res.status(400).json({ message: "ماه نامعتبر است. باید بین 1 تا 12 باشد." });
      }
    }

    // Validate quarter for 3-month reports
    let quarterNum: number | undefined;
    if (reportType === '3-month') {
      if (!quarter) {
        return res.status(400).json({ message: "سه‌ماهه برای گزارش سه‌ماهه الزامی است" });
      }

      quarterNum = parseInt(quarter as string);
      
      if (isNaN(quarterNum) || quarterNum < 1 || quarterNum > 4) {
        return res.status(400).json({ message: "سه‌ماهه نامعتبر است. باید بین 1 تا 4 باشد." });
      }
    }

    // Get tax installment and law enforcement report data
    const { getTaxInstallmentLawEnforcementReport } = await import('../services/taxInstallmentLawEnforcementService');
    
    // For monthly reports, we need to convert month to a quarter-like structure
    // or modify the service to accept month parameter
    let actualReportType: 'yearly' | '3-month' = reportType === 'monthly' ? '3-month' : reportType as 'yearly' | '3-month';
    let actualQuarter: number | undefined = quarterNum;
    
    if (reportType === 'monthly' && monthNum) {
      // Convert month to quarter
      actualQuarter = Math.ceil(monthNum / 3);
    }
    
    const report = await getTaxInstallmentLawEnforcementReport(
      yearShamsi,
      actualReportType,
      actualQuarter
    );
    
    // For monthly reports, filter the data to only include the specific month
    if (reportType === 'monthly' && monthNum) {
      // Filter monthly data
      if (report.monthlyTrends) {
        report.monthlyTrends = report.monthlyTrends.filter((m: any) => m.month === monthNum);
      }
      if (report.byGroup) {
        report.byGroup = report.byGroup.map((group: any) => ({
          ...group,
          monthlyData: group.monthlyData.filter((m: any) => m.month === monthNum),
        }));
      }
      // Recalculate summary for the single month
      if (report.monthlyTrends && report.monthlyTrends.length > 0) {
        const monthData = report.monthlyTrends[0];
        report.summary = {
          totalInstallmentCases: monthData.installmentCases.total,
          completedInstallmentCases: monthData.installmentCases.completed,
          pendingInstallmentCases: monthData.installmentCases.pending,
          totalInstallmentAmountFixed: monthData.installmentCases.amountFixed,
          totalLawEnforcementCases: monthData.lawEnforcementCases.total,
          completedLawEnforcementCases: monthData.lawEnforcementCases.completed,
          pendingLawEnforcementCases: monthData.lawEnforcementCases.pending,
          totalLawEnforcementAmountFixed: monthData.lawEnforcementCases.amountFixed,
        };
      }
    }

    // Log report access
    await storage.createAuditLog({
      userId: user.id,
      action: 'view_tax_installment_law_enforcement_report',
      entityType: 'report',
      entityId: 'tax-installment-law-enforcement',
      details: {
        reportType,
        yearShamsi,
        quarter: quarterNum,
        month: monthNum,
        installmentCases: report.summary.totalInstallmentCases,
        lawEnforcementCases: report.summary.totalLawEnforcementCases,
        groupCount: report.byGroup.length,
      },
      ipAddress: extractClientIp(req),
    });

    res.json(report);
  } catch (error) {
    console.error('Error fetching tax installment and law enforcement report:', error);
    if (error instanceof Error && error.message.includes('Quarter is required')) {
      return res.status(400).json({ message: error.message });
    }
    res.status(500).json({ message: "خطا در دریافت گزارش" });
  }
});

// Export tax installment and law enforcement report to Excel
router.get("/tax-installment-law-enforcement/export", requireAuth, requirePermission('reports:generate'), async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    const { reportType, year, quarter, month } = req.query;

    if (!reportType || (reportType !== 'yearly' && reportType !== '3-month' && reportType !== 'monthly')) {
      return res.status(400).json({ message: "نوع گزارش الزامی است" });
    }

    if (!year) {
      return res.status(400).json({ message: "سال الزامی است" });
    }

    const yearShamsi = parseInt(year as string);
    
    if (isNaN(yearShamsi) || yearShamsi < 1300 || yearShamsi > 1500) {
      return res.status(400).json({ message: "سال نامعتبر است" });
    }

    let monthNum: number | undefined;
    if (reportType === 'monthly') {
      if (!month) {
        return res.status(400).json({ message: "ماه الزامی است" });
      }
      monthNum = parseInt(month as string);
      if (isNaN(monthNum) || monthNum < 1 || monthNum > 12) {
        return res.status(400).json({ message: "ماه نامعتبر است" });
      }
    }

    let quarterNum: number | undefined;
    if (reportType === '3-month') {
      if (!quarter) {
        return res.status(400).json({ message: "سه‌ماهه الزامی است" });
      }
      quarterNum = parseInt(quarter as string);
      if (isNaN(quarterNum) || quarterNum < 1 || quarterNum > 4) {
        return res.status(400).json({ message: "سه‌ماهه نامعتبر است" });
      }
    }

    const { getTaxInstallmentLawEnforcementReport } = await import('../services/taxInstallmentLawEnforcementService');
    
    // For monthly reports, convert to quarter
    let actualReportType: 'yearly' | '3-month' = reportType === 'monthly' ? '3-month' : reportType as 'yearly' | '3-month';
    let actualQuarter: number | undefined = quarterNum;
    
    if (reportType === 'monthly' && monthNum) {
      actualQuarter = Math.ceil(monthNum / 3);
    }
    
    const report = await getTaxInstallmentLawEnforcementReport(yearShamsi, actualReportType, actualQuarter);
    
    // Filter for monthly if needed
    if (reportType === 'monthly' && monthNum) {
      if (report.monthlyTrends) {
        report.monthlyTrends = report.monthlyTrends.filter((m: any) => m.month === monthNum);
      }
      if (report.byGroup) {
        report.byGroup = report.byGroup.map((group: any) => ({
          ...group,
          monthlyData: group.monthlyData.filter((m: any) => m.month === monthNum),
        }));
      }
    }

    // Month names in Dari
    const monthNames = ['', 'حمل', 'ثور', 'جوزا', 'سرطان', 'اسد', 'سنبله', 'میزان', 'عقرب', 'قوس', 'جدی', 'دلو', 'حوت'];
    const quarterLabels = ['', 'سه‌ماهه اول', 'سه‌ماهه دوم', 'سه‌ماهه سوم', 'سه‌ماهه چهارم'];
    const periodLabel = reportType === 'yearly' 
      ? `سال مالی ${yearShamsi}`
      : reportType === 'monthly' && monthNum
      ? `برج ${monthNames[monthNum]} سال مالی ${yearShamsi}`
      : `${quarterLabels[quarterNum!]} سال مالی ${yearShamsi}`;

    // Create workbook
    const workbook = new ExcelJS.Workbook();
    
    // Sheet 1: Summary
    const summarySheet = workbook.addWorksheet('خلاصه');
    summarySheet.views = [{ rightToLeft: true }];
    
    // Summary header
    summarySheet.mergeCells(1, 1, 1, 9);
    const summaryHeader = summarySheet.getCell(1, 1);
    summaryHeader.value = `گزارش قضایای اقساط و تنفیذ قانون - ${periodLabel}`;
    summaryHeader.font = { name: 'Arial', size: 14, bold: true };
    summaryHeader.alignment = { horizontal: 'center', vertical: 'middle' };
    summaryHeader.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFE0E0E0' } };
    
    // Summary section headers
    summarySheet.mergeCells(3, 1, 3, 4);
    const installmentHeader = summarySheet.getCell(3, 1);
    installmentHeader.value = 'قضایای اقساط';
    installmentHeader.font = { name: 'Arial', size: 12, bold: true };
    installmentHeader.alignment = { horizontal: 'right', vertical: 'middle' };
    installmentHeader.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFD0D0D0' } };
    
    summarySheet.mergeCells(3, 5, 3, 8);
    const lawEnforcementHeader = summarySheet.getCell(3, 5);
    lawEnforcementHeader.value = 'قضایای تنفیذ قانون';
    lawEnforcementHeader.font = { name: 'Arial', size: 12, bold: true };
    lawEnforcementHeader.alignment = { horizontal: 'right', vertical: 'middle' };
    lawEnforcementHeader.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFD0D0D0' } };
    
    // Summary column headers
    const summaryColHeaders = ['کل قضایا', 'تکمیل شده', 'در انتظار', 'مبلغ تثبیت شده', 'کل قضایا', 'تکمیل شده', 'در انتظار', 'مبلغ تثبیت شده'];
    const summaryColHeaderRow = summarySheet.addRow(summaryColHeaders);
    summaryColHeaderRow.font = { name: 'Arial', size: 11, bold: true };
    summaryColHeaderRow.alignment = { horizontal: 'right', vertical: 'middle' };
    summaryColHeaderRow.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFD9D9D9' } };
    
    // Summary data
    const summaryDataRow = summarySheet.addRow([
      report.summary.totalInstallmentCases,
      report.summary.completedInstallmentCases,
      report.summary.pendingInstallmentCases,
      report.summary.totalInstallmentAmountFixed,
      report.summary.totalLawEnforcementCases,
      report.summary.completedLawEnforcementCases,
      report.summary.pendingLawEnforcementCases,
      report.summary.totalLawEnforcementAmountFixed,
    ]);
    summaryDataRow.eachCell((cell) => {
      cell.alignment = { horizontal: 'right', vertical: 'middle' };
      cell.numFmt = '#,##0';
    });
    
    // Set column widths
    for (let col = 1; col <= 8; col++) {
      summarySheet.getColumn(col).width = 18;
    }
    
    // Sheet 2: Group Performance
    const groupSheet = workbook.addWorksheet('عملکرد گروه‌ها');
    groupSheet.views = [{ rightToLeft: true }];
    
    // Group performance header
    groupSheet.mergeCells(1, 1, 1, 9);
    const groupHeader = groupSheet.getCell(1, 1);
    groupHeader.value = `عملکرد تفصیلی گروه‌ها - ${periodLabel}`;
    groupHeader.font = { name: 'Arial', size: 14, bold: true };
    groupHeader.alignment = { horizontal: 'center', vertical: 'middle' };
    groupHeader.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFE0E0E0' } };
    
    // Group performance headers
    const groupHeaders = ['گروه', 'ماه', 'اقساط - کل', 'اقساط - تکمیل', 'اقساط - انتظار', 'اقساط - مبلغ', 'تنفیذ - کل', 'تنفیذ - تکمیل', 'تنفیذ - انتظار', 'تنفیذ - مبلغ'];
    const groupHeaderRow = groupSheet.addRow(groupHeaders);
    groupHeaderRow.font = { name: 'Arial', size: 11, bold: true };
    groupHeaderRow.alignment = { horizontal: 'right', vertical: 'middle' };
    groupHeaderRow.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFD9D9D9' } };
    
    // Group performance data
    report.byGroup.forEach(group => {
      group.monthlyData.forEach(monthData => {
        const dataRow = groupSheet.addRow([
          group.groupName,
          monthNames[monthData.month],
          monthData.installmentCases.total,
          monthData.installmentCases.completed,
          monthData.installmentCases.pending,
          monthData.installmentCases.amountFixed,
          monthData.lawEnforcementCases.total,
          monthData.lawEnforcementCases.completed,
          monthData.lawEnforcementCases.pending,
          monthData.lawEnforcementCases.amountFixed,
        ]);
        dataRow.eachCell((cell, colNum) => {
          cell.alignment = { horizontal: 'right', vertical: 'middle' };
          if (colNum > 2) cell.numFmt = '#,##0';
        });
      });
    });
    
    // Set column widths and formatting
    groupSheet.getColumn(1).width = 30;
    groupSheet.getColumn(2).width = 15;
    for (let col = 3; col <= 10; col++) {
      groupSheet.getColumn(col).width = 15;
      groupSheet.getColumn(col).numFmt = '#,##0';
    }
    
    // Sheet 3: Monthly Breakdown
    const monthlySheet = workbook.addWorksheet('تفکیک ماهوار');
    monthlySheet.views = [{ rightToLeft: true }];
    
    // Monthly breakdown header
    monthlySheet.mergeCells(1, 1, 1, 9);
    const monthlyHeader = monthlySheet.getCell(1, 1);
    monthlyHeader.value = `تفکیک ماهوار - ${periodLabel}`;
    monthlyHeader.font = { name: 'Arial', size: 14, bold: true };
    monthlyHeader.alignment = { horizontal: 'center', vertical: 'middle' };
    monthlyHeader.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFE0E0E0' } };
    
    // Monthly breakdown section headers
    monthlySheet.mergeCells(3, 1, 3, 4);
    const monthlyInstallmentHeader = monthlySheet.getCell(3, 1);
    monthlyInstallmentHeader.value = 'قضایای اقساط';
    monthlyInstallmentHeader.font = { name: 'Arial', size: 12, bold: true };
    monthlyInstallmentHeader.alignment = { horizontal: 'right', vertical: 'middle' };
    monthlyInstallmentHeader.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFD0D0D0' } };
    
    monthlySheet.mergeCells(3, 5, 3, 8);
    const monthlyLawEnforcementHeader = monthlySheet.getCell(3, 5);
    monthlyLawEnforcementHeader.value = 'قضایای تنفیذ قانون';
    monthlyLawEnforcementHeader.font = { name: 'Arial', size: 12, bold: true };
    monthlyLawEnforcementHeader.alignment = { horizontal: 'right', vertical: 'middle' };
    monthlyLawEnforcementHeader.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFD0D0D0' } };
    
    // Monthly breakdown column headers
    const monthlyColHeaders = ['ماه', 'کل', 'تکمیل', 'انتظار', 'مبلغ', 'کل', 'تکمیل', 'انتظار', 'مبلغ'];
    const monthlyColHeaderRow = monthlySheet.addRow(monthlyColHeaders);
    monthlyColHeaderRow.font = { name: 'Arial', size: 11, bold: true };
    monthlyColHeaderRow.alignment = { horizontal: 'right', vertical: 'middle' };
    monthlyColHeaderRow.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFD9D9D9' } };
    
    // Monthly breakdown data
    report.monthlyTrends.forEach(monthData => {
      const dataRow = monthlySheet.addRow([
        monthNames[monthData.month],
        monthData.installmentCases.total,
        monthData.installmentCases.completed,
        monthData.installmentCases.pending,
        monthData.installmentCases.amountFixed,
        monthData.lawEnforcementCases.total,
        monthData.lawEnforcementCases.completed,
        monthData.lawEnforcementCases.pending,
        monthData.lawEnforcementCases.amountFixed,
      ]);
      dataRow.eachCell((cell, colNum) => {
        cell.alignment = { horizontal: 'right', vertical: 'middle' };
        if (colNum > 1) cell.numFmt = '#,##0';
      });
    });
    
    // Set column widths and formatting
    monthlySheet.getColumn(1).width = 20;
    for (let col = 2; col <= 9; col++) {
      monthlySheet.getColumn(col).width = 15;
      monthlySheet.getColumn(col).numFmt = '#,##0';
    }
    
    // Set response headers
    const filename = reportType === 'yearly'
      ? `tax-installment-law-enforcement-${yearShamsi}.xlsx`
      : `tax-installment-law-enforcement-${yearShamsi}-q${quarterNum}.xlsx`;
    const encodedFilename = encodeURIComponent(filename);
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename="${encodedFilename}"; filename*=UTF-8''${encodedFilename}`);
    
    await workbook.xlsx.write(res);
    res.end();
    
    // Log export
    await storage.createAuditLog({
      userId: user.id,
      action: 'export_tax_installment_law_enforcement',
      entityType: 'report',
      entityId: 'tax-installment-law-enforcement',
      details: { reportType, yearShamsi, quarter: quarterNum },
      ipAddress: extractClientIp(req),
    });
  } catch (error) {
    console.error('Error exporting tax installment and law enforcement report:', error);
    res.status(500).json({ message: "خطا در صادر کردن گزارش" });
  }
});

export default router;
