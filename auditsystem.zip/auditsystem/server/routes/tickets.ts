import { Router, type Request, type Response } from "express";
import { storage } from "../storage";
import { insertTicketSchema } from "@shared/schema";
import { requireAuth } from "../middleware/auth";
import { requirePermission } from "../middleware/permissions";
import { generateTicketId } from "../utils/idGenerator";
import { extractClientIp } from "../utils/ipExtractor";

const router = Router();

// Anonymous Lost Password Ticket Creation (Public endpoint - no auth required)
router.post("/lost-password", async (req: Request, res: Response) => {
  try {
    const { auditId, groupId, phoneNumber, description } = req.body;

    // Validate required fields
    if (!auditId || !groupId || !phoneNumber) {
      return res.status(400).json({ 
        message: "آی دی بررسی، گروه، و شماره تلفن الزامی است" 
      });
    }

    // Verify user exists with matching audit ID and phone
    const user = await storage.getUserByAuditId(auditId);
    if (!user) {
      return res.status(404).json({ 
        message: "کاربری با این آی دی بررسی یافت نشد" 
      });
    }

    if (user.phoneNumber !== phoneNumber) {
      return res.status(400).json({ 
        message: "شماره تلفن مطابقت ندارد" 
      });
    }

    // Verify group membership
    if (user.groupId !== groupId) {
      return res.status(400).json({ 
        message: "گروه مطابقت ندارد" 
      });
    }

    const ticketId = await generateTicketId();
    
    const ticketData = {
      ticketId,
      type: 'lost_password',
      requestedBy: user.id,
      status: 'منتظر تایید',
      description: description || 'درخواست بازیابی رمز عبور',
      auditId,
      groupId,
      phoneNumber,
    };
    
    const newTicket = await storage.createTicket(ticketData);
    
    await storage.createAuditLog({
      userId: user.id,
      action: 'create_lost_password_ticket',
      entityType: 'ticket',
      entityId: newTicket.id,
      newValue: { ticketId, auditId, groupId },
      ipAddress: extractClientIp(req),
    });
    
    res.status(201).json({ 
      message: "تکت بازیابی رمز عبور با موفقیت ایجاد شد",
      ticketId: newTicket.ticketId 
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "خطا در ایجاد تکت بازیابی رمز عبور" });
  }
});

// Get all tickets (filtered by permissions)
router.get("/", requireAuth, async (req: Request, res: Response) => {
  try {
    // User data is already refreshed by refreshUserData middleware
    const user = req.user as any;
    if (!user || !user.id) {
      return res.status(401).json({ message: 'احراز هویت نشده' });
    }
    
    // CRITICAL RBAC ENFORCEMENT: Use unified permission helper
    const { getTicketVisibility } = await import('../utils/permissionHelpers');
    const visibility = await getTicketVisibility(user);
    
    let tickets;
    
    if (visibility.canViewAll) {
      // User can see all tickets (coordinator, admin, users with tickets:approve)
      tickets = await storage.getTickets();
    } else if (visibility.requiresFiltering) {
      if (visibility.filterByAssignee) {
        // Users with tickets:submit see only tickets they created
        const allTickets = await storage.getTickets();
        tickets = allTickets.filter(t => t.requestedBy === user.id);
      } else {
        // No access
        tickets = [];
      }
    } else {
      // No access
      tickets = [];
    }
    
    res.json(tickets);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "خطا در دریافت لیست تکت‌ها" });
  }
});

// Get ticket by ID
router.get("/:id", requireAuth, async (req: Request, res: Response) => {
  try {
    const ticket = await storage.getTicket(req.params.id);
    if (!ticket) {
      return res.status(404).json({ message: "تکت یافت نشد" });
    }
    res.json(ticket);
  } catch (error) {
    res.status(500).json({ message: "خطا در دریافت اطلاعات تکت" });
  }
});

// Create ticket
router.post("/", requireAuth, async (req: Request, res: Response) => {
  try {
    const ticketId = await generateTicketId();
    
    const ticketData = {
      ...req.body,
      ticketId,
      requestedBy: (req.user as any).id,
      status: 'منتظر تایید',
    };
    
    const validatedData = insertTicketSchema.parse(ticketData);
    const newTicket = await storage.createTicket(validatedData);
    
    await storage.createAuditLog({
      userId: (req.user as any).id,
      action: 'create_ticket',
      entityType: 'ticket',
      entityId: newTicket.id,
      details: {
        newValue: newTicket,
        ticketId: newTicket.ticketId,
        type: newTicket.type,
        createdAt: newTicket.createdAt?.toISOString(),
      },
      ipAddress: extractClientIp(req),
    });
    
    res.status(201).json(newTicket);
  } catch (error) {
    console.error(error);
    res.status(400).json({ message: "خطا در ایجاد تکت" });
  }
});

// Bulk create approval tickets
router.post("/bulk", requireAuth, async (req: Request, res: Response) => {
  try {
    const { tickets } = req.body;
    
    if (!Array.isArray(tickets) || tickets.length === 0) {
      return res.status(400).json({ 
        message: "لیست تکت‌ها باید یک آرایه غیر خالی باشد" 
      });
    }

    if (tickets.length > 50) {
      return res.status(400).json({ 
        message: "حداکثر ۵۰ تکت را می‌توان به صورت همزمان ایجاد کرد" 
      });
    }

    const createdTickets = [];
    const errors = [];

    for (let i = 0; i < tickets.length; i++) {
      try {
        const ticketId = await generateTicketId();
        
        const ticketData = {
          ...tickets[i],
          ticketId,
          requestedBy: (req.user as any).id,
          status: 'منتظر تایید',
        };
        
        const validatedData = insertTicketSchema.parse(ticketData);
        const newTicket = await storage.createTicket(validatedData);
        
        await storage.createAuditLog({
          userId: (req.user as any).id,
          action: 'create_ticket',
          entityType: 'ticket',
          entityId: newTicket.id,
          newValue: newTicket,
        });
        
        createdTickets.push(newTicket);
      } catch (error: any) {
        errors.push({
          index: i,
          ticket: tickets[i],
          error: error.message || 'خطای نامشخص'
        });
      }
    }

    res.status(201).json({
      message: `${createdTickets.length} تکت با موفقیت ایجاد شد`,
      created: createdTickets,
      errors: errors.length > 0 ? errors : undefined,
      total: tickets.length,
      successful: createdTickets.length,
      failed: errors.length
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "خطا در ایجاد تکت‌های دسته‌ای" });
  }
});

// Approve ticket
router.post("/:id/approve", requireAuth, requirePermission('tickets:approve'), async (req: Request, res: Response) => {
  try {
    const updatedTicket = await storage.updateTicketStatus(req.params.id, 'تایید شده');
    
    if (!updatedTicket) {
      return res.status(404).json({ message: "تکت یافت نشد" });
    }
    
    await storage.createAuditLog({
      userId: (req.user as any).id,
      action: 'approve_ticket',
      entityType: 'ticket',
      entityId: updatedTicket.id,
      details: {
        oldValue: { status: updatedTicket.status },
        newValue: { status: 'تایید شده' },
        ticketId: updatedTicket.ticketId,
        approvedBy: (req.user as any).id,
        approvedAt: new Date().toISOString(),
      },
      ipAddress: extractClientIp(req),
    });
    
    if (updatedTicket.caseId) {
      await storage.updateCaseStatus(updatedTicket.caseId, 'تایید شده');
    }
    
    await storage.createNotification({
      userId: updatedTicket.requestedBy,
      message: `تکت شما ${updatedTicket.ticketId} تایید شد`,
      messagePashto: `ستاسو ټکټ ${updatedTicket.ticketId} تایید شو`,
      type: 'ticket_approved',
    });
    
    res.json(updatedTicket);
  } catch (error) {
    res.status(500).json({ message: "خطا در تایید تکت" });
  }
});

// Reject ticket
router.post("/:id/reject", requireAuth, requirePermission('tickets:approve'), async (req: Request, res: Response) => {
  try {
    const { reason } = req.body;
    const updatedTicket = await storage.updateTicketStatus(req.params.id, 'رد شده');
    
    if (!updatedTicket) {
      return res.status(404).json({ message: "تکت یافت نشد" });
    }
    
    const ticket = await storage.getTicket(req.params.id);
    await storage.createAuditLog({
      userId: (req.user as any).id,
      action: 'reject_ticket',
      entityType: 'ticket',
      entityId: updatedTicket.id,
      details: {
        oldValue: { status: ticket?.status },
        newValue: { status: 'رد شده', reason },
        ticketId: updatedTicket.ticketId,
        rejectedBy: (req.user as any).id,
        rejectedAt: new Date().toISOString(),
      },
      ipAddress: extractClientIp(req),
    });
    
    if (updatedTicket.caseId) {
      await storage.updateCaseStatus(updatedTicket.caseId, 'رد شده');
    }
    
    await storage.createNotification({
      userId: updatedTicket.requestedBy,
      message: `تکت شما ${updatedTicket.ticketId} رد شد. دلیل: ${reason || 'مشخص نشده'}`,
      messagePashto: `ستاسو ټکټ ${updatedTicket.ticketId} رد شو. دلیل: ${reason || 'نه دی ټاکل شوی'}`,
      type: 'ticket_rejected',
    });
    
    res.json(updatedTicket);
  } catch (error) {
    res.status(500).json({ message: "خطا در رد تکت" });
  }
});

// Reset password from ticket (Admin only - generates new password)
router.post("/:id/reset-password", requireAuth, requirePermission('users:manage'), async (req: Request, res: Response) => {
  try {
    const ticket = await storage.getTicket(req.params.id);
    if (!ticket) {
      return res.status(404).json({ message: "تکت یافت نشد" });
    }
    
    // Check ticket type
    if (ticket.type !== 'lost_password' && ticket.type !== 'بازیابی رمز') {
      return res.status(400).json({ message: "این تکت برای بازیابی رمز عبور نیست" });
    }
    
    // Check ticket status
    if (ticket.status !== 'منتظر تایید' && ticket.status !== 'pending_reset') {
      return res.status(400).json({ message: "این تکت قبلاً پردازش شده است" });
    }
    
    // Get user from ticket
    const user = await storage.getUser(ticket.requestedBy);
    if (!user) {
      return res.status(404).json({ message: "کاربر یافت نشد" });
    }
    
    // Generate secure random password (16 characters)
    const { generateRandomPassword } = await import('../utils/idGenerator');
    const plainPassword = generateRandomPassword();
    
    // Hash and update password
    const { hashPassword } = await import('../auth/password');
    const hashedPassword = await hashPassword(plainPassword);
    
    await storage.updateUser(user.id, {
      password: hashedPassword,
      mustChangePassword: true,
      passwordExpiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000), // 24 hours
    });
    
    // Update ticket status
    await storage.updateTicketStatus(req.params.id, 'تایید شده');
    
    // Audit log (DO NOT include plaintext password)
    await storage.createAuditLog({
      userId: (req.user as any).id,
      action: 'password_reset',
      entityType: 'user',
      entityId: user.id,
      details: {
        ticketId: ticket.id,
        ticketType: ticket.type,
        resetForUserId: user.id,
        resetForAuditId: user.auditId,
      },
      ipAddress: extractClientIp(req),
    });
    
    // Return plaintext password (one-time only, not stored)
    res.json({ 
      password: plainPassword,
      message: 'رمز عبور با موفقیت بازنشانی شد'
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "خطا در بازنشانی رمز عبور" });
  }
});

// Legacy endpoint - kept for backward compatibility
router.post("/:id/resolve-password", requireAuth, requirePermission('users:manage'), async (req: Request, res: Response) => {
  try {
    const { newPassword } = req.body;
    
    if (!newPassword || newPassword.length < 8) {
      return res.status(400).json({ 
        message: "رمز عبور جدید باید حداقل ۸ کاراکتر باشد" 
      });
    }

    const ticket = await storage.getTicket(req.params.id);
    if (!ticket) {
      return res.status(404).json({ message: "تکت یافت نشد" });
    }

    if (ticket.type !== 'lost_password') {
      return res.status(400).json({ 
        message: "این تکت یک تکت بازیابی رمز عبور نیست" 
      });
    }

    if (ticket.status === 'تایید شده') {
      return res.status(400).json({ 
        message: "این تکت قبلاً حل شده است" 
      });
    }

    // Update user password with 24h expiry
    // Note: passwordChangedAt is left null until user changes it themselves
    const passwordExpiresAt = new Date();
    passwordExpiresAt.setHours(passwordExpiresAt.getHours() + 24);

    await storage.updateUser(ticket.requestedBy, {
      password: newPassword,
      mustChangePassword: true,
      passwordExpiresAt,
    });

    // Update ticket status
    await storage.updateTicketStatus(req.params.id, 'تایید شده');

    await storage.createAuditLog({
      userId: (req.user as any).id,
      action: 'resolve_lost_password_ticket',
      entityType: 'ticket',
      entityId: ticket.id,
      newValue: { status: 'تایید شده', passwordReset: true },
      ipAddress: extractClientIp(req),
    });

    // Notify user
    await storage.createNotification({
      userId: ticket.requestedBy,
      message: `رمز عبور شما بازیابی شد. رمز عبور جدید ظرف ۲۴ ساعت منقضی می‌شود`,
      messagePashto: `ستاسو پټ نوم بیرته ترلاسه شو. نوی پټ نوم په ۲۴ ساعتو کې ختمیږي`,
      type: 'password_reset',
    });

    res.json({ 
      message: "رمز عبور با موفقیت بازیابی شد",
      expiresAt: passwordExpiresAt 
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "خطا در بازیابی رمز عبور" });
  }
});

export default router;
