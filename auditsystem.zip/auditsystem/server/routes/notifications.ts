import { Router, type Request, type Response } from "express";
import { storage } from "../storage";
import { requireAuth } from "../middleware/auth";

const router = Router();

// Get current user's notifications
router.get("/", requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    const notifications = await storage.getNotifications(user.id);
    res.json(notifications);
  } catch (error) {
    res.status(500).json({ message: "خطا در دریافت اعلان‌ها" });
  }
});

// Mark notification as read
router.post("/:id/mark-read", requireAuth, async (req: Request, res: Response) => {
  try {
    await storage.markNotificationAsRead(req.params.id);
    res.json({ message: "اعلان به عنوان خوانده شده علامت گذاری شد" });
  } catch (error) {
    res.status(500).json({ message: "خطا در بروزرسانی اعلان" });
  }
});

export default router;
