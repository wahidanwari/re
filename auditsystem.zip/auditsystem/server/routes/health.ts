import { Router, type Request, type Response } from "express";
import { pool } from "../db";

const router = Router();

/**
 * GET /api/health
 * Health check endpoint - checks server and database connectivity
 * This endpoint is public and can be used for monitoring and load balancers
 */
router.get("/", async (_req: Request, res: Response) => {
  const health = {
    status: "healthy",
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    environment: process.env.NODE_ENV || "development",
    version: process.env.npm_package_version || "1.0.0",
    checks: {
      server: "ok",
      database: "unknown",
    },
  };

  // Check database connectivity
  try {
    const client = await pool.connect();
    try {
      // Simple query to check database is responsive
      await client.query("SELECT 1");
      health.checks.database = "ok";
    } finally {
      client.release();
    }
  } catch (error) {
    health.status = "degraded";
    health.checks.database = "error";
    console.error("Database health check failed:", error);
  }

  // Return appropriate status code based on health
  const statusCode = health.status === "healthy" ? 200 : 503;

  res.status(statusCode).json(health);
});

/**
 * GET /api/health/ready
 * Readiness probe - checks if the service is ready to accept traffic
 * More thorough checks than basic health endpoint
 */
router.get("/ready", async (_req: Request, res: Response) => {
  const checks: Record<string, any> = {
    server: { status: "ok", timestamp: new Date().toISOString() },
    database: { status: "unknown", timestamp: new Date().toISOString() },
  };

  // Check database connectivity and basic functionality
  try {
    const client = await pool.connect();
    try {
      // Check if we can query a system table
      const result = await client.query("SELECT NOW() as current_time");
      checks.database = {
        status: "ok",
        timestamp: new Date().toISOString(),
        databaseTime: result.rows[0]?.current_time,
      };
    } finally {
      client.release();
    }
  } catch (error: any) {
    checks.database = {
      status: "error",
      timestamp: new Date().toISOString(),
      error: error.message || "Database connection failed",
    };
    return res.status(503).json({
      status: "not_ready",
      checks,
      message: "Service is not ready",
    });
  }

  res.status(200).json({
    status: "ready",
    checks,
    message: "Service is ready to accept traffic",
  });
});

/**
 * GET /api/health/live
 * Liveness probe - checks if the service is alive
 * Minimal check, should always return 200 if process is running
 */
router.get("/live", (_req: Request, res: Response) => {
  res.status(200).json({
    status: "alive",
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
  });
});

export default router;

