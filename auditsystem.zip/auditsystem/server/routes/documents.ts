import { Router, type Request, type Response } from "express";
import multer from "multer";
import { storage } from "../storage";
import { requireAuth } from "../middleware/auth";
import { requirePermission } from "../middleware/permissions";
import { extractClientIp } from "../utils/ipExtractor";
import {
  saveDocument,
  getDocument,
  isValidFileType,
  isValidDocumentType,
  MAX_FILE_SIZE,
  ALLOWED_DOCUMENT_TYPES,
} from "../utils/documentStorage";

const router = Router();

const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: MAX_FILE_SIZE,
  },
  fileFilter: (_req, file, cb) => {
    // Check both MIME type and filename extension (browsers sometimes send wrong MIME types)
    if (isValidFileType(file.mimetype, file.originalname)) {
      cb(null, true);
    } else {
      cb(new Error(`نوع فایل مجاز نیست. نوع: ${file.mimetype}, فایل: ${file.originalname}`));
    }
  },
});

router.get("/case/:caseId", requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    const { userHasPermission } = await import('../middleware/permissions');
    
    // System admin can see all documents
    if (user.role !== 'system_admin') {
      // Check if user has cases:view permission
      const hasView = await userHasPermission(user, 'cases:view');
      if (!hasView) {
        return res.status(403).json({ message: 'عدم دسترسی - شما مجوز مشاهده اسناد را ندارید' });
      }
    }
    
    const caseData = await storage.getCasesByCaseId(req.params.caseId);
    if (!caseData) {
      return res.status(404).json({ message: "قضیه یافت نشد" });
    }
    
    const documents = await storage.getDocuments(caseData.id);
    res.json(documents);
  } catch (error) {
    res.status(500).json({ message: "خطا در دریافت اسناد" });
  }
});

router.get("/:id", requireAuth, async (req: Request, res: Response) => {
  try {
    const document = await storage.getDocument(req.params.id);
    if (!document) {
      return res.status(404).json({ message: "سند یافت نشد" });
    }
    res.json(document);
  } catch (error) {
    res.status(500).json({ message: "خطا در دریافت سند" });
  }
});

router.get("/:id/download", requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    const { userHasPermission } = await import('../middleware/permissions');
    
    // System admin can download any document
    if (user.role !== 'system_admin') {
      // Check if user has documents:download or cases:view permission
      const canDownload = await userHasPermission(user, 'documents:download') || 
                          await userHasPermission(user, 'cases:view');
      if (!canDownload) {
        return res.status(403).json({ message: 'عدم دسترسی - شما مجوز دانلود اسناد را ندارید' });
      }
    }
    
    const document = await storage.getDocument(req.params.id);
    if (!document) {
      return res.status(404).json({ message: "سند یافت نشد" });
    }

    const fileBuffer = await getDocument(document.storagePath);
    
    const filename = document.storagePath.split('/').pop() || 'document';
    
    res.setHeader('Content-Type', document.mimeType);
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.setHeader('Content-Length', document.sizeBytes);
    
    res.send(fileBuffer);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "خطا در دانلود فایل" });
  }
});

router.post("/upload", requireAuth, requirePermission('documents:upload'), (req: Request, res: Response, next: any) => {
  upload.single('file')(req, res, (err: any) => {
    if (err) {
      // Handle multer errors
      if (err.code === 'LIMIT_FILE_SIZE') {
        return res.status(400).json({ message: 'حجم فایل بیش از حد مجاز است (حداکثر 25MB)' });
      }
      // Handle fileFilter errors and other multer errors
      return res.status(400).json({ message: err.message || 'خطا در آپلود فایل' });
    }
    next();
  });
}, async (req: Request, res: Response) => {
  try {
    if (!req.file) {
      return res.status(400).json({ message: "فایلی انتخاب نشده است" });
    }

    const { caseId, description, docType, docDate, isFinal } = req.body;

    if (!caseId) {
      return res.status(400).json({ message: "نمبر قضیه الزامی است" });
    }

    if (!docType) {
      return res.status(400).json({ message: "نوع سند الزامی است" });
    }

    // Validate document type
    if (!isValidDocumentType(docType)) {
      return res.status(400).json({ 
        message: `نوع سند نامعتبر است. انواع مجاز: ${ALLOWED_DOCUMENT_TYPES.join('، ')}` 
      });
    }

    if (!docDate) {
      return res.status(400).json({ message: "تاریخ سند الزامی است" });
    }

    const caseExists = await storage.getCasesByCaseId(caseId);
    if (!caseExists) {
      return res.status(404).json({ message: "قضیه یافت نشد" });
    }
    
    const actualCaseId = caseExists.id;

    const fileResult = await saveDocument(
      actualCaseId,
      req.file.buffer,
      req.file.originalname,
      req.file.mimetype
    );

    const documentData = {
      caseId: actualCaseId,
      uploaderId: (req.user as any).id,
      storagePath: fileResult.filepath,
      mimeType: fileResult.mimetype,
      sizeBytes: fileResult.size,
      docType,
      docDate,
      isFinal: isFinal === 'true' || isFinal === true,
      description: description || null,
    };

    const newDocument = await storage.createDocument(documentData);

    await storage.createAuditLog({
      userId: (req.user as any).id,
      action: 'upload_document',
      entityType: 'document',
      entityId: newDocument.id,
      newValue: { storagePath: fileResult.filepath, caseId },
    });

    res.status(201).json(newDocument);
  } catch (error: any) {
    console.error(error);
    res.status(400).json({ message: error.message || "خطا در آپلود فایل" });
  }
});

// Revoke document endpoint (admin only - no file deletion, just marks as revoked)
router.post("/:id/revoke", requireAuth, requirePermission('users:manage'), async (req: Request, res: Response) => {
  try {
    const { revocationReason } = req.body;

    if (!revocationReason) {
      return res.status(400).json({ message: "دلیل لغو الزامی است" });
    }

    const document = await storage.getDocument(req.params.id);
    if (!document) {
      return res.status(404).json({ message: "سند یافت نشد" });
    }

    if (document.isRevoked) {
      return res.status(400).json({ message: "این سند قبلاً لغو شده است" });
    }

    const user = req.user as any;
    const updatedDocument = await storage.updateDocument(req.params.id, {
      isRevoked: true,
      revokedBy: user.id,
      revokedAt: new Date(),
      revocationReason,
    });

    await storage.createAuditLog({
      userId: user.id,
      action: 'revoke_document',
      entityType: 'document',
      entityId: req.params.id,
      oldValue: { isRevoked: false },
      newValue: { isRevoked: true, revokedBy: user.id, revocationReason },
      ipAddress: extractClientIp(req),
    });

    res.json(updatedDocument);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "خطا در لغو سند" });
  }
});

export default router;
