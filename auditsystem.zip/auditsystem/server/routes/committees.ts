import { Router, type Request, type Response } from "express";
import { storage } from "../storage";
import { insertCommitteeSchema } from "@shared/schema";
import { requireAuth } from "../middleware/auth";
import { extractClientIp } from "../utils/ipExtractor";
import { z } from "zod";
import jalaali from "jalaali-js";

const router = Router();

// ============================================================================
// OLD COMMITTEE MODULE - DISABLED
// ============================================================================
// This module has been deactivated to prepare for a clean rebuild.
// All routes return a clear message indicating the module is disabled.
// Database tables and records remain intact for reference/migration.
// ============================================================================

// Disable all committee routes with clear message
const DISABLED_MESSAGE = {
  message: "ماژول کمیته قدیمی غیرفعال شده است — با پیاده‌سازی جدید جایگزین خواهد شد",
  messageEn: "Old committee module disabled — replaced by new implementation",
  disabled: true,
  module: "committees"
};

// Middleware to disable all routes
const disableRoute = (req: Request, res: Response) => {
  res.status(503).json(DISABLED_MESSAGE);
};

// Helper function to check if user has committee access (System Admin, Director, or Coordinator)
function hasCommitteeAccess(user: any): boolean {
  if (!user) return false;
  
  // System admin has access
  if (user.role === 'system_admin') return true;
  
  // Director has access
  if (user.role === 'director') return true;
  
  // Coordinator has access (acting_coordinator permission package)
  if (user.permissionPackages && Array.isArray(user.permissionPackages) && user.permissionPackages.includes('acting_coordinator')) {
    return true;
  }
  
  return false;
}

// Get all committees - DISABLED
router.get("/", requireAuth, disableRoute);

// Get active committees only - DISABLED
router.get("/active", requireAuth, disableRoute);

// Get committee by ID - DISABLED
router.get("/:id", requireAuth, disableRoute);

// Get entities in a committee - DISABLED
router.get("/:id/entities", requireAuth, disableRoute);

// Get cases in a committee - DISABLED
router.get("/:id/cases", requireAuth, disableRoute);

// Get cases available for committee selection - DISABLED
router.get("/:id/available-cases", requireAuth, disableRoute);

// Link existing case to committee - DISABLED
router.post("/:id/cases/:caseId", requireAuth, disableRoute);

// OLD IMPLEMENTATION (DISABLED - KEPT FOR REFERENCE):
/* router.post("/:id/cases/:caseId", requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    
    // Check if user has committee access
    if (!hasCommitteeAccess(user)) {
      return res.status(403).json({ message: "فقط مدیر سیستم، مدیر، و هماهنگ‌کننده می‌توانند قضیه به کمیته اضافه کنند" });
    }
    
    const committee = await storage.getCommittee(req.params.id);
    if (!committee) {
      return res.status(404).json({ message: "کمیته یافت نشد" });
    }
    
    if (committee.status === 'Closed') {
      return res.status(400).json({ message: "نمی‌توان به کمیته بسته شده قضیه اضافه کرد" });
    }
    
    // Check if committee is locked
    if ((committee as any).locked === true) {
      return res.status(400).json({ message: "کمیته قفل شده است. نمی‌توان قضیه جدید اضافه کرد." });
    }
    
    const caseData = await storage.getCase(req.params.caseId);
    if (!caseData) {
      return res.status(404).json({ message: "قضیه یافت نشد" });
    }
    
    // Check if case is already in a different committee
    if (caseData.committeeId && caseData.committeeId !== req.params.id) {
      return res.status(400).json({ message: "این قضیه قبلاً به کمیته دیگری اختصاص داده شده است" });
    }
    
    // Note: Month/year validation removed - cases from any month/year can be assigned to committees
    // The committee month/year is used for reporting/tracking purposes only
    
    // Link case to committee
    const updatedCase = await storage.updateCase(req.params.caseId, {
      committeeId: req.params.id,
    });
    
    if (!updatedCase) {
      return res.status(404).json({ message: "قضیه یافت نشد" });
    }
    
    // Audit Logging
    await storage.createAuditLog({
      userId: user.id,
      action: 'link_case_to_committee',
      entityType: 'case',
      entityId: updatedCase.id,
      details: {
        committeeId: req.params.id,
        committeeName: committee.name,
        caseId: updatedCase.caseId,
      },
      ipAddress: extractClientIp(req),
    });
    
    res.json(updatedCase);
  } catch (error: any) {
    console.error('Error linking case to committee:', error);
    res.status(400).json({ message: error?.message || "خطا در اضافه کردن قضیه به کمیته" });
  }
});

// Create committee (System Admin, Director, or Coordinator) - DISABLED
router.post("/", requireAuth, disableRoute);

// OLD IMPLEMENTATION (DISABLED - KEPT FOR REFERENCE):
/* router.post("/", requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    
    // Check if user has committee access
    if (!hasCommitteeAccess(user)) {
      return res.status(403).json({ message: "فقط مدیر سیستم، مدیر، و هماهنگ‌کننده می‌توانند کمیته ایجاد کنند" });
    }

    // Convert ISO string dates to Date objects
    const startDate = req.body.startDate ? new Date(req.body.startDate) : null;
    const endDate = req.body.endDate ? new Date(req.body.endDate) : null;
    
    // Validate dates
    if (!startDate || isNaN(startDate.getTime())) {
      return res.status(400).json({ message: "تاریخ شروع نامعتبر است" });
    }
    if (!endDate || isNaN(endDate.getTime())) {
      return res.status(400).json({ message: "تاریخ پایان نامعتبر است" });
    }
    if (endDate < startDate) {
      return res.status(400).json({ message: "تاریخ پایان باید بعد از تاریخ شروع باشد" });
    }
    
    // Extract month and year from period or use provided values
    // Afghan months: حمل، ثور، جوزا، سرطان، اسد، سنبله، میزان، عقرب، قوس، جدی، دلو، حوت
    const afghanMonths = ['حمل', 'ثور', 'جوزا', 'سرطان', 'اسد', 'سنبله', 'میزان', 'عقرب', 'قوس', 'جدی', 'دلو', 'حوت'];
    
    let month = req.body.month;
    let year = req.body.year;
    
    // If month/year not provided, try to extract from period or startDate
    if (!month || !year) {
      const shamsiStart = jalaali.toJalaali(startDate);
      if (!month) {
        month = afghanMonths[shamsiStart.jm - 1]; // jm is 1-12
      }
      if (!year) {
        year = shamsiStart.jy;
      }
    }
    
    // Generate period string if not provided
    const period = req.body.period || `${month} ${year}`;
    
    const committeeData = {
      ...req.body,
      name: req.body.name,
      period: period,
      month: month,
      year: year,
      startDate: startDate,
      endDate: endDate,
      notes: req.body.notes || null,
      status: 'Active',
      locked: false,
      createdBy: user.id,
    };

    // Validate the data
    let validatedData;
    try {
      validatedData = insertCommitteeSchema.parse(committeeData);
    } catch (validationError: any) {
      // Handle Zod validation errors with better error messages
      if (validationError.errors && Array.isArray(validationError.errors)) {
        const errorMessages = validationError.errors.map((err: any) => {
          const field = err.path?.join('.') || 'field';
          const message = err.message || 'خطا در اعتبارسنجی';
          return `${field}: ${message}`;
        }).join(', ');
        console.error('[COMMITTEE CREATION VALIDATION ERRORS]', JSON.stringify(validationError.errors, null, 2));
        return res.status(400).json({ 
          message: `خطا در اعتبارسنجی داده‌ها: ${errorMessages}`,
          errors: validationError.errors 
        });
      }
      throw validationError;
    }
    
    const newCommittee = await storage.createCommittee(validatedData);

    // Audit Logging
    await storage.createAuditLog({
      userId: user.id,
      action: 'create_committee',
      entityType: 'committee',
      entityId: newCommittee.id,
      details: {
        committeeName: newCommittee.name,
        period: newCommittee.period,
      },
      ipAddress: extractClientIp(req),
    });

    res.status(201).json(newCommittee);
  } catch (error: any) {
    console.error('[COMMITTEE CREATION ERROR]', error);
    if (error?.issues) {
      console.error('[COMMITTEE CREATION VALIDATION ERRORS]', JSON.stringify(error.issues, null, 2));
    }
    res.status(400).json({ message: error?.message || "خطا در ایجاد کمیته" });
  }
}); */

// Update committee (System Admin, Director, or Coordinator) - DISABLED
router.put("/:id", requireAuth, disableRoute);

// OLD IMPLEMENTATION (DISABLED - KEPT FOR REFERENCE):
/* router.put("/:id", requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    
    // Check if user has committee access
    if (!hasCommitteeAccess(user)) {
      return res.status(403).json({ message: "فقط مدیر سیستم، مدیر، و هماهنگ‌کننده می‌توانند کمیته را ویرایش کنند" });
    }

    const oldCommittee = await storage.getCommittee(req.params.id);
    if (!oldCommittee) {
      return res.status(404).json({ message: "کمیته یافت نشد" });
    }

    const updatedCommittee = await storage.updateCommittee(req.params.id, req.body);
    if (!updatedCommittee) {
      return res.status(404).json({ message: "کمیته یافت نشد" });
    }

    // Audit Logging
    await storage.createAuditLog({
      userId: user.id,
      action: 'update_committee',
      entityType: 'committee',
      entityId: updatedCommittee.id,
      details: {
        oldCommittee: oldCommittee,
        newCommittee: updatedCommittee,
      },
      ipAddress: extractClientIp(req),
    });

    res.json(updatedCommittee);
  } catch (error) {
    console.error('Error updating committee:', error);
    res.status(400).json({ message: "خطا در بروزرسانی کمیته" });
  }
});

// Close committee (System Admin, Director, or Coordinator) - DISABLED
router.post("/:id/close", requireAuth, disableRoute);

// OLD IMPLEMENTATION (DISABLED - KEPT FOR REFERENCE):
/* router.post("/:id/close", requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    
    // Check if user has committee access
    if (!hasCommitteeAccess(user)) {
      return res.status(403).json({ message: "فقط مدیر سیستم، مدیر، و هماهنگ‌کننده می‌توانند کمیته را ببندند" });
    }

    const closedCommittee = await storage.closeCommittee(req.params.id);
    if (!closedCommittee) {
      return res.status(404).json({ message: "کمیته یافت نشد" });
    }
    
    // Lock the committee when closed
    await storage.updateCommittee(req.params.id, { locked: true });

    // Audit Logging
    await storage.createAuditLog({
      userId: user.id,
      action: 'close_committee',
      entityType: 'committee',
      entityId: closedCommittee.id,
      details: {
        committeeName: closedCommittee.name,
        locked: true,
      },
      ipAddress: extractClientIp(req),
    });

    const updatedCommittee = await storage.getCommittee(req.params.id);
    res.json(updatedCommittee);
  } catch (error) {
    console.error('Error closing committee:', error);
    res.status(400).json({ message: "خطا در بستن کمیته" });
  }
}); */

// Lock committee (System Admin, Director, or Coordinator) - DISABLED
// After approval, committee becomes locked - no new cases can be added
router.post("/:id/lock", requireAuth, disableRoute);

// OLD IMPLEMENTATION (DISABLED - KEPT FOR REFERENCE):
/* router.post("/:id/lock", requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    
    // Check if user has committee access
    if (!hasCommitteeAccess(user)) {
      return res.status(403).json({ message: "فقط مدیر سیستم، مدیر، و هماهنگ‌کننده می‌توانند کمیته را قفل کنند" });
    }

    const committee = await storage.getCommittee(req.params.id);
    if (!committee) {
      return res.status(404).json({ message: "کمیته یافت نشد" });
    }

    const lockedCommittee = await storage.updateCommittee(req.params.id, { locked: true });
    if (!lockedCommittee) {
      return res.status(404).json({ message: "کمیته یافت نشد" });
    }

    // Audit Logging
    await storage.createAuditLog({
      userId: user.id,
      action: 'lock_committee',
      entityType: 'committee',
      entityId: lockedCommittee.id,
      details: {
        committeeName: lockedCommittee.name,
      },
      ipAddress: extractClientIp(req),
    });

    res.json(lockedCommittee);
  } catch (error) {
    console.error('Error locking committee:', error);
    res.status(400).json({ message: "خطا در قفل کردن کمیته" });
  }
});

// Add entity to committee (System Admin, Director, or Coordinator) - DISABLED
router.post("/:id/entities", requireAuth, disableRoute);

// OLD IMPLEMENTATION (DISABLED - KEPT FOR REFERENCE):
/* router.post("/:id/entities", requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    
    // Check if user has committee access
    if (!hasCommitteeAccess(user)) {
      return res.status(403).json({ message: "فقط مدیر سیستم، مدیر، و هماهنگ‌کننده می‌توانند نهاد به کمیته اضافه کنند" });
    }

    const { entityId, receivingGroup } = req.body;

    if (!entityId) {
      return res.status(400).json({ message: "شناسه نهاد الزامی است" });
    }

    if (!receivingGroup) {
      return res.status(400).json({ message: "گروه دریافت‌کننده الزامی است" });
    }

    // Check if committee exists and is active
    const committee = await storage.getCommittee(req.params.id);
    if (!committee) {
      return res.status(404).json({ message: "کمیته یافت نشد" });
    }
    if (committee.status === 'Closed') {
      return res.status(400).json({ message: "نمی‌توان به کمیته بسته شده نهاد اضافه کرد" });
    }
    // Check if committee is locked
    if ((committee as any).locked === true) {
      return res.status(400).json({ message: "کمیته قفل شده است. نمی‌توان قضیه جدید اضافه کرد. فقط اختصاص به گروه و تولید گزارش مجاز است." });
    }

    // Get entity
    const entity = await storage.getEntity(entityId);
    if (!entity) {
      return res.status(404).json({ message: "نهاد یافت نشد" });
    }

    // Add entity to committee
    await storage.addEntityToCommittee(req.params.id, entityId);

    // Auto-generate case for this entity
    const maxCaseNumber = await storage.getMaxCaseNumber();
    let numericCaseNumber = maxCaseNumber + 1;
    let caseId = String(numericCaseNumber);

    // Check if caseId already exists and find next available
    let existingCaseById = await storage.getCasesByCaseId(caseId);
    while (existingCaseById) {
      numericCaseNumber += 1;
      caseId = String(numericCaseNumber);
      existingCaseById = await storage.getCasesByCaseId(caseId);
    }

    // Get current date in Shamsi format (DD-MM-YYYY)
    const now = new Date();
    const shamsiDate = jalaali.toJalaali(now);
    const referralDate = `${String(shamsiDate.jd).padStart(2, '0')}-${String(shamsiDate.jm).padStart(2, '0')}-${shamsiDate.jy}`;

    // Determine groupReferrer (sender group) - use first static referral group as default
    const STATIC_REFERRAL_GROUPS = [
      { id: 'group-1', name: 'گروه اول سنجش ابتدایی' },
      { id: 'group-2', name: 'گروه دوم سنجش ابتدایی' },
      { id: 'group-3', name: 'گروه سوم سنجش ابتدایی' },
      { id: 'group-4', name: 'گروه چهارم سنجش ابتدایی' },
      { id: 'group-5', name: 'گروه پنجم سنجش ابتدایی' },
      { id: 'group-6', name: 'گروه ششم سنجش ابتدایی' },
      { id: 'group-7', name: 'گروه هفتم سنجش ابتدایی' },
      { id: 'group-8', name: 'گروه هشتم سنجش ابتدایی' },
      { id: 'group-9', name: 'گروه نهم سنجش ابتدایی' },
      { id: 'group-10', name: 'مدیریت عمومی تشخیص مالیه دهنده' },
    ];
    const defaultGroupReferrer = STATIC_REFERRAL_GROUPS[0].id;

    // Create case with status "Pending Group Assignment"
    // Extract audit year range from committee or use periodsUnderReview
    const auditYearRange = req.body.auditYearRange || committee.period || '';
    
    const caseData = {
      caseId,
      caseNumber: numericCaseNumber,
      entityId: entity.id,
      companyName: entity.companyName,
      tin: entity.tin,
      businessNature: entity.businessNature,
      periodsUnderReview: committee.period, // Use committee period
      auditYearRange: auditYearRange, // سال‌های بررسی
      referralDate,
      groupReferrer: defaultGroupReferrer,
      receivingGroup: receivingGroup,
      status: 'Pending Group Assignment', // Initial status for committee cases
      committeeId: req.params.id,
    };

    const newCase = await storage.createCase(caseData);

    // Audit Logging
    await storage.createAuditLog({
      userId: user.id,
      action: 'add_entity_to_committee',
      entityType: 'committee',
      entityId: req.params.id,
      details: {
        entityId: entity.id,
        entityName: entity.companyName,
        caseId: newCase.id,
        receivingGroup: receivingGroup,
      },
      ipAddress: extractClientIp(req),
    });

    res.status(201).json({
      committeeEntity: await storage.getCommitteeEntities(req.params.id),
      case: newCase,
    });
  } catch (error: any) {
    console.error('[ADD ENTITY TO COMMITTEE ERROR]', error);
    res.status(400).json({ message: error?.message || "خطا در اضافه کردن نهاد به کمیته" });
  }
}); */

// Remove entity from committee (System Admin, Director, or Coordinator, before case generation) - DISABLED
router.delete("/:id/entities/:entityId", requireAuth, disableRoute);

// OLD IMPLEMENTATION (DISABLED - KEPT FOR REFERENCE):
/* router.delete("/:id/entities/:entityId", requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    
    // Check if user has committee access
    if (!hasCommitteeAccess(user)) {
      return res.status(403).json({ message: "فقط مدیر سیستم، مدیر، و هماهنگ‌کننده می‌توانند نهاد را از کمیته حذف کنند" });
    }

    // Check if case exists for this entity in this committee
    const committeeCases = await storage.getCasesByCommittee(req.params.id);
    const existingCase = committeeCases.find(c => c.entityId === req.params.entityId);
    
    if (existingCase) {
      return res.status(400).json({ message: "نمی‌توان نهادی را که قضیه برای آن ایجاد شده است حذف کرد" });
    }

    const removed = await storage.removeEntityFromCommittee(req.params.id, req.params.entityId);
    if (!removed) {
      return res.status(404).json({ message: "نهاد در کمیته یافت نشد" });
    }

    // Audit Logging
    await storage.createAuditLog({
      userId: user.id,
      action: 'remove_entity_from_committee',
      entityType: 'committee',
      entityId: req.params.id,
      details: {
        entityId: req.params.entityId,
      },
      ipAddress: extractClientIp(req),
    });

    res.json({ message: "نهاد از کمیته حذف شد" });
  } catch (error) {
    console.error('Error removing entity from committee:', error);
    res.status(400).json({ message: "خطا در حذف نهاد از کمیته" });
  }
}); */

export default router;