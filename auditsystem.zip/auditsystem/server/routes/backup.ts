import { Router, type Request, type Response } from "express";
import { requireAuth } from "../middleware/auth";
import { requirePermission } from "../middleware/permissions";
import { extractClientIp } from "../utils/ipExtractor";
import { storage } from "../storage";
import {
  createBackup,
  restoreBackup,
  listBackups,
  ensureBackupDirectory,
} from "../utils/backup";
import type { User } from "@shared/schema";

const router = Router();

// All backup routes require authentication and settings:manage permission (admin only)
router.use(requireAuth);
router.use(requirePermission('settings:manage'));

/**
 * POST /api/backup/create
 * Create a new database backup (encrypted)
 * Requires: settings:manage permission (admin only)
 */
router.post("/create", async (req: Request, res: Response) => {
  try {
    const user = req.user as User;
    const { includeDocuments } = req.body;

    // Log backup creation
    await storage.createAuditLog({
      userId: user.id,
      action: "backup_created",
      entityType: "backup",
      entityId: "new",
      details: {
        requestedBy: user.id,
        requestedByRole: user.role,
        includeDocuments: includeDocuments || false,
        requestedAt: new Date().toISOString(),
      },
      ipAddress: extractClientIp(req),
    });

    // Create backup
    const backup = await createBackup(includeDocuments || false);

    // Log successful backup
    await storage.createAuditLog({
      userId: user.id,
      action: "backup_created_success",
      entityType: "backup",
      entityId: backup.backupPath,
      details: {
        backupPath: backup.backupPath,
        size: backup.size,
        encrypted: backup.encrypted,
        createdAt: new Date().toISOString(),
      },
      ipAddress: extractClientIp(req),
    });

    res.json({
      message: "پشتیبان‌گیری با موفقیت ایجاد شد",
      backup: {
        path: backup.backupPath,
        size: backup.size,
        encrypted: backup.encrypted,
        createdAt: new Date().toISOString(),
      },
    });
  } catch (error: any) {
    console.error("Backup creation error:", error);
    
    // Log backup failure
    const user = req.user as User;
    if (user) {
      await storage.createAuditLog({
        userId: user.id,
        action: "backup_created_failed",
        entityType: "backup",
        entityId: "failed",
        details: {
          error: error.message || "Unknown error",
          failedAt: new Date().toISOString(),
        },
        ipAddress: extractClientIp(req),
      });
    }
    
    res.status(500).json({
      message: "خطا در ایجاد پشتیبان‌گیری",
      error: error.message || "Unknown error",
    });
  }
});

/**
 * GET /api/backup/list
 * List all available backups
 * Requires: settings:manage permission (admin only)
 */
router.get("/list", async (req: Request, res: Response) => {
  try {
    const backups = await listBackups();
    
    // Sort by creation date (newest first)
    backups.sort((a, b) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
    
    res.json({
      backups,
      count: backups.length,
    });
  } catch (error: any) {
    console.error("Error listing backups:", error);
    res.status(500).json({
      message: "خطا در دریافت فهرست پشتیبان‌ها",
      error: error.message || "Unknown error",
    });
  }
});

/**
 * POST /api/backup/restore
 * Restore database from a backup
 * WARNING: This will overwrite existing data
 * Requires: settings:manage permission (admin only)
 */
router.post("/restore", async (req: Request, res: Response) => {
  try {
    const user = req.user as User;
    const { backupPath, encryptionKey, confirm } = req.body;

    if (!backupPath) {
      return res.status(400).json({
        message: "مسیر فایل پشتیبان الزامی است",
      });
    }

    if (confirm !== "RESTORE") {
      return res.status(400).json({
        message: "برای تأیید بازیابی، باید confirm='RESTORE' ارسال کنید",
        warning: "این عملیات تمام داده‌های موجود را حذف می‌کند!",
      });
    }

    // Log restore attempt
    await storage.createAuditLog({
      userId: user.id,
      action: "backup_restore_attempt",
      entityType: "backup",
      entityId: backupPath,
      details: {
        backupPath,
        requestedBy: user.id,
        requestedByRole: user.role,
        requestedAt: new Date().toISOString(),
        warning: "This will overwrite all existing data!",
      },
      ipAddress: extractClientIp(req),
    });

    // Restore backup
    const result = await restoreBackup(backupPath, encryptionKey);

    if (result.restored) {
      // Log successful restore
      await storage.createAuditLog({
        userId: user.id,
        action: "backup_restore_success",
        entityType: "backup",
        entityId: backupPath,
        details: {
          backupPath,
          tablesRestored: result.tablesRestored,
          restoredAt: new Date().toISOString(),
          errors: result.errors,
        },
        ipAddress: extractClientIp(req),
      });

      res.json({
        message: "بازیابی با موفقیت انجام شد",
        restored: true,
        tablesRestored: result.tablesRestored,
        errors: result.errors,
      });
    } else {
      // Log failed restore
      await storage.createAuditLog({
        userId: user.id,
        action: "backup_restore_failed",
        entityType: "backup",
        entityId: backupPath,
        details: {
          backupPath,
          errors: result.errors,
          failedAt: new Date().toISOString(),
        },
        ipAddress: extractClientIp(req),
      });

      res.status(500).json({
        message: "خطا در بازیابی پشتیبان",
        restored: false,
        errors: result.errors,
      });
    }
  } catch (error: any) {
    console.error("Restore error:", error);
    
    // Log restore failure
    const user = req.user as User;
    if (user) {
      await storage.createAuditLog({
        userId: user.id,
        action: "backup_restore_failed",
        entityType: "backup",
        entityId: req.body?.backupPath || "unknown",
        details: {
          error: error.message || "Unknown error",
          failedAt: new Date().toISOString(),
        },
        ipAddress: extractClientIp(req),
      });
    }
    
    res.status(500).json({
      message: "خطا در بازیابی پشتیبان",
      error: error.message || "Unknown error",
    });
  }
});

/**
 * GET /api/backup/download/:filename
 * Download a backup file (encrypted)
 * Requires: settings:manage permission (admin only)
 */
router.get("/download/:filename", async (req: Request, res: Response) => {
  try {
    const { filename } = req.params;
    const backupDir = await ensureBackupDirectory();
    const { join } = await import('path');
    const { existsSync, createReadStream } = await import('fs');
    
    const backupPath = join(backupDir, filename);
    
    // Security: Prevent directory traversal
    if (!filename.endsWith('.sql') || filename.includes('..') || filename.includes('/')) {
      return res.status(400).json({
        message: "نام فایل نامعتبر است",
      });
    }
    
    if (!existsSync(backupPath)) {
      return res.status(404).json({
        message: "فایل پشتیبان یافت نشد",
      });
    }
    
    // Log download
    const user = req.user as User;
    await storage.createAuditLog({
      userId: user.id,
      action: "backup_downloaded",
      entityType: "backup",
      entityId: filename,
      details: {
        filename,
        downloadedAt: new Date().toISOString(),
      },
      ipAddress: extractClientIp(req),
    });
    
    res.setHeader('Content-Type', 'application/octet-stream');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    
    const fileStream = createReadStream(backupPath);
    fileStream.pipe(res);
  } catch (error: any) {
    console.error("Error downloading backup:", error);
    res.status(500).json({
      message: "خطا در دانلود فایل پشتیبان",
      error: error.message || "Unknown error",
    });
  }
});

export default router;

