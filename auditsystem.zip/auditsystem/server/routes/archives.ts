import { Router, type Request, type Response } from "express";
import multer from "multer";
import { requireAuth } from "../middleware/auth";
import { requirePermission, requireAnyPermission } from "../middleware/permissions";
import { extractClientIp } from "../utils/ipExtractor";
import { storage } from "../storage";
import { saveToIncoming, readArchiveFile, isValidArchiveFileType, MAX_ARCHIVE_FILE_SIZE } from "../utils/archiveStorage";
import { ingestArchiveFile } from "../services/archiveIngestionService";

const router = Router();

const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: MAX_ARCHIVE_FILE_SIZE,
  },
  fileFilter: (_req, file, cb) => {
    if (isValidArchiveFileType(file.mimetype, file.originalname)) {
      cb(null, true);
    } else {
      cb(new Error(`نوع فایل مجاز نیست. فقط فایل‌های Excel مجاز هستند.`));
    }
  },
});

// GET /api/archives - List/search archived files with pagination
router.get("/", requireAuth, requirePermission('archives:view'), async (req: Request, res: Response) => {
  try {
    const page = parseInt(req.query.page as string) || 1;
    const size = Math.min(parseInt(req.query.size as string) || 25, 100); // Max 100 per page
    const year = req.query.year ? parseInt(req.query.year as string) : undefined;
    const category = req.query.category as string | undefined;
    const q = req.query.q as string | undefined;
    const sort = req.query.sort as string | undefined;
    const uploadedBy = req.query.uploadedBy as string | undefined;
    const dateFrom = req.query.dateFrom ? new Date(req.query.dateFrom as string) : undefined;
    const dateTo = req.query.dateTo ? new Date(req.query.dateTo as string) : undefined;

    const result = await storage.getArchivedFiles({
      page,
      size,
      year,
      category,
      q,
      sort,
      uploadedBy,
      dateFrom,
      dateTo,
    });

    // Enrich with user names
    const enrichedFiles = await Promise.all(
      result.files.map(async (file) => {
        let uploadedByName = null;
        if (file.uploadedBy) {
          const user = await storage.getUser(file.uploadedBy);
          uploadedByName = user?.fullName || null;
        }
        return {
          ...file,
          uploadedByName,
        };
      })
    );

    res.json({
      files: enrichedFiles,
      pagination: {
        total: result.total,
        page: result.page,
        size: result.size,
        totalPages: Math.ceil(result.total / result.size),
      },
    });
  } catch (error) {
    console.error("Error fetching archived files:", error);
    res.status(500).json({ message: "خطا در دریافت فایل‌های بایگانی" });
  }
});

// GET /api/archives/:id - Get file metadata and versions
router.get("/:id", requireAuth, requirePermission('archives:view'), async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const file = await storage.getArchivedFile(id);

    if (!file) {
      return res.status(404).json({ message: "فایل بایگانی یافت نشد" });
    }

    // Get versions
    const versions = await storage.getArchivedFileVersions(id);

    // Enrich with user names
    let uploadedByName = null;
    if (file.uploadedBy) {
      const user = await storage.getUser(file.uploadedBy);
      uploadedByName = user?.fullName || null;
    }

    const enrichedVersions = await Promise.all(
      versions.map(async (version) => {
        let uploadedByName = null;
        if (version.uploadedBy) {
          const user = await storage.getUser(version.uploadedBy);
          uploadedByName = user?.fullName || null;
        }
        return {
          ...version,
          uploadedByName,
        };
      })
    );

    // Log metadata view
    const user = req.user as any;
    await storage.logArchivedFileAccess({
      archivedFileId: id,
      userId: user.id,
      action: 'VIEW_METADATA',
      ipAddress: extractClientIp(req),
    });

    res.json({
      ...file,
      uploadedByName,
      versions: enrichedVersions,
    });
  } catch (error) {
    console.error("Error fetching archived file:", error);
    res.status(500).json({ message: "خطا در دریافت فایل بایگانی" });
  }
});

// GET /api/archives/:id/download - Download file
router.get("/:id/download", requireAuth, requirePermission('archives:view'), async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const version = req.query.version ? parseInt(req.query.version as string) : undefined;

    const file = await storage.getArchivedFile(id);
    if (!file) {
      return res.status(404).json({ message: "فایل بایگانی یافت نشد" });
    }

    let filePath: string;
    let fileName: string;

    if (version) {
      // Download specific version
      const versions = await storage.getArchivedFileVersions(id);
      const versionRecord = versions.find((v) => v.versionNumber === version);
      if (!versionRecord) {
        return res.status(404).json({ message: "نسخه مشخص شده یافت نشد" });
      }
      filePath = versionRecord.path;
      fileName = versionRecord.fileName;
    } else {
      // Download current version
      filePath = file.path;
      fileName = file.fileName;
    }

    // Read file
    const fileBuffer = await readArchiveFile(filePath);

    // Log download
    const user = req.user as any;
    await storage.logArchivedFileAccess({
      archivedFileId: id,
      userId: user.id,
      action: 'DOWNLOAD',
      ipAddress: extractClientIp(req),
    });

    // Set headers
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename="${encodeURIComponent(fileName)}"`);
    res.setHeader('Content-Length', fileBuffer.length.toString());

    res.send(fileBuffer);
  } catch (error) {
    console.error("Error downloading archived file:", error);
    res.status(500).json({ message: "خطا در دانلود فایل بایگانی" });
  }
});

// POST /api/archives - Upload file
router.post(
  "/",
  requireAuth,
  requirePermission('archives:upload'),
  upload.single("file"),
  async (req: Request, res: Response) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "فایلی انتخاب نشده است" });
      }

      const { year, category, description, notes } = req.body;
      const user = req.user as any;

      // Validate required fields
      if (!year) {
        return res.status(400).json({ message: "سال الزامی است" });
      }
      if (!category) {
        return res.status(400).json({ message: "دسته‌بندی الزامی است" });
      }

      const yearNum = parseInt(year);
      if (isNaN(yearNum) || yearNum < 1300 || yearNum > 1500) {
        return res.status(400).json({ message: "سال نامعتبر است" });
      }

      // Save to incoming staging area
      const staging = await saveToIncoming(
        req.file.buffer,
        req.file.originalname,
        req.file.mimetype
      );

      try {
        // Ingest file: move to final location, create DB records, set permissions
        const result = await ingestArchiveFile({
          stagingPath: staging.filepath,
          stagingFilename: staging.filename,
          originalFileName: req.file.originalname,
          year: yearNum,
          category,
          description: description || null,
          uploadedBy: user.id,
          notes: notes || null,
        });

        // Log upload access with IP (ingestion service already logs, but without IP)
        await storage.logArchivedFileAccess({
          archivedFileId: result.archivedFile.id,
          userId: user.id,
          action: 'UPLOAD',
          ipAddress: extractClientIp(req),
        });

        res.status(201).json({
          message: "فایل با موفقیت آپلود و بایگانی شد",
          file: {
            id: result.archivedFile.id,
            fileName: result.archivedFile.fileName,
            version: result.archivedFile.version,
          },
          checksum: result.checksum,
        });
      } catch (ingestionError) {
        // Staging file cleanup is handled in ingestArchiveFile
        throw ingestionError;
      }
    } catch (error: any) {
      console.error("Error uploading archived file:", error);
      if (error.code === 'LIMIT_FILE_SIZE') {
        return res.status(400).json({ message: 'حجم فایل بیش از حد مجاز است' });
      }
      res.status(500).json({ 
        message: error.message || "خطا در آپلود فایل بایگانی" 
      });
    }
  }
);

// DELETE /api/archives/:id - Soft delete (System Admin only)
router.delete("/:id", requireAuth, requirePermission('archives:delete'), async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const file = await storage.getArchivedFile(id);

    if (!file) {
      return res.status(404).json({ message: "فایل بایگانی یافت نشد" });
    }

    await storage.softDeleteArchivedFile(id);

    // Log deletion
    const user = req.user as any;
    await storage.logArchivedFileAccess({
      archivedFileId: id,
      userId: user.id,
      action: 'DELETE',
      ipAddress: extractClientIp(req),
    });

    res.json({ message: "فایل بایگانی با موفقیت حذف شد" });
  } catch (error) {
    console.error("Error deleting archived file:", error);
    res.status(500).json({ message: "خطا در حذف فایل بایگانی" });
  }
});

export default router;

