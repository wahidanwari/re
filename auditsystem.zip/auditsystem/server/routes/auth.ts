import { Router } from 'express';
import passport from '../auth/passport';
import type { Request, Response, NextFunction } from 'express';
import type { User } from '@shared/schema';
import { extractClientIp } from '../utils/ipExtractor';
import { authRateLimit } from '../middleware/rateLimit';
import { sanitizeBody, checkSQLInjection } from '../middleware/validation';
import { requireAuth } from '../middleware/auth';

const router = Router();

// Apply rate limiting and sanitization to all auth routes
router.use(sanitizeBody);
router.use(checkSQLInjection);

router.post('/login', authRateLimit(), (req: Request, res: Response, next: NextFunction) => {
  passport.authenticate('local', async (err: any, user: User | false, info: any) => {
    if (err) {
      return next(err);
    }
    
    // Import rate limit store to track/clear login attempts
    const rateLimitModule = await import('../middleware/rateLimit');
    const loginAttemptStore = rateLimitModule.loginAttemptStore;
    const loginAttemptKey = (req as any).loginAttemptKey;
    
    if (!user) {
      // Track failed login attempt
      if (loginAttemptKey && loginAttemptStore[loginAttemptKey]) {
        const now = Date.now();
        loginAttemptStore[loginAttemptKey].attempts.push(now);
        loginAttemptStore[loginAttemptKey].lastAttempt = now;
      }
      
      // Log failed login attempt with IP address
      try {
        const { storage } = await import('../storage');
        // Try to find user by auditId if possible from request body
        const { auditId } = req.body;
        if (auditId) {
          const attemptedUser = await storage.getUserByAuditId(auditId);
          if (attemptedUser) {
            await storage.createAuditLog({
              userId: attemptedUser.id,
              action: 'login_failed',
              entityType: 'user',
              entityId: attemptedUser.id,
              details: {
                reason: info?.message || 'Invalid credentials',
                attemptedAt: new Date().toISOString(),
                failedAttempts: loginAttemptKey && loginAttemptStore[loginAttemptKey] 
                  ? loginAttemptStore[loginAttemptKey].attempts.length 
                  : 1,
              },
              ipAddress: extractClientIp(req),
            });
          }
        }
      } catch (logError) {
        console.error('Failed to log failed login attempt:', logError);
      }
      
      return res.status(401).json({
        message: info?.message || 'آی دی بررسی یا رمز عبور نادرست است'
      });
    }
    
    // Successful login - clear failed attempts
    if (loginAttemptKey && loginAttemptStore[loginAttemptKey]) {
      delete loginAttemptStore[loginAttemptKey];
    }

    // Additional check for deactivated users (double-check)
    if (!user.isActive) {
      // Log login attempt by deactivated user with IP
      try {
        const { storage } = await import('../storage');
        await storage.createAuditLog({
          userId: user.id,
          action: 'login_attempt_deactivated',
          entityType: 'user',
          entityId: user.id,
          details: {
            auditId: user.auditId,
            reason: 'Account is deactivated',
            attemptedAt: new Date().toISOString(),
          },
          ipAddress: extractClientIp(req),
        });
      } catch (logError) {
        console.error('Failed to log deactivated user login attempt:', logError);
      }
      
      return res.status(403).json({
        message: 'حساب کاربری شما غیرفعال است. لطفاً با مدیر سیستم تماس بگیرید.'
      });
    }

    req.logIn(user, async (err) => {
      if (err) {
        return next(err);
      }
      
      // Update last login time and log successful login
      try {
        const { storage } = await import('../storage');
        await storage.updateUser(user.id, {
          lastLoginAt: new Date(),
        });
        
        // Log successful login with IP address
        await storage.createAuditLog({
          userId: user.id,
          action: 'login_success',
          entityType: 'user',
          entityId: user.id,
          details: {
            auditId: user.auditId,
            loginTime: new Date().toISOString(),
          },
          ipAddress: extractClientIp(req),
        });
      } catch (error) {
        console.error('Failed to update last login:', error);
      }
      
      const { password, ...userWithoutPassword } = user;
      
      // CRITICAL: Ensure permissionPackages is always an array (never null/undefined)
      const userResponse = {
        ...userWithoutPassword,
        permissionPackages: Array.isArray(user.permissionPackages) 
          ? user.permissionPackages 
          : (user.permissionPackages ? [user.permissionPackages] : []),
      };
      
      // Get effective permissions for the user
      const { getEffectivePermissions, computeModulesFromPermissions } = await import('../services/permissionService');
      const effectivePermissions = await getEffectivePermissions(user.id);
      
      // Calculate modules list from permissions
      const modules = computeModulesFromPermissions(effectivePermissions);
      
      // Convert to array of permission names for easier frontend use
      const effectivePermissionsList = Object.entries(effectivePermissions)
        .filter(([_, has]) => has)
        .map(([perm]) => perm);
      
      // Get permissionsVersion from user data
      const permissionsVersion = user.permissionsVersion || 1;
      
      return res.json({
        message: 'ورود موفقیت آمیز',
        user: {
          ...userResponse,
          effectivePermissions: effectivePermissionsList, // Array of permission names
        },
        effectivePermissions, // Also include as object for detailed checks
        modules, // Modules list for frontend navigation
        permissionsVersion, // Permissions version for cache invalidation
        mustChangePassword: user.mustChangePassword || false,
        passwordExpired: user.passwordExpiresAt ? new Date() > user.passwordExpiresAt : false,
      });
    });
  })(req, res, next);
});

router.post('/logout', async (req: Request, res: Response) => {
  const user = req.user as User | undefined;
  
  req.logout(async (err) => {
    if (err) {
      return res.status(500).json({ message: 'خطا در خروج از سیستم' });
    }
    
    // Audit log logout
    if (user) {
      try {
        const { storage } = await import('../storage');
        await storage.createAuditLog({
          userId: user.id,
          action: 'logout',
          entityType: 'user',
          entityId: user.id,
          ipAddress: extractClientIp(req),
        });
      } catch (error) {
        console.error('Failed to log logout action:', error);
      }
    }
    
    res.json({ message: 'خروج موفقیت آمیز' });
  });
});

router.get('/me', async (req: Request, res: Response) => {
  if (!req.isAuthenticated() || !req.user) {
    return res.status(401).json({ message: 'احراز هویت نشده' });
  }
  
  // CRITICAL: Refresh user from database to ensure we have latest permissions/role/groupId
  const sessionUser = req.user as User;
  const { storage } = await import('../storage');
  const freshUser = await storage.getUser(sessionUser.id);
  
  if (!freshUser) {
    return res.status(401).json({ message: 'کاربر یافت نشد' });
  }
  
  // Update session with fresh user data
  req.user = freshUser;
  
  const { password, ...userWithoutPassword } = freshUser;
  
  // CRITICAL: Ensure permissionPackages is always an array (never null/undefined)
  const userResponse = {
    ...userWithoutPassword,
    permissionPackages: Array.isArray(freshUser.permissionPackages) 
      ? freshUser.permissionPackages 
      : (freshUser.permissionPackages ? [freshUser.permissionPackages] : []),
  };
  
  // Get effective permissions
  const { getEffectivePermissions, computeModulesFromPermissions } = await import('../services/permissionService');
  const effectivePermissions = await getEffectivePermissions(freshUser.id);
  
  // Calculate modules list from permissions
  const modules = computeModulesFromPermissions(effectivePermissions);
  
  // Get permissions_version from database (incremented when permissions change)
  const permissionsVersion = freshUser.permissionsVersion || 1;
  
  // Convert effectivePermissions to array of permission names for easier frontend use
  const effectivePermissionsList = Object.entries(effectivePermissions)
    .filter(([_, has]) => has)
    .map(([perm]) => perm);
  
  // Set cache control headers to prevent stale data
  res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, private');
  res.setHeader('Pragma', 'no-cache');
  res.setHeader('Expires', '0');
  
  res.json({ 
    user: {
      ...userResponse,
      effectivePermissions: effectivePermissionsList, // Include as array in user object
    },
    effectivePermissions, // Also include as object for detailed checks
    effectivePermissionsList, // Array version for convenience
    modules, // Modules list for frontend navigation
    permissionsVersion,
  });
});

// Get effective permissions for current user
router.get('/effective-permissions', async (req: Request, res: Response) => {
  if (!req.isAuthenticated() || !req.user) {
    return res.status(401).json({ message: 'احراز هویت نشده' });
  }
  
  try {
    const { getEffectivePermissions, computeModulesFromPermissions } = await import('../services/permissionService');
    const user = req.user as User;
    const permissions = await getEffectivePermissions(user.id);
    
    // Optionally include modules list
    const includeModules = req.query.modules === 'true';
    const response: any = permissions;
    
    if (includeModules) {
      response.modules = computeModulesFromPermissions(permissions);
    }
    
    res.json(response);
  } catch (error) {
    console.error('Error getting effective permissions:', error);
    res.status(500).json({ message: 'خطا در دریافت مجوزها' });
  }
});

// Refresh current user's session with latest data
router.post('/refresh-session', requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user as User;
    
    // Get fresh user data from database
    const { storage } = await import('../storage');
    const freshUser = await storage.getUser(user.id);
    
    if (!freshUser) {
      return res.status(404).json({ message: 'کاربر یافت نشد' });
    }
    
    // Get effective permissions
    const { getEffectivePermissions, computeModulesFromPermissions } = await import('../services/permissionService');
    const effectivePermissions = await getEffectivePermissions(freshUser.id);
    
    // Calculate modules list
    const modules = computeModulesFromPermissions(effectivePermissions);
    
    // Regenerate session with fresh user data
    req.logIn(freshUser, async (err) => {
      if (err) {
        return res.status(500).json({ message: 'خطا در بروزرسانی نشست' });
      }
      
      // Convert permissions to array
      const effectivePermissionsList = Object.entries(effectivePermissions)
        .filter(([_, has]) => has)
        .map(([perm]) => perm);
      
      const { password, ...userWithoutPassword } = freshUser;
      
      // CRITICAL: Ensure permissionPackages is always an array
      const userResponse = {
        ...userWithoutPassword,
        permissionPackages: Array.isArray(freshUser.permissionPackages) 
          ? freshUser.permissionPackages 
          : (freshUser.permissionPackages ? [freshUser.permissionPackages] : []),
      };
      
      res.json({
        message: 'Session refreshed successfully',
        user: {
          ...userResponse,
          effectivePermissions: effectivePermissionsList,
        },
        effectivePermissions,
        modules,
        permissionsVersion: freshUser.permissionsVersion || 1,
      });
    });
  } catch (error) {
    console.error('Error refreshing session:', error);
    res.status(500).json({ message: 'خطا در بروزرسانی نشست' });
  }
});

router.post('/change-password', async (req: Request, res: Response) => {
  if (!req.isAuthenticated() || !req.user) {
    return res.status(401).json({ message: 'احراز هویت نشده' });
  }

  const { currentPassword, newPassword } = req.body;
  
  if (!currentPassword || !newPassword) {
    return res.status(400).json({
      message: 'رمز عبور فعلی و جدید الزامی است'
    });
  }

  // Validate password against policy
  const { validatePassword } = await import('../middleware/passwordPolicy');
  const passwordValidation = validatePassword(newPassword);
  
  if (!passwordValidation.valid) {
    return res.status(400).json({
      message: 'رمز عبور جدید معیارهای امنیتی را رعایت نمی‌کند',
      errors: passwordValidation.errors,
    });
  }

  try {
    const { storage } = await import('../storage');
    const { comparePassword } = await import('../auth/password');
    
    const user = req.user as User;
    const currentUser = await storage.getUser(user.id);
    
    if (!currentUser) {
      return res.status(404).json({ message: 'کاربر یافت نشد' });
    }

    // Verify current password
    const isValidPassword = await comparePassword(currentPassword, currentUser.password);
    if (!isValidPassword) {
      return res.status(400).json({ message: 'رمز عبور فعلی نادرست است' });
    }
    
    // Update password (storage.updateUser will hash it)
    await storage.updateUser(user.id, {
      password: newPassword,
      mustChangePassword: false,
      passwordExpiresAt: null,
      passwordChangedAt: new Date(),
    });

    await storage.createAuditLog({
      userId: user.id,
      action: 'change_password',
      entityType: 'user',
      entityId: user.id,
      ipAddress: req.ip,
    });

    res.json({ message: 'رمز عبور با موفقیت تغییر یافت' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'خطا در تغییر رمز عبور' });
  }
});

router.post('/forgot-password', async (req: Request, res: Response) => {
  const { auditId, groupId, phoneNumber } = req.body;
  
  if (!auditId || !groupId || !phoneNumber) {
    return res.status(400).json({
      message: 'آی دی بررسی، گروه و شماره تماس الزامی است'
    });
  }
  
  try {
    const { storage } = await import('../storage');
    const { generateTicketId } = await import('../utils/idGenerator');
    
    const user = await storage.getUserByAuditId(auditId);
    if (!user || user.groupId !== groupId || user.phoneNumber !== phoneNumber) {
      return res.status(400).json({
        message: 'اطلاعات وارد شده صحیح نیست'
      });
    }
    
    const ticketId = await generateTicketId();
    
    const ticket = await storage.createTicket({
      ticketId,
      type: 'بازیابی رمز',
      requestedBy: user.id,
      status: 'منتظر تایید',
      description: 'درخواست بازیابی رمز عبور',
      auditId,
      groupId,
      phoneNumber,
    });
    
    res.json({
      message: 'تکت بازیابی رمز عبور ایجاد شد',
      ticketId: ticket.ticketId
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'خطا در ایجاد تکت' });
  }
});

export default router;
