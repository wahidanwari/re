import { Router, type Request, type Response } from 'express';
import { requireAuth } from '../middleware/auth';
import { extractClientIp } from '../utils/ipExtractor';

const router = Router();

/**
 * POST /api/session/heartbeat
 * Updates lastActivity timestamp for the current session
 * This endpoint can be called periodically to keep the session alive
 * Rate-limited to prevent abuse
 */
router.post('/heartbeat', requireAuth, async (req: Request, res: Response) => {
  if (!req.session) {
    return res.status(401).json({ message: 'نشست یافت نشد' });
  }

  const now = Date.now();
  const previousActivity = req.session.lastActivity || now;
  
  // Update lastActivity
  req.session.lastActivity = now;
  
  // Extend session cookie expiration (sliding expiration)
  if (req.session.cookie) {
    const SESSION_MAX_AGE = parseInt(process.env.SESSION_MAX_AGE || '36000000', 10);
    req.session.cookie.maxAge = SESSION_MAX_AGE;
  }
  
  // Save session to persist changes
  req.session.save((err) => {
    if (err) {
      console.error('Failed to save session on heartbeat:', err);
      return res.status(500).json({ message: 'خطا در بروز رسانی نشست' });
    }
    
    // Calculate time until expiration (based on inactivity timeout)
    const SESSION_INACTIVITY_TIMEOUT = parseInt(process.env.SESSION_INACTIVITY_TIMEOUT || '5400000', 10);
    const timeUntilExpiration = SESSION_INACTIVITY_TIMEOUT - (now - previousActivity);
    
    res.json({
      message: 'نشست بروز رسانی شد',
      lastActivity: new Date(now).toISOString(),
      expiresIn: Math.max(0, timeUntilExpiration),
    });
  });
});

export default router;

