import { Router, type Request, type Response } from "express";
import { storage } from "../storage";
import { requireAuth } from "../middleware/auth";

const router = Router();

router.get("/stats", requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    
    const stats = await storage.getDashboardStats(user.id, user.groupId);
    
    res.json({
      ...stats,
      userInfo: {
        id: user.id,
        name: user.name,
        role: user.role,
        groupId: user.groupId,
      },
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "خطا در دریافت آمار داشبورد" });
  }
});

export default router;
