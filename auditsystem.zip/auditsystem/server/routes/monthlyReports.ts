import { Router, type Request, type Response } from "express";
import { storage } from "../storage";
import { requireAuth } from "../middleware/auth";
import { requirePermission } from "../middleware/permissions";
import { extractClientIp } from "../utils/ipExtractor";
import { 
  upsertMonthlyReport, 
  getMonthlyReportBreakdown,
  afghanMonthToNumber,
  getShamsiMonthDateRange
} from "../services/monthlyGroupReportService";
import { z } from "zod";
import type { MonthlyReportBreakdown } from "../services/monthlyGroupReportService";

const router = Router();

// Afghan months: حمل، ثور، جوزا، سرطان، اسد، سنبله، میزان، عقرب، قوس، جدی، دلو، حوت
const AFGHAN_MONTHS = ['حمل', 'ثور', 'جوزا', 'سرطان', 'اسد', 'سنبله', 'میزان', 'عقرب', 'قوس', 'جدی', 'دلو', 'حوت'];

/**
 * GET /api/reports/monthly
 * Get monthly report for a group
 * Query params: groupId, year, month (month can be number 1-12 or Afghan month name)
 */
router.get("/", requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    if (!user || !user.id) {
      return res.status(401).json({ message: 'احراز هویت نشده' });
    }

    const { groupId, year, month } = req.query;

    if (!groupId || !year || !month) {
      return res.status(400).json({ 
        message: 'groupId, year, and month are required' 
      });
    }

    // Parse month (can be number or Afghan month name)
    let monthNumber: number;
    if (typeof month === 'string' && /^\d+$/.test(month)) {
      monthNumber = parseInt(month, 10);
    } else if (typeof month === 'string') {
      monthNumber = afghanMonthToNumber(month);
    } else {
      return res.status(400).json({ message: 'Invalid month format' });
    }

    const yearNumber = parseInt(year as string, 10);
    if (isNaN(yearNumber) || yearNumber < 1300 || yearNumber > 1500) {
      return res.status(400).json({ message: 'Invalid year' });
    }

    // Check permissions - senior auditor can only see their group's reports
    if (user.role === 'senior_auditor' && user.groupId !== groupId) {
      return res.status(403).json({ 
        message: 'شما فقط می‌توانید گزارش گروه خود را مشاهده کنید' 
      });
    }

    // Get report breakdown
    const breakdown = await getMonthlyReportBreakdown(
      groupId as string,
      monthNumber,
      yearNumber
    );

    if (!breakdown) {
      return res.status(404).json({ 
        message: 'گزارش ماهانه برای این گروه یافت نشد. لطفاً ابتدا گزارش را محاسبه کنید.' 
      });
    }

    res.json(breakdown);
  } catch (error: any) {
    console.error('Error fetching monthly report:', error);
    res.status(500).json({ 
      message: error.message || "خطا در دریافت گزارش ماهانه" 
    });
  }
});

/**
 * POST /api/reports/monthly/compute
 * Compute monthly report for a group
 * Body: { groupId, year, month }
 */
router.post("/compute", requireAuth, requirePermission('reports:generate'), async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    if (!user || !user.id) {
      return res.status(401).json({ message: 'احراز هویت نشده' });
    }

    const { groupId, year, month } = req.body;

    if (!groupId || !year || !month) {
      return res.status(400).json({ 
        message: 'groupId, year, and month are required' 
      });
    }

    // Parse month
    let monthNumber: number;
    if (typeof month === 'number') {
      monthNumber = month;
    } else if (typeof month === 'string' && /^\d+$/.test(month)) {
      monthNumber = parseInt(month, 10);
    } else if (typeof month === 'string') {
      monthNumber = afghanMonthToNumber(month);
    } else {
      return res.status(400).json({ message: 'Invalid month format' });
    }

    const yearNumber = parseInt(year.toString(), 10);
    if (isNaN(yearNumber) || yearNumber < 1300 || yearNumber > 1500) {
      return res.status(400).json({ message: 'Invalid year' });
    }

    // Compute report
    const report = await upsertMonthlyReport(
      groupId,
      monthNumber,
      yearNumber,
      user.id
    );

    // Get breakdown for response
    const breakdown = await getMonthlyReportBreakdown(
      groupId,
      monthNumber,
      yearNumber
    );

    // Audit log
    await storage.createAuditLog({
      userId: user.id,
      action: 'compute_monthly_report',
      entityType: 'monthly_group_report',
      entityId: report.id,
      details: {
        groupId,
        monthNumber,
        yearNumber,
        reportId: report.id,
      },
      ipAddress: extractClientIp(req),
    });

    res.json({
      report,
      breakdown,
      message: 'گزارش ماهانه با موفقیت محاسبه شد'
    });
  } catch (error: any) {
    console.error('Error computing monthly report:', error);
    res.status(500).json({ 
      message: error.message || "خطا در محاسبه گزارش ماهانه" 
    });
  }
});

/**
 * PUT /api/reports/monthly/:reportId/manual-override
 * Manually override report fields (with audit trail)
 * Body: { field, value, reason }
 */
router.put("/:reportId/manual-override", requireAuth, requirePermission('reports:override_complete'), async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    if (!user || !user.id) {
      return res.status(401).json({ message: 'احراز هویت نشده' });
    }

    const { reportId } = req.params;
    const { field, value, reason } = req.body;

    const allowedFields = ['distributedCount', 'finalizedCount', 'underReviewCount', 'collectedAmount'];
    if (!allowedFields.includes(field)) {
      return res.status(400).json({ 
        message: `Field ${field} is not allowed for manual override. Allowed fields: ${allowedFields.join(', ')}` 
      });
    }

    // Get existing report by ID
    const { db } = await import('../db');
    const { monthlyGroupReports } = await import('@shared/schema');
    const { eq } = await import('drizzle-orm');
    
    const [report] = await db
      .select()
      .from(monthlyGroupReports)
      .where(eq(monthlyGroupReports.id, reportId))
      .limit(1);

    if (!report) {
      return res.status(404).json({ message: 'گزارش یافت نشد' });
    }

    // Get existing manual overrides
    const existingOverrides = (report.manualOverrides as any) || {};
    const overrideHistory = existingOverrides.history || [];

    // Add new override
    const newOverride = {
      field,
      oldValue: (report as any)[field],
      newValue: value,
      adjustedBy: user.id,
      adjustedAt: new Date().toISOString(),
      reason: reason || 'Manual adjustment',
    };

    overrideHistory.push(newOverride);

    // Update report
    const updateData: any = {
      [field]: value,
      manualOverrides: {
        ...existingOverrides,
        [field]: value,
        history: overrideHistory,
        lastAdjustedBy: user.id,
        lastAdjustedAt: new Date().toISOString(),
      },
      updatedAt: new Date(),
    };

    const [updated] = await db
      .update(monthlyGroupReports)
      .set(updateData)
      .where(eq(monthlyGroupReports.id, reportId))
      .returning();

    // Audit log
    await storage.createAuditLog({
      userId: user.id,
      action: 'manual_override_monthly_report',
      entityType: 'monthly_group_report',
      entityId: reportId,
      details: {
        field,
        oldValue: newOverride.oldValue,
        newValue: value,
        reason,
      },
      ipAddress: extractClientIp(req),
    });

    res.json({
      report: updated,
      message: 'گزارش با موفقیت به‌روزرسانی شد'
    });
  } catch (error: any) {
    console.error('Error updating monthly report:', error);
    res.status(500).json({ 
      message: error.message || "خطا در به‌روزرسانی گزارش" 
    });
  }
});

/**
 * PUT /api/groups/:groupId/monthly-tax-target
 * Update group's monthly tax target
 */
router.put("/groups/:groupId/monthly-tax-target", requireAuth, requirePermission('groups:manage'), async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    if (!user || !user.id) {
      return res.status(401).json({ message: 'احراز هویت نشده' });
    }

    const { groupId } = req.params;
    const { monthlyTaxTarget } = req.body;

    const target = monthlyTaxTarget === null || monthlyTaxTarget === '' 
      ? null 
      : parseFloat(monthlyTaxTarget);

    if (target !== null && (isNaN(target) || target < 0)) {
      return res.status(400).json({ message: 'Invalid monthly tax target value' });
    }

    const updated = await storage.updateGroupMonthlyTaxTarget(groupId, target);

    if (!updated) {
      return res.status(404).json({ message: 'گروه یافت نشد' });
    }

    // Audit log
    await storage.createAuditLog({
      userId: user.id,
      action: 'update_group_monthly_tax_target',
      entityType: 'group',
      entityId: groupId,
      details: {
        monthlyTaxTarget: target,
      },
      ipAddress: extractClientIp(req),
    });

    res.json({
      group: updated,
      message: 'هدف مالی ماهانه گروه با موفقیت به‌روزرسانی شد'
    });
  } catch (error: any) {
    console.error('Error updating group monthly tax target:', error);
    res.status(500).json({ 
      message: error.message || "خطا در به‌روزرسانی هدف مالی ماهانه" 
    });
  }
});

export default router;

