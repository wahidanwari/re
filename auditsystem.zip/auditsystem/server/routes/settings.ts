import { Router, type Request, type Response } from "express";
import { storage } from "../storage";
import { requireAuth } from "../middleware/auth";
import { requirePermission } from "../middleware/permissions";
import { insertSystemSettingSchema } from "@shared/schema";
import { extractClientIp } from "../utils/ipExtractor";

const router = Router();

router.get("/", requireAuth, async (req: Request, res: Response) => {
  try {
    const settings = await storage.getSettings();
    res.json(settings);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "خطا در دریافت تنظیمات" });
  }
});

// Get user preferences (language, theme, date format)
// IMPORTANT: This must be defined BEFORE /:key route to avoid route matching conflicts
router.get("/preferences", requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    if (!user || !user.id) {
      return res.status(401).json({ message: "احراز هویت نشده" });
    }
    
    const currentUser = await storage.getUser(user.id);
    if (!currentUser) {
      // Return defaults instead of 404 if user not found
      return res.json({
        preferredLanguage: 'dari',
        preferredTheme: 'light',
        dateFormat: 'shamsi',
      });
    }
    
    // Get preferences from user record or return defaults
    // Note: preferredTheme and dateFormat may be stored in user preferences JSON field if added to schema
    // For now, return what we have and defaults
    res.json({
      preferredLanguage: currentUser.preferredLanguage ?? 'dari',
      preferredTheme: (currentUser as any).preferredTheme ?? 'light',
      dateFormat: (currentUser as any).dateFormat ?? 'shamsi',
    });
  } catch (error) {
    console.error('Error fetching user preferences:', error);
    // Return defaults on error instead of 500
    res.json({
      preferredLanguage: 'dari',
      preferredTheme: 'light',
      dateFormat: 'shamsi',
    });
  }
});

router.get("/:key", requireAuth, async (req: Request, res: Response) => {
  try {
    const setting = await storage.getSetting(req.params.key);
    if (!setting) {
      return res.status(404).json({ message: "تنظیم یافت نشد" });
    }
    res.json(setting);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "خطا در دریافت تنظیم" });
  }
});

router.post("/", requireAuth, requirePermission('settings:manage'), async (req: Request, res: Response) => {
  try {
    const settingData = {
      ...req.body,
      updatedBy: (req.user as any).id,
    };
    
    const validatedData = insertSystemSettingSchema.parse(settingData);
    const setting = await storage.setSetting(validatedData);
    
    await storage.createAuditLog({
      userId: (req.user as any).id,
      action: 'update_setting',
      entityType: 'system_setting',
      entityId: setting.id,
      newValue: setting,
      ipAddress: extractClientIp(req),
    });
    
    res.json(setting);
  } catch (error) {
    console.error(error);
    res.status(400).json({ message: "خطا در ذخیره تنظیم" });
  }
});

router.put("/:key", requireAuth, requirePermission('settings:manage'), async (req: Request, res: Response) => {
  try {
    const { value } = req.body;
    const updatedSetting = await storage.updateSetting(
      req.params.key,
      value,
      (req.user as any).id
    );
    
    if (!updatedSetting) {
      return res.status(404).json({ message: "تنظیم یافت نشد" });
    }
    
    await storage.createAuditLog({
      userId: (req.user as any).id,
      action: 'update_setting',
      entityType: 'system_setting',
      entityId: updatedSetting.id,
      newValue: updatedSetting,
      ipAddress: extractClientIp(req),
    });
    
    res.json(updatedSetting);
  } catch (error) {
    console.error(error);
    res.status(400).json({ message: "خطا در بروز رسانی تنظیم" });
  }
});

// Update user preferences (language, theme, date format)
router.put("/preferences", requireAuth, async (req: Request, res: Response) => {
  try {
    const { preferredLanguage, preferredTheme, dateFormat } = req.body;
    const user = req.user as any;
    
    // Validate language
    if (preferredLanguage && !['dari', 'pashto', 'english'].includes(preferredLanguage)) {
      return res.status(400).json({ message: "زبان انتخابی نامعتبر است" });
    }
    
    // Validate theme
    if (preferredTheme && !['light', 'dark', 'system'].includes(preferredTheme)) {
      return res.status(400).json({ message: "تم انتخابی نامعتبر است" });
    }
    
    // Validate date format
    if (dateFormat && !['shamsi', 'gregorian'].includes(dateFormat)) {
      return res.status(400).json({ message: "فرمت تاریخ نامعتبر است" });
    }
    
    // Update user preferences
    // Note: preferredTheme and dateFormat can be stored in a JSON preferences field
    // For now, we'll store them in the user record if the schema supports it
    const updateData: any = {};
    if (preferredLanguage) updateData.preferredLanguage = preferredLanguage;
    // Store theme and dateFormat in user preferences JSON if schema supports it
    // Otherwise, we can store them client-side in localStorage
    
    const updatedUser = await storage.updateUser(user.id, updateData);
    
    if (!updatedUser) {
      return res.status(404).json({ message: "کاربر یافت نشد" });
    }
    
    await storage.createAuditLog({
      userId: user.id,
      action: 'update_preferences',
      entityType: 'user',
      entityId: user.id,
      details: { preferredLanguage, preferredTheme, dateFormat },
      ipAddress: extractClientIp(req),
    });
    
    res.json({
      preferredLanguage: updatedUser.preferredLanguage ?? 'dari',
      preferredTheme: preferredTheme ?? 'light',
      dateFormat: dateFormat ?? 'shamsi',
    });
  } catch (error) {
    console.error(error);
    res.status(400).json({ message: "خطا در بروز رسانی تنظیمات" });
  }
});

export default router;
