import { Router, type Request, type Response } from "express";
import { storage } from "../storage";
import { insertCaseSchema, type Case, type Entity } from "@shared/schema";
import { requireAuth } from "../middleware/auth";
import { requirePermission, requireAnyPermission, userHasPermission } from "../middleware/permissions";
import { extractClientIp } from "../utils/ipExtractor";
import jalaali from "jalaali-js";
import { string } from "zod";

const router = Router();

// Get all cases (filtered by permissions)
router.get("/", requireAuth, async (req: Request, res: Response) => {
  try {
    // User data is already refreshed by refreshUserData middleware
    const user = req.user as any;
    if (!user || !user.id) {
      return res.status(401).json({ message: 'احراز هویت نشده' });
    }
    
    // CRITICAL RBAC ENFORCEMENT: Use unified permission helper
    const { getCaseVisibility } = await import('../utils/permissionHelpers');
    const visibility = await getCaseVisibility(user);
    
    // DEBUG LOGGING: Log visibility decision and result count
    if (process.env.DEBUG_LOGGING === 'true') {
      console.log(`[CASES ROUTE] User: ${user.id} (${user.role}), Packages: ${JSON.stringify(user.permissionPackages || [])}, Visibility: canViewAll=${visibility.canViewAll}, requiresFiltering=${visibility.requiresFiltering}, filterByAssignee=${visibility.filterByAssignee}, filterByGroup=${visibility.filterByGroup}`);
    }
    
    let cases: Case[] = [];
    
    if (visibility.canViewAll) {
      // User can see all cases (coordinator, director, admin)
      cases = await storage.getCases();
      if (process.env.DEBUG_LOGGING === 'true') {
        console.log(`[CASES ROUTE] Coordinator/Admin access - returning ${cases.length} cases`);
      }
    } else if (visibility.requiresFiltering) {
      if (visibility.filterByAssignee) {
        // Auditor: Get cases assigned to them
        cases = await storage.getCasesByAssignee(user.id);
      } else if (visibility.filterByGroup) {
        // Senior auditor: Get cases for their group
        cases = await storage.getCasesByGroup(visibility.filterByGroup);
      } else {
        // No access
        cases = [];
      }
    } else {
      // No access
      cases = [];
    }
    
    // Set cache control headers to prevent stale data
    res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, private');
    res.setHeader('Pragma', 'no-cache');
    res.setHeader('Expires', '0');
    
    // Log RBAC decision only in debug mode (removes user IDs from production logs)
    if (process.env.DEBUG_LOGGING === 'true') {
      console.log(`[RBAC] GET /cases - User: ${user.role}, GroupId: ${user.groupId ? 'set' : 'none'}, Cases returned: ${cases.length}`);
    }
    
    res.json(cases);
  } catch (error) {
    console.error('Error fetching cases:', error);
    res.status(500).json({ message: "خطا در دریافت لیست قضایا" });
  }
});

// Get case by ID (with RBAC enforcement)
router.get("/:id", requireAuth, async (req: Request, res: Response) => {
  try {
    // User data is already refreshed by refreshUserData middleware
    const user = req.user as any;
    if (!user || !user.id) {
      return res.status(401).json({ message: 'احراز هویت نشده' });
    }
    
    const caseData = await storage.getCase(req.params.id);
    if (!caseData) {
      return res.status(404).json({ message: "قضیه یافت نشد" });
    }

    // Use unified permission helper
    const { getCaseVisibility } = await import('../utils/permissionHelpers');
    const visibility = await getCaseVisibility(user);

    // RBAC enforcement: Check if user has permission to view this specific case
    if (user.role !== 'system_admin') {
      const { getEffectivePermissions } = await import('../services/permissionService');
      const effectivePermissions = await getEffectivePermissions(user.id);
      
      // Check if user has cases:view permission
      if (!effectivePermissions['cases:view']) {
        return res.status(403).json({ message: 'عدم دسترسی - شما مجوز لازم را ندارید' });
      }
      
      // If coordinator, can view all cases
      if (visibility.canViewAll) {
        // Access granted, continue
      } else if (visibility.filterByAssignee) {
        // Auditor: Check if case is assigned to them
        if (caseData.assignedTo !== user.id) {
          return res.status(403).json({ message: 'عدم دسترسی - شما فقط می‌توانید قضایای اختصاص داده شده به خود را مشاهده کنید' });
        }
      } else if (visibility.filterByGroup) {
        // Senior auditor: Check if case belongs to their group
        if (caseData.receivingGroup !== visibility.filterByGroup) {
          return res.status(403).json({ message: 'عدم دسترسی - شما فقط می‌توانید قضایای گروه خود را مشاهده کنید' });
        }
      } else {
        // No access
        return res.status(403).json({ message: 'عدم دسترسی' });
      }
    }
    
    // Enhance response with additional data
    const responseData: any = { ...caseData };
    
    // Get assigned user info
    if (caseData.assignedTo) {
      const assignedUser = await storage.getUser(caseData.assignedTo);
      responseData.assignedUser = assignedUser ? {
        id: assignedUser.id,
        fullName: assignedUser.fullName,
        auditId: assignedUser.auditId,
      } : null;
    }
    
    // Get assigned by user info
    if (caseData.assignedBy) {
      const assignedByUser = await storage.getUser(caseData.assignedBy);
      responseData.assignedByUser = assignedByUser ? {
        id: assignedByUser.id,
        fullName: assignedByUser.fullName,
        auditId: assignedByUser.auditId,
      } : null;
    }
    
    // Get case metrics
    const metrics = await storage.getCaseMetrics(req.params.id);
    responseData.metrics = metrics || null;
    
    // Get installment payments
    const installments = await storage.getInstallmentPayments(req.params.id);
    responseData.installments = installments || [];
    
    // Get case flags
    const flags = await storage.getCaseFlags(req.params.id);
    responseData.flags = flags || [];
    
    // Get section statuses
    const sectionStatuses = await storage.getCaseSectionStatus(req.params.id);
    responseData.sectionStatuses = sectionStatuses || [];
    
    res.json(responseData);
  } catch (error) {
    console.error('Error getting case:', error);
    res.status(500).json({ message: "خطا در دریافت اطلاعات قضیه" });
  }
});

// Get cases by group (with RBAC enforcement)
router.get("/group/:groupId", requireAuth, async (req: Request, res: Response) => {
  try {
    // Get fresh user data from database
    const sessionUser = req.user as any;
    if (!sessionUser || !sessionUser.id) {
      return res.status(401).json({ message: 'احراز هویت نشده' });
    }
    
    const user = await storage.getUser(sessionUser.id);
    if (!user) {
      return res.status(401).json({ message: 'کاربر یافت نشد' });
    }
    
    const groupId = req.params.groupId;
    
    // Get effective permissions
    const { getEffectivePermissions, isCoordinator } = await import('../services/permissionService');
    const effectivePermissions = await getEffectivePermissions(user.id);
    const coordinatorCheck = await isCoordinator(user.id);
    
    // CRITICAL RBAC ENFORCEMENT: Only allow access to own group, unless coordinator
    if (user.role !== 'system_admin') {
      // Check if user has cases:view permission
      if (!effectivePermissions['cases:view']) {
        return res.status(403).json({ message: 'عدم دسترسی - شما مجوز لازم را ندارید' });
      }
      
      const baseRole = user.role;
      
      if (baseRole === 'auditor') {
        // Auditor cannot access group cases endpoint, UNLESS coordinator
        if (!coordinatorCheck) {
          return res.status(403).json({ message: 'عدم دسترسی - شما فقط می‌توانید قضایای اختصاص داده شده به خود را مشاهده کنید' });
        }
      } else if (baseRole === 'senior_auditor' && user.groupId && !coordinatorCheck) {
        // Senior auditor can ONLY access their own group's cases
        if (groupId !== user.groupId) {
          return res.status(403).json({ message: 'عدم دسترسی - شما فقط می‌توانید قضایای گروه خود را مشاهده کنید' });
        }
      } else if (!coordinatorCheck && baseRole !== 'director' && !effectivePermissions['groups:set_targets']) {
        // Other roles without coordinator package or director permissions cannot access
        return res.status(403).json({ message: 'عدم دسترسی' });
      }
    }
    
    const cases = await storage.getCasesByGroup(groupId);
    res.json(cases);
  } catch (error) {
    res.status(500).json({ message: "خطا در دریافت قضایای گروه" });
  }
});

// Create case (requires cases:assign_to_group or cases:assign_to_auditor)
// Create case - requires entities:create permission (Senior Auditor or Coordinator, NOT Auditor)
router.post("/", requireAuth, requirePermission('entities:create'), async (req: Request, res: Response) => {
  try {
    // Validate entity exists first
    const entity = await storage.getEntity(req.body.entityId);
    if (!entity) {
      return res.status(400).json({ message: "نهاد یافت نشد" });
    }
    
    // NEW ARCHITECTURE: Check for existing audit record or require auditRecordId
    // First, check if entity has any audit records
    const entityAuditRecords = await storage.getAuditRecords(req.body.entityId);
    const hasAuditRecords = entityAuditRecords.length > 0;
    
    let auditRecord = null;
    
    // If entity has no audit records, auditRecordId is optional
    if (!hasAuditRecords && !req.body.auditRecordId) {
      // Allow case creation without audit record for first-time entities
      auditRecord = null;
    } else if (req.body.auditRecordId) {
      // Use provided audit record
      auditRecord = await storage.getAuditRecord(req.body.auditRecordId);
      if (!auditRecord) {
        // Log missing audit record attempt
        console.error('[CASE_CREATION] Missing audit record', {
          userId: (req.user as any).id,
          entityId: req.body.entityId,
          auditRecordId: req.body.auditRecordId,
          payload: { ...req.body, password: undefined },
        });
        
        return res.status(400).json({ 
          code: 'MISSING_AUDIT_RECORD',
          message: "سابقه بررسی یافت نشد",
          messageFa: "سابقه بررسی یافت نشد. لطفاً یک سابقه بررسی معتبر انتخاب کنید.",
          help: "select audit record or create new via /api/audit-records/entities/:entityId/audits"
        });
      }
      
      // Validate that audit record belongs to the provided entity
      if (auditRecord.entityId !== req.body.entityId) {
        console.error('[CASE_CREATION] Audit record entity mismatch', {
          userId: (req.user as any).id,
          entityId: req.body.entityId,
          auditRecordId: req.body.auditRecordId,
          auditRecordEntityId: auditRecord.entityId,
        });
        
        return res.status(400).json({ 
          code: 'AUDIT_RECORD_ENTITY_MISMATCH',
          message: "سابقه بررسی متعلق به این نهاد نیست",
          messageFa: "سابقه بررسی انتخاب شده متعلق به نهاد انتخاب شده نیست. لطفاً سابقه بررسی صحیح را انتخاب کنید.",
        });
      }
      
      // Check if audit record is completed (policy: no new cases on completed audits)
      if (auditRecord.status === 'completed') {
        return res.status(400).json({ 
          code: 'AUDIT_RECORD_COMPLETED',
          message: "این سابقه بررسی تکمیل شده است — ایجاد قضیه جدید برای این سابقه مجاز نیست",
          messageFa: "این سابقه بررسی تکمیل شده است — ایجاد قضیه جدید برای این سابقه مجاز نیست",
        });
      }
    } else if (req.body.entityId && (req.body.yearFrom || req.body.yearTo || req.body.auditYears)) {
      // OPTIONAL: Resolve audit record by entity + year range
      let yearFrom: number | undefined;
      let yearTo: number | undefined;
      
      if (req.body.yearFrom && req.body.yearTo) {
        yearFrom = parseInt(req.body.yearFrom, 10);
        yearTo = parseInt(req.body.yearTo, 10);
      } else if (req.body.auditYears) {
        // Parse auditYears text
        const parsed = req.body.auditYears.replace(/[–—]/g, '-');
        if (parsed.includes('-')) {
          const parts = parsed.split('-').map((s: string) => s.trim());
          yearFrom = parseInt(parts[0], 10);
          yearTo = parseInt(parts[1] || parts[0], 10);
        } else {
          yearFrom = parseInt(parsed, 10);
          yearTo = yearFrom;
        }
      }
      
      if (yearFrom !== undefined && yearTo !== undefined && !isNaN(yearFrom) && !isNaN(yearTo)) {
        const existingRecords = await storage.getAuditRecords(req.body.entityId, { yearFrom, yearTo });
        
        if (existingRecords.length === 0) {
          // No audit record found - optionally create one if allow_auto_create is true
          if (req.body.allow_auto_create === true && req.body.groupReferrer && req.body.referralDate) {
            // Auto-create audit record (requires referring group and referral date)
            try {
              const newAuditRecord = await storage.createAuditRecord({
                entityId: req.body.entityId,
                auditYears: req.body.auditYears || `${yearFrom}${yearFrom !== yearTo ? `-${yearTo}` : ''}`,
                referringGroup: req.body.groupReferrer,
                referralDate: new Date(req.body.referralDate),
                yearFrom,
                yearTo,
                status: 'in-progress',
                createdByUserId: (req.user as any).id,
              });
              auditRecord = newAuditRecord;
            } catch (error: any) {
              console.error('[CASE_CREATION] Failed to auto-create audit record', error);
              return res.status(400).json({ 
                code: 'AUDIT_RECORD_CREATION_FAILED',
                message: "نمی‌توان سابقه بررسی را به صورت خودکار ایجاد کرد",
                messageFa: "نمی‌توان سابقه بررسی را به صورت خودکار ایجاد کرد. لطفاً ابتدا یک سابقه بررسی ایجاد کنید.",
                error: error.message,
              });
            }
          } else {
            // Log missing audit record attempt
            console.error('[CASE_CREATION] Missing audit record for entity+year', {
              userId: (req.user as any).id,
              entityId: req.body.entityId,
              yearFrom,
              yearTo,
              payload: { ...req.body, password: undefined },
            });
            
            return res.status(400).json({ 
              code: 'MISSING_AUDIT_RECORD',
              message: "لطفاً یک سابقه بررسی موجود را انتخاب کنید یا یک سابقه جدید برای این نهاد ایجاد کنید",
              messageFa: "لطفاً یک سابقه بررسی موجود را انتخاب کنید یا یک سابقه جدید برای این نهاد ایجاد کنید",
              help: "select audit record or create new via /api/audit-records/entities/:entityId/audits",
              suggestion: "You can create an audit record first, or provide allow_auto_create=true with groupReferrer and referralDate to auto-create"
            });
          }
        } else if (existingRecords.length === 1) {
          // Single match - use it
          auditRecord = existingRecords[0];
          
          // Check if completed
          if (auditRecord.status === 'completed') {
            return res.status(400).json({ 
              code: 'AUDIT_RECORD_COMPLETED',
              message: "این سابقه بررسی تکمیل شده است — ایجاد قضیه جدید برای این سابقه مجاز نیست",
              messageFa: "این سابقه بررسی تکمیل شده است — ایجاد قضیه جدید برای این سابقه مجاز نیست",
            });
          }
        } else {
          // Multiple matches - return conflict with list
          return res.status(409).json({ 
            code: 'MULTIPLE_AUDIT_RECORDS',
            message: "چندین سابقه بررسی برای این بازه سالی یافت شد",
            messageFa: "چندین سابقه بررسی برای این بازه سالی یافت شد. لطفاً شناسه سابقه بررسی را به صورت صریح مشخص کنید.",
            conflicts: existingRecords.map(r => ({
              id: r.id,
              auditYears: r.auditYears || `${r.yearFrom}-${r.yearTo}`,
              status: r.status,
              assignedGroup: r.assignedGroup,
            })),
          });
        }
      }
    }
    
    // Final check: require audit record ONLY if entity has audit records
    if (!auditRecord && hasAuditRecords) {
      // Entity has audit records but none was selected/resolved
      console.error('[CASE_CREATION] Missing audit record - entity has records but none selected', {
        userId: (req.user as any).id,
        entityId: req.body.entityId,
        auditRecordsCount: entityAuditRecords.length,
        payload: { ...req.body, password: undefined },
      });
      
      return res.status(400).json({ 
        code: 'MISSING_AUDIT_RECORD',
        message: "لطفاً یک سابقه بررسی موجود را انتخاب کنید",
        messageFa: "این نهاد دارای سابقه بررسی است. لطفاً یک سابقه بررسی را انتخاب کنید.",
        help: "select audit record via /api/audit-records/entities/:entityId/audits"
      });
    }
    
    // If entity has no audit records, auditRecord is null and that's OK
    
    // Require explicit groupReferrer selection (no autofill from entity or audit record)
    const senderGroup = req.body.groupReferrer;
    if (!senderGroup || senderGroup.trim() === '') {
      return res.status(400).json({ message: "گروه ارجاع‌دهنده الزامی است. لطفاً گروه ارجاع‌دهنده را انتخاب کنید." });
    }
    
    // CRITICAL: Validate no overlapping audit year ranges for the same entity
    // Parse auditYearRange from request to extract startYear and endYear
    let newStartYear: number | null = null;
    let newEndYear: number | null = null;
    
    if (req.body.auditYearRange) {
      const rangeStr = req.body.auditYearRange.trim();
      // Parse formats like "1399–1401", "1399-1401", or single year "1400"
      const rangeMatch = rangeStr.match(/^(\d{4})[\s\-–—]+(\d{4})$/);
      const singleYearMatch = rangeStr.match(/^(\d{4})$/);
      
      if (rangeMatch) {
        newStartYear = parseInt(rangeMatch[1], 10);
        newEndYear = parseInt(rangeMatch[2], 10);
      } else if (singleYearMatch) {
        const year = parseInt(singleYearMatch[1], 10);
        newStartYear = year;
        newEndYear = year;
      }
    }
    
    // If auditYearRange is provided, validate it's parseable
    if (req.body.auditYearRange && (newStartYear === null || newEndYear === null || isNaN(newStartYear) || isNaN(newEndYear))) {
      return res.status(400).json({ 
        code: 'INVALID_YEAR_RANGE',
        message: "فرمت بازه سالی نامعتبر است",
        messageFa: "فرمت بازه سالی نامعتبر است. فرمت صحیح: \"1400\" یا \"1399–1401\"",
      });
    }
    
    // Validate startYear <= endYear
    if (newStartYear !== null && newEndYear !== null && newStartYear > newEndYear) {
      return res.status(400).json({ 
        code: 'INVALID_YEAR_RANGE',
        message: "سال شروع نمی‌تواند بزرگتر از سال پایان باشد",
        messageFa: "سال شروع نمی‌تواند بزرگتر از سال پایان باشد",
      });
    }
    
    // Check for overlapping year ranges with existing cases (regardless of status)
    if (newStartYear !== null && newEndYear !== null) {
      const existingCases = await storage.getCasesByEntity(req.body.entityId);
      
      // Helper function to parse year range from existing case
      const parseCaseYearRange = (rangeStr: string | null | undefined): { startYear: number; endYear: number } | null => {
        if (!rangeStr || !rangeStr.trim()) return null;
        const trimmed = rangeStr.trim();
        const rangeMatch = trimmed.match(/^(\d{4})[\s\-–—]+(\d{4})$/);
        const singleYearMatch = trimmed.match(/^(\d{4})$/);
        
        if (rangeMatch) {
          const start = parseInt(rangeMatch[1], 10);
          const end = parseInt(rangeMatch[2], 10);
          if (!isNaN(start) && !isNaN(end)) {
            return { startYear: start, endYear: end };
          }
        } else if (singleYearMatch) {
          const year = parseInt(singleYearMatch[1], 10);
          if (!isNaN(year)) {
            return { startYear: year, endYear: year };
          }
        }
        return null;
      };
      
      // Helper function to check if two year ranges overlap
      const rangesOverlap = (
        start1: number, end1: number,
        start2: number, end2: number
      ): boolean => {
        // Two ranges overlap if: start1 <= end2 AND start2 <= end1
        return start1 <= end2 && start2 <= end1;
      };
      
      // Check each existing case for overlap
      // Prefer numeric columns if available, fallback to parsing text field
      const overlappingCases: Array<{ caseId: string; auditYearRange: string; status: string }> = [];
      
      for (const existingCase of existingCases) {
        let existingStartYear: number | null = null;
        let existingEndYear: number | null = null;
        
        // Prefer numeric columns if available (from migration)
        if ((existingCase as any).auditYearStart !== null && (existingCase as any).auditYearStart !== undefined &&
            (existingCase as any).auditYearEnd !== null && (existingCase as any).auditYearEnd !== undefined) {
          existingStartYear = (existingCase as any).auditYearStart;
          existingEndYear = (existingCase as any).auditYearEnd;
        } else {
          // Fallback to parsing text field for backward compatibility
          const existingRange = parseCaseYearRange(existingCase.auditYearRange || null);
          if (existingRange) {
            existingStartYear = existingRange.startYear;
            existingEndYear = existingRange.endYear;
          }
        }
        
        if (existingStartYear !== null && existingEndYear !== null) {
          if (rangesOverlap(newStartYear, newEndYear, existingStartYear, existingEndYear)) {
            overlappingCases.push({
              caseId: existingCase.caseId,
              auditYearRange: existingCase.auditYearRange || `${existingStartYear}–${existingEndYear}`,
              status: existingCase.status,
            });
          }
        }
      }
      
      // If any overlaps found, reject the request
      if (overlappingCases.length > 0) {
        return res.status(409).json({ 
          code: 'OVERLAPPING_YEAR_RANGE',
          message: "بازه سالی با قضایای موجود همپوشانی دارد",
          messageFa: `بازه سالی "${req.body.auditYearRange}" با ${overlappingCases.length} قضیه موجود همپوشانی دارد. هر نهاد می‌تواند فقط یک قضیه برای هر بازه سالی داشته باشد.`,
          conflicts: overlappingCases,
          requestedRange: req.body.auditYearRange,
        });
      }
    }
    
    // Static predefined referral groups (don't exist in DB, so skip validation)
    const STATIC_REFERRAL_GROUPS = [
      'گروه اول سنجش ابتدایی',
      'گروه دوم سنجش ابتدایی',
      'گروه سوم سنجش ابتدایی',
      'گروه چهارم سنجش ابتدایی',
      'گروه پنجم سنجش ابتدایی',
      'گروه ششم سنجش ابتدایی',
      'گروه هفتم سنجش ابتدایی',
      'گروه هشتم سنجش ابتدایی',
      'گروه نهم سنجش ابتدایی',
      'مدیریت عمومی تشخیص مالیه دهنده',
    ];
    
    // Check if it's a static group (by name)
    const isStaticGroup = STATIC_REFERRAL_GROUPS.includes(senderGroup);
    
    // Only validate if it's not a static group
    if (!isStaticGroup) {
      // Validate sender group exists (try by ID first, then by name)
      let senderGroupObj = await storage.getGroup(senderGroup);
      if (!senderGroupObj) {
        // Try looking up by name
        senderGroupObj = await storage.getGroupByName(senderGroup);
      }
      if (!senderGroupObj) {
        return res.status(400).json({ message: "گروه ارجاع‌دهنده یافت نشد" });
      }
    }
    
    // Validate receiving group exists (audit group - PHASE 1)
    if (req.body.receivingGroup) {
      const receivingGroupObj = await storage.getGroup(req.body.receivingGroup);
      if (!receivingGroupObj) {
        return res.status(400).json({ message: "گروه دریافت‌کننده یافت نشد" });
      }
    }
    
    // CRITICAL: Validate committeeId exists BEFORE assignment to prevent FK violation
    if (req.body.committeeId) {
      const committee = await storage.getCommittee(req.body.committeeId);
      if (!committee) {
        return res.status(400).json({ 
          code: 'INVALID_COMMITTEE_ID',
          message: "کمیته یافت نشد",
          messageFa: `کمیته با شناسه "${req.body.committeeId}" یافت نشد. لطفاً یک کمیته معتبر انتخاب کنید.`,
        });
      }
    }
    
    // Auto-generate case number (remove any caseNumber from request body to prevent conflicts)
    const { caseNumber: _, caseId: __, ...bodyWithoutCaseFields } = req.body;
    
    const maxCaseNumber = await storage.getMaxCaseNumber();
    let numericCaseNumber = maxCaseNumber + 1;
    let caseId = String(numericCaseNumber);
    
    // Check if caseId already exists and find next available
    let existingCaseById = await storage.getCasesByCaseId(caseId);
    while (existingCaseById) {
      numericCaseNumber += 1;
      caseId = String(numericCaseNumber);
      existingCaseById = await storage.getCasesByCaseId(caseId);
    }
    
    // Ensure caseNumber is always a valid number
    if (!numericCaseNumber || numericCaseNumber <= 0) {
      numericCaseNumber = 1;
      caseId = '1';
    }
    
    // CRITICAL: Construct periodsUnderReview from auditYearRange or year range
    // This field is required (.notNull()) in the schema
    let periodsUnderReview: string;
    if (req.body.auditYearRange) {
      periodsUnderReview = req.body.auditYearRange.trim();
    } else if (newStartYear !== null && newEndYear !== null) {
      // Construct from numeric years
      if (newStartYear === newEndYear) {
        periodsUnderReview = String(newStartYear);
      } else {
        periodsUnderReview = `${newStartYear}–${newEndYear}`;
      }
    } else {
      // Fallback: use empty string or default (should not happen if validation is correct)
      periodsUnderReview = req.body.periodsUnderReview || '';
    }
    
    const caseData = {
      ...bodyWithoutCaseFields,
      caseId, // Display ID (numeric string)
      caseNumber: numericCaseNumber, // Auto-generated numeric ID
      groupReferrer: senderGroup, // گروه ارجاع‌دهنده (explicitly selected by user)
      status: 'ایجاد شده',
      periodsUnderReview, // CRITICAL: Required field - سال‌های بررسی
      auditYearRange: req.body.auditYearRange || periodsUnderReview, // For backward compatibility
      // Populate numeric audit year columns for database constraint
      auditYearStart: newStartYear !== null ? newStartYear : undefined,
      auditYearEnd: newEndYear !== null ? newEndYear : undefined,
    };
    
    // Validate case data with schema
    let validatedData;
    try {
      validatedData = insertCaseSchema.parse(caseData);
    } catch (error: any) {
      // Log detailed error for debugging
      console.error('[CASE_CREATION] Schema validation error:', {
        error: error.message,
        issues: error.issues,
        caseData: Object.keys(caseData).reduce((acc, key) => {
          acc[key] = caseData[key as keyof typeof caseData] === undefined ? 'UNDEFINED' : typeof caseData[key as keyof typeof caseData];
          return acc;
        }, {} as Record<string, string>),
      });
      
      // Return user-friendly error message
      if (error.issues && Array.isArray(error.issues)) {
        const missingFields = error.issues
          .filter((issue: any) => issue.code === 'invalid_type' && issue.received === 'undefined')
          .map((issue: any) => issue.path.join('.'))
          .join(', ');
        
        if (missingFields) {
          return res.status(400).json({
            code: 'MISSING_REQUIRED_FIELDS',
            message: `فیلدهای الزامی وجود ندارند: ${missingFields}`,
            messageFa: `فیلدهای الزامی وجود ندارند: ${missingFields}`,
          });
        }
      }
      
      return res.status(400).json({
        code: 'VALIDATION_ERROR',
        message: 'خطا در اعتبارسنجی داده‌ها',
        messageFa: error.message || 'خطا در اعتبارسنجی داده‌ها',
      });
    }
    
    const newCase = await storage.createCase(validatedData);
    
    // Audit Logging / Traceability - Capture entity source
    await storage.createAuditLog({
      userId: (req.user as any).id,
      action: 'create_case',
      entityType: 'case',
      entityId: newCase.id,
      details: {
        case: newCase,
        sourceEntity: {
          id: entity.id,
          companyName: entity.companyName,
          tin: entity.tin,
        },
        createdFromEntity: true, // Flag indicating case was created from entity management
        // Only include auditRecordId if audit record exists
        ...(auditRecord ? {
          auditRecordId: auditRecord.id,
          auditYears: auditRecord.auditYears || null,
        } : {
          auditRecordId: null,
          auditYears: null,
        }),
        hasAuditRecords: hasAuditRecords,
        auditRecordsCount: entityAuditRecords.length,
        groupReferrer: senderGroup,
        receivingGroup: req.body.receivingGroup || null,
      },
      ipAddress: extractClientIp(req),
    });
    
    if (newCase.groupReferrer) {
      await storage.createNotification({
        userId: newCase.groupReferrer,
        message: `قضیه جدید ${caseId} به گروه شما ارجاع شد`,
        messagePashto: `نوې قضیه ${caseId} ستاسو ډلې ته حواله شوه`,
        type: 'case_assignment',
      });
    }
    
    res.status(201).json(newCase);
  } catch (error: any) {
    console.error('[CASE CREATION ERROR]', error);
    // Log the actual error message for debugging
    if (error?.message) {
      console.error('[CASE CREATION ERROR MESSAGE]', error.message);
    }
    if (error?.issues) {
      console.error('[CASE CREATION VALIDATION ERRORS]', JSON.stringify(error.issues, null, 2));
    }
    // Return more specific error message if it's a validation error
    if (error?.issues && Array.isArray(error.issues)) {
      const caseNumberError = error.issues.find((issue: any) => 
        issue.path?.includes('caseNumber') || issue.path?.includes('case_number')
      );
      if (caseNumberError) {
        return res.status(400).json({ 
          message: `خطا در اعتبارسنجی: ${caseNumberError.message || 'خطا در ایجاد قضیه'}` 
        });
      }
    }
    res.status(400).json({ message: error?.message || "خطا در ایجاد قضیه" });
  }
});

// Update case (admin only)
router.put("/:id", requireAuth, requirePermission('users:manage'), async (req: Request, res: Response) => {
  try {
    const oldCase = await storage.getCase(req.params.id);
    if (!oldCase) {
      return res.status(404).json({ message: "قضیه یافت نشد" });
    }
    
    // Allow flag updates even for completed cases
    // Only prevent status changes for completed cases (flags can be updated)
    const { CaseStatus } = await import('@shared/schema');
    if (oldCase.status === CaseStatus.COMPLETED && req.body.status && req.body.status !== CaseStatus.COMPLETED) {
      return res.status(400).json({ 
        message: "نمی توان وضعیت قضیه تکمیل شده را تغییر داد" 
      });
    }
    
    // CRITICAL: Validate committeeId exists BEFORE update to prevent FK violation
    if (req.body.committeeId !== undefined) {
      // If committeeId is being set (including null), validate it exists
      if (req.body.committeeId !== null && req.body.committeeId !== '') {
        const committee = await storage.getCommittee(req.body.committeeId);
        if (!committee) {
          return res.status(400).json({ 
            code: 'INVALID_COMMITTEE_ID',
            message: "کمیته یافت نشد",
            messageFa: `کمیته با شناسه "${req.body.committeeId}" یافت نشد. لطفاً یک کمیته معتبر انتخاب کنید.`,
          });
        }
      }
    }
    
    const updatedCase = await storage.updateCase(req.params.id, req.body);
    if (!updatedCase) {
      return res.status(404).json({ message: "قضیه یافت نشد" });
    }
    
    await storage.createAuditLog({
      userId: (req.user as any).id,
      action: 'update_case',
      entityType: 'case',
      entityId: updatedCase.id,
      details: {
        oldCase: oldCase,
        newCase: updatedCase,
      },
      ipAddress: extractClientIp(req),
    });
    
    res.json(updatedCase);
  } catch (error) {
    res.status(400).json({ message: "خطا در بروزرسانی قضیه" });
  }
});

// Assign case to auditor or group
router.post("/:id/assign", requireAuth, requireAnyPermission(['cases:assign_to_auditor', 'cases:assign_to_group', 'users:manage']), async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    const { userId, groupId } = req.body;
    
    // Validate that either userId or groupId is provided, but not both
    if (!userId && !groupId) {
      return res.status(400).json({ 
        message: "باید کاربر یا گروه مشخص شود. لطفاً یکی از فیلدهای userId یا groupId را ارسال کنید." 
      });
    }
    
    if (userId && groupId) {
      return res.status(400).json({ 
        message: "نمی‌توان همزمان به کاربر و گروه اختصاص داد. لطفاً فقط یکی از فیلدهای userId یا groupId را ارسال کنید." 
      });
    }
    
    // Check if user has permission to assign cases
    const { getEffectivePermissions, isCoordinator } = await import('../services/permissionService');
    const effectivePermissions = await getEffectivePermissions(user.id);
    const coordinatorCheck = await isCoordinator(user.id);
    
    // Auditors without coordinator package cannot assign cases
    if (user.role === 'auditor' && !coordinatorCheck) {
      const hasAssignPermission = effectivePermissions['cases:assign_to_auditor'] || effectivePermissions['cases:assign_to_group'];
      if (!hasAssignPermission) {
        return res.status(403).json({ 
          message: 'بررس‌ها نمی‌توانند قضایا را واگذار کنند. فقط می‌توانند قضایای اختصاص داده شده به خود را مشاهده کنند.' 
        });
      }
    }
    
    // Get the case first to check permissions
    const caseToAssign = await storage.getCase(req.params.id);
    if (!caseToAssign) {
      return res.status(404).json({ message: "قضیه یافت نشد" });
    }
    
    // System admin can assign any case
    if (user.role !== 'system_admin') {
      // Get effective permissions to check coordinator status
      const { getEffectivePermissions, isCoordinator } = await import('../services/permissionService');
      const effectivePermissions = await getEffectivePermissions(user.id);
      const coordinatorCheck = await isCoordinator(user.id);
      
      // If senior auditor (and not coordinator), ensure they can only assign cases from their audit group
      // PHASE 1: Use receivingGroup for audit group filtering
      if (user.role === 'senior_auditor' && user.groupId && !coordinatorCheck) {
        if (caseToAssign.receivingGroup !== user.groupId) {
          return res.status(403).json({ message: 'شما فقط می‌توانید قضایای گروه خود را واگذار کنید' });
        }
      }
    }
    
    let updatedCase;
    let assignmentType = '';
    
    // Assign to group
    if (groupId) {
      // Check if user has permission to assign to groups
      const hasGroupAssignPermission = await userHasPermission(user, 'cases:assign_to_group');
      if (!hasGroupAssignPermission && user.role !== 'system_admin') {
        return res.status(403).json({ message: 'شما مجوز اختصاص قضیه به گروه را ندارید' });
      }
      
      // Validate group exists
      const group = await storage.getGroup(groupId);
      if (!group) {
        return res.status(404).json({ message: "گروه یافت نشد" });
      }
      
      // If senior auditor (and not coordinator), ensure they can only assign to their own group
      if (user.role === 'senior_auditor' && user.groupId) {
        const { isCoordinator } = await import('../services/permissionService');
        const coordinatorCheck = await isCoordinator(user.id);
        
        if (!coordinatorCheck) {
          // Senior Auditor can only assign to their own group
          if (groupId !== user.groupId) {
            return res.status(403).json({ 
              message: 'شما فقط می‌توانید قضایا را به گروه خود اختصاص دهید' 
            });
          }
        }
      }
      
      // CRITICAL: Validate that case is in CREATED status for group assignment
      const { CaseStatus } = await import('@shared/schema');
      if (caseToAssign.status !== CaseStatus.CREATED) {
        return res.status(400).json({ 
          message: `قضیه باید در وضعیت "ایجاد شده" باشد تا به گروه اختصاص داده شود. وضعیت فعلی: ${caseToAssign.status}` 
        });
      }
      
      // Use state machine for group assignment
      const { executeTransition } = await import('../services/caseStateMachine');
      
      // Execute transition using state machine (assign_to_group from CREATED)
      const transitionResult = await executeTransition(req.params.id, user, 'assign_to_group', {
        groupId: groupId,
        notes: `قضیه به گروه اختصاص داده شد`,
      });
      
      if (!transitionResult.success) {
        return res.status(400).json({ 
          message: transitionResult.errorMessage || 'خطا در اختصاص قضیه به گروه' 
        });
      }
      
      // Get updated case
      updatedCase = await storage.getCase(req.params.id);
      if (!updatedCase) {
        return res.status(404).json({ message: "قضیه یافت نشد" });
      }
      assignmentType = 'group';
      
      if (!updatedCase) {
        return res.status(404).json({ message: "قضیه یافت نشد" });
      }
      
      // Get all group members to notify them and return in response
      const groupMembers = await storage.getGroupMembers(groupId);
      const activeMembers = groupMembers.filter(m => m.isActive);
      
      // Get full user details for active members (for response)
      const activeMembersWithUsers = await Promise.all(
        activeMembers.map(async (member) => {
          const memberUser = await storage.getUser(member.userId);
          return {
            ...member,
            user: memberUser ? {
              id: memberUser.id,
              fullName: memberUser.fullName,
              auditId: memberUser.auditId,
              role: memberUser.role,
            } : null,
          };
        })
      );
      
      // Notify all active group members
      const groupName = group?.name || group?.code || 'گروه';
      for (const member of activeMembers) {
        try {
          const memberUser = await storage.getUser(member.userId);
          if (memberUser) {
            await storage.createNotification({
              userId: member.userId,
              message: `قضیه ${updatedCase.caseId} به گروه ${groupName} اختصاص داده شد`,
              messagePashto: `قضیه ${updatedCase.caseId} د ${groupName} ډلې ته تعیین شوه`,
              type: 'case_assignment',
            });
          }
        } catch (error) {
          console.error(`Failed to notify group member ${member.userId}:`, error);
        }
      }
    } 
    // Assign to individual user
    else if (userId) {
      // Check if user has permission to assign to auditor
      const hasAuditorAssignPermission = await userHasPermission(user, 'cases:assign_to_auditor');
      if (!hasAuditorAssignPermission && user.role !== 'system_admin') {
        return res.status(403).json({ message: 'شما مجوز اختصاص قضیه به کاربر را ندارید' });
      }
      
      // Validate user exists
      const targetUser = await storage.getUser(userId);
      if (!targetUser) {
        return res.status(404).json({ message: "کاربر یافت نشد" });
      }
      
      // If senior auditor (and not coordinator), ensure they can only assign to users in their own group
      // NOTE: This allows self-assignment since the Senior Auditor is in their own group
      if (user.role === 'senior_auditor' && user.groupId) {
        const { isCoordinator } = await import('../services/permissionService');
        const coordinatorCheck = await isCoordinator(user.id);
        
        if (!coordinatorCheck) {
          // Senior Auditor can only assign to users in their own group (including themselves)
          if (targetUser.groupId !== user.groupId) {
            return res.status(403).json({ 
              message: 'شما فقط می‌توانید قضایا را به کاربران گروه خود اختصاص دهید' 
            });
          }
        }
      }
      
      // CRITICAL: Validate that case is in correct status for auditor assignment
      // Assignment to auditor (including senior self-assignment) is ONLY allowed when state = در انتظار بررسی بازرس ارشد
      const { CaseStatus } = await import('@shared/schema');
      if (caseToAssign.status !== CaseStatus.PENDING_SENIOR_REVIEW) {
        return res.status(400).json({ 
          message: `قضیه باید در وضعیت "در انتظار بررسی بازرس ارشد" باشد. وضعیت فعلی: ${caseToAssign.status}` 
        });
      }
      
      // Use state machine for assignment transitions
      const { executeTransition } = await import('../services/caseStateMachine');
      
      // Execute transition using state machine (assign_to_auditor from PENDING_SENIOR_REVIEW)
      // After assignment, state MUST transition to UNDER_REVIEW automatically
      const transitionResult = await executeTransition(req.params.id, user, 'assign_to_auditor', {
        userId: userId,
        notes: `قضیه به بازرس اختصاص داده شد`,
      });
      
      if (!transitionResult.success) {
        return res.status(400).json({ 
          message: transitionResult.errorMessage || 'خطا در اختصاص قضیه به بازرس' 
        });
      }
      
      // Get updated case
      updatedCase = await storage.getCase(req.params.id);
      if (!updatedCase) {
        return res.status(404).json({ message: "قضیه یافت نشد" });
      }
      assignmentType = 'user';
      
      if (!updatedCase) {
        return res.status(404).json({ message: "قضیه یافت نشد" });
      }
      
      // Notify the assigned user
      await storage.createNotification({
        userId,
        message: `قضیه ${updatedCase.caseId} به شما اختصاص داده شد`,
        messagePashto: `قضیه ${updatedCase.caseId} تاسو ته تعیین شوه`,
        type: 'case_assignment',
      });
    }
    
    // Validate that assignment was successful
    if (!assignmentType || !updatedCase) {
      console.error('Assignment failed - missing assignmentType or updatedCase', {
        caseId: req.params.id,
        assignmentType,
        hasUpdatedCase: !!updatedCase,
        userId: req.body?.userId,
        groupId: req.body?.groupId,
      });
      return res.status(500).json({ message: "خطا در اختصاص قضیه - اطلاعات ناقص است" });
    }
    
    // Get user names for audit log
    const seniorName = user.fullName || user.auditId || user.id;
    let auditorName = '';
    if (assignmentType === 'user' && userId) {
      const assignedUser = await storage.getUser(userId);
      auditorName = assignedUser?.fullName || assignedUser?.auditId || userId;
    }
    
    // Log the assignment action with status transition details
    try {
      await storage.createAuditLog({
        userId: user.id,
        action: 'assign_case',
        entityType: 'case',
        entityId: updatedCase.id,
        details: {
          fromStatus: caseToAssign.status,
          toStatus: updatedCase.status,
          oldValue: { 
            assignedTo: caseToAssign.assignedTo,
            assignedAuditor: caseToAssign.assignedAuditor,
            receivingGroup: caseToAssign.receivingGroup,
            status: caseToAssign.status,
          },
          newValue: { 
            assignedTo: assignmentType === 'user' ? userId : caseToAssign.assignedTo,
            assignedAuditor: assignmentType === 'user' ? userId : caseToAssign.assignedAuditor,
            receivingGroup: assignmentType === 'group' ? (groupId || caseToAssign.receivingGroup) : caseToAssign.receivingGroup,
            assignmentType,
            status: updatedCase.status,
          },
          caseId: updatedCase.caseId,
          assignedByRole: user.role,
          assignedBy: seniorName,
          assignedTo: auditorName || (assignmentType === 'group' ? 'Group' : ''),
          assignedAt: new Date().toISOString(),
          note: assignmentType === 'user' 
            ? `Assigned to auditor ${auditorName} by ${seniorName}`
            : `Assigned to group by ${seniorName}`,
        },
        ipAddress: extractClientIp(req),
      });
    } catch (auditError: any) {
      // Log audit error but don't fail the request
      console.error('Failed to create audit log for case assignment:', {
        error: auditError?.message,
        caseId: updatedCase.id,
        userId: user.id,
      });
    }
    
    // Return case with group members if assigned to group, or assigned user info if assigned to user
    // Note: updatedCase is already validated above, so we can safely use it here
    const responseData: any = { ...updatedCase };
    // Use groupId from req.body to ensure it's available (fallback to updatedCase.receivingGroup if needed)
    const responseGroupId = assignmentType === 'group' ? (groupId || updatedCase?.receivingGroup) : null;
    if (assignmentType === 'group' && responseGroupId) {
      try {
        // Get group members for the response
        const groupMembers = await storage.getGroupMembers(responseGroupId);
        const activeMembers = groupMembers.filter(m => m.isActive);
        const activeMembersWithUsers = await Promise.all(
          activeMembers.map(async (member) => {
            try {
              const memberUser = await storage.getUser(member.userId);
              return {
                ...member,
                user: memberUser ? {
                  id: memberUser.id,
                  fullName: memberUser.fullName,
                  auditId: memberUser.auditId,
                  role: memberUser.role,
                } : null,
              };
            } catch (memberError) {
              console.error(`Failed to get user for group member ${member.userId}:`, memberError);
              return {
                ...member,
                user: null,
              };
            }
          })
        );
        responseData.groupMembers = activeMembersWithUsers;
      } catch (groupError: any) {
        console.error('Failed to get group members for response:', {
          error: groupError?.message,
          groupId,
        });
        // Continue without group members in response
        responseData.groupMembers = [];
      }
    } else if (assignmentType === 'user' && updatedCase.assignedTo) {
      try {
        // Include assigned user display name
        const assignedUser = await storage.getUser(updatedCase.assignedTo);
        responseData.assignedUser = assignedUser ? {
          id: assignedUser.id,
          fullName: assignedUser.fullName,
          auditId: assignedUser.auditId,
        } : null;
      } catch (userError: any) {
        console.error('Failed to get assigned user for response:', {
          error: userError?.message,
          userId: updatedCase.assignedTo,
        });
        // Continue without assigned user in response
        responseData.assignedUser = null;
      }
    }
    res.json(responseData);
  } catch (error: any) {
    console.error('Error assigning case:', {
      error: error?.message,
      stack: error?.stack,
      name: error?.name,
      code: error?.code,
      caseId: req.params.id,
      userId: req.body?.userId,
      groupId: req.body?.groupId,
      userRole: (req.user as any)?.role,
      userIdProvided: !!req.body?.userId,
      groupIdProvided: !!req.body?.groupId,
    });
    
    // Provide more detailed error in development
    const errorMessage = process.env.NODE_ENV === 'development' 
      ? `خطا در اختصاص قضیه: ${error?.message || 'خطای نامشخص'}`
      : "خطا در اختصاص قضیه";
    
    res.status(500).json({ 
      message: errorMessage,
      error: process.env.NODE_ENV === 'development' ? {
        message: error?.message,
        name: error?.name,
        code: error?.code,
      } : undefined
    });
  }
});

// Start audit - DEPRECATED: Assignment now automatically transitions to UNDER_REVIEW
// Kept for backward compatibility but returns error
router.post("/:id/start-audit", requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    const caseData = await storage.getCase(req.params.id);
    
    if (!caseData) {
      return res.status(404).json({ message: "قضیه یافت نشد" });
    }
    
    // With new lifecycle, assignment automatically transitions to UNDER_REVIEW
    // This endpoint is no longer needed
    const { CaseStatus } = await import('@shared/schema');
    if (caseData.status === CaseStatus.UNDER_REVIEW || caseData.status === 'در حال بررسی') {
      return res.json(caseData); // Already in review
    }
    
    return res.status(400).json({ 
      message: 'این عملیات دیگر استفاده نمی‌شود. اختصاص قضیه به بازرس به طور خودکار وضعیت را به "در حال بررسی" تغییر می‌دهد.' 
    });
  } catch (error) {
    console.error('Error starting audit:', error);
    res.status(500).json({ message: "خطا در شروع بررسی" });
  }
});

// Update case status (DEPRECATED - Use POST /api/cases/:id/transition instead)
// Kept for backward compatibility, but uses state machine internally
router.patch("/:id/status", requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    const { status } = req.body;
    const currentCase = await storage.getCase(req.params.id);
    
    if (!currentCase) {
      return res.status(404).json({ message: "قضیه یافت نشد" });
    }
    
    // Determine transition name based on status change
    let transitionName: string | null = null;
    const { CaseStatus } = await import('@shared/schema');
    
    // Normalize status strings for comparison (trim whitespace)
    const normalizedCurrentStatus = currentCase.status?.trim();
    const normalizedNewStatus = status?.trim();
    
    // Map status changes to transition names (NEW 6-STATUS LIFECYCLE)
    if (normalizedCurrentStatus === CaseStatus.CREATED && normalizedNewStatus === CaseStatus.PENDING_SENIOR_REVIEW) {
      transitionName = 'assign_to_group';
    } else if (normalizedCurrentStatus === CaseStatus.PENDING_SENIOR_REVIEW && normalizedNewStatus === CaseStatus.UNDER_REVIEW) {
      transitionName = 'assign_to_auditor';
    } else if (normalizedCurrentStatus === CaseStatus.UNDER_REVIEW && normalizedNewStatus === CaseStatus.PENDING_DOCUMENTS) {
      transitionName = 'wait_for_documents';
    } else if (normalizedCurrentStatus === CaseStatus.UNDER_REVIEW && normalizedNewStatus === CaseStatus.SUSPENDED) {
      transitionName = 'suspend';
    } else if (normalizedCurrentStatus === CaseStatus.PENDING_DOCUMENTS && normalizedNewStatus === CaseStatus.UNDER_REVIEW) {
      transitionName = 'resume_review';
    } else if (normalizedCurrentStatus === CaseStatus.SUSPENDED && normalizedNewStatus === CaseStatus.UNDER_REVIEW) {
      transitionName = 'resume_review';
    } else if ((normalizedCurrentStatus === CaseStatus.UNDER_REVIEW || normalizedCurrentStatus === CaseStatus.PENDING_DOCUMENTS || normalizedCurrentStatus === CaseStatus.SUSPENDED) && normalizedNewStatus === CaseStatus.COMPLETED) {
      transitionName = 'complete';
    } else if (normalizedCurrentStatus === CaseStatus.COMPLETED && normalizedNewStatus === CaseStatus.UNDER_REVIEW) {
      transitionName = 'reopen';
    }
    
    // If we can map to a transition, use state machine
    if (transitionName) {
      try {
        const { executeTransition } = await import('../services/caseStateMachine');
        const result = await executeTransition(req.params.id, user, transitionName as any, {
          ipAddress: extractClientIp(req),
          rejectionReason: req.body.rejectionReason,
        });
        
        if (!result.success) {
          return res.status(400).json({ 
            message: result.errorMessage || "انتقال وضعیت مجاز نیست" 
          });
        }
        
        const updatedCase = await storage.getCase(req.params.id);
        return res.json(updatedCase);
      } catch (error: any) {
        console.error('[STATUS UPDATE] Error executing transition:', {
          error: error.message,
          stack: error.stack,
          caseId: req.params.id,
          currentStatus: currentCase.status,
          newStatus: status,
          transitionName,
          userId: user.id,
          userRole: user.role,
        });
        return res.status(500).json({ 
          message: error.message || "خطا در بروزرسانی وضعیت قضیه" 
        });
      }
    }
    
    // Fallback to old behavior for unmapped transitions (with warning)
    console.warn(`[DEPRECATED] PATCH /api/cases/:id/status used with unmapped transition: ${currentCase.status} -> ${status}. Use POST /api/cases/:id/transition instead.`);
    
    // Old validation logic (kept for backward compatibility)
    // Only allow the 6 new statuses
    // CaseStatus is already imported above at line 1137
    const validStatuses = [
      CaseStatus.CREATED,
      CaseStatus.PENDING_SENIOR_REVIEW,
      CaseStatus.UNDER_REVIEW,
      CaseStatus.PENDING_DOCUMENTS,
      CaseStatus.SUSPENDED,
      CaseStatus.COMPLETED,
      'ایجاد شده',
      'در انتظار بررسی بازرس ارشد', // Must match CaseStatus.PENDING_SENIOR_REVIEW
      'در حال بررسی',
      'در انتظار تکمیل مدارک',
      'تعلیق شده',
      'تکمیل شده',
    ];
    if (!validStatuses.includes(status)) {
      return res.status(400).json({ message: "وضعیت نامعتبر است" });
    }
    
    // Prevent status changes for completed cases
    if (currentCase.status === CaseStatus.COMPLETED || currentCase.status === 'تکمیل شده') {
      return res.status(400).json({ 
        message: "نمی توان وضعیت قضیه تکمیل شده را تغییر داد" 
      });
    }
    
    if (status === 'تکمیل شده' && currentCase.status !== 'تکمیل شده') {
      const { validateCaseReportCompletion, canOverrideValidation } = await import('../services/reportValidationService');
      const allowOverride = await canOverrideValidation(user);
      const validation = await validateCaseReportCompletion(currentCase, allowOverride);
      
      if (!validation.isValid) {
        return res.status(400).json({ 
          message: validation.errorMessage || "گزارش تکمیل نشده است. لطفاً تمام معلومات لازم گزارش را درج نمایید.",
          missingFields: validation.missingFields,
          canOverride: allowOverride
        });
      }
    }
    
    const updatedCase = await storage.updateCaseStatus(req.params.id, status);
    
    if (!updatedCase) {
      return res.status(404).json({ message: "قضیه یافت نشد" });
    }
    
    await storage.createAuditLog({
      userId: user.id,
      action: 'update_case_status',
      entityType: 'case',
      entityId: updatedCase.id,
      details: {
        oldValue: { status: currentCase.status },
        newValue: { status },
        deprecated: true,
        message: 'This endpoint is deprecated. Use POST /api/cases/:id/transition instead.',
      },
      ipAddress: extractClientIp(req),
    });
    
    res.json(updatedCase);
  } catch (error: any) {
    console.error('[STATUS UPDATE] Unexpected error:', {
      error: error.message,
      stack: error.stack,
      caseId: req.params.id,
      userId: (req.user as any)?.id,
    });
    res.status(500).json({ message: "خطا در بروزرسانی وضعیت قضیه" });
  }
});

// Complete case (DEPRECATED - Use POST /api/cases/:id/transition with transition='complete' instead)
// Kept for backward compatibility, but uses state machine internally
router.post("/:id/complete", requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    const currentCase = await storage.getCase(req.params.id);
    
    if (!currentCase) {
      return res.status(404).json({ message: "قضیه یافت نشد" });
    }
    
    // Check if user has cases:complete permission
    const hasCompletePermission = await userHasPermission(user, 'cases:complete');
    if (!hasCompletePermission && user.role !== 'system_admin') {
      return res.status(403).json({ message: 'عدم دسترسی - شما مجوز تکمیل قضیه را ندارید' });
    }
    
    // System admin can complete any case
    if (user.role !== 'system_admin') {
      // Use unified permission helper
      const { getCaseVisibility } = await import('../utils/permissionHelpers');
      const { isCoordinator } = await import('../services/permissionService');
      const visibility = await getCaseVisibility(user);
      const coordinatorCheck = await isCoordinator(user.id);
      
      // Coordinator can complete any case
      if (coordinatorCheck || visibility.canViewAll) {
        // Access granted, continue
      } else if (visibility.filterByAssignee) {
        // Auditor: Can only complete their assigned cases
        if (currentCase.assignedTo !== user.id) {
          return res.status(403).json({ 
            message: 'شما فقط می‌توانید قضایای اختصاص داده شده به خود را تکمیل کنید' 
          });
        }
      } else if (visibility.filterByGroup) {
        // Senior auditor: Can only complete cases from their group
        if (currentCase.receivingGroup !== visibility.filterByGroup) {
          return res.status(403).json({ 
            message: 'شما فقط می‌توانید قضایای گروه خود را تکمیل کنید' 
          });
        }
      } else {
        // No access
        return res.status(403).json({ message: 'عدم دسترسی' });
      }
    }
    
    // Use state machine to execute transition
    const { executeTransition } = await import('../services/caseStateMachine');
    const result = await executeTransition(req.params.id, user, 'complete', {
      ipAddress: extractClientIp(req),
    });
    
    if (!result.success) {
      // Get validation details for error response
      const { validateCaseReportCompletion, canOverrideValidation } = await import('../services/reportValidationService');
      const allowOverride = await canOverrideValidation(user);
      const validation = await validateCaseReportCompletion(currentCase, allowOverride);
      
      return res.status(400).json({ 
        message: result.errorMessage || validation.errorMessage || "گزارش تکمیل نشده است. لطفاً تمام معلومات لازم گزارش را درج نمایید.",
        missingFields: validation.missingFields,
        canOverride: allowOverride
      });
    }
    
    // Get updated case
    const updatedCase = await storage.getCase(req.params.id);
    if (!updatedCase) {
      return res.status(404).json({ message: "قضیه یافت نشد" });
    }
    
    // Update entity status if all cases are completed (special logic for complete endpoint)
    const { db } = await import('../db');
    const { cases: casesTable, entities: entitiesTable } = await import('@shared/schema');
    const { eq } = await import('drizzle-orm');
    
    let updatedEntity: Entity | undefined;
    
    await db.transaction(async (tx) => {
      // Get all cases for this entity
      const entityCases = await tx
        .select()
        .from(casesTable)
        .where(eq(casesTable.entityId, currentCase.entityId));
      
      // Check if all cases for this entity are completed
      const allCasesCompleted = entityCases.every(
        c => c.status === 'تکمیل شده' || c.status === 'تایید شده' || c.status === 'رد شده'
      );
      
      // Update entity status if all cases are completed
      if (allCasesCompleted) {
        const [entityResult] = await tx
          .update(entitiesTable)
          .set({ status: 'COMPLETED' })
          .where(eq(entitiesTable.id, currentCase.entityId))
          .returning();
        
        updatedEntity = entityResult;
      }
    });
    
    // Determine the role that completed the case (in Persian)
    const completedByRole = user.role === 'senior_auditor' ? 'مدیر عمومی گروه' : 
                           user.role === 'auditor' ? 'بررس' : 
                           user.role === 'system_admin' ? 'مدیر سیستم' : 'نامشخص';
    
    // Notify the assigned auditor if case was completed by someone else
    if (currentCase.assignedTo && currentCase.assignedTo !== user.id) {
      await storage.createNotification({
        userId: currentCase.assignedTo,
        message: `قضیه ${updatedCase.caseId} توسط ${completedByRole} تکمیل شد`,
        messagePashto: `قضیه ${updatedCase.caseId} د ${completedByRole} لخوا بشپړه شوه`,
        type: 'case_completion',
      });
    }
    
    // Notify senior auditor if case was completed by an auditor in their audit group
    if (user.role === 'auditor' && currentCase.receivingGroup) {
      try {
        const groupUsers = await storage.getUsers();
        const seniorAuditor = groupUsers.find(
          u => u.role === 'senior_auditor' && u.groupId === currentCase.receivingGroup
        );
        
        if (seniorAuditor && seniorAuditor.id !== user.id) {
          await storage.createNotification({
            userId: seniorAuditor.id,
            message: `قضیه ${updatedCase.caseId} توسط بررس تکمیل شد`,
            messagePashto: `قضیه ${updatedCase.caseId} د بررس لخوا بشپړه شوه`,
            type: 'case_completion',
          });
        }
      } catch (error) {
        console.error('Error notifying senior auditor:', error);
      }
    }
    
    
    // Return case with entity update status
    res.json({
      ...updatedCase,
      entityStatusUpdated: !!updatedEntity,
    });
  } catch (error) {
    console.error('Error completing case:', error);
    res.status(500).json({ message: "خطا در تکمیل قضیه" });
  }
});

// Approve case (DEPRECATED - Use POST /api/cases/:id/transition with transition='approve' instead)
// Kept for backward compatibility, but uses state machine internally
router.post("/:id/approve", requireAuth, requirePermission('tickets:approve'), async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    const currentCase = await storage.getCase(req.params.id);
    
    if (!currentCase) {
      return res.status(404).json({ message: "قضیه یافت نشد" });
    }
    
    // Use state machine to execute transition
    const { executeTransition } = await import('../services/caseStateMachine');
    const result = await executeTransition(req.params.id, user, 'approve', {
      ipAddress: extractClientIp(req),
    });
    
    if (!result.success) {
      return res.status(400).json({ 
        message: result.errorMessage || "فقط قضایای تکمیل شده می توانند تایید شوند" 
      });
    }
    
    const updatedCase = await storage.getCase(req.params.id);
    if (!updatedCase) {
      return res.status(404).json({ message: "قضیه یافت نشد" });
    }
    
    // Notify case creator
    if (currentCase.assignedTo) {
      await storage.createNotification({
        userId: currentCase.assignedTo,
        message: `قضیه ${updatedCase.caseId} تایید شد`,
        messagePashto: `قضیه ${updatedCase.caseId} تصدیق شوه`,
        type: 'case_approval',
      });
    }
    
    res.json(updatedCase);
  } catch (error) {
    console.error('Error approving case:', error);
    res.status(500).json({ message: "خطا در تایید قضیه" });
  }
});

// Reject case (DEPRECATED - Use POST /api/cases/:id/transition with transition='reject' instead)
// Kept for backward compatibility, but uses state machine internally
router.post("/:id/reject", requireAuth, requirePermission('tickets:approve'), async (req: Request, res: Response) => {
  try {
    const { rejectionReason } = req.body;
    const user = req.user as any;
    
    if (!rejectionReason) {
      return res.status(400).json({ message: "دلیل رد الزامی است" });
    }
    
    const currentCase = await storage.getCase(req.params.id);
    
    if (!currentCase) {
      return res.status(404).json({ message: "قضیه یافت نشد" });
    }
    
    // Use state machine to execute transition
    const { executeTransition } = await import('../services/caseStateMachine');
    const result = await executeTransition(req.params.id, user, 'reject', {
      rejectionReason,
      ipAddress: extractClientIp(req),
    });
    
    if (!result.success) {
      return res.status(400).json({ 
        message: result.errorMessage || "فقط قضایای تکمیل شده می توانند رد شوند" 
      });
    }
    
    const updatedCase = await storage.getCase(req.params.id);
    if (!updatedCase) {
      return res.status(404).json({ message: "قضیه یافت نشد" });
    }
    
    // Notify case creator
    if (currentCase.assignedTo) {
      await storage.createNotification({
        userId: currentCase.assignedTo,
        message: `قضیه ${updatedCase.caseId} رد شد. دلیل: ${rejectionReason}`,
        messagePashto: `قضیه ${updatedCase.caseId} رد شوه. دلیل: ${rejectionReason}`,
        type: 'case_rejection',
      });
    }
    
    res.json(updatedCase);
  } catch (error) {
    console.error('Error rejecting case:', error);
    res.status(500).json({ message: "خطا در رد قضیه" });
  }
});

// Get required fields schema for report V2 (Suggestion C - Dynamic field sync)
// CRITICAL: This route MUST be defined BEFORE any /:id routes to avoid route conflicts
// Express matches routes in order, so /schema must come before /:id
router.get("/schema/report/v2", requireAuth, async (req: Request, res: Response) => {
  try {
    // Return the current active form schema with required fields
    const schema = {
      sections: {
        section_1: {
          name: 'مشخصات نهاد',
          requiredFields: [
            'companyName',
            'tin',
            'businessNature',
            'groupReferrer',
            'referralDate',
            'periodsUnderReview',
          ],
          optionalFields: [
            'finalDocumentDate',
            'capitalPeriod',
            'province',
            'district',
            'streetAddress',
            'postalCode',
            'phone',
            'email',
            'registrationNumber',
            'registrationDate',
            'businessLicenseNumber',
            'businessLicenseDate',
            'taxOffice',
            'taxOfficeCode',
            'taxRegistrationDate',
          ],
        },
        section_2: {
          name: 'بیرون‌نویسی‌ها',
          requiredFields: [
            'salaryTax',
            'rentTax',
            'contractTax',
            'profitTransactionTax',
            'incomeTax',
            'withholdingTax',
            'penaltyTax',
            'interest',
            'otherTaxes',
            'reducedLoss',
            'reducedRemainingAmount',
            'confirmedAmount',
            'collectedCurrentMonth',
            'remainingCollectible',
            'activityStatus',
            'attachmentNumber',
            'attachmentDate',
            'finalDocumentDate',
          ],
          optionalFields: [
            'taxBase',
            'taxRate',
            'calculationMethod',
            'paymentMethod',
            'paymentReferenceNumber',
            'paymentDate',
            'bankName',
            'bankAccountNumber',
            'bankBranch',
          ],
        },
        section_5: {
          name: 'تایید و آپلود اسناد',
          requiredFields: [
            'preparedBy', // Auto-set
          ],
          optionalFields: [
            'reviewedBy',
            'reviewedAt',
            'reviewedByRole',
            'reviewNotes',
            'approvedBy',
            'approvedAt',
            'approvedByRole',
          ],
        },
      },
      deprecatedSections: ['section_3', 'section_4'],
      version: '2.0',
    };

    res.json(schema);
  } catch (error) {
    console.error('Error fetching report schema:', error);
    res.status(500).json({ message: "خطا در دریافت ساختار گزارش" });
  }
});

// Get case report (for case completion form)
router.get("/:id/report", requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    const caseData = await storage.getCase(req.params.id);
    
    if (!caseData) {
      return res.status(404).json({ message: "قضیه یافت نشد" });
    }

    // RBAC: Check if user can view this case
    const { getCaseVisibility } = await import('../utils/permissionHelpers');
    const visibility = await getCaseVisibility(user);

    if (user.role !== 'system_admin') {
      const { getEffectivePermissions } = await import('../services/permissionService');
      const effectivePermissions = await getEffectivePermissions(user.id);
      
      if (!effectivePermissions['cases:view']) {
        return res.status(403).json({ message: 'عدم دسترسی - شما مجوز لازم را ندارید' });
      }
      
      if (visibility.canViewAll) {
        // Access granted
      } else if (visibility.filterByAssignee) {
        if (caseData.assignedTo !== user.id) {
          return res.status(403).json({ message: 'عدم دسترسی' });
        }
      } else if (visibility.filterByGroup) {
        if (caseData.receivingGroup !== visibility.filterByGroup) {
          return res.status(403).json({ message: 'عدم دسترسی' });
        }
      } else {
        return res.status(403).json({ message: 'عدم دسترسی' });
      }
    }

    // Get existing report or return empty structure
    const report = await storage.getCaseReport(req.params.id);
    
    // Get entity for auto-population
    const entity = await storage.getEntity(caseData.entityId);
    
    // Get final document date
    // Get final document date from documents
    // Note: docDate is stored as Shamsi date string (DD-MM-YYYY), not Gregorian
    // We'll sort by string comparison for Shamsi dates (YYYY-MM-DD format for proper sorting)
    const documents = await storage.getDocuments(req.params.id);
    const finalDoc = documents
      .filter(d => d.isFinal && !d.isRevoked)
      .sort((a, b) => {
        // Convert DD-MM-YYYY to YYYY-MM-DD for proper string sorting
        const convertForSort = (dateStr: string) => {
          if (!dateStr) return '0000-00-00';
          const parts = dateStr.split('-');
          if (parts.length === 3) {
            return `${parts[2]}-${parts[1]}-${parts[0]}`; // YYYY-MM-DD
          }
          return dateStr;
        };
        return convertForSort(b.docDate || '').localeCompare(convertForSort(a.docDate || ''));
      })[0];

    // Build response with auto-populated data
    const response: any = {
      // Section 1: Entity Details (auto-populated from case/entity)
      companyName: caseData.companyName || entity?.companyName || '',
      tin: caseData.tin || entity?.tin || '',
      businessNature: caseData.businessNature || entity?.businessNature || '',
      groupReferrer: caseData.groupReferrer || entity?.referralGroup || '',
      referralDate: caseData.referralDate || '',
      periodsUnderReview: caseData.periodsUnderReview || entity?.periodsUnderReview || '',
      finalDocumentDate: report?.finalDocumentDate || finalDoc?.docDate || '',
      capitalPeriod: report?.capitalPeriod || '',
      
      // Section 2: Extractions
      salaryTax: report?.salaryTax || '',
      rentTax: report?.rentTax || '',
      contractTax: report?.contractTax || '',
      profitTransactionTax: report?.profitTransactionTax || '',
      incomeTax: report?.incomeTax || '',
      reducedLoss: report?.reducedLoss || '',
      reducedRemainingAmount: report?.reducedRemainingAmount || '',
      confirmedAmount: report?.confirmedAmount || '',
      collectedCurrentMonth: report?.collectedCurrentMonth || '',
      remainingCollectible: report?.remainingCollectible || '',
      activityStatus: report?.activityStatus || '',
      attachmentNumber: report?.attachmentNumber || caseData.transactionId || '',
      attachmentDate: report?.attachmentDate || '',
      
      // Additional read-only fields from entity (for final report view)
      contactPerson: entity?.contactPerson || '', // نماینده
      phone: entity?.phone || '', // شماره تماس نماینده
      registeredAddress: entity?.registeredAddress || '', // آدرس نهاد
    };

    res.json(response);
  } catch (error) {
    console.error('Error fetching case report:', error);
    res.status(500).json({ message: "خطا در دریافت گزارش قضیه" });
  }
});

// Save case report (before completion)
router.post("/:id/report", requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    const caseData = await storage.getCase(req.params.id);
    
    if (!caseData) {
      return res.status(404).json({ message: "قضیه یافت نشد" });
    }

    // RBAC: Check if user can edit this case
    const { getCaseVisibility } = await import('../utils/permissionHelpers');
    const visibility = await getCaseVisibility(user);

    if (user.role !== 'system_admin') {
      const { getEffectivePermissions } = await import('../services/permissionService');
      const effectivePermissions = await getEffectivePermissions(user.id);
      
      if (!effectivePermissions['cases:complete']) {
        return res.status(403).json({ message: 'عدم دسترسی - شما مجوز تکمیل قضیه را ندارید' });
      }
      
      if (visibility.canViewAll) {
        // Access granted
      } else if (visibility.filterByAssignee) {
        if (caseData.assignedTo !== user.id) {
          return res.status(403).json({ message: 'عدم دسترسی' });
        }
      } else if (visibility.filterByGroup) {
        if (caseData.receivingGroup !== visibility.filterByGroup) {
          return res.status(403).json({ message: 'عدم دسترسی' });
        }
      } else {
        return res.status(403).json({ message: 'عدم دسترسی' });
      }
    }

    // Prevent editing reports for completed cases
    const { CaseStatus } = await import('@shared/schema');
    if (caseData.status === CaseStatus.COMPLETED || caseData.status === 'تکمیل شده') {
      return res.status(400).json({ 
        message: "نمی‌توان گزارش قضیه تکمیل شده را ویرایش کرد" 
      });
    }

    // Extract report data from request
    const reportData = {
      caseId: req.params.id,
      finalDocumentDate: req.body.finalDocumentDate || null,
      capitalPeriod: req.body.capitalPeriod || null,
      salaryTax: req.body.salaryTax || null,
      rentTax: req.body.rentTax || null,
      contractTax: req.body.contractTax || null,
      profitTransactionTax: req.body.profitTransactionTax || null,
      incomeTax: req.body.incomeTax || null,
      reducedLoss: req.body.reducedLoss || null,
      reducedRemainingAmount: req.body.reducedRemainingAmount || null,
      confirmedAmount: req.body.confirmedAmount || null,
      collectedCurrentMonth: req.body.collectedCurrentMonth || null,
      remainingCollectible: req.body.remainingCollectible || null,
      activityStatus: req.body.activityStatus || null,
      attachmentNumber: req.body.attachmentNumber || null,
      attachmentDate: req.body.attachmentDate || null,
    };

    // Upsert report
    const report = await storage.upsertCaseReport(reportData);

    // PHASE 1: Payment Traceability - Create Payment record if collectedCurrentMonth > 0
    if (report.collectedCurrentMonth) {
      const collectedAmount = typeof report.collectedCurrentMonth === 'string' 
        ? parseFloat(report.collectedCurrentMonth.replace(/,/g, '')) || 0
        : (typeof report.collectedCurrentMonth === 'number' ? report.collectedCurrentMonth : 0);
      
      if (collectedAmount > 0) {
        try {
          // Parse payment date from report or use current date
          let paymentDate: Date = new Date();
          if (req.body.paymentDate) {
            const { parseDateString } = await import('../utils/shamsiDate');
            const { date: parsedDate } = parseDateString(req.body.paymentDate);
            if (parsedDate) {
              paymentDate = parsedDate;
            }
          }
          
          await storage.createPayment({
            caseId: req.params.id,
            paymentDate: paymentDate,
            paymentAmount: collectedAmount.toString(),
            paymentType: 'normal',
          });
        } catch (paymentError) {
          // Log but don't fail the request if payment creation fails
          console.warn('[PAYMENT TRACEABILITY] Failed to create payment record:', paymentError);
        }
      }
    }

    // Update case transactionId if attachmentNumber is provided
    if (req.body.attachmentNumber) {
      await storage.updateCase(req.params.id, {
        transactionId: req.body.attachmentNumber,
      });
    }

    await storage.createAuditLog({
      userId: user.id,
      action: 'save_case_report',
      entityType: 'case',
      entityId: caseData.id,
      details: {
        caseId: caseData.caseId,
        reportSaved: true,
      },
      ipAddress: extractClientIp(req),
    });

    res.json(report);
  } catch (error) {
    console.error('Error saving case report:', error);
    res.status(500).json({ message: "خطا در ذخیره گزارش قضیه" });
  }
});

// Get case report V2 (structured)
router.get("/:id/report/v2", requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    const caseData = await storage.getCase(req.params.id);
    
    if (!caseData) {
      return res.status(404).json({ message: "قضیه یافت نشد" });
    }

    // RBAC: Check if user can view this case
    const { getCaseVisibility } = await import('../utils/permissionHelpers');
    const visibility = await getCaseVisibility(user);

    if (user.role !== 'system_admin') {
      const { getEffectivePermissions } = await import('../services/permissionService');
      const effectivePermissions = await getEffectivePermissions(user.id);
      
      if (!effectivePermissions['cases:view']) {
        return res.status(403).json({ message: 'عدم دسترسی - شما مجوز لازم را ندارید' });
      }
      
      if (visibility.canViewAll) {
        // Access granted
      } else if (visibility.filterByAssignee) {
        if (caseData.assignedTo !== user.id) {
          return res.status(403).json({ message: 'عدم دسترسی' });
        }
      } else if (visibility.filterByGroup) {
        if (caseData.receivingGroup !== visibility.filterByGroup) {
          return res.status(403).json({ message: 'عدم دسترسی' });
        }
      } else {
        return res.status(403).json({ message: 'عدم دسترسی' });
      }
    }

    // Get existing report or create empty structure
    let report = await storage.getCaseReportV2(req.params.id);
    
    // Get entity for auto-population
    const entity = await storage.getEntity(caseData.entityId);
    
    // Get final document date from documents
    // Note: docDate is stored as Shamsi date string (DD-MM-YYYY), not Gregorian
    // We'll sort by string comparison for Shamsi dates (YYYY-MM-DD format for proper sorting)
    const documents = await storage.getDocuments(req.params.id);
    const finalDoc = documents
      .filter(d => d.isFinal && !d.isRevoked)
      .sort((a, b) => {
        // Convert DD-MM-YYYY to YYYY-MM-DD for proper string sorting
        const convertForSort = (dateStr: string) => {
          if (!dateStr) return '0000-00-00';
          const parts = dateStr.split('-');
          if (parts.length === 3) {
            return `${parts[2]}-${parts[1]}-${parts[0]}`; // YYYY-MM-DD
          }
          return dateStr;
        };
        return convertForSort(b.docDate || '').localeCompare(convertForSort(a.docDate || ''));
      })[0];

    // If report doesn't exist, return structure with auto-populated data
    if (!report) {
      const response: any = {
        caseId: req.params.id,
        status: 'draft',
        version: 1,
        // Section 1: Auto-populated
        companyName: caseData.companyName || entity?.companyName || '',
        tin: caseData.tin || entity?.tin || '',
        businessNature: caseData.businessNature || entity?.businessNature || '',
        groupReferrer: caseData.groupReferrer || entity?.referralGroup || '',
        referralDate: caseData.referralDate || '',
        periodsUnderReview: caseData.periodsUnderReview || entity?.periodsUnderReview || '',
        finalDocumentDate: finalDoc?.docDate || '',
        capitalPeriod: '',
        // Additional entity fields for report (read-only)
        representative: entity?.contactPerson || '',
        representativeContactNumber: entity?.phone || '',
        entityAddress: entity?.registeredAddress || '',
        // Section 2: Defaults to 0
        salaryTax: 0,
        rentTax: 0,
        contractTax: 0,
        profitTransactionTax: 0,
        incomeTax: 0,
        withholdingTax: 0,
        penaltyTax: 0,
        interest: 0,
        otherTaxes: 0,
        reducedLoss: 0,
        reducedRemainingAmount: 0,
        confirmedAmount: 0,
        collectedCurrentMonth: 0,
        remainingCollectible: 0,
        activityStatus: '',
        attachmentNumber: caseData.transactionId || '',
        attachmentDate: '',
        // Section 3: Empty
        findingsSummary: '',
        detailedFindings: '',
        riskAssessment: '',
        recommendations: '',
        actionItems: '',
        followUpRequired: false,
        followUpDate: '',
        // Section 4: Empty arrays
        documentsReviewed: [],
        documentsAttached: [],
        missingDocuments: '',
        documentReviewDate: '',
        documentReviewNotes: '',
      };
      return res.json(response);
    }

    // Enrich existing report with entity data if not already present
    const enrichedReport = {
      ...report,
      representative: report.representative || entity?.contactPerson || '',
      representativeContactNumber: report.representativeContactNumber || entity?.phone || '',
      entityAddress: report.entityAddress || entity?.registeredAddress || '',
    };
    
    // Return existing report with entity data
    res.json(enrichedReport);
  } catch (error) {
    console.error('Error fetching case report v2:', error);
    res.status(500).json({ message: "خطا در دریافت گزارش قضیه" });
  }
});

// Save case report V2 draft (autosave)
router.post("/:id/report/v2/draft", requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    const caseData = await storage.getCase(req.params.id);
    
    if (!caseData) {
      return res.status(404).json({ message: "قضیه یافت نشد" });
    }

    // RBAC: Check if user can edit this case
    // For draft saves, allow users with cases:view permission (less restrictive)
    // Only require cases:complete for final completion
    const { getCaseVisibility } = await import('../utils/permissionHelpers');
    const visibility = await getCaseVisibility(user);

    if (user.role !== 'system_admin') {
      const { getEffectivePermissions } = await import('../services/permissionService');
      const effectivePermissions = await getEffectivePermissions(user.id);
      
      // Allow draft saves with cases:view permission (auditors can save reports for assigned cases)
      const canView = effectivePermissions['cases:view'];
      const canComplete = effectivePermissions['cases:complete'];
      
      if (!canView && !canComplete) {
        return res.status(403).json({ message: 'عدم دسترسی - شما مجوز لازم را ندارید' });
      }
      
      if (visibility.canViewAll) {
        // Access granted (coordinator, director, admin)
      } else if (visibility.filterByAssignee) {
        // Auditor: Must be assigned to this case (check both assignedTo and assignedAuditor)
        if (caseData.assignedTo !== user.id && caseData.assignedAuditor !== user.id) {
          return res.status(403).json({ message: 'عدم دسترسی - شما فقط می‌توانید گزارش قضایای اختصاص داده شده به خود را ویرایش کنید' });
        }
      } else if (visibility.filterByGroup) {
        // Senior auditor: Case must belong to their group
        if (caseData.receivingGroup !== visibility.filterByGroup) {
          return res.status(403).json({ message: 'عدم دسترسی - شما فقط می‌توانید گزارش قضایای گروه خود را ویرایش کنید' });
        }
      } else {
        return res.status(403).json({ message: 'عدم دسترسی' });
      }
    }

    // Check if report is locked (but allow editing of completed reports)
    const existingReport = await storage.getCaseReportV2(req.params.id);
    if (existingReport?.status === 'locked') {
      return res.status(400).json({ 
        message: "گزارش قفل شده است و نمی‌توان آن را ویرایش کرد" 
      });
    }
    
    // Allow editing completed reports (but not locked ones)
    // Completed reports can be edited by authorized users to fix errors

    // Get entity for auto-population
    const entity = await storage.getEntity(caseData.entityId);

    // Prepare report data
    const reportData: any = {
      caseId: req.params.id,
      status: existingReport?.status || 'draft',
      // Section 1: Auto-populate basic fields if not provided
      companyName: req.body.companyName || caseData.companyName || entity?.companyName || '',
      tin: req.body.tin || caseData.tin || entity?.tin || '',
      businessNature: req.body.businessNature || caseData.businessNature || entity?.businessNature || '',
      groupReferrer: req.body.groupReferrer || caseData.groupReferrer || entity?.referralGroup || '',
      referralDate: req.body.referralDate || caseData.referralDate || '',
      periodsUnderReview: req.body.periodsUnderReview || caseData.periodsUnderReview || entity?.periodsUnderReview || '',
      // Allow partial updates - only update provided fields
      ...(req.body.finalDocumentDate !== undefined && { finalDocumentDate: req.body.finalDocumentDate }),
      ...(req.body.capitalPeriod !== undefined && { capitalPeriod: req.body.capitalPeriod }),
      // Address
      ...(req.body.province !== undefined && { province: req.body.province }),
      ...(req.body.district !== undefined && { district: req.body.district }),
      ...(req.body.streetAddress !== undefined && { streetAddress: req.body.streetAddress }),
      ...(req.body.postalCode !== undefined && { postalCode: req.body.postalCode }),
      ...(req.body.phone !== undefined && { phone: req.body.phone }),
      ...(req.body.email !== undefined && { email: req.body.email }),
      // Registration
      ...(req.body.registrationNumber !== undefined && { registrationNumber: req.body.registrationNumber }),
      ...(req.body.registrationDate !== undefined && { registrationDate: req.body.registrationDate }),
      ...(req.body.businessLicenseNumber !== undefined && { businessLicenseNumber: req.body.businessLicenseNumber }),
      ...(req.body.businessLicenseDate !== undefined && { businessLicenseDate: req.body.businessLicenseDate }),
      // Tax
      ...(req.body.taxOffice !== undefined && { taxOffice: req.body.taxOffice }),
      ...(req.body.taxRegistrationDate !== undefined && { taxRegistrationDate: req.body.taxRegistrationDate }),
      ...(req.body.taxOfficeCode !== undefined && { taxOfficeCode: req.body.taxOfficeCode }),
      // Section 2: Tax types (convert strings to numbers)
      // ALWAYS include these fields for calculation - required fields must be numbers (0 is valid)
      salaryTax: req.body.salaryTax !== undefined
        ? (typeof req.body.salaryTax === 'string'
          ? (req.body.salaryTax === '' ? 0 : (isNaN(parseFloat(req.body.salaryTax)) ? 0 : parseFloat(req.body.salaryTax)))
          : (req.body.salaryTax === null ? 0 : (typeof req.body.salaryTax === 'number' ? req.body.salaryTax : 0)))
        : (existingReport?.salaryTax ?? 0),
      rentTax: req.body.rentTax !== undefined
        ? (typeof req.body.rentTax === 'string'
          ? (req.body.rentTax === '' ? 0 : (isNaN(parseFloat(req.body.rentTax)) ? 0 : parseFloat(req.body.rentTax)))
          : (req.body.rentTax === null ? 0 : (typeof req.body.rentTax === 'number' ? req.body.rentTax : 0)))
        : (existingReport?.rentTax ?? 0),
      contractTax: req.body.contractTax !== undefined
        ? (typeof req.body.contractTax === 'string'
          ? (req.body.contractTax === '' ? 0 : (isNaN(parseFloat(req.body.contractTax)) ? 0 : parseFloat(req.body.contractTax)))
          : (req.body.contractTax === null ? 0 : (typeof req.body.contractTax === 'number' ? req.body.contractTax : 0)))
        : (existingReport?.contractTax ?? 0),
      // ALWAYS include these fields for calculation - required fields must be numbers (0 is valid)
      // These fields are critical and must always be present, even if 0
      profitTransactionTax: req.body.profitTransactionTax !== undefined 
        ? (typeof req.body.profitTransactionTax === 'string' 
          ? (req.body.profitTransactionTax === '' ? 0 : (isNaN(parseFloat(req.body.profitTransactionTax)) ? 0 : parseFloat(req.body.profitTransactionTax))) 
          : (req.body.profitTransactionTax === null ? 0 : (typeof req.body.profitTransactionTax === 'number' ? req.body.profitTransactionTax : 0)))
        : (existingReport?.profitTransactionTax ?? 0),
      incomeTax: req.body.incomeTax !== undefined 
        ? (typeof req.body.incomeTax === 'string' 
          ? (req.body.incomeTax === '' ? 0 : (isNaN(parseFloat(req.body.incomeTax)) ? 0 : parseFloat(req.body.incomeTax))) 
          : (req.body.incomeTax === null ? 0 : (typeof req.body.incomeTax === 'number' ? req.body.incomeTax : 0)))
        : (existingReport?.incomeTax ?? 0),
      ...(req.body.withholdingTax !== undefined && { withholdingTax: typeof req.body.withholdingTax === 'string' ? parseFloat(req.body.withholdingTax) || 0 : req.body.withholdingTax }),
      ...(req.body.penaltyTax !== undefined && { penaltyTax: typeof req.body.penaltyTax === 'string' ? parseFloat(req.body.penaltyTax) || 0 : req.body.penaltyTax }),
      ...(req.body.interest !== undefined && { interest: typeof req.body.interest === 'string' ? parseFloat(req.body.interest) || 0 : req.body.interest }),
      ...(req.body.otherTaxes !== undefined && { otherTaxes: typeof req.body.otherTaxes === 'string' ? parseFloat(req.body.otherTaxes) || 0 : req.body.otherTaxes }),
      // Financial
      ...(req.body.reducedLoss !== undefined && { reducedLoss: typeof req.body.reducedLoss === 'string' ? parseFloat(req.body.reducedLoss) || 0 : req.body.reducedLoss }),
      ...(req.body.reducedRemainingAmount !== undefined && { reducedRemainingAmount: typeof req.body.reducedRemainingAmount === 'string' ? parseFloat(req.body.reducedRemainingAmount) || 0 : req.body.reducedRemainingAmount }),
      ...(req.body.confirmedAmount !== undefined && { confirmedAmount: typeof req.body.confirmedAmount === 'string' ? parseFloat(req.body.confirmedAmount) || 0 : req.body.confirmedAmount }),
      // ALWAYS include this field for calculation - required field must be a number (0 is valid)
      // This field is critical and must always be present, even if 0
      collectedCurrentMonth: req.body.collectedCurrentMonth !== undefined 
        ? (typeof req.body.collectedCurrentMonth === 'string' 
          ? (req.body.collectedCurrentMonth === '' ? 0 : (isNaN(parseFloat(req.body.collectedCurrentMonth)) ? 0 : parseFloat(req.body.collectedCurrentMonth))) 
          : (req.body.collectedCurrentMonth === null ? 0 : (typeof req.body.collectedCurrentMonth === 'number' ? req.body.collectedCurrentMonth : 0)))
        : (existingReport?.collectedCurrentMonth ?? 0),
      ...(req.body.remainingCollectible !== undefined && { remainingCollectible: typeof req.body.remainingCollectible === 'string' ? parseFloat(req.body.remainingCollectible) || 0 : req.body.remainingCollectible }),
      // Calculation
      ...(req.body.taxBase !== undefined && { taxBase: typeof req.body.taxBase === 'string' ? parseFloat(req.body.taxBase) : req.body.taxBase }),
      ...(req.body.taxRate !== undefined && { taxRate: typeof req.body.taxRate === 'string' ? parseFloat(req.body.taxRate) : req.body.taxRate }),
      ...(req.body.calculationMethod !== undefined && { calculationMethod: req.body.calculationMethod }),
      // Payment
      ...(req.body.paymentMethod !== undefined && { paymentMethod: req.body.paymentMethod }),
      ...(req.body.paymentReferenceNumber !== undefined && { paymentReferenceNumber: req.body.paymentReferenceNumber }),
      ...(req.body.paymentDate !== undefined && { paymentDate: req.body.paymentDate }),
      ...(req.body.bankName !== undefined && { bankName: req.body.bankName }),
      ...(req.body.bankAccountNumber !== undefined && { bankAccountNumber: req.body.bankAccountNumber }),
      ...(req.body.bankBranch !== undefined && { bankBranch: req.body.bankBranch }),
      // Status & Attachment
      ...(req.body.activityStatus !== undefined && { activityStatus: req.body.activityStatus }),
      ...(req.body.attachmentNumber !== undefined && { attachmentNumber: req.body.attachmentNumber }),
      ...(req.body.attachmentDate !== undefined && { attachmentDate: req.body.attachmentDate }),
      // Section 3
      ...(req.body.findingsSummary !== undefined && { findingsSummary: req.body.findingsSummary }),
      ...(req.body.detailedFindings !== undefined && { detailedFindings: req.body.detailedFindings }),
      ...(req.body.riskAssessment !== undefined && { riskAssessment: req.body.riskAssessment }),
      ...(req.body.recommendations !== undefined && { recommendations: req.body.recommendations }),
      ...(req.body.actionItems !== undefined && { actionItems: req.body.actionItems }),
      ...(req.body.followUpRequired !== undefined && { followUpRequired: req.body.followUpRequired }),
      ...(req.body.followUpDate !== undefined && { followUpDate: req.body.followUpDate }),
      // Section 4
      ...(req.body.documentsReviewed !== undefined && { documentsReviewed: req.body.documentsReviewed }),
      ...(req.body.documentsAttached !== undefined && { documentsAttached: req.body.documentsAttached }),
      ...(req.body.missingDocuments !== undefined && { missingDocuments: req.body.missingDocuments }),
      ...(req.body.documentReviewDate !== undefined && { documentReviewDate: req.body.documentReviewDate }),
      ...(req.body.documentReviewNotes !== undefined && { documentReviewNotes: req.body.documentReviewNotes }),
      // Section 5: Auto-set preparedBy on first save
      ...(existingReport ? {} : {
        preparedBy: user.id,
        preparedAt: new Date(),
        preparedByRole: user.role,
      }),
      lastSavedBy: user.id,
      lastSavedAt: new Date(),
    };

    // Debug logging - check what we received in req.body first
    console.log('[BACKEND SAVE] req.body values:', {
      profitTransactionTax: req.body.profitTransactionTax,
      incomeTax: req.body.incomeTax,
      collectedCurrentMonth: req.body.collectedCurrentMonth,
      profitTransactionTaxUndefined: req.body.profitTransactionTax === undefined,
      incomeTaxUndefined: req.body.incomeTax === undefined,
      collectedCurrentMonthUndefined: req.body.collectedCurrentMonth === undefined,
    });
    
    // Debug logging for the three critical fields in reportData
    console.log('[BACKEND SAVE] reportData values:', {
      profitTransactionTax: reportData.profitTransactionTax,
      incomeTax: reportData.incomeTax,
      collectedCurrentMonth: reportData.collectedCurrentMonth,
      profitTransactionTaxType: typeof reportData.profitTransactionTax,
      incomeTaxType: typeof reportData.incomeTax,
      collectedCurrentMonthType: typeof reportData.collectedCurrentMonth,
      hasProfitTransactionTax: 'profitTransactionTax' in reportData,
      hasIncomeTax: 'incomeTax' in reportData,
      hasCollectedCurrentMonth: 'collectedCurrentMonth' in reportData,
    });

    // Upsert report with transaction safety
    let report;
    try {
      report = await storage.upsertCaseReportV2(reportData);
      
      // Debug logging after save
      console.log('[BACKEND SAVE] Saved report:', {
        profitTransactionTax: report.profitTransactionTax,
        incomeTax: report.incomeTax,
        collectedCurrentMonth: report.collectedCurrentMonth,
      });
      
      // Verify report was actually saved
      if (!report || !report.id) {
        throw new Error('Report save failed - no ID returned');
      }
      
      // Double-check by fetching the saved report
      const verifiedReport = await storage.getCaseReportV2(req.params.id);
      if (!verifiedReport) {
        throw new Error('Report save failed - could not verify persistence');
      }
      
      // Log successful persistence
      console.log('[CASE REPORT PERSISTENCE] Report saved successfully:', {
        caseId: req.params.id,
        reportId: report.id,
        version: report.version,
        status: report.status,
        savedBy: user.id,
        timestamp: new Date().toISOString(),
      });
      
      // PHASE 1: Payment Traceability - Create Payment record if collectedCurrentMonth > 0
      if (report.collectedCurrentMonth) {
        const collectedAmount = typeof report.collectedCurrentMonth === 'string' 
          ? parseFloat(report.collectedCurrentMonth.toString().replace(/,/g, '')) || 0
          : (typeof report.collectedCurrentMonth === 'number' ? report.collectedCurrentMonth : 0);
        
        if (collectedAmount > 0) {
          try {
            // Parse payment date from report or use current date
            let paymentDate: Date = new Date();
            if (req.body.paymentDate) {
              const { parseDateString } = await import('../utils/shamsiDate');
              const { date: parsedDate } = parseDateString(req.body.paymentDate);
              if (parsedDate) {
                paymentDate = parsedDate;
              }
            } else if (report.paymentDate) {
              // Try to parse from report.paymentDate (stored as text in DD-MM-YYYY format)
              const { parseDateString } = await import('../utils/shamsiDate');
              const { date: parsedDate } = parseDateString(report.paymentDate);
              if (parsedDate) {
                paymentDate = parsedDate;
              }
            }
            
            await storage.createPayment({
              caseId: req.params.id,
              paymentDate: paymentDate,
              paymentAmount: collectedAmount.toString(),
              paymentType: 'normal',
            });
          } catch (paymentError) {
            // Log but don't fail the request if payment creation fails
            console.warn('[PAYMENT TRACEABILITY] Failed to create payment record:', paymentError);
          }
        }
      }
    } catch (error) {
      console.error('[CASE REPORT PERSISTENCE ERROR] Failed to save report:', {
        caseId: req.params.id,
        error: error instanceof Error ? error.message : String(error),
        userId: user.id,
        timestamp: new Date().toISOString(),
      });
      throw error; // Re-throw to trigger error response
    }

    // Create history entry
    try {
      await storage.createCaseReportHistory({
        reportId: report.id,
        version: report.version,
        changedBy: user.id,
        changeType: existingReport ? 'update' : 'create',
        section: req.body.section || null,
        changes: req.body, // Store what changed
        snapshot: report, // Full snapshot
        notes: req.body.notes || null,
      });
    } catch (historyError) {
      // Log but don't fail the request if history fails
      console.warn('[CASE REPORT HISTORY] Failed to create history entry:', historyError);
    }

    // Update case transactionId if attachmentNumber is provided
    if (req.body.attachmentNumber) {
      await storage.updateCase(req.params.id, {
        transactionId: req.body.attachmentNumber,
      });
    }

    await storage.createAuditLog({
      userId: user.id,
      action: 'save_case_report_v2_draft',
      entityType: 'case',
      entityId: caseData.id,
      details: {
        caseId: caseData.caseId,
        reportId: report.id,
        version: report.version,
        section: req.body.section,
      },
      ipAddress: extractClientIp(req),
    });

    res.json(report);
  } catch (error) {
    console.error('[CASE REPORT PERSISTENCE ERROR] Error saving case report v2 draft:', {
      caseId: req.params.id,
      error: error instanceof Error ? error.message : String(error),
      stack: error instanceof Error ? error.stack : undefined,
      userId: (req.user as any)?.id,
      timestamp: new Date().toISOString(),
    });
    res.status(500).json({ 
      message: "خطا در ذخیره گزارش قضیه",
      error: process.env.NODE_ENV === 'development' ? (error instanceof Error ? error.message : String(error)) : undefined
    });
  }
});

// Validate case report V2
router.post("/:id/report/v2/validate", requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    const caseData = await storage.getCase(req.params.id);
    
    if (!caseData) {
      return res.status(404).json({ message: "قضیه یافت نشد" });
    }

    // Get report (use provided data or fetch from DB)
    let report = await storage.getCaseReportV2(req.params.id);
    
    // If report data provided in request, merge it
    if (req.body.reportData && report) {
      report = { ...report, ...req.body.reportData };
    } else if (req.body.reportData && !report) {
      // Create temporary report object for validation
      const entity = await storage.getEntity(caseData.entityId);
      report = {
        ...req.body.reportData,
        caseId: req.params.id,
        companyName: req.body.reportData.companyName || caseData.companyName || entity?.companyName || '',
        tin: req.body.reportData.tin || caseData.tin || entity?.tin || '',
        businessNature: req.body.reportData.businessNature || caseData.businessNature || entity?.businessNature || '',
        groupReferrer: req.body.reportData.groupReferrer || caseData.groupReferrer || entity?.referralGroup || '',
        referralDate: req.body.reportData.referralDate || caseData.referralDate || '',
        periodsUnderReview: req.body.reportData.periodsUnderReview || caseData.periodsUnderReview || entity?.periodsUnderReview || '',
      } as any;
    }

    if (!report) {
      return res.status(404).json({ message: "گزارش یافت نشد" });
    }

    // Validate
    const { validateReport, validateSection } = await import('../services/reportValidationServiceV2');
    
    let validationResult;
    if (req.body.section) {
      // Validate specific section
      const sectionResult = await validateSection(report, req.body.section, caseData);
      validationResult = {
        isValid: sectionResult.isValid,
        errors: sectionResult.errors,
        warnings: sectionResult.warnings,
        section: sectionResult,
      };
    } else {
      // Validate entire report
      validationResult = await validateReport(report, caseData);
    }

    res.json(validationResult);
  } catch (error) {
    console.error('Error validating case report v2:', error);
    res.status(500).json({ message: "خطا در اعتبارسنجی گزارش" });
  }
});

// Complete case report V2
router.post("/:id/report/v2/complete", requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    const caseData = await storage.getCase(req.params.id);
    
    if (!caseData) {
      return res.status(404).json({ message: "قضیه یافت نشد" });
    }

    // Get report
    const report = await storage.getCaseReportV2(req.params.id);
    if (!report) {
      return res.status(404).json({ message: "گزارش یافت نشد" });
    }

    // Validate report
    const { validateReport } = await import('../services/reportValidationServiceV2');
    const validation = await validateReport(report, caseData);

    if (!validation.isValid) {
      // Only include errors from required sections (1, 2, 5) - exclude section_3 and section_4
      const requiredSectionErrors = [
        ...validation.sections.section_1.errors,
        ...validation.sections.section_2.errors,
        ...validation.sections.section_5.errors,
      ];

      // Build detailed error message from required section errors only
      const errorMessages = requiredSectionErrors
        .map(err => err.message)
        .filter((msg, idx, arr) => arr.indexOf(msg) === idx); // Remove duplicates

      // Log validation details for debugging (Suggestion A)
      console.log('[DEBUG] Report validation failed:', {
        caseId: req.params.id,
        allErrors: validation.errors.map(e => ({ field: e.field, message: e.message, code: e.code })),
        requiredSectionErrors: requiredSectionErrors.map(e => ({ field: e.field, message: e.message, code: e.code })),
        sections: {
          section_1: { 
            complete: validation.sections.section_1.complete, 
            errors: validation.sections.section_1.errors.map(e => e.field),
            errorCount: validation.sections.section_1.errors.length 
          },
          section_2: { 
            complete: validation.sections.section_2.complete, 
            errors: validation.sections.section_2.errors.map(e => e.field),
            errorCount: validation.sections.section_2.errors.length 
          },
          section_3: { 
            complete: validation.sections.section_3.complete, 
            errors: validation.sections.section_3.errors.map(e => e.field),
            errorCount: validation.sections.section_3.errors.length,
            note: 'Optional - not required for completion'
          },
          section_4: { 
            complete: validation.sections.section_4.complete, 
            errors: validation.sections.section_4.errors.map(e => e.field),
            errorCount: validation.sections.section_4.errors.length,
            note: 'Optional - not required for completion'
          },
          section_5: { 
            complete: validation.sections.section_5.complete, 
            errors: validation.sections.section_5.errors.map(e => e.field),
            errorCount: validation.sections.section_5.errors.length 
          },
        },
        completion: validation.completion,
        isValid: validation.isValid,
      });

      return res.status(400).json({
        success: false,
        validation: {
          ...validation,
          // Only return errors from required sections in the validation object
          errors: requiredSectionErrors,
          // Update sections to show only required section errors (clear optional sections)
          sections: {
            ...validation.sections,
            section_3: {
              ...validation.sections.section_3,
              errors: [], // Clear section_3 errors since it's optional
            },
            section_4: {
              ...validation.sections.section_4,
              errors: [], // Clear section_4 errors since it's optional
            },
          },
        },
        message: errorMessages.length > 0 
          ? `گزارش کامل نیست. خطاها: ${errorMessages.join('; ')}`
          : 'گزارش کامل نیست. لطفاً تمام بخش‌های الزامی را تکمیل کنید.',
        errors: requiredSectionErrors, // Only return required section errors - USE THIS FIELD
      });
    }

    // Auto-fill reviewedBy and reviewedAt from assigned user
    const reviewedBy = caseData.assignedTo || user.id;
    const reviewedByUser = await storage.getUser(reviewedBy);
    const reviewedByRole = reviewedByUser ? (reviewedByUser.fullName || reviewedByUser.auditId || '') : '';

    // Update report status to completed and set reviewed fields with transaction safety
    const updatedReport = await storage.updateCaseReportV2(req.params.id, {
      status: 'completed',
      reviewedBy: reviewedBy,
      reviewedAt: new Date(),
      reviewedByRole: reviewedByRole,
    });

    if (!updatedReport || !updatedReport.id) {
      console.error('[CASE REPORT COMPLETION ERROR] Failed to update report status:', {
        caseId: req.params.id,
        reportId: report.id,
        userId: user.id,
      });
      return res.status(500).json({ message: "خطا در ذخیره وضعیت گزارش" });
    }
    
    // Verify persistence
    const verifiedReport = await storage.getCaseReportV2(req.params.id);
    if (!verifiedReport || verifiedReport.status !== 'completed') {
      console.error('[CASE REPORT COMPLETION ERROR] Report status not persisted correctly:', {
        caseId: req.params.id,
        expectedStatus: 'completed',
        actualStatus: verifiedReport?.status,
      });
      return res.status(500).json({ message: "خطا در تایید ذخیره وضعیت گزارش" });
    }
    
    // Log successful completion
    console.log('[CASE REPORT PERSISTENCE] Report marked as completed:', {
      caseId: req.params.id,
      reportId: updatedReport.id,
      version: updatedReport.version,
      completedBy: user.id,
      reviewedBy: reviewedBy,
      timestamp: new Date().toISOString(),
    });

    // Create history entry
    await storage.createCaseReportHistory({
      reportId: updatedReport.id,
      version: updatedReport.version,
      changedBy: user.id,
      changeType: 'status_change',
      section: null,
      changes: { status: { from: report.status, to: 'completed' } },
      snapshot: updatedReport,
      notes: 'گزارش تکمیل شد',
    });

    await storage.createAuditLog({
      userId: user.id,
      action: 'complete_case_report_v2',
      entityType: 'case',
      entityId: caseData.id,
      details: {
        caseId: caseData.caseId,
        reportId: updatedReport.id,
      },
      ipAddress: extractClientIp(req),
    });

    res.json({
      success: true,
      report: updatedReport,
      validation,
    });
  } catch (error) {
    console.error('Error completing case report v2:', error);
    res.status(500).json({ message: "خطا در تکمیل گزارش" });
  }
});

// Generate PDF for case report V2
router.get("/:id/report/v2/pdf", requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    const caseData = await storage.getCase(req.params.id);
    
    if (!caseData) {
      return res.status(404).json({ message: "قضیه یافت نشد" });
    }

    // RBAC: Check if user can view this case
    const { getCaseVisibility } = await import('../utils/permissionHelpers');
    const visibility = await getCaseVisibility(user);

    if (user.role !== 'system_admin') {
      const { getEffectivePermissions } = await import('../services/permissionService');
      const effectivePermissions = await getEffectivePermissions(user.id);
      
      if (!effectivePermissions['cases:view']) {
        return res.status(403).json({ message: 'عدم دسترسی - شما مجوز لازم را ندارید' });
      }
      
      if (visibility.canViewAll) {
        // Access granted
      } else if (visibility.filterByAssignee) {
        if (caseData.assignedTo !== user.id) {
          return res.status(403).json({ message: 'عدم دسترسی' });
        }
      } else if (visibility.filterByGroup) {
        if (caseData.receivingGroup !== visibility.filterByGroup) {
          return res.status(403).json({ message: 'عدم دسترسی' });
        }
      } else {
        return res.status(403).json({ message: 'عدم دسترسی' });
      }
    }

    // Get report
    const report = await storage.getCaseReportV2(req.params.id);
    if (!report) {
      return res.status(404).json({ message: "گزارش یافت نشد" });
    }

    // Get entity for additional fields
    const entity = await storage.getEntity(caseData.entityId);
    
    // Enrich report with entity data
    const enrichedReport = {
      ...report,
      representative: (report as any).representative || entity?.contactPerson || '',
      representativeContactNumber: (report as any).representativeContactNumber || entity?.phone || '',
      entityAddress: (report as any).entityAddress || entity?.registeredAddress || '',
    };

    // Get users for signatures
    const preparedByUser = report.preparedBy ? await storage.getUser(report.preparedBy) : undefined;
    const reviewedByUser = report.reviewedBy ? await storage.getUser(report.reviewedBy) : undefined;
    const approvedByUser = report.approvedBy ? await storage.getUser(report.approvedBy) : undefined;

    // Generate PDF
    const { generateReportPDFBuffer } = await import('../services/reportPDFService');
    const pdfBuffer = await generateReportPDFBuffer({
      report: enrichedReport as any,
      caseData,
      preparedByUser: preparedByUser || undefined,
      reviewedByUser: reviewedByUser || undefined,
      approvedByUser: approvedByUser || undefined,
    });

    // Set response headers
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename=report-${caseData.caseId}.pdf`);
    res.setHeader('Content-Length', pdfBuffer.length.toString());

    res.send(pdfBuffer);
  } catch (error) {
    console.error('Error generating report PDF:', error);
    res.status(500).json({ message: "خطا در تولید PDF گزارش" });
  }
});

// Get case report history
router.get("/:id/report/v2/history", requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    const caseData = await storage.getCase(req.params.id);
    
    if (!caseData) {
      return res.status(404).json({ message: "قضیه یافت نشد" });
    }

    const report = await storage.getCaseReportV2(req.params.id);
    if (!report) {
      return res.status(404).json({ message: "گزارش یافت نشد" });
    }

    const history = await storage.getCaseReportHistory(report.id);

    // Enrich with user details
    const enrichedHistory = await Promise.all(
      history.map(async (entry) => {
        const changedByUser = await storage.getUser(entry.changedBy);
        return {
          ...entry,
          changedByUser: changedByUser ? {
            id: changedByUser.id,
            fullName: changedByUser.fullName,
            role: changedByUser.role,
            auditId: changedByUser.auditId,
          } : null,
        };
      })
    );

    res.json({
      reportId: report.id,
      history: enrichedHistory,
    });
  } catch (error) {
    console.error('Error fetching case report history:', error);
    res.status(500).json({ message: "خطا در دریافت تاریخچه گزارش" });
  }
});

// Get allowed transitions for a case
router.get("/:id/transitions", requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    const caseItem = await storage.getCase(req.params.id);
    
    if (!caseItem) {
      return res.status(404).json({ message: "قضیه یافت نشد" });
    }
    
    // Check RBAC access
    const { getCaseVisibility } = await import('../utils/permissionHelpers');
    const visibility = await getCaseVisibility(user);
    
    if (user.role !== 'system_admin') {
      const { getEffectivePermissions } = await import('../services/permissionService');
      const effectivePermissions = await getEffectivePermissions(user.id);
      
      if (!effectivePermissions['cases:view']) {
        return res.status(403).json({ message: 'عدم دسترسی - شما مجوز لازم را ندارید' });
      }
      
      if (visibility.canViewAll) {
        // Access granted
      } else if (visibility.filterByAssignee) {
        if (caseItem.assignedTo !== user.id) {
          return res.status(403).json({ message: 'عدم دسترسی' });
        }
      } else if (visibility.filterByGroup) {
        if (caseItem.receivingGroup !== visibility.filterByGroup) {
          return res.status(403).json({ message: 'عدم دسترسی' });
        }
      } else {
        return res.status(403).json({ message: 'عدم دسترسی' });
      }
    }
    
    // Get allowed transitions
    const { getAllowedTransitions, getTransitionInfo } = await import('../services/caseStateMachine');
    const allowed = getAllowedTransitions(caseItem, user);
    
    // Format response with transition info
    const transitions = allowed.map(rule => {
      const info = getTransitionInfo(rule.name);
      return {
        name: rule.name,
        toStatus: rule.to,
        label: info.label,
        description: info.description,
        requiredPermission: rule.requiredPermission,
        requiresConfirmation: info.requiresConfirmation,
        validation: {
          requiresReport: rule.name === 'complete',
          requiresAssignment: rule.name === 'start',
          requiresRejectionReason: rule.name === 'reject',
        },
      };
    });
    
    res.json({
      currentStatus: caseItem.status,
      allowedTransitions: transitions,
    });
  } catch (error) {
    console.error('Error getting allowed transitions:', error);
    res.status(500).json({ message: "خطا در دریافت انتقال‌های مجاز" });
  }
});

// Get transition history for a case
router.get("/:id/transitions/history", requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    const caseItem = await storage.getCase(req.params.id);
    
    if (!caseItem) {
      return res.status(404).json({ message: "قضیه یافت نشد" });
    }
    
    // Check RBAC access
    const { getCaseVisibility } = await import('../utils/permissionHelpers');
    const visibility = await getCaseVisibility(user);
    
    if (user.role !== 'system_admin') {
      const { getEffectivePermissions } = await import('../services/permissionService');
      const effectivePermissions = await getEffectivePermissions(user.id);
      
      if (!effectivePermissions['cases:view']) {
        return res.status(403).json({ message: 'عدم دسترسی - شما مجوز لازم را ندارید' });
      }
      
      if (visibility.canViewAll) {
        // Access granted
      } else if (visibility.filterByAssignee) {
        if (caseItem.assignedTo !== user.id) {
          return res.status(403).json({ message: 'عدم دسترسی' });
        }
      } else if (visibility.filterByGroup) {
        if (caseItem.receivingGroup !== visibility.filterByGroup) {
          return res.status(403).json({ message: 'عدم دسترسی' });
        }
      } else {
        return res.status(403).json({ message: 'عدم دسترسی' });
      }
    }
    
    // Get transition history
    const transitions = await storage.getCaseStatusTransitions(req.params.id);
    
    // Enrich with user details
    const enrichedTransitions = await Promise.all(
      transitions.map(async (transition) => {
        const transitionedByUser = await storage.getUser(transition.transitionedBy);
        return {
          id: transition.id,
          fromStatus: transition.fromStatus,
          toStatus: transition.toStatus,
          transitionName: transition.transitionName,
          transitionedBy: transitionedByUser ? {
            id: transitionedByUser.id,
            fullName: transitionedByUser.fullName,
            role: transitionedByUser.role,
            auditId: transitionedByUser.auditId,
          } : null,
          transitionedAt: transition.transitionedAt,
          notes: transition.notes,
          rejectionReason: transition.rejectionReason,
          metadata: transition.metadata,
        };
      })
    );
    
    res.json({
      caseId: req.params.id,
      transitions: enrichedTransitions,
    });
  } catch (error) {
    console.error('Error getting transition history:', error);
    res.status(500).json({ message: "خطا در دریافت تاریخچه انتقال‌ها" });
  }
});

// Execute case status transition (unified endpoint)
router.post("/:id/transition", requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    const { transition, metadata } = req.body;
    const caseId = req.params.id;
    
    // Validate transition name
    const validTransitions = ['assign', 'start', 'complete', 'submit_for_approval', 'approve', 'reject', 'reopen', 'reassign', 'to_installment', 'move_to_installment', 'to_law_enforcement', 'send_to_law_enforcement'];
    if (!transition || !validTransitions.includes(transition)) {
      return res.status(400).json({
        success: false,
        error: {
          code: 'INVALID_TRANSITION_NAME',
          message: 'نام انتقال نامعتبر است',
          validTransitions,
        },
      });
    }
    
    // Get case and check RBAC
    const caseItem = await storage.getCase(caseId);
    if (!caseItem) {
      return res.status(404).json({
        success: false,
        error: {
          code: 'CASE_NOT_FOUND',
          message: 'قضیه یافت نشد',
        },
      });
    }
    
    // Check RBAC access to this case
    const { getCaseVisibility } = await import('../utils/permissionHelpers');
    const visibility = await getCaseVisibility(user);
    
    if (user.role !== 'system_admin') {
      const { getEffectivePermissions } = await import('../services/permissionService');
      const effectivePermissions = await getEffectivePermissions(user.id);
      
      // Check if user has cases:view permission
      if (!effectivePermissions['cases:view']) {
        return res.status(403).json({
          success: false,
          error: {
            code: 'PERMISSION_DENIED',
            message: 'عدم دسترسی - شما مجوز لازم را ندارید',
          },
        });
      }
      
      // Check case access
      if (visibility.canViewAll) {
        // Access granted
      } else if (visibility.filterByAssignee) {
        // Auditor: Check if case is assigned to them (check both assignedTo and assignedAuditor)
        if (caseItem.assignedTo !== user.id && caseItem.assignedAuditor !== user.id) {
          return res.status(403).json({
            success: false,
            error: {
              code: 'PERMISSION_DENIED',
              message: 'عدم دسترسی - شما فقط می‌توانید قضایای اختصاص داده شده به خود را مشاهده کنید',
            },
          });
        }
      } else if (visibility.filterByGroup) {
        // Senior auditor: Check if case belongs to their group
        if (caseItem.receivingGroup !== visibility.filterByGroup) {
          return res.status(403).json({
            success: false,
            error: {
              code: 'PERMISSION_DENIED',
              message: 'عدم دسترسی - شما فقط می‌توانید قضایای گروه خود را مشاهده کنید',
            },
          });
        }
      } else {
        return res.status(403).json({
          success: false,
          error: {
            code: 'PERMISSION_DENIED',
            message: 'عدم دسترسی',
          },
        });
      }
    }
    
    // Execute transition
    const { executeTransition, getAllowedTransitions } = await import('../services/caseStateMachine');
    const result = await executeTransition(caseId, user, transition, {
      ...metadata,
      ipAddress: extractClientIp(req),
    });
    
    if (!result.success) {
      // Get allowed transitions for error message
      const allowed = getAllowedTransitions(caseItem, user);
      
      return res.status(400).json({
        success: false,
        error: {
          code: 'INVALID_TRANSITION',
          message: result.errorMessage,
          allowedTransitions: allowed.map(t => t.name),
        },
      });
    }
    
    // Get updated case
    const updatedCase = await storage.getCase(caseId);
    if (!updatedCase) {
      return res.status(404).json({
        success: false,
        error: {
          code: 'CASE_NOT_FOUND',
          message: 'قضیه یافت نشد',
        },
      });
    }
    
    // Get transition record
    const transitionRecord = result.transitionId 
      ? await storage.getCaseStatusTransition(result.transitionId)
      : null;
    
    // Send notifications if needed
    if (transition === 'complete' && caseItem.assignedTo && caseItem.assignedTo !== user.id) {
      await storage.createNotification({
        userId: caseItem.assignedTo,
        message: `قضیه ${updatedCase.caseId} تکمیل شد`,
        messagePashto: `قضیه ${updatedCase.caseId} بشپړه شوه`,
        type: 'case_completion',
      });
    }
    
    if (transition === 'approve' && caseItem.assignedTo) {
      await storage.createNotification({
        userId: caseItem.assignedTo,
        message: `قضیه ${updatedCase.caseId} تایید شد`,
        messagePashto: `قضیه ${updatedCase.caseId} تصدیق شوه`,
        type: 'case_approval',
      });
    }
    
    if (transition === 'reject' && caseItem.assignedTo) {
      await storage.createNotification({
        userId: caseItem.assignedTo,
        message: `قضیه ${updatedCase.caseId} رد شد. دلیل: ${metadata?.rejectionReason || 'نامشخص'}`,
        messagePashto: `قضیه ${updatedCase.caseId} رد شوه. دلیل: ${metadata?.rejectionReason || 'نامشخص'}`,
        type: 'case_rejection',
      });
    }
    
    res.json({
      success: true,
      case: updatedCase,
      transition: transitionRecord,
    });
  } catch (error) {
    console.error('Error executing transition:', error);
    res.status(500).json({
      success: false,
      error: {
        code: 'INTERNAL_ERROR',
        message: 'خطا در اجرای انتقال وضعیت',
      },
    });
  }
});

// Export completed cases to Excel
router.post("/export/completed", requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    const { filters } = req.body;
    
    // Get all cases with RBAC filtering
    const { getCaseVisibility } = await import('../utils/permissionHelpers');
    const visibility = await getCaseVisibility(user);
    
    let allCases: Case[] = [];
    
    if (visibility.canViewAll) {
      allCases = await storage.getCases();
    } else if (visibility.requiresFiltering) {
      if (visibility.filterByAssignee) {
        allCases = await storage.getCasesByAssignee(user.id);
      } else if (visibility.filterByGroup) {
        allCases = await storage.getCasesByGroup(visibility.filterByGroup);
      }
    }
    
    // Filter to completed cases (only COMPLETED status)
    const { CaseStatus } = await import('@shared/schema');
    let completedCases = allCases.filter(c => 
      c.status === CaseStatus.COMPLETED || 
      c.status === 'تکمیل شده'
    );
    
    // Apply additional filters if provided
    if (filters) {
      if (filters.entityName) {
        completedCases = completedCases.filter(c => 
          c.companyName?.toLowerCase().includes(filters.entityName.toLowerCase())
        );
      }
      if (filters.tin) {
        completedCases = completedCases.filter(c => 
          c.tin?.toLowerCase().includes(filters.tin.toLowerCase())
        );
      }
      if (filters.assignedAuditor) {
        completedCases = completedCases.filter(c => c.assignedTo === filters.assignedAuditor);
      }
      if (filters.caseType) {
        completedCases = completedCases.filter(c => 
          c.periodsUnderReview?.toLowerCase().includes(filters.caseType.toLowerCase())
        );
      }
    }
    
    // Get users for assignedTo names
    const users = await storage.getUsers();
    const getUserName = (userId: string | null | undefined) => {
      if (!userId) return '-';
      const user = users.find(u => u.id === userId);
      return user?.fullName || userId;
    };
    
    // Create Excel workbook
    const ExcelJS = await import('exceljs');
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet('قضایای تکمیل شده');
    
    // Set RTL direction
    worksheet.views = [{ rightToLeft: true }];
    
    // Define columns
    worksheet.columns = [
      { header: 'نمبر قضیه', key: 'caseId', width: 15 },
      { header: 'نام نهاد', key: 'companyName', width: 30 },
      { header: 'نمبر تشخیصیه', key: 'tin', width: 15 },
      { header: 'سال های بررسی', key: 'periodsUnderReview', width: 20 },
      { header: 'بررس اختصاص داده شده', key: 'assignedTo', width: 20 },
      { header: 'وضعیت', key: 'status', width: 15 },
      { header: 'تاریخ ایجاد', key: 'createdAt', width: 15 },
      { header: 'تاریخ تکمیل', key: 'completedAt', width: 15 },
      { header: 'تاریخ تایید/رد', key: 'approvedAt', width: 15 },
    ];
    
    // Add header row with formatting
    const headerRow = worksheet.getRow(1);
    headerRow.font = { name: 'Arial', size: 11, bold: true };
    headerRow.alignment = { horizontal: 'right', vertical: 'middle' };
    headerRow.fill = {
      type: 'pattern',
      pattern: 'solid',
      fgColor: { argb: 'FFD9D9D9' }
    };
    headerRow.height = 25;
    
    // Add data rows
    completedCases.forEach((caseItem) => {
      const row = worksheet.addRow([
        caseItem.caseId,
        caseItem.companyName,
        caseItem.tin,
        caseItem.periodsUnderReview,
        getUserName(caseItem.assignedTo),
        caseItem.status,
        caseItem.createdAt ? new Date(caseItem.createdAt).toLocaleDateString('fa-IR') : '-',
        caseItem.completedAt ? new Date(caseItem.completedAt).toLocaleDateString('fa-IR') : '-',
        caseItem.approvedAt ? new Date(caseItem.approvedAt).toLocaleDateString('fa-IR') : 
        caseItem.rejectedAt ? new Date(caseItem.rejectedAt).toLocaleDateString('fa-IR') : '-',
      ]);
      
      row.eachCell((cell) => {
        cell.alignment = { horizontal: 'right', vertical: 'middle' };
      });
    });
    
    // Generate buffer
    const buffer = await workbook.xlsx.writeBuffer();
    
    // Set response headers
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename=completed-cases-${new Date().toISOString().split('T')[0]}.xlsx`);
    
    res.send(Buffer.from(buffer));
  } catch (error) {
    console.error('Error exporting completed cases:', error);
    res.status(500).json({ message: "خطا در صادر کردن گزارش" });
  }
});

// Export completed cases to PDF
router.post("/export/completed/pdf", requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    const { filters } = req.body;
    
    // Get all cases with RBAC filtering
    const { getCaseVisibility } = await import('../utils/permissionHelpers');
    const visibility = await getCaseVisibility(user);
    
    let allCases: Case[] = [];
    
    if (visibility.canViewAll) {
      allCases = await storage.getCases();
    } else if (visibility.requiresFiltering) {
      if (visibility.filterByAssignee) {
        allCases = await storage.getCasesByAssignee(user.id);
      } else if (visibility.filterByGroup) {
        allCases = await storage.getCasesByGroup(visibility.filterByGroup);
      }
    }
    
    // Filter to completed cases (only COMPLETED status)
    const { CaseStatus } = await import('@shared/schema');
    let completedCases = allCases.filter(c => 
      c.status === CaseStatus.COMPLETED || 
      c.status === 'تکمیل شده'
    );
    
    // Apply additional filters if provided
    if (filters) {
      if (filters.entityName) {
        completedCases = completedCases.filter(c => 
          c.companyName?.toLowerCase().includes(filters.entityName.toLowerCase())
        );
      }
      if (filters.tin) {
        completedCases = completedCases.filter(c => 
          c.tin?.toLowerCase().includes(filters.tin.toLowerCase())
        );
      }
      if (filters.assignedAuditor) {
        completedCases = completedCases.filter(c => c.assignedTo === filters.assignedAuditor);
      }
      if (filters.caseType) {
        completedCases = completedCases.filter(c => 
          c.periodsUnderReview?.toLowerCase().includes(filters.caseType.toLowerCase())
        );
      }
    }
    
    // Get users for assignedTo names
    const users = await storage.getUsers();
    const getUserName = (userId: string | null | undefined) => {
      if (!userId) return '-';
      const user = users.find(u => u.id === userId);
      return user?.fullName || userId;
    };
    
    // Create PDF
    const PDFDocument = await import('pdfkit');
    const doc = new PDFDocument.default({ 
      size: 'A4',
      margins: { top: 50, bottom: 50, left: 50, right: 50 }
    });
    
    // Set response headers
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename=completed-cases-${new Date().toISOString().split('T')[0]}.pdf`);
    
    // Pipe PDF to response
    doc.pipe(res);
    
    // Add title
    doc.fontSize(16).text('گزارش قضایای تکمیل شده', { align: 'right' });
    doc.moveDown();
    doc.fontSize(10).text(`تعداد: ${completedCases.length} قضیه`, { align: 'right' });
    doc.moveDown(2);
    
    // Add cases
    completedCases.forEach((caseItem, idx) => {
      if (idx > 0) {
        doc.moveDown();
        doc.moveTo(50, doc.y).lineTo(550, doc.y).stroke();
        doc.moveDown();
      }
      
      doc.fontSize(12).text(`قضیه شماره: ${caseItem.caseId}`, { align: 'right' });
      doc.fontSize(10).text(`نام نهاد: ${caseItem.companyName}`, { align: 'right' });
      doc.fontSize(10).text(`TIN: ${caseItem.tin}`, { align: 'right' });
      doc.fontSize(10).text(`سال های بررسی: ${caseItem.periodsUnderReview || '-'}`, { align: 'right' });
      doc.fontSize(10).text(`بررس: ${getUserName(caseItem.assignedTo)}`, { align: 'right' });
      doc.fontSize(10).text(`وضعیت: ${caseItem.status}`, { align: 'right' });
      doc.fontSize(10).text(`تاریخ ایجاد: ${caseItem.createdAt ? new Date(caseItem.createdAt).toLocaleDateString('fa-IR') : '-'}`, { align: 'right' });
      if (caseItem.completedAt) {
        doc.fontSize(10).text(`تاریخ تکمیل: ${new Date(caseItem.completedAt).toLocaleDateString('fa-IR')}`, { align: 'right' });
      }
      
      if ((idx + 1) % 20 === 0 && idx < completedCases.length - 1) {
        doc.addPage();
      }
    });
    
    doc.end();
  } catch (error) {
    console.error('Error exporting completed cases to PDF:', error);
    res.status(500).json({ message: "خطا در صادر کردن PDF" });
  }
});

// Complete a specific section (section-scoped validation)
router.post("/:id/sections/:sectionId/complete", requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    const { sectionId } = req.params;
    const caseData = await storage.getCase(req.params.id);
    
    if (!caseData) {
      return res.status(404).json({ message: "قضیه یافت نشد" });
    }
    
    // Check permissions
    if (user.role !== 'system_admin' && caseData.assignedTo !== user.id) {
      return res.status(403).json({ message: 'عدم دسترسی' });
    }
    
    // Validate only fields in this section
    const report = await storage.getCaseReportV2(req.params.id);
    if (!report) {
      return res.status(400).json({ message: "گزارش یافت نشد. لطفاً ابتدا گزارش را ایجاد کنید." });
    }
    
    // Section-scoped validation would go here
    // For now, just mark section as completed
    await storage.upsertCaseSectionStatus({
      caseId: req.params.id,
      sectionId: sectionId,
      isCompleted: true,
      completedBy: user.id,
      completedAt: new Date(),
    });
    
    await storage.createAuditLog({
      userId: user.id,
      action: 'complete_section',
      entityType: 'case',
      entityId: req.params.id,
      details: {
        caseId: caseData.caseId,
        sectionId: sectionId,
      },
      ipAddress: extractClientIp(req),
    });
    
    res.json({ success: true, message: `بخش ${sectionId} با موفقیت تکمیل شد` });
  } catch (error) {
    console.error('Error completing section:', error);
    res.status(500).json({ message: "خطا در تکمیل بخش" });
  }
});

// Update or create case metrics (senior auditor only)
router.post("/:id/metrics", requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    
    // Check if user is senior_auditor or admin
    if (user.role !== 'senior_auditor' && user.role !== 'system_admin') {
      return res.status(403).json({ message: 'فقط بازرس ارشد می‌تواند آمار را ویرایش کند' });
    }
    
    const caseData = await storage.getCase(req.params.id);
    if (!caseData) {
      return res.status(404).json({ message: "قضیه یافت نشد" });
    }
    
    const {
      installments_this_month,
      nonresponsive_count,
      incoming_documents,
      outgoing_documents,
      incoming_inquiries,
      outgoing_inquiries,
      remarks,
    } = req.body;
    
    const oldMetrics = await storage.getCaseMetrics(req.params.id);
    
    const updatedMetrics = await storage.upsertCaseMetrics(req.params.id, {
      installmentsThisMonth: installments_this_month,
      nonresponsiveCount: nonresponsive_count,
      incomingDocuments: incoming_documents,
      outgoingDocuments: outgoing_documents,
      incomingInquiries: incoming_inquiries,
      outgoingInquiries: outgoing_inquiries,
      remarks: remarks,
    }, user.id);
    
    // Log the change
    await storage.createAuditLog({
      userId: user.id,
      action: 'update_case_metrics',
      entityType: 'case',
      entityId: req.params.id,
      details: {
        caseId: caseData.caseId,
        oldValue: oldMetrics,
        newValue: updatedMetrics,
      },
      ipAddress: extractClientIp(req),
    });
    
    res.json(updatedMetrics);
  } catch (error) {
    console.error('Error updating case metrics:', error);
    res.status(500).json({ message: "خطا در بروزرسانی آمار" });
  }
});

// Get installment payments
router.get("/:id/installments", requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    const caseData = await storage.getCase(req.params.id);
    
    if (!caseData) {
      return res.status(404).json({ message: "قضیه یافت نشد" });
    }
    
    // Check permissions
    if (user.role !== 'auditor' && user.role !== 'senior_auditor' && user.role !== 'system_admin') {
      return res.status(403).json({ message: 'عدم دسترسی' });
    }
    
    const payments = await storage.getInstallmentPayments(req.params.id);
    res.json(payments);
  } catch (error) {
    console.error('Error fetching installment payments:', error);
    res.status(500).json({ message: "خطا در دریافت پرداخت‌های قسط" });
  }
});

// Create installment payment
router.post("/:id/installments", requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    const caseData = await storage.getCase(req.params.id);
    
    if (!caseData) {
      return res.status(404).json({ message: "قضیه یافت نشد" });
    }
    
    // Check permissions - auditor or senior_auditor can add payments
    if (user.role !== 'auditor' && user.role !== 'senior_auditor' && user.role !== 'system_admin') {
      return res.status(403).json({ message: 'عدم دسترسی' });
    }
    
    const { payment_date, amount_paid, remaining_balance, notes } = req.body;
    
    // Validate required fields
    if (!payment_date || amount_paid === undefined || amount_paid === null) {
      return res.status(400).json({ message: "تاریخ پرداخت و مبلغ پرداخت شده الزامی است" });
    }
    
    // Validate and parse date - frontend sends ISO YYYY-MM-DD format (Gregorian)
    let paymentDate: Date;
    try {
      const { gregorianStringToDate } = await import('../utils/shamsiDate');
      // Frontend sends ISO YYYY-MM-DD format (Gregorian) - convert from Shamsi before submitting
      const parsedDate = gregorianStringToDate(payment_date);
      if (!parsedDate) {
        return res.status(400).json({ message: "تاریخ پرداخت نامعتبر است. لطفاً تاریخ را به درستی وارد کنید." });
      }
      paymentDate = parsedDate;
    } catch (error) {
      console.error('Error parsing payment date:', error);
      return res.status(400).json({ message: "تاریخ پرداخت نامعتبر است" });
    }
    
    // Validate and parse amount
    const amountPaidNum = typeof amount_paid === 'string' 
      ? parseFloat(amount_paid) 
      : (typeof amount_paid === 'number' ? amount_paid : NaN);
    
    if (isNaN(amountPaidNum) || amountPaidNum < 0) {
      return res.status(400).json({ message: "مبلغ پرداخت شده نامعتبر است" });
    }
    
    // Parse remaining balance (optional)
    const remainingBalanceNum = remaining_balance !== undefined && remaining_balance !== null
      ? (typeof remaining_balance === 'string' 
          ? parseFloat(remaining_balance) 
          : (typeof remaining_balance === 'number' ? remaining_balance : 0))
      : 0;
    
    const payment = await storage.createInstallmentPayment({
      caseId: req.params.id,
      paymentDate: paymentDate,
      amountPaid: amountPaidNum.toString(),
      remainingBalance: (isNaN(remainingBalanceNum) ? 0 : remainingBalanceNum).toString(),
      notes: notes || null,
      createdBy: user.id,
    });
    
    // PHASE 1: Payment Traceability - Create Payment record for installment payment
    try {
      await storage.createPayment({
        caseId: req.params.id,
        paymentDate: paymentDate,
        paymentAmount: amountPaidNum.toString(),
        paymentType: 'installment',
      });
    } catch (paymentError) {
      // Log but don't fail the request if payment creation fails
      console.warn('[PAYMENT TRACEABILITY] Failed to create payment record for installment:', paymentError);
    }
    
    // Update isTaxInstallment flag when a tax payment is created
    // Flags are independent of lifecycle status
    if (!(caseData as any).isTaxInstallment && !(caseData as any).is_tax_installment) {
      try {
        await storage.updateCase(req.params.id, { isTaxInstallment: true });
        console.log(`Case ${req.params.id} marked as installment case due to payment creation`);
      } catch (error) {
        console.error('Could not update case isTaxInstallment flag:', error);
      }
    }
    
    // Update metrics aggregate
    const metrics = await storage.getCaseMetrics(req.params.id);
    const currentCount = metrics?.installmentsThisMonth || 0;
    await storage.upsertCaseMetrics(req.params.id, {
      installmentsThisMonth: currentCount + 1,
    }, user.id);
    
    // Log the creation
    await storage.createAuditLog({
      userId: user.id,
      action: 'create_installment_payment',
      entityType: 'case',
      entityId: req.params.id,
      details: {
        caseId: caseData.caseId,
        paymentId: payment.id,
        amountPaid: amount_paid,
        remainingBalance: remaining_balance || 0,
        notes: notes || null,
      },
      ipAddress: extractClientIp(req),
    });
    
    res.status(201).json(payment);
  } catch (error) {
    console.error('Error creating installment payment:', error);
    res.status(500).json({ message: "خطا در ثبت پرداخت قسط" });
  }
});

// Create case flag (nonresponsive, escalation, etc.)
router.post("/:id/flags", requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    const caseData = await storage.getCase(req.params.id);
    
    if (!caseData) {
      return res.status(404).json({ message: "قضیه یافت نشد" });
    }
    
    const { type, details } = req.body;
    
    if (!type) {
      return res.status(400).json({ message: "نوع پرچم الزامی است" });
    }
    
    const flag = await storage.createCaseFlag({
      caseId: req.params.id,
      type: type,
      details: details || {},
      createdBy: user.id,
    });
    
    // Handle special flag types
    if (type === 'nonresponsive_mark') {
      // Non-responsive cases remain in their current lifecycle state
      // No status change needed - this is tracked via case flags/metrics
      // If needed, can transition to SUSPENDED: await executeTransition(req.params.id, user, 'suspend', { notes: 'عدم پاسخگو' });
    } else if (type === 'escalation_to_enforcement') {
      // Update isLawEnforcement flag (not status)
      // Flags are independent of lifecycle status
      try {
        await storage.updateCase(req.params.id, { isLawEnforcement: true });
        console.log(`Case ${req.params.id} marked as law enforcement case`);
      } catch (error) {
        console.error('Could not update case isLawEnforcement flag:', error);
      }
    }
    
    // Log the flag creation
    await storage.createAuditLog({
      userId: user.id,
      action: `create_case_flag_${type}`,
      entityType: 'case',
      entityId: req.params.id,
      details: {
        caseId: caseData.caseId,
        flagType: type,
        flagDetails: details,
      },
      ipAddress: extractClientIp(req),
    });
    
    res.status(201).json(flag);
  } catch (error) {
    console.error('Error creating case flag:', error);
    res.status(500).json({ message: "خطا در ایجاد پرچم" });
  }
});

// Reopen case (senior auditor only)
router.post("/:id/reopen", requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    
    // Check if user is senior_auditor or admin
    if (user.role !== 'senior_auditor' && user.role !== 'system_admin') {
      return res.status(403).json({ message: 'فقط بازرس ارشد می‌تواند قضیه را باز کند' });
    }
    
    const caseData = await storage.getCase(req.params.id);
    if (!caseData) {
      return res.status(404).json({ message: "قضیه یافت نشد" });
    }
    
    const { reason } = req.body;
    
    const oldStatus = caseData.status;
    
    const { CaseStatus } = await import('@shared/schema');
    // Use state machine to reopen (COMPLETED → UNDER_REVIEW)
    const { executeTransition } = await import('../services/caseStateMachine');
    const result = await executeTransition(req.params.id, user, 'reopen', {
      notes: reason || 'قضیه بازگشایی شد',
    });
    
    if (!result.success) {
      return res.status(400).json({ message: result.errorMessage || 'خطا در بازگشایی قضیه' });
    }
    
    const updatedCase = await storage.getCase(req.params.id);
    if (!updatedCase) {
      return res.status(404).json({ message: "قضیه یافت نشد" });
    }
    
    // Log the reopen
    await storage.createAuditLog({
      userId: user.id,
      action: 'reopen_case',
      entityType: 'case',
      entityId: req.params.id,
      details: {
        caseId: caseData.caseId,
        oldStatus: oldStatus,
        newStatus: updatedCase.status,
        reason: reason,
      },
      ipAddress: extractClientIp(req),
    });
    
    res.json(updatedCase);
  } catch (error) {
    console.error('Error reopening case:', error);
    res.status(500).json({ message: "خطا در باز کردن قضیه" });
  }
});

// Get cases with remaining balance > 0 (Financial Tracking - قضایای در اقساط)
// This endpoint returns all cases with unpaid tax, regardless of audit status
router.get("/financial/unpaid", requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    if (!user || !user.id) {
      return res.status(401).json({ message: 'احراز هویت نشده' });
    }
    
    // RBAC: Use unified permission helper
    const { getCaseVisibility } = await import('../utils/permissionHelpers');
    const visibility = await getCaseVisibility(user);
    
    let allCases: Case[] = [];
    
    if (visibility.canViewAll) {
      allCases = await storage.getCases();
    } else if (visibility.requiresFiltering) {
      if (visibility.filterByAssignee) {
        allCases = await storage.getCasesByAssignee(user.id);
      } else if (visibility.filterByGroup) {
        allCases = await storage.getCasesByGroup(visibility.filterByGroup);
      }
    }
    
    // Get financial information for each case
    const casesWithFinancialInfo = await Promise.all(
      allCases.map(async (caseItem) => {
        // Get confirmedAmount (مبلغ تثبیت شده)
        const reportV2 = await storage.getCaseReportV2(caseItem.id);
        const report = reportV2 || await storage.getCaseReport(caseItem.id);
        
        let confirmedAmount = 0;
        if (reportV2?.confirmedAmount) {
          confirmedAmount = typeof reportV2.confirmedAmount === 'string'
            ? parseFloat(reportV2.confirmedAmount.toString().replace(/,/g, '')) || 0
            : (typeof reportV2.confirmedAmount === 'number' ? reportV2.confirmedAmount : 0);
        } else if (report?.confirmedAmount) {
          confirmedAmount = typeof report.confirmedAmount === 'string'
            ? parseFloat(report.confirmedAmount.replace(/,/g, '')) || 0
            : 0;
        }
        
        // Get all payments for this case
        const allPayments = await storage.getPaymentsByCase(caseItem.id);
        
        // Calculate total paid
        let totalPaid = 0;
        let lastPaymentDate: Date | null = null;
        let lastPaymentType: string | null = null;
        
        for (const payment of allPayments) {
          const amount = typeof payment.paymentAmount === 'string'
            ? parseFloat(payment.paymentAmount) || 0
            : (typeof payment.paymentAmount === 'number' ? payment.paymentAmount : 0);
          totalPaid += amount;
          
          // Track last payment
          const paymentDate = payment.paymentDate instanceof Date ? payment.paymentDate : new Date(payment.paymentDate);
          if (!lastPaymentDate || paymentDate > lastPaymentDate) {
            lastPaymentDate = paymentDate;
            lastPaymentType = payment.paymentType;
          }
        }
        
        // Calculate remaining balance
        const remainingBalance = Math.max(0, confirmedAmount - totalPaid);
        
        // Check if case has installment payments
        const installmentPayments = await storage.getInstallmentPayments(caseItem.id);
        const hasInstallmentPlan = installmentPayments.length > 0;
        
        return {
          ...caseItem,
          financialInfo: {
            confirmedAmount,
            totalPaid,
            remainingBalance,
            lastPaymentDate: lastPaymentDate?.toISOString() || null,
            lastPaymentType,
            hasInstallmentPlan,
          },
        };
      })
    );
    
    // Filter: only cases with remaining balance > 0
    // This ensures:
    // - COMPLETED_FULLY_PAID cases (remainingBalance = 0) are EXCLUDED
    // - COMPLETED_WITH_INSTALLMENTS cases (remainingBalance > 0) are INCLUDED
    // - COMPLETED_WITH_REMAINING_BALANCE cases (remainingBalance > 0) are INCLUDED
    // - UNDER_AUDIT cases with remaining balance > 0 are also included
    const unpaidCases = casesWithFinancialInfo.filter(
      (caseItem: any) => {
        const remainingBalance = caseItem.financialInfo?.remainingBalance || 0;
        // Only include cases with remaining balance > 0.01 (to handle floating point precision)
        return remainingBalance > 0.01;
      }
    );
    
    res.json(unpaidCases);
  } catch (error) {
    console.error('Error fetching cases with unpaid balance:', error);
    res.status(500).json({ message: "خطا در دریافت قضایای با مانده بدهی" });
  }
});

// Get financial information for a case
router.get("/:id/financial", requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    const caseData = await storage.getCase(req.params.id);
    
    if (!caseData) {
      return res.status(404).json({ message: "قضیه یافت نشد" });
    }
    
    // RBAC check
    const { getCaseVisibility } = await import('../utils/permissionHelpers');
    const visibility = await getCaseVisibility(user);
    
    if (user.role !== 'system_admin') {
      const { getEffectivePermissions } = await import('../services/permissionService');
      const effectivePermissions = await getEffectivePermissions(user.id);
      
      if (!effectivePermissions['cases:view']) {
        return res.status(403).json({ message: 'عدم دسترسی' });
      }
      
      if (visibility.requiresFiltering) {
        if (visibility.filterByAssignee && caseData.assignedTo !== user.id && caseData.assignedAuditor !== user.id) {
          return res.status(403).json({ message: 'عدم دسترسی' });
        }
        if (visibility.filterByGroup && caseData.receivingGroup !== visibility.filterByGroup) {
          return res.status(403).json({ message: 'عدم دسترسی' });
        }
      }
    }
    
    // Get confirmedAmount (مبلغ تثبیت شده)
    const reportV2 = await storage.getCaseReportV2(req.params.id);
    const report = reportV2 || await storage.getCaseReport(req.params.id);
    
    let confirmedAmount = 0;
    if (reportV2?.confirmedAmount) {
      confirmedAmount = typeof reportV2.confirmedAmount === 'string'
        ? parseFloat(reportV2.confirmedAmount.toString().replace(/,/g, '')) || 0
        : (typeof reportV2.confirmedAmount === 'number' ? reportV2.confirmedAmount : 0);
    } else if (report?.confirmedAmount) {
      confirmedAmount = typeof report.confirmedAmount === 'string'
        ? parseFloat(report.confirmedAmount.replace(/,/g, '')) || 0
        : 0;
    }
    
    // Get all payments
    const allPayments = await storage.getPaymentsByCase(req.params.id);
    
    // Calculate total paid
    let totalPaid = 0;
    for (const payment of allPayments) {
      const amount = typeof payment.paymentAmount === 'string'
        ? parseFloat(payment.paymentAmount) || 0
        : (typeof payment.paymentAmount === 'number' ? payment.paymentAmount : 0);
      totalPaid += amount;
    }
    
    // Calculate remaining balance
    const remainingBalance = Math.max(0, confirmedAmount - totalPaid);
    
    res.json({
      confirmedAmount,
      totalPaid,
      remainingBalance,
      caseStatus: caseData.status,
    });
  } catch (error) {
    console.error('Error fetching financial information:', error);
    res.status(500).json({ message: "خطا در دریافت اطلاعات مالی" });
  }
});

// Get payment history for a case
router.get("/:id/payments", requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    const caseData = await storage.getCase(req.params.id);
    
    if (!caseData) {
      return res.status(404).json({ message: "قضیه یافت نشد" });
    }
    
    // RBAC check
    const { getCaseVisibility } = await import('../utils/permissionHelpers');
    const visibility = await getCaseVisibility(user);
    
    if (user.role !== 'system_admin') {
      const { getEffectivePermissions } = await import('../services/permissionService');
      const effectivePermissions = await getEffectivePermissions(user.id);
      
      if (!effectivePermissions['cases:view']) {
        return res.status(403).json({ message: 'عدم دسترسی' });
      }
      
      if (visibility.requiresFiltering) {
        if (visibility.filterByAssignee && caseData.assignedTo !== user.id && caseData.assignedAuditor !== user.id) {
          return res.status(403).json({ message: 'عدم دسترسی' });
        }
        if (visibility.filterByGroup && caseData.receivingGroup !== visibility.filterByGroup) {
          return res.status(403).json({ message: 'عدم دسترسی' });
        }
      }
    }
    
    // Get all payments, ordered by date (oldest first for history)
    const payments = await storage.getPaymentsByCase(req.params.id);
    
    // Sort by date ascending for chronological history
    const sortedPayments = [...payments].sort((a, b) => {
      const dateA = a.paymentDate instanceof Date ? a.paymentDate : new Date(a.paymentDate);
      const dateB = b.paymentDate instanceof Date ? b.paymentDate : new Date(b.paymentDate);
      return dateA.getTime() - dateB.getTime();
    });
    
    res.json(sortedPayments);
  } catch (error) {
    console.error('Error fetching payment history:', error);
    res.status(500).json({ message: "خطا در دریافت تاریخچه پرداخت‌ها" });
  }
});

// Record new payment (Financial Follow-Up Form)
router.post("/:id/payments", requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    const caseData = await storage.getCase(req.params.id);
    
    if (!caseData) {
      return res.status(404).json({ message: "قضیه یافت نشد" });
    }
    
    // Check permissions - auditor or senior_auditor can record payments
    if (user.role !== 'auditor' && user.role !== 'senior_auditor' && user.role !== 'system_admin') {
      return res.status(403).json({ message: 'عدم دسترسی' });
    }
    
    const { payment_date, payment_amount, payment_type, notes } = req.body;
    
    // Validate required fields
    if (!payment_date || payment_amount === undefined || payment_amount === null) {
      return res.status(400).json({ message: "تاریخ پرداخت و مبلغ پرداخت الزامی است" });
    }
    
    // Validate and parse date - frontend sends ISO YYYY-MM-DD format (Gregorian)
    let paymentDate: Date;
    try {
      const { gregorianStringToDate } = await import('../utils/shamsiDate');
      // Frontend sends ISO YYYY-MM-DD format (Gregorian) - convert from Shamsi before submitting
      const parsedDate = gregorianStringToDate(payment_date);
      if (!parsedDate) {
        return res.status(400).json({ message: "تاریخ پرداخت نامعتبر است" });
      }
      paymentDate = parsedDate;
    } catch (error) {
      console.error('Error parsing payment date:', error);
      return res.status(400).json({ message: "تاریخ پرداخت نامعتبر است" });
    }
    
    // Validate and parse amount
    const amountPaidNum = typeof payment_amount === 'string' 
      ? parseFloat(payment_amount) 
      : (typeof payment_amount === 'number' ? payment_amount : NaN);
    
    if (isNaN(amountPaidNum) || amountPaidNum <= 0) {
      return res.status(400).json({ message: "مبلغ پرداخت نامعتبر است" });
    }
    
    // Validate payment type
    if (payment_type !== 'normal' && payment_type !== 'installment') {
      return res.status(400).json({ message: "نوع پرداخت نامعتبر است" });
    }
    
    // Create payment record (PHASE 1: Payment Traceability)
    const payment = await storage.createPayment({
      caseId: req.params.id,
      paymentDate: paymentDate,
      paymentAmount: amountPaidNum.toString(),
      paymentType: payment_type,
    });
    
    // If it's an installment payment, also create installment payment record
    if (payment_type === 'installment') {
      // Get current remaining balance to calculate remaining balance after this payment
      const reportV2 = await storage.getCaseReportV2(req.params.id);
      const report = reportV2 || await storage.getCaseReport(req.params.id);
      
      let confirmedAmount = 0;
      if (reportV2?.confirmedAmount) {
        confirmedAmount = typeof reportV2.confirmedAmount === 'string'
          ? parseFloat(reportV2.confirmedAmount.toString().replace(/,/g, '')) || 0
          : (typeof reportV2.confirmedAmount === 'number' ? reportV2.confirmedAmount : 0);
      } else if (report?.confirmedAmount) {
        confirmedAmount = typeof report.confirmedAmount === 'string'
          ? parseFloat(report.confirmedAmount.replace(/,/g, '')) || 0
          : 0;
      }
      
      // Get all payments to calculate remaining balance
      const allPayments = await storage.getPaymentsByCase(req.params.id);
      let totalPaid = 0;
      for (const p of allPayments) {
        const amount = typeof p.paymentAmount === 'string'
          ? parseFloat(p.paymentAmount) || 0
          : (typeof p.paymentAmount === 'number' ? p.paymentAmount : 0);
        totalPaid += amount;
      }
      const remainingBalance = Math.max(0, confirmedAmount - totalPaid);
      
      await storage.createInstallmentPayment({
        caseId: req.params.id,
        paymentDate: paymentDate,
        amountPaid: amountPaidNum.toString(),
        remainingBalance: remainingBalance.toString(),
        notes: notes || null,
        createdBy: user.id,
      });
    }
    
    // Log the payment creation
    await storage.createAuditLog({
      userId: user.id,
      action: 'record_payment',
      entityType: 'case',
      entityId: req.params.id,
      details: {
        caseId: caseData.caseId,
        paymentId: payment.id,
        paymentAmount: payment_amount,
        paymentType: payment_type,
        paymentDate: payment_date,
        notes: notes || null,
      },
      ipAddress: extractClientIp(req),
    });
    
    res.status(201).json(payment);
  } catch (error) {
    console.error('Error recording payment:', error);
    res.status(500).json({ message: "خطا در ثبت پرداخت" });
  }
});

// Enhanced PATCH /cases/:id to handle override fields
router.patch("/:id", requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    const oldCase = await storage.getCase(req.params.id);
    
    if (!oldCase) {
      return res.status(404).json({ message: "قضیه یافت نشد" });
    }
    
    // Check permissions
    const isAssignedAuditor = oldCase.assignedTo === user.id;
    const isSeniorAuditor = user.role === 'senior_auditor' || user.role === 'system_admin';
    
    if (!isAssignedAuditor && !isSeniorAuditor) {
      return res.status(403).json({ message: 'عدم دسترسی' });
    }
    
    // Prevent updates to approved/rejected cases unless senior
    const { CaseStatus } = await import('@shared/schema');
    if ((oldCase.status === CaseStatus.COMPLETED || oldCase.status === 'تکمیل شده') && !isSeniorAuditor) {
      return res.status(400).json({ 
        message: "نمی توان قضیه تایید شده یا رد شده را ویرایش کرد" 
      });
    }
    
    const updateData: any = {};
    
    // Handle override fields
    if (req.body.institution_info_manual !== undefined) {
      updateData.institutionInfoManual = req.body.institution_info_manual;
      updateData.institutionInfoOverriddenBy = user.id;
      updateData.institutionInfoOverriddenAt = new Date();
    }
    
    if (req.body.representative_name_manual !== undefined) {
      updateData.representativeNameManual = req.body.representative_name_manual;
    }
    
    if (req.body.representative_phone_manual !== undefined) {
      updateData.representativePhoneManual = req.body.representative_phone_manual;
    }
    
    if (req.body.institution_address_manual !== undefined) {
      updateData.institutionAddressManual = req.body.institution_address_manual;
    }
    
    // Allow other field updates
    const allowedFields = ['notes', 'status'];
    for (const field of allowedFields) {
      if (req.body[field] !== undefined) {
        updateData[field] = req.body[field];
      }
    }
    
    const updatedCase = await storage.updateCase(req.params.id, updateData);
    
    if (!updatedCase) {
      return res.status(404).json({ message: "قضیه یافت نشد" });
    }
    
    // Log override changes
    if (updateData.institutionInfoManual || updateData.representativeNameManual || 
        updateData.representativePhoneManual || updateData.institutionAddressManual) {
      await storage.createAuditLog({
        userId: user.id,
        action: 'update_case_override_fields',
        entityType: 'case',
        entityId: updatedCase.id,
        details: {
          oldValue: {
            institutionInfoManual: oldCase.institutionInfoManual,
            representativeNameManual: oldCase.representativeNameManual,
            representativePhoneManual: oldCase.representativePhoneManual,
            institutionAddressManual: oldCase.institutionAddressManual,
          },
          newValue: {
            institutionInfoManual: updatedCase.institutionInfoManual,
            representativeNameManual: updatedCase.representativeNameManual,
            representativePhoneManual: updatedCase.representativePhoneManual,
            institutionAddressManual: updatedCase.institutionAddressManual,
          },
        },
        ipAddress: extractClientIp(req),
      });
    }
    
    res.json(updatedCase);
  } catch (error) {
    console.error('Error updating case:', error);
    res.status(400).json({ message: "خطا در بروزرسانی قضیه" });
  }
});

export default router;
