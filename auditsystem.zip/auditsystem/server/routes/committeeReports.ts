/**
 * Committee Reporting Routes
 * Provides reporting and analytics endpoints for committees, assignments, and audit groups
 */

import { Router, type Request, type Response } from "express";
import { requireAuth } from "../middleware/auth";
import { extractClientIp } from "../utils/ipExtractor";
import { storage } from "../storage";
import {
  getCommitteeReport,
  getYearlyCommitteeSummary,
  getAuditGroupWorkloadReport,
  getCaseAssignmentHistoryView,
  hasReportAccess,
  getAllAuditGroupsForReporting,
} from "../services/committeeReportingService";
import { hasCommitteeManagementPermission } from "../services/committeeService";
import ExcelJS from "exceljs";
import PDFDocument from "pdfkit";
import jalaali from "jalaali-js";

const router = Router();

/**
 * Helper: Convert date to Shamsi format
 */
function toShamsiDate(date: Date): string {
  const j = jalaali.toJalaali(date);
  return `${j.jy}/${String(j.jm).padStart(2, '0')}/${String(j.jd).padStart(2, '0')}`;
}

/**
 * Helper: Get month name in Dari
 */
function getMonthName(month: number): string {
  const months = [
    'حمل', 'ثور', 'جوزا', 'سرطان', 'اسد', 'سنبله',
    'میزان', 'عقرب', 'قوس', 'جدی', 'دلو', 'حوت'
  ];
  return months[month - 1] || `ماه ${month}`;
}

/**
 * GET /api/committee-reports/committees/:id
 * Get single committee report
 */
router.get("/committees/:id", requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    
    // Check access
    if (!hasReportAccess(user)) {
      return res.status(403).json({
        message: "شما مجوز مشاهده گزارش کمیته را ندارید",
      });
    }
    
    const report = await getCommitteeReport(req.params.id);
    res.json(report);
  } catch (error: any) {
    console.error('[COMMITTEE REPORTS] Error fetching committee report:', error);
    res.status(400).json({
      message: error?.message || "خطا در دریافت گزارش کمیته",
    });
  }
});

/**
 * GET /api/committee-reports/yearly/:year
 * Get yearly committee summary
 */
router.get("/yearly/:year", requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    
    // Check access
    if (!hasReportAccess(user)) {
      return res.status(403).json({
        message: "شما مجوز مشاهده گزارش سالانه را ندارید",
      });
    }
    
    const year = parseInt(req.params.year);
    if (isNaN(year) || year < 1300 || year > 1500) {
      return res.status(400).json({
        message: "سال نامعتبر است",
      });
    }
    
    const summary = await getYearlyCommitteeSummary(year);
    res.json(summary);
  } catch (error: any) {
    console.error('[COMMITTEE REPORTS] Error fetching yearly summary:', error);
    res.status(400).json({
      message: error?.message || "خطا در دریافت گزارش سالانه",
    });
  }
});

/**
 * GET /api/committee-reports/audit-groups/:groupId
 * Get audit group workload report
 */
router.get("/audit-groups/:groupId", requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    const groupId = req.params.groupId;
    
    // Check access
    if (!hasReportAccess(user, groupId)) {
      return res.status(403).json({
        message: "شما مجوز مشاهده گزارش گروه را ندارید",
      });
    }
    
    const report = await getAuditGroupWorkloadReport(groupId);
    res.json(report);
  } catch (error: any) {
    console.error('[COMMITTEE REPORTS] Error fetching audit group report:', error);
    res.status(400).json({
      message: error?.message || "خطا در دریافت گزارش گروه",
    });
  }
});

/**
 * GET /api/committee-reports/cases/:caseId/history
 * Get case assignment history view
 */
router.get("/cases/:caseId/history", requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    
    // Get case to check access
    const caseItem = await storage.getCase(req.params.caseId);
    if (!caseItem) {
      return res.status(404).json({
        message: "قضیه یافت نشد",
      });
    }
    
    // Check access - users can see history if they have access to the case
    // Directors, Coordinators, System Admins can see all
    // Audit groups can see cases assigned to them
    if (hasCommitteeManagementPermission(user)) {
      // Full access
    } else if (user.groupId && caseItem.currentAuditGroupId === user.groupId) {
      // Group can see their cases
    } else {
      return res.status(403).json({
        message: "شما مجوز مشاهده تاریخچه اختصاص این قضیه را ندارید",
      });
    }
    
    const history = await getCaseAssignmentHistoryView(req.params.caseId);
    res.json(history);
  } catch (error: any) {
    console.error('[COMMITTEE REPORTS] Error fetching case history:', error);
    res.status(400).json({
      message: error?.message || "خطا در دریافت تاریخچه اختصاص",
    });
  }
});

/**
 * GET /api/committee-reports/audit-groups
 * Get list of audit groups for reporting
 */
router.get("/audit-groups", requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    
    // Check access
    if (!hasReportAccess(user)) {
      return res.status(403).json({
        message: "شما مجوز مشاهده لیست گروه‌ها را ندارید",
      });
    }
    
    const groups = await getAllAuditGroupsForReporting();
    res.json(groups);
  } catch (error: any) {
    console.error('[COMMITTEE REPORTS] Error fetching audit groups:', error);
    res.status(500).json({
      message: "خطا در دریافت لیست گروه‌ها",
    });
  }
});

/**
 * GET /api/committee-reports/committees/:id/export
 * Export committee report to Excel
 */
router.get("/committees/:id/export", requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    const format = (req.query.format as string) || 'excel';
    
    // Check access
    if (!hasReportAccess(user)) {
      return res.status(403).json({
        message: "شما مجوز صادر کردن گزارش کمیته را ندارید",
      });
    }
    
    const report = await getCommitteeReport(req.params.id);
    
    if (format === 'excel') {
      // Create Excel workbook
      const workbook = new ExcelJS.Workbook();
      const worksheet = workbook.addWorksheet('گزارش کمیته');
      
      // Set RTL direction
      worksheet.views = [{ rightToLeft: true }];
      
      // Add committee info
      worksheet.addRow(['گزارش کمیته']);
      worksheet.mergeCells('A1:D1');
      worksheet.getRow(1).font = { name: 'Arial', size: 16, bold: true };
      worksheet.getRow(1).alignment = { horizontal: 'right', vertical: 'middle' };
      
      worksheet.addRow(['عنوان کمیته:', report.committee.title]);
      worksheet.addRow(['سال:', report.committee.year]);
      worksheet.addRow(['ماه:', getMonthName(report.committee.month)]);
      worksheet.addRow(['وضعیت:', report.committee.status]);
      worksheet.addRow(['تاریخ ایجاد:', toShamsiDate(report.committee.createdAt)]);
      if (report.committee.approvedAt) {
        worksheet.addRow(['تاریخ تایید:', toShamsiDate(report.committee.approvedAt)]);
      }
      worksheet.addRow(['ایجاد شده توسط:', report.committee.createdByName || 'نامشخص']);
      if (report.committee.approvedByName) {
        worksheet.addRow(['تایید شده توسط:', report.committee.approvedByName]);
      }
      
      worksheet.addRow([]); // Empty row
      
      // Add summary
      worksheet.addRow(['خلاصه']);
      worksheet.mergeCells('A10:D10');
      worksheet.getRow(10).font = { name: 'Arial', size: 14, bold: true };
      worksheet.addRow(['تعداد کل قضایا:', report.summary.totalCases]);
      worksheet.addRow(['قضایای اختصاص داده شده از طریق کمیته:', report.summary.casesBySource.committee]);
      worksheet.addRow(['قضایای اختصاص داده شده مستقیم:', report.summary.casesBySource.direct]);
      
      worksheet.addRow([]); // Empty row
      
      // Add cases table
      const headers = [
        'شماره قضیه',
        'نام نهاد',
        'گروه بررسی',
        'تاریخ اختصاص',
        'منبع اختصاص',
        'وضعیت فعلی',
        'اختصاص داده شده توسط',
      ];
      
      const headerRow = worksheet.addRow(headers);
      headerRow.font = { name: 'Arial', size: 11, bold: true };
      headerRow.alignment = { horizontal: 'right', vertical: 'middle' };
      headerRow.fill = {
        type: 'pattern',
        pattern: 'solid',
        fgColor: { argb: 'FFD9D9D9' }
      };
      
      // Add data rows
      report.cases.forEach((caseItem) => {
        const sourceText = caseItem.assignmentSource === 'COMMITTEE' 
          ? 'کمیته' 
          : caseItem.assignmentSource === 'DIRECT' 
          ? 'مستقیم' 
          : 'اختصاص مجدد';
        
        worksheet.addRow([
          caseItem.caseNumber || caseItem.caseId,
          caseItem.entityName,
          caseItem.auditGroupName || 'نامشخص',
          toShamsiDate(caseItem.assignmentDate),
          sourceText,
          caseItem.caseCurrentStatus,
          caseItem.assignedByName || 'نامشخص',
        ]);
      });
      
      // Set column widths
      worksheet.getColumn(1).width = 15;
      worksheet.getColumn(2).width = 30;
      worksheet.getColumn(3).width = 20;
      worksheet.getColumn(4).width = 15;
      worksheet.getColumn(5).width = 15;
      worksheet.getColumn(6).width = 20;
      worksheet.getColumn(7).width = 20;
      
      // RTL alignment for all cells
      worksheet.eachRow((row) => {
        row.eachCell((cell) => {
          cell.alignment = { horizontal: 'right', vertical: 'middle' };
        });
      });
      
      // Set response headers
      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      res.setHeader('Content-Disposition', `attachment; filename="committee-report-${report.committee.id}.xlsx"`);
      
      // Write to response
      await workbook.xlsx.write(res);
      res.end();
    } else {
      // PDF export (simplified for now)
      return res.status(400).json({
        message: "PDF export not yet implemented",
      });
    }
  } catch (error: any) {
    console.error('[COMMITTEE REPORTS] Error exporting committee report:', error);
    res.status(400).json({
      message: error?.message || "خطا در صادر کردن گزارش",
    });
  }
});

/**
 * GET /api/committee-reports/yearly/:year/export
 * Export yearly summary to Excel
 */
router.get("/yearly/:year/export", requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    
    // Check access
    if (!hasReportAccess(user)) {
      return res.status(403).json({
        message: "شما مجوز صادر کردن گزارش سالانه را ندارید",
      });
    }
    
    const year = parseInt(req.params.year);
    if (isNaN(year) || year < 1300 || year > 1500) {
      return res.status(400).json({
        message: "سال نامعتبر است",
      });
    }
    
    const summary = await getYearlyCommitteeSummary(year);
    
    // Create Excel workbook
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet(`گزارش سالانه ${year}`);
    
    // Set RTL direction
    worksheet.views = [{ rightToLeft: true }];
    
    // Add title
    worksheet.addRow([`گزارش سالانه کمیته‌ها - سال ${year}`]);
    worksheet.mergeCells('A1:D1');
    worksheet.getRow(1).font = { name: 'Arial', size: 16, bold: true };
    worksheet.getRow(1).alignment = { horizontal: 'right', vertical: 'middle' };
    
    worksheet.addRow([]);
    
    // Add summary
    worksheet.addRow(['خلاصه']);
    worksheet.mergeCells('A3:D3');
    worksheet.getRow(3).font = { name: 'Arial', size: 14, bold: true };
    worksheet.addRow(['تعداد کل کمیته‌ها:', summary.totalCommittees]);
    worksheet.addRow(['قضایای اختصاص داده شده از طریق کمیته:', summary.totalCasesAssignedViaCommittees]);
    worksheet.addRow(['قضایای اختصاص داده شده مستقیم:', summary.totalDirectAssignments]);
    
    worksheet.addRow([]);
    
    // Add monthly breakdown table
    const headers = ['ماه', 'تعداد کمیته‌ها', 'تعداد قضایای اختصاص داده شده'];
    const headerRow = worksheet.addRow(headers);
    headerRow.font = { name: 'Arial', size: 11, bold: true };
    headerRow.alignment = { horizontal: 'right', vertical: 'middle' };
    headerRow.fill = {
      type: 'pattern',
      pattern: 'solid',
      fgColor: { argb: 'FFD9D9D9' }
    };
    
    summary.monthlyBreakdown.forEach((month) => {
      worksheet.addRow([
        getMonthName(month.month),
        month.committeeCount,
        month.casesAssignedCount,
      ]);
    });
    
    // Set column widths
    worksheet.getColumn(1).width = 20;
    worksheet.getColumn(2).width = 20;
    worksheet.getColumn(3).width = 30;
    
    // RTL alignment
    worksheet.eachRow((row) => {
      row.eachCell((cell) => {
        cell.alignment = { horizontal: 'right', vertical: 'middle' };
      });
    });
    
    // Set response headers
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename="yearly-summary-${year}.xlsx"`);
    
    // Write to response
    await workbook.xlsx.write(res);
    res.end();
  } catch (error: any) {
    console.error('[COMMITTEE REPORTS] Error exporting yearly summary:', error);
    res.status(400).json({
      message: error?.message || "خطا در صادر کردن گزارش سالانه",
    });
  }
});

/**
 * GET /api/committee-reports/audit-groups/:groupId/export
 * Export audit group workload report to Excel
 */
router.get("/audit-groups/:groupId/export", requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    const groupId = req.params.groupId;
    
    // Check access
    if (!hasReportAccess(user, groupId)) {
      return res.status(403).json({
        message: "شما مجوز صادر کردن گزارش گروه را ندارید",
      });
    }
    
    const report = await getAuditGroupWorkloadReport(groupId);
    
    // Create Excel workbook
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet(`گزارش گروه ${report.auditGroupName}`);
    
    // Set RTL direction
    worksheet.views = [{ rightToLeft: true }];
    
    // Add title
    worksheet.addRow([`گزارش بار کاری گروه: ${report.auditGroupName}`]);
    worksheet.mergeCells('A1:D1');
    worksheet.getRow(1).font = { name: 'Arial', size: 16, bold: true };
    worksheet.getRow(1).alignment = { horizontal: 'right', vertical: 'middle' };
    
    worksheet.addRow([]);
    
    // Add summary
    worksheet.addRow(['خلاصه']);
    worksheet.mergeCells('A3:D3');
    worksheet.getRow(3).font = { name: 'Arial', size: 14, bold: true };
    worksheet.addRow(['قضایای دریافت شده از طریق کمیته:', report.totalCasesViaCommittees]);
    worksheet.addRow(['قضایای اختصاص داده شده مستقیم:', report.totalDirectAssignments]);
    worksheet.addRow(['قضایای در انتظار بررسی:', report.casesPendingReview]);
    worksheet.addRow(['قضایای تکمیل شده:', report.casesCompleted]);
    worksheet.addRow(['میانگین قضایا به ازای هر کمیته:', report.averageCasesPerCommittee.toFixed(2)]);
    
    worksheet.addRow([]);
    
    // Add committees table
    if (report.committees.length > 0) {
      worksheet.addRow(['کمیته‌های مرتبط']);
      worksheet.mergeCells('A10:D10');
      worksheet.getRow(10).font = { name: 'Arial', size: 14, bold: true };
      
      const headers = ['عنوان کمیته', 'تعداد قضایا'];
      const headerRow = worksheet.addRow(headers);
      headerRow.font = { name: 'Arial', size: 11, bold: true };
      headerRow.alignment = { horizontal: 'right', vertical: 'middle' };
      headerRow.fill = {
        type: 'pattern',
        pattern: 'solid',
        fgColor: { argb: 'FFD9D9D9' }
      };
      
      report.committees.forEach((committee) => {
        worksheet.addRow([
          committee.committeeTitle,
          committee.casesCount,
        ]);
      });
    }
    
    // Set column widths
    worksheet.getColumn(1).width = 30;
    worksheet.getColumn(2).width = 20;
    
    // RTL alignment
    worksheet.eachRow((row) => {
      row.eachCell((cell) => {
        cell.alignment = { horizontal: 'right', vertical: 'middle' };
      });
    });
    
    // Set response headers
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename="audit-group-workload-${groupId}.xlsx"`);
    
    // Write to response
    await workbook.xlsx.write(res);
    res.end();
  } catch (error: any) {
    console.error('[COMMITTEE REPORTS] Error exporting audit group report:', error);
    res.status(400).json({
      message: error?.message || "خطا در صادر کردن گزارش گروه",
    });
  }
});

export default router;

