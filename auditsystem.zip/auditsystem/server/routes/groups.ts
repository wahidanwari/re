import { Router, type Request, type Response } from "express";
import { storage } from "../storage";
import { insertGroupSchema, insertGroupMemberSchema, insertGroupTargetSchema, groupTargets } from "@shared/schema";
import { db } from "../db";
import { eq, and, inArray } from "drizzle-orm";
import { requireAuth } from "../middleware/auth";
import { requirePermission, requireAnyPermission } from "../middleware/permissions";
import { extractClientIp } from "../utils/ipExtractor";
import jalaali from "jalaali-js";

const router = Router();

// Get all groups
router.get("/", requireAuth, async (req: Request, res: Response) => {
  try {
    // User data is already refreshed by refreshUserData middleware
    const user = req.user as any;
    if (!user || !user.id) {
      return res.status(401).json({ message: 'احراز هویت نشده' });
    }
    
    // CRITICAL RBAC ENFORCEMENT: Use unified permission helper
    const { getGroupVisibility } = await import('../utils/permissionHelpers');
    const visibility = await getGroupVisibility(user);
    
    let groups = await storage.getGroups();
    
    // Apply department filter if requested (for user creation dropdown)
    const departmentOnly = req.query.department === 'audit';
    if (departmentOnly) {
      // Filter groups to only those with "سنجش" or "بررسی" in name, or code starting with "AUD"
      const filteredGroups = groups.filter(group => {
        const name = (group.name || '').toLowerCase();
        const code = (group.code || '').toUpperCase();
        return name.includes('سنجش') || 
               name.includes('بررسی') ||
               code.startsWith('AUD') ||
               code.startsWith('GRP') ||
               name.includes('audit');
      });
      // If filter returns empty, return all groups (less restrictive)
      groups = filteredGroups.length > 0 ? filteredGroups : groups;
    }
    
    // Apply permission-based filtering
    if (!visibility.canViewAll && visibility.requiresFiltering) {
      if (visibility.filterByGroup) {
        // Senior auditor: Only show their own group
        groups = groups.filter(group => group.id === visibility.filterByGroup);
      } else {
        // No access
        groups = [];
      }
    }
    // If canViewAll is true, user sees all groups (no additional filtering needed)
    
    res.json(groups);
  } catch (error) {
    console.error('Error fetching groups:', error);
    res.status(500).json({ message: "خطا در دریافت لیست گروه‌ها" });
  }
});

// Get group by ID
router.get("/:id", requireAuth, async (req: Request, res: Response) => {
  try {
    // User data is already refreshed by refreshUserData middleware
    const user = req.user as any;
    if (!user || !user.id) {
      return res.status(401).json({ message: 'احراز هویت نشده' });
    }
    
    const group = await storage.getGroup(req.params.id);
    if (!group) {
      return res.status(404).json({ message: "گروه یافت نشد" });
    }
    
    // Use unified permission helper
    const { getGroupVisibility } = await import('../utils/permissionHelpers');
    const visibility = await getGroupVisibility(user);
    
    // System admin can access any group
    if (user.role !== 'system_admin') {
      // If coordinator or has groups:manage, can access any group
      if (visibility.canViewAll) {
        // Access granted, continue
      } else if (visibility.filterByGroup) {
        // Senior auditor: Only allow access to their own group
        if (group.id !== visibility.filterByGroup) {
          return res.status(403).json({ message: 'شما فقط می‌توانید به گروه خود دسترسی داشته باشید' });
        }
      } else {
        // No access
        return res.status(403).json({ message: 'عدم دسترسی' });
      }
    }
    
    res.json(group);
  } catch (error) {
    res.status(500).json({ message: "خطا در دریافت اطلاعات گروه" });
  }
});

// Get auditors for a group (includes both auditors and senior_auditors for self-assignment)
router.get("/:id/auditors", requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    const groupId = req.params.id;
    
    // RBAC enforcement
    if (user.role !== 'system_admin' && user.role !== 'director') {
      const { getGroupVisibility } = await import('../utils/permissionHelpers');
      const { isCoordinator } = await import('../services/permissionService');
      const visibility = await getGroupVisibility(user);
      const coordinatorCheck = await isCoordinator(user.id);
      
      // Senior Auditor can only fetch auditors from their own group
      if (user.role === 'senior_auditor') {
        if (!coordinatorCheck && groupId !== user.groupId) {
          return res.status(403).json({ 
            message: 'شما فقط می‌توانید بررس‌های گروه خود را مشاهده کنید' 
          });
        }
      } else {
        // Other roles don't have access
        return res.status(403).json({ message: 'عدم دسترسی' });
      }
    }
    
    // Verify group exists
    const group = await storage.getGroup(groupId);
    if (!group) {
      return res.status(404).json({ message: "گروه یافت نشد" });
    }
    
    // Get group members
    const members = await storage.getGroupMembers(groupId);
    
    // Fetch user details and filter for auditors and senior_auditors
    // CRITICAL: Senior Auditors can assign cases to themselves, so include senior_auditors
    const auditors = await Promise.all(
      members.map(async (member) => {
        const memberUser = await storage.getUser(member.userId);
        // Include active auditors AND senior_auditors (for self-assignment)
        if (!memberUser || !memberUser.isActive) {
          return null;
        }
        // Include both auditors and senior_auditors
        if (memberUser.role !== 'auditor' && memberUser.role !== 'senior_auditor') {
          return null;
        }
        return {
          id: memberUser.id,
          auditId: memberUser.auditId,
          fullName: memberUser.fullName,
          role: memberUser.role,
          groupId: memberUser.groupId,
        };
      })
    );
    
    // Filter out null entries
    const activeAuditors = auditors.filter(a => a !== null);
    
    res.json(activeAuditors);
  } catch (error) {
    console.error('Error fetching group auditors:', error);
    res.status(500).json({ message: "خطا در دریافت بررس‌های گروه" });
  }
});

// Get group members
router.get("/:id/members", requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    const groupId = req.params.id;
    
    // RBAC: Senior Auditor can only see members of their own group
    if (user.role === 'senior_auditor' && user.groupId) {
      const userPackages = (user.permissionPackages || []) as string[];
      const isCoordinator = userPackages.includes('acting_coordinator');
      
      // If not coordinator, restrict to own group
      if (!isCoordinator && groupId !== user.groupId) {
        return res.status(403).json({ message: 'شما فقط می‌توانید اعضای گروه خود را مشاهده کنید' });
      }
    }
    
    // Get group members (already filtered by isActive in storage)
    const members = await storage.getGroupMembers(groupId);
    
    // Fetch user details for each member and filter by active users only
    const membersWithUsers = await Promise.all(
      members.map(async (member) => {
        const user = await storage.getUser(member.userId);
        // Only include active users
        if (!user || !user.isActive) {
          return null;
        }
        return {
          ...member,
          user: {
            id: user.id,
            auditId: user.auditId,
            fullName: user.fullName,
            role: user.role,
          },
        };
      })
    );
    
    // Filter out null entries (inactive users)
    const activeMembersWithUsers = membersWithUsers.filter(m => m !== null);
    
    res.json(activeMembersWithUsers);
  } catch (error) {
    console.error('Error fetching group members:', error);
    res.status(500).json({ message: "خطا در دریافت اعضای گروه" });
  }
});

// Get group targets
router.get("/:id/targets", requireAuth, async (req: Request, res: Response) => {
  try {
    const targets = await storage.getGroupTargets(req.params.id);
    res.json(targets);
  } catch (error) {
    res.status(500).json({ message: "خطا در دریافت اهداف گروه" });
  }
});

// Get group statistics (KPIs)
router.get("/:id/statistics", requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    const groupId = req.params.id;
    
    // RBAC: Check access to this group
    const { getGroupVisibility } = await import('../utils/permissionHelpers');
    const visibility = await getGroupVisibility(user);
    
    // Verify group exists
    const group = await storage.getGroup(groupId);
    if (!group) {
      return res.status(404).json({ message: "گروه یافت نشد" });
    }
    
    // Check permissions
    if (user.role !== 'system_admin' && !visibility.canViewAll) {
      if (visibility.filterByGroup && groupId !== visibility.filterByGroup) {
        return res.status(403).json({ message: 'شما فقط می‌توانید آمار گروه خود را مشاهده کنید' });
      } else if (!visibility.filterByGroup) {
        return res.status(403).json({ message: 'عدم دسترسی' });
      }
    }
    
    // Get query parameters for date filtering
    const monthShamsi = req.query.monthShamsi ? parseInt(req.query.monthShamsi as string) : null;
    const yearShamsi = req.query.yearShamsi ? parseInt(req.query.yearShamsi as string) : null;
    
    // Get all cases assigned to this group
    const allCases = await storage.getCasesByGroup(groupId);
    
    // Filter by date range if provided (default: current month)
    let filteredCases = allCases;
    if (monthShamsi && yearShamsi) {
      filteredCases = allCases.filter(c => {
        if (!c.createdAt) return false;
        const j = jalaali.toJalaali(new Date(c.createdAt));
        return j.jm === monthShamsi && j.jy === yearShamsi;
      });
    } else if (yearShamsi) {
      filteredCases = allCases.filter(c => {
        if (!c.createdAt) return false;
        const j = jalaali.toJalaali(new Date(c.createdAt));
        return j.jy === yearShamsi;
      });
    } else {
      // Default: current month
      const now = new Date();
      const jNow = jalaali.toJalaali(now);
      filteredCases = allCases.filter(c => {
        if (!c.createdAt) return false;
        const j = jalaali.toJalaali(new Date(c.createdAt));
        return j.jm === jNow.jm && j.jy === jNow.jy;
      });
    }
    
    // Calculate statistics
    const totalAssignedCases = filteredCases.length;
    
    // Completed cases: status is 'تکمیل شده' OR has completed report
    const completedCases = filteredCases.filter(c => {
      if (c.status === 'تکمیل شده' || c.status === 'COMPLETED') return true;
      // Check if report is completed
      // We'll need to check reports separately since we can't join easily here
      return false;
    });
    
    // Check report completion status for cases
    const { db } = await import('../db');
    const { caseReportsV2 } = await import('@shared/schema');
    const { eq, inArray } = await import('drizzle-orm');
    
    const caseIds = filteredCases.map(c => c.id);
    let completedCaseIds = new Set<string>();
    
    if (caseIds.length > 0) {
      const completedReports = await db
        .select({ caseId: caseReportsV2.caseId })
        .from(caseReportsV2)
        .where(
          and(
            inArray(caseReportsV2.caseId, caseIds),
            eq(caseReportsV2.status, 'completed')
          )
        );
      
      completedCaseIds = new Set(completedReports.map(r => r.caseId));
    }
    
    // Count truly completed cases
    const trulyCompleted = filteredCases.filter(c => 
      c.status === 'تکمیل شده' || c.status === 'COMPLETED' || completedCaseIds.has(c.id)
    );
    
    const pendingCases = totalAssignedCases - trulyCompleted.length;
    
    // Get group members count
    const members = await storage.getGroupMembers(groupId);
    const activeMembers = members.filter(m => m.isActive);
    
    // Get member details to filter active users
    const memberUserIds = activeMembers.map(m => m.userId);
    const activeUsers = await Promise.all(
      memberUserIds.map(id => storage.getUser(id))
    );
    const membersCount = activeUsers.filter(u => u && u.isActive).length;
    
    // Get targets for current year (default) or specified year
    const targetYear = yearShamsi || jalaali.toJalaali(new Date()).jy;
    const targets = await storage.getGroupTargets(groupId);
    const currentYearTarget = targets.find(t => parseInt(t.yearShamsi) === targetYear);
    
    // Calculate target achievement
    let targetAchieved = null;
    if (currentYearTarget && currentYearTarget.targetCaseCount) {
      // For monthly view, calculate progress
      if (monthShamsi) {
        // Get all completed cases for the year up to this month
        const yearCases = allCases.filter(c => {
          if (!c.createdAt) return false;
          const j = jalaali.toJalaali(new Date(c.createdAt));
          return j.jy === targetYear && j.jm <= monthShamsi;
        });
        
        const yearCompleted = yearCases.filter(c => 
          c.status === 'تکمیل شده' || c.status === 'COMPLETED' || completedCaseIds.has(c.id)
        );
        
        // Monthly target (assuming equal distribution)
        const monthlyTarget = Math.ceil(currentYearTarget.targetCaseCount / 12);
        const achievedCount = yearCompleted.length;
        
        targetAchieved = {
          target: monthlyTarget,
          achieved: achievedCount,
          yearTarget: currentYearTarget.targetCaseCount,
          yearAchieved: yearCompleted.length,
          percentComplete: monthlyTarget > 0 ? Math.round((achievedCount / monthlyTarget) * 100) : 0,
          yearPercentComplete: currentYearTarget.targetCaseCount > 0 
            ? Math.round((yearCompleted.length / currentYearTarget.targetCaseCount) * 100) 
            : 0,
        };
      } else {
        // Yearly view
        const yearCases = allCases.filter(c => {
          if (!c.createdAt) return false;
          const j = jalaali.toJalaali(new Date(c.createdAt));
          return j.jy === targetYear;
        });
        
        const yearCompleted = yearCases.filter(c => 
          c.status === 'تکمیل شده' || c.status === 'COMPLETED' || completedCaseIds.has(c.id)
        );
        
        targetAchieved = {
          target: currentYearTarget.targetCaseCount,
          achieved: yearCompleted.length,
          percentComplete: currentYearTarget.targetCaseCount > 0 
            ? Math.round((yearCompleted.length / currentYearTarget.targetCaseCount) * 100) 
            : 0,
        };
      }
    }
    
    // Get member activity (cases handled by each member)
    const memberActivity = await Promise.all(
      activeMembers.map(async (member) => {
        const userCases = filteredCases.filter(c => c.assignedTo === member.userId);
        const userCompleted = userCases.filter(c => 
          c.status === 'تکمیل شده' || c.status === 'COMPLETED' || completedCaseIds.has(c.id)
        );
        const user = await storage.getUser(member.userId);
        return {
          userId: member.userId,
          userName: user?.fullName || '—',
          auditId: user?.auditId || '—',
          role: user?.role || '—',
          assignedRole: member.assignedRole,
          casesHandled: userCases.length,
          casesCompleted: userCompleted.length,
          isActive: user?.isActive || false,
        };
      })
    );
    
    res.json({
      groupId,
      groupName: group.name,
      period: {
        monthShamsi: monthShamsi || jalaali.toJalaali(new Date()).jm,
        yearShamsi: yearShamsi || jalaali.toJalaali(new Date()).jy,
      },
      statistics: {
        totalAssignedCases,
        completedCases: trulyCompleted.length,
        pendingCases,
        membersCount,
      },
      targetAchieved,
      memberActivity,
    });
  } catch (error) {
    console.error('Error fetching group statistics:', error);
    res.status(500).json({ message: "خطا در دریافت آمار گروه" });
  }
});

// Create group (requires permission)
router.post("/", requireAuth, requirePermission('groups:manage'), async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    const validatedData = insertGroupSchema.parse(req.body);
    const newGroup = await storage.createGroup(validatedData);
    
    // Automatically assign existing department-level targets to the new group
    // Get all other active groups
    const allGroups = await storage.getGroups();
    const otherActiveGroups = allGroups.filter(g => g.isActive && g.id !== newGroup.id);
    
    if (otherActiveGroups.length > 0) {
      // Get targets for all other groups
      const allTargets: Array<{ groupId: string; target: any }> = [];
      for (const group of otherActiveGroups) {
        const groupTargets = await storage.getGroupTargets(group.id);
        for (const target of groupTargets) {
          allTargets.push({ groupId: group.id, target });
        }
      }
      
      // Find common targets (targets that exist for multiple groups with same values)
      // This indicates department-level targets
      const targetMap = new Map<string, { target: any; groupCount: number; groups: string[] }>();
      
      for (const { groupId, target } of allTargets) {
        const key = `${target.yearShamsi}_${target.targetCaseCount || 'null'}_${target.targetMonetary || 'null'}`;
        if (!targetMap.has(key)) {
          targetMap.set(key, {
            target,
            groupCount: 0,
            groups: []
          });
        }
        const entry = targetMap.get(key)!;
        if (!entry.groups.includes(groupId)) {
          entry.groupCount++;
          entry.groups.push(groupId);
        }
      }
      
      // Assign targets that exist for at least 2 other groups (indicating department-level targets)
      // Or assign targets for the current year if they exist for any other group
      const currentYear = jalaali.toJalaali(new Date()).jy;
      const assignedTargets = [];
      
      for (const [key, entry] of targetMap.entries()) {
        const yearShamsi = parseInt(entry.target.yearShamsi);
        const isCurrentYear = yearShamsi === currentYear;
        const isCommonTarget = entry.groupCount >= 2;
        
        // Assign if it's a common target (exists for 2+ groups) OR if it's for current year and exists for at least one group
        if (isCommonTarget || (isCurrentYear && entry.groupCount >= 1)) {
          try {
            const targetData = {
              groupId: newGroup.id,
              yearShamsi: entry.target.yearShamsi,
              targetCaseCount: entry.target.targetCaseCount,
              targetMonetary: entry.target.targetMonetary,
              setBy: user.id,
            };
            
            const validatedTargetData = insertGroupTargetSchema.parse(targetData);
            const newTarget = await storage.setGroupTarget(validatedTargetData);
            assignedTargets.push(newTarget);
          } catch (targetError) {
            console.error(`Failed to assign target to new group ${newGroup.id}:`, targetError);
            // Continue with other targets even if one fails
          }
        }
      }
      
      if (assignedTargets.length > 0) {
        console.log(`Assigned ${assignedTargets.length} existing target(s) to new group ${newGroup.id}`);
      }
    }
    
    await storage.createAuditLog({
      userId: user.id,
      action: 'create_group',
      entityType: 'group',
      entityId: newGroup.id,
      newValue: newGroup,
      ipAddress: extractClientIp(req),
    });
    
    res.status(201).json(newGroup);
  } catch (error: any) {
    console.error(error);
    
    // Check for duplicate key error (unique constraint violation)
    if (error.code === '23505') {
      // PostgreSQL unique constraint violation
      if (error.constraint === 'groups_code_unique' || error.detail?.includes('code')) {
        return res.status(409).json({ 
          message: `کد گروه "${req.body.code}" قبلاً استفاده شده است. لطفاً کد دیگری انتخاب کنید.` 
        });
      }
      if (error.constraint === 'groups_name_key' || error.detail?.includes('name')) {
        return res.status(409).json({ 
          message: `نام گروه "${req.body.name}" قبلاً استفاده شده است. لطفاً نام دیگری انتخاب کنید.` 
        });
      }
    }
    
    res.status(400).json({ message: "خطا در ایجاد گروه" });
  }
});

// Update group (requires permission)
router.put("/:id", requireAuth, requirePermission('groups:manage'), async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    const group = await storage.getGroup(req.params.id);
    if (!group) {
      return res.status(404).json({ message: "گروه یافت نشد" });
    }
    
    // System admin can update any group
    if (user.role !== 'system_admin') {
      // Use unified permission helper
      const { getGroupVisibility } = await import('../utils/permissionHelpers');
      const { isCoordinator } = await import('../services/permissionService');
      const visibility = await getGroupVisibility(user);
      const coordinatorCheck = await isCoordinator(user.id);
      
      // Coordinator or users with groups:manage can update any group
      if (coordinatorCheck || visibility.canViewAll) {
        // Access granted, continue
      } else if (visibility.filterByGroup) {
        // Senior auditor: Only allow updating their own group
        if (group.id !== visibility.filterByGroup) {
          return res.status(403).json({ message: 'شما فقط می‌توانید گروه خود را ویرایش کنید' });
        }
      } else {
        // No access
        return res.status(403).json({ message: 'عدم دسترسی' });
      }
    }
    
    const validatedData = insertGroupSchema.partial().parse(req.body);
    const updatedGroup = await storage.updateGroup(req.params.id, validatedData);
    
    if (!updatedGroup) {
      return res.status(500).json({ message: "خطا در بروز رسانی گروه" });
    }
    
    await storage.createAuditLog({
      userId: user.id,
      action: 'update_group',
      entityType: 'group',
      entityId: updatedGroup.id,
      oldValue: group,
      newValue: updatedGroup,
      ipAddress: extractClientIp(req),
    });
    
    res.json(updatedGroup);
  } catch (error) {
    console.error(error);
    res.status(400).json({ message: "خطا در بروز رسانی گروه" });
  }
});

// Delete group (soft delete - requires permission)
router.delete("/:id", requireAuth, requirePermission('groups:manage'), async (req: Request, res: Response) => {
  try {
    const group = await storage.getGroup(req.params.id);
    if (!group) {
      return res.status(404).json({ message: "گروه یافت نشد" });
    }
    
    const success = await storage.deleteGroup(req.params.id);
    
    if (!success) {
      return res.status(500).json({ message: "خطا در حذف گروه" });
    }
    
    await storage.createAuditLog({
      userId: (req.user as any).id,
      action: 'delete_group',
      entityType: 'group',
      entityId: req.params.id,
      oldValue: group,
      ipAddress: extractClientIp(req),
    });
    
    res.json({ message: "گروه با موفقیت حذف شد" });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "خطا در حذف گروه" });
  }
});

// Assign member to group (requires permission)
router.post("/:id/members", requireAuth, requirePermission('groups:manage'), async (req: Request, res: Response) => {
  try {
    const { userId, role } = req.body;
    
    if (!userId) {
      return res.status(400).json({ message: "آی دی کاربر الزامی است" });
    }
    
    const currentUser = req.user as any;
    
    // Verify target user exists
    const targetUser = await storage.getUser(userId);
    if (!targetUser) {
      return res.status(404).json({ message: "کاربر یافت نشد" });
    }
    
    // Verify group exists
    const group = await storage.getGroup(req.params.id);
    if (!group) {
      return res.status(404).json({ message: "گروه یافت نشد" });
    }
    
    // System admin can add members to any group
    if (currentUser.role !== 'system_admin') {
      // If senior_auditor, only allow adding members to their own group
      if (currentUser.role === 'senior_auditor' && currentUser.groupId) {
        if (req.params.id !== currentUser.groupId) {
          return res.status(403).json({ message: 'شما فقط می‌توانید به گروه خود عضو اضافه کنید' });
        }
      }
    }
    
    // Validate role is either 'auditor' or 'senior_auditor' (General Group Manager)
    const validRoles = ['auditor', 'senior_auditor'];
    const assignedRole = role || 'auditor';
    
    if (!validRoles.includes(assignedRole)) {
      return res.status(400).json({ message: "نقش باید 'بررس' یا 'مدیر عمومی گروه' باشد" });
    }
    
    const memberData = {
      groupId: req.params.id,
      userId,
      assignedRole: assignedRole,
    };
    
    const validatedData = insertGroupMemberSchema.parse(memberData);
    const newMember = await storage.addGroupMember(validatedData);
    
    // CRITICAL: Synchronize user.groupId with group membership
    // Update the user's groupId field to match the group they're being added to
    await storage.updateUser(userId, {
      groupId: req.params.id,
    });
    
    await storage.createAuditLog({
      userId: currentUser.id,
      action: 'add_group_member',
      entityType: 'group_member',
      entityId: newMember.id,
      details: {
        groupId: req.params.id,
        userId,
        assignedRole,
        userGroupIdUpdated: true, // Track that user.groupId was synchronized
      },
      ipAddress: extractClientIp(req),
    });
    
    // Return updated group with all members for frontend sync
    const updatedGroup = await storage.getGroup(req.params.id);
    const allMembers = await storage.getGroupMembers(req.params.id);
    
    // Get user details for each member
    const membersWithUsers = await Promise.all(
      allMembers.map(async (member) => {
        const memberUser = await storage.getUser(member.userId);
        return {
          ...member,
          user: memberUser ? {
            id: memberUser.id,
            fullName: memberUser.fullName,
            auditId: memberUser.auditId,
            role: memberUser.role,
            groupId: memberUser.groupId,
          } : null,
        };
      })
    );
    
    res.status(201).json({
      member: newMember,
      group: updatedGroup,
      members: membersWithUsers,
    });
  } catch (error) {
    console.error(error);
    res.status(400).json({ message: "خطا در افزودن عضو به گروه" });
  }
});

// Remove member from group (requires permission)
router.delete("/:groupId/members/:userId", requireAuth, requirePermission('groups:manage'), async (req: Request, res: Response) => {
  try {
    const { groupId, userId } = req.params;
    
    const success = await storage.removeGroupMember(groupId, userId);
    
    if (!success) {
      return res.status(404).json({ message: "عضو گروه یافت نشد" });
    }
    
    // CRITICAL: Check if user has any other active group memberships
    // If not, clear the user's groupId field
    const user = await storage.getUser(userId);
    if (user) {
      // Query all active group memberships for this user
      const { db } = await import('../db');
      const { groupMembers } = await import('@shared/schema');
      const { eq, and } = await import('drizzle-orm');
      
      const allUserMemberships = await db
        .select()
        .from(groupMembers)
        .where(and(eq(groupMembers.userId, userId), eq(groupMembers.isActive, true)));
      
      const remainingMemberships = allUserMemberships.filter(m => m.groupId !== groupId);
      
      if (remainingMemberships.length === 0) {
        // User has no other active group memberships, clear groupId
        await storage.updateUser(userId, {
          groupId: null,
        });
      } else if (user.groupId === groupId) {
        // User's current groupId matches the removed group, update to first remaining group
        await storage.updateUser(userId, {
          groupId: remainingMemberships[0].groupId,
        });
      }
    }
    
    await storage.createAuditLog({
      userId: (req.user as any).id,
      action: 'remove_group_member',
      entityType: 'group_member',
      entityId: `${groupId}-${userId}`,
      details: {
        groupId,
        userId,
        userGroupIdUpdated: true, // Track that user.groupId was synchronized
      },
      ipAddress: extractClientIp(req),
    });
    
    // Return updated group with all members for frontend sync
    const updatedGroup = await storage.getGroup(groupId);
    const allMembers = await storage.getGroupMembers(groupId);
    
    // Get user details for each member
    const membersWithUsers = await Promise.all(
      allMembers.map(async (member) => {
        const memberUser = await storage.getUser(member.userId);
        return {
          ...member,
          user: memberUser ? {
            id: memberUser.id,
            fullName: memberUser.fullName,
            auditId: memberUser.auditId,
            role: memberUser.role,
            groupId: memberUser.groupId,
          } : null,
        };
      })
    );
    
    res.json({ 
      message: "عضو از گروه حذف شد",
      group: updatedGroup,
      members: membersWithUsers,
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "خطا در حذف عضو از گروه" });
  }
});

// Set department-level targets (bulk operation - propagates to all groups)
router.post("/targets/department", requireAuth, requirePermission('groups:set_targets'), async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    
    const { yearShamsi, targetCaseCount, targetMonetary } = req.body;
    
    if (!yearShamsi) {
      return res.status(400).json({ message: "سال شمسی الزامی است" });
    }
    
    // Get all active groups
    const allGroups = await storage.getGroups();
    const activeGroups = allGroups.filter(g => g.isActive);
    
    if (activeGroups.length === 0) {
      return res.status(400).json({ message: "هیچ گروه فعالی وجود ندارد" });
    }
    
    // Create targets for all groups
    const createdTargets = [];
    const errors = [];
    
    for (const group of activeGroups) {
      try {
        const targetData = {
          groupId: group.id,
          yearShamsi,
          targetCaseCount: targetCaseCount ? parseInt(targetCaseCount.toString()) : null,
          targetMonetary: targetMonetary || null,
          setBy: user.id,
        };
        
        const validatedData = insertGroupTargetSchema.parse(targetData);
        const newTarget = await storage.setGroupTarget(validatedData);
        createdTargets.push(newTarget);
      } catch (error: any) {
        console.error(`Failed to set target for group ${group.id}:`, error);
        errors.push({ groupId: group.id, groupName: group.name, error: error.message });
      }
    }
    
    // Log the bulk operation
    await storage.createAuditLog({
      userId: user.id,
      action: 'set_department_targets',
      entityType: 'department_target',
      entityId: 'all',
      details: {
        yearShamsi,
        targetCaseCount: targetCaseCount ? parseInt(targetCaseCount.toString()) : null,
        targetMonetary: targetMonetary || null,
        groupsAffected: activeGroups.length,
        targetsCreated: createdTargets.length,
        errors: errors.length > 0 ? errors : undefined,
        setBy: user.id,
        setByRole: user.role,
        setAt: new Date().toISOString(),
      },
      ipAddress: extractClientIp(req),
    });
    
    // Notify all group members about the updated targets
    for (const group of activeGroups) {
      const groupMembers = await storage.getGroupMembers(group.id);
      const activeMembers = groupMembers.filter(m => m.isActive);
      
      for (const member of activeMembers) {
        try {
          await storage.createNotification({
            userId: member.userId,
            message: `هدف جدید برای تمام گروه‌ها در سال ${yearShamsi} تعیین شد`,
            messagePashto: `نوی هدف د ټولو ډلو لپاره د ${yearShamsi} کال کې ټاکل شو`,
            type: 'department_target_update',
          });
        } catch (error) {
          console.error(`Failed to notify group member ${member.userId}:`, error);
        }
      }
    }
    
    if (errors.length > 0) {
      return res.status(207).json({
        message: `اهداف برای ${createdTargets.length} گروه تعیین شد، اما ${errors.length} خطا رخ داد`,
        targetsCreated: createdTargets.length,
        errors,
      });
    }
    
    res.status(201).json({
      message: `اهداف برای ${createdTargets.length} گروه با موفقیت تعیین شد`,
      targetsCreated: createdTargets.length,
      targets: createdTargets,
    });
  } catch (error) {
    console.error(error);
    res.status(400).json({ message: "خطا در تعیین اهداف بخش" });
  }
});

// Set targets for group (requires groups:set_targets permission - Director only)
router.post("/:id/targets", requireAuth, requirePermission('groups:set_targets'), async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    
    const { yearShamsi, targetCaseCount, targetMonetary } = req.body;
    
    if (!yearShamsi) {
      return res.status(400).json({ message: "سال شمسی الزامی است" });
    }
    
    // Verify group exists
    const group = await storage.getGroup(req.params.id);
    if (!group) {
      return res.status(404).json({ message: "گروه یافت نشد" });
    }
    
    const targetData = {
      groupId: req.params.id,
      yearShamsi,
      targetCaseCount: targetCaseCount ? parseInt(targetCaseCount) : null,
      targetMonetary: targetMonetary || null,
      setBy: user.id,
    };
    
    const validatedData = insertGroupTargetSchema.parse(targetData);
    const newTarget = await storage.setGroupTarget(validatedData);
    
    await storage.createAuditLog({
      userId: user.id,
      action: 'set_group_target',
      entityType: 'group_target',
      entityId: newTarget.id,
      details: {
        newValue: { 
          groupId: req.params.id, 
          groupName: group.name,
          yearShamsi, 
          targetCaseCount: targetCaseCount ? parseInt(targetCaseCount) : null, 
          targetMonetary: targetMonetary || null 
        },
        setBy: user.id,
        setByRole: user.role,
        setAt: new Date().toISOString(),
      },
      ipAddress: extractClientIp(req),
    });
    
    // Notify all group members about the updated target
    const groupMembers = await storage.getGroupMembers(req.params.id);
    const activeMembers = groupMembers.filter(m => m.isActive);
    
    for (const member of activeMembers) {
      try {
        const memberUser = await storage.getUser(member.userId);
        if (memberUser) {
          await storage.createNotification({
            userId: member.userId,
            message: `هدف جدید برای گروه ${group.name} در سال ${yearShamsi} تعیین شد`,
            messagePashto: `نوی هدف د ${group.name} ډلې لپاره د ${yearShamsi} کال کې ټاکل شو`,
            type: 'group_target_update',
          });
        }
      } catch (error) {
        console.error(`Failed to notify group member ${member.userId}:`, error);
      }
    }
    
    res.status(201).json(newTarget);
  } catch (error) {
    console.error(error);
    res.status(400).json({ message: "خطا در تعیین هدف برای گروه" });
  }
});

// Update target for group (requires groups:set_targets permission)
router.put("/:groupId/targets/:targetId", requireAuth, requirePermission('groups:set_targets'), async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    const { groupId, targetId } = req.params;
    
    const { targetCaseCount, targetMonetary } = req.body;
    
    // Verify target exists
    const existingTarget = await storage.getGroupTarget(targetId);
    if (!existingTarget) {
      return res.status(404).json({ message: "هدف یافت نشد" });
    }
    
    // Verify target belongs to the specified group
    if (existingTarget.groupId !== groupId) {
      return res.status(400).json({ message: "هدف به این گروه تعلق ندارد" });
    }
    
    // Verify group exists
    const group = await storage.getGroup(groupId);
    if (!group) {
      return res.status(404).json({ message: "گروه یافت نشد" });
    }
    
    // Prepare update data
    const updateData: any = {
      setBy: user.id,
    };
    
    if (targetCaseCount !== undefined) {
      updateData.targetCaseCount = targetCaseCount ? parseInt(targetCaseCount.toString()) : null;
    }
    if (targetMonetary !== undefined) {
      updateData.targetMonetary = targetMonetary || null;
    }
    
    // Update the target
    const updatedTarget = await storage.updateGroupTarget(targetId, updateData);
    
    if (!updatedTarget) {
      return res.status(500).json({ message: "خطا در بروز رسانی هدف" });
    }
    
    // Log the update
    await storage.createAuditLog({
      userId: user.id,
      action: 'update_group_target',
      entityType: 'group_target',
      entityId: updatedTarget.id,
      details: {
        oldValue: existingTarget,
        newValue: updatedTarget,
        groupId,
        groupName: group.name,
        yearShamsi: existingTarget.yearShamsi,
        setBy: user.id,
        setByRole: user.role,
        setAt: new Date().toISOString(),
      },
      ipAddress: extractClientIp(req),
    } as any);
    
    // Notify all group members about the updated target
    const groupMembers = await storage.getGroupMembers(groupId);
    const activeMembers = groupMembers.filter(m => m.isActive);
    
    for (const member of activeMembers) {
      try {
        const memberUser = await storage.getUser(member.userId);
        if (memberUser) {
          await storage.createNotification({
            userId: member.userId,
            message: `هدف گروه ${group.name} برای سال ${existingTarget.yearShamsi} بروز رسانی شد`,
            messagePashto: `د ${group.name} ډلې هدف د ${existingTarget.yearShamsi} کال لپاره تازه شو`,
            type: 'group_target_update',
          });
        }
      } catch (error) {
        console.error(`Failed to notify group member ${member.userId}:`, error);
      }
    }
    
    res.json(updatedTarget);
  } catch (error) {
    console.error(error);
    res.status(400).json({ message: "خطا در بروز رسانی هدف" });
  }
});

// Get target achievement for a group
router.get("/:id/targets/achievement", requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    const groupId = req.params.id;
    
    // RBAC: Check access to this group
    const { getGroupVisibility } = await import('../utils/permissionHelpers');
    const visibility = await getGroupVisibility(user);
    
    // Verify group exists
    const group = await storage.getGroup(groupId);
    if (!group) {
      return res.status(404).json({ message: "گروه یافت نشد" });
    }
    
    // Check permissions
    if (user.role !== 'system_admin' && !visibility.canViewAll) {
      if (visibility.filterByGroup && groupId !== visibility.filterByGroup) {
        return res.status(403).json({ message: 'شما فقط می‌توانید اهداف گروه خود را مشاهده کنید' });
      } else if (!visibility.filterByGroup) {
        return res.status(403).json({ message: 'عدم دسترسی' });
      }
    }
    
    const yearShamsi = req.query.yearShamsi ? parseInt(req.query.yearShamsi as string) : jalaali.toJalaali(new Date()).jy;
    
    // Get all targets for this group
    const targets = await storage.getGroupTargets(groupId);
    const target = targets.find(t => parseInt(t.yearShamsi) === yearShamsi);
    
    if (!target) {
      return res.json({
        groupId,
        groupName: group.name,
        yearShamsi,
        hasTarget: false,
        target: null,
        achievement: null,
        monthlyBreakdown: [],
      });
    }
    
    // Get all cases for this group in the target year
    const allCases = await storage.getCasesByGroup(groupId);
    const yearCases = allCases.filter(c => {
      if (!c.createdAt) return false;
      const j = jalaali.toJalaali(new Date(c.createdAt));
      return j.jy === yearShamsi;
    });
    
    // Get completed reports
    const { db } = await import('../db');
    const { caseReportsV2 } = await import('@shared/schema');
    const { inArray, eq, and } = await import('drizzle-orm');
    
    const caseIds = yearCases.map(c => c.id);
    let completedCaseIds = new Set<string>();
    
    if (caseIds.length > 0) {
      const completedReports = await db
        .select({ caseId: caseReportsV2.caseId })
        .from(caseReportsV2)
        .where(
          and(
            inArray(caseReportsV2.caseId, caseIds),
            eq(caseReportsV2.status, 'completed')
          )
        );
      
      completedCaseIds = new Set(completedReports.map(r => r.caseId));
    }
    
    // Count completed cases
    const completedCases = yearCases.filter(c => 
      c.status === 'تکمیل شده' || c.status === 'COMPLETED' || completedCaseIds.has(c.id)
    );
    
    const achieved = completedCases.length;
    const targetCount = target.targetCaseCount || 0;
    const percentComplete = targetCount > 0 ? Math.round((achieved / targetCount) * 100) : 0;
    
    // Monthly breakdown
    const monthlyBreakdown = [];
    for (let month = 1; month <= 12; month++) {
      const monthCases = yearCases.filter(c => {
        if (!c.createdAt) return false;
        const j = jalaali.toJalaali(new Date(c.createdAt));
        return j.jm === month;
      });
      
      const monthCompleted = monthCases.filter(c => 
        c.status === 'تکمیل شده' || c.status === 'COMPLETED' || completedCaseIds.has(c.id)
      );
      
      const monthlyTarget = Math.ceil(targetCount / 12);
      const monthPercent = monthlyTarget > 0 ? Math.round((monthCompleted.length / monthlyTarget) * 100) : 0;
      
      monthlyBreakdown.push({
        monthShamsi: month,
        target: monthlyTarget,
        achieved: monthCompleted.length,
        percentComplete: monthPercent,
        status: monthCompleted.length >= monthlyTarget ? 'achieved' : 
                monthCompleted.length >= monthlyTarget * 0.8 ? 'almost' : 'not_achieved',
      });
    }
    
    res.json({
      groupId,
      groupName: group.name,
      yearShamsi,
      hasTarget: true,
      target: {
        targetCaseCount: target.targetCaseCount,
        targetMonetary: target.targetMonetary,
      },
      achievement: {
        target: targetCount,
        achieved,
        percentComplete,
        status: achieved >= targetCount ? 'achieved' : 
                achieved >= targetCount * 0.8 ? 'almost' : 'not_achieved',
        exceeded: achieved > targetCount,
      },
      monthlyBreakdown,
    });
  } catch (error) {
    console.error('Error fetching target achievement:', error);
    res.status(500).json({ message: "خطا در دریافت پیشرفت اهداف" });
  }
});

// Get targets summary for all groups
router.get("/targets/summary", requireAuth, async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    
    // RBAC: Check if user can view all groups
    const { getGroupVisibility } = await import('../utils/permissionHelpers');
    const visibility = await getGroupVisibility(user);
    
    if (!visibility.canViewAll && user.role !== 'system_admin') {
      return res.status(403).json({ message: 'عدم دسترسی - فقط مدیران می‌توانند خلاصه اهداف را مشاهده کنند' });
    }
    
    const yearShamsi = req.query.yearShamsi ? parseInt(req.query.yearShamsi as string) : jalaali.toJalaali(new Date()).jy;
    
    // Get all active groups
    const allGroups = await storage.getGroups();
    const activeGroups = allGroups.filter(g => g.isActive);
    
    const summary = [];
    
    for (const group of activeGroups) {
      // Get target for this year
      const targets = await storage.getGroupTargets(group.id);
      const target = targets.find(t => parseInt(t.yearShamsi) === yearShamsi);
      
      if (!target || !target.targetCaseCount) {
        summary.push({
          groupId: group.id,
          groupName: group.name,
          groupCode: group.code,
          hasTarget: false,
          target: null,
          achieved: null,
          percentComplete: 0,
          status: 'no_target',
        });
        continue;
      }
      
      // Get cases for this group in the target year
      const allCases = await storage.getCasesByGroup(group.id);
      const yearCases = allCases.filter(c => {
        if (!c.createdAt) return false;
        const j = jalaali.toJalaali(new Date(c.createdAt));
        return j.jy === yearShamsi;
      });
      
      // Get completed reports
      const { db } = await import('../db');
      const { caseReportsV2 } = await import('@shared/schema');
      const { inArray, eq, and } = await import('drizzle-orm');
      
      const caseIds = yearCases.map(c => c.id);
      let completedCaseIds = new Set<string>();
      
      if (caseIds.length > 0) {
        const completedReports = await db
          .select({ caseId: caseReportsV2.caseId })
          .from(caseReportsV2)
          .where(
            and(
              inArray(caseReportsV2.caseId, caseIds),
              eq(caseReportsV2.status, 'completed')
            )
          );
        
        completedCaseIds = new Set(completedReports.map(r => r.caseId));
      }
      
      // Count completed cases
      const completedCases = yearCases.filter(c => 
        c.status === 'تکمیل شده' || c.status === 'COMPLETED' || completedCaseIds.has(c.id)
      );
      
      const achieved = completedCases.length;
      const targetCount = target.targetCaseCount;
      const percentComplete = targetCount > 0 ? Math.round((achieved / targetCount) * 100) : 0;
      
      summary.push({
        groupId: group.id,
        groupName: group.name,
        groupCode: group.code,
        hasTarget: true,
        target: targetCount,
        achieved,
        percentComplete,
        status: achieved >= targetCount ? 'achieved' : 
                achieved >= targetCount * 0.8 ? 'almost' : 'not_achieved',
        exceeded: achieved > targetCount,
      });
    }
    
    // Sort by percentComplete descending
    summary.sort((a, b) => b.percentComplete - a.percentComplete);
    
    // Calculate totals
    const totalTargets = summary.reduce((sum, s) => sum + (s.target || 0), 0);
    const totalAchieved = summary.reduce((sum, s) => sum + (s.achieved || 0), 0);
    const totalPercent = totalTargets > 0 ? Math.round((totalAchieved / totalTargets) * 100) : 0;
    const targetsAchieved = summary.filter(s => s.status === 'achieved').length;
    const targetsNotAchieved = summary.filter(s => s.status === 'not_achieved').length;
    
    res.json({
      yearShamsi,
      summary,
      totals: {
        totalTargets,
        totalAchieved,
        totalPercent,
        targetsAchieved,
        targetsNotAchieved,
        totalGroups: summary.length,
      },
    });
  } catch (error) {
    console.error('Error fetching targets summary:', error);
    res.status(500).json({ message: "خطا در دریافت خلاصه اهداف" });
  }
});

// Clear all groups (admin only - requires special permission)
// This deletes all groups, members, and targets while preserving cases
router.post("/clear-all", requireAuth, requirePermission('groups:manage'), async (req: Request, res: Response) => {
  try {
    const user = req.user as any;
    
    // Only system admin can clear all groups
    if (user.role !== 'system_admin') {
      return res.status(403).json({ 
        message: 'فقط مدیر سیستم می‌تواند تمام گروه‌ها را پاک کند' 
      });
    }
    
    // Get all groups first for logging
    const allGroups = await storage.getGroups();
    
    // Check for cases assigned to groups
    const allCases = await storage.getCases();
    const casesWithGroups = allCases.filter(c => c.groupReferrer);
    
    if (casesWithGroups.length > 0) {
      return res.status(400).json({ 
        message: `نمی‌توان گروه‌ها را پاک کرد زیرا ${casesWithGroups.length} قضیه به گروه‌ها اختصاص داده شده است. لطفاً ابتدا قضایا را واگذار یا حذف کنید.`
      });
    }
    
    // Delete all group targets first (to handle foreign key constraints)
    for (const group of allGroups) {
      const targets = await storage.getGroupTargets(group.id);
      for (const target of targets) {
        await db.delete(groupTargets).where(eq(groupTargets.id, target.id));
      }
    }
    
    // Delete all group members
    for (const group of allGroups) {
      const members = await storage.getGroupMembers(group.id);
      for (const member of members) {
        await storage.removeGroupMember(group.id, member.userId);
      }
    }
    
    // Delete all groups
    for (const group of allGroups) {
      await storage.deleteGroup(group.id);
    }
    
    // Log the action
    await storage.createAuditLog({
      userId: user.id,
      action: 'clear_all_groups',
      entityType: 'group',
      entityId: 'all',
      details: {
        groupsCleared: allGroups.length,
        groupsDeleted: allGroups.map(g => ({ id: g.id, name: g.name, code: g.code })),
        clearedAt: new Date().toISOString(),
      },
      ipAddress: extractClientIp(req),
    });
    
    res.json({ 
      message: `${allGroups.length} گروه با موفقیت پاک شد`,
      groupsCleared: allGroups.length 
    });
  } catch (error) {
    console.error('Error clearing groups:', error);
    res.status(500).json({ message: "خطا در پاک کردن گروه‌ها" });
  }
});

export default router;
