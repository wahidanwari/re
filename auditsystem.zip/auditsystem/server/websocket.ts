import { WebSocketServer, WebSocket } from 'ws';
import type { Server } from 'http';
import type { IncomingMessage } from 'http';

interface AuthenticatedWebSocket extends WebSocket {
  userId?: string;
  isAlive?: boolean;
}

export class NotificationWebSocketServer {
  private wss: WebSocketServer;
  private clients: Map<string, Set<AuthenticatedWebSocket>> = new Map();
  private sessionStore: any;

  constructor(server: Server, sessionStore: any) {
    this.sessionStore = sessionStore;
    this.wss = new WebSocketServer({ 
      server,
      path: '/ws/notifications',
      verifyClient: (info, callback) => {
        this.authenticateConnection(info.req, callback);
      }
    });

    // Add error handler for WebSocketServer
    // Only log errors that are specific to WebSocket operations, not HTTP server listen errors
    this.wss.on('error', (error: any) => {
      // Ignore listen-related errors - these are handled by the HTTP server error handler
      // These errors occur when the HTTP server has listen errors and propagate to WebSocketServer
      if (error.code === 'EADDRINUSE' || error.code === 'ENOTSUP' || error.code === 'EADDRNOTAVAIL') {
        // These are HTTP server listen errors, not WebSocket errors
        // The HTTP server error handler will handle them properly
        return;
      }
      // Log other WebSocket-specific errors (suppress expected connection errors in dev)
      if (process.env.DEBUG_WEBSOCKET === 'true' || 
          (error.code && !['ECONNRESET', 'ECONNREFUSED', 'EPIPE'].includes(error.code))) {
        console.error('[WebSocket] Server error:', error.message || error);
      }
    });

    this.wss.on('connection', (ws: AuthenticatedWebSocket, req: IncomingMessage) => {
      const userId = (req as any).session?.passport?.user;

      if (!userId) {
        ws.close(1008, 'احراز هویت نشده');
        return;
      }

      ws.userId = userId;
      ws.isAlive = true;

      if (!this.clients.has(userId)) {
        this.clients.set(userId, new Set());
      }
      this.clients.get(userId)?.add(ws);

      ws.on('pong', () => {
        ws.isAlive = true;
      });

      ws.on('close', () => {
        if (ws.userId) {
          this.clients.get(ws.userId)?.delete(ws);
          if (this.clients.get(ws.userId)?.size === 0) {
            this.clients.delete(ws.userId);
          }
        }
      });

      ws.on('error', (error: any) => {
        // Suppress expected WebSocket errors (connection resets during dev)
        // Only log unexpected errors or in debug mode
        if (process.env.DEBUG_WEBSOCKET === 'true' || (error.code && !['ECONNRESET', 'ECONNREFUSED'].includes(error.code))) {
          console.error('[WebSocket] Client error:', error.message || error);
        }
      });

      ws.send(JSON.stringify({
        type: 'connected',
        message: 'اتصال به سرور اعلانات برقرار شد',
      }));
    });

    const heartbeat = setInterval(() => {
      this.wss.clients.forEach((ws: WebSocket) => {
        const client = ws as AuthenticatedWebSocket;
        if (client.isAlive === false) {
          return client.terminate();
        }
        client.isAlive = false;
        client.ping();
      });
    }, 30000);

    this.wss.on('close', () => {
      clearInterval(heartbeat);
    });
  }

  private authenticateConnection(req: IncomingMessage, callback: (result: boolean, code?: number, message?: string) => void) {
    const cookies = req.headers.cookie;
    if (!cookies) {
      return callback(false, 401, 'احراز هویت نشده');
    }

    const cookieParts = cookies.split(';').map(c => c.trim());
    let sessionId = '';
    
    for (const cookie of cookieParts) {
      // Support both 'audit.sid' (our custom name) and 'connect.sid' (default)
      if (cookie.startsWith('audit.sid=')) {
        sessionId = cookie.substring('audit.sid='.length);
        break;
      } else if (cookie.startsWith('connect.sid=')) {
        sessionId = cookie.substring('connect.sid='.length);
        break;
      }
    }
    
    if (!sessionId) {
      return callback(false, 401, 'احراز هویت نشده');
    }

    const sid = decodeURIComponent(sessionId).split('.')[0].slice(2);
    
    this.sessionStore.get(sid, (err: any, session: any) => {
      if (err || !session || !session.passport?.user) {
        return callback(false, 401, 'احراز هویت نشده');
      }
      
      (req as any).session = session;
      callback(true);
    });
  }

  sendNotificationToUser(userId: string, notification: any) {
    const userConnections = this.clients.get(userId);
    if (userConnections) {
      const message = JSON.stringify({
        type: 'notification',
        data: notification,
      });
      userConnections.forEach((ws) => {
        if (ws.readyState === WebSocket.OPEN) {
          ws.send(message);
        }
      });
    }
  }

  broadcastToGroup(userIds: string[], notification: any) {
    userIds.forEach((userId) => {
      this.sendNotificationToUser(userId, notification);
    });
  }

  getActiveConnections(userId: string): number {
    return this.clients.get(userId)?.size || 0;
  }

  /**
   * Send permission change notification to user
   * This triggers client to refresh permissions
   */
  notifyPermissionChange(userId: string) {
    const userConnections = this.clients.get(userId);
    if (userConnections) {
      const message = JSON.stringify({
        type: 'permission_change',
        data: {
          message: 'Your permissions have been updated. Please refresh.',
          timestamp: new Date().toISOString(),
        },
      });
      userConnections.forEach((ws) => {
        if (ws.readyState === WebSocket.OPEN) {
          ws.send(message);
        }
      });
    }
  }

  /**
   * Send session invalidated notification to user
   * This triggers client to logout and redirect to login
   */
  notifySessionInvalidated(userId: string) {
    const userConnections = this.clients.get(userId);
    if (userConnections) {
      const message = JSON.stringify({
        type: 'session_invalidated',
        data: {
          message: 'Your session has been invalidated. Please log in again.',
          timestamp: new Date().toISOString(),
        },
      });
      userConnections.forEach((ws) => {
        if (ws.readyState === WebSocket.OPEN) {
          ws.send(message);
        }
      });
    }
  }

  getTotalConnections(): number {
    return this.wss.clients.size;
  }
}

export let wsServer: NotificationWebSocketServer;

export function initializeWebSocket(server: Server, sessionStore: any) {
  wsServer = new NotificationWebSocketServer(server, sessionStore);
  return wsServer;
}

export function getWebSocketServer(): NotificationWebSocketServer | null {
  return wsServer || null;
}
