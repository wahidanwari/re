/**
 * Committee-Based Intake Workflow Migration Runner
 * Executes migration 025_committee_based_intake_workflow.sql
 * 
 * Usage: npm run db:migrate-committee-based-intake-workflow
 */

import "dotenv/config";
import { Pool } from 'pg';
import * as fs from 'fs';
import * as path from 'path';

if (!process.env.DATABASE_URL) {
  throw new Error("DATABASE_URL must be set in .env file");
}

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

async function runMigration() {
  const client = await pool.connect();
  const migrationsDir = path.join(process.cwd(), 'migrations');
  const migrationFile = path.join(migrationsDir, '025_committee_based_intake_workflow.sql');

  try {
    console.log('🔄 Running Committee-Based Intake Workflow Migration...');
    console.log(`📄 Reading migration file: ${migrationFile}`);

    // Check if file exists
    if (!fs.existsSync(migrationFile)) {
      throw new Error(`Migration file not found: ${migrationFile}`);
    }

    // Read SQL file
    const sql = fs.readFileSync(migrationFile, 'utf8');

    // Execute migration
    await client.query('BEGIN');
    console.log('📝 Executing SQL migration...');
    
    await client.query(sql);
    
    await client.query('COMMIT');
    console.log('✅ Migration completed successfully!');
    console.log('📊 Created/Modified:');
    console.log('   - Added status column to entities table');
    console.log('   - Added committee_id column to cases table');
    console.log('   - Created committees table');
    console.log('   - Created committee_entities junction table');
    console.log('   - Created all indexes and constraints');

  } catch (error: any) {
    await client.query('ROLLBACK');
    console.error('❌ Migration failed:', error.message);
    if (error.code) {
      console.error(`   Error code: ${error.code}`);
    }
    if (error.detail) {
      console.error(`   Detail: ${error.detail}`);
    }
    throw error;
  } finally {
    client.release();
    await pool.end();
  }
}

runMigration()
  .then(() => {
    console.log('✨ Migration process completed');
    process.exit(0);
  })
  .catch((error) => {
    console.error('💥 Migration process failed:', error);
    process.exit(1);
  });

