/**
 * Legacy Excel Files Ingestion Script
 * 
 * Migrates 100+ legacy Excel files into the archive system.
 * 
 * Usage:
 *   npm run ingest-legacy-excel -- --csv metadata.csv --source-dir /path/to/files --migration-user-id <user-id>
 * 
 * CSV Format (metadata.csv):
 *   originalFileName,year,category,description,sourcePath
 *   file1.xlsx,1400,گزارشات مالی,گزارش مالی سال 1400,/path/to/file1.xlsx
 *   file2.xlsx,1401,اسناد حسابداری,اسناد حسابداری سال 1401,/path/to/file2.xlsx
 * 
 * The script will:
 * 1. Read CSV metadata file
 * 2. Validate each file exists
 * 3. Move files to /data/archives/legacy-excel/{year}/
 * 4. Create ArchivedFile and ArchivedFileVersion records
 * 5. Set read-only permissions (chmod 0444)
 * 6. Calculate and validate checksums
 */

import "dotenv/config";
import { parse } from "csv-parse/sync";
import { readFileSync, existsSync, statSync, readdirSync } from "fs";
import { join, basename, dirname } from "path";
import { db } from "../db";
import { archivedFiles, archivedFileVersions } from "@shared/schema";
import { eq, and } from "drizzle-orm";
import {
  ensureYearDirectory,
  calculateFileChecksum,
  generateStoredFileName,
} from "../utils/archiveStorage";
import { rename, chmod } from "fs/promises";

interface MetadataRow {
  originalFileName: string;
  year: number;
  category: string;
  description: string;
  sourcePath: string;
}

interface IngestionResult {
  success: number;
  failed: number;
  errors: Array<{ file: string; error: string }>;
}

/**
 * Parse CSV metadata file
 */
function parseMetadata(csvPath: string): MetadataRow[] {
  if (!existsSync(csvPath)) {
    throw new Error(`CSV file not found: ${csvPath}`);
  }

  const content = readFileSync(csvPath, "utf-8");
  const records = parse(content, {
    columns: true,
    skip_empty_lines: true,
    trim: true,
  }) as Array<Record<string, string>>;

  return records.map((row) => {
    const year = parseInt(row.year);
    if (isNaN(year) || year < 1300 || year > 1500) {
      throw new Error(`Invalid year in row: ${row.year}`);
    }

    return {
      originalFileName: row.originalFileName || basename(row.sourcePath),
      year,
      category: row.category,
      description: row.description || "",
      sourcePath: row.sourcePath,
    };
  });
}

/**
 * Ingest a single file
 */
async function ingestFile(
  metadata: MetadataRow,
  migrationUserId: string,
  dryRun: boolean = false
): Promise<{ success: boolean; error?: string }> {
  try {
    // Validate source file exists
    if (!existsSync(metadata.sourcePath)) {
      return {
        success: false,
        error: `Source file not found: ${metadata.sourcePath}`,
      };
    }

    // Validate it's an Excel file
    const ext = metadata.sourcePath.toLowerCase();
    if (!ext.endsWith(".xlsx") && !ext.endsWith(".xls")) {
      return {
        success: false,
        error: `Not an Excel file: ${metadata.sourcePath}`,
      };
    }

    if (dryRun) {
      console.log(`[DRY RUN] Would ingest: ${metadata.originalFileName}`);
      return { success: true };
    }

    // Check if file already exists in archive
    const existing = await db
      .select()
      .from(archivedFiles)
      .where(
        and(
          eq(archivedFiles.originalFileName, metadata.originalFileName),
          eq(archivedFiles.year, metadata.year)
        )
      )
      .limit(1);

    if (existing.length > 0) {
      return {
        success: false,
        error: `File already exists in archive: ${metadata.originalFileName} (year ${metadata.year})`,
      };
    }

    // Ensure year directory exists
    const yearPath = await ensureYearDirectory(metadata.year);

    // Generate stored filename
    const storedFileName = generateStoredFileName(
      metadata.year,
      metadata.category,
      metadata.description,
      metadata.originalFileName,
      1 // Initial version
    );

    const finalPath = join(yearPath, storedFileName);

    // Check if final path already exists
    if (existsSync(finalPath)) {
      return {
        success: false,
        error: `Target file already exists: ${finalPath}`,
      };
    }

    // Move file to archive location
    await rename(metadata.sourcePath, finalPath);

    // Set read-only permissions
    try {
      await chmod(finalPath, 0o444);
    } catch (error) {
      console.warn(`Warning: Could not set read-only permissions on ${finalPath}:`, error);
    }

    // Get file size
    const stats = statSync(finalPath);
    const sizeBytes = stats.size;

    // Calculate checksum
    const checksum = await calculateFileChecksum(finalPath);

    // Calculate relative path
    const relativePath = join(metadata.year.toString(), storedFileName);

    // Create ArchivedFile record
    const [archivedFile] = await db
      .insert(archivedFiles)
      .values({
        fileName: storedFileName,
        originalFileName: metadata.originalFileName,
        year: metadata.year,
        category: metadata.category,
        description: metadata.description || null,
        path: relativePath,
        sizeBytes,
        uploadedBy: migrationUserId,
        isReadonly: true,
        currentVersion: 1,
      })
      .returning();

    // Create initial version record
    await db.insert(archivedFileVersions).values({
      archivedFileId: archivedFile.id,
      versionNumber: 1,
      fileName: storedFileName,
      path: relativePath,
      sizeBytes,
      uploadedBy: migrationUserId,
      notes: `Migrated from legacy system - Checksum: ${checksum}`,
    });

    console.log(`✓ Ingested: ${metadata.originalFileName} -> ${storedFileName} (${checksum})`);
    return { success: true };
  } catch (error: any) {
    return {
      success: false,
      error: error.message || String(error),
    };
  }
}

/**
 * Main ingestion function
 */
async function main() {
  const args = process.argv.slice(2);
  const csvIndex = args.indexOf("--csv");
  const sourceDirIndex = args.indexOf("--source-dir");
  const userIdIndex = args.indexOf("--migration-user-id");
  const dryRun = args.includes("--dry-run");

  if (csvIndex === -1 || !args[csvIndex + 1]) {
    console.error("Error: --csv parameter is required");
    console.error("Usage: npm run ingest-legacy-excel -- --csv metadata.csv --source-dir /path/to/files --migration-user-id <user-id>");
    process.exit(1);
  }

  if (userIdIndex === -1 || !args[userIdIndex + 1]) {
    console.error("Error: --migration-user-id parameter is required");
    console.error("Usage: npm run ingest-legacy-excel -- --csv metadata.csv --source-dir /path/to/files --migration-user-id <user-id>");
    process.exit(1);
  }

  const csvPath = args[csvIndex + 1];
  const sourceDir = sourceDirIndex !== -1 ? args[sourceDirIndex + 1] : null;
  const migrationUserId = args[userIdIndex + 1];

  console.log("=== Legacy Excel Files Ingestion ===");
  console.log(`CSV File: ${csvPath}`);
  if (sourceDir) {
    console.log(`Source Directory: ${sourceDir}`);
  }
  console.log(`Migration User ID: ${migrationUserId}`);
  console.log(`Dry Run: ${dryRun ? "YES" : "NO"}`);
  console.log("");

  try {
    // Parse metadata
    let metadataRows = parseMetadata(csvPath);

    // If source-dir is provided, update source paths
    if (sourceDir) {
      metadataRows = metadataRows.map((row) => ({
        ...row,
        sourcePath: join(sourceDir, row.originalFileName),
      }));
    }

    console.log(`Found ${metadataRows.length} files to ingest\n`);

    // Ingest each file
    const result: IngestionResult = {
      success: 0,
      failed: 0,
      errors: [],
    };

    for (const metadata of metadataRows) {
      const fileResult = await ingestFile(metadata, migrationUserId, dryRun);
      if (fileResult.success) {
        result.success++;
      } else {
        result.failed++;
        result.errors.push({
          file: metadata.originalFileName,
          error: fileResult.error || "Unknown error",
        });
        console.error(`✗ Failed: ${metadata.originalFileName} - ${fileResult.error}`);
      }
    }

    // Print summary
    console.log("\n=== Ingestion Summary ===");
    console.log(`Success: ${result.success}`);
    console.log(`Failed: ${result.failed}`);
    if (result.errors.length > 0) {
      console.log("\nErrors:");
      result.errors.forEach(({ file, error }) => {
        console.log(`  - ${file}: ${error}`);
      });
    }

    process.exit(result.failed > 0 ? 1 : 0);
  } catch (error: any) {
    console.error("Fatal error:", error.message);
    process.exit(1);
  }
}

// Run if executed directly
if (require.main === module) {
  main();
}

export { ingestFile, parseMetadata };

