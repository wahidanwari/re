/**
 * Migration: Add Audit Year Numeric Columns and Constraint
 * Converts audit_year_range (TEXT) to audit_year_start and audit_year_end (INTEGER)
 * Adds PostgreSQL exclusion constraint to prevent overlapping year ranges per entity
 * 
 * Usage: npm run db:migrate-audit-year-constraint
 */

import "dotenv/config";
import { Pool } from 'pg';
import * as fs from 'fs';
import * as path from 'path';

if (!process.env.DATABASE_URL) {
  throw new Error("DATABASE_URL must be set");
}

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

async function runMigration() {
  const client = await pool.connect();
  
  try {
    console.log('🚀 Starting migration: Add Audit Year Numeric Columns and Constraint...\n');
    
    // Read the SQL migration file
    const migrationsDir = path.join(process.cwd(), 'migrations');
    const migrationFile = path.join(migrationsDir, '034_add_audit_year_numeric_columns_and_constraint.sql');
    
    if (!fs.existsSync(migrationFile)) {
      throw new Error(`Migration file not found: ${migrationFile}`);
    }
    
    const sql = fs.readFileSync(migrationFile, 'utf-8');
    
    // Set search path
    await client.query('SET search_path TO public;');
    
    // Execute the migration
    console.log('📝 Executing SQL migration...');
    await client.query(sql);
    
    console.log('✅ Migration completed successfully!\n');
    console.log('Changes applied:');
    console.log('  - Added audit_year_start and audit_year_end columns to cases table');
    console.log('  - Migrated existing data from audit_year_range to numeric columns');
    console.log('  - Created indexes on new columns');
    console.log('  - Added check constraint to ensure start <= end');
    console.log('  - Added exclusion constraint to prevent overlapping year ranges (if btree_gist available)');
    console.log('  - Kept audit_year_range column for backward compatibility\n');
    
  } catch (error: any) {
    console.error('❌ Migration failed:', error.message);
    
    // Provide helpful error messages
    if (error.code === '42710') {
      console.log('⚠️  Some columns may already exist. This is safe to ignore.');
    } else if (error.message.includes('permission denied') || error.message.includes('btree_gist')) {
      console.log('⚠️  Note: btree_gist extension requires superuser privileges.');
      console.log('   The exclusion constraint was skipped, but application-level validation will still work.');
    } else if (error.message.includes('constraint') || error.message.includes('overlap')) {
      console.log('⚠️  There may be existing overlapping data. Check your cases table.');
    } else {
      console.error('Full error:', error);
      throw error;
    }
  } finally {
    client.release();
    await pool.end();
  }
}

runMigration().catch((error) => {
  console.error('Fatal error:', error);
  process.exit(1);
});

