/**
 * Cleanup Old Sessions Script
 * Removes expired sessions from session table
 * 
 * Usage: tsx server/scripts/cleanup-old-sessions.ts
 */

import "dotenv/config";
import { pool } from "../db";

async function cleanupOldSessions() {
  try {
    console.log("Starting cleanup of expired sessions...");
    
    const client = await pool.connect();
    
    try {
      // Delete expired sessions
      // connect-pg-simple uses 'expire' column for expiration time
      const result = await client.query(
        `DELETE FROM session 
         WHERE expire < NOW() 
         RETURNING sid`
      );
      
      const deletedCount = result.rowCount || 0;
      
      console.log(`Successfully deleted ${deletedCount} expired sessions.`);
      console.log(`Cleanup completed at ${new Date().toISOString()}`);
    } finally {
      client.release();
    }
    
    process.exit(0);
  } catch (error) {
    console.error("Error cleaning up sessions:", error);
    process.exit(1);
  }
}

cleanupOldSessions();

