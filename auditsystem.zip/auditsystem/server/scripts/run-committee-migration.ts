/**
 * Run Committee Migration
 * Executes migration 033_new_committee_data_model.sql
 * 
 * Usage: npm run db:migrate-committee
 * Or: tsx server/scripts/run-committee-migration.ts
 */

import "dotenv/config";
import { Pool } from 'pg';
import * as fs from 'fs';
import * as path from 'path';

if (!process.env.DATABASE_URL) {
  throw new Error("DATABASE_URL must be set");
}

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

async function runMigration() {
  const client = await pool.connect();
  const migrationPath = path.join(process.cwd(), 'migrations', '033_new_committee_data_model.sql');
  
  console.log('🚀 Running Committee Migration...\n');
  console.log(`📁 Migration file: ${migrationPath}\n`);
  
  try {
    // Set search path
    await client.query(`SET search_path TO public;`);
    
    // Check if migration file exists
    if (!fs.existsSync(migrationPath)) {
      throw new Error(`Migration file not found: ${migrationPath}`);
    }
    
    // Read SQL migration file
    const sql = fs.readFileSync(migrationPath, 'utf-8');
    
    console.log('→ Executing migration...\n');
    
    // Execute migration
    await client.query(sql);
    
    console.log('✓ Migration completed successfully!\n');
    
    // Verify tables were created
    const tablesResult = await client.query(`
      SELECT table_name 
      FROM information_schema.tables 
      WHERE table_schema = 'public' 
      AND table_name IN ('committees', 'committee_case_assignments')
      ORDER BY table_name
    `);
    
    console.log('📊 Created tables:');
    tablesResult.rows.forEach(row => {
      console.log(`   ✓ ${row.table_name}`);
    });
    
    // Check if old table was renamed
    const oldTableResult = await client.query(`
      SELECT table_name 
      FROM information_schema.tables 
      WHERE table_schema = 'public' 
      AND table_name = 'committees_old'
    `);
    
    if (oldTableResult.rows.length > 0) {
      console.log('\n📦 Old committees table archived as: committees_old');
    }
    
    // Check new columns in cases table
    const columnsResult = await client.query(`
      SELECT column_name 
      FROM information_schema.columns 
      WHERE table_name = 'cases' 
      AND column_name IN ('current_assignment_id', 'current_audit_group_id')
      ORDER BY column_name
    `);
    
    if (columnsResult.rows.length > 0) {
      console.log('\n📝 Added columns to cases table:');
      columnsResult.rows.forEach(row => {
        console.log(`   ✓ ${row.column_name}`);
      });
    }
    
    console.log('\n✅ All done!');
    
  } catch (error: any) {
    console.error('\n❌ Migration failed:');
    console.error(error.message);
    if (error.position) {
      console.error(`   Error at position: ${error.position}`);
    }
    if (error.detail) {
      console.error(`   Detail: ${error.detail}`);
    }
    process.exit(1);
  } finally {
    client.release();
    await pool.end();
  }
}

runMigration().catch(console.error);

