/**
 * Yearly Audit Records Migration Runner
 * Executes migration 022_yearly_audit_records.sql
 * 
 * Usage: npm run db:migrate-yearly-audit-ts
 */

import "dotenv/config";
import { Pool } from 'pg';
import * as fs from 'fs';
import * as path from 'path';

if (!process.env.DATABASE_URL) {
  throw new Error("DATABASE_URL must be set in .env file");
}

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

async function runMigration() {
  const client = await pool.connect();
  const migrationsDir = path.join(process.cwd(), 'migrations');
  const migrationFile = path.join(migrationsDir, '022_yearly_audit_records.sql');

  try {
    console.log('🔄 Running Yearly Audit Records Migration...');
    console.log(`📄 Reading migration file: ${migrationFile}`);

    // Check if file exists
    if (!fs.existsSync(migrationFile)) {
      throw new Error(`Migration file not found: ${migrationFile}`);
    }

    // Read SQL file
    const sql = fs.readFileSync(migrationFile, 'utf8');

    // Execute migration
    await client.query('BEGIN');
    console.log('📝 Executing SQL migration...');
    
    await client.query(sql);
    
    await client.query('COMMIT');
    console.log('✅ Migration completed successfully!');
    console.log('📊 Created tables:');
    console.log('   - audit_records');
    console.log('   - audit_record_history');
    console.log('   - All indexes and constraints');

  } catch (error: any) {
    await client.query('ROLLBACK');
    console.error('❌ Migration failed:', error.message);
    if (error.code) {
      console.error(`   Error code: ${error.code}`);
    }
    throw error;
  } finally {
    client.release();
    await pool.end();
  }
}

runMigration()
  .then(() => {
    console.log('✨ Migration process completed');
    process.exit(0);
  })
  .catch((error) => {
    console.error('💥 Migration process failed:', error);
    process.exit(1);
  });

