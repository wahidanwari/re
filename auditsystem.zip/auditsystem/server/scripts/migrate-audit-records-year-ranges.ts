/**
 * Migration script to apply 023_audit_records_year_ranges.sql
 * 
 * This script runs the SQL migration without requiring psql command line tool
 * 
 * Usage:
 *   npm run db:migrate-audit-records-year-ranges
 *   or: tsx server/scripts/migrate-audit-records-year-ranges.ts
 */

import 'dotenv/config';
import { Pool } from 'pg';
import * as fs from 'fs';
import * as path from 'path';

if (!process.env.DATABASE_URL) {
  throw new Error('DATABASE_URL must be set');
}

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

async function runMigration() {
  const client = await pool.connect();
  
  try {
    console.log('='.repeat(60));
    console.log('Audit Records Year Ranges Migration');
    console.log('='.repeat(60));
    console.log('Starting migration...\n');
    
    // Read SQL migration file
    const migrationPath = path.join(process.cwd(), 'migrations', '023_audit_records_year_ranges.sql');
    
    if (!fs.existsSync(migrationPath)) {
      throw new Error(`Migration file not found: ${migrationPath}`);
    }
    
    const sql = fs.readFileSync(migrationPath, 'utf-8');
    
    // Execute migration
    console.log('Executing migration SQL...');
    await client.query(sql);
    
    console.log('\n' + '='.repeat(60));
    console.log('✓ Migration completed successfully!');
    console.log('='.repeat(60));
    console.log('\nChanges applied:');
    console.log('  - audit_records table updated with year ranges (year_from, year_to)');
    console.log('  - Existing data migrated from single-year to year ranges');
    console.log('  - Overlap detection constraints and triggers created');
    console.log('  - Indexes created for performance');
    console.log('\nNext steps:');
    console.log('  1. Verify migration: SELECT COUNT(*) FROM audit_records;');
    console.log('  2. (Optional) Run data migration: npm run db:migrate-entity-audit-records');
    console.log('');
  } catch (error: any) {
    console.error('\n' + '='.repeat(60));
    console.error('✗ Migration failed!');
    console.error('='.repeat(60));
    console.error('\nError:', error.message);
    
    if (error.code) {
      console.error('Error code:', error.code);
    }
    
    if (error.position) {
      console.error('Error position:', error.position);
    }
    
    console.error('\nPlease check:');
    console.error('  1. DATABASE_URL is correct');
    console.error('  2. Database is accessible');
    console.error('  3. You have necessary permissions');
    console.error('  4. Migration file exists: migrations/023_audit_records_year_ranges.sql');
    console.error('');
    
    throw error;
  } finally {
    client.release();
    await pool.end();
  }
}

runMigration()
  .then(() => {
    console.log('Done!');
    process.exit(0);
  })
  .catch((error) => {
    console.error('Migration error:', error);
    process.exit(1);
  });

