/**
 * Comprehensive Database Migration Runner
 * Executes all 14 database migrations in the correct order
 * 
 * Usage: npm run db:migrate-all
 */

import "dotenv/config";
import { Pool } from 'pg';
import * as fs from 'fs';
import * as path from 'path';
import { execSync } from 'child_process';

if (!process.env.DATABASE_URL) {
  throw new Error("DATABASE_URL must be set");
}

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

// Define all migrations in order
const migrations = [
  { file: '001_canonical_rbac.sql', name: 'Canonical RBAC System' },
  { file: '002_add_case_completed_by.sql', name: 'Add Case Completed By' },
  { file: '003_add_permissions_version.sql', name: 'Add Permissions Version' },
  { file: '004_production_indexes.sql', name: 'Production Indexes' },
  { file: '005_fix_audit_id_unique_constraint.sql', name: 'Fix Audit ID Unique Constraint' },
  { file: '006_entity_case_workflow_fixes.sql', name: 'Entity Case Workflow Fixes' },
  { file: '007_entity_types_table.sql', name: 'Entity Types Table' },
  { file: '008_fix_group_code_unique_constraint.sql', name: 'Fix Group Code Unique Constraint' },
  { file: '009_merge_entity_date_fields.sql', name: 'Merge Entity Date Fields' },
  { file: '010_add_case_transaction_fields.sql', name: 'Add Case Transaction Fields' },
  { file: '011_add_reports_override_permission.sql', name: 'Add Reports Override Permission' },
  { file: '012_create_case_reports_table.sql', name: 'Create Case Reports Table' },
  { file: '013_case_status_state_machine.sql', name: 'Case Status State Machine' },
  { file: '014_case_reports_v2_structured.sql', name: 'Case Reports V2 Structured' },
  { file: '015_create_ministry_reports_table.sql', name: 'Create Ministry Reports Table' },
  { file: '026_legacy_excel_archives.sql', name: 'Legacy Excel Archives Module' },
];

async function pushBaseSchema() {
  console.log("📐 Pushing base schema from Drizzle...");
  
  try {
    // Run drizzle-kit push to create base tables from schema.ts
    execSync("npx drizzle-kit push", {
      stdio: "inherit",
      env: process.env,
    });
    console.log("  ✓ Base schema pushed\n");
  } catch (error) {
    console.error("  ✗ Failed to push base schema:", error);
    throw error;
  }
}

async function checkBaseTablesExist(client: any): Promise<boolean> {
  try {
    const result = await client.query(`
      SELECT EXISTS (
        SELECT FROM information_schema.tables 
        WHERE table_schema = 'public' 
        AND table_name IN ('users', 'cases', 'entities', 'groups')
      );
    `);
    return result.rows[0]?.exists || false;
  } catch (error) {
    return false;
  }
}

async function runAllMigrations() {
  let client = await pool.connect();
  const migrationsDir = path.join(process.cwd(), 'migrations');
  
  console.log('🚀 Starting database migrations...\n');
  console.log(`📁 Migrations directory: ${migrationsDir}\n`);
  
  let successCount = 0;
  let skipCount = 0;
  let errorCount = 0;
  
  try {
    // Set search path
    await client.query(`SET search_path TO public;`);
    
    // Check if base tables exist
    const baseTablesExist = await checkBaseTablesExist(client);
    
    if (!baseTablesExist) {
      console.log('⚠️  Base tables (users, cases, entities, groups) not found.');
      console.log('📐 Pushing base schema first...\n');
      client.release();
      await pushBaseSchema();
      // Reconnect after schema push
      client = await pool.connect();
      await client.query(`SET search_path TO public;`);
    } else {
      console.log('✓ Base tables already exist, skipping schema push.\n');
    }
    
    console.log(`📊 Total migrations to run: ${migrations.length}\n`);
    console.log('─'.repeat(60));
    
    for (let i = 0; i < migrations.length; i++) {
      const migration = migrations[i];
      const migrationPath = path.join(migrationsDir, migration.file);
      const migrationNumber = String(i + 1).padStart(2, '0');
      
      // Check if migration file exists
      if (!fs.existsSync(migrationPath)) {
        console.log(`\n⚠️  [${migrationNumber}/${migrations.length}] ${migration.file}`);
        console.log(`   ⚠️  Migration file not found, skipping...`);
        skipCount++;
        continue;
      }
      
      console.log(`\n📦 [${migrationNumber}/${migrations.length}] ${migration.file}`);
      console.log(`   ${migration.name}`);
      console.log(`   → Running migration...`);
      
      try {
        // Read SQL migration file
        const sql = fs.readFileSync(migrationPath, 'utf-8');
        
        // Execute migration
        await client.query(sql);
        
        console.log(`   ✓ Migration completed successfully!`);
        successCount++;
      } catch (error: any) {
        // Check for common "already exists" errors that are safe to ignore
        const errorMessage = error.message || '';
        const errorCode = error.code || '';
        
        if (
          errorCode === '42P07' || // relation already exists
          errorCode === '42710' || // object already exists
          errorMessage.includes('already exists') ||
          errorMessage.includes('duplicate key') ||
          (errorMessage.includes('constraint') && errorMessage.includes('already exists'))
        ) {
          console.log(`   ⚠️  Migration may have already been applied (safe to ignore)`);
          console.log(`   ℹ️  Error: ${errorMessage.substring(0, 100)}...`);
          skipCount++;
        } else if (errorCode === '42P01') {
          // Relation does not exist - base schema might not be set up
          console.error(`   ❌ Migration failed!`);
          console.error(`   Error: ${errorMessage}`);
          console.error(`   Code: ${errorCode}`);
          console.error(`   ℹ️  This usually means base tables don't exist.`);
          console.error(`   💡 Try running: npm run db:push (to create base schema)`);
          errorCount++;
        } else {
          console.error(`   ❌ Migration failed!`);
          console.error(`   Error: ${errorMessage}`);
          if (error.code) {
            console.error(`   Code: ${errorCode}`);
          }
          errorCount++;
          
          // Ask if user wants to continue
          console.error(`\n⚠️  Migration ${migrationNumber} failed. Continuing with remaining migrations...`);
          console.error(`   Please review the error above and fix any issues.\n`);
        }
      }
    }
    
    console.log('\n' + '─'.repeat(60));
    console.log('\n📊 Migration Summary:');
    console.log(`   ✓ Successful: ${successCount}`);
    console.log(`   ⚠️  Skipped: ${skipCount}`);
    console.log(`   ❌ Errors: ${errorCount}`);
    console.log(`   📦 Total: ${migrations.length}`);
    
    if (errorCount > 0) {
      console.log('\n⚠️  Some migrations failed. Please review the errors above.');
      console.log('   You may need to fix issues and re-run specific migrations.');
    } else if (successCount > 0) {
      console.log('\n✅ All migrations completed successfully!');
    }
    
  } catch (error: any) {
    console.error('\n❌ Fatal error during migration process:', error);
    throw error;
  } finally {
    if (client) {
      client.release();
    }
    await pool.end();
  }
}

// Run migrations
runAllMigrations()
  .then(() => {
    console.log('\n✨ Migration runner finished!\n');
    process.exit(0);
  })
  .catch((error) => {
    console.error('\n❌ Migration runner failed:', error);
    process.exit(1);
  });

