/**
 * Migration Script: Linked Audit Record Architecture
 * Refactors entity-audit workflow to separate permanent entity identity from audit instances
 * 
 * This script:
 * 1. Adds new fields to audit_records table
 * 2. Migrates audit data from entities to audit_records
 * 3. Removes audit-related fields from entities table
 */

import "dotenv/config";
import { Pool } from "pg";
import * as fs from "fs";
import * as path from "path";
import { fileURLToPath } from "url";
import { dirname } from "path";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

if (!process.env.DATABASE_URL) {
  throw new Error("DATABASE_URL must be set in environment variables or .env file");
}

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

async function runMigration() {
  const client = await pool.connect();
  
  try {
    console.log("🔄 Starting Linked Audit Record Architecture migration...");
    console.log("");
    
    // Read the SQL migration file
    const migrationPath = path.join(process.cwd(), 'migrations', '024_linked_audit_record_architecture.sql');
    
    if (!fs.existsSync(migrationPath)) {
      throw new Error(`Migration file not found: ${migrationPath}`);
    }
    
    const sql = fs.readFileSync(migrationPath, 'utf-8');
    
    console.log("📝 Executing migration SQL...");
    
    // Execute the migration
    await client.query(sql);
    
    console.log("");
    console.log("✅ Migration completed successfully!");
    console.log("");
    console.log("Changes applied:");
    console.log("  - Added audit_years, referring_group, referral_date, assigned_group to audit_records");
    console.log("  - Migrated audit data from entities to audit_records");
    console.log("  - Removed audit-related fields from entities table");
    console.log("");
    console.log("Next steps:");
    console.log("  1. Verify migration: SELECT COUNT(*) FROM audit_records;");
    console.log("  2. Check entities table: SELECT column_name FROM information_schema.columns WHERE table_name = 'entities';");
    console.log("  3. Test creating new entities and audit records");
    
  } catch (error: any) {
    console.error("");
    console.error("❌ Migration failed!");
    console.error("");
    console.error("Error:", error.message);
    if (error.code) {
      console.error("PostgreSQL Error Code:", error.code);
    }
    if (error.position) {
      console.error("Error Position:", error.position);
    }
    console.error("");
    console.error("Rollback may be required if migration partially completed.");
    throw error;
  } finally {
    client.release();
    await pool.end();
  }
}

// Run migration
runMigration()
  .then(() => {
    console.log("Migration script completed.");
    process.exit(0);
  })
  .catch((error) => {
    console.error("Fatal error:", error);
    process.exit(1);
  });

