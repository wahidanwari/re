/**
 * Migration Script: Payment Traceability (PHASE 1 & 2)
 * Runs migrations 031 and 032 for payment tracking and monthly snapshots
 * 
 * Usage: npm run db:migrate-payment-traceability
 * Or: tsx server/scripts/migrate-payment-traceability.ts
 */

import "dotenv/config";
import { Pool } from 'pg';
import * as fs from 'fs';
import * as path from 'path';

if (!process.env.DATABASE_URL) {
  console.error("❌ ERROR: DATABASE_URL environment variable is not set!");
  console.error("   Please set it in your .env file or environment variables");
  process.exit(1);
}

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

const migrations = [
  { 
    file: '031_create_payments_table.sql', 
    name: 'Create Payments Table (PHASE 1: Payment Traceability)' 
  },
  { 
    file: '032_create_case_monthly_snapshots_table.sql', 
    name: 'Create Case Monthly Snapshots Table (PHASE 2: Monthly Remaining Balance Snapshot)' 
  },
];

async function runMigrations() {
  const client = await pool.connect();
  const migrationsDir = path.join(process.cwd(), 'migrations');
  
  console.log('🚀 Starting Payment Traceability Migrations...\n');
  console.log(`📁 Migrations directory: ${migrationsDir}\n`);
  
  let successCount = 0;
  let skipCount = 0;
  let errorCount = 0;
  
  try {
    // Set search path
    await client.query(`SET search_path TO public;`);
    
    console.log(`📊 Total migrations to run: ${migrations.length}\n`);
    console.log('─'.repeat(60));
    
    for (let i = 0; i < migrations.length; i++) {
      const migration = migrations[i];
      const migrationPath = path.join(migrationsDir, migration.file);
      const migrationNumber = String(i + 1).padStart(2, '0');
      
      // Check if migration file exists
      if (!fs.existsSync(migrationPath)) {
        console.log(`\n⚠️  [${migrationNumber}/${migrations.length}] ${migration.file}`);
        console.log(`   ⚠️  Migration file not found, skipping...`);
        skipCount++;
        continue;
      }
      
      console.log(`\n📦 [${migrationNumber}/${migrations.length}] ${migration.file}`);
      console.log(`   ${migration.name}`);
      console.log(`   → Running migration...`);
      
      try {
        // Read SQL migration file
        const sql = fs.readFileSync(migrationPath, 'utf-8');
        
        // Execute migration
        await client.query(sql);
        
        console.log(`   ✓ Migration completed successfully!`);
        successCount++;
      } catch (error: any) {
        // Check for common "already exists" errors that are safe to ignore
        const errorMessage = error.message || '';
        const errorCode = error.code || '';
        
        if (
          errorCode === '42P07' || // relation already exists
          errorCode === '42710' || // object already exists
          errorMessage.includes('already exists') ||
          errorMessage.includes('duplicate key') ||
          (errorMessage.includes('constraint') && errorMessage.includes('already exists'))
        ) {
          console.log(`   ⚠️  Migration may have already been applied (safe to ignore)`);
          console.log(`   ℹ️  Error: ${errorMessage.substring(0, 100)}...`);
          skipCount++;
        } else if (errorCode === '42P01') {
          // Relation does not exist - base schema might not be set up
          console.error(`   ❌ Migration failed!`);
          console.error(`   Error: ${errorMessage}`);
          console.error(`   Code: ${errorCode}`);
          console.error(`   ℹ️  This usually means base tables don't exist.`);
          console.error(`   💡 Try running: npm run db:push (to create base schema)`);
          errorCount++;
        } else {
          console.error(`   ❌ Migration failed!`);
          console.error(`   Error: ${errorMessage}`);
          if (error.code) {
            console.error(`   Code: ${errorCode}`);
          }
          errorCount++;
          
          // Ask if user wants to continue
          console.error(`\n⚠️  Migration ${migrationNumber} failed. Continuing with remaining migrations...`);
          console.error(`   Please review the error above and fix any issues.\n`);
        }
      }
    }
    
    console.log('\n' + '─'.repeat(60));
    console.log('\n📊 Migration Summary:');
    console.log(`   ✓ Successful: ${successCount}`);
    console.log(`   ⚠️  Skipped: ${skipCount}`);
    console.log(`   ❌ Errors: ${errorCount}`);
    console.log('');
    
    if (errorCount === 0) {
      console.log('✅ All migrations completed successfully!');
      console.log('');
      console.log('📋 Next steps:');
      console.log('   1. Verify tables were created: payments, case_monthly_snapshots');
      console.log('   2. Test payment recording functionality');
      console.log('   3. Test monthly snapshot calculation');
    } else {
      console.log('⚠️  Some migrations had errors. Please review the output above.');
      process.exit(1);
    }
    
  } catch (error: any) {
    console.error('\n❌ Fatal error running migrations:', error);
    process.exit(1);
  } finally {
    client.release();
    await pool.end();
  }
}

// Run migrations
runMigrations().catch((error) => {
  console.error('Fatal error:', error);
  process.exit(1);
});

