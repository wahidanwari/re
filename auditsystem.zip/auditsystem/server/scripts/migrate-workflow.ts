/**
 * Workflow System Migration Runner
 * Executes all workflow-related migrations (016-020)
 * 
 * Usage: npm run db:migrate-workflow
 */

import "dotenv/config";
import { Pool } from 'pg';
import * as fs from 'fs';
import * as path from 'path';

if (!process.env.DATABASE_URL) {
  throw new Error("DATABASE_URL must be set in .env file");
}

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

// Define all workflow migrations in order
const migrations = [
  { file: '016_create_monthly_transactions_table.sql', name: 'MonthlyTransactions Table' },
  { file: '017_create_internal_report_table.sql', name: 'InternalReport Table' },
  { file: '018_create_ministry_summary_table.sql', name: 'MinistrySummary Table' },
  { file: '019_create_alerts_table.sql', name: 'Alerts Table' },
  { file: '020_create_workflow_config_table.sql', name: 'WorkflowConfig Table' },
];

async function runWorkflowMigrations() {
  const client = await pool.connect();
  const migrationsDir = path.join(process.cwd(), 'migrations');
  
  console.log('🚀 Starting Workflow System Migrations...\n');
  console.log(`📁 Migrations directory: ${migrationsDir}\n`);
  
  let successCount = 0;
  let skipCount = 0;
  let errorCount = 0;
  
  try {
    // Set search path
    await client.query(`SET search_path TO public;`);
    
    console.log(`📊 Total migrations to run: ${migrations.length}\n`);
    console.log('─'.repeat(60));
    
    for (let i = 0; i < migrations.length; i++) {
      const migration = migrations[i];
      const migrationPath = path.join(migrationsDir, migration.file);
      
      console.log(`\n[${i + 1}/${migrations.length}] ${migration.name}`);
      console.log(`   File: ${migration.file}`);
      
      // Check if file exists
      if (!fs.existsSync(migrationPath)) {
        console.log(`   ⚠️  File not found: ${migrationPath}`);
        errorCount++;
        continue;
      }
      
      try {
        // Read SQL file
        const sql = fs.readFileSync(migrationPath, 'utf-8');
        
        // Execute migration
        await client.query(sql);
        
        console.log(`   ✓ Migration completed successfully`);
        successCount++;
      } catch (error: any) {
        // Check if error is because table already exists
        if (error.message && error.message.includes('already exists')) {
          console.log(`   ⚠️  Table/view already exists, skipping...`);
          skipCount++;
        } else {
          console.log(`   ✗ Migration failed: ${error.message}`);
          console.log(`   Error details: ${error.stack}`);
          errorCount++;
        }
      }
    }
    
    console.log('\n' + '─'.repeat(60));
    console.log('\n📊 Migration Summary:');
    console.log(`   ✓ Successful: ${successCount}`);
    console.log(`   ⚠️  Skipped (already exists): ${skipCount}`);
    console.log(`   ✗ Failed: ${errorCount}`);
    
    if (errorCount === 0) {
      console.log('\n🎉 All workflow migrations completed successfully!');
      console.log('\nNext steps:');
      console.log('  1. Verify tables: Check that all 5 tables were created');
      console.log('  2. Test workflow: POST /api/workflow/automate/10/1404');
    } else {
      console.log('\n⚠️  Some migrations failed. Please check the errors above.');
      process.exit(1);
    }
  } catch (error: any) {
    console.error('\n❌ Fatal error:', error.message);
    process.exit(1);
  } finally {
    client.release();
    await pool.end();
  }
}

// Run migrations
runWorkflowMigrations().catch((error) => {
  console.error('Unhandled error:', error);
  process.exit(1);
});

