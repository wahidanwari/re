/**
 * Check what case statuses exist in the database
 */

import "dotenv/config";
import { Pool } from 'pg';

if (!process.env.DATABASE_URL) {
  throw new Error("DATABASE_URL must be set");
}

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

async function checkStatuses() {
  const client = await pool.connect();
  
  try {
    const result = await client.query(`
      SELECT status, COUNT(*) as count
      FROM cases
      GROUP BY status
      ORDER BY count DESC;
    `);
    
    console.log('Current case statuses in database:');
    result.rows.forEach(row => {
      console.log(`  "${row.status}": ${row.count} cases`);
    });
    
    // Check for invalid statuses
    const validStatuses = [
      'جدید',
      'اختصاص داده شده',
      'منتظر بررسی بازرس ارشد',
      'اختصاص داده شده به بازرس',
      'در جریان بررسی',
      'تکمیل شده',
      'منتظر تایید',
      'تایید شده',
      'رد شده',
      'عدم پاسخگو',
      'ارسال‌ شده به تنفیذ قانون',
      'در اقساط',
      'ارسال‌شده به تنفیذ قانون'
    ];
    
    const invalidStatuses = result.rows
      .filter(row => !validStatuses.includes(row.status))
      .map(row => row.status);
    
    if (invalidStatuses.length > 0) {
      console.log('\n⚠️  Invalid statuses found (not in constraint):');
      invalidStatuses.forEach(status => {
        const count = result.rows.find(r => r.status === status)?.count;
        console.log(`  "${status}": ${count} cases`);
      });
    } else {
      console.log('\n✓ All statuses are valid');
    }
    
  } catch (error: any) {
    console.error('Error:', error.message);
    process.exit(1);
  } finally {
    client.release();
    await pool.end();
  }
}

checkStatuses();

