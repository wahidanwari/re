// Verification script for case status state machine migration
import "dotenv/config";
import { Pool } from 'pg';

if (!process.env.DATABASE_URL) {
  throw new Error("DATABASE_URL must be set");
}

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

async function verifyMigration() {
  const client = await pool.connect();
  
  try {
    console.log('Verifying case status state machine migration...');
    
    // Check if case_status_transitions table exists
    const tableCheck = await client.query(`
      SELECT EXISTS (
        SELECT FROM information_schema.tables 
        WHERE table_name = 'case_status_transitions'
      );
    `);
    
    if (!tableCheck.rows[0].exists) {
      throw new Error('case_status_transitions table does not exist!');
    }
    console.log('✓ case_status_transitions table exists');
    
    // Check if constraints exist
    const constraintCheck = await client.query(`
      SELECT constraint_name 
      FROM information_schema.table_constraints 
      WHERE table_name = 'cases' 
      AND constraint_name IN ('cases_status_check', 'cases_approved_check', 'cases_rejected_check', 'cases_completed_check');
    `);
    
    console.log(`✓ Found ${constraintCheck.rows.length} check constraints on cases table`);
    
    // Check if indexes exist
    const indexCheck = await client.query(`
      SELECT indexname 
      FROM pg_indexes 
      WHERE tablename IN ('cases', 'case_status_transitions')
      AND indexname LIKE 'idx_%';
    `);
    
    console.log(`✓ Found ${indexCheck.rows.length} indexes`);
    
    // Check foreign keys
    const fkCheck = await client.query(`
      SELECT constraint_name 
      FROM information_schema.table_constraints 
      WHERE table_name = 'cases' 
      AND constraint_type = 'FOREIGN KEY'
      AND constraint_name LIKE 'fk_cases_%';
    `);
    
    console.log(`✓ Found ${fkCheck.rows.length} foreign key constraints on cases table`);
    
    console.log('\n✓ Migration verification completed successfully!');
  } catch (error) {
    console.error('Verification failed:', error);
    throw error;
  } finally {
    client.release();
    await pool.end();
  }
}

verifyMigration()
  .then(() => {
    console.log('Done!');
    process.exit(0);
  })
  .catch((error) => {
    console.error('Verification error:', error);
    process.exit(1);
  });

