/**
 * Cleanup Old Audit Logs Script
 * Removes audit logs older than specified days
 * 
 * Usage: tsx server/scripts/cleanup-old-logs.ts [days]
 * Default: 90 days
 */

import "dotenv/config";
import { db } from "../db";
import { auditLogs } from "@shared/schema";
import { lt } from "drizzle-orm";
import { sql } from "drizzle-orm";

const RETENTION_DAYS = parseInt(process.argv[2] || "90", 10);

async function cleanupOldLogs() {
  try {
    console.log(`Starting cleanup of audit logs older than ${RETENTION_DAYS} days...`);
    
    // Calculate cutoff date
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - RETENTION_DAYS);
    
    // Get count of logs to be deleted
    const logsToDelete = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(auditLogs)
      .where(lt(auditLogs.createdAt, cutoffDate));
    
    const count = logsToDelete[0]?.count || 0;
    
    if (count === 0) {
      console.log("No old audit logs to delete.");
      return;
    }
    
    console.log(`Found ${count} audit logs to delete.`);
    
    // Delete old logs
    const deleted = await db
      .delete(auditLogs)
      .where(lt(auditLogs.createdAt, cutoffDate))
      .returning({ id: auditLogs.id });
    
    console.log(`Successfully deleted ${deleted.length} audit logs.`);
    console.log(`Cleanup completed at ${new Date().toISOString()}`);
    
    process.exit(0);
  } catch (error) {
    console.error("Error cleaning up audit logs:", error);
    process.exit(1);
  }
}

cleanupOldLogs();

