// Migration script to add user preferences columns
import "dotenv/config";
import { Pool } from 'pg';

if (!process.env.DATABASE_URL) {
  throw new Error("DATABASE_URL must be set");
}

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

async function addUserPreferencesColumns() {
  const client = await pool.connect();
  
  try {
    console.log('Adding user preferences columns...');
    
    // Check if columns already exist
    const checkQuery = `
      SELECT column_name 
      FROM information_schema.columns 
      WHERE table_name = 'users' 
      AND column_name IN ('email_notifications', 'mobile_notifications', 'preferred_language')
    `;
    const existingColumns = await client.query(checkQuery);
    const existingColumnNames = existingColumns.rows.map((r: any) => r.column_name);
    
    if (!existingColumnNames.includes('email_notifications')) {
      await client.query(`
        ALTER TABLE users 
        ADD COLUMN IF NOT EXISTS email_notifications BOOLEAN DEFAULT true
      `);
      console.log('✓ Added email_notifications column');
    } else {
      console.log('✓ email_notifications column already exists');
    }
    
    if (!existingColumnNames.includes('mobile_notifications')) {
      await client.query(`
        ALTER TABLE users 
        ADD COLUMN IF NOT EXISTS mobile_notifications BOOLEAN DEFAULT true
      `);
      console.log('✓ Added mobile_notifications column');
    } else {
      console.log('✓ mobile_notifications column already exists');
    }
    
    if (!existingColumnNames.includes('preferred_language')) {
      await client.query(`
        ALTER TABLE users 
        ADD COLUMN IF NOT EXISTS preferred_language TEXT DEFAULT 'dari'
      `);
      console.log('✓ Added preferred_language column');
    } else {
      console.log('✓ preferred_language column already exists');
    }
    
    console.log('Migration completed successfully!');
  } catch (error) {
    console.error('Migration failed:', error);
    throw error;
  } finally {
    client.release();
    await pool.end();
  }
}

addUserPreferencesColumns()
  .then(() => {
    console.log('Done!');
    process.exit(0);
  })
  .catch((error) => {
    console.error('Error:', error);
    process.exit(1);
  });

