// Migration script for case reports v2
import "dotenv/config";
import { Pool } from 'pg';
import * as fs from 'fs';
import * as path from 'path';

if (!process.env.DATABASE_URL) {
  throw new Error("DATABASE_URL must be set");
}

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

async function runMigration() {
  const client = await pool.connect();
  
  try {
    console.log('Starting case reports v2 migration...');
    
    // Read SQL migration file
    const migrationPath = path.join(process.cwd(), 'migrations', '014_case_reports_v2_structured.sql');
    const sql = fs.readFileSync(migrationPath, 'utf-8');
    
    // Execute migration
    await client.query(sql);
    
    console.log('✓ Case reports v2 migration completed successfully!');
    console.log('✓ case_reports_v2 table created');
    console.log('✓ case_report_history table created');
    console.log('✓ Existing data migrated');
    console.log('✓ Indexes created');
  } catch (error) {
    console.error('Migration failed:', error);
    throw error;
  } finally {
    client.release();
    await pool.end();
  }
}

runMigration()
  .then(() => {
    console.log('Done!');
    process.exit(0);
  })
  .catch((error) => {
    console.error('Migration error:', error);
    process.exit(1);
  });

