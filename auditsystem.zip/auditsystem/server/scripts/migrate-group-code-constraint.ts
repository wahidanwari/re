// Migration script to fix group code unique constraint
import "dotenv/config";
import { Pool } from 'pg';
import * as fs from 'fs';
import * as path from 'path';

if (!process.env.DATABASE_URL) {
  throw new Error("DATABASE_URL must be set");
}

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

async function runMigration() {
  const client = await pool.connect();
  
  try {
    console.log('Starting group code constraint migration...');
    
    // Read SQL migration file
    const migrationPath = path.join(process.cwd(), 'migrations', '008_fix_group_code_unique_constraint.sql');
    const sql = fs.readFileSync(migrationPath, 'utf-8');
    
    // Execute migration
    await client.query(sql);
    
    console.log('✓ Group code constraint migration completed successfully!');
    console.log('✓ Partial unique index created (only for active groups)');
    console.log('✓ Soft-deleted groups can now reuse codes');
  } catch (error) {
    console.error('Migration failed:', error);
    throw error;
  } finally {
    client.release();
    await pool.end();
  }
}

runMigration()
  .then(() => {
    console.log('Done!');
    process.exit(0);
  })
  .catch((error) => {
    console.error('Migration error:', error);
    process.exit(1);
  });

