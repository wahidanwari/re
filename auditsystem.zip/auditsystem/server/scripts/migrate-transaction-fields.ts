// Migration script to add transactionId and paymentDate fields to cases table
import "dotenv/config";
import { Pool } from 'pg';
import * as fs from 'fs';
import * as path from 'path';

if (!process.env.DATABASE_URL) {
  throw new Error("DATABASE_URL must be set");
}

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

async function runMigration() {
  const client = await pool.connect();
  
  try {
    console.log('Starting transaction fields migration...');
    
    // Read SQL migration file
    const migrationPath = path.join(process.cwd(), 'migrations', '010_add_case_transaction_fields.sql');
    const sql = fs.readFileSync(migrationPath, 'utf-8');
    
    // Execute migration
    await client.query(sql);
    
    console.log('✓ Transaction fields migration completed successfully!');
    console.log('✓ Added transaction_id column to cases table');
    console.log('✓ Added payment_date column to cases table');
  } catch (error: any) {
    if (error.code === '42703' || error.message?.includes('does not exist')) {
      console.error('Migration failed: Column might already exist or table structure issue');
    } else {
      console.error('Migration failed:', error);
    }
    throw error;
  } finally {
    client.release();
    await pool.end();
  }
}

runMigration()
  .then(() => {
    console.log('Done!');
    process.exit(0);
  })
  .catch((error) => {
    console.error('Migration error:', error);
    process.exit(1);
  });

