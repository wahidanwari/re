/**
 * Fix invalid case statuses before updating constraint
 */

import "dotenv/config";
import { Pool } from 'pg';

if (!process.env.DATABASE_URL) {
  throw new Error("DATABASE_URL must be set");
}

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

async function fixStatuses() {
  const client = await pool.connect();
  
  try {
    console.log('Fixing invalid case statuses...');
    
    // Get all unique statuses
    const result = await client.query(`
      SELECT DISTINCT status, COUNT(*) as count
      FROM cases
      GROUP BY status
      ORDER BY count DESC;
    `);
    
    const validStatuses = [
      'جدید',
      'اختصاص داده شده',
      'منتظر بررسی بازرس ارشد',
      'اختصاص داده شده به بازرس',
      'در جریان بررسی',
      'تکمیل شده',
      'منتظر تایید',
      'تایید شده',
      'رد شده',
      'عدم پاسخگو',
      'ارسال‌ شده به تنفیذ قانون',
      'در اقساط',
      'ارسال‌شده به تنفیذ قانون'
    ];
    
    console.log('\nCurrent statuses:');
    for (const row of result.rows) {
      const isValid = validStatuses.includes(row.status);
      console.log(`  "${row.status}": ${row.count} cases ${isValid ? '✓' : '✗ INVALID'}`);
      
      if (!isValid) {
        // Map invalid statuses to valid ones
        let newStatus: string;
        if (row.status === 'در انتظار بررسی') {
          newStatus = 'اختصاص داده شده';
        } else if (row.status === 'ارجاع به تنفیذ قانون') {
          newStatus = 'ارسال‌ شده به تنفیذ قانون';
        } else {
          // Default: use 'جدید' for unknown statuses
          newStatus = 'جدید';
          console.log(`    ⚠️  Unknown status, mapping to 'جدید'`);
        }
        
        await client.query(`
          UPDATE cases
          SET status = $1
          WHERE status = $2
        `, [newStatus, row.status]);
        
        console.log(`    → Updated to "${newStatus}"`);
      }
    }
    
    console.log('\n✓ All invalid statuses have been fixed');
    
  } catch (error: any) {
    console.error('Error:', error.message);
    process.exit(1);
  } finally {
    client.release();
    await pool.end();
  }
}

fixStatuses();

