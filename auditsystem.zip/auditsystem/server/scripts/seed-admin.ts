import { db } from "../db";
import { users } from "@shared/schema";
import { hashPassword } from "../auth/password";
import { eq } from "drizzle-orm";

async function seedAdmin() {
  try {
    console.log("Checking for existing admin user...");
    
    const existingAdmin = await db
      .select()
      .from(users)
      .where(eq(users.auditId, "anwari2027"))
      .limit(1);

    if (existingAdmin.length > 0) {
      console.log("✓ Admin user 'anwari2027' already exists");
      process.exit(0);
    }

    console.log("Creating default system admin user...");
    
    const hashedPassword = await hashPassword("passpin123");
    
    const [admin] = await db
      .insert(users)
      .values({
        auditId: "anwari2027",
        password: hashedPassword,
        fullName: "عبدالله احمدی",
        role: "system_admin",
        phoneNumber: "+93 700 000 001",
        mustChangePassword: false,
        permissionPackages: [],
      })
      .returning();

    console.log("✓ Successfully created admin user:");
    console.log(`  Audit ID: ${admin.auditId}`);
    console.log(`  Full Name: ${admin.fullName}`);
    console.log(`  Role: ${admin.role}`);
    console.log("\n  Login credentials:");
    console.log(`  Username: anwari2027`);
    console.log(`  Password: passpin123`);
    console.log("\n⚠️  Remember to change the password in production!");
    
    process.exit(0);
  } catch (error) {
    console.error("✗ Error seeding admin user:", error);
    process.exit(1);
  }
}

seedAdmin();
