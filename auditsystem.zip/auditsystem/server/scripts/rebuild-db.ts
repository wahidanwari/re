/**
 * PHASE 1: Fresh Database Rebuild Script
 * Drops and recreates the entire database schema from migrations
 * 
 * WARNING: This will destroy all data!
 */

import "dotenv/config";
import { Pool } from "pg";
import * as fs from "fs";
import * as path from "path";
import { fileURLToPath } from "url";
import { dirname } from "path";
import { execSync } from "child_process";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Environment check
if (process.env.NODE_ENV === "production") {
  console.error("❌ ERROR: Cannot run rebuild-db in production environment!");
  console.error("   Set NODE_ENV to 'development' or 'test' to proceed.");
  process.exit(1);
}

if (!process.env.DATABASE_URL) {
  throw new Error("DATABASE_URL must be set");
}

// Parse database URL to get database name
function getDatabaseName(url: string): string {
  try {
    const urlObj = new URL(url);
    return urlObj.pathname.slice(1); // Remove leading '/'
  } catch {
    // If URL parsing fails, try regex
    const match = url.match(/\/\/(?:[^:]+:[^@]+@)?[^\/]+\/([^?]+)/);
    if (match) {
      return match[1];
    }
    throw new Error("Could not parse database name from DATABASE_URL");
  }
}

// Get connection URL without database name (to connect to postgres database)
function getPostgresUrl(url: string): string {
  try {
    const urlObj = new URL(url);
    urlObj.pathname = "/postgres";
    return urlObj.toString();
  } catch {
    // Fallback: replace database name with 'postgres'
    return url.replace(/\/[^\/]+(\?|$)/, "/postgres$1");
  }
}

async function pushBaseSchema() {
  console.log("📐 Pushing base schema from Drizzle...");
  
  try {
    // Run drizzle-kit push to create base tables from schema.ts
    execSync("npx drizzle-kit push", {
      stdio: "inherit",
      env: process.env,
    });
    console.log("  ✓ Base schema pushed");
  } catch (error) {
    console.error("  ✗ Failed to push base schema:", error);
    throw error;
  }
}

async function runMigrations(pool: Pool, dbName: string) {
  console.log("📦 Running SQL migrations...");
  
  const migrationsDir = path.join(process.cwd(), "migrations");
  const migrationFiles = [
    "001_canonical_rbac.sql",
    "002_add_case_completed_by.sql",
    "003_add_permissions_version.sql",
    "004_production_indexes.sql",
    "005_fix_audit_id_unique_constraint.sql",
    "006_entity_case_workflow_fixes.sql",
    "007_entity_types_table.sql",
  ].filter(file => {
    const filePath = path.join(migrationsDir, file);
    return fs.existsSync(filePath);
  });

  if (migrationFiles.length === 0) {
    throw new Error("No migration files found in migrations/ directory");
  }

  const client = await pool.connect();
  
  try {
    // Connect to the target database
    await client.query(`SET search_path TO public;`);
    
    for (const migrationFile of migrationFiles) {
      console.log(`  → Running ${migrationFile}...`);
      const migrationPath = path.join(migrationsDir, migrationFile);
      const sql = fs.readFileSync(migrationPath, "utf-8");
      
      await client.query(sql);
      console.log(`  ✓ ${migrationFile} completed`);
    }
  } finally {
    client.release();
  }
  
  console.log("✓ All migrations completed");
}

async function fixUniqueConstraints(pool: Pool) {
  console.log("🔧 Fixing unique constraints...");
  
  const client = await pool.connect();
  
  try {
    // Fix auditId unique constraint to allow reuse after deletion
    // Create a partial unique index that only applies to active users
    await client.query(`
      -- Drop existing unique constraint if it exists
      DROP INDEX IF EXISTS users_audit_id_unique;
      ALTER TABLE users DROP CONSTRAINT IF EXISTS users_audit_id_unique;
      
      -- Create partial unique index for active users only
      CREATE UNIQUE INDEX IF NOT EXISTS users_audit_id_active_unique 
      ON users(audit_id) 
      WHERE is_active = true;
    `);
    
    console.log("  ✓ Fixed users.auditId unique constraint (allows reuse for deleted users)");
    
    // Ensure other unique constraints are in place
    await client.query(`
      -- Ensure entities.tin is unique
      CREATE UNIQUE INDEX IF NOT EXISTS entities_tin_unique ON entities(tin);
      
      -- Ensure cases.case_id is unique
      CREATE UNIQUE INDEX IF NOT EXISTS cases_case_id_unique ON cases(case_id);
      
      -- Ensure cases.case_number is unique (partial, for non-null values)
      CREATE UNIQUE INDEX IF NOT EXISTS cases_case_number_unique 
      ON cases(case_number) 
      WHERE case_number IS NOT NULL;
      
      -- Ensure tickets.ticket_id is unique
      CREATE UNIQUE INDEX IF NOT EXISTS tickets_ticket_id_unique ON tickets(ticket_id);
      
      -- Ensure groups.code is unique
      CREATE UNIQUE INDEX IF NOT EXISTS groups_code_unique ON groups(code);
    `);
    
    console.log("  ✓ All unique constraints verified");
  } finally {
    client.release();
  }
}

async function rebuildDatabase() {
  const dbUrl = process.env.DATABASE_URL!;
  const dbName = getDatabaseName(dbUrl);
  const postgresUrl = getPostgresUrl(dbUrl);
  
  console.log("🗑️  Starting fresh database rebuild...");
  console.log(`   Database: ${dbName}`);
  console.log(`   Environment: ${process.env.NODE_ENV || "development"}`);
  console.log("");
  
  // Connect to postgres database to drop/create target database
  const adminPool = new Pool({ connectionString: postgresUrl });
  const adminClient = await adminPool.connect();
  
  try {
    // Terminate all connections to the target database
    console.log("🔌 Terminating existing connections...");
    await adminClient.query(`
      SELECT pg_terminate_backend(pg_stat_activity.pid)
      FROM pg_stat_activity
      WHERE pg_stat_activity.datname = $1
        AND pid <> pg_backend_pid();
    `, [dbName]);
    console.log("  ✓ Connections terminated");
    
    // Drop database
    console.log(`🗑️  Dropping database '${dbName}'...`);
    await adminClient.query(`DROP DATABASE IF EXISTS ${adminClient.escapeIdentifier(dbName)};`);
    console.log("  ✓ Database dropped");
    
    // Create database
    console.log(`✨ Creating fresh database '${dbName}'...`);
    await adminClient.query(`CREATE DATABASE ${adminClient.escapeIdentifier(dbName)};`);
    console.log("  ✓ Database created");
    
  } finally {
    adminClient.release();
    await adminPool.end();
  }
  
  // Connect to the new database and push base schema, then run migrations
  const pool = new Pool({ connectionString: dbUrl });
  
  try {
    // Step 1: Push base schema from Drizzle (creates users, groups, cases, etc.)
    await pushBaseSchema();
    
    // Step 2: Run SQL migrations (RBAC, indexes, etc.)
    await runMigrations(pool, dbName);
    
    // Step 3: Fix unique constraints
    await fixUniqueConstraints(pool);
    
    console.log("\n✅ Database rebuild completed successfully!");
    console.log("\n📝 Next steps:");
    console.log("   1. Run: npm run db:seed");
    console.log("   2. Or run: npm run db:reset (to seed automatically)");
    
  } finally {
    await pool.end();
  }
}

rebuildDatabase()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error("\n❌ Database rebuild failed:", error);
    process.exit(1);
  });

