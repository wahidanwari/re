/**
 * Migration: Case Management Enhancements
 * Adds assignment tracking, override fields, metrics, installments, and flags
 * 
 * Usage: npm run db:migrate-case-management-enhancements
 */

import "dotenv/config";
import { Pool } from 'pg';
import * as fs from 'fs';
import * as path from 'path';

if (!process.env.DATABASE_URL) {
  throw new Error("DATABASE_URL must be set");
}

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

async function runMigration() {
  const client = await pool.connect();
  
  try {
    console.log('🚀 Starting Case Management Enhancements migration...\n');
    
    // Set search path
    await client.query(`SET search_path TO public;`);
    
    // Read migration file
    const migrationPath = path.join(process.cwd(), 'migrations', '027_case_management_enhancements.sql');
    
    if (!fs.existsSync(migrationPath)) {
      throw new Error(`Migration file not found: ${migrationPath}`);
    }
    
    console.log(`📄 Reading migration file: ${migrationPath}`);
    const sql = fs.readFileSync(migrationPath, 'utf-8');
    
    console.log('⚙️  Executing migration...\n');
    
    // Execute migration
    await client.query(sql);
    
    console.log('✅ Migration completed successfully!\n');
    console.log('📋 Summary:');
    console.log('  - Added columns to cases table (assigned_by, assigned_at, override fields, reopen fields)');
    console.log('  - Created case_metrics table');
    console.log('  - Created installment_payments table');
    console.log('  - Created case_flags table');
    console.log('  - Created case_section_status table');
    console.log('  - Updated status constraints');
    console.log('  - Created indexes for performance');
    
  } catch (error) {
    console.error('❌ Migration failed:', error);
    throw error;
  } finally {
    client.release();
    await pool.end();
  }
}

runMigration().catch((error) => {
  console.error('Fatal error:', error);
  process.exit(1);
});

