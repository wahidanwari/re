/**
 * Monthly Aggregation Job
 * Computes monthly group reports for the previous month
 * Should be run on the 1st of each month (or configurable)
 * 
 * Usage:
 *   node -r ts-node/register server/scripts/monthlyAggregationJob.ts [month] [year]
 * 
 * If month/year not provided, uses previous month
 */

import { upsertMonthlyReport } from '../services/monthlyGroupReportService';
import { storage } from '../storage';
import jalaali from 'jalaali-js';

async function runMonthlyAggregation(month?: number, year?: number) {
  try {
    console.log('Starting monthly aggregation job...');
    
    // Determine month/year to process
    let targetMonth: number;
    let targetYear: number;
    
    if (month && year) {
      targetMonth = month;
      targetYear = year;
    } else {
      // Default to previous month
      const now = new Date();
      const shamsi = jalaali.toJalaali(now);
      
      if (shamsi.jm === 1) {
        // If current month is حمل (1), previous month is حوت (12) of previous year
        targetMonth = 12;
        targetYear = shamsi.jy - 1;
      } else {
        targetMonth = shamsi.jm - 1;
        targetYear = shamsi.jy;
      }
    }
    
    console.log(`Processing reports for month ${targetMonth}, year ${targetYear}`);
    
    // Get all active groups
    const groups = await storage.getGroups();
    const activeGroups = groups.filter(g => g.isActive);
    
    console.log(`Found ${activeGroups.length} active groups`);
    
    // Process each group
    const results = [];
    for (const group of activeGroups) {
      try {
        console.log(`Processing group: ${group.name} (${group.id})`);
        
        // Use system user ID or a special service account
        // In production, you might want to create a system user for this
        const systemUserId = 'system'; // This should be a real system user ID
        
        const report = await upsertMonthlyReport(
          group.id,
          targetMonth,
          targetYear,
          systemUserId
        );
        
        results.push({
          groupId: group.id,
          groupName: group.name,
          success: true,
          reportId: report.id,
        });
        
        console.log(`✓ Completed: ${group.name}`);
      } catch (error: any) {
        console.error(`✗ Error processing group ${group.name}:`, error.message);
        results.push({
          groupId: group.id,
          groupName: group.name,
          success: false,
          error: error.message,
        });
      }
    }
    
    // Summary
    const successful = results.filter(r => r.success).length;
    const failed = results.filter(r => !r.success).length;
    
    console.log('\n=== Aggregation Summary ===');
    console.log(`Total groups: ${activeGroups.length}`);
    console.log(`Successful: ${successful}`);
    console.log(`Failed: ${failed}`);
    
    if (failed > 0) {
      console.log('\nFailed groups:');
      results.filter(r => !r.success).forEach(r => {
        console.log(`  - ${r.groupName}: ${r.error}`);
      });
    }
    
    console.log('\nMonthly aggregation job completed.');
    
    return results;
  } catch (error: any) {
    console.error('Fatal error in monthly aggregation job:', error);
    throw error;
  }
}

// Run if executed directly
if (require.main === module) {
  const args = process.argv.slice(2);
  const month = args[0] ? parseInt(args[0], 10) : undefined;
  const year = args[1] ? parseInt(args[1], 10) : undefined;
  
  runMonthlyAggregation(month, year)
    .then(() => {
      console.log('Job finished successfully');
      process.exit(0);
    })
    .catch((error) => {
      console.error('Job failed:', error);
      process.exit(1);
    });
}

export { runMonthlyAggregation };

