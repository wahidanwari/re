/**
 * PHASE 2: Reset Development Data Script
 * Truncates all data tables and re-seeds default data
 * 
 * This script:
 * - Truncates all data tables (respecting foreign keys)
 * - Resets SERIAL sequences
 * - Re-seeds default users, roles, permissions, and packages
 * 
 * WARNING: This will delete all data!
 */

import "dotenv/config";
import { Pool } from "pg";
import { runSeed } from "./seed";

// Environment check
if (process.env.NODE_ENV === "production") {
  console.error("❌ ERROR: Cannot run reset-db in production environment!");
  console.error("   Set NODE_ENV to 'development' or 'test' to proceed.");
  process.exit(1);
}

if (!process.env.DATABASE_URL) {
  throw new Error("DATABASE_URL must be set");
}

// Tables in dependency order (child tables first, then parents)
// This ensures we can truncate with CASCADE
const TABLES_TO_TRUNCATE = [
  // Bridge/mapping tables (depend on users, roles, packages, etc.)
  "user_packages",
  "user_roles",
  "package_permissions",
  "role_permissions",
  "group_targets",
  "group_members",
  
  // Data tables with foreign keys
  "notifications",
  "documents",
  "tickets",
  "cases",
  "entities",
  "audit_logs",
  "system_settings",
  
  // User and group tables
  "users",
  "groups",
  
  // RBAC base tables (no dependencies)
  "packages",
  "permissions",
  "roles",
  
  // Session table (if exists)
  "session",
];

// Tables with SERIAL primary keys that need sequence reset
const SERIAL_TABLES = [
  "roles",
  "permissions",
  "role_permissions",
  "packages",
  "package_permissions",
  "user_roles",
  "user_packages",
];

async function truncateAllTables(pool: Pool) {
  console.log("🗑️  Truncating all tables...");
  
  const client = await pool.connect();
  
  try {
    // Disable foreign key checks temporarily (PostgreSQL doesn't support this directly,
    // but we'll use TRUNCATE CASCADE which handles dependencies)
    
    // Start transaction
    await client.query("BEGIN");
    
    try {
      // Truncate all tables in reverse dependency order with CASCADE
      // This ensures all related data is deleted
      for (const table of TABLES_TO_TRUNCATE.reverse()) {
        // Check if table exists before trying to truncate
        const tableExists = await client.query(`
          SELECT EXISTS (
            SELECT FROM information_schema.tables 
            WHERE table_schema = 'public' 
            AND table_name = $1
          );
        `, [table]);
        
        if (tableExists.rows[0].exists) {
          await client.query(`TRUNCATE TABLE ${client.escapeIdentifier(table)} CASCADE;`);
          console.log(`  ✓ Truncated ${table}`);
        } else {
          console.log(`  ⚠ Table ${table} does not exist, skipping...`);
        }
      }
      
      // Reset SERIAL sequences
      console.log("\n🔄 Resetting SERIAL sequences...");
      for (const table of SERIAL_TABLES) {
        try {
          // Get the sequence name (usually table_name_column_name_seq)
          const sequenceQuery = `
            SELECT column_name, column_default
            FROM information_schema.columns
            WHERE table_name = $1 
              AND column_default LIKE 'nextval%'
            LIMIT 1;
          `;
          
          const seqResult = await client.query(sequenceQuery, [table]);
          
          if (seqResult.rows.length > 0) {
            const defaultVal = seqResult.rows[0].column_default;
            const seqMatch = defaultVal.match(/'([^']+)'/);
            
            if (seqMatch) {
              const seqName = seqMatch[1];
              await client.query(`ALTER SEQUENCE ${client.escapeIdentifier(seqName)} RESTART WITH 1;`);
              console.log(`  ✓ Reset sequence for ${table}`);
            }
          }
        } catch (error: any) {
          // Table might not exist or have no sequence, skip it
          if (error.code !== "42P01") {
            console.log(`  ⚠ Could not reset sequence for ${table}: ${error.message}`);
          }
        }
      }
      
      // Commit transaction
      await client.query("COMMIT");
      console.log("\n✓ All tables truncated and sequences reset");
      
    } catch (error) {
      await client.query("ROLLBACK");
      throw error;
    }
    
  } finally {
    client.release();
  }
}

async function resetDatabase() {
  const dbUrl = process.env.DATABASE_URL!;
  
  console.log("🔄 Starting database reset...");
  console.log(`   Environment: ${process.env.NODE_ENV || "development"}`);
  console.log("");
  
  const pool = new Pool({ connectionString: dbUrl });
  
  try {
    // Step 1: Truncate all tables
    await truncateAllTables(pool);
    
    console.log("\n🌱 Re-seeding default data...");
    
    // Step 2: Re-seed
    await runSeed();
    
    console.log("\n✅ Database reset completed successfully!");
    console.log("\n📋 The database now contains:");
    console.log("   • Fresh schema (no leftover data)");
    console.log("   • Default system users");
    console.log("   • Standard roles and permissions");
    console.log("   • Permission packages");
    console.log("   • No test data, cases, entities, or documents");
    
  } finally {
    await pool.end();
  }
}

resetDatabase()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error("\n❌ Database reset failed:", error);
    process.exit(1);
  });

