/**
 * Migration: Monthly Group Reports
 * Adds monthly_tax_target to groups and creates monthly_group_reports tables
 * 
 * Usage: npm run db:migrate-monthly-group-reports
 */

import "dotenv/config";
import { Pool } from 'pg';
import * as fs from 'fs';
import * as path from 'path';

if (!process.env.DATABASE_URL) {
  throw new Error("DATABASE_URL must be set");
}

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

async function runMigration() {
  const client = await pool.connect();
  
  try {
    console.log('🚀 Starting Monthly Group Reports migration...\n');
    
    // Set search path
    await client.query(`SET search_path TO public;`);
    
    // Read migration file
    const migrationPath = path.join(process.cwd(), 'migrations', '030_monthly_group_reports.sql');
    
    if (!fs.existsSync(migrationPath)) {
      throw new Error(`Migration file not found: ${migrationPath}`);
    }
    
    console.log(`📄 Reading migration file: ${migrationPath}`);
    const sql = fs.readFileSync(migrationPath, 'utf-8');
    
    console.log('⚙️  Executing migration...\n');
    
    // Execute migration
    await client.query(sql);
    
    console.log('✅ Migration completed successfully!\n');
    
    // Verify tables were created
    const tablesCheck = await client.query(`
      SELECT table_name 
      FROM information_schema.tables 
      WHERE table_schema = 'public' 
      AND table_name IN ('monthly_group_reports', 'monthly_report_anomalies')
      ORDER BY table_name;
    `);
    
    if (tablesCheck.rows.length === 2) {
      console.log('✓ Verified: monthly_group_reports table created');
      console.log('✓ Verified: monthly_report_anomalies table created');
    } else {
      console.warn('⚠️  Warning: Some tables may not have been created');
      console.log('Tables found:', tablesCheck.rows.map(r => r.table_name));
    }
    
    // Verify column was added to groups
    const columnCheck = await client.query(`
      SELECT column_name, data_type 
      FROM information_schema.columns 
      WHERE table_name = 'groups' 
      AND column_name = 'monthly_tax_target';
    `);
    
    if (columnCheck.rows.length > 0) {
      console.log('✓ Verified: monthly_tax_target column added to groups table');
      console.log(`  Type: ${columnCheck.rows[0].data_type}`);
    } else {
      console.warn('⚠️  Warning: monthly_tax_target column may not have been added');
    }
    
    console.log('\n🎉 Migration verification complete!');
    
  } catch (error: any) {
    console.error('❌ Migration failed:', error.message);
    console.error(error);
    throw error;
  } finally {
    client.release();
    await pool.end();
  }
}

// Run migration
runMigration()
  .then(() => {
    console.log('\n✅ All done!');
    process.exit(0);
  })
  .catch((error) => {
    console.error('\n❌ Migration failed:', error);
    process.exit(1);
  });

