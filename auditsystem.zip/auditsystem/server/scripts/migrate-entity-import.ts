/**
 * Entity Import System Migration Runner
 * Executes migration 021_entity_import_system.sql
 * 
 * Usage: npm run db:migrate-entity-import
 */

import "dotenv/config";
import { Pool } from 'pg';
import * as fs from 'fs';
import * as path from 'path';

if (!process.env.DATABASE_URL) {
  throw new Error("DATABASE_URL must be set in .env file");
}

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

async function runEntityImportMigration() {
  const client = await pool.connect();
  const migrationsDir = path.join(process.cwd(), 'migrations');
  const migrationFile = '021_entity_import_system.sql';
  const migrationPath = path.join(migrationsDir, migrationFile);
  
  console.log('🚀 Starting Entity Import System Migration...\n');
  console.log(`📁 Migration file: ${migrationPath}\n`);
  
  try {
    // Check if file exists
    if (!fs.existsSync(migrationPath)) {
      console.error(`❌ Migration file not found: ${migrationPath}`);
      process.exit(1);
    }
    
    // Set search path
    await client.query(`SET search_path TO public;`);
    
    // Read SQL file
    console.log('📖 Reading migration file...');
    const sql = fs.readFileSync(migrationPath, 'utf-8');
    
    // Execute migration
    console.log('⚙️  Executing migration...\n');
    await client.query(sql);
    
    console.log('─'.repeat(60));
    console.log('\n✓ Entity import system migration completed successfully!');
    console.log('\n📊 Created:');
    console.log('   - import_batches table');
    console.log('   - import_errors table');
    console.log('   - Extended entities table with import fields');
    console.log('   - Indexes for performance');
    console.log('\n🎉 Migration complete!');
    
  } catch (error: any) {
    // Check if error is because table/column already exists
    if (error.message && (
      error.message.includes('already exists') ||
      error.message.includes('duplicate') ||
      error.code === '42P07' || // duplicate_table
      error.code === '42701'    // duplicate_column
    )) {
      console.log('⚠️  Tables/columns already exist, migration may have already been run.');
      console.log('   This is safe to ignore if you intended to re-run the migration.');
    } else {
      console.error('\n❌ Migration failed:', error.message);
      if (error.stack) {
        console.error('Error details:', error.stack);
      }
      process.exit(1);
    }
  } finally {
    client.release();
    await pool.end();
  }
}

// Run migration
runEntityImportMigration().catch((error) => {
  console.error('Unhandled error:', error);
  process.exit(1);
});

