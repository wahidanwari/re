// Migration script to add completed_by field to cases table
import "dotenv/config";
import { Pool } from 'pg';
import * as fs from 'fs';
import * as path from 'path';

if (!process.env.DATABASE_URL) {
  throw new Error("DATABASE_URL must be set");
}

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

async function runMigration() {
  const client = await pool.connect();
  
  try {
    console.log('Starting migration: Add completed_by field to cases table...');
    
    // Read SQL migration file
    const migrationPath = path.join(process.cwd(), 'migrations', '002_add_case_completed_by.sql');
    const sql = fs.readFileSync(migrationPath, 'utf-8');
    
    // Execute migration
    await client.query(sql);
    
    console.log('✓ Migration completed successfully!');
    console.log('✓ Added completed_by column to cases table');
    console.log('✓ Added index on completed_by column');
  } catch (error: any) {
    if (error.code === '42703' || error.message?.includes('does not exist')) {
      // Column might already exist, try to check first
      console.log('Checking if column already exists...');
      const checkResult = await client.query(`
        SELECT column_name 
        FROM information_schema.columns 
        WHERE table_name='cases' AND column_name='completed_by'
      `);
      
      if (checkResult.rows.length > 0) {
        console.log('✓ Column completed_by already exists, skipping migration');
      } else {
        console.error('Migration failed:', error);
        throw error;
      }
    } else {
      console.error('Migration failed:', error);
      throw error;
    }
  } finally {
    client.release();
    await pool.end();
  }
}

runMigration()
  .then(() => {
    console.log('Done!');
    process.exit(0);
  })
  .catch((error) => {
    console.error('Migration failed:', error);
    process.exit(1);
  });

