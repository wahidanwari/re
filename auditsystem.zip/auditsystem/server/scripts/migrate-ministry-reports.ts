// Migration script to create ministry_reports table
import "dotenv/config";
import { Pool } from 'pg';
import * as fs from 'fs';
import * as path from 'path';

if (!process.env.DATABASE_URL) {
  throw new Error("DATABASE_URL must be set");
}

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

async function runMigration() {
  const client = await pool.connect();
  
  try {
    console.log('Starting ministry_reports table migration...');
    
    // Read SQL migration file
    const migrationPath = path.join(process.cwd(), 'migrations', '015_create_ministry_reports_table.sql');
    const sql = fs.readFileSync(migrationPath, 'utf-8');
    
    // Execute migration
    await client.query(sql);
    
    console.log('✓ Ministry reports migration completed successfully!');
    console.log('✓ Created ministry_reports table with all required fields');
    console.log('✓ Added indexes for performance');
  } catch (error: any) {
    if (error.code === '42P07' || error.message?.includes('already exists')) {
      console.warn('⚠ Table might already exist, continuing...');
    } else {
      console.error('Migration failed:', error);
      throw error;
    }
  } finally {
    client.release();
    await pool.end();
  }
}

runMigration()
  .then(() => {
    console.log('Done!');
    process.exit(0);
  })
  .catch((error) => {
    console.error('Migration error:', error);
    process.exit(1);
  });

