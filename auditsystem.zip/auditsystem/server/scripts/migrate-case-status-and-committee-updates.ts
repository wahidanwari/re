/**
 * Migration: Case Status and Committee Updates
 * Adds auditYearRange, assignedAuditor to cases
 * Adds month, year, locked fields to committees
 * Updates status constraints
 * 
 * Usage: npm run db:migrate-case-status-and-committee-updates
 */

import "dotenv/config";
import { Pool } from 'pg';
import * as fs from 'fs';
import * as path from 'path';

if (!process.env.DATABASE_URL) {
  throw new Error("DATABASE_URL must be set");
}

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

async function runMigration() {
  const client = await pool.connect();
  
  try {
    console.log('🚀 Starting migration: Case Status and Committee Updates...\n');
    
    // Read the SQL migration file
    const migrationsDir = path.join(process.cwd(), 'migrations');
    const migrationFile = path.join(migrationsDir, '029_case_status_and_committee_updates.sql');
    
    if (!fs.existsSync(migrationFile)) {
      throw new Error(`Migration file not found: ${migrationFile}`);
    }
    
    const sql = fs.readFileSync(migrationFile, 'utf-8');
    
    // Set search path
    await client.query('SET search_path TO public;');
    
    // Execute the migration
    console.log('📝 Executing SQL migration...');
    await client.query(sql);
    
    console.log('✅ Migration completed successfully!\n');
    console.log('Changes applied:');
    console.log('  - Added auditYearRange column to cases table');
    console.log('  - Added assignedAuditor column to cases table');
    console.log('  - Added month, year, locked columns to committees table');
    console.log('  - Updated case status constraint to include new statuses');
    console.log('  - Created indexes for performance\n');
    
  } catch (error: any) {
    console.error('❌ Migration failed:', error.message);
    if (error.code === '42710') {
      console.log('⚠️  Some columns may already exist. This is safe to ignore.');
    } else {
      throw error;
    }
  } finally {
    client.release();
    await pool.end();
  }
}

runMigration().catch((error) => {
  console.error('Fatal error:', error);
  process.exit(1);
});

