/**
 * Migration: Update cases_status_check constraint to include all valid statuses
 * Adds missing statuses that are used in the application but not in the constraint
 */

import "dotenv/config";
import { Pool } from 'pg';
import { readFileSync } from 'fs';
import { join } from 'path';

if (!process.env.DATABASE_URL) {
  throw new Error("DATABASE_URL must be set");
}

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

async function runMigration() {
  const client = await pool.connect();
  
  try {
    console.log('Updating cases_status_check constraint...');
    
    // Read the migration SQL file
    const sqlPath = join(process.cwd(), 'migrations', '035_update_cases_status_check_constraint.sql');
    const sql = readFileSync(sqlPath, 'utf-8');
    
    // Execute the migration
    await client.query(sql);
    
    console.log('✓ Successfully updated cases_status_check constraint');
    console.log('  Added all valid case statuses including:');
    console.log('  - منتظر بررسی بازرس ارشد');
    console.log('  - اختصاص داده شده به بازرس');
    console.log('  - عدم پاسخگو');
    console.log('  - ارسال‌ شده به تنفیذ قانون');
    console.log('  - در اقساط');
    console.log('  - ارسال‌شده به تنفیذ قانون');
    console.log('  Note: Committee-assigned cases use "اختصاص داده شده" (ASSIGNED)');
    
  } catch (error: any) {
    console.error('✗ Migration failed:', error.message);
    if (error.detail) {
      console.error('  Detail:', error.detail);
    }
    process.exit(1);
  } finally {
    client.release();
    await pool.end();
  }
}

runMigration();

