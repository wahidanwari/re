/**
 * Run Legacy Excel Archives Migration
 * 
 * Executes the 026_legacy_excel_archives.sql migration file
 * Works on Windows without requiring psql
 * 
 * Usage: npm run db:migrate-archives
 */

import "dotenv/config";
import { Pool } from 'pg';
import * as fs from 'fs';
import * as path from 'path';

if (!process.env.DATABASE_URL) {
  throw new Error("DATABASE_URL must be set");
}

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

async function runArchiveMigration() {
  const client = await pool.connect();
  const migrationsDir = path.join(process.cwd(), 'migrations');
  const migrationFile = '026_legacy_excel_archives.sql';
  const migrationPath = path.join(migrationsDir, migrationFile);
  
  console.log('🚀 Running Legacy Excel Archives Migration...\n');
  console.log(`📁 Migration file: ${migrationPath}\n`);
  
  try {
    // Check if migration file exists
    if (!fs.existsSync(migrationPath)) {
      throw new Error(`Migration file not found: ${migrationPath}`);
    }
    
    // Set search path
    await client.query(`SET search_path TO public;`);
    
    // Read SQL migration file
    console.log('📖 Reading migration file...');
    const sql = fs.readFileSync(migrationPath, 'utf-8');
    
    // Execute migration
    console.log('⚙️  Executing migration...');
    await client.query(sql);
    
    console.log('\n✅ Migration completed successfully!');
    console.log('   Tables created:');
    console.log('   - archived_files');
    console.log('   - archived_file_versions');
    console.log('   - archived_file_access_logs');
    console.log('   - Indexes created');
    
  } catch (error: any) {
    console.error('\n❌ Migration failed:');
    console.error(`   ${error.message}`);
    
    if (error.code === '42P07') {
      console.error('\n   ⚠️  Table already exists. Migration may have already been run.');
    } else if (error.code === '23505') {
      console.error('\n   ⚠️  Unique constraint violation. Some data may already exist.');
    }
    
    process.exit(1);
  } finally {
    client.release();
    await pool.end();
  }
}

// Run migration
runArchiveMigration().catch((error) => {
  console.error('Fatal error:', error);
  process.exit(1);
});

