// Migration script to create case_reports table
import "dotenv/config";
import { Pool } from 'pg';
import * as fs from 'fs';
import * as path from 'path';

if (!process.env.DATABASE_URL) {
  throw new Error("DATABASE_URL must be set");
}

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

async function runMigration() {
  const client = await pool.connect();
  
  try {
    console.log('Starting case_reports table migration...');
    
    // Read SQL migration file
    const migrationPath = path.join(process.cwd(), 'migrations', '012_create_case_reports_table.sql');
    const sql = fs.readFileSync(migrationPath, 'utf-8');
    
    // Execute migration
    await client.query(sql);
    
    console.log('✓ Case reports migration completed successfully!');
    console.log('✓ Created case_reports table with all required fields');
    console.log('✓ Added indexes for performance');
  } catch (error: any) {
    if (error.code === '42P07' || error.message?.includes('already exists')) {
      console.warn('⚠ Table might already exist, continuing...');
    } else {
      console.error('Migration failed:', error);
      throw error;
    }
  } finally {
    client.release();
    await pool.end();
  }
}

runMigration()
  .then(() => {
    console.log('Done!');
    process.exit(0);
  })
  .catch((error) => {
    console.error('Migration error:', error);
    process.exit(1);
  });

