/**
 * Migration Script: Convert per-year entities to Master Entity + Audit Records
 * 
 * This script migrates the existing data structure where entities were created
 * per audit year to the new normalized structure with:
 * - Single master entity per TIN
 * - Multiple audit_records linked to the entity with year ranges
 * 
 * Usage:
 *   npm run migrate:entity-audit-records [--dry-run]
 * 
 * Options:
 *   --dry-run: Preview changes without applying them
 */

import 'dotenv/config';
import { db, pool } from '../db';
import { entities, auditRecords } from '@shared/schema';
import { eq, sql } from 'drizzle-orm';
import * as readline from 'readline';

interface MigrationStats {
  totalEntities: number;
  duplicateTINs: number;
  masterEntitiesCreated: number;
  masterEntitiesKept: number;
  auditRecordsCreated: number;
  errors: Array<{ entityId: string; error: string }>;
}

interface EntityWithYear {
  id: string;
  tin: string;
  companyName: string;
  yearsUnderReview?: string;
  periodsUnderReview?: string;
  referralGroup?: string;
  createdDate?: Date;
  status: string;
  [key: string]: any;
}

function parseYearRange(yearsString?: string): Array<{ from: number; to: number }> {
  if (!yearsString) return [];
  
  const ranges: Array<{ from: number; to: number }> = [];
  
  // Handle formats like "1402", "1400-1402", "1398,1400-1402", etc.
  const parts = yearsString.split(/[,\s]+/).filter(p => p.trim());
  
  for (const part of parts) {
    const trimmed = part.trim();
    
    // Single year: "1402"
    if (/^\d+$/.test(trimmed)) {
      const year = parseInt(trimmed, 10);
      if (!isNaN(year)) {
        ranges.push({ from: year, to: year });
      }
    }
    // Range: "1400-1402"
    else if (/^\d+-\d+$/.test(trimmed)) {
      const [fromStr, toStr] = trimmed.split('-');
      const from = parseInt(fromStr, 10);
      const to = parseInt(toStr, 10);
      if (!isNaN(from) && !isNaN(to) && from <= to) {
        ranges.push({ from, to });
      }
    }
  }
  
  return ranges;
}

function extractYearFromEntity(entity: EntityWithYear): Array<{ from: number; to: number }> {
  // Try to extract year from yearsUnderReview or periodsUnderReview
  const yearRanges = parseYearRange(entity.yearsUnderReview || entity.periodsUnderReview);
  
  // If no year found in text fields, try to infer from createdDate
  if (yearRanges.length === 0 && entity.createdDate) {
    const date = new Date(entity.createdDate);
    // Convert to Shamsi year (approximate)
    const shamsiYear = date.getFullYear() - 621; // Rough conversion
    if (shamsiYear > 1300 && shamsiYear < 1500) {
      yearRanges.push({ from: shamsiYear, to: shamsiYear });
    }
  }
  
  return yearRanges;
}

async function findMasterEntity(tin: string): Promise<EntityWithYear | null> {
  const [entity] = await db
    .select()
    .from(entities)
    .where(eq(entities.tin, tin))
    .limit(1);
  
  return entity as EntityWithYear | null;
}

async function createAuditRecord(
  entityId: string,
  yearRange: { from: number; to: number },
  entityData: EntityWithYear,
  dryRun: boolean
): Promise<void> {
  if (dryRun) {
    console.log(`  [DRY RUN] Would create audit_record: entity=${entityId}, years=${yearRange.from}-${yearRange.to}`);
    return;
  }
  
  try {
    await db.insert(auditRecords).values({
      entityId,
      yearFrom: yearRange.from,
      yearTo: yearRange.to,
      auditGroupId: entityData.referralGroup || null,
      assignedAt: entityData.createdDate || new Date(),
      createdByUserId: null, // We don't have this info
      status: entityData.status === 'COMPLETED' ? 'completed' : 
              entityData.status === 'NEW' ? 'planned' : 'in_progress',
      notes: `Migrated from entity ${entityData.id}`,
      responsibleEvaluator: null,
    });
  } catch (error: any) {
    if (error.code === '23505') {
      // Unique constraint violation - overlap detected
      console.warn(`  [WARNING] Overlap detected for ${yearRange.from}-${yearRange.to}, skipping`);
    } else {
      throw error;
    }
  }
}

async function migrateEntity(
  entity: EntityWithYear,
  stats: MigrationStats,
  dryRun: boolean
): Promise<void> {
  const yearRanges = extractYearFromEntity(entity);
  
  if (yearRanges.length === 0) {
    console.log(`  [SKIP] Entity ${entity.id} (TIN: ${entity.tin}) - No year information found`);
    return;
  }
  
  // Find or create master entity
  let masterEntity = await findMasterEntity(entity.tin);
  
  if (!masterEntity) {
    // Create master entity (use the first entity we find as the master)
    if (dryRun) {
      console.log(`  [DRY RUN] Would create master entity for TIN: ${entity.tin}`);
      stats.masterEntitiesCreated++;
    } else {
      // Create master entity based on current entity
      const [newMaster] = await db.insert(entities).values({
        companyName: entity.companyName,
        tin: entity.tin,
        businessNature: entity.businessNature,
        referralGroup: entity.referralGroup,
        createdDate: entity.createdDate,
        status: 'NEW',
        notes: `Master entity created during migration from ${entity.id}`,
      }).returning();
      
      masterEntity = newMaster as EntityWithYear;
      stats.masterEntitiesCreated++;
    }
  } else {
    stats.masterEntitiesKept++;
  }
  
  if (!masterEntity) {
    stats.errors.push({
      entityId: entity.id,
      error: 'Failed to create or find master entity',
    });
    return;
  }
  
  // Create audit records for each year range
  for (const yearRange of yearRanges) {
    try {
      await createAuditRecord(masterEntity.id, yearRange, entity, dryRun);
      stats.auditRecordsCreated++;
    } catch (error: any) {
      stats.errors.push({
        entityId: entity.id,
        error: `Failed to create audit record for ${yearRange.from}-${yearRange.to}: ${error.message}`,
      });
    }
  }
  
  // If this entity is not the master, we could optionally delete it
  // For safety, we'll leave it and mark it in notes
  if (masterEntity.id !== entity.id && !dryRun) {
    await db
      .update(entities)
      .set({
        notes: `${entity.notes || ''}\n[MIGRATED] Master entity: ${masterEntity.id}`.trim(),
      })
      .where(eq(entities.id, entity.id));
  }
}

async function findDuplicateTINs(): Promise<Map<string, EntityWithYear[]>> {
  const allEntities = await db.select().from(entities);
  const tinMap = new Map<string, EntityWithYear[]>();
  
  for (const entity of allEntities) {
    const tin = entity.tin;
    if (!tinMap.has(tin)) {
      tinMap.set(tin, []);
    }
    tinMap.get(tin)!.push(entity as EntityWithYear);
  }
  
  // Filter to only duplicates
  const duplicates = new Map<string, EntityWithYear[]>();
  for (const [tin, entitiesList] of Array.from(tinMap.entries())) {
    if (entitiesList.length > 1) {
      duplicates.set(tin, entitiesList);
    }
  }
  
  return duplicates;
}

async function main() {
  const args = process.argv.slice(2);
  const dryRun = args.includes('--dry-run');
  
  console.log('='.repeat(60));
  console.log('Entity to Audit Records Migration Script');
  console.log('='.repeat(60));
  console.log(`Mode: ${dryRun ? 'DRY RUN (no changes will be made)' : 'LIVE (changes will be applied)'}`);
  console.log('');
  
  if (!dryRun) {
    const rl = readline.createInterface({
      input: process.stdin,
      output: process.stdout,
    });
    
    const answer = await new Promise<string>((resolve) => {
      rl.question('Are you sure you want to proceed with LIVE migration? (yes/no): ', resolve);
    });
    
    rl.close();
    
    const normalizedAnswer = answer.toLowerCase().trim();
    if (normalizedAnswer !== 'yes' && normalizedAnswer !== 'y') {
      console.log('Migration cancelled.');
      process.exit(0);
    }
  }
  
  const stats: MigrationStats = {
    totalEntities: 0,
    duplicateTINs: 0,
    masterEntitiesCreated: 0,
    masterEntitiesKept: 0,
    auditRecordsCreated: 0,
    errors: [],
  };
  
  try {
    // Step 1: Find all entities
    console.log('Step 1: Analyzing entities...');
    const allEntities = await db.select().from(entities);
    stats.totalEntities = allEntities.length;
    console.log(`  Found ${allEntities.length} entities`);
    
    // Step 2: Find duplicate TINs
    console.log('\nStep 2: Finding duplicate TINs...');
    const duplicateTINs = await findDuplicateTINs();
    stats.duplicateTINs = duplicateTINs.size;
    console.log(`  Found ${duplicateTINs.size} TINs with multiple entities`);
    
    // Step 3: Process entities with duplicate TINs first
    console.log('\nStep 3: Processing entities with duplicate TINs...');
    const duplicateEntries = Array.from(duplicateTINs.entries());
    for (const [tin, entitiesList] of duplicateEntries) {
      console.log(`\n  Processing TIN: ${tin} (${entitiesList.length} entities)`);
      
      // Sort by creation date (oldest first) to use as master
      const sorted = entitiesList.sort((a: EntityWithYear, b: EntityWithYear) => {
        const dateA = a.createdAt ? new Date(a.createdAt).getTime() : 0;
        const dateB = b.createdAt ? new Date(b.createdAt).getTime() : 0;
        return dateA - dateB;
      });
      
      for (const entity of sorted) {
        await migrateEntity(entity, stats, dryRun);
      }
    }
    
    // Step 4: Process remaining entities (single TIN per entity)
    console.log('\nStep 4: Processing remaining entities...');
    const processedTINs = new Set(duplicateTINs.keys());
    const remainingEntities = allEntities.filter(e => !processedTINs.has(e.tin));
    
    for (const entity of remainingEntities) {
      await migrateEntity(entity as EntityWithYear, stats, dryRun);
    }
    
    // Step 5: Print summary
    console.log('\n' + '='.repeat(60));
    console.log('Migration Summary');
    console.log('='.repeat(60));
    console.log(`Total entities processed: ${stats.totalEntities}`);
    console.log(`Duplicate TINs found: ${stats.duplicateTINs}`);
    console.log(`Master entities created: ${stats.masterEntitiesCreated}`);
    console.log(`Master entities kept: ${stats.masterEntitiesKept}`);
    console.log(`Audit records created: ${stats.auditRecordsCreated}`);
    console.log(`Errors: ${stats.errors.length}`);
    
    if (stats.errors.length > 0) {
      console.log('\nErrors:');
      for (const error of stats.errors) {
        console.log(`  - Entity ${error.entityId}: ${error.error}`);
      }
    }
    
    if (dryRun) {
      console.log('\n[DRY RUN] No changes were made. Run without --dry-run to apply changes.');
    } else {
      console.log('\nMigration completed successfully!');
    }
    
  } catch (error) {
    console.error('\nFatal error during migration:', error);
    process.exit(1);
  } finally {
    await pool.end();
  }
}

// Run migration
main().catch(console.error);

