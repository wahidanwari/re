// Migration script for case lifecycle redesign
import "dotenv/config";
import { Pool } from 'pg';
import * as fs from 'fs';
import * as path from 'path';

if (!process.env.DATABASE_URL) {
  throw new Error("DATABASE_URL must be set");
}

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

async function runMigration() {
  const client = await pool.connect();
  
  try {
    console.log('🚀 Starting case lifecycle redesign migration...');
    console.log('');
    
    // Read SQL migration file
    const migrationPath = path.join(process.cwd(), 'migrations', '036_case_lifecycle_redesign.sql');
    
    if (!fs.existsSync(migrationPath)) {
      throw new Error(`Migration file not found: ${migrationPath}`);
    }
    
    const sql = fs.readFileSync(migrationPath, 'utf-8');
    
    // Set search path
    await client.query(`SET search_path TO public;`);
    
    // Execute migration
    console.log('📦 Executing migration...');
    await client.query(sql);
    
    console.log('');
    console.log('✅ Case lifecycle redesign migration completed successfully!');
    console.log('✅ New flag columns added (is_law_enforcement, is_tax_installment, is_cancelled)');
    console.log('✅ Case statuses migrated to new 6-status lifecycle');
    console.log('✅ Status constraint updated');
    console.log('✅ Indexes created');
  } catch (error: any) {
    console.error('');
    console.error('❌ Migration failed:', error.message);
    if (error.code) {
      console.error(`   Error code: ${error.code}`);
    }
    if (error.detail) {
      console.error(`   Detail: ${error.detail}`);
    }
    throw error;
  } finally {
    client.release();
    await pool.end();
  }
}

runMigration()
  .then(() => {
    console.log('');
    console.log('Done!');
    process.exit(0);
  })
  .catch((error) => {
    console.error('');
    console.error('Migration error:', error);
    process.exit(1);
  });

