/**
 * Comprehensive Database Seeding Script
 * Seeds default system users, roles, permissions, and packages
 */

import "dotenv/config";
import { db } from "../db";
import { 
  users, roles, permissions, packages, 
  rolePermissions, packagePermissions, 
  userRoles, userPackages 
} from "@shared/schema";
import { hashPassword } from "../auth/password";
import { eq, sql, and } from "drizzle-orm";

interface SeedUser {
  auditId: string;
  password: string;
  fullName: string;
  role: string;
  phoneNumber?: string;
}

const DEFAULT_USERS: SeedUser[] = [
  {
    auditId: "admin001",
    password: "Admin@2024!",
    fullName: "System Administrator",
    role: "system_admin",
    phoneNumber: "+93 700 000 001",
  },
  {
    auditId: "auditor001",
    password: "Auditor@2024!",
    fullName: "Default Auditor",
    role: "auditor",
    phoneNumber: "+93 700 000 002",
  },
  {
    auditId: "senior001",
    password: "Senior@2024!",
    fullName: "Default Senior Auditor",
    role: "senior_auditor",
    phoneNumber: "+93 700 000 003",
  },
];

async function seedRoles() {
  console.log("Seeding roles...");
  
  const rolesData = [
    { name: "system_admin", description: "System Administrator - Full system control" },
    { name: "director", description: "Director - Oversight, final approvals, system-wide reporting" },
    { name: "senior_auditor", description: "Senior Auditor - Team lead, manages workflow of auditors" },
    { name: "auditor", description: "Auditor - Base-level user working on assigned cases" },
  ];

  for (const roleData of rolesData) {
    await db
      .insert(roles)
      .values(roleData)
      .onConflictDoNothing();
  }
  
  console.log("✓ Roles seeded");
}

async function seedPermissions() {
  console.log("Seeding permissions...");
  
  const permissionsData = [
    { name: "cases:read_all", description: "Read all cases" },
    { name: "cases:read_assigned", description: "Read assigned cases" },
    { name: "cases:assign_to_groups", description: "Assign cases to groups" },
    { name: "cases:assign_to_auditors", description: "Assign cases to auditors" },
    { name: "cases:update_progress", description: "Update case progress" },
    { name: "users:manage_all", description: "Manage all users" },
    { name: "groups:manage_all", description: "Manage all groups" },
    { name: "groups:manage_own", description: "Manage own group" },
    { name: "approvals:create_tickets", description: "Create approval tickets" },
    { name: "approvals:approve_tickets", description: "Approve/reject tickets" },
    { name: "reports:system_wide", description: "View system-wide reports" },
    { name: "reports:internal", description: "View internal reports" },
    { name: "reports:group_level", description: "View group-level reports" },
    { name: "system:manage_settings", description: "Manage system settings" },
  ];

  for (const permData of permissionsData) {
    await db
      .insert(permissions)
      .values(permData)
      .onConflictDoNothing();
  }
  
  console.log("✓ Permissions seeded");
}

async function seedPackages() {
  console.log("Seeding packages...");
  
  const packagesData = [
    { 
      name: "acting_coordinator", 
      description: "Acting Coordinator Package - Grants cases:assign_to_groups, groups:manage_all, reports:internal" 
    },
    { 
      name: "approval_authority", 
      description: "Approval Authority Package - Grants approvals:approve_tickets" 
    },
  ];

  for (const pkgData of packagesData) {
    await db
      .insert(packages)
      .values(pkgData)
      .onConflictDoNothing();
  }
  
  console.log("✓ Packages seeded");
}

async function seedRolePermissions() {
  console.log("Seeding role-permission mappings...");
  
  // Get role IDs
  const [sysAdminRole] = await db.select().from(roles).where(eq(roles.name, "system_admin")).limit(1);
  const [directorRole] = await db.select().from(roles).where(eq(roles.name, "director")).limit(1);
  const [seniorAuditorRole] = await db.select().from(roles).where(eq(roles.name, "senior_auditor")).limit(1);
  const [auditorRole] = await db.select().from(roles).where(eq(roles.name, "auditor")).limit(1);

  if (!sysAdminRole || !directorRole || !seniorAuditorRole || !auditorRole) {
    throw new Error("Required roles not found. Run seedRoles first.");
  }

  // Get all permissions
  const allPermissions = await db.select().from(permissions);
  const permissionMap = new Map(allPermissions.map(p => [p.name, p.id]));

  // System Admin: All permissions
  for (const perm of allPermissions) {
    await db
      .insert(rolePermissions)
      .values({
        roleId: sysAdminRole.id,
        permissionId: perm.id,
        allow: true,
      })
      .onConflictDoUpdate({
        set: { allow: true },
        target: [rolePermissions.roleId, rolePermissions.permissionId],
      });
  }

  // Director: Read cases, approve tickets, view reports
  const directorPerms = ["cases:read_all", "cases:read_assigned", "approvals:approve_tickets", 
                         "reports:system_wide", "reports:internal", "reports:group_level"];
  for (const permName of directorPerms) {
    const permId = permissionMap.get(permName);
    if (permId) {
      await db
        .insert(rolePermissions)
        .values({
          roleId: directorRole.id,
          permissionId: permId,
          allow: true,
        })
        .onConflictDoUpdate({
          set: { allow: true },
          target: [rolePermissions.roleId, rolePermissions.permissionId],
        });
    }
  }

  // Senior Auditor: Read cases, assign to auditors, update progress, manage own group, create tickets, group reports
  const seniorPerms = ["cases:read_all", "cases:read_assigned", "cases:assign_to_auditors", 
                       "cases:update_progress", "groups:manage_own", "approvals:create_tickets", 
                       "reports:group_level"];
  for (const permName of seniorPerms) {
    const permId = permissionMap.get(permName);
    if (permId) {
      await db
        .insert(rolePermissions)
        .values({
          roleId: seniorAuditorRole.id,
          permissionId: permId,
          allow: true,
        })
        .onConflictDoUpdate({
          set: { allow: true },
          target: [rolePermissions.roleId, rolePermissions.permissionId],
        });
    }
  }

  // Auditor: Read assigned cases, update progress, create tickets
  const auditorPerms = ["cases:read_assigned", "cases:update_progress", "approvals:create_tickets"];
  for (const permName of auditorPerms) {
    const permId = permissionMap.get(permName);
    if (permId) {
      await db
        .insert(rolePermissions)
        .values({
          roleId: auditorRole.id,
          permissionId: permId,
          allow: true,
        })
        .onConflictDoUpdate({
          set: { allow: true },
          target: [rolePermissions.roleId, rolePermissions.permissionId],
        });
    }
  }

  console.log("✓ Role-permission mappings seeded");
}

async function seedPackagePermissions() {
  console.log("Seeding package-permission mappings...");
  
  const [actingCoordPkg] = await db.select().from(packages).where(eq(packages.name, "acting_coordinator")).limit(1);
  const [approvalAuthPkg] = await db.select().from(packages).where(eq(packages.name, "approval_authority")).limit(1);

  if (!actingCoordPkg || !approvalAuthPkg) {
    throw new Error("Required packages not found. Run seedPackages first.");
  }

  const allPermissions = await db.select().from(permissions);
  const permissionMap = new Map(allPermissions.map(p => [p.name, p.id]));

  // Acting Coordinator Package
  const coordPerms = ["cases:assign_to_groups", "groups:manage_all", "reports:internal"];
  for (const permName of coordPerms) {
    const permId = permissionMap.get(permName);
    if (permId) {
      await db
        .insert(packagePermissions)
        .values({
          packageId: actingCoordPkg.id,
          permissionId: permId,
          allow: true,
        })
        .onConflictDoUpdate({
          set: { allow: true },
          target: [packagePermissions.packageId, packagePermissions.permissionId],
        });
    }
  }

  // Approval Authority Package
  const approvalPermId = permissionMap.get("approvals:approve_tickets");
  if (approvalPermId) {
    await db
      .insert(packagePermissions)
      .values({
        packageId: approvalAuthPkg.id,
        permissionId: approvalPermId,
        allow: true,
      })
      .onConflictDoUpdate({
        set: { allow: true },
        target: [packagePermissions.packageId, packagePermissions.permissionId],
      });
  }

  console.log("✓ Package-permission mappings seeded");
}

async function seedUsers() {
  console.log("Seeding default users...");
  
  for (const userData of DEFAULT_USERS) {
    // Check if active user with this auditId already exists
    // The unique constraint only applies to active users
    const existing = await db
      .select()
      .from(users)
      .where(
        and(
          eq(users.auditId, userData.auditId),
          eq(users.isActive, true)
        )
      )
      .limit(1);

    if (existing.length > 0) {
      console.log(`  ⚠ User ${userData.auditId} already exists (active), skipping...`);
      continue;
    }

    const hashedPassword = await hashPassword(userData.password);
    
    const [user] = await db
      .insert(users)
      .values({
        auditId: userData.auditId,
        password: hashedPassword,
        fullName: userData.fullName,
        role: userData.role,
        phoneNumber: userData.phoneNumber,
        mustChangePassword: false,
        permissionPackages: [],
        isActive: true,
      })
      .returning();

    // Assign role
    const [role] = await db.select().from(roles).where(eq(roles.name, userData.role)).limit(1);
    if (role) {
      await db
        .insert(userRoles)
        .values({
          userId: user.id,
          roleId: role.id,
        })
        .onConflictDoNothing();
    }

    console.log(`  ✓ Created user: ${userData.auditId} (${userData.fullName})`);
  }
  
  console.log("✓ Default users seeded");
}

export async function runSeed() {
  try {
    console.log("🌱 Starting database seeding...\n");
    
    await seedRoles();
    await seedPermissions();
    await seedPackages();
    await seedRolePermissions();
    await seedPackagePermissions();
    await seedUsers();
    
    console.log("\n✅ Database seeding completed successfully!");
    console.log("\n📋 Default User Credentials:");
    console.log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
    for (const user of DEFAULT_USERS) {
      console.log(`  ${user.auditId} | ${user.password} | ${user.fullName}`);
    }
    console.log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
    console.log("\n⚠️  Remember to change passwords in production!");
    
  } catch (error) {
    console.error("❌ Error seeding database:", error);
    throw error;
  }
}

// Run if called directly (not imported)
// Only execute if this file is run directly via tsx/node, not when imported
const isDirectExecution = process.argv[1] && (
  process.argv[1].endsWith('seed.ts') || 
  process.argv[1].includes('seed.ts')
) && !process.argv[1].includes('reset-db');

if (isDirectExecution) {
  runSeed()
    .then(() => process.exit(0))
    .catch((error) => {
      console.error("❌ Error seeding database:", error);
      process.exit(1);
    });
}

