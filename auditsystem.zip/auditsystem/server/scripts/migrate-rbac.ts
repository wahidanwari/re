// Migration script to set up canonical RBAC system
import "dotenv/config";
import { Pool } from 'pg';
import * as fs from 'fs';
import * as path from 'path';

if (!process.env.DATABASE_URL) {
  throw new Error("DATABASE_URL must be set");
}

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

async function runMigration() {
  const client = await pool.connect();
  
  try {
    console.log('Starting RBAC migration...');
    
    // Read SQL migration file
    const migrationPath = path.join(process.cwd(), 'migrations', '001_canonical_rbac.sql');
    const sql = fs.readFileSync(migrationPath, 'utf-8');
    
    // Execute migration
    await client.query(sql);
    
    console.log('✓ RBAC migration completed successfully!');
    console.log('✓ Roles, permissions, packages, and audit_logs tables created');
    console.log('✓ Existing users migrated to user_roles table');
    console.log('✓ Existing permission packages migrated to user_packages table');
  } catch (error) {
    console.error('Migration failed:', error);
    throw error;
  } finally {
    client.release();
    await pool.end();
  }
}

runMigration()
  .then(() => {
    console.log('Done!');
    process.exit(0);
  })
  .catch((error) => {
    console.error('Error:', error);
    process.exit(1);
  });

