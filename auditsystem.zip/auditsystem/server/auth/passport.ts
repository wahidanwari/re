import passport from 'passport';
import { Strategy as LocalStrategy } from 'passport-local';
import { storage } from '../storage';
import { comparePassword } from './password';
import type { User } from '@shared/schema';

passport.use(
  new LocalStrategy(
    {
      usernameField: 'auditId',
      passwordField: 'password',
    },
    async (auditId, password, done) => {
      try {
        const user = await storage.getUserByAuditId(auditId);
        
        if (!user) {
          return done(null, false, { message: 'آی دی بررسی یا رمز عبور نادرست است' });
        }

        // Check if user account is active
        if (!user.isActive) {
          // Log login attempt by deactivated user for audit purposes
          try {
            await storage.createAuditLog({
              userId: user.id,
              action: 'login_attempt_deactivated',
              entityType: 'user',
              entityId: user.id,
              details: {
                auditId: user.auditId,
                reason: 'Account is deactivated',
                attemptedAt: new Date().toISOString(),
              },
              ipAddress: undefined, // IP will be logged in the route handler
            });
          } catch (logError) {
            console.error('Failed to log deactivated user login attempt:', logError);
          }
          
          return done(null, false, { 
            message: 'حساب کاربری شما غیرفعال است. لطفاً با مدیر سیستم تماس بگیرید.' 
          });
        }

        const isValidPassword = await comparePassword(password, user.password);
        
        if (!isValidPassword) {
          return done(null, false, { message: 'آی دی بررسی یا رمز عبور نادرست است' });
        }

        return done(null, user);
      } catch (error) {
        return done(error);
      }
    }
  )
);

passport.serializeUser((user, done) => {
  done(null, (user as User).id);
});

passport.deserializeUser(async (id: string, done) => {
  try {
    const user = await storage.getUser(id);
    done(null, user || null);
  } catch (error) {
    done(error);
  }
});

export default passport;
