import type { Request, Response, NextFunction } from 'express';
import { ZodSchema, ZodError } from 'zod';

/**
 * Middleware to validate request body using Zod schema
 */
export function validateBody<T>(schema: ZodSchema<T>) {
  return (req: Request, res: Response, next: NextFunction) => {
    try {
      const validated = schema.parse(req.body);
      req.body = validated;
      next();
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({
          message: 'خطا در اعتبارسنجی داده‌ها',
          errors: error.errors.map(e => ({
            path: e.path.join('.'),
            message: e.message,
          })),
        });
      }
      return res.status(400).json({ message: 'خطا در اعتبارسنجی داده‌ها' });
    }
  };
}

/**
 * Middleware to validate request query parameters using Zod schema
 */
export function validateQuery<T>(schema: ZodSchema<T>) {
  return (req: Request, res: Response, next: NextFunction) => {
    try {
      const validated = schema.parse(req.query);
      req.query = validated as any;
      next();
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({
          message: 'خطا در اعتبارسنجی پارامترهای جستجو',
          errors: error.errors.map(e => ({
            path: e.path.join('.'),
            message: e.message,
          })),
        });
      }
      return res.status(400).json({ message: 'خطا در اعتبارسنجی پارامترهای جستجو' });
    }
  };
}

/**
 * Middleware to validate request params using Zod schema
 */
export function validateParams<T>(schema: ZodSchema<T>) {
  return (req: Request, res: Response, next: NextFunction) => {
    try {
      const validated = schema.parse(req.params);
      req.params = validated as any;
      next();
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({
          message: 'خطا در اعتبارسنجی پارامترهای مسیر',
          errors: error.errors.map(e => ({
            path: e.path.join('.'),
            message: e.message,
          })),
        });
      }
      return res.status(400).json({ message: 'خطا در اعتبارسنجی پارامترهای مسیر' });
    }
  };
}

/**
 * Sanitize string input to prevent XSS and injection attacks
 */
export function sanitizeString(input: string | undefined | null): string {
  if (!input || typeof input !== 'string') return '';
  
  return input
    .trim()
    .replace(/[<>]/g, '') // Remove HTML brackets
    .replace(/javascript:/gi, '') // Remove javascript: protocol
    .replace(/on\w+=/gi, '') // Remove event handlers
    .substring(0, 10000); // Limit length
}

/**
 * Sanitize object recursively
 */
export function sanitizeObject(obj: any): any {
  if (obj === null || obj === undefined) return obj;
  
  if (typeof obj === 'string') {
    return sanitizeString(obj);
  }
  
  if (Array.isArray(obj)) {
    return obj.map(item => sanitizeObject(item));
  }
  
  if (typeof obj === 'object') {
    const sanitized: any = {};
    for (const key in obj) {
      if (Object.prototype.hasOwnProperty.call(obj, key)) {
        // Sanitize key as well
        const sanitizedKey = sanitizeString(key);
        sanitized[sanitizedKey] = sanitizeObject(obj[key]);
      }
    }
    return sanitized;
  }
  
  return obj;
}

/**
 * Middleware to sanitize request body
 */
export function sanitizeBody(req: Request, _res: Response, next: NextFunction) {
  if (req.body && typeof req.body === 'object') {
    req.body = sanitizeObject(req.body);
  }
  next();
}

/**
 * Middleware to sanitize query parameters
 */
export function sanitizeQuery(req: Request, _res: Response, next: NextFunction) {
  if (req.query && typeof req.query === 'object') {
    req.query = sanitizeObject(req.query) as any;
  }
  next();
}

/**
 * Middleware to sanitize URL parameters
 */
export function sanitizeParams(req: Request, _res: Response, next: NextFunction) {
  if (req.params && typeof req.params === 'object') {
    req.params = sanitizeObject(req.params) as any;
  }
  next();
}

/**
 * SQL injection prevention: Check if string contains SQL injection patterns
 */
export function isSQLInjectionAttempt(input: string): boolean {
  if (!input || typeof input !== 'string') return false;
  
  const sqlPatterns = [
    /(\%27)|(\')|(\-\-)|(\%23)|(#)/i, // Single quote, comment
    /((\%3D)|(=))[^\n]*((\%27)|(\')|(\-\-)|(\%3B)|(;))/i, // SQL injection
    /\w*((\%27)|(\'))((\%6F)|o|(\%4F))((\%72)|r|(\%52))/i, // OR
    /((\%27)|(\'))union/i, // UNION
    /exec(\s|\+)+(s|x)p\w+/i, // EXEC stored procedure
    /;.*drop.*table/i, // DROP TABLE
    /;.*delete.*from/i, // DELETE FROM
    /;.*insert.*into/i, // INSERT INTO
    /;.*update.*set/i, // UPDATE SET
  ];
  
  return sqlPatterns.some(pattern => pattern.test(input));
}

/**
 * Middleware to check for SQL injection attempts in request body
 */
export function checkSQLInjection(req: Request, res: Response, next: NextFunction) {
  const checkValue = (value: any): boolean => {
    if (typeof value === 'string') {
      return isSQLInjectionAttempt(value);
    }
    if (Array.isArray(value)) {
      return value.some(item => checkValue(item));
    }
    if (value && typeof value === 'object') {
      return Object.values(value).some(val => checkValue(val));
    }
    return false;
  };
  
  // Check body
  if (req.body && checkValue(req.body)) {
    return res.status(400).json({ message: 'درخواست نامعتبر' });
  }
  
  // Check query
  if (req.query && checkValue(req.query)) {
    return res.status(400).json({ message: 'پارامترهای جستجو نامعتبر' });
  }
  
  // Check params
  if (req.params && checkValue(req.params)) {
    return res.status(400).json({ message: 'پارامترهای مسیر نامعتبر' });
  }
  
  next();
}

