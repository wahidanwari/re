// Permission Middleware - Uses the permission service to check permissions

import type { Request, Response, NextFunction } from 'express';
import type { User } from '@shared/schema';
import { hasPermission, type PermissionName } from '../services/permissionService';

/**
 * Middleware to require a specific permission
 */
export function requirePermission(permission: PermissionName) {
  return async (req: Request, res: Response, next: NextFunction) => {
    if (!req.isAuthenticated() || !req.user) {
      return res.status(401).json({ message: 'احراز هویت نشده' });
    }

    const user = req.user as User;
    
    // System admin bypasses all permission checks
    if (user.role === 'system_admin') {
      return next();
    }
    
    try {
      const hasPerm = await hasPermission(user.id, permission);
      
      // DEBUG LOGGING: Log permission checks (only in debug mode)
      if (process.env.DEBUG_LOGGING === 'true') {
        const { getEffectivePermissions } = await import('../services/permissionService');
        const effectivePerms = await getEffectivePermissions(user.id);
        const permList = Object.entries(effectivePerms)
          .filter(([_, has]) => has)
          .map(([perm]) => perm);
        console.log(`[PERMISSION CHECK] Route: ${req.path}, User: ${user.id} (${user.role}), Packages: ${JSON.stringify(user.permissionPackages || [])}, Required: ${permission}, Has: ${hasPerm}, Effective Perms: ${permList.join(', ')}`);
      }
      
      if (!hasPerm) {
        return res.status(403).json({ message: 'عدم دسترسی - شما مجوز لازم را ندارید' });
      }
      next();
    } catch (error) {
      console.error('Permission check error:', error);
      return res.status(500).json({ message: 'خطا در بررسی مجوز' });
    }
  };
}

/**
 * Middleware to require any of the specified permissions
 */
export function requireAnyPermission(permissions: PermissionName[]) {
  return async (req: Request, res: Response, next: NextFunction) => {
    if (!req.isAuthenticated() || !req.user) {
      return res.status(401).json({ message: 'احراز هویت نشده' });
    }

    const user = req.user as User;
    
    // System admin bypasses all permission checks
    if (user.role === 'system_admin') {
      return next();
    }
    
    try {
      const { hasPermission } = await import('../services/permissionService');
      const hasAnyPermission = await Promise.all(
        permissions.map(perm => hasPermission(user.id, perm))
      ).then(results => results.some(result => result));
      
      if (!hasAnyPermission) {
        return res.status(403).json({ message: 'عدم دسترسی - شما مجوز لازم را ندارید' });
      }
      next();
    } catch (error) {
      console.error('Permission check error:', error);
      return res.status(500).json({ message: 'خطا در بررسی مجوز' });
    }
  };
}

/**
 * Middleware to require all of the specified permissions
 */
export function requireAllPermissions(permissions: PermissionName[]) {
  return async (req: Request, res: Response, next: NextFunction) => {
    if (!req.isAuthenticated() || !req.user) {
      return res.status(401).json({ message: 'احراز هویت نشده' });
    }

    const user = req.user as User;
    
    // System admin bypasses all permission checks
    if (user.role === 'system_admin') {
      return next();
    }
    
    try {
      const { hasPermission } = await import('../services/permissionService');
      const hasAllPermissions = await Promise.all(
        permissions.map(perm => hasPermission(user.id, perm))
      ).then(results => results.every(result => result));
      
      if (!hasAllPermissions) {
        return res.status(403).json({ message: 'عدم دسترسی - شما مجوز لازم را ندارید' });
      }
      next();
    } catch (error) {
      console.error('Permission check error:', error);
      return res.status(500).json({ message: 'خطا در بررسی مجوز' });
    }
  };
}

/**
 * Helper to check permission (for use in route handlers)
 */
export async function userHasPermission(user: User, permission: PermissionName): Promise<boolean> {
  return await hasPermission(user.id, permission);
}

/**
 * Get effective permissions for a user (for use in route handlers)
 */
export async function getUserEffectivePermissions(user: User) {
  const { getEffectivePermissions } = await import('../services/permissionService');
  return await getEffectivePermissions(user.id);
}
