import type { Request, Response, NextFunction } from 'express';
import type { User } from '@shared/schema';

/**
 * Middleware to refresh user data from database on each request
 * This ensures we always have the latest permissions, role, and packages
 * Only applies to authenticated users
 */
export async function refreshUserData(req: Request, res: Response, next: NextFunction) {
  // Skip refresh for auth routes (login, logout, etc.)
  if (req.path.startsWith('/api/auth')) {
    return next();
  }

  if (!req.isAuthenticated() || !req.user) {
    return next();
  }

  try {
    const { storage } = await import('../storage');
    const sessionUser = req.user as User;
    const freshUser = await storage.getUser(sessionUser.id);
    
    if (freshUser) {
      // DEBUG LOGGING: Log user refresh (only in debug mode)
      if (process.env.DEBUG_LOGGING === 'true') {
        console.log(`[REFRESH USER DATA] User: ${freshUser.id} (${freshUser.role}), Packages: ${JSON.stringify(freshUser.permissionPackages || [])}, GroupId: ${freshUser.groupId || 'none'}`);
      }
      
      // Update req.user with fresh data (includes updated permissions)
      req.user = freshUser;
    }
  } catch (error) {
    console.error('Error refreshing user data:', error);
    // Don't fail the request if refresh fails
  }
  
  next();
}

export function requireAuth(req: Request, res: Response, next: NextFunction) {
  if (!req.isAuthenticated() || !req.user) {
    return res.status(401).json({ message: 'احراز هویت نشده - لطفاً وارد شوید' });
  }
  next();
}

export function isAuthenticated(req: Request): boolean {
  return req.isAuthenticated() && !!req.user;
}

export function getCurrentUser(req: Request): User | null {
  return (req.user as User) || null;
}
