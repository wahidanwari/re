import type { Request, Response, NextFunction } from 'express';
import type { User } from '@shared/schema';

// Session inactivity timeout in milliseconds (default: 90 minutes = 5400000ms)
// Range: 60-120 minutes as per requirements
const SESSION_INACTIVITY_TIMEOUT = parseInt(process.env.SESSION_INACTIVITY_TIMEOUT || '5400000', 10); // 90 minutes default
// Enable sliding expiration (default: true) - extends session on activity
const SLIDING_EXPIRATION = process.env.SLIDING_EXPIRATION !== 'false';

/**
 * Middleware to check session inactivity timeout
 * Implements sliding expiration: session expires after SESSION_TIMEOUT of inactivity
 * Each authenticated request updates lastActivity, extending the session
 */
export function sessionTimeout() {
  return (req: Request, res: Response, next: NextFunction) => {
    // Only check for authenticated sessions
    if (!req.session || !req.isAuthenticated()) {
      return next();
    }

    const now = Date.now();
    
    // Initialize lastActivity if not set (for new sessions)
    if (!req.session.lastActivity) {
      req.session.lastActivity = now;
      return next();
    }
    
    const timeSinceLastActivity = now - req.session.lastActivity;
    
    // Check if session has expired due to inactivity
    if (timeSinceLastActivity > SESSION_INACTIVITY_TIMEOUT) {
      // Log session expiration for audit
      const user = req.user as User | undefined;
      if (user && req.session && req.session.lastActivity) {
        // Use dynamic import for ES modules
        import('../storage').then(({ storage }) => {
          storage.createAuditLog({
            userId: user.id,
            action: 'session_expired',
            entityType: 'session',
            entityId: req.sessionID,
            details: {
              reason: 'inactivity_timeout',
              lastActivity: new Date(req.session.lastActivity).toISOString(),
              timeoutMs: SESSION_INACTIVITY_TIMEOUT,
            },
            ipAddress: req.ip,
          }).catch((err: any) => console.error('Failed to log session expiration:', err));
        }).catch((error) => {
          console.error('Failed to log session expiration:', error);
        });
      }
      
      req.session.destroy((err) => {
        if (err) {
          console.error('Session destruction error:', err);
        }
      });
      return res.status(401).json({ 
        message: '   شما به دلیل عدم فعالیت منقضی شده است',
        code: 'SESSION_EXPIRED'
      });
    }
    
    // Update lastActivity on each authenticated request (sliding expiration)
    if (SLIDING_EXPIRATION) {
      req.session.lastActivity = now;
      // Also update cookie expiration to extend session (use maxAge from session config)
      if (req.session.cookie) {
        const SESSION_MAX_AGE = parseInt(process.env.SESSION_MAX_AGE || '36000000', 10);
        req.session.cookie.maxAge = SESSION_MAX_AGE;
      }
    }
    
    next();
  };
}

export function checkPasswordExpiry() {
  return async (req: Request, res: Response, next: NextFunction) => {
    if (!req.isAuthenticated() || !req.user) {
      return next();
    }

    const user = req.user as User;
    
    // Check if password is expired
    if (user.passwordExpiresAt) {
      const now = new Date();
      if (now > user.passwordExpiresAt) {
        return res.status(403).json({
          message: 'رمز عبور شما منقضی شده است. لطفا رمز عبور را تغییر دهید',
          code: 'PASSWORD_EXPIRED',
          mustChangePassword: true
        });
      }
    }

    // Check if user must change password on first login
    if (user.mustChangePassword) {
      return res.status(403).json({
        message: 'شما باید رمز عبور خود را تغییر دهید',
        code: 'MUST_CHANGE_PASSWORD',
        mustChangePassword: true
      });
    }

    next();
  };
}

declare module 'express-session' {
  interface SessionData {
    lastActivity?: number;
  }
}
