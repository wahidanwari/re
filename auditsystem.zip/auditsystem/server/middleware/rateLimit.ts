import type { Request, Response, NextFunction } from 'express';
import { extractClientIp } from '../utils/ipExtractor';

interface RateLimitStore {
  [key: string]: {
    count: number;
    resetTime: number;
  };
}

interface LoginAttemptStore {
  [key: string]: {
    attempts: number[];
    lastAttempt: number;
  };
}

interface BurstStore {
  [key: string]: {
    requests: number[];
  };
}

// In-memory store for rate limiting
// In production, consider using Redis for distributed systems
const rateLimitStore: RateLimitStore = {};

// Store for tracking login attempts (per IP or user)
export const loginAttemptStore: LoginAttemptStore = {};

// Store for tracking API request bursts
const burstStore: BurstStore = {};

// Cleanup old entries periodically
setInterval(() => {
  const now = Date.now();
  for (const key in rateLimitStore) {
    if (rateLimitStore[key].resetTime < now) {
      delete rateLimitStore[key];
    }
  }
  
  // Cleanup login attempts older than 1 hour
  for (const key in loginAttemptStore) {
    const store = loginAttemptStore[key];
    store.attempts = store.attempts.filter(timestamp => now - timestamp < 60 * 60 * 1000);
    if (store.attempts.length === 0 && now - store.lastAttempt > 60 * 60 * 1000) {
      delete loginAttemptStore[key];
    }
  }
  
  // Cleanup burst data older than 10 seconds
  for (const key in burstStore) {
    const store = burstStore[key];
    store.requests = store.requests.filter(timestamp => now - timestamp < 10000);
    if (store.requests.length === 0) {
      delete burstStore[key];
    }
  }
}, 60000); // Cleanup every minute

/**
 * Rate limiting middleware (legacy - kept for backward compatibility)
 * @param windowMs - Time window in milliseconds
 * @param maxRequests - Maximum number of requests per window
 * @param message - Error message to return when limit is exceeded
 */
export function rateLimit(
  windowMs: number = 60 * 60 * 1000, // 60 minutes default
  maxRequests: number = 500, // 100 requests default
  message: string = 'تعداد درخواست‌ها بیش از حد مجاز است. لطفاً بعداً تلاش کنید.'
) {
  return (req: Request, res: Response, next: NextFunction) => {
    const clientIp = extractClientIp(req);
    const key = `${req.path}:${clientIp}`;
    const now = Date.now();
    
    // Get or create rate limit entry
    let entry = rateLimitStore[key];
    
    if (!entry || entry.resetTime < now) {
      // Create new entry or reset expired entry
      entry = {
        count: 0,
        resetTime: now + windowMs,
      };
      rateLimitStore[key] = entry;
    }
    
    // Increment count
    entry.count++;
    
    // Set rate limit headers
    res.setHeader('X-RateLimit-Limit', maxRequests.toString());
    res.setHeader('X-RateLimit-Remaining', Math.max(0, maxRequests - entry.count).toString());
    res.setHeader('X-RateLimit-Reset', new Date(entry.resetTime).toISOString());
    
    // Check if limit exceeded
    if (entry.count > maxRequests) {
      // Log rate limit violation
      console.warn(`Rate limit exceeded for ${clientIp} on ${req.path}`);
      
      return res.status(429).json({
        message,
        retryAfter: Math.ceil((entry.resetTime - now) / 1000), // seconds
      });
    }
    
    next();
  };
}

/**
 * Progressive delay rate limiting for authentication endpoints
 * - 1-5 failed attempts: no delay
 * - 6-10 failed attempts: 5-10 second delay
 * - 10+ failed attempts: log event, notify sysadmin, optional temporary delay
 * Never permanently locks out users
 */
export function authRateLimit() {
  return async (req: Request, res: Response, next: NextFunction) => {
    const clientIp = extractClientIp(req);
    const { auditId } = req.body || {};
    const key = auditId ? `login:${auditId}` : `login:ip:${clientIp}`;
    const now = Date.now();
    
    // Get or create login attempt entry
    let entry = loginAttemptStore[key];
    
    if (!entry) {
      entry = {
        attempts: [],
        lastAttempt: 0,
      };
      loginAttemptStore[key] = entry;
    }
    
    // Clean old attempts (older than 1 hour)
    entry.attempts = entry.attempts.filter(timestamp => now - timestamp < 60 * 60 * 1000);
    
    const failedAttempts = entry.attempts.length;
    
    // Progressive delay logic
    if (failedAttempts >= 6 && failedAttempts <= 10) {
      // 6-10 failed attempts: 5-10 second delay
      const delayMs = 5000 + Math.random() * 5000; // Random between 5-10 seconds
      const timeSinceLastAttempt = now - entry.lastAttempt;
      
      if (timeSinceLastAttempt < delayMs) {
        const remainingDelay = Math.ceil((delayMs - timeSinceLastAttempt) / 1000);
        return res.status(429).json({
          message: `تعداد تلاش‌های ناموفق زیاد است. لطفاً ${remainingDelay} ثانیه صبر کنید.`,
          retryAfter: remainingDelay,
        });
      }
    } else if (failedAttempts >= 10) {
      // 10+ failed attempts: log event, notify sysadmin, optional temporary delay
      const delayMs = 10000 + Math.random() * 5000; // Random between 10-15 seconds
      const timeSinceLastAttempt = now - entry.lastAttempt;
      
      // Log the event
      try {
        const { storage } = await import('../storage');
        const attemptedUser = auditId ? await storage.getUserByAuditId(auditId) : null;
        
        await storage.createAuditLog({
          userId: attemptedUser?.id || null,
          action: 'login_attempt_excessive',
          entityType: 'user',
          entityId: attemptedUser?.id || null,
          details: {
            auditId: auditId || 'unknown',
            failedAttempts: failedAttempts,
            ipAddress: clientIp,
            timestamp: new Date().toISOString(),
          },
          ipAddress: clientIp,
        });
        
        // Notify sysadmin (find all system admins and create notifications)
        const allUsers = await storage.getUsers();
        const sysadmins = allUsers.filter(u => u.role === 'system_admin' && u.isActive);
        
        for (const admin of sysadmins) {
          await storage.createNotification({
            userId: admin.id,
            type: 'security_alert',
            message: `هشدار امنیتی: تعداد ${failedAttempts} تلاش ناموفق ورود از IP ${clientIp}${auditId ? ` برای کاربر ${auditId}` : ''} ثبت شده است.`,
            isRead: false,
          });
        }
      } catch (logError) {
        console.error('Failed to log excessive login attempts:', logError);
      }
      
      if (timeSinceLastAttempt < delayMs) {
        const remainingDelay = Math.ceil((delayMs - timeSinceLastAttempt) / 1000);
        return res.status(429).json({
          message: `تعداد تلاش‌های ناموفق بسیار زیاد است. لطفاً ${remainingDelay} ثانیه صبر کنید.`,
          retryAfter: remainingDelay,
        });
      }
    }
    
    // Store the attempt timestamp (will be updated after login attempt)
    // We'll track failed attempts in the auth route handler
    (req as any).loginAttemptKey = key;
    
    next();
  };
}

/**
 * Burst detection for API rate limiting
 * Only triggers if >50 requests in <5 seconds
 * Adds short artificial delay (1-3 seconds) instead of blocking
 */
export function apiRateLimit() {
  return (req: Request, res: Response, next: NextFunction) => {
    const clientIp = extractClientIp(req);
    const userId = (req.user as any)?.id || 'anonymous';
    const key = `api:${userId}:${clientIp}`;
    const now = Date.now();
    
    // Get or create burst entry
    let entry = burstStore[key];
    
    if (!entry) {
      entry = {
        requests: [],
      };
      burstStore[key] = entry;
    }
    
    // Clean old requests (older than 5 seconds)
    entry.requests = entry.requests.filter(timestamp => now - timestamp < 5000);
    
    // Add current request
    entry.requests.push(now);
    
    // Check for burst (>50 requests in <5 seconds)
    if (entry.requests.length > 50) {
      // Log burst detection (async, don't block)
      (async () => {
        try {
          const { storage } = await import('../storage');
          await storage.createAuditLog({
            userId: userId !== 'anonymous' ? userId : null,
            action: 'api_burst_detected',
            entityType: 'api',
            entityId: req.path,
            details: {
              requestCount: entry.requests.length,
              timeWindow: '5 seconds',
              path: req.path,
              method: req.method,
              timestamp: new Date().toISOString(),
            },
            ipAddress: clientIp,
          });
        } catch (logError) {
          console.error('Failed to log API burst:', logError);
        }
      })();
      
      // Add short artificial delay (1-3 seconds)
      const delayMs = 1000 + Math.random() * 2000; // Random between 1-3 seconds
      
      // Use setTimeout to delay the request processing
      return setTimeout(() => {
        next();
      }, delayMs);
    }
    
    // Normal operation - no delay
    next();
  };
}

