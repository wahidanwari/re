/**
 * Password policy validation
 */

export interface PasswordPolicy {
  minLength: number;
  requireUppercase: boolean;
  requireLowercase: boolean;
  requireNumbers: boolean;
  requireSpecialChars: boolean;
  maxLength?: number;
  commonPasswords?: string[];
}

const DEFAULT_POLICY: PasswordPolicy = {
  minLength: 8,
  requireUppercase: false,
  requireLowercase: true,
  requireNumbers: true,
  requireSpecialChars: false,
  maxLength: 128,
  commonPasswords: [
    'password',
    '12345678',
    'password123',
    'admin123',
    '123456',
    'qwerty',
    'abc123',
  ],
};

/**
 * Validate password against policy
 */
export function validatePassword(
  password: string,
  policy: PasswordPolicy = DEFAULT_POLICY
): { valid: boolean; errors: string[] } {
  const errors: string[] = [];

  if (!password || typeof password !== 'string') {
    return { valid: false, errors: ['رمز عبور الزامی است'] };
  }

  // Check minimum length
  if (password.length < policy.minLength) {
    errors.push(`رمز عبور باید حداقل ${policy.minLength} کاراکتر باشد`);
  }

  // Check maximum length
  if (policy.maxLength && password.length > policy.maxLength) {
    errors.push(`رمز عبور نباید بیشتر از ${policy.maxLength} کاراکتر باشد`);
  }

  // Check for uppercase letters
  if (policy.requireUppercase && !/[A-Z]/.test(password)) {
    errors.push('رمز عبور باید حداقل یک حرف بزرگ داشته باشد');
  }

  // Check for lowercase letters
  if (policy.requireLowercase && !/[a-z]/.test(password)) {
    errors.push('رمز عبور باید حداقل یک حرف کوچک داشته باشد');
  }

  // Check for numbers
  if (policy.requireNumbers && !/[0-9]/.test(password)) {
    errors.push('رمز عبور باید حداقل یک عدد داشته باشد');
  }

  // Check for special characters
  if (policy.requireSpecialChars && !/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(password)) {
    errors.push('رمز عبور باید حداقل یک کاراکتر خاص داشته باشد');
  }

  // Check against common passwords
  if (policy.commonPasswords) {
    const lowerPassword = password.toLowerCase();
    if (policy.commonPasswords.some(common => lowerPassword.includes(common.toLowerCase()))) {
      errors.push('رمز عبور انتخاب شده خیلی ساده است. لطفاً رمز عبور قوی‌تری انتخاب کنید');
    }
  }

  return {
    valid: errors.length === 0,
    errors,
  };
}

/**
 * Generate a strong random password
 */
export function generateStrongPassword(length: number = 12): string {
  const uppercase = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  const lowercase = 'abcdefghijklmnopqrstuvwxyz';
  const numbers = '0123456789';
  const special = '!@#$%^&*()_+-=[]{}|;:,.<>?';
  
  const allChars = uppercase + lowercase + numbers + special;
  let password = '';
  
  // Ensure at least one character from each category
  password += uppercase[Math.floor(Math.random() * uppercase.length)];
  password += lowercase[Math.floor(Math.random() * lowercase.length)];
  password += numbers[Math.floor(Math.random() * numbers.length)];
  password += special[Math.floor(Math.random() * special.length)];
  
  // Fill the rest randomly
  for (let i = password.length; i < length; i++) {
    password += allChars[Math.floor(Math.random() * allChars.length)];
  }
  
  // Shuffle the password
  return password
    .split('')
    .sort(() => Math.random() - 0.5)
    .join('');
}

