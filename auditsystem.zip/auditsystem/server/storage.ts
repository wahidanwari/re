import { 
  type User, type InsertUser,
  type Group, type InsertGroup,
  type GroupMember, type InsertGroupMember,
  type GroupTarget, type InsertGroupTarget,
  type Entity, type InsertEntity,
  type Case, type InsertCase,
  type Ticket, type InsertTicket,
  type Document, type InsertDocument,
  type Notification, type InsertNotification,
  type AuditLog, type InsertAuditLog,
  type SystemSetting, type InsertSystemSetting,
  type EntityType, type InsertEntityType,
  type CaseReport, type InsertCaseReport,
  type CaseReportV2, type InsertCaseReportV2,
  type CaseReportHistory, type InsertCaseReportHistory,
  type CaseStatusTransition, type InsertCaseStatusTransition,
  type CaseMetrics, type InsertCaseMetrics,
  type InstallmentPayment, type InsertInstallmentPayment,
  type Payment, type InsertPayment,
  type CaseMonthlySnapshot, type InsertCaseMonthlySnapshot,
  type CaseFlag, type InsertCaseFlag,
  type CaseSectionStatus, type InsertCaseSectionStatus,
  type MinistryReport, type InsertMinistryReport,
  type AuditRecord, type InsertAuditRecord,
  type AuditRecordHistory, type InsertAuditRecordHistory,
  type Committee, type InsertCommittee,
  type CommitteeEntity, type InsertCommitteeEntity,
  type CommitteeNew, type InsertCommitteeNew,
  type CommitteeCaseAssignment, type InsertCommitteeCaseAssignment,
  type ArchivedFile, type InsertArchivedFile,
  type ArchivedFileVersion, type InsertArchivedFileVersion,
  type ArchivedFileAccessLog, type InsertArchivedFileAccessLog,
  type MonthlyGroupReport, type InsertMonthlyGroupReport,
  type MonthlyReportAnomaly, type InsertMonthlyReportAnomaly,
  users, groups, groupMembers, groupTargets,
  entities, cases, tickets, documents, notifications, auditLogs, systemSettings, entityTypes, caseReports, caseReportsV2, caseReportHistory, caseStatusTransitions, caseMetrics, installmentPayments, payments, caseMonthlySnapshots, caseFlags, caseSectionStatus, ministryReports,   auditRecords, auditRecordHistory, committees, committeeEntities, committeesNew, committeeCaseAssignments,
  monthlyGroupReports, monthlyReportAnomalies,
  archivedFiles, archivedFileVersions, archivedFileAccessLogs
} from "@shared/schema";
import { db } from "./db";
import { eq, and, desc, asc, count, inArray, sql, ne, or, lt, gt, lte, gte, like, ilike, isNull } from "drizzle-orm";
import { hashPassword } from "./auth/password";
import jalaali from "jalaali-js";

export interface IStorage {
  // Users
  getUser(id: string): Promise<User | undefined>;
  getUserByAuditId(auditId: string): Promise<User | undefined>;
  getUsers(): Promise<User[]>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, user: Partial<InsertUser>): Promise<User | undefined>;
  deactivateUser(id: string): Promise<boolean>;
  activateUser(id: string): Promise<boolean>;
  deleteUser(id: string): Promise<boolean>;
  
  // Groups
  getGroups(): Promise<Group[]>;
  getGroup(id: string): Promise<Group | undefined>;
  createGroup(group: InsertGroup): Promise<Group>;
  updateGroup(id: string, group: Partial<InsertGroup>): Promise<Group | undefined>;
  deleteGroup(id: string): Promise<boolean>;
  
  // Group Members
  getGroupMembers(groupId: string): Promise<GroupMember[]>;
  addGroupMember(member: InsertGroupMember): Promise<GroupMember>;
  removeGroupMember(groupId: string, userId: string): Promise<boolean>;
  
  // Group Targets
  getGroupTargets(groupId: string): Promise<GroupTarget[]>;
  getGroupTarget(targetId: string): Promise<GroupTarget | undefined>;
  setGroupTarget(target: InsertGroupTarget): Promise<GroupTarget>;
  updateGroupTarget(targetId: string, target: Partial<InsertGroupTarget>): Promise<GroupTarget | undefined>;
  
  // Entities
  getEntities(): Promise<Entity[]>;
  getEntity(id: string): Promise<Entity | undefined>;
  getEntityByTin(tin: string): Promise<Entity | undefined>;
  createEntity(entity: InsertEntity): Promise<Entity>;
  updateEntity(id: string, entity: Partial<InsertEntity>): Promise<Entity | undefined>;
  deleteEntity(id: string): Promise<boolean>;
  
  // Cases
  getCases(): Promise<Case[]>;
  getCase(id: string): Promise<Case | undefined>;
  getCaseByCaseNumber(caseNumber: number): Promise<Case | undefined>;
  getCasesByCaseId(caseId: string): Promise<Case | undefined>;
  getMaxCaseNumber(): Promise<number>;
  getCasesByEntityAndPeriod(entityId: string, periodsUnderReview: string): Promise<Case | undefined>;
  getCasesByEntity(entityId: string): Promise<Case[]>;
  getCasesByGroup(groupId: string): Promise<Case[]>;
  getCasesByAssignee(userId: string): Promise<Case[]>;
  getCompletedCasesByMonth(month: number, year: number): Promise<Case[]>;
  createCase(caseData: InsertCase): Promise<Case>;
  updateCase(id: string, caseData: Partial<InsertCase>): Promise<Case | undefined>;
  assignCaseToUser(caseId: string, userId: string): Promise<Case | undefined>;
  assignCaseToGroup(caseId: string, groupId: string): Promise<Case | undefined>;
  updateCaseStatus(caseId: string, status: string): Promise<Case | undefined>;
  assignCaseToUserWithMetadata(caseId: string, userId: string, assignedBy: string): Promise<Case | undefined>;
  
  // Case Metrics
  getCaseMetrics(caseId: string): Promise<CaseMetrics | undefined>;
  upsertCaseMetrics(caseId: string, metrics: Partial<InsertCaseMetrics>, updatedBy: string): Promise<CaseMetrics>;
  
  // Installment Payments
  getInstallmentPayments(caseId: string): Promise<InstallmentPayment[]>;
  createInstallmentPayment(payment: InsertInstallmentPayment): Promise<InstallmentPayment>;
  deleteInstallmentPayment(id: string): Promise<boolean>;
  
  // Payments (Payment Traceability - PHASE 1)
  createPayment(payment: InsertPayment): Promise<Payment>;
  getPaymentsByCase(caseId: string): Promise<Payment[]>;
  getPaymentsByDateRange(caseId: string, startDate: Date, endDate: Date): Promise<Payment[]>;
  getPaymentsByMonth(caseId: string, month: number, year: number): Promise<Payment[]>;
  
  // Case Monthly Snapshots (PHASE 2: Monthly Remaining Balance Snapshot)
  createOrUpdateCaseMonthlySnapshot(snapshot: InsertCaseMonthlySnapshot): Promise<CaseMonthlySnapshot>;
  getCaseMonthlySnapshot(caseId: string, reportMonth: string): Promise<CaseMonthlySnapshot | undefined>;
  getCaseMonthlySnapshotsByCase(caseId: string): Promise<CaseMonthlySnapshot[]>;
  getPreviousMonthSnapshot(caseId: string, currentMonth: string): Promise<CaseMonthlySnapshot | undefined>;
  getPaymentsInMonth(caseId: string, month: number, year: number): Promise<Payment[]>;
  
  // Case Flags
  getCaseFlags(caseId: string, type?: string): Promise<CaseFlag[]>;
  createCaseFlag(flag: InsertCaseFlag): Promise<CaseFlag>;
  
  // Case Section Status
  getCaseSectionStatus(caseId: string): Promise<CaseSectionStatus[]>;
  getCaseSectionStatusBySection(caseId: string, sectionId: string): Promise<CaseSectionStatus | undefined>;
  upsertCaseSectionStatus(status: InsertCaseSectionStatus): Promise<CaseSectionStatus>;
  
  // Documents
  getDocuments(caseId: string): Promise<Document[]>;
  getDocument(id: string): Promise<Document | undefined>;
  createDocument(document: InsertDocument): Promise<Document>;
  updateDocument(id: string, updates: Partial<Document>): Promise<Document | undefined>;
  
  // Tickets
  getTickets(): Promise<Ticket[]>;
  getTicket(id: string): Promise<Ticket | undefined>;
  getTicketsByUser(userId: string): Promise<Ticket[]>;
  createTicket(ticket: InsertTicket): Promise<Ticket>;
  updateTicketStatus(id: string, status: string): Promise<Ticket | undefined>;
  
  // Notifications
  getNotifications(userId: string): Promise<Notification[]>;
  createNotification(notification: InsertNotification): Promise<Notification>;
  markNotificationAsRead(id: string): Promise<boolean>;
  
  // Audit Logs
  createAuditLog(log: InsertAuditLog): Promise<AuditLog>;
  getAuditLogs(entityType?: string, entityId?: string): Promise<AuditLog[]>;
  deleteAuditLogs(filters: { userId?: string; startDate?: Date; endDate?: Date; entityType?: string }): Promise<number>;
  deleteAllAuditLogs(): Promise<number>;
  
  // Dashboard Statistics
  getDashboardStats(userId: string, groupId?: string): Promise<{
    caseStats: {
      total: number;
      inProgress: number;
      completed: number;
      pending: number;
      myAssignedCases: number;
    };
    ticketStats: {
      total: number;
      pending: number;
      approved: number;
      rejected: number;
    };
    recentActivity: {
      notifications: Notification[];
      recentCases: Case[];
    };
  }>;
  
  // System Settings
  getSettings(): Promise<SystemSetting[]>;
  getSetting(key: string): Promise<SystemSetting | undefined>;
  setSetting(setting: InsertSystemSetting): Promise<SystemSetting>;
  updateSetting(key: string, value: any, updatedBy: string): Promise<SystemSetting | undefined>;
  
  // Entity Types (PHASE 2)
  getEntityTypes(): Promise<EntityType[]>;
  getActiveEntityTypes(): Promise<EntityType[]>;
  getEntityType(id: string): Promise<EntityType | undefined>;
  createEntityType(type: InsertEntityType): Promise<EntityType>;
  updateEntityType(id: string, type: Partial<InsertEntityType>): Promise<EntityType | undefined>;
  deleteEntityType(id: string): Promise<boolean>;
  
  // Case Reports (Legacy)
  getCaseReport(caseId: string): Promise<CaseReport | undefined>;
  createCaseReport(report: InsertCaseReport): Promise<CaseReport>;
  updateCaseReport(caseId: string, report: Partial<InsertCaseReport>): Promise<CaseReport | undefined>;
  upsertCaseReport(report: InsertCaseReport): Promise<CaseReport>;
  
  // Case Reports V2 (Structured)
  getCaseReportV2(caseId: string): Promise<CaseReportV2 | undefined>;
  createCaseReportV2(report: InsertCaseReportV2): Promise<CaseReportV2>;
  updateCaseReportV2(caseId: string, report: Partial<InsertCaseReportV2>): Promise<CaseReportV2 | undefined>;
  upsertCaseReportV2(report: InsertCaseReportV2): Promise<CaseReportV2>;
  lockCaseReportV2(caseId: string): Promise<CaseReportV2 | undefined>;
  unlockCaseReportV2(caseId: string): Promise<CaseReportV2 | undefined>;
  
  // Case Report History
  getCaseReportHistory(reportId: string): Promise<CaseReportHistory[]>;
  createCaseReportHistory(history: InsertCaseReportHistory): Promise<CaseReportHistory>;
  
  // Case Status Transitions
  getCaseStatusTransitions(caseId: string): Promise<CaseStatusTransition[]>;
  getCaseStatusTransition(id: string): Promise<CaseStatusTransition | undefined>;
  createCaseStatusTransition(transition: InsertCaseStatusTransition): Promise<CaseStatusTransition>;
  
  // Ministry Reports
  getMinistryReport(groupId: string, monthShamsi: number, yearShamsi: number): Promise<MinistryReport | undefined>;
  upsertMinistryReport(report: InsertMinistryReport): Promise<MinistryReport>;
  getMinistryReportsByMonth(monthShamsi: number, yearShamsi: number): Promise<MinistryReport[]>;
  
  // Audit Records (Year Range Audits)
  getAuditRecords(entityId?: string, filters?: { yearFrom?: number; yearTo?: number; status?: string; auditGroupId?: string }): Promise<AuditRecord[]>;
  getAuditRecord(id: string): Promise<AuditRecord | undefined>;
  getAuditRecordsByEntity(entityId: string): Promise<AuditRecord[]>;
  checkAuditRecordOverlap(entityId: string, yearFrom: number, yearTo: number, excludeId?: string): Promise<AuditRecord[]>;
  createAuditRecord(record: InsertAuditRecord): Promise<AuditRecord>;
  updateAuditRecord(id: string, record: Partial<InsertAuditRecord>): Promise<AuditRecord | undefined>;
  deleteAuditRecord(id: string): Promise<boolean>;
  completeAuditRecord(id: string, completedBy: string): Promise<AuditRecord | undefined>;
  
  // Audit Record History
  getAuditRecordHistory(auditRecordId: string): Promise<AuditRecordHistory[]>;
  createAuditRecordHistory(history: InsertAuditRecordHistory): Promise<AuditRecordHistory>;
  
  // Committees (OLD - deprecated)
  getCommittees(): Promise<Committee[]>;
  getCommittee(id: string): Promise<Committee | undefined>;
  getActiveCommittees(): Promise<Committee[]>;
  createCommittee(committee: InsertCommittee): Promise<Committee>;
  updateCommittee(id: string, committee: Partial<InsertCommittee>): Promise<Committee | undefined>;
  closeCommittee(id: string): Promise<Committee | undefined>;
  
  // New Committee Module
  getCommitteesNew(): Promise<CommitteeNew[]>;
  getCommitteeNew(id: string): Promise<CommitteeNew | undefined>;
  getCommitteeByYearMonth(year: number, month: number): Promise<CommitteeNew | undefined>;
  createCommitteeNew(committee: InsertCommitteeNew): Promise<CommitteeNew>;
  updateCommitteeNew(id: string, committee: Partial<InsertCommitteeNew>): Promise<CommitteeNew | undefined>;
  
  // Committee Case Assignments
  getCommitteeCaseAssignment(id: string): Promise<CommitteeCaseAssignment | undefined>;
  createCommitteeCaseAssignment(assignment: InsertCommitteeCaseAssignment): Promise<CommitteeCaseAssignment>;
  getCaseAssignmentHistory(caseId: string): Promise<CommitteeCaseAssignment[]>;
  getCommitteeAssignments(committeeId: string): Promise<CommitteeCaseAssignment[]>;
  getAllAssignmentsByAuditGroup(auditGroupId: string): Promise<CommitteeCaseAssignment[]>;
  getAllDirectAssignments(startDate?: Date, endDate?: Date): Promise<CommitteeCaseAssignment[]>;
  
  // Committee Entities
  getCommitteeEntities(committeeId: string): Promise<CommitteeEntity[]>;
  addEntityToCommittee(committeeId: string, entityId: string): Promise<CommitteeEntity>;
  removeEntityFromCommittee(committeeId: string, entityId: string): Promise<boolean>;
  getEntitiesByCommittee(committeeId: string): Promise<Entity[]>;
  
  // Committee Cases
  getCasesByCommittee(committeeId: string): Promise<Case[]>;
  getCasesByCommitteeAndStatus(committeeId: string, status: string): Promise<Case[]>;
  getCasesByShamsiMonthAndYear(month: string, year: number, excludeCommitteeId?: string): Promise<Case[]>;
  
  // Monthly Group Reports
  getMonthlyGroupReport(groupId: string, monthNumber: number, year: number): Promise<MonthlyGroupReport | undefined>;
  upsertMonthlyGroupReport(report: InsertMonthlyGroupReport): Promise<MonthlyGroupReport>;
  getMonthlyReportAnomalies(reportId: string): Promise<MonthlyReportAnomaly[]>;
  updateGroupMonthlyTaxTarget(groupId: string, target: number | null): Promise<Group | undefined>;
  
  // Archived Files
  getArchivedFiles(filters?: {
    page?: number;
    size?: number;
    year?: number;
    category?: string;
    q?: string;
    sort?: string;
    uploadedBy?: string;
    dateFrom?: Date;
    dateTo?: Date;
  }): Promise<{ files: ArchivedFile[]; total: number; page: number; size: number }>;
  getArchivedFile(id: string): Promise<ArchivedFile | undefined>;
  getArchivedFileVersions(archivedFileId: string): Promise<ArchivedFileVersion[]>;
  createArchivedFile(file: InsertArchivedFile): Promise<ArchivedFile>;
  createArchivedFileVersion(version: InsertArchivedFileVersion): Promise<ArchivedFileVersion>;
  updateArchivedFile(id: string, updates: Partial<InsertArchivedFile>): Promise<ArchivedFile | undefined>;
  softDeleteArchivedFile(id: string): Promise<boolean>;
  logArchivedFileAccess(log: InsertArchivedFileAccessLog): Promise<ArchivedFileAccessLog>;
  findExistingArchivedFile(originalFileName: string, year: number): Promise<ArchivedFile | undefined>;
  
}

export class DatabaseStorage implements IStorage {
  // Users
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByAuditId(auditId: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.auditId, auditId));
    return user || undefined;
  }

  async getUsers(): Promise<User[]> {
    return await db.select().from(users).orderBy(asc(users.createdAt));
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const hashedPassword = await hashPassword(insertUser.password);
    const [user] = await db
      .insert(users)
      .values({
        ...insertUser,
        password: hashedPassword,
      })
      .returning();
    return user;
  }

  async updateUser(id: string, userData: Partial<InsertUser>): Promise<User | undefined> {
    const updateData: any = { ...userData };
    if (updateData.password) {
      updateData.password = await hashPassword(updateData.password);
    }
    
    const [user] = await db
      .update(users)
      .set(updateData)
      .where(eq(users.id, id))
      .returning();
    return user || undefined;
  }

  async deactivateUser(id: string): Promise<boolean> {
    const [user] = await db
      .update(users)
      .set({ isActive: false, mustChangePassword: true })
      .where(eq(users.id, id))
      .returning();
    return !!user;
  }

  async activateUser(id: string): Promise<boolean> {
    const [user] = await db
      .update(users)
      .set({ isActive: true })
      .where(eq(users.id, id))
      .returning();
    return !!user;
  }

  async deleteUser(id: string): Promise<boolean> {
    // Check if user has open or pending cases assigned to them
    // Only prevent deletion for active cases - completed/approved/rejected cases are historical data and don't block deletion
    // Final states that don't block deletion: 'تکمیل شده', 'تایید شده', 'رد شده'
    const blockingStatuses = ['جدید', 'در جریان بررسی', 'منتظر تایید'];
    const assignedCases = await db
      .select()
      .from(cases)
      .where(
        and(
          eq(cases.assignedTo, id),
          // Only block deletion for non-final active cases
          inArray(cases.status, blockingStatuses)
        )
      )
      .limit(1);
    
    if (assignedCases.length > 0) {
      throw new Error('نمی‌توان کاربری را که دارای قضایای باز یا در حال بررسی است حذف کرد. لطفاً ابتدا قضایای مرتبط را تکمیل یا واگذار کنید.');
    }
    
    // Check for pending tickets created by this user
    const pendingTickets = await db
      .select()
      .from(tickets)
      .where(
        and(
          eq(tickets.requestedBy, id),
          eq(tickets.status, 'منتظر تایید')
        )
      )
      .limit(1);
    
    if (pendingTickets.length > 0) {
      throw new Error('نمی‌توان کاربری را که دارای تکت‌های در حال بررسی است حذف کرد. لطفاً ابتدا تکت‌های مرتبط را بررسی کنید.');
    }
    
    // Delete user (cascade will handle userRoles and userPackages)
    // Historical audit data is preserved as userId can be NULL in audit logs
    const [deletedUser] = await db
      .delete(users)
      .where(eq(users.id, id))
      .returning();
    return !!deletedUser;
  }

  // Groups
  async getGroups(): Promise<Group[]> {
    return await db
      .select()
      .from(groups)
      .where(eq(groups.isActive, true))
      .orderBy(asc(groups.code));
  }

  async getGroup(id: string): Promise<Group | undefined> {
    const [group] = await db
      .select()
      .from(groups)
      .where(and(eq(groups.id, id), eq(groups.isActive, true)));
    return group || undefined;
  }

  async getGroupByName(name: string): Promise<Group | undefined> {
    const [group] = await db
      .select()
      .from(groups)
      .where(and(eq(groups.name, name), eq(groups.isActive, true)));
    return group || undefined;
  }

  async createGroup(insertGroup: InsertGroup): Promise<Group> {
    const [group] = await db
      .insert(groups)
      .values(insertGroup)
      .returning();
    return group;
  }

  async updateGroup(id: string, groupData: Partial<InsertGroup>): Promise<Group | undefined> {
    const [group] = await db
      .update(groups)
      .set(groupData)
      .where(eq(groups.id, id))
      .returning();
    return group || undefined;
  }

  async deleteGroup(id: string): Promise<boolean> {
    const [deletedGroup] = await db
      .update(groups)
      .set({ isActive: false })
      .where(eq(groups.id, id))
      .returning();
    return !!deletedGroup;
  }

  // Group Members
  async getGroupMembers(groupId: string): Promise<GroupMember[]> {
    return await db
      .select()
      .from(groupMembers)
      .where(and(eq(groupMembers.groupId, groupId), eq(groupMembers.isActive, true)));
  }

  async addGroupMember(member: InsertGroupMember): Promise<GroupMember> {
    const [groupMember] = await db
      .insert(groupMembers)
      .values(member)
      .returning();
    return groupMember;
  }

  async removeGroupMember(groupId: string, userId: string): Promise<boolean> {
    const [member] = await db
      .update(groupMembers)
      .set({ isActive: false })
      .where(and(eq(groupMembers.groupId, groupId), eq(groupMembers.userId, userId)))
      .returning();
    return !!member;
  }

  // Group Targets
  async getGroupTargets(groupId: string): Promise<GroupTarget[]> {
    return await db
      .select()
      .from(groupTargets)
      .where(eq(groupTargets.groupId, groupId))
      .orderBy(desc(groupTargets.yearShamsi));
  }

  async getGroupTarget(targetId: string): Promise<GroupTarget | undefined> {
    const [target] = await db
      .select()
      .from(groupTargets)
      .where(eq(groupTargets.id, targetId))
      .limit(1);
    return target;
  }

  async setGroupTarget(target: InsertGroupTarget): Promise<GroupTarget> {
    // Check if target already exists for this group and year
    const existing = await db
      .select()
      .from(groupTargets)
      .where(
        and(
          eq(groupTargets.groupId, target.groupId),
          eq(groupTargets.yearShamsi, target.yearShamsi)
        )
      )
      .limit(1);

    if (existing.length > 0) {
      // Update existing target
      const [updated] = await db
        .update(groupTargets)
        .set({
          targetCaseCount: target.targetCaseCount,
          targetMonetary: target.targetMonetary,
          setBy: target.setBy,
          setAt: new Date(),
        })
        .where(eq(groupTargets.id, existing[0].id))
        .returning();
      return updated;
    } else {
      // Insert new target
      const [groupTarget] = await db
        .insert(groupTargets)
        .values(target)
        .returning();
      return groupTarget;
    }
  }

  async updateGroupTarget(targetId: string, target: Partial<InsertGroupTarget>): Promise<GroupTarget | undefined> {
    const updateData: any = {};
    
    if (target.targetCaseCount !== undefined) {
      updateData.targetCaseCount = target.targetCaseCount;
    }
    if (target.targetMonetary !== undefined) {
      updateData.targetMonetary = target.targetMonetary;
    }
    if (target.setBy !== undefined) {
      updateData.setBy = target.setBy;
    }
    // Always update setAt timestamp
    updateData.setAt = new Date();
    
    const [updated] = await db
      .update(groupTargets)
      .set(updateData)
      .where(eq(groupTargets.id, targetId))
      .returning();
    
    return updated;
  }

  // Entities
  async getEntities(): Promise<Entity[]> {
    return await db.select().from(entities).orderBy(desc(entities.createdAt));
  }

  async getEntity(id: string): Promise<Entity | undefined> {
    const [entity] = await db.select().from(entities).where(eq(entities.id, id));
    return entity || undefined;
  }

  async getEntityByTin(tin: string): Promise<Entity | undefined> {
    const [entity] = await db.select().from(entities).where(eq(entities.tin, tin));
    return entity || undefined;
  }

  async searchEntitiesByTin(query: string, limit: number = 10): Promise<Entity[]> {
    // Case-insensitive partial match search (prefix + contains)
    // Use SQL ILIKE for PostgreSQL case-insensitive search
    const searchPattern = `%${query}%`;
    const results = await db
      .select()
      .from(entities)
      .where(sql`${entities.tin} ILIKE ${searchPattern}`)
      .limit(limit)
      .orderBy(asc(entities.tin));
    return results;
  }

  async createEntity(entity: InsertEntity): Promise<Entity> {
    const [newEntity] = await db
      .insert(entities)
      .values(entity)
      .returning();
    return newEntity;
  }

  async updateEntity(id: string, entityData: Partial<InsertEntity>): Promise<Entity | undefined> {
    const [entity] = await db
      .update(entities)
      .set(entityData)
      .where(eq(entities.id, id))
      .returning();
    return entity || undefined;
  }

  async deleteEntity(id: string): Promise<boolean> {
    // Check if entity has associated cases
    const entityCases = await db
      .select()
      .from(cases)
      .where(eq(cases.entityId, id))
      .limit(1);
    
    if (entityCases.length > 0) {
      throw new Error('نمی‌توان نهادی که قضایای مرتبط دارد را حذف کرد');
    }
    
    const [deletedEntity] = await db
      .delete(entities)
      .where(eq(entities.id, id))
      .returning();
    return !!deletedEntity;
  }

  // Cases
  async getCases(): Promise<Case[]> {
    return await db.select().from(cases).orderBy(desc(cases.createdAt));
  }

  async getCase(id: string): Promise<Case | undefined> {
    const [caseData] = await db.select().from(cases).where(eq(cases.id, id));
    return caseData || undefined;
  }

  async getCaseByCaseNumber(caseNumber: number): Promise<Case | undefined> {
    const [case_] = await db
      .select()
      .from(cases)
      .where(eq(cases.caseNumber, caseNumber))
      .limit(1);
    return case_ || undefined;
  }

  async getCasesByCaseId(caseId: string): Promise<Case | undefined> {
    const [caseData] = await db.select().from(cases).where(eq(cases.caseId, caseId));
    return caseData || undefined;
  }

  async getMaxCaseNumber(): Promise<number> {
    const result = await db
      .select({ max: sql<number>`COALESCE(MAX(${cases.caseNumber}), 0)` })
      .from(cases);
    return result[0]?.max || 0;
  }

  async getCasesByEntityAndPeriod(entityId: string, periodsUnderReview: string): Promise<Case | undefined> {
    const [caseData] = await db
      .select()
      .from(cases)
      .where(and(eq(cases.entityId, entityId), eq(cases.periodsUnderReview, periodsUnderReview)));
    return caseData || undefined;
  }

  async getCasesByEntity(entityId: string): Promise<Case[]> {
    return await db
      .select()
      .from(cases)
      .where(eq(cases.entityId, entityId))
      .orderBy(desc(cases.createdAt));
  }

  async getCasesByGroup(groupId: string): Promise<Case[]> {
    // PHASE 1: Use receivingGroup for audit group filtering (not groupReferrer which is sender group)
    // BUG FIX #1: Include all cases with receivingGroup matching this group
    // This includes cases in "منتظر بررسی بازرس ارشد" status that have receivingGroup set
    return await db
      .select()
      .from(cases)
      .where(eq(cases.receivingGroup, groupId))
      .orderBy(desc(cases.createdAt));
  }

  async getCasesByAssignee(userId: string): Promise<Case[]> {
    // SECTION 1 RBAC FIX: Auditor must ONLY see cases assigned to them
    // Check both assignedTo and assignedAuditor fields to ensure complete filtering
    return await db
      .select()
      .from(cases)
      .where(
        or(
          eq(cases.assignedTo, userId),
          eq(cases.assignedAuditor, userId)
        )
      )
      .orderBy(desc(cases.createdAt));
  }

  async getCompletedCasesByMonth(month: number, year: number): Promise<Case[]> {
    // Get all completed cases
    const allCases = await db
      .select()
      .from(cases)
      .where(
        and(
          sql`${cases.status} IN ('تکمیل شده', 'COMPLETED')`,
          sql`${cases.completedAt} IS NOT NULL`
        )
      );
    
    // Filter by Shamsi month/year
    const filteredCases = allCases.filter(c => {
      if (!c.completedAt) return false;
      const j = jalaali.toJalaali(new Date(c.completedAt));
      return j.jm === month && j.jy === year;
    });
    
    return filteredCases;
  }

  async createCase(caseData: InsertCase): Promise<Case> {
    const [newCase] = await db
      .insert(cases)
      .values(caseData)
      .returning();
    return newCase;
  }

  async updateCase(id: string, caseData: Partial<InsertCase>): Promise<Case | undefined> {
    const [updatedCase] = await db
      .update(cases)
      .set(caseData)
      .where(eq(cases.id, id))
      .returning();
    return updatedCase || undefined;
  }

  async assignCaseToUser(caseId: string, userId: string): Promise<Case | undefined> {
    const [updatedCase] = await db
      .update(cases)
      .set({ assignedTo: userId })
      .where(eq(cases.id, caseId))
      .returning();
    return updatedCase || undefined;
  }

  async assignCaseToGroup(caseId: string, groupId: string): Promise<Case | undefined> {
    // PHASE 1: Assign case to audit group by updating receivingGroup (not groupReferrer which is sender group)
    // Clear assignedTo to indicate it's assigned to the group, not individual user
    const [updatedCase] = await db
      .update(cases)
      .set({ 
        receivingGroup: groupId,
        assignedTo: null, // Clear individual assignment when assigned to group
      })
      .where(eq(cases.id, caseId))
      .returning();
    return updatedCase || undefined;
  }

  async updateCaseStatus(caseId: string, status: string): Promise<Case | undefined> {
    const [updatedCase] = await db
      .update(cases)
      .set({ status })
      .where(eq(cases.id, caseId))
      .returning();
    return updatedCase || undefined;
  }

  async assignCaseToUserWithMetadata(caseId: string, userId: string, assignedBy: string): Promise<Case | undefined> {
    const [updatedCase] = await db
      .update(cases)
      .set({ 
        assignedTo: userId,
        assignedBy: assignedBy,
        assignedAt: new Date(),
        status: 'اختصاص داده شده', // Atomic status update - set to ASSIGNED when assigning to auditor
      })
      .where(eq(cases.id, caseId))
      .returning();
    return updatedCase || undefined;
  }

  // Case Metrics
  async getCaseMetrics(caseId: string): Promise<CaseMetrics | undefined> {
    const [metrics] = await db
      .select()
      .from(caseMetrics)
      .where(eq(caseMetrics.caseId, caseId))
      .limit(1);
    return metrics || undefined;
  }

  async upsertCaseMetrics(caseId: string, metricsData: Partial<InsertCaseMetrics>, updatedBy: string): Promise<CaseMetrics> {
    const existing = await this.getCaseMetrics(caseId);
    
    if (existing) {
      const [updated] = await db
        .update(caseMetrics)
        .set({
          ...metricsData,
          lastUpdatedBy: updatedBy,
          lastUpdatedAt: new Date(),
        })
        .where(eq(caseMetrics.caseId, caseId))
        .returning();
      return updated!;
    } else {
      const [created] = await db
        .insert(caseMetrics)
        .values({
          caseId,
          ...metricsData,
          lastUpdatedBy: updatedBy,
          lastUpdatedAt: new Date(),
        } as InsertCaseMetrics)
        .returning();
      return created;
    }
  }

  // Installment Payments
  async getInstallmentPayments(caseId: string): Promise<InstallmentPayment[]> {
    return await db
      .select()
      .from(installmentPayments)
      .where(eq(installmentPayments.caseId, caseId))
      .orderBy(desc(installmentPayments.paymentDate));
  }

  async createInstallmentPayment(payment: InsertInstallmentPayment): Promise<InstallmentPayment> {
    const [created] = await db
      .insert(installmentPayments)
      .values(payment)
      .returning();
    return created;
  }

  async deleteInstallmentPayment(id: string): Promise<boolean> {
    const [deleted] = await db
      .delete(installmentPayments)
      .where(eq(installmentPayments.id, id))
      .returning();
    return !!deleted;
  }

  // Payments (Payment Traceability - PHASE 1)
  async createPayment(payment: InsertPayment): Promise<Payment> {
    const [created] = await db
      .insert(payments)
      .values(payment)
      .returning();
    return created;
  }

  async getPaymentsByCase(caseId: string): Promise<Payment[]> {
    return await db
      .select()
      .from(payments)
      .where(eq(payments.caseId, caseId))
      .orderBy(desc(payments.paymentDate));
  }

  async getPaymentsByDateRange(caseId: string, startDate: Date, endDate: Date): Promise<Payment[]> {
    return await db
      .select()
      .from(payments)
      .where(
        and(
          eq(payments.caseId, caseId),
          gte(payments.paymentDate, startDate),
          lte(payments.paymentDate, endDate)
        )
      )
      .orderBy(desc(payments.paymentDate));
  }

  async getPaymentsByMonth(caseId: string, month: number, year: number): Promise<Payment[]> {
    // Get start and end of month in Shamsi calendar
    const startOfMonth = jalaali.toGregorian(year, month, 1);
    const daysInMonth = jalaali.jalaaliMonthLength(year, month);
    const endOfMonth = jalaali.toGregorian(year, month, daysInMonth);
    
    const startDate = new Date(startOfMonth.gy, startOfMonth.gm - 1, startOfMonth.gd);
    const endDate = new Date(endOfMonth.gy, endOfMonth.gm - 1, endOfMonth.gd);
    
    // Set time to start/end of day
    startDate.setHours(0, 0, 0, 0);
    endDate.setHours(23, 59, 59, 999);
    
    return await this.getPaymentsByDateRange(caseId, startDate, endDate);
  }

  // Case Monthly Snapshots (PHASE 2: Monthly Remaining Balance Snapshot)
  async createOrUpdateCaseMonthlySnapshot(snapshot: InsertCaseMonthlySnapshot): Promise<CaseMonthlySnapshot> {
    // Use upsert to create or update snapshot
    const [result] = await db
      .insert(caseMonthlySnapshots)
      .values({
        ...snapshot,
        updatedAt: new Date(),
      })
      .onConflictDoUpdate({
        target: [caseMonthlySnapshots.caseId, caseMonthlySnapshots.reportMonth],
        set: {
          remainingBalanceEndOfMonth: snapshot.remainingBalanceEndOfMonth,
          totalPaidInMonth: snapshot.totalPaidInMonth,
          confirmedAmount: snapshot.confirmedAmount,
          updatedAt: new Date(),
        },
      })
      .returning();
    return result;
  }

  async getCaseMonthlySnapshot(caseId: string, reportMonth: string): Promise<CaseMonthlySnapshot | undefined> {
    const [snapshot] = await db
      .select()
      .from(caseMonthlySnapshots)
      .where(
        and(
          eq(caseMonthlySnapshots.caseId, caseId),
          eq(caseMonthlySnapshots.reportMonth, reportMonth)
        )
      )
      .limit(1);
    return snapshot;
  }

  async getCaseMonthlySnapshotsByCase(caseId: string): Promise<CaseMonthlySnapshot[]> {
    return await db
      .select()
      .from(caseMonthlySnapshots)
      .where(eq(caseMonthlySnapshots.caseId, caseId))
      .orderBy(desc(caseMonthlySnapshots.reportMonth));
  }

  async getPreviousMonthSnapshot(caseId: string, currentMonth: string): Promise<CaseMonthlySnapshot | undefined> {
    // Parse current month (YYYY-MM format)
    const [yearStr, monthStr] = currentMonth.split('-');
    const currentYear = parseInt(yearStr, 10);
    const currentMonthNum = parseInt(monthStr, 10);
    
    // Calculate previous month
    let prevYear = currentYear;
    let prevMonth = currentMonthNum - 1;
    if (prevMonth < 1) {
      prevMonth = 12;
      prevYear = currentYear - 1;
    }
    
    const prevMonthStr = `${prevYear}-${String(prevMonth).padStart(2, '0')}`;
    
    return await this.getCaseMonthlySnapshot(caseId, prevMonthStr);
  }

  async getPaymentsInMonth(caseId: string, month: number, year: number): Promise<Payment[]> {
    // This is the same as getPaymentsByMonth, but with a clearer name for Phase 2
    return await this.getPaymentsByMonth(caseId, month, year);
  }

  // Case Flags
  async getCaseFlags(caseId: string, type?: string): Promise<CaseFlag[]> {
    const conditions = [eq(caseFlags.caseId, caseId)];
    if (type) {
      conditions.push(eq(caseFlags.type, type));
    }
    return await db
      .select()
      .from(caseFlags)
      .where(and(...conditions))
      .orderBy(desc(caseFlags.createdAt));
  }

  async createCaseFlag(flag: InsertCaseFlag): Promise<CaseFlag> {
    const [created] = await db
      .insert(caseFlags)
      .values(flag)
      .returning();
    return created;
  }

  // Case Section Status
  async getCaseSectionStatus(caseId: string): Promise<CaseSectionStatus[]> {
    return await db
      .select()
      .from(caseSectionStatus)
      .where(eq(caseSectionStatus.caseId, caseId))
      .orderBy(asc(caseSectionStatus.sectionId));
  }

  async getCaseSectionStatusBySection(caseId: string, sectionId: string): Promise<CaseSectionStatus | undefined> {
    const [status] = await db
      .select()
      .from(caseSectionStatus)
      .where(
        and(
          eq(caseSectionStatus.caseId, caseId),
          eq(caseSectionStatus.sectionId, sectionId)
        )
      )
      .limit(1);
    return status || undefined;
  }

  async upsertCaseSectionStatus(statusData: InsertCaseSectionStatus): Promise<CaseSectionStatus> {
    const existing = await this.getCaseSectionStatusBySection(statusData.caseId, statusData.sectionId);
    
    if (existing) {
      const [updated] = await db
        .update(caseSectionStatus)
        .set({
          ...statusData,
          updatedAt: new Date(),
        })
        .where(eq(caseSectionStatus.id, existing.id))
        .returning();
      return updated!;
    } else {
      const [created] = await db
        .insert(caseSectionStatus)
        .values(statusData)
        .returning();
      return created;
    }
  }

  // Documents
  async getDocuments(caseId: string): Promise<Document[]> {
    return await db
      .select()
      .from(documents)
      .where(eq(documents.caseId, caseId))
      .orderBy(desc(documents.uploadedAt));
  }

  async getDocument(id: string): Promise<Document | undefined> {
    const [document] = await db.select().from(documents).where(eq(documents.id, id));
    return document || undefined;
  }

  async createDocument(document: InsertDocument): Promise<Document> {
    const [newDocument] = await db.insert(documents).values(document).returning();
    return newDocument;
  }

  async updateDocument(id: string, updates: Partial<Document>): Promise<Document | undefined> {
    const [updatedDocument] = await db
      .update(documents)
      .set(updates)
      .where(eq(documents.id, id))
      .returning();
    return updatedDocument || undefined;
  }

  // Tickets
  async getTickets(): Promise<Ticket[]> {
    return await db.select().from(tickets).orderBy(desc(tickets.createdAt));
  }

  async getTicket(id: string): Promise<Ticket | undefined> {
    const [ticket] = await db.select().from(tickets).where(eq(tickets.id, id));
    return ticket || undefined;
  }

  async getTicketsByUser(userId: string): Promise<Ticket[]> {
    return await db
      .select()
      .from(tickets)
      .where(eq(tickets.requestedBy, userId))
      .orderBy(desc(tickets.createdAt));
  }

  async createTicket(ticket: InsertTicket): Promise<Ticket> {
    const [newTicket] = await db
      .insert(tickets)
      .values(ticket)
      .returning();
    return newTicket;
  }

  async updateTicketStatus(id: string, status: string): Promise<Ticket | undefined> {
    const [updatedTicket] = await db
      .update(tickets)
      .set({ status })
      .where(eq(tickets.id, id))
      .returning();
    return updatedTicket || undefined;
  }

  // Notifications
  async getNotifications(userId: string): Promise<Notification[]> {
    return await db
      .select()
      .from(notifications)
      .where(eq(notifications.userId, userId))
      .orderBy(desc(notifications.createdAt));
  }

  async createNotification(notification: InsertNotification): Promise<Notification> {
    const [newNotification] = await db
      .insert(notifications)
      .values(notification)
      .returning();
    
    try {
      const { wsServer } = await import('./websocket');
      if (wsServer) {
        wsServer.sendNotificationToUser(newNotification.userId, newNotification);
      }
    } catch (error) {
      console.error('Failed to broadcast notification via WebSocket:', error);
    }
    
    return newNotification;
  }

  async markNotificationAsRead(id: string): Promise<boolean> {
    const [notification] = await db
      .update(notifications)
      .set({ isRead: true })
      .where(eq(notifications.id, id))
      .returning();
    return !!notification;
  }

  // Audit Logs
  async createAuditLog(log: InsertAuditLog | { userId?: string; action: string; details?: any; entityType?: string; entityId?: string; ipAddress?: string }): Promise<AuditLog> {
    // Handle both old format (oldValue/newValue) and new format (details)
    let logData: any;
    
    // CRITICAL: Use current UTC time (database stores UTC, we format as Afghanistan time when displaying)
    // This ensures no timezone conversion issues - we store the moment in time correctly
    // and always format it as Afghanistan time (Asia/Kabul) when displaying
    const timestamp = new Date();
    
    if ('details' in log || (!('oldValue' in log) && !('newValue' in log))) {
      // New format with details
      logData = {
        userId: (log as any).userId || null,
        action: log.action,
        details: (log as any).details || {},
        entityType: (log as any).entityType || null,
        entityId: (log as any).entityId || null,
        ipAddress: (log as any).ipAddress || null,
        createdAt: timestamp, // Explicitly set timestamp
      };
    } else {
      // Old format - convert to new format
      const oldLog = log as InsertAuditLog;
      logData = {
        userId: oldLog.userId || null,
        action: log.action,
        details: {
          oldValue: oldLog.oldValue,
          newValue: oldLog.newValue,
        },
        entityType: oldLog.entityType || null,
        entityId: oldLog.entityId || null,
        ipAddress: oldLog.ipAddress || null,
        createdAt: timestamp, // Explicitly set timestamp
      };
    }
    
    const [auditLog] = await db
      .insert(auditLogs)
      .values(logData)
      .returning();
    return auditLog;
  }

  async getAuditLogs(entityType?: string, entityId?: string): Promise<AuditLog[]> {
    let query = db.select().from(auditLogs);
    
    if (entityType && entityId) {
      query = query.where(and(
        eq(auditLogs.entityType, entityType),
        eq(auditLogs.entityId, entityId)
      )) as any;
    } else if (entityType) {
      query = query.where(eq(auditLogs.entityType, entityType)) as any;
    }
    
    return await query.orderBy(desc(auditLogs.createdAt));
  }

  async deleteAuditLogs(filters: { userId?: string; startDate?: Date; endDate?: Date; entityType?: string }): Promise<number> {
    const conditions: any[] = [];
    
    if (filters.userId) {
      conditions.push(eq(auditLogs.userId, filters.userId));
    }
    
    if (filters.entityType) {
      conditions.push(eq(auditLogs.entityType, filters.entityType));
    }
    
    if (filters.startDate) {
      conditions.push(sql`${auditLogs.createdAt} >= ${filters.startDate}`);
    }
    
    if (filters.endDate) {
      const endDate = new Date(filters.endDate);
      endDate.setHours(23, 59, 59, 999);
      conditions.push(sql`${auditLogs.createdAt} <= ${endDate}`);
    }
    
    let query = db.delete(auditLogs);
    if (conditions.length > 0) {
      query = query.where(and(...conditions)) as any;
    }
    
    const result = await query.returning();
    return result.length;
  }

  async deleteAllAuditLogs(): Promise<number> {
    const result = await db.delete(auditLogs).returning();
    return result.length;
  }

  async getDashboardStats(userId: string, groupId?: string) {
    let totalCasesQuery = db.select({ count: count() }).from(cases);
    let inProgressQuery = db.select({ count: count() }).from(cases).where(eq(cases.status, 'در حال بررسی'));
    let completedQuery = db.select({ count: count() }).from(cases).where(eq(cases.status, 'تکمیل شده'));
    let pendingQuery = db.select({ count: count() }).from(cases).where(eq(cases.status, 'منتظر تایید'));
    
    if (groupId) {
      totalCasesQuery = db.select({ count: count() }).from(cases).where(eq(cases.groupReferrer, groupId)) as any;
      inProgressQuery = db.select({ count: count() }).from(cases).where(and(eq(cases.groupReferrer, groupId), eq(cases.status, 'در حال بررسی'))) as any;
      completedQuery = db.select({ count: count() }).from(cases).where(and(eq(cases.groupReferrer, groupId), eq(cases.status, 'تکمیل شده'))) as any;
      pendingQuery = db.select({ count: count() }).from(cases).where(and(eq(cases.groupReferrer, groupId), eq(cases.status, 'منتظر تایید'))) as any;
    }
    
    const [totalCasesResult, inProgressResult, completedResult, pendingResult, myAssignedResult] = await Promise.all([
      totalCasesQuery,
      inProgressQuery,
      completedQuery,
      pendingQuery,
      db.select({ count: count() }).from(cases).where(eq(cases.assignedTo, userId)),
    ]);
    
    let totalTicketsQuery = db.select({ count: count() }).from(tickets);
    let pendingTicketsQuery = db.select({ count: count() }).from(tickets).where(eq(tickets.status, 'منتظر تایید'));
    let approvedTicketsQuery = db.select({ count: count() }).from(tickets).where(eq(tickets.status, 'تایید شده'));
    let rejectedTicketsQuery = db.select({ count: count() }).from(tickets).where(eq(tickets.status, 'رد شده'));
    
    if (groupId) {
      totalTicketsQuery = db.select({ count: count() })
        .from(tickets)
        .leftJoin(users, eq(tickets.requestedBy, users.id))
        .where(eq(users.groupId, groupId)) as any;
      pendingTicketsQuery = db.select({ count: count() })
        .from(tickets)
        .leftJoin(users, eq(tickets.requestedBy, users.id))
        .where(and(eq(users.groupId, groupId), eq(tickets.status, 'منتظر تایید'))) as any;
      approvedTicketsQuery = db.select({ count: count() })
        .from(tickets)
        .leftJoin(users, eq(tickets.requestedBy, users.id))
        .where(and(eq(users.groupId, groupId), eq(tickets.status, 'تایید شده'))) as any;
      rejectedTicketsQuery = db.select({ count: count() })
        .from(tickets)
        .leftJoin(users, eq(tickets.requestedBy, users.id))
        .where(and(eq(users.groupId, groupId), eq(tickets.status, 'رد شده'))) as any;
    }
    
    const [totalTicketsResult, pendingTicketsResult, approvedTicketsResult, rejectedTicketsResult] = await Promise.all([
      totalTicketsQuery,
      pendingTicketsQuery,
      approvedTicketsQuery,
      rejectedTicketsQuery,
    ]);
    
    const caseStats = {
      total: Number(totalCasesResult[0].count),
      inProgress: Number(inProgressResult[0].count),
      completed: Number(completedResult[0].count),
      pending: Number(pendingResult[0].count),
      myAssignedCases: Number(myAssignedResult[0].count),
    };
    
    const ticketStats = {
      total: Number(totalTicketsResult[0].count),
      pending: Number(pendingTicketsResult[0].count),
      approved: Number(approvedTicketsResult[0].count),
      rejected: Number(rejectedTicketsResult[0].count),
    };
    
    const userNotifications = await db
      .select()
      .from(notifications)
      .where(eq(notifications.userId, userId))
      .orderBy(desc(notifications.createdAt))
      .limit(10);
    
    let recentCasesQuery = db
      .select()
      .from(cases)
      .orderBy(desc(cases.createdAt))
      .limit(10);
    
    if (groupId) {
      recentCasesQuery = db
        .select()
        .from(cases)
        .where(eq(cases.groupReferrer, groupId))
        .orderBy(desc(cases.createdAt))
        .limit(10) as any;
    }
    
    const recentCases = await recentCasesQuery;
    
    return {
      caseStats,
      ticketStats,
      recentActivity: {
        notifications: userNotifications,
        recentCases,
      },
    };
  }

  async getSettings(): Promise<SystemSetting[]> {
    return await db.select().from(systemSettings);
  }

  async getSetting(key: string): Promise<SystemSetting | undefined> {
    const [setting] = await db.select().from(systemSettings).where(eq(systemSettings.key, key));
    return setting || undefined;
  }

  async setSetting(setting: InsertSystemSetting): Promise<SystemSetting> {
    const existing = await this.getSetting(setting.key);
    if (existing) {
      const [updated] = await db
        .update(systemSettings)
        .set({ value: setting.value, updatedBy: setting.updatedBy, updatedAt: new Date() })
        .where(eq(systemSettings.key, setting.key))
        .returning();
      return updated;
    }
    
    const [newSetting] = await db
      .insert(systemSettings)
      .values(setting)
      .returning();
    return newSetting;
  }

  async updateSetting(key: string, value: any, updatedBy: string): Promise<SystemSetting | undefined> {
    const [updated] = await db
      .update(systemSettings)
      .set({ value, updatedBy, updatedAt: new Date() })
      .where(eq(systemSettings.key, key))
      .returning();
    return updated || undefined;
  }

  // Entity Types (PHASE 2)
  async getEntityTypes(): Promise<EntityType[]> {
    return await db.select().from(entityTypes).orderBy(asc(entityTypes.name));
  }

  async getActiveEntityTypes(): Promise<EntityType[]> {
    return await db
      .select()
      .from(entityTypes)
      .where(eq(entityTypes.status, "active"))
      .orderBy(asc(entityTypes.name));
  }

  async getEntityType(id: string): Promise<EntityType | undefined> {
    const [type] = await db.select().from(entityTypes).where(eq(entityTypes.id, id));
    return type || undefined;
  }

  async createEntityType(type: InsertEntityType): Promise<EntityType> {
    const [newType] = await db
      .insert(entityTypes)
      .values({ ...type, updatedAt: new Date() })
      .returning();
    return newType;
  }

  async updateEntityType(id: string, type: Partial<InsertEntityType>): Promise<EntityType | undefined> {
    const [updated] = await db
      .update(entityTypes)
      .set({ ...type, updatedAt: new Date() })
      .where(eq(entityTypes.id, id))
      .returning();
    return updated || undefined;
  }

  async deleteEntityType(id: string): Promise<boolean> {
    // Soft delete by setting status to inactive
    const [updated] = await db
      .update(entityTypes)
      .set({ status: "inactive", updatedAt: new Date() })
      .where(eq(entityTypes.id, id))
      .returning();
    return !!updated;
  }

  // Case Reports
  async getCaseReport(caseId: string): Promise<CaseReport | undefined> {
    const [report] = await db
      .select()
      .from(caseReports)
      .where(eq(caseReports.caseId, caseId));
    return report || undefined;
  }

  async createCaseReport(report: InsertCaseReport): Promise<CaseReport> {
    const [newReport] = await db
      .insert(caseReports)
      .values(report)
      .returning();
    return newReport;
  }

  async updateCaseReport(caseId: string, report: Partial<InsertCaseReport>): Promise<CaseReport | undefined> {
    const [updated] = await db
      .update(caseReports)
      .set({ ...report, updatedAt: new Date() })
      .where(eq(caseReports.caseId, caseId))
      .returning();
    return updated || undefined;
  }

  async upsertCaseReport(report: InsertCaseReport): Promise<CaseReport> {
    // Check if report exists
    const existing = await this.getCaseReport(report.caseId);
    
    if (existing) {
      // Update existing report
      const [updated] = await db
        .update(caseReports)
        .set({ ...report, updatedAt: new Date() })
        .where(eq(caseReports.caseId, report.caseId))
        .returning();
      return updated!;
    } else {
      // Create new report
      return await this.createCaseReport(report);
    }
  }

  // Case Reports V2 (Structured)
  async getCaseReportV2(caseId: string): Promise<CaseReportV2 | undefined> {
    const [report] = await db
      .select()
      .from(caseReportsV2)
      .where(eq(caseReportsV2.caseId, caseId));
    return report || undefined;
  }

  async createCaseReportV2(report: InsertCaseReportV2): Promise<CaseReportV2> {
    // Apply automatic calculations before saving
    const { applyCalculationsToReport } = await import('./services/caseReportCalculationService');
    const reportWithCalculations = applyCalculationsToReport(report) as InsertCaseReportV2;
    
    const [newReport] = await db
      .insert(caseReportsV2)
      .values(reportWithCalculations)
      .returning();
    return newReport;
  }

  async updateCaseReportV2(caseId: string, report: Partial<InsertCaseReportV2>): Promise<CaseReportV2 | undefined> {
    // Get existing report to merge with for calculations
    const existing = await this.getCaseReportV2(caseId);
    
    // Merge existing data with updates for calculation context
    const mergedReport = existing ? { ...existing, ...report } : report;
    
    // Apply automatic calculations
    const { applyCalculationsToReport } = await import('./services/caseReportCalculationService');
    const reportWithCalculations = applyCalculationsToReport(mergedReport);
    
    // Only update fields that were provided or calculated
    const updateData: Partial<InsertCaseReportV2> = {
      ...report,
      ...reportWithCalculations,
      updatedAt: new Date(),
    };
    
    const [updated] = await db
      .update(caseReportsV2)
      .set(updateData)
      .where(eq(caseReportsV2.caseId, caseId))
      .returning();
    return updated || undefined;
  }

  async upsertCaseReportV2(report: InsertCaseReportV2): Promise<CaseReportV2> {
    const existing = await this.getCaseReportV2(report.caseId);
    
    if (existing) {
      // Merge existing data with updates for calculation context
      const mergedReport = { ...existing, ...report };
      
      // Apply automatic calculations
      const { applyCalculationsToReport } = await import('./services/caseReportCalculationService');
      const reportWithCalculations = applyCalculationsToReport(mergedReport) as Partial<InsertCaseReportV2>;
      
      // Update existing report and increment version
      // IMPORTANT: Preserve the original field values from report, calculations only add computed fields
      // Ensure numeric fields are properly formatted for database (numeric type)
      const updateData: any = {
        ...report, // Original values from request (including profitTransactionTax, incomeTax, collectedCurrentMonth)
        ...reportWithCalculations, // Calculated fields (confirmedAmount, remainingCollectible)
        updatedAt: new Date(),
        version: existing.version + 1,
      };
      
      // Ensure critical numeric fields are always numbers (not null/undefined)
      // Database expects numeric type, so convert to number if needed
      if (updateData.profitTransactionTax === null || updateData.profitTransactionTax === undefined) {
        updateData.profitTransactionTax = 0;
      }
      if (updateData.incomeTax === null || updateData.incomeTax === undefined) {
        updateData.incomeTax = 0;
      }
      if (updateData.collectedCurrentMonth === null || updateData.collectedCurrentMonth === undefined) {
        updateData.collectedCurrentMonth = 0;
      }
      
      // Convert to numbers if they're strings (from database)
      updateData.profitTransactionTax = typeof updateData.profitTransactionTax === 'string' 
        ? parseFloat(updateData.profitTransactionTax) || 0 
        : (typeof updateData.profitTransactionTax === 'number' ? updateData.profitTransactionTax : 0);
      updateData.incomeTax = typeof updateData.incomeTax === 'string' 
        ? parseFloat(updateData.incomeTax) || 0 
        : (typeof updateData.incomeTax === 'number' ? updateData.incomeTax : 0);
      updateData.collectedCurrentMonth = typeof updateData.collectedCurrentMonth === 'string' 
        ? parseFloat(updateData.collectedCurrentMonth) || 0 
        : (typeof updateData.collectedCurrentMonth === 'number' ? updateData.collectedCurrentMonth : 0);
      
      // Debug logging
      console.log('[STORAGE UPDATE] Updating report with:', {
        profitTransactionTax: updateData.profitTransactionTax,
        incomeTax: updateData.incomeTax,
        collectedCurrentMonth: updateData.collectedCurrentMonth,
        confirmedAmount: updateData.confirmedAmount,
        remainingCollectible: updateData.remainingCollectible,
        profitTransactionTaxType: typeof updateData.profitTransactionTax,
        incomeTaxType: typeof updateData.incomeTax,
        collectedCurrentMonthType: typeof updateData.collectedCurrentMonth,
      });
      
      const [updated] = await db
        .update(caseReportsV2)
        .set(updateData)
        .where(eq(caseReportsV2.caseId, report.caseId))
        .returning();
      
      console.log('[STORAGE UPDATE] Updated report:', {
        profitTransactionTax: updated.profitTransactionTax,
        incomeTax: updated.incomeTax,
        collectedCurrentMonth: updated.collectedCurrentMonth,
      });
      
      return updated!;
    } else {
      // Create new report (calculations applied in createCaseReportV2)
      return await this.createCaseReportV2(report);
    }
  }

  async lockCaseReportV2(caseId: string): Promise<CaseReportV2 | undefined> {
    const [updated] = await db
      .update(caseReportsV2)
      .set({ status: 'locked', updatedAt: new Date() })
      .where(eq(caseReportsV2.caseId, caseId))
      .returning();
    return updated || undefined;
  }

  async unlockCaseReportV2(caseId: string): Promise<CaseReportV2 | undefined> {
    const [updated] = await db
      .update(caseReportsV2)
      .set({ status: 'draft', updatedAt: new Date() })
      .where(eq(caseReportsV2.caseId, caseId))
      .returning();
    return updated || undefined;
  }

  // Case Report History
  async getCaseReportHistory(reportId: string): Promise<CaseReportHistory[]> {
    return await db
      .select()
      .from(caseReportHistory)
      .where(eq(caseReportHistory.reportId, reportId))
      .orderBy(desc(caseReportHistory.changedAt));
  }

  async createCaseReportHistory(history: InsertCaseReportHistory): Promise<CaseReportHistory> {
    const [newHistory] = await db
      .insert(caseReportHistory)
      .values(history)
      .returning();
    return newHistory;
  }

  // Case Status Transitions
  async getCaseStatusTransitions(caseId: string): Promise<CaseStatusTransition[]> {
    return await db
      .select()
      .from(caseStatusTransitions)
      .where(eq(caseStatusTransitions.caseId, caseId))
      .orderBy(desc(caseStatusTransitions.transitionedAt));
  }

  async getCaseStatusTransition(id: string): Promise<CaseStatusTransition | undefined> {
    const [transition] = await db
      .select()
      .from(caseStatusTransitions)
      .where(eq(caseStatusTransitions.id, id))
      .limit(1);
    return transition || undefined;
  }

  async createCaseStatusTransition(transition: InsertCaseStatusTransition): Promise<CaseStatusTransition> {
    const [newTransition] = await db
      .insert(caseStatusTransitions)
      .values(transition)
      .returning();
    return newTransition;
  }

  // Ministry Reports
  async getMinistryReport(groupId: string, monthShamsi: number, yearShamsi: number): Promise<MinistryReport | undefined> {
    const [report] = await db
      .select()
      .from(ministryReports)
      .where(
        and(
          eq(ministryReports.groupId, groupId),
          eq(ministryReports.monthShamsi, monthShamsi),
          eq(ministryReports.yearShamsi, yearShamsi)
        )
      )
      .limit(1);
    return report || undefined;
  }

  async upsertMinistryReport(report: InsertMinistryReport): Promise<MinistryReport> {
    // Try to find existing report
    const existing = await this.getMinistryReport(
      report.groupId,
      report.monthShamsi,
      report.yearShamsi
    );

    if (existing) {
      // Update existing - only update provided fields (PATCH semantics)
      // Preserve existing values for fields not provided
      const updateData: any = {
        lastUpdatedAt: new Date(),
      };
      
      // Only update fields that are explicitly provided (not undefined)
      if (report.lettersReceived !== undefined) updateData.lettersReceived = report.lettersReceived;
      if (report.lettersSent !== undefined) updateData.lettersSent = report.lettersSent;
      if (report.inquiriesReceived !== undefined) updateData.inquiriesReceived = report.inquiriesReceived;
      if (report.inquiriesSent !== undefined) updateData.inquiriesSent = report.inquiriesSent;
      if (report.notes !== undefined) updateData.notes = report.notes;
      if (report.lastUpdatedBy !== undefined) updateData.lastUpdatedBy = report.lastUpdatedBy;
      
      const [updated] = await db
        .update(ministryReports)
        .set(updateData)
        .where(eq(ministryReports.id, existing.id))
        .returning();
      return updated;
    } else {
      // Create new - use defaults for missing fields
      const newReportData: InsertMinistryReport = {
        groupId: report.groupId,
        monthShamsi: report.monthShamsi,
        yearShamsi: report.yearShamsi,
        lettersReceived: report.lettersReceived ?? 0,
        lettersSent: report.lettersSent ?? 0,
        inquiriesReceived: report.inquiriesReceived ?? 0,
        inquiriesSent: report.inquiriesSent ?? 0,
        notes: report.notes ?? null,
        lastUpdatedBy: report.lastUpdatedBy,
      };
      
      const [newReport] = await db
        .insert(ministryReports)
        .values(newReportData)
        .returning();
      return newReport;
    }
  }

  async getMinistryReportsByMonth(monthShamsi: number, yearShamsi: number): Promise<MinistryReport[]> {
    return await db
      .select()
      .from(ministryReports)
      .where(
        and(
          eq(ministryReports.monthShamsi, monthShamsi),
          eq(ministryReports.yearShamsi, yearShamsi)
        )
      )
      .orderBy(asc(ministryReports.groupId));
  }

  // Audit Records (Year Range Audits)
  async getAuditRecords(entityId?: string, filters?: { yearFrom?: number; yearTo?: number; status?: string; auditGroupId?: string }): Promise<AuditRecord[]> {
    const conditions = [];
    if (entityId) {
      conditions.push(eq(auditRecords.entityId, entityId));
    }
    if (filters) {
      if (filters.yearFrom !== undefined) {
        conditions.push(sql`${auditRecords.yearFrom} <= ${filters.yearFrom}`);
        conditions.push(sql`${auditRecords.yearTo} >= ${filters.yearFrom}`);
      }
      if (filters.yearTo !== undefined) {
        conditions.push(sql`${auditRecords.yearFrom} <= ${filters.yearTo}`);
        conditions.push(sql`${auditRecords.yearTo} >= ${filters.yearTo}`);
      }
      if (filters.status) {
        conditions.push(eq(auditRecords.status, filters.status));
      }
      if (filters.auditGroupId) {
        conditions.push(eq(auditRecords.auditGroupId, filters.auditGroupId));
      }
    }
    
    return await db
      .select()
      .from(auditRecords)
      .where(conditions.length > 0 ? and(...conditions) : undefined)
      .orderBy(desc(auditRecords.yearFrom), desc(auditRecords.createdAt));
  }

  async getAuditRecord(id: string): Promise<AuditRecord | undefined> {
    const [record] = await db.select().from(auditRecords).where(eq(auditRecords.id, id));
    return record || undefined;
  }

  async getAuditRecordsByEntity(entityId: string): Promise<AuditRecord[]> {
    return await db
      .select()
      .from(auditRecords)
      .where(eq(auditRecords.entityId, entityId))
      .orderBy(desc(auditRecords.yearFrom), desc(auditRecords.createdAt));
  }

  async checkAuditRecordOverlap(entityId: string, yearFrom: number, yearTo: number, excludeId?: string): Promise<AuditRecord[]> {
    const conditions: any[] = [
      eq(auditRecords.entityId, entityId),
      // Overlap condition: NOT (year_to < yearFrom OR year_from > yearTo)
      sql`NOT (${auditRecords.yearTo} < ${yearFrom} OR ${auditRecords.yearFrom} > ${yearTo})`
    ];
    
    if (excludeId) {
      conditions.push(ne(auditRecords.id, excludeId));
    }
    
    return await db
      .select()
      .from(auditRecords)
      .where(and(...conditions));
  }

  async createAuditRecord(record: InsertAuditRecord): Promise<AuditRecord> {
    // Validate year range
    if (record.yearFrom > record.yearTo) {
      throw new Error('yearFrom must be less than or equal to yearTo');
    }
    
    // Check for overlaps (database trigger will also enforce this)
    const overlaps = await this.checkAuditRecordOverlap(record.entityId, record.yearFrom, record.yearTo);
    if (overlaps.length > 0) {
      throw new Error(`Overlapping year range detected. Existing ranges: ${overlaps.map(o => `${o.yearFrom}-${o.yearTo}`).join(', ')}`);
    }
    
    const [newRecord] = await db
      .insert(auditRecords)
      .values({
        ...record,
        updatedAt: new Date(),
      })
      .returning();
    return newRecord;
  }

  async updateAuditRecord(id: string, record: Partial<InsertAuditRecord>): Promise<AuditRecord | undefined> {
    // If updating year range, check for overlaps
    if (record.yearFrom !== undefined || record.yearTo !== undefined) {
      const existing = await this.getAuditRecord(id);
      if (!existing) {
        return undefined;
      }
      
      const newYearFrom = record.yearFrom ?? existing.yearFrom;
      const newYearTo = record.yearTo ?? existing.yearTo;
      
      if (newYearFrom > newYearTo) {
        throw new Error('yearFrom must be less than or equal to yearTo');
      }
      
      // Check for overlaps excluding current record
      const overlaps = await this.checkAuditRecordOverlap(existing.entityId, newYearFrom, newYearTo, id);
      if (overlaps.length > 0) {
        throw new Error(`Overlapping year range detected. Existing ranges: ${overlaps.map(o => `${o.yearFrom}-${o.yearTo}`).join(', ')}`);
      }
    }
    
    const [updated] = await db
      .update(auditRecords)
      .set({
        ...record,
        updatedAt: new Date(),
      })
      .where(eq(auditRecords.id, id))
      .returning();
    return updated || undefined;
  }

  async deleteAuditRecord(id: string): Promise<boolean> {
    const [deleted] = await db
      .delete(auditRecords)
      .where(eq(auditRecords.id, id))
      .returning();
    return !!deleted;
  }

  async completeAuditRecord(id: string, completedBy: string): Promise<AuditRecord | undefined> {
    const [updated] = await db
      .update(auditRecords)
      .set({
        status: 'completed',
        completedAt: new Date(),
        updatedAt: new Date(),
      })
      .where(eq(auditRecords.id, id))
      .returning();
    return updated || undefined;
  }

  // Audit Record History
  async getAuditRecordHistory(auditRecordId: string): Promise<AuditRecordHistory[]> {
    return await db
      .select()
      .from(auditRecordHistory)
      .where(eq(auditRecordHistory.auditRecordId, auditRecordId))
      .orderBy(desc(auditRecordHistory.changedAt));
  }

  async createAuditRecordHistory(history: InsertAuditRecordHistory): Promise<AuditRecordHistory> {
    const [newHistory] = await db
      .insert(auditRecordHistory)
      .values(history)
      .returning();
    return newHistory;
  }

  // Committees
  async getCommittees(): Promise<Committee[]> {
    return await db
      .select()
      .from(committees)
      .orderBy(desc(committees.createdAt));
  }

  async getCommittee(id: string): Promise<Committee | undefined> {
    const [committee] = await db
      .select()
      .from(committees)
      .where(eq(committees.id, id));
    return committee || undefined;
  }

  async getActiveCommittees(): Promise<Committee[]> {
    return await db
      .select()
      .from(committees)
      .where(eq(committees.status, 'Active'))
      .orderBy(desc(committees.createdAt));
  }

  async createCommittee(committee: InsertCommittee): Promise<Committee> {
    const [newCommittee] = await db
      .insert(committees)
      .values(committee)
      .returning();
    return newCommittee;
  }

  async updateCommittee(id: string, committeeData: Partial<InsertCommittee>): Promise<Committee | undefined> {
    const [updated] = await db
      .update(committees)
      .set(committeeData)
      .where(eq(committees.id, id))
      .returning();
    return updated || undefined;
  }

  async closeCommittee(id: string): Promise<Committee | undefined> {
    const [updated] = await db
      .update(committees)
      .set({ status: 'Closed', locked: true })
      .where(eq(committees.id, id))
      .returning();
    return updated || undefined;
  }
  
  // New Committee Module Storage Methods
  async getCommitteesNew(): Promise<CommitteeNew[]> {
    return await db
      .select()
      .from(committeesNew)
      .orderBy(desc(committeesNew.createdAt));
  }
  
  async getCommitteeNew(id: string): Promise<CommitteeNew | undefined> {
    const [committee] = await db
      .select()
      .from(committeesNew)
      .where(eq(committeesNew.id, id));
    return committee || undefined;
  }
  
  async getCommitteeByYearMonth(year: number, month: number): Promise<CommitteeNew | undefined> {
    const [committee] = await db
      .select()
      .from(committeesNew)
      .where(and(
        eq(committeesNew.year, year),
        eq(committeesNew.month, month)
      ));
    return committee || undefined;
  }
  
  async createCommitteeNew(committee: InsertCommitteeNew): Promise<CommitteeNew> {
    const [newCommittee] = await db
      .insert(committeesNew)
      .values(committee)
      .returning();
    return newCommittee;
  }
  
  async updateCommitteeNew(id: string, updates: Partial<InsertCommitteeNew>): Promise<CommitteeNew | undefined> {
    const [updated] = await db
      .update(committeesNew)
      .set(updates)
      .where(eq(committeesNew.id, id))
      .returning();
    return updated || undefined;
  }
  
  // Committee Case Assignments Storage Methods
  async getCommitteeCaseAssignment(id: string): Promise<CommitteeCaseAssignment | undefined> {
    const [assignment] = await db
      .select()
      .from(committeeCaseAssignments)
      .where(eq(committeeCaseAssignments.id, id));
    return assignment || undefined;
  }
  
  async createCommitteeCaseAssignment(assignment: InsertCommitteeCaseAssignment): Promise<CommitteeCaseAssignment> {
    const [newAssignment] = await db
      .insert(committeeCaseAssignments)
      .values(assignment)
      .returning();
    return newAssignment;
  }
  
  async getCaseAssignmentHistory(caseId: string): Promise<CommitteeCaseAssignment[]> {
    return await db
      .select()
      .from(committeeCaseAssignments)
      .where(eq(committeeCaseAssignments.caseId, caseId))
      .orderBy(desc(committeeCaseAssignments.assignedAt));
  }
  
  async getCommitteeAssignments(committeeId: string): Promise<CommitteeCaseAssignment[]> {
    return await db
      .select()
      .from(committeeCaseAssignments)
      .where(eq(committeeCaseAssignments.committeeId, committeeId))
      .orderBy(desc(committeeCaseAssignments.assignedAt));
  }
  
  async getAllAssignmentsByAuditGroup(auditGroupId: string): Promise<CommitteeCaseAssignment[]> {
    return await db
      .select()
      .from(committeeCaseAssignments)
      .where(eq(committeeCaseAssignments.auditGroupId, auditGroupId))
      .orderBy(desc(committeeCaseAssignments.assignedAt));
  }
  
  async getAllDirectAssignments(startDate?: Date, endDate?: Date): Promise<CommitteeCaseAssignment[]> {
    const conditions: any[] = [eq(committeeCaseAssignments.assignmentType, 'DIRECT')];
    
    if (startDate) {
      conditions.push(gte(committeeCaseAssignments.assignedAt, startDate));
    }
    if (endDate) {
      conditions.push(lte(committeeCaseAssignments.assignedAt, endDate));
    }
    
    return await db
      .select()
      .from(committeeCaseAssignments)
      .where(and(...conditions))
      .orderBy(desc(committeeCaseAssignments.assignedAt));
  }

  // Committee Entities
  async getCommitteeEntities(committeeId: string): Promise<CommitteeEntity[]> {
    return await db
      .select()
      .from(committeeEntities)
      .where(eq(committeeEntities.committeeId, committeeId))
      .orderBy(desc(committeeEntities.createdAt));
  }

  async addEntityToCommittee(committeeId: string, entityId: string): Promise<CommitteeEntity> {
    // Check if committee is closed or locked
    const committee = await this.getCommittee(committeeId);
    if (!committee) {
      throw new Error('کمیته یافت نشد');
    }
    if (committee.status === 'Closed') {
      throw new Error('نمی‌توان به کمیته بسته شده نهاد اضافه کرد');
    }
    // Check if committee is locked
    if ((committee as any).locked === true) {
      throw new Error('کمیته قفل شده است. نمی‌توان قضیه جدید اضافه کرد. فقط اختصاص به گروه و تولید گزارش مجاز است.');
    }

    // Check if entity already exists in committee
    const existing = await db
      .select()
      .from(committeeEntities)
      .where(
        and(
          eq(committeeEntities.committeeId, committeeId),
          eq(committeeEntities.entityId, entityId)
        )
      )
      .limit(1);

    if (existing.length > 0) {
      throw new Error('این نهاد قبلاً به کمیته اضافه شده است');
    }

    const [newEntry] = await db
      .insert(committeeEntities)
      .values({ committeeId, entityId })
      .returning();
    return newEntry;
  }

  async removeEntityFromCommittee(committeeId: string, entityId: string): Promise<boolean> {
    const [deleted] = await db
      .delete(committeeEntities)
      .where(
        and(
          eq(committeeEntities.committeeId, committeeId),
          eq(committeeEntities.entityId, entityId)
        )
      )
      .returning();
    return !!deleted;
  }

  async getEntitiesByCommittee(committeeId: string): Promise<Entity[]> {
    const committeeEntityIds = await db
      .select({ entityId: committeeEntities.entityId })
      .from(committeeEntities)
      .where(eq(committeeEntities.committeeId, committeeId));

    if (committeeEntityIds.length === 0) {
      return [];
    }

    const entityIds = committeeEntityIds.map(ce => ce.entityId);
    return await db
      .select()
      .from(entities)
      .where(inArray(entities.id, entityIds));
  }

  // Committee Cases
  async getCasesByCommittee(committeeId: string): Promise<Case[]> {
    return await db
      .select()
      .from(cases)
      .where(eq(cases.committeeId, committeeId))
      .orderBy(desc(cases.createdAt));
  }

  async getCasesByCommitteeAndStatus(committeeId: string, status: string): Promise<Case[]> {
    return await db
      .select()
      .from(cases)
      .where(
        and(
          eq(cases.committeeId, committeeId),
          eq(cases.status, status)
        )
      )
      .orderBy(desc(cases.createdAt));
  }

  async getCasesByShamsiMonthAndYear(month: string, year: number, excludeCommitteeId?: string): Promise<Case[]> {
    // FIX: Committee case loading - removed restrictive month/year filtering
    // Business rules: Cases should appear if:
    // 1. Case exists (created)
    // 2. Case is NOT completed
    // 3. Case is NOT archived or deleted
    // 4. Case has NOT already been assigned through a committee (except current)
    // 5. Case status is one of: جدید, در انتظار (Pending Group Assignment)
    // 6. Case does NOT already belong to another committee record
    
    try {
      const queryConditions: any[] = [];
      
      // Status filter: Only "جدید" (NEW) and "Pending Group Assignment" (در انتظار)
      // Note: "Pending Group Assignment" is a string literal used for committee cases
      queryConditions.push(
        or(
          eq(cases.status, 'جدید'),
          eq(cases.status, 'Pending Group Assignment')
        )
      );
      
      // Exclude completed cases
      queryConditions.push(ne(cases.status, 'تکمیل شده'));
      
      // Exclude cases already assigned to a committee
      // If excludeCommitteeId is provided, allow cases assigned to that committee (for viewing)
      // Otherwise, only show unassigned cases
      if (excludeCommitteeId) {
        queryConditions.push(
          or(
            isNull(cases.committeeId),
            eq(cases.committeeId, excludeCommitteeId)
          )
        );
      } else {
        // Only show cases not assigned to any committee
        queryConditions.push(isNull(cases.committeeId));
      }
      
      // Exclude cases already assigned to a group (receivingGroup IS NOT NULL)
      // Cases should not appear if they've already been assigned to an audit group
      queryConditions.push(isNull(cases.receivingGroup));
      
      const filteredCases = await db
        .select()
        .from(cases)
        .where(and(...queryConditions))
        .orderBy(desc(cases.createdAt));
      
      return filteredCases;
    } catch (error) {
      console.error('Error querying cases for committee selection:', error);
      // Fallback to in-memory filtering if database query fails
      const allCases = await this.getCases();
      
      const filtered = allCases.filter(c => {
        // Status must be "جدید" or "Pending Group Assignment"
        const validStatus = c.status === 'جدید' || c.status === 'Pending Group Assignment';
        if (!validStatus) return false;
        
        // Exclude completed cases
        if (c.status === 'تکمیل شده') return false;
        
        // Exclude cases already assigned to a committee
        if (excludeCommitteeId) {
          // Exclude cases assigned to any committee except the current one
          if (c.committeeId && c.committeeId !== excludeCommitteeId) {
            return false;
          }
        } else {
          // Exclude all cases with any committeeId
          if (c.committeeId) {
            return false;
          }
        }
        
        // Exclude cases already assigned to a group
        if (c.receivingGroup) {
          return false;
        }
        
        return true;
      });
      
      return filtered;
    }
  }

  // Archived Files
  async getArchivedFiles(filters?: {
    page?: number;
    size?: number;
    year?: number;
    category?: string;
    q?: string;
    sort?: string;
    uploadedBy?: string;
    dateFrom?: Date;
    dateTo?: Date;
  }): Promise<{ files: ArchivedFile[]; total: number; page: number; size: number }> {
    const page = filters?.page || 1;
    const size = filters?.size || 25;
    const offset = (page - 1) * size;

    const conditions: any[] = [isNull(archivedFiles.deletedAt)]; // Only non-deleted files

    if (filters?.year) {
      conditions.push(eq(archivedFiles.year, filters.year));
    }

    if (filters?.category) {
      conditions.push(eq(archivedFiles.category, filters.category));
    }

    if (filters?.uploadedBy) {
      conditions.push(eq(archivedFiles.uploadedBy, filters.uploadedBy));
    }

    if (filters?.dateFrom) {
      conditions.push(gte(archivedFiles.uploadedAt, filters.dateFrom));
    }

    if (filters?.dateTo) {
      const endDate = new Date(filters.dateTo);
      endDate.setHours(23, 59, 59, 999);
      conditions.push(lte(archivedFiles.uploadedAt, endDate));
    }

    if (filters?.q) {
      const searchPattern = `%${filters.q}%`;
      conditions.push(
        or(
          ilike(archivedFiles.fileName, searchPattern),
          ilike(archivedFiles.originalFileName, searchPattern),
          ilike(archivedFiles.description, searchPattern),
          ilike(archivedFiles.category, searchPattern)
        )
      );
    }

    const whereClause = conditions.length > 0 ? and(...conditions) : undefined;

    // Get total count
    const totalResult = await db
      .select({ count: count() })
      .from(archivedFiles)
      .where(whereClause);
    const total = Number(totalResult[0]?.count || 0);

    // Determine sort order
    let orderBy: any;
    if (filters?.sort) {
      const [field, direction] = filters.sort.split(':');
      if (field === 'year') {
        orderBy = direction === 'asc' ? asc(archivedFiles.year) : desc(archivedFiles.year);
      } else if (field === 'category') {
        orderBy = direction === 'asc' ? asc(archivedFiles.category) : desc(archivedFiles.category);
      } else if (field === 'uploadedAt') {
        orderBy = direction === 'asc' ? asc(archivedFiles.uploadedAt) : desc(archivedFiles.uploadedAt);
      } else if (field === 'fileName') {
        orderBy = direction === 'asc' ? asc(archivedFiles.fileName) : desc(archivedFiles.fileName);
      } else {
        orderBy = desc(archivedFiles.uploadedAt); // Default
      }
    } else {
      orderBy = desc(archivedFiles.uploadedAt); // Default: newest first
    }

    // Get paginated results
    const files = await db
      .select()
      .from(archivedFiles)
      .where(whereClause)
      .orderBy(orderBy)
      .limit(size)
      .offset(offset);

    return {
      files,
      total,
      page,
      size,
    };
  }

  async getArchivedFile(id: string): Promise<ArchivedFile | undefined> {
    const [file] = await db
      .select()
      .from(archivedFiles)
      .where(and(eq(archivedFiles.id, id), isNull(archivedFiles.deletedAt)))
      .limit(1);
    return file || undefined;
  }

  async getArchivedFileVersions(archivedFileId: string): Promise<ArchivedFileVersion[]> {
    return await db
      .select()
      .from(archivedFileVersions)
      .where(eq(archivedFileVersions.archivedFileId, archivedFileId))
      .orderBy(desc(archivedFileVersions.versionNumber));
  }

  async createArchivedFile(file: InsertArchivedFile): Promise<ArchivedFile> {
    const [newFile] = await db
      .insert(archivedFiles)
      .values(file)
      .returning();
    return newFile;
  }

  async createArchivedFileVersion(version: InsertArchivedFileVersion): Promise<ArchivedFileVersion> {
    const [newVersion] = await db
      .insert(archivedFileVersions)
      .values(version)
      .returning();
    return newVersion;
  }

  async updateArchivedFile(id: string, updates: Partial<InsertArchivedFile>): Promise<ArchivedFile | undefined> {
    const [updated] = await db
      .update(archivedFiles)
      .set(updates)
      .where(eq(archivedFiles.id, id))
      .returning();
    return updated || undefined;
  }

  async softDeleteArchivedFile(id: string): Promise<boolean> {
    const [deleted] = await db
      .update(archivedFiles)
      .set({ deletedAt: new Date() })
      .where(eq(archivedFiles.id, id))
      .returning();
    return !!deleted;
  }

  async logArchivedFileAccess(log: InsertArchivedFileAccessLog): Promise<ArchivedFileAccessLog> {
    const [accessLog] = await db
      .insert(archivedFileAccessLogs)
      .values(log)
      .returning();
    return accessLog;
  }

  async findExistingArchivedFile(originalFileName: string, year: number): Promise<ArchivedFile | undefined> {
    const [file] = await db
      .select()
      .from(archivedFiles)
      .where(
        and(
          eq(archivedFiles.originalFileName, originalFileName),
          eq(archivedFiles.year, year),
          isNull(archivedFiles.deletedAt)
        )
      )
      .limit(1);
    return file || undefined;
  }

  // Monthly Group Reports
  async getMonthlyGroupReport(groupId: string, monthNumber: number, year: number): Promise<MonthlyGroupReport | undefined> {
    const [report] = await db
      .select()
      .from(monthlyGroupReports)
      .where(
        and(
          eq(monthlyGroupReports.groupId, groupId),
          eq(monthlyGroupReports.monthNumber, monthNumber),
          eq(monthlyGroupReports.yearNumber, year)
        )
      )
      .limit(1);
    return report || undefined;
  }

  async upsertMonthlyGroupReport(report: InsertMonthlyGroupReport): Promise<MonthlyGroupReport> {
    const existing = await this.getMonthlyGroupReport(report.groupId, report.monthNumber, report.yearNumber);
    
    if (existing) {
      const [updated] = await db
        .update(monthlyGroupReports)
        .set({
          ...report,
          updatedAt: new Date(),
        })
        .where(eq(monthlyGroupReports.id, existing.id))
        .returning();
      return updated;
    } else {
      const [created] = await db
        .insert(monthlyGroupReports)
        .values(report)
        .returning();
      return created;
    }
  }

  async getMonthlyReportAnomalies(reportId: string): Promise<MonthlyReportAnomaly[]> {
    return await db
      .select()
      .from(monthlyReportAnomalies)
      .where(eq(monthlyReportAnomalies.reportId, reportId))
      .orderBy(monthlyReportAnomalies.createdAt);
  }

  async updateGroupMonthlyTaxTarget(groupId: string, target: number | null): Promise<Group | undefined> {
    const [updated] = await db
      .update(groups)
      .set({ monthlyTaxTarget: target ? target.toString() : null })
      .where(eq(groups.id, groupId))
      .returning();
    return updated || undefined;
  }

}

export const storage = new DatabaseStorage();
