import type { Request } from 'express';

/**
 * Extract client IP address from request, handling:
 * - X-Forwarded-For header (for reverse proxies/load balancers)
 * - X-Real-IP header (alternative proxy header)
 * - req.ip (Express trust proxy must be enabled)
 * - req.connection.remoteAddress (fallback)
 * 
 * Handles LAN/local IPs correctly and extracts the first real client IP
 * from proxy chains.
 * 
 * @param req Express request object
 * @returns Client IP address or 'unknown' if not available
 */
export function extractClientIp(req: Request): string {
  // Priority 1: X-Forwarded-For header (most common for reverse proxies)
  // Format: "client, proxy1, proxy2" - we want the first (original client)
  const forwardedFor = req.headers['x-forwarded-for'];
  if (forwardedFor) {
    const ips = Array.isArray(forwardedFor) 
      ? forwardedFor[0].split(',') 
      : forwardedFor.split(',');
    const firstIp = ips[0]?.trim();
    if (firstIp) {
      return firstIp;
    }
  }
  
  // Priority 2: X-Real-IP header (alternative proxy header)
  const realIp = req.headers['x-real-ip'];
  if (realIp) {
    const ip = Array.isArray(realIp) ? realIp[0] : realIp;
    if (ip) {
      return ip.trim();
    }
  }
  
  // Priority 3: req.ip (requires Express trust proxy to be configured)
  if (req.ip && req.ip !== '::1' && req.ip !== '127.0.0.1') {
    return req.ip;
  }
  
  // Priority 4: req.connection.remoteAddress (fallback)
  const remoteAddress = req.connection?.remoteAddress || 
                        (req.socket as any)?.remoteAddress;
  if (remoteAddress) {
    // Handle IPv6 mapped IPv4 addresses (::ffff:192.168.1.1 -> 192.168.1.1)
    if (remoteAddress.startsWith('::ffff:')) {
      return remoteAddress.substring(7);
    }
    return remoteAddress;
  }
  
  // Fallback: return 'unknown' if no IP can be determined
  return 'unknown';
}

