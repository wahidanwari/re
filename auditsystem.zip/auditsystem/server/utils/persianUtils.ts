/**
 * Utility functions for handling Persian text and numbers
 */

/**
 * Persian digits to English digits mapping
 */
const PERSIAN_TO_ENGLISH_DIGITS: Record<string, string> = {
  '۰': '0', '۱': '1', '۲': '2', '۳': '3', '۴': '4',
  '۵': '5', '۶': '6', '۷': '7', '۸': '8', '۹': '9',
};

/**
 * Convert Persian digits to English digits
 */
export function convertPersianToEnglish(text: string): string {
  if (!text) return text;
  return text
    .split('')
    .map(char => PERSIAN_TO_ENGLISH_DIGITS[char] || char)
    .join('');
}

/**
 * Normalize Persian text (trim, convert digits, remove zero-width characters)
 */
export function normalizePersianText(text: string): string {
  if (!text) return '';
  return convertPersianToEnglish(text.trim())
    .replace(/[\u200C\u200D\u200E\u200F\u202A-\u202E]/g, ''); // Remove zero-width characters
}

/**
 * Check if a string contains Persian digits
 */
export function hasPersianDigits(text: string): boolean {
  return /[۰-۹]/.test(text);
}

