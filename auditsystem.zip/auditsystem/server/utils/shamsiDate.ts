/**
 * Utility functions for Shamsi (Jalaali) date conversion
 */

import jalaali from "jalaali-js";

/**
 * Convert Gregorian date string (YYYY-MM-DD) to JavaScript Date
 */
export function gregorianStringToDate(gregorianDate: string): Date | null {
  try {
    // Trim whitespace
    const trimmed = gregorianDate.trim();
    const parts = trimmed.split('-');
    if (parts.length !== 3) {
      return null;
    }
    
    const year = parseInt(parts[0], 10);
    const month = parseInt(parts[1], 10);
    const day = parseInt(parts[2], 10);
    
    if (isNaN(year) || isNaN(month) || isNaN(day)) {
      return null;
    }
    
    // Validate ranges - Gregorian years should be reasonable (1900-2100)
    if (year < 1900 || year > 2100) {
      return null;
    }
    if (month < 1 || month > 12 || day < 1 || day > 31) {
      return null;
    }
    
    // Create date and validate it's actually valid (handles invalid dates like Feb 30)
    const date = new Date(year, month - 1, day);
    if (date.getFullYear() !== year || date.getMonth() !== month - 1 || date.getDate() !== day) {
      return null;
    }
    
    return date;
  } catch (error) {
    console.error('Error converting Gregorian date:', error);
    return null;
  }
}

/**
 * Convert Shamsi date string (YYYY/MM/DD) to JavaScript Date
 */
export function shamsiToDate(shamsiDate: string): Date | null {
  try {
    const parts = shamsiDate.split('/');
    if (parts.length !== 3) {
      return null;
    }
    
    const year = parseInt(parts[0], 10);
    const month = parseInt(parts[1], 10);
    const day = parseInt(parts[2], 10);
    
    if (isNaN(year) || isNaN(month) || isNaN(day)) {
      return null;
    }
    
    // Convert Jalaali to Gregorian
    const gregorian = jalaali.toGregorian(year, month, day);
    return new Date(gregorian.gy, gregorian.gm - 1, gregorian.gd);
  } catch (error) {
    console.error('Error converting Shamsi date:', error);
    return null;
  }
}

/**
 * Convert JavaScript Date to Shamsi date string (YYYY/MM/DD)
 */
export function dateToShamsi(date: Date): string {
  const j = jalaali.toJalaali(date);
  return `${j.jy}/${String(j.jm).padStart(2, '0')}/${String(j.jd).padStart(2, '0')}`;
}

/**
 * Parse date string (accepts both Gregorian YYYY-MM-DD and Shamsi YYYY/MM/DD formats)
 */
export function parseDateString(dateString: string): { date: Date | null; format: 'gregorian' | 'shamsi' | null } {
  if (!dateString || typeof dateString !== 'string') {
    return { date: null, format: null };
  }
  
  const trimmed = dateString.trim();
  
  // Try Gregorian format first (YYYY-MM-DD) - this is what the client sends
  if (trimmed.includes('-')) {
    const date = gregorianStringToDate(trimmed);
    if (date) {
      return { date, format: 'gregorian' };
    }
  }
  
  // Try Shamsi format (YYYY/MM/DD) - for backward compatibility
  if (trimmed.includes('/')) {
    const date = shamsiToDate(trimmed);
    if (date) {
      return { date, format: 'shamsi' };
    }
  }
  
  return { date: null, format: null };
}

/**
 * Validate date string format (accepts both Gregorian YYYY-MM-DD and Shamsi YYYY/MM/DD) and ensure it's not in the future
 */
export function validateShamsiDate(dateString: string): { valid: boolean; error?: string } {
  if (!dateString || typeof dateString !== 'string') {
    return { valid: false, error: 'تاریخ نامعتبر است' };
  }
  
  const { date, format } = parseDateString(dateString);
  if (!date || !format) {
    return { valid: false, error: 'فرمت تاریخ نامعتبر است. فرمت صحیح: YYYY/MM/DD یا YYYY-MM-DD' };
  }
  
  // Check if date is in the future
  const now = new Date();
  if (date > now) {
    return { valid: false, error: 'تاریخ نمی‌تواند در آینده باشد' };
  }
  
  return { valid: true };
}

