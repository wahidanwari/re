import { db } from "../db";
import { users, cases, tickets } from "@shared/schema";
import { sql } from "drizzle-orm";
import { randomBytes } from "crypto";

export async function generateAuditId(): Promise<string> {
  // New format: aud1234 (lowercase 'aud' + 4 digits)
  // Check for both old format (AUD-XXXXX) and new format (audXXXX)
  const result = await db.execute<{ max_id: string }>(sql`
    SELECT COALESCE(
      MAX(
        CASE 
          WHEN audit_id ~ '^aud[0-9]+$' THEN CAST(SUBSTRING(audit_id FROM 4) AS INTEGER)
          WHEN audit_id ~ '^AUD-[0-9]+$' THEN CAST(SUBSTRING(audit_id FROM 5) AS INTEGER)
          ELSE 0
        END
      ), 0
    ) + 1 as max_id
    FROM users
    WHERE audit_id ~ '^(aud|AUD-)[0-9]+$'
  `);
  
  const nextId = result.rows[0]?.max_id || 1;
  // Format as audXXXX (4 digits, zero-padded)
  return `aud${String(nextId).padStart(4, '0')}`;
}

export async function generateCaseId(): Promise<string> {
  const result = await db.execute<{ max_id: string }>(sql`
    SELECT COALESCE(MAX(CAST(SUBSTRING(case_id FROM 9) AS INTEGER)), 0) + 1 as max_id
    FROM cases
    WHERE case_id ~ '^AUDCASE-[0-9]+$'
  `);
  
  const nextId = result.rows[0]?.max_id || 1;
  return `AUDCASE-${String(nextId).padStart(5, '0')}`;
}

export async function generateTicketId(): Promise<string> {
  const result = await db.execute<{ max_id: string }>(sql`
    SELECT COALESCE(MAX(CAST(SUBSTRING(ticket_id FROM 5) AS INTEGER)), 0) + 1 as max_id
    FROM tickets
    WHERE ticket_id ~ '^TKT-[0-9]+$'
  `);
  
  const nextId = result.rows[0]?.max_id || 1;
  return `TKT-${String(nextId).padStart(5, '0')}`;
}

/**
 * Generate a simple, predictable password for new users
 * Format: changeme## where ## is a 2-digit number (00-99)
 * This ensures easy first login and forces password change
 */
export function generateRandomPassword(length: number = 12): string {
  // Generate 2-digit random number (00-99)
  const randomNum = Math.floor(Math.random() * 100);
  const twoDigits = String(randomNum).padStart(2, '0');
  
  // Return password in format: changeme##
  return `changeme${twoDigits}`;
}
