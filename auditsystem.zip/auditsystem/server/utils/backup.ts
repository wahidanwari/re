import crypto from 'crypto';
import { pool } from '../db';
import { writeFile, readFile, mkdir } from 'fs/promises';
import { join } from 'path';
import { existsSync } from 'fs';

const BACKUP_DIR = process.env.BACKUP_DIR || './backups';
const ENCRYPTION_KEY = process.env.BACKUP_ENCRYPTION_KEY || crypto.randomBytes(32).toString('hex');
const ENCRYPTION_ALGORITHM = 'aes-256-gcm';

/**
 * Ensure backup directory exists
 */
export async function ensureBackupDirectory(): Promise<string> {
  if (!existsSync(BACKUP_DIR)) {
    await mkdir(BACKUP_DIR, { recursive: true });
  }
  return BACKUP_DIR;
}

/**
 * Encrypt data using AES-256-GCM
 */
export function encryptBackup(data: string, key: string): { encrypted: string; iv: string; authTag: string } {
  const iv = crypto.randomBytes(16);
  const cipher = crypto.createCipheriv(ENCRYPTION_ALGORITHM, Buffer.from(key, 'hex'), iv);
  
  let encrypted = cipher.update(data, 'utf8', 'hex');
  encrypted += cipher.final('hex');
  const authTag = cipher.getAuthTag().toString('hex');
  
  return { encrypted, iv: iv.toString('hex'), authTag };
}

/**
 * Decrypt data using AES-256-GCM
 */
export function decryptBackup(encrypted: string, key: string, iv: string, authTag: string): string {
  const decipher = crypto.createDecipheriv(
    ENCRYPTION_ALGORITHM,
    Buffer.from(key, 'hex'),
    Buffer.from(iv, 'hex')
  );
  decipher.setAuthTag(Buffer.from(authTag, 'hex'));
  
  let decrypted = decipher.update(encrypted, 'hex', 'utf8');
  decrypted += decipher.final('utf8');
  
  return decrypted;
}

/**
 * Create a database backup
 * Returns the backup file path
 */
export async function createBackup(includeDocuments: boolean = false): Promise<{
  backupPath: string;
  metadataPath: string;
  size: number;
  encrypted: boolean;
}> {
  const backupDir = await ensureBackupDirectory();
  const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
  const backupFilename = `db-backup-${timestamp}.sql`;
  const metadataFilename = `db-backup-${timestamp}.sql.meta.json`;
  const backupPath = join(backupDir, backupFilename);
  const metadataPath = join(backupDir, metadataFilename);

  // Create database dump using pg_dump format
  const client = await pool.connect();
  try {
    // Get all table data
    const tables = [
      'users', 'groups', 'group_members', 'group_targets',
      'entities', 'cases', 'tickets', 'notifications',
      'audit_logs', 'documents', 'system_settings',
      'roles', 'permissions', 'role_permissions',
      'packages', 'package_permissions', 'user_roles', 'user_packages',
      'session', // Session table
    ];

    let sqlDump = `-- Database Backup
-- Created: ${new Date().toISOString()}
-- Backup Type: Full
-- Encrypted: Yes

BEGIN;
\n`;

    // Export each table
    for (const table of tables) {
      try {
        // Get table schema (CREATE TABLE statement would be complex, so we'll just export data)
        // In production, you might want to use pg_dump binary or a proper library
        const result = await client.query(`SELECT * FROM ${table}`);
        
        if (result.rows.length > 0) {
          sqlDump += `\n-- Table: ${table}\n`;
          // Note: This is a simplified export. For production, consider using pg_dump
          // For now, we'll export as INSERT statements
          const columns = Object.keys(result.rows[0]);
          sqlDump += `INSERT INTO ${table} (${columns.join(', ')}) VALUES\n`;
          
          const values = result.rows.map((row, idx) => {
            const rowValues = columns.map(col => {
              const val = row[col];
              if (val === null) return 'NULL';
              if (typeof val === 'string') return `'${val.replace(/'/g, "''")}'`;
              if (typeof val === 'boolean') return val ? 'TRUE' : 'FALSE';
              if (val instanceof Date) return `'${val.toISOString()}'`;
              if (Array.isArray(val)) return `'${JSON.stringify(val).replace(/'/g, "''")}'`;
              if (typeof val === 'object') return `'${JSON.stringify(val).replace(/'/g, "''")}'`;
              return String(val);
            });
            return `(${rowValues.join(', ')})`;
          });
          
          sqlDump += values.join(',\n');
          sqlDump += ';\n\n';
        }
      } catch (error: any) {
        // Table might not exist or have different structure, skip
        console.warn(`Warning: Could not export table ${table}:`, error.message);
      }
    }

    sqlDump += '\nCOMMIT;\n';

    // Encrypt the backup
    const { encrypted, iv, authTag } = encryptBackup(sqlDump, ENCRYPTION_KEY);

    // Write encrypted backup
    await writeFile(backupPath, encrypted, 'utf8');

    // Write metadata
    const metadata = {
      filename: backupFilename,
      createdAt: new Date().toISOString(),
      databaseUrl: process.env.DATABASE_URL ? 'REDACTED' : undefined,
      tableCount: tables.length,
      encrypted: true,
      algorithm: ENCRYPTION_ALGORITHM,
      iv,
      authTag,
      size: Buffer.byteLength(encrypted, 'utf8'),
      includesDocuments: includeDocuments,
    };

    await writeFile(metadataPath, JSON.stringify(metadata, null, 2), 'utf8');

    const stats = await import('fs').then(fs => fs.promises.stat(backupPath));

    return {
      backupPath,
      metadataPath,
      size: stats.size,
      encrypted: true,
    };
  } finally {
    client.release();
  }
}

/**
 * Restore database from backup
 */
export async function restoreBackup(backupPath: string, encryptionKey?: string): Promise<{
  restored: boolean;
  tablesRestored: number;
  errors: string[];
}> {
  const key = encryptionKey || ENCRYPTION_KEY;
  const errors: string[] = [];
  let tablesRestored = 0;

  try {
    // Read backup file
    const encryptedData = await readFile(backupPath, 'utf8');

    // Find metadata file
    const metadataPath = backupPath.replace('.sql', '.sql.meta.json');
    let metadata: any = {};
    try {
      const metadataContent = await readFile(metadataPath, 'utf8');
      metadata = JSON.parse(metadataContent);
    } catch (error) {
      errors.push('Could not read metadata file. Using default encryption settings.');
    }

    // Decrypt backup
    let sqlDump: string;
    if (metadata.encrypted) {
      if (!metadata.iv || !metadata.authTag) {
        throw new Error('Missing encryption parameters in metadata');
      }
      sqlDump = decryptBackup(encryptedData, key, metadata.iv, metadata.authTag);
    } else {
      sqlDump = encryptedData;
    }

    // Execute restore (WARNING: This will overwrite existing data)
    const client = await pool.connect();
    try {
      // Begin transaction
      await client.query('BEGIN');

      // Execute SQL dump
      // Note: This is a simplified restore. For production, consider using pg_restore or proper SQL parser
      const statements = sqlDump.split(';').filter(s => s.trim().length > 0);
      
      for (const statement of statements) {
        const trimmed = statement.trim();
        if (!trimmed || trimmed.startsWith('--')) continue;
        
        try {
          await client.query(trimmed);
          if (trimmed.toUpperCase().includes('INSERT INTO')) {
            tablesRestored++;
          }
        } catch (error: any) {
          errors.push(`Error executing statement: ${error.message}`);
          // Continue with other statements
        }
      }

      // Commit transaction
      await client.query('COMMIT');

      return {
        restored: true,
        tablesRestored,
        errors,
      };
    } catch (error: any) {
      await client.query('ROLLBACK');
      throw error;
    } finally {
      client.release();
    }
  } catch (error: any) {
    errors.push(`Restore failed: ${error.message}`);
    return {
      restored: false,
      tablesRestored: 0,
      errors,
    };
  }
}

/**
 * List available backups
 */
export async function listBackups(): Promise<Array<{
  filename: string;
  path: string;
  metadataPath: string;
  createdAt: string;
  size: number;
  encrypted: boolean;
}>> {
  const backupDir = await ensureBackupDirectory();
  const { readdir, stat } = await import('fs/promises');
  
  const files = await readdir(backupDir);
  const backupFiles = files.filter(f => f.endsWith('.sql') && !f.endsWith('.meta.json'));
  
  const backups = await Promise.all(
    backupFiles.map(async (filename) => {
      const path = join(backupDir, filename);
      const metadataPath = join(backupDir, filename.replace('.sql', '.sql.meta.json'));
      
      try {
        const stats = await stat(path);
        let metadata: any = {};
        
        try {
          const metadataContent = await readFile(metadataPath, 'utf8');
          metadata = JSON.parse(metadataContent);
        } catch {
          // Metadata file might not exist for old backups
        }
        
        return {
          filename,
          path,
          metadataPath,
          createdAt: metadata.createdAt || stats.birthtime.toISOString(),
          size: stats.size,
          encrypted: metadata.encrypted || false,
        };
      } catch (error) {
        return null;
      }
    })
  );
  
  return backups.filter(b => b !== null) as Array<{
    filename: string;
    path: string;
    metadataPath: string;
    createdAt: string;
    size: number;
    encrypted: boolean;
  }>;
}

