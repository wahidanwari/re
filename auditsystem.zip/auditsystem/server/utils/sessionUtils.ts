// Session Utilities - Handle session invalidation and regeneration

import type { Request } from 'express';
import { db } from '../db';
import { sql } from 'drizzle-orm';

/**
 * Invalidate all sessions for a user
 * Since PostgreSQL session store doesn't support user-based lookup,
 * we query the session table directly
 * 
 * @param userId - The user ID whose sessions should be invalidated
 * @returns Number of sessions invalidated
 */
export async function invalidateUserSession(userId: string): Promise<number> {
  try {
    // Query session table for sessions containing this user ID
    // Session data is stored as JSON, so we need to search within it
    // The session structure is: { passport: { user: userId } } or { passport: { user: { id: userId, ... } } }
    const result = await db.execute(sql`
      DELETE FROM session
      WHERE sess::text LIKE ${`%"passport":{"user":"${userId}"}%`}
         OR sess::text LIKE ${`%"passport":{"user":{"id":"${userId}"}%`}
    `);
    
    return result.rowCount || 0;
  } catch (error) {
    console.error('Error invalidating user session:', error);
    // Fallback: return 0 (session may not exist or table structure may differ)
    return 0;
  }
}

/**
 * Regenerate session for current user
 * Creates new session ID and updates session data
 * 
 * @param req - Express request object
 * @returns Promise that resolves when session is regenerated
 */
export async function regenerateUserSession(req: Request): Promise<void> {
  return new Promise((resolve, reject) => {
    if (!req.session) {
      return reject(new Error('No session found'));
    }
    
    req.session.regenerate((err) => {
      if (err) {
        reject(err);
      } else {
        resolve();
      }
    });
  });
}

