import { mkdir, writeFile, readFile, access, chmod, stat, rename } from 'fs/promises';
import { join } from 'path';
import { existsSync } from 'fs';
import * as crypto from 'crypto';

// Base path for archives (configurable via env var)
const ARCHIVE_BASE_PATH = process.env.ARCHIVE_BASE_PATH || join(process.cwd(), 'data', 'archives', 'legacy-excel');
const INCOMING_PATH = join(ARCHIVE_BASE_PATH, 'incoming');

// Allowed file types for archives (Excel only)
export const ALLOWED_ARCHIVE_TYPES = {
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': '.xlsx',
  'application/vnd.ms-excel': '.xls',
};

export const MAX_ARCHIVE_FILE_SIZE = 100 * 1024 * 1024; // 100MB for legacy files

export interface ArchiveFileResult {
  filename: string;
  filepath: string;
  size: number;
  mimetype: string;
  year: number;
  category: string;
  description: string;
}

/**
 * Ensure archive directory structure exists
 */
export async function ensureArchiveDirectories(): Promise<void> {
  await mkdir(ARCHIVE_BASE_PATH, { recursive: true });
  await mkdir(INCOMING_PATH, { recursive: true });
}

/**
 * Get year directory path
 */
export function getYearDirectoryPath(year: number): string {
  return join(ARCHIVE_BASE_PATH, year.toString());
}

/**
 * Ensure year directory exists
 */
export async function ensureYearDirectory(year: number): Promise<string> {
  const yearPath = getYearDirectoryPath(year);
  await mkdir(yearPath, { recursive: true });
  return yearPath;
}

/**
 * Generate stored filename: [YYYY]_[Category]_[ShortDescription]_[OriginalFileName]_[v{N}].xlsx
 */
export function generateStoredFileName(
  year: number,
  category: string,
  description: string,
  originalFileName: string,
  version: number
): string {
  // Sanitize inputs
  const sanitizedCategory = category.replace(/[^a-zA-Z0-9\u0600-\u06FF\s-]/g, '').trim();
  const sanitizedDescription = description
    .replace(/[^a-zA-Z0-9\u0600-\u06FF\s-]/g, '')
    .trim()
    .substring(0, 50); // Limit description length
  const sanitizedOriginal = originalFileName.replace(/[^a-zA-Z0-9\u0600-\u06FF._-]/g, '').trim();
  
  // Get extension from original filename
  const ext = originalFileName.includes('.') 
    ? originalFileName.substring(originalFileName.lastIndexOf('.'))
    : '.xlsx';
  
  // Build filename
  const parts = [
    year.toString(),
    sanitizedCategory,
    sanitizedDescription,
    sanitizedOriginal.replace(ext, ''), // Remove extension from original
    `v${version}${ext}`
  ].filter(p => p.length > 0);
  
  return parts.join('_');
}

/**
 * Save file to incoming staging area
 */
export async function saveToIncoming(
  buffer: Buffer,
  originalFilename: string,
  mimetype: string
): Promise<{ filepath: string; filename: string; size: number }> {
  await ensureArchiveDirectories();
  
  // Validate file type
  if (!isValidArchiveFileType(mimetype, originalFilename)) {
    throw new Error(`نوع فایل مجاز نیست. فقط فایل‌های Excel مجاز هستند.`);
  }
  
  // Validate file size
  if (buffer.length > MAX_ARCHIVE_FILE_SIZE) {
    throw new Error(`حجم فایل بیش از حد مجاز است (حداکثر ${MAX_ARCHIVE_FILE_SIZE / 1024 / 1024}MB)`);
  }
  
  // Generate unique filename for staging
  const timestamp = Date.now();
  const randomSuffix = crypto.randomBytes(8).toString('hex');
  const ext = originalFilename.includes('.') 
    ? originalFilename.substring(originalFilename.lastIndexOf('.'))
    : '.xlsx';
  const stagingFilename = `${timestamp}_${randomSuffix}${ext}`;
  const stagingPath = join(INCOMING_PATH, stagingFilename);
  
  await writeFile(stagingPath, buffer);
  
  return {
    filepath: stagingPath,
    filename: stagingFilename,
    size: buffer.length,
  };
}

/**
 * Move file from incoming to final location and set read-only
 */
export async function finalizeArchiveFile(
  stagingPath: string,
  year: number,
  category: string,
  description: string,
  originalFileName: string,
  version: number
): Promise<{ filepath: string; filename: string; relativePath: string }> {
  // Ensure year directory exists
  const yearPath = await ensureYearDirectory(year);
  
  // Generate final filename
  const finalFilename = generateStoredFileName(year, category, description, originalFileName, version);
  const finalPath = join(yearPath, finalFilename);
  
  // Check if file already exists (shouldn't happen with versioning, but safety check)
  if (existsSync(finalPath)) {
    throw new Error(`فایل با این نام قبلاً وجود دارد: ${finalFilename}`);
  }
  
  // Move file from staging to final location
  await rename(stagingPath, finalPath);
  
  // Set read-only permissions (0444 = read-only for all)
  // Note: On Windows, chmod may not work as expected, but we try anyway
  try {
    await chmod(finalPath, 0o444);
  } catch (error) {
    // On Windows, chmod might fail, but that's okay - file is still moved
    console.warn(`Warning: Could not set read-only permissions on ${finalPath}:`, error);
  }
  
  // Calculate relative path from archive base
  const relativePath = join(year.toString(), finalFilename);
  
  return {
    filepath: finalPath,
    filename: finalFilename,
    relativePath,
  };
}

/**
 * Read archived file
 */
export async function readArchiveFile(relativePath: string): Promise<Buffer> {
  const fullPath = join(ARCHIVE_BASE_PATH, relativePath);
  
  try {
    await access(fullPath);
  } catch (error) {
    throw new Error('فایل بایگانی یافت نشد');
  }
  
  return await readFile(fullPath);
}

/**
 * Get file stats
 */
export async function getArchiveFileStats(relativePath: string): Promise<{ size: number; mtime: Date }> {
  const fullPath = join(ARCHIVE_BASE_PATH, relativePath);
  const stats = await stat(fullPath);
  return {
    size: stats.size,
    mtime: stats.mtime,
  };
}

/**
 * Validate archive file type
 */
export function isValidArchiveFileType(mimetype: string, filename?: string): boolean {
  // Check MIME type
  if (mimetype in ALLOWED_ARCHIVE_TYPES) {
    return true;
  }
  
  // Fallback: check file extension
  if (filename) {
    const ext = filename.toLowerCase();
    return ext.endsWith('.xlsx') || ext.endsWith('.xls');
  }
  
  return false;
}

/**
 * Calculate file checksum (MD5)
 */
export async function calculateFileChecksum(filepath: string): Promise<string> {
  const buffer = await readFile(filepath);
  return crypto.createHash('md5').update(buffer).digest('hex');
}

/**
 * Clean up staging file (if upload fails)
 */
export async function cleanupStagingFile(stagingPath: string): Promise<void> {
  try {
    const { unlink } = await import('fs/promises');
    await unlink(stagingPath);
  } catch (error) {
    // Ignore errors - file might not exist
    console.warn(`Warning: Could not cleanup staging file ${stagingPath}:`, error);
  }
}

