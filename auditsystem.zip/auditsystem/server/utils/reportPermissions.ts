import type { User } from '@shared/schema';

/**
 * Check if user can access a specific group's reports
 * Director: Can access all groups
 * Senior Auditor: Can only access their own group
 * Auditor: Cannot access group reports
 */
export async function canAccessGroupReport(
  user: User,
  groupId: string
): Promise<{ allowed: boolean; message?: string }> {
  // System admin can access all
  if (user.role === 'system_admin') {
    return { allowed: true };
  }

  // Director can access all groups
  if (user.role === 'director') {
    return { allowed: true };
  }

  // Check if user is coordinator (can access all)
  try {
    const { isCoordinator } = await import('../services/permissionService');
    const coordinatorCheck = await isCoordinator(user.id);
    if (coordinatorCheck) {
      return { allowed: true };
    }
  } catch (error) {
    // Fallback to role check if coordinator check fails
  }

  // Senior Auditor can only access their own group
  if (user.role === 'senior_auditor') {
    if (user.groupId === groupId) {
      return { allowed: true };
    }
    return {
      allowed: false,
      message: 'عدم دسترسی - شما فقط می‌توانید گزارش‌های گروه خود را مشاهده کنید',
    };
  }

  // Auditor cannot access group reports
  if (user.role === 'auditor') {
    return {
      allowed: false,
      message: 'عدم دسترسی - شما مجوز مشاهده گزارش‌های گروه را ندارید',
    };
  }

  // Default: no access
  return {
    allowed: false,
    message: 'عدم دسترسی - شما مجوز مشاهده این گزارش را ندارید',
  };
}

/**
 * Check if user can access ministry reports
 * Director: Can access all
 * Senior Auditor: Can only access their own group's data
 * Auditor: Cannot access
 */
export async function canAccessMinistryReport(
  user: User,
  groupId?: string
): Promise<{ allowed: boolean; message?: string }> {
  // System admin can access all
  if (user.role === 'system_admin') {
    return { allowed: true };
  }

  // Director can access all
  if (user.role === 'director') {
    return { allowed: true };
  }

  // Check if user is coordinator (can access all)
  try {
    const { isCoordinator } = await import('../services/permissionService');
    const coordinatorCheck = await isCoordinator(user.id);
    if (coordinatorCheck) {
      return { allowed: true };
    }
  } catch (error) {
    // Fallback to role check if coordinator check fails
  }

  // Senior Auditor can only access their own group's data
  if (user.role === 'senior_auditor') {
    if (!groupId || user.groupId === groupId) {
      return { allowed: true };
    }
    return {
      allowed: false,
      message: 'عدم دسترسی - شما فقط می‌توانید گزارش‌های گروه خود را مشاهده کنید',
    };
  }

  // Auditor cannot access ministry reports
  if (user.role === 'auditor') {
    return {
      allowed: false,
      message: 'عدم دسترسی - شما مجوز مشاهده گزارش‌های وزارتی را ندارید',
    };
  }

  // Default: no access
  return {
    allowed: false,
    message: 'عدم دسترسی - فقط مدیر و هماهنگ‌کننده می‌توانند این گزارش را مشاهده کنند',
  };
}

