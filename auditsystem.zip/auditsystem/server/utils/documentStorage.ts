import { mkdir, writeFile, readFile, access } from 'fs/promises';
import { join } from 'path';
import { randomBytes } from 'crypto';

const DOCVAULT_ROOT = join(process.cwd(), 'docvault');

// Allowed file types: PDF, Images, Word, Excel
export const ALLOWED_FILE_TYPES = {
  'application/pdf': '.pdf',
  'image/jpeg': '.jpg',
  'image/png': '.png',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document': '.docx',
  'application/msword': '.doc',
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': '.xlsx',
  'application/vnd.ms-excel': '.xls',
};

// Document types allowed in the system
export const ALLOWED_DOCUMENT_TYPES = [
  'مکتوب',      // Official Letter
  'استعلام',    // Inquiry
  'اسناد حمایوی' // Supporting Documents
];

export const MAX_FILE_SIZE = 25 * 1024 * 1024; // 25MB

export interface FileUploadResult {
  filename: string;
  filepath: string;
  size: number;
  mimetype: string;
}

function sanitizeCaseId(caseId: string): string {
  if (caseId.includes('/') || caseId.includes('\\') || caseId.includes('..')) {
    throw new Error('نمبر قضیه نامعتبر است');
  }
  return caseId;
}

export async function ensureCaseDirectory(caseId: string): Promise<string> {
  const sanitizedId = sanitizeCaseId(caseId);
  const casePath = join(DOCVAULT_ROOT, sanitizedId);
  await mkdir(casePath, { recursive: true });
  return casePath;
}

// Helper function to get file extension from filename
function getExtensionFromFilename(filename: string): string {
  const parts = filename.toLowerCase().split('.');
  if (parts.length < 2) return '';
  return '.' + parts[parts.length - 1];
}

// Helper function to normalize MIME type based on file extension
function normalizeMimeType(mimetype: string, filename: string): string {
  const ext = getExtensionFromFilename(filename);
  
  // If MIME type is already valid, use it
  if (mimetype in ALLOWED_FILE_TYPES) {
    return mimetype;
  }
  
  // Fallback: check file extension and map to correct MIME type
  const extensionMap: Record<string, string> = {
    '.pdf': 'application/pdf',
    '.jpg': 'image/jpeg',
    '.jpeg': 'image/jpeg',
    '.png': 'image/png',
    '.doc': 'application/msword',
    '.docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    '.xls': 'application/vnd.ms-excel',
    '.xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  };
  
  const normalizedMime = extensionMap[ext];
  if (normalizedMime && normalizedMime in ALLOWED_FILE_TYPES) {
    return normalizedMime;
  }
  
  // If still not found, return original (will fail validation)
  return mimetype;
}

export async function saveDocument(
  caseId: string,
  buffer: Buffer,
  originalFilename: string,
  mimetype: string
): Promise<FileUploadResult> {
  // Normalize MIME type (handles cases where browser sends wrong MIME type)
  const normalizedMimeType = normalizeMimeType(mimetype, originalFilename);
  
  // Get extension from normalized MIME type
  let extension = ALLOWED_FILE_TYPES[normalizedMimeType as keyof typeof ALLOWED_FILE_TYPES];
  
  // If still no extension, try to get it from filename
  if (!extension) {
    const fileExt = getExtensionFromFilename(originalFilename);
    const extensionMap: Record<string, string> = {
      '.pdf': '.pdf',
      '.jpg': '.jpg',
      '.jpeg': '.jpg',
      '.png': '.png',
      '.doc': '.doc',
      '.docx': '.docx',
      '.xls': '.xls',
      '.xlsx': '.xlsx',
    };
    extension = extensionMap[fileExt];
    
    // If we found extension from filename, normalize MIME type again
    if (extension) {
      const extToMimeMap: Record<string, string> = {
        '.pdf': 'application/pdf',
        '.jpg': 'image/jpeg',
        '.jpeg': 'image/jpeg',
        '.png': 'image/png',
        '.doc': 'application/msword',
        '.docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        '.xls': 'application/vnd.ms-excel',
        '.xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      };
      const finalMimeType = extToMimeMap[extension];
      if (finalMimeType && finalMimeType in ALLOWED_FILE_TYPES) {
        // Use the normalized values
        const casePath = await ensureCaseDirectory(caseId);
        const randomSuffix = randomBytes(8).toString('hex');
        const filename = `${Date.now()}_${randomSuffix}${extension}`;
        const filepath = join(casePath, filename);
        
        await writeFile(filepath, buffer);
        
        return {
          filename,
          filepath: join(caseId, filename),
          size: buffer.length,
          mimetype: finalMimeType,
        };
      }
    }
    
    throw new Error(`نوع فایل مجاز نیست. نوع دریافت شده: ${mimetype}, پسوند فایل: ${getExtensionFromFilename(originalFilename)}`);
  }

  if (buffer.length > MAX_FILE_SIZE) {
    throw new Error('حجم فایل بیش از حد مجاز است (حداکثر 25MB)');
  }

  const casePath = await ensureCaseDirectory(caseId);
  
  const randomSuffix = randomBytes(8).toString('hex');
  const filename = `${Date.now()}_${randomSuffix}${extension}`;
  const filepath = join(casePath, filename);

  await writeFile(filepath, buffer);

  return {
    filename,
    filepath: join(caseId, filename),
    size: buffer.length,
    mimetype: normalizedMimeType,
  };
}

export async function getDocument(filepath: string): Promise<Buffer> {
  const fullPath = join(DOCVAULT_ROOT, filepath);
  
  try {
    await access(fullPath);
  } catch (error) {
    throw new Error('فایل یافت نشد');
  }

  return await readFile(fullPath);
}

export function isValidFileType(mimetype: string, filename?: string): boolean {
  // Check MIME type first
  if (mimetype in ALLOWED_FILE_TYPES) {
    return true;
  }
  
  // Fallback: check file extension if filename provided
  if (filename) {
    const ext = getExtensionFromFilename(filename);
    const extensionMap: Record<string, string> = {
      '.pdf': 'application/pdf',
      '.jpg': 'image/jpeg',
      '.jpeg': 'image/jpeg',
      '.png': 'image/png',
      '.doc': 'application/msword',
      '.docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      '.xls': 'application/vnd.ms-excel',
      '.xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    };
    const normalizedMime = extensionMap[ext];
    return normalizedMime ? normalizedMime in ALLOWED_FILE_TYPES : false;
  }
  
  return false;
}

export function getFileExtension(mimetype: string): string {
  return ALLOWED_FILE_TYPES[mimetype as keyof typeof ALLOWED_FILE_TYPES] || '';
}

export function isValidDocumentType(docType: string): boolean {
  return ALLOWED_DOCUMENT_TYPES.includes(docType);
}
