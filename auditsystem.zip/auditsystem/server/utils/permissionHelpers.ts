// Unified Permission Helpers
// Centralized logic for determining data visibility based on effective permissions

import type { User } from '@shared/schema';
import { getEffectivePermissions, isCoordinator, type EffectivePermissions } from '../services/permissionService';

export interface DataVisibilityResult {
  canViewAll: boolean; // True if user can see all data (coordinator, director, admin)
  requiresFiltering: boolean; // True if data needs to be filtered
  filterByAssignee?: boolean; // Filter by assignedTo = user.id
  filterByGroup?: string; // Filter by groupId
  filterByEntityIds?: string[]; // Filter by specific entity IDs
}

/**
 * Determine data visibility for entities based on effective permissions
 */
export async function getEntityVisibility(user: User): Promise<DataVisibilityResult> {
  // System admin sees all
  if (user.role === 'system_admin') {
    return { canViewAll: true, requiresFiltering: false };
  }

  // Get effective permissions FIRST
  const effectivePermissions = await getEffectivePermissions(user.id);
  const coordinatorCheck = await isCoordinator(user.id);

  // DEBUG LOGGING: Log visibility decision (only in debug mode)
  if (process.env.DEBUG_LOGGING === 'true') {
    const permList = Object.entries(effectivePermissions)
      .filter(([_, has]) => has)
      .map(([perm]) => perm);
    console.log(`[ENTITY VISIBILITY] User: ${user.id} (${user.role}), Packages: ${JSON.stringify(user.permissionPackages || [])}, Coordinator: ${coordinatorCheck}, Effective Perms: ${permList.join(', ')}, entities:view: ${effectivePermissions['entities:view']}`);
  }

  // CRITICAL: Check coordinator status FIRST, before role-based checks
  // Coordinator sees all entities regardless of base role
  if (coordinatorCheck) {
    if (process.env.DEBUG_LOGGING === 'true') {
      console.log(`[ENTITY VISIBILITY] Coordinator detected - granting full access`);
    }
    return { canViewAll: true, requiresFiltering: false };
  }

  // Check if user has entities:view permission
  if (!effectivePermissions['entities:view']) {
    return { canViewAll: false, requiresFiltering: true };
  }

  // Director or users with groups:set_targets see all
  if (user.role === 'director' || effectivePermissions['groups:set_targets']) {
    return { canViewAll: true, requiresFiltering: false };
  }

  // Senior auditor sees their group's entities
  if (user.role === 'senior_auditor' && user.groupId) {
    return { 
      canViewAll: false, 
      requiresFiltering: true, 
      filterByGroup: user.groupId 
    };
  }

  // Auditor sees only entities linked to their assigned cases
  if (user.role === 'auditor') {
    return { 
      canViewAll: false, 
      requiresFiltering: true, 
      filterByAssignee: true 
    };
  }

  // Default: no access
  return { canViewAll: false, requiresFiltering: true };
}

/**
 * Determine data visibility for cases based on effective permissions
 */
export async function getCaseVisibility(user: User): Promise<DataVisibilityResult> {
  // System admin sees all
  if (user.role === 'system_admin') {
    return { canViewAll: true, requiresFiltering: false };
  }

  // Get effective permissions FIRST
  const effectivePermissions = await getEffectivePermissions(user.id);
  const coordinatorCheck = await isCoordinator(user.id);

  // DEBUG LOGGING: Log visibility decision (only in debug mode)
  if (process.env.DEBUG_LOGGING === 'true') {
    const permList = Object.entries(effectivePermissions)
      .filter(([_, has]) => has)
      .map(([perm]) => perm);
    console.log(`[CASE VISIBILITY] User: ${user.id} (${user.role}), Packages: ${JSON.stringify(user.permissionPackages || [])}, Coordinator: ${coordinatorCheck}, Effective Perms: ${permList.join(', ')}, cases:view: ${effectivePermissions['cases:view']}`);
  }

  // CRITICAL: Check coordinator status FIRST, before role-based checks
  // Coordinator sees all cases regardless of base role
  if (coordinatorCheck) {
    if (process.env.DEBUG_LOGGING === 'true') {
      console.log(`[CASE VISIBILITY] Coordinator detected - granting full access`);
    }
    return { canViewAll: true, requiresFiltering: false };
  }

  // Check if user has cases:view permission
  if (!effectivePermissions['cases:view']) {
    return { canViewAll: false, requiresFiltering: true };
  }

  // Director or users with groups:set_targets see all
  if (user.role === 'director' || effectivePermissions['groups:set_targets']) {
    return { canViewAll: true, requiresFiltering: false };
  }

  // Senior auditor sees their group's cases
  if (user.role === 'senior_auditor' && user.groupId) {
    return { 
      canViewAll: false, 
      requiresFiltering: true, 
      filterByGroup: user.groupId 
    };
  }

  // Auditor sees only cases assigned to them
  if (user.role === 'auditor') {
    return { 
      canViewAll: false, 
      requiresFiltering: true, 
      filterByAssignee: true 
    };
  }

  // Default: no access
  return { canViewAll: false, requiresFiltering: true };
}

/**
 * Determine data visibility for groups based on effective permissions
 */
export async function getGroupVisibility(user: User): Promise<DataVisibilityResult> {
  // System admin sees all
  if (user.role === 'system_admin') {
    return { canViewAll: true, requiresFiltering: false };
  }

  // Get effective permissions FIRST
  const effectivePermissions = await getEffectivePermissions(user.id);
  const coordinatorCheck = await isCoordinator(user.id);

  // CRITICAL: Check coordinator status FIRST, before role-based checks
  // Coordinator sees all groups regardless of base role
  if (coordinatorCheck) {
    return { canViewAll: true, requiresFiltering: false };
  }

  // Users with groups:manage see all groups
  if (effectivePermissions['groups:manage']) {
    return { canViewAll: true, requiresFiltering: false };
  }

  // Senior auditor sees only their own group
  if (user.role === 'senior_auditor' && user.groupId) {
    return { 
      canViewAll: false, 
      requiresFiltering: true, 
      filterByGroup: user.groupId 
    };
  }

  // Default: no access
  return { canViewAll: false, requiresFiltering: true };
}

/**
 * Determine data visibility for tickets based on effective permissions
 */
export async function getTicketVisibility(user: User): Promise<DataVisibilityResult> {
  // System admin sees all
  if (user.role === 'system_admin') {
    return { canViewAll: true, requiresFiltering: false };
  }

  // Get effective permissions FIRST
  const effectivePermissions = await getEffectivePermissions(user.id);
  const coordinatorCheck = await isCoordinator(user.id);

  // CRITICAL: Check coordinator status FIRST, before role-based checks
  // Coordinator sees all tickets regardless of base role
  if (coordinatorCheck) {
    return { canViewAll: true, requiresFiltering: false };
  }

  // Users with tickets:approve see all tickets
  if (effectivePermissions['tickets:approve']) {
    return { canViewAll: true, requiresFiltering: false };
  }

  // Users with tickets:submit see only their own tickets
  if (effectivePermissions['tickets:submit']) {
    return { 
      canViewAll: false, 
      requiresFiltering: true, 
      filterByAssignee: true 
    };
  }

  // Default: no access
  return { canViewAll: false, requiresFiltering: true };
}

