import session from 'express-session';
import connectPgSimple from 'connect-pg-simple';
import { pool } from '../db';

const PgSession = connectPgSimple(session);

export const sessionStore = new PgSession({
  pool: pool,
  tableName: 'session',
  createTableIfMissing: true,
});

// Session duration: 8-12 hours (default: 10 hours = 36000000ms)
const SESSION_MAX_AGE = parseInt(process.env.SESSION_MAX_AGE || '36000000', 10); // 10 hours default

export const sessionConfig: session.SessionOptions = {
  store: sessionStore,
  secret: process.env.SESSION_SECRET || 'audit-system-secret-change-in-production',
  resave: false,
  saveUninitialized: false,
  cookie: {
    secure: process.env.NODE_ENV === 'production',
    httpOnly: true, // CRITICAL: Prevents XSS attacks
    maxAge: SESSION_MAX_AGE, // 8-12 hours (configurable via SESSION_MAX_AGE env var)
    sameSite: 'lax', // Allows cookies in cross-site requests
    // Ensure cookie persists across browser restarts
    path: '/',
    // CRITICAL: Don't expire on browser close - session should persist
    expires: undefined, // Let maxAge handle expiration
  },
  name: 'audit.sid', // Keep consistent name
  // Rolling: true would extend session on each request, but we want explicit control
  rolling: false,
};
