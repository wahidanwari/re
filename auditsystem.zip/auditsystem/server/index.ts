// Load environment variables from .env file FIRST, before any other imports
import "dotenv/config";

// CRITICAL: Set timezone to Afghanistan (Asia/Kabul) for consistent event logging
// This ensures all timestamps are created with the correct timezone context
if (!process.env.TZ) {
  process.env.TZ = 'Asia/Kabul';
}

import express, { type Request, Response, NextFunction } from "express";
import session from "express-session";
import passport from "./auth/passport";
import { registerRoutes } from "./routes";
import { setupVite, serveStatic, log } from "./vite";
import { sessionConfig } from "./config/session";
import { sessionTimeout } from "./middleware/session";
import { apiRateLimit } from "./middleware/rateLimit";

// Helper function to sanitize log data (remove sensitive information)
function sanitizeLogData(data: any): any {
  if (!data || typeof data !== 'object') {
    return data;
  }
  
  if (Array.isArray(data)) {
    return data.map(item => sanitizeLogData(item));
  }
  
  const sanitized: any = {};
  const sensitiveKeys = ['password', 'token', 'secret', 'auth', 'session', 'cookie', 'userId', 'id'];
  
  for (const [key, value] of Object.entries(data)) {
    const lowerKey = key.toLowerCase();
    if (sensitiveKeys.some(sk => lowerKey.includes(sk))) {
      sanitized[key] = '[REDACTED]';
    } else if (typeof value === 'object' && value !== null) {
      sanitized[key] = sanitizeLogData(value);
    } else {
      sanitized[key] = value;
    }
  }
  
  return sanitized;
}

// Port configuration constants
// Server port - default 3000, can be overridden with PORT or SERVER_PORT env var
const SERVER_PORT = parseInt(process.env.PORT || process.env.SERVER_PORT || "3000", 10);
// Client port - default 5174, used for CORS configuration in standalone mode
const CLIENT_PORT = parseInt(process.env.VITE_PORT || process.env.CLIENT_PORT || "5174", 10);
const SERVER_HOST = process.env.HOST || "127.0.0.1";

// Handle uncaught exceptions and unhandled promise rejections
process.on('uncaughtException', (error: Error) => {
  log(`Uncaught Exception: ${error.message}`, 'system', 'error');
  if (process.env.DEBUG_LOGGING === 'true' && error.stack) {
    console.error(error.stack);
  }
  process.exit(1);
});

process.on('unhandledRejection', (reason: any, promise: Promise<any>) => {
  const reasonMsg = reason instanceof Error ? reason.message : String(reason);
  log(`Unhandled Rejection: ${reasonMsg}`, 'system', 'error');
  if (process.env.DEBUG_LOGGING === 'true') {
    console.error('Promise:', promise);
    if (reason instanceof Error && reason.stack) {
      console.error(reason.stack);
    }
  }
  process.exit(1);
});

const app = express();

declare module 'http' {
  interface IncomingMessage {
    rawBody: unknown
  }
}
// Enable CORS when running in standalone mode (client on different port)
const isStandaloneMode = process.env.VITE_MODE === "standalone";
if (isStandaloneMode) {
  app.use((req, res, next) => {
    const origin = req.headers.origin;
    // Allow requests from Vite dev server (client port)
    const allowedOrigins = [
      `http://localhost:${CLIENT_PORT}`,
      `http://127.0.0.1:${CLIENT_PORT}`,
      ...(SERVER_HOST !== "127.0.0.1" && SERVER_HOST !== "localhost" 
        ? [`http://${SERVER_HOST}:${CLIENT_PORT}`] 
        : []),
    ];
    
    if (origin && allowedOrigins.includes(origin)) {
      res.setHeader("Access-Control-Allow-Origin", origin);
    }
    res.setHeader("Access-Control-Allow-Credentials", "true");
    res.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, PATCH, OPTIONS");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");
    
    if (req.method === "OPTIONS") {
      return res.sendStatus(200);
    }
    next();
  });
}

// Trust proxy for accurate IP extraction (needed for X-Forwarded-For, req.ip)
// This allows Express to correctly extract client IPs from reverse proxies/load balancers
app.set('trust proxy', true);

app.use(express.json({
  verify: (req, _res, buf) => {
    req.rawBody = buf;
  },
  limit: '10mb', // Limit request body size
}));
app.use(express.urlencoded({ extended: false, limit: '10mb' }));
app.use(session(sessionConfig));
app.use(passport.initialize());
app.use(passport.session());

// Apply session timeout middleware to all routes (checks inactivity)
// This must be after session and passport middleware
app.use(sessionTimeout());

// Apply user data refresh middleware to all authenticated routes
// This ensures we always have the latest permissions, role, and packages
import { refreshUserData } from './middleware/auth';
app.use('/api', refreshUserData);

// Apply API burst detection to all API routes (except auth routes which have their own rate limiting)
// This detects >50 requests in <5 seconds and adds a short delay
app.use('/api', (req, res, next) => {
  // Skip burst detection for auth routes (they have progressive delay rate limiting)
  if (req.path.startsWith('/api/auth')) {
    return next();
  }
  return apiRateLimit()(req, res, next);
});

app.use((req, res, next) => {
  const start = Date.now();
  const path = req.path;
  let capturedJsonResponse: Record<string, any> | undefined = undefined;

  const originalResJson = res.json;
  res.json = function (bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };

  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path.startsWith("/api")) {
      // Only log errors or if DEBUG mode is enabled
      const isError = res.statusCode >= 400;
      const isDebugMode = process.env.DEBUG_LOGGING === 'true';
      
      // Skip logging for frequent health-check endpoints (unless error or debug mode)
      const skipPaths = ['/api/auth/me', '/api/session/heartbeat', '/api/auth/effective-permissions'];
      const shouldSkip = !isError && !isDebugMode && skipPaths.includes(path);
      
      if (shouldSkip) {
        return; // Don't log routine checks
      }
      
      let logLine = `${req.method} ${path} ${res.statusCode} in ${duration}ms`;
      
      // Only include response data for errors or in debug mode, and sanitize sensitive data
      if (capturedJsonResponse && (isError || isDebugMode)) {
        // Sanitize response to remove sensitive data
        const sanitized = sanitizeLogData(capturedJsonResponse);
        const responseStr = JSON.stringify(sanitized);
        // Limit response logging to 200 chars to avoid huge logs
        if (responseStr.length > 200) {
          logLine += ` :: ${responseStr.slice(0, 199)}…`;
        } else {
          logLine += ` :: ${responseStr}`;
        }
      }

      // Use appropriate log level with better formatting
      if (isError) {
        // Determine error type for better categorization
        let errorType = 'error';
        if (res.statusCode >= 500) {
          errorType = 'error';
        } else if (res.statusCode === 403) {
          errorType = 'warn'; // Permission errors are warnings, not critical errors
        } else if (res.statusCode === 401) {
          errorType = 'warn'; // Auth errors are warnings
        }
        log(logLine, 'express', errorType as 'info' | 'error' | 'warn');
      } else {
        log(logLine, 'express', 'info');
      }
    }
  });

  next();
});

(async () => {
  try {
    const server = await registerRoutes(app);

    // Port and host are configured at the top of the file as constants
    // SERVER_PORT: default 3000 (configurable via PORT or SERVER_PORT env var)
    // SERVER_HOST: default 127.0.0.1 (configurable via HOST env var)
    const port = SERVER_PORT;
    const host = SERVER_HOST;

    // Add error handlers for the HTTP server IMMEDIATELY after creation
    // This ensures we catch errors early, including those from WebSocket setup
    server.on('error', (error: NodeJS.ErrnoException) => {
      if (error.code === 'EADDRINUSE') {
        log(`Port ${port} is already in use. Please stop the other process or use a different port.`, 'server', 'error');
        process.exit(1);
      } else if (error.code === 'ENOTSUP') {
        log(`Operation not supported on socket ${host}:${port}. This may be a Windows compatibility issue.`, 'server', 'error');
        log(`Error details: ${error.message}`, 'server', 'error');
        log(`Try setting HOST=127.0.0.1 in your .env file if you encounter this error.`, 'server', 'warn');
        process.exit(1);
      } else if (error.code === 'EADDRNOTAVAIL') {
        log(`Address ${host}:${port} is not available. The address may be invalid or not configured on this system.`, 'server', 'error');
        log(`Error details: ${error.message}`, 'server', 'error');
        log(`Try setting HOST=127.0.0.1 or HOST=localhost in your .env file.`, 'server', 'warn');
        process.exit(1);
      } else {
        log(`Server error: ${error.message}`, 'error');
        process.exit(1);
      }
    });

    app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
      const status = err.status || err.statusCode || 500;
      const message = err.message || "Internal Server Error";

      // Log error with appropriate level
      const logLevel = status >= 500 ? 'error' : status >= 400 ? 'warn' : 'info';
      log(`Request error: ${message} (${status})`, 'express', logLevel as 'info' | 'error' | 'warn');
      
      if (process.env.DEBUG_LOGGING === 'true' && err.stack) {
        console.error(err.stack);
      }

      res.status(status).json({ message });
      // Don't throw - error is already handled
    });

    // Setup Vite middleware only if running in integrated mode (not standalone)
    // In standalone mode, client runs separately and proxies API requests
    
    if (app.get("env") === "development" && !isStandaloneMode) {
      await setupVite(app, server);
    } else if (app.get("env") === "production") {
      serveStatic(app);
    } else if (isStandaloneMode) {
      // Standalone server mode - only serve API, no client serving
      app.use((req, res, next) => {
        if (!req.path.startsWith("/api") && !req.path.startsWith("/ws")) {
          res.status(404).json({ 
            message: "Not found. This is the API server only. Client should be running separately.",
            path: req.path
          });
        } else {
          next();
        }
      });
    }

    // Use standard listen syntax for cross-platform compatibility
    // reusePort is not supported on Windows, so we use the standard method
    server.listen(port, host, () => {
      const mode = isStandaloneMode 
        ? "API server (standalone)" 
        : app.get("env") === "development" 
          ? "API + Client (integrated)" 
          : "Production";
      
      log(`${mode} serving on ${host}:${port}`, 'server', 'info');
      if (isStandaloneMode) {
        log(`Client should be running separately on port ${CLIENT_PORT}`, 'server', 'info');
        log(`CORS is enabled for client origin: http://localhost:${CLIENT_PORT}`, 'server', 'info');
      }
    });
  } catch (error) {
    log(`Failed to start server: ${error instanceof Error ? error.message : String(error)}`, 'error');
    process.exit(1);
  }
})();
