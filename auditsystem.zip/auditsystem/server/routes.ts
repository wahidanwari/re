import type { Express } from "express";
import { createServer, type Server } from "http";
import authRoutes from "./routes/auth";
import usersRoutes from "./routes/users";
import groupsRoutes from "./routes/groups";
import entitiesRoutes from "./routes/entities";
import casesRoutes from "./routes/cases";
import documentsRoutes from "./routes/documents";
import ticketsRoutes from "./routes/tickets";
import notificationsRoutes from "./routes/notifications";
import dashboardRoutes from "./routes/dashboard";
import settingsRoutes from "./routes/settings";
import reportsRoutes from "./routes/reports";
import auditLogsRoutes from "./routes/audit-logs";
import entityTypesRoutes from "./routes/entity-types";
import sessionRoutes from "./routes/session";
import healthRoutes from "./routes/health";
import backupRoutes from "./routes/backup";
import workflowRoutes from "./routes/workflow";
import auditRecordsRoutes from "./routes/auditRecords";
import committeesRoutes from "./routes/committees";
import committeesNewRoutes from "./routes/committeesNew";
import committeeReportsRoutes from "./routes/committeeReports";
import archivesRoutes from "./routes/archives";
import monthlyReportsRoutes from "./routes/monthlyReports";
import { initializeWebSocket } from "./websocket";
import { sessionStore } from "./config/session";

export async function registerRoutes(app: Express): Promise<Server> {
  // Health check endpoints (public, no auth required)
  app.use("/api/health", healthRoutes);
  
  // Authentication API (public routes)
  app.use("/api/auth", authRoutes);
  
  // Session management (protected routes)
  app.use("/api/session", sessionRoutes);
  
  // Protected API routes
  app.use("/api/users", usersRoutes);
  app.use("/api/groups", groupsRoutes);
  app.use("/api/entities", entitiesRoutes);
  app.use("/api/cases", casesRoutes);
  app.use("/api/documents", documentsRoutes);
  app.use("/api/tickets", ticketsRoutes);
  app.use("/api/notifications", notificationsRoutes);
  app.use("/api/dashboard", dashboardRoutes);
  app.use("/api/settings", settingsRoutes);
  app.use("/api/reports", reportsRoutes);
  app.use("/api/audit-logs", auditLogsRoutes);
  app.use("/api/entity-types", entityTypesRoutes);
  app.use("/api/backup", backupRoutes);
  app.use("/api/workflow", workflowRoutes);
  app.use("/api/audit-records", auditRecordsRoutes);
    app.use("/api/committees", committeesRoutes); // OLD - disabled
    app.use("/api/committees-new", committeesNewRoutes); // NEW - active
    app.use("/api/committee-reports", committeeReportsRoutes); // Committee reporting
    app.use("/api/archives", archivesRoutes);
  app.use("/api/reports/monthly", monthlyReportsRoutes);

  const httpServer = createServer(app);
  
  initializeWebSocket(httpServer, sessionStore);

  return httpServer;
}
