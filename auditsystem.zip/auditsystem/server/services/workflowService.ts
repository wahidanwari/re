/**
 * Workflow Service
 * Handles population and updates of workflow tables:
 * - MonthlyTransactions: Per-entity monthly transaction data
 * - InternalReport: Aggregated per-entity monthly reports
 * - MinistrySummary: Aggregated per-group monthly summaries
 */

import { storage } from '../storage';
import { db } from '../db';
import { 
  monthlyTransactions, 
  internalReport, 
  ministrySummary,
  workflowAlerts,
  workflowConfig,
  entities,
  groups,
  groupTargets,
  type MonthlyTransaction,
  type InsertMonthlyTransaction,
  type InternalReport,
  type InsertInternalReport,
  type MinistrySummary,
  type InsertMinistrySummary,
  type WorkflowAlert,
  type InsertWorkflowAlert,
  type WorkflowConfig,
  type InsertWorkflowConfig
} from '@shared/schema';
import { eq, and, sql, inArray } from 'drizzle-orm';

/**
 * Populate MonthlyTransactions from entities for a specific month/year
 * This creates transaction records for all entities in the master table
 */
export async function populateMonthlyTransactions(
  monthShamsi: number,
  yearShamsi: number
): Promise<{ created: number; updated: number }> {
  console.log(`[Workflow] Populating MonthlyTransactions for ${monthShamsi}/${yearShamsi}`);
  
  // Get all entities from master table
  const allEntities = await storage.getEntities();
  console.log(`[Workflow] Found ${allEntities.length} entities in master table`);
  
  let created = 0;
  let updated = 0;
  
  for (const entity of allEntities) {
    // Check if transaction record already exists
    const existing = await db
      .select()
      .from(monthlyTransactions)
      .where(
        and(
          eq(monthlyTransactions.entityTin, entity.tin),
          eq(monthlyTransactions.monthShamsi, monthShamsi),
          eq(monthlyTransactions.yearShamsi, yearShamsi)
        )
      )
      .limit(1);
    
    const transactionData: InsertMonthlyTransaction = {
      entityTin: entity.tin,
      monthShamsi,
      yearShamsi,
      // Initialize all fields to 0/null - will be updated when actual transaction data is entered
      taxSalary: '0',
      taxRent: '0',
      taxContract: '0',
      taxProfit: '0',
      incomeTax: '0',
      lossReduction: '0',
      collectedAmount: '0',
      remainingAmount: '0',
      stabilizedAmount: '0',
      correspondencesIn: 0,
      correspondencesOut: 0,
      inquiriesIn: 0,
      inquiriesOut: 0,
      notes: null,
    };
    
    if (existing.length > 0) {
      // Update existing record
      await db
        .update(monthlyTransactions)
        .set({
          ...transactionData,
          updatedAt: sql`NOW()`,
        })
        .where(eq(monthlyTransactions.id, existing[0].id));
      updated++;
    } else {
      // Create new record
      await db.insert(monthlyTransactions).values(transactionData);
      created++;
    }
  }
  
  console.log(`[Workflow] MonthlyTransactions: Created ${created}, Updated ${updated}`);
  return { created, updated };
}

/**
 * Update a specific MonthlyTransaction record
 */
export async function updateMonthlyTransaction(
  entityTin: string,
  monthShamsi: number,
  yearShamsi: number,
  data: Partial<InsertMonthlyTransaction>
): Promise<MonthlyTransaction | null> {
  const existing = await db
    .select()
    .from(monthlyTransactions)
    .where(
      and(
        eq(monthlyTransactions.entityTin, entityTin),
        eq(monthlyTransactions.monthShamsi, monthShamsi),
        eq(monthlyTransactions.yearShamsi, yearShamsi)
      )
    )
    .limit(1);
  
  if (existing.length === 0) {
    // Create new record if it doesn't exist
    const newRecord: InsertMonthlyTransaction = {
      entityTin,
      monthShamsi,
      yearShamsi,
      taxSalary: '0',
      taxRent: '0',
      taxContract: '0',
      taxProfit: '0',
      incomeTax: '0',
      lossReduction: '0',
      collectedAmount: '0',
      remainingAmount: '0',
      stabilizedAmount: '0',
      correspondencesIn: 0,
      correspondencesOut: 0,
      inquiriesIn: 0,
      inquiriesOut: 0,
      notes: null,
      ...data,
    };
    
    const [result] = await db.insert(monthlyTransactions).values(newRecord).returning();
    return result;
  }
  
  // Update existing record
  const [result] = await db
    .update(monthlyTransactions)
    .set({
      ...data,
      updatedAt: sql`NOW()`,
    })
    .where(eq(monthlyTransactions.id, existing[0].id))
    .returning();
  
  return result || null;
}

/**
 * Calculate and populate InternalReport from MonthlyTransactions for a specific month/year
 */
export async function populateInternalReport(
  monthShamsi: number,
  yearShamsi: number
): Promise<{ created: number; updated: number }> {
  console.log(`[Workflow] Populating InternalReport for ${monthShamsi}/${yearShamsi}`);
  
  // Get all monthly transactions for this month/year
  const transactions = await db
    .select()
    .from(monthlyTransactions)
    .where(
      and(
        eq(monthlyTransactions.monthShamsi, monthShamsi),
        eq(monthlyTransactions.yearShamsi, yearShamsi)
      )
    );
  
  console.log(`[Workflow] Found ${transactions.length} monthly transactions`);
  
  if (transactions.length === 0) {
    console.log(`[Workflow] No transactions found, skipping InternalReport population`);
    return { created: 0, updated: 0 };
  }
  
  let created = 0;
  let updated = 0;
  
  for (const transaction of transactions) {
    // Get entity from master table to get entity name
    const entity = await storage.getEntityByTin(transaction.entityTin);
    if (!entity) {
      console.warn(`[Workflow] Entity not found for TIN: ${transaction.entityTin}`);
      continue;
    }
    
    // Calculate TotalTaxableAmount
    const totalTaxableAmount = (
      parseFloat(transaction.taxSalary || '0') +
      parseFloat(transaction.taxRent || '0') +
      parseFloat(transaction.taxContract || '0') +
      parseFloat(transaction.taxProfit || '0') +
      parseFloat(transaction.incomeTax || '0')
    ).toFixed(2);
    
    // Calculate RemainingAmount
    const collectedAmount = parseFloat(transaction.collectedAmount || '0');
    const remainingAmount = (parseFloat(totalTaxableAmount) - collectedAmount).toFixed(2);
    
    // Check if report already exists
    const existing = await db
      .select()
      .from(internalReport)
      .where(
        and(
          eq(internalReport.entityTin, transaction.entityTin),
          eq(internalReport.monthShamsi, monthShamsi),
          eq(internalReport.yearShamsi, yearShamsi)
        )
      )
      .limit(1);
    
    const reportData: InsertInternalReport = {
      entityTin: transaction.entityTin,
      entityName: entity.companyName,
      monthShamsi,
      yearShamsi,
      totalTaxableAmount: totalTaxableAmount,
      collectedAmount: transaction.collectedAmount,
      remainingAmount: remainingAmount,
      stabilizedAmount: transaction.stabilizedAmount,
      taxSalary: transaction.taxSalary,
      taxRent: transaction.taxRent,
      taxContract: transaction.taxContract,
      taxProfit: transaction.taxProfit,
      incomeTax: transaction.incomeTax,
      lossReduction: transaction.lossReduction,
      correspondencesIn: transaction.correspondencesIn,
      correspondencesOut: transaction.correspondencesOut,
      inquiriesIn: transaction.inquiriesIn,
      inquiriesOut: transaction.inquiriesOut,
      status: 'active',
      notes: transaction.notes,
    };
    
    if (existing.length > 0) {
      // Update existing report
      await db
        .update(internalReport)
        .set({
          ...reportData,
          updatedAt: sql`NOW()`,
        })
        .where(eq(internalReport.id, existing[0].id));
      updated++;
    } else {
      // Create new report
      await db.insert(internalReport).values(reportData);
      created++;
    }
  }
  
  console.log(`[Workflow] InternalReport: Created ${created}, Updated ${updated}`);
  
  // Automatically update MinistrySummary when InternalReport changes
  if (created > 0 || updated > 0) {
    console.log(`[Workflow] Triggering MinistrySummary update after InternalReport changes`);
    await populateMinistrySummary(monthShamsi, yearShamsi);
    
    // Automatically generate alerts after updating reports and summaries
    // Note: generateAlerts will be called later - for now we'll skip to avoid circular dependency
    // Alerts will be generated when executeAutomatedWorkflow is called
    console.log(`[Workflow] Alert generation will be handled by automated workflow`);
  }
  
  return { created, updated };
}

/**
 * Calculate and populate MinistrySummary from InternalReport for a specific month/year
 */
export async function populateMinistrySummary(
  monthShamsi: number,
  yearShamsi: number
): Promise<{ created: number; updated: number }> {
  console.log(`[Workflow] Populating MinistrySummary for ${monthShamsi}/${yearShamsi}`);
  
  // Get all internal reports for this month/year
  const reports = await db
    .select()
    .from(internalReport)
    .where(
      and(
        eq(internalReport.monthShamsi, monthShamsi),
        eq(internalReport.yearShamsi, yearShamsi),
        eq(internalReport.status, 'active')
      )
    );
  
  console.log(`[Workflow] Found ${reports.length} active internal reports`);
  
  if (reports.length === 0) {
    console.log(`[Workflow] No reports found, skipping MinistrySummary population`);
    return { created: 0, updated: 0 };
  }
  
  // Group reports by referral group
  const groupMap = new Map<string, {
    groupId: string | null;
    groupName: string;
    groupCode: string | null;
    reports: typeof reports;
  }>();
  
  for (const report of reports) {
    // Get entity to find referral group
    const entity = await storage.getEntityByTin(report.entityTin);
    if (!entity || !entity.referralGroup) {
      console.warn(`[Workflow] Entity not found or no referral group for TIN: ${report.entityTin}`);
      continue;
    }
    
    // Try to get group by ID or name
    let groupId: string | null = null;
    let groupName = entity.referralGroup;
    let groupCode: string | null = null;
    
    // Check if referralGroup is a group ID
    const groupById = await storage.getGroup(entity.referralGroup);
    if (groupById) {
      groupId = groupById.id;
      groupName = groupById.name;
      groupCode = groupById.code || null;
    } else {
      // Check if it's a group name
      const groupByName = await storage.getGroupByName(entity.referralGroup);
      if (groupByName) {
        groupId = groupByName.id;
        groupName = groupByName.name;
        groupCode = groupByName.code || null;
      }
      // Otherwise, it's a static group name (no group in DB)
    }
    
    const key = groupName;
    if (!groupMap.has(key)) {
      groupMap.set(key, {
        groupId,
        groupName,
        groupCode,
        reports: [],
      });
    }
    groupMap.get(key)!.reports.push(report);
  }
  
  console.log(`[Workflow] Grouped into ${groupMap.size} groups`);
  
  let created = 0;
  let updated = 0;
  
  for (const [groupName, groupData] of Array.from(groupMap.entries())) {
    const groupReports = groupData.reports;
    
    // Calculate entity counts
    const totalEntities = groupReports.length;
    
    // Count entities by compliance status
    let finalizedEntities = 0;
    let partiallyCompliantEntities = 0;
    let nonCompliantEntities = 0;
    
    for (const report of groupReports) {
      const remainingAmount = parseFloat(report.remainingAmount || '0');
      const totalTaxableAmount = parseFloat(report.totalTaxableAmount || '0');
      
      if (remainingAmount === 0) {
        finalizedEntities++;
      } else if (remainingAmount > 0 && remainingAmount < totalTaxableAmount) {
        partiallyCompliantEntities++;
      } else if (remainingAmount === totalTaxableAmount) {
        nonCompliantEntities++;
      }
    }
    
    // Calculate revenue collected (sum of CollectedAmount)
    const revenueCollected = groupReports.reduce((sum: number, r: typeof groupReports[0]) => 
      sum + parseFloat(r.collectedAmount || '0'), 0
    ).toFixed(2);
    
    // Get monthly revenue target from group_targets
    let monthlyRevenueTarget: number | null = null;
    if (groupData.groupId) {
      const yearTarget = await db
        .select()
        .from(groupTargets)
        .where(
          and(
            eq(groupTargets.groupId, groupData.groupId),
            eq(groupTargets.yearShamsi, yearShamsi.toString())
          )
        )
        .limit(1);
      
      if (yearTarget.length > 0 && yearTarget[0].targetMonetary) {
        // Parse targetMonetary (might be a string like "1000000" or "1,000,000")
        const targetValue = parseFloat(yearTarget[0].targetMonetary.replace(/,/g, '')) || 0;
        monthlyRevenueTarget = Math.round(targetValue / 12); // Divide yearly target by 12
      }
    }
    
    // Calculate percent variation
    const percentVariation = monthlyRevenueTarget && monthlyRevenueTarget > 0
      ? ((parseFloat(revenueCollected) / monthlyRevenueTarget) * 100).toFixed(2)
      : null;
    
    // Aggregate correspondence and inquiry data
    const incomingLetters = groupReports.reduce((sum: number, r: typeof groupReports[0]) => 
      sum + (r.correspondencesIn || 0), 0
    );
    const outgoingLetters = groupReports.reduce((sum: number, r: typeof groupReports[0]) => 
      sum + (r.correspondencesOut || 0), 0
    );
    const incomingInquiries = groupReports.reduce((sum: number, r: typeof groupReports[0]) => 
      sum + (r.inquiriesIn || 0), 0
    );
    const outgoingInquiries = groupReports.reduce((sum: number, r: typeof groupReports[0]) => 
      sum + (r.inquiriesOut || 0), 0
    );
    
    // Check if summary already exists
    const existing = await db
      .select()
      .from(ministrySummary)
      .where(
        and(
          eq(ministrySummary.groupName, groupName),
          eq(ministrySummary.monthShamsi, monthShamsi),
          eq(ministrySummary.yearShamsi, yearShamsi)
        )
      )
      .limit(1);
    
    const summaryData: InsertMinistrySummary = {
      groupId: groupData.groupId,
      groupName: groupData.groupName,
      groupCode: groupData.groupCode,
      monthShamsi,
      yearShamsi,
      totalEntities,
      finalizedEntities,
      partiallyCompliantEntities,
      nonCompliantEntities,
      revenueCollected: revenueCollected,
      monthlyRevenueTarget: monthlyRevenueTarget ? monthlyRevenueTarget.toFixed(2) : null,
      percentVariation: percentVariation,
      incomingLetters,
      outgoingLetters,
      incomingInquiries,
      outgoingInquiries,
      status: 'active',
      notes: null,
    };
    
    if (existing.length > 0) {
      // Update existing summary
      await db
        .update(ministrySummary)
        .set({
          ...summaryData,
          updatedAt: sql`NOW()`,
        })
        .where(eq(ministrySummary.id, existing[0].id));
      updated++;
    } else {
      // Create new summary
      await db.insert(ministrySummary).values(summaryData);
      created++;
    }
  }
  
  console.log(`[Workflow] MinistrySummary: Created ${created}, Updated ${updated}`);
  return { created, updated };
}

/**
 * Recalculate all workflow tables for a specific month/year
 * This ensures data consistency across all workflow tables
 */
export async function recalculateWorkflow(
  monthShamsi: number,
  yearShamsi: number
): Promise<{
  transactions: { created: number; updated: number };
  reports: { created: number; updated: number };
  summaries: { created: number; updated: number };
}> {
  console.log(`[Workflow] Recalculating workflow for ${monthShamsi}/${yearShamsi}`);
  
  // Step 1: Populate MonthlyTransactions
  const transactions = await populateMonthlyTransactions(monthShamsi, yearShamsi);
  
  // Step 2: Populate InternalReport from MonthlyTransactions
  const reports = await populateInternalReport(monthShamsi, yearShamsi);
  
  // Step 3: Populate MinistrySummary from InternalReport
  const summaries = await populateMinistrySummary(monthShamsi, yearShamsi);
  
  console.log(`[Workflow] Recalculation complete for ${monthShamsi}/${yearShamsi}`);
  
  return {
    transactions,
    reports,
    summaries,
  };
}

/**
 * Get MonthlyTransactions for a specific entity and month/year
 */
export async function getMonthlyTransaction(
  entityTin: string,
  monthShamsi: number,
  yearShamsi: number
): Promise<MonthlyTransaction | null> {
  const [result] = await db
    .select()
    .from(monthlyTransactions)
    .where(
      and(
        eq(monthlyTransactions.entityTin, entityTin),
        eq(monthlyTransactions.monthShamsi, monthShamsi),
        eq(monthlyTransactions.yearShamsi, yearShamsi)
      )
    )
    .limit(1);
  
  return result || null;
}

/**
 * Get InternalReport for a specific entity and month/year
 */
export async function getInternalReport(
  entityTin: string,
  monthShamsi: number,
  yearShamsi: number
): Promise<InternalReport | null> {
  const [result] = await db
    .select()
    .from(internalReport)
    .where(
      and(
        eq(internalReport.entityTin, entityTin),
        eq(internalReport.monthShamsi, monthShamsi),
        eq(internalReport.yearShamsi, yearShamsi)
      )
    )
    .limit(1);
  
  return result || null;
}

/**
 * Get MinistrySummary for a specific group and month/year
 */
export async function getMinistrySummary(
  groupName: string,
  monthShamsi: number,
  yearShamsi: number
): Promise<MinistrySummary | null> {
  const [result] = await db
    .select()
    .from(ministrySummary)
    .where(
      and(
        eq(ministrySummary.groupName, groupName),
        eq(ministrySummary.monthShamsi, monthShamsi),
        eq(ministrySummary.yearShamsi, yearShamsi)
      )
    )
    .limit(1);
  
  return result || null;
}

/**
 * Get all InternalReports for a specific month/year
 */
export async function getInternalReportsForMonth(
  monthShamsi: number,
  yearShamsi: number
): Promise<InternalReport[]> {
  return await db
    .select()
    .from(internalReport)
    .where(
      and(
        eq(internalReport.monthShamsi, monthShamsi),
        eq(internalReport.yearShamsi, yearShamsi),
        eq(internalReport.status, 'active')
      )
    );
}

/**
 * Get all MinistrySummaries for a specific month/year
 */
export async function getMinistrySummariesForMonth(
  monthShamsi: number,
  yearShamsi: number
): Promise<MinistrySummary[]> {
  return await db
    .select()
    .from(ministrySummary)
    .where(
      and(
        eq(ministrySummary.monthShamsi, monthShamsi),
        eq(ministrySummary.yearShamsi, yearShamsi),
        eq(ministrySummary.status, 'active')
      )
    );
}

/**
 * Update MinistrySummary for a specific group when InternalReport changes
 * This function is called automatically when InternalReport is updated
 * It recalculates the summary for the affected group only
 */
export async function updateMinistrySummaryForGroup(
  groupName: string,
  monthShamsi: number,
  yearShamsi: number
): Promise<MinistrySummary | null> {
  console.log(`[Workflow] Updating MinistrySummary for group ${groupName}, ${monthShamsi}/${yearShamsi}`);
  
  // Get all internal reports for this group and month/year
  const allReports = await db
    .select()
    .from(internalReport)
    .where(
      and(
        eq(internalReport.monthShamsi, monthShamsi),
        eq(internalReport.yearShamsi, yearShamsi),
        eq(internalReport.status, 'active')
      )
    );
  
  // Filter reports for this specific group
  const groupReports: typeof allReports = [];
  for (const report of allReports) {
    // Get entity to find referral group
    const entity = await storage.getEntityByTin(report.entityTin);
    if (!entity || !entity.referralGroup) {
      continue;
    }
    
    // Check if this entity belongs to the target group
    let entityGroupName = entity.referralGroup;
    
    // Try to get group by ID or name
    const groupById = await storage.getGroup(entity.referralGroup);
    if (groupById) {
      entityGroupName = groupById.name;
    } else {
      const groupByName = await storage.getGroupByName(entity.referralGroup);
      if (groupByName) {
        entityGroupName = groupByName.name;
      }
    }
    
    if (entityGroupName === groupName) {
      groupReports.push(report);
    }
  }
  
  if (groupReports.length === 0) {
    console.log(`[Workflow] No reports found for group ${groupName}, removing summary if exists`);
    // Remove summary if no reports exist
    await db
      .delete(ministrySummary)
      .where(
        and(
          eq(ministrySummary.groupName, groupName),
          eq(ministrySummary.monthShamsi, monthShamsi),
          eq(ministrySummary.yearShamsi, yearShamsi)
        )
      );
    return null;
  }
  
  // Get group information
  let groupId: string | null = null;
  let groupCode: string | null = null;
  const groupByName = await storage.getGroupByName(groupName);
  if (groupByName) {
    groupId = groupByName.id;
    groupCode = groupByName.code || null;
  }
  
  // Calculate entity counts
  const totalEntities = groupReports.length;
  let finalizedEntities = 0;
  let partiallyCompliantEntities = 0;
  let nonCompliantEntities = 0;
  
  for (const report of groupReports) {
    const remainingAmount = parseFloat(report.remainingAmount || '0');
    const totalTaxableAmount = parseFloat(report.totalTaxableAmount || '0');
    
    if (remainingAmount === 0) {
      finalizedEntities++;
    } else if (remainingAmount > 0 && remainingAmount < totalTaxableAmount) {
      partiallyCompliantEntities++;
    } else if (remainingAmount === totalTaxableAmount) {
      nonCompliantEntities++;
    }
  }
  
  // Calculate revenue collected
  const revenueCollected = groupReports.reduce((sum, r) => 
    sum + parseFloat(r.collectedAmount || '0'), 0
  ).toFixed(2);
  
  // Get monthly revenue target
  let monthlyRevenueTarget: number | null = null;
  if (groupId) {
    const yearTarget = await db
      .select()
      .from(groupTargets)
      .where(
        and(
          eq(groupTargets.groupId, groupId),
          eq(groupTargets.yearShamsi, yearShamsi.toString())
        )
      )
      .limit(1);
    
    if (yearTarget.length > 0 && yearTarget[0].targetMonetary) {
      const targetValue = parseFloat(yearTarget[0].targetMonetary.replace(/,/g, '')) || 0;
      monthlyRevenueTarget = Math.round(targetValue / 12);
    }
  }
  
  // Calculate percent variation
  const percentVariation = monthlyRevenueTarget && monthlyRevenueTarget > 0
    ? ((parseFloat(revenueCollected) / monthlyRevenueTarget) * 100).toFixed(2)
    : null;
  
  // Aggregate correspondence and inquiry data
  const incomingLetters = groupReports.reduce((sum, r) => 
    sum + (r.correspondencesIn || 0), 0
  );
  const outgoingLetters = groupReports.reduce((sum, r) => 
    sum + (r.correspondencesOut || 0), 0
  );
  const incomingInquiries = groupReports.reduce((sum, r) => 
    sum + (r.inquiriesIn || 0), 0
  );
  const outgoingInquiries = groupReports.reduce((sum, r) => 
    sum + (r.inquiriesOut || 0), 0
  );
  
  // Check if summary exists
  const existing = await db
    .select()
    .from(ministrySummary)
    .where(
      and(
        eq(ministrySummary.groupName, groupName),
        eq(ministrySummary.monthShamsi, monthShamsi),
        eq(ministrySummary.yearShamsi, yearShamsi)
      )
    )
    .limit(1);
  
  const summaryData: InsertMinistrySummary = {
    groupId,
    groupName,
    groupCode,
    monthShamsi,
    yearShamsi,
    totalEntities,
    finalizedEntities,
    partiallyCompliantEntities,
    nonCompliantEntities,
    revenueCollected: revenueCollected,
    monthlyRevenueTarget: monthlyRevenueTarget ? monthlyRevenueTarget.toFixed(2) : null,
    percentVariation: percentVariation,
    incomingLetters,
    outgoingLetters,
    incomingInquiries,
    outgoingInquiries,
    status: 'active',
    notes: null,
  };
  
  if (existing.length > 0) {
    // Update existing summary
    const [result] = await db
      .update(ministrySummary)
      .set({
        ...summaryData,
        updatedAt: sql`NOW()`,
      })
      .where(eq(ministrySummary.id, existing[0].id))
      .returning();
    return result || null;
  } else {
    // Create new summary
    const [result] = await db.insert(ministrySummary).values(summaryData).returning();
    return result || null;
  }
}

/**
 * Get alerts for a specific entity
 */
export async function getEntityAlerts(
  entityTin: string,
  monthShamsi?: number,
  yearShamsi?: number
): Promise<WorkflowAlert[]> {
  const conditions: any[] = [
    eq(workflowAlerts.entityTin, entityTin)
  ];
  
  if (monthShamsi !== undefined) {
    conditions.push(eq(workflowAlerts.monthShamsi, monthShamsi));
  }
  
  if (yearShamsi !== undefined) {
    conditions.push(eq(workflowAlerts.yearShamsi, yearShamsi));
  }
  
  return await db
    .select()
    .from(workflowAlerts)
    .where(and(...conditions))
    .orderBy(sql`${workflowAlerts.createdAt} DESC`);
}

/**
 * Get alerts for a specific group
 */
export async function getGroupAlerts(
  groupName: string,
  monthShamsi?: number,
  yearShamsi?: number
): Promise<WorkflowAlert[]> {
  const conditions: any[] = [
    eq(workflowAlerts.groupName, groupName)
  ];
  
  if (monthShamsi !== undefined) {
    conditions.push(eq(workflowAlerts.monthShamsi, monthShamsi));
  }
  
  if (yearShamsi !== undefined) {
    conditions.push(eq(workflowAlerts.yearShamsi, yearShamsi));
  }
  
  return await db
    .select()
    .from(workflowAlerts)
    .where(and(...conditions))
    .orderBy(sql`${workflowAlerts.createdAt} DESC`);
}

/**
 * Get all alerts for a specific month/year
 */
export async function getAlerts(
  monthShamsi: number,
  yearShamsi: number,
  status?: 'active' | 'acknowledged' | 'resolved' | 'dismissed'
): Promise<WorkflowAlert[]> {
  const conditions: any[] = [
    eq(workflowAlerts.monthShamsi, monthShamsi),
    eq(workflowAlerts.yearShamsi, yearShamsi)
  ];
  
  if (status) {
    conditions.push(eq(workflowAlerts.status, status));
  }
  
  return await db
    .select()
    .from(workflowAlerts)
    .where(and(...conditions))
    .orderBy(sql`${workflowAlerts.createdAt} DESC`);
}

/**
 * Acknowledge an alert
 */
export async function acknowledgeAlert(alertId: string, userId: string): Promise<WorkflowAlert | null> {
  const [result] = await db
    .update(workflowAlerts)
    .set({
      status: 'acknowledged',
      acknowledgedBy: userId,
      acknowledgedAt: sql`NOW()`,
      updatedAt: sql`NOW()`,
    })
    .where(eq(workflowAlerts.id, alertId))
    .returning();
  
  return result || null;
}

/**
 * Resolve an alert
 */
export async function resolveAlert(alertId: string): Promise<WorkflowAlert | null> {
  const [result] = await db
    .update(workflowAlerts)
    .set({
      status: 'resolved',
      resolvedAt: sql`NOW()`,
      updatedAt: sql`NOW()`,
    })
    .where(eq(workflowAlerts.id, alertId))
    .returning();
  
  return result || null;
}

/**
 * Generate entity alerts for a specific month/year
 * Flags entities where RemainingAmount > threshold
 */
export async function generateEntityAlerts(
  monthShamsi: number,
  yearShamsi: number,
  threshold: number = 0.3
): Promise<number> {
  // Get all internal reports for the month/year
  const reports = await getInternalReportsForMonth(monthShamsi, yearShamsi);
  
  // Clear existing entity alerts for this month/year
  await db
    .delete(workflowAlerts)
    .where(
      and(
        eq(workflowAlerts.monthShamsi, monthShamsi),
        eq(workflowAlerts.yearShamsi, yearShamsi),
        eq(workflowAlerts.alertType, 'entity_remaining_amount')
      )
    );
  
  let alertCount = 0;
  
  for (const report of reports) {
    const remainingAmount = parseFloat(report.remainingAmount || '0');
    const totalTaxableAmount = parseFloat(report.totalTaxableAmount || '0');
    
    if (totalTaxableAmount === 0) continue;
    
    const remainingPercentage = remainingAmount / totalTaxableAmount;
    
    if (remainingPercentage > threshold) {
      // Determine severity
      let severity: 'low' | 'medium' | 'high' | 'critical' = 'low';
      if (remainingPercentage >= 0.9) {
        severity = 'critical';
      } else if (remainingPercentage >= 0.7) {
        severity = 'high';
      } else if (remainingPercentage >= 0.5) {
        severity = 'medium';
      }
      
      const alertData: InsertWorkflowAlert = {
        entityTin: report.entityTin,
        groupName: null,
        alertType: 'entity_remaining_amount',
        message: `نهاد ${report.entityName} (${report.entityTin}) دارای مبلغ باقیمانده بالا است: ${formatNumber(remainingAmount)} از ${formatNumber(totalTaxableAmount)} (${(remainingPercentage * 100).toFixed(1)}%)`,
        monthShamsi,
        yearShamsi,
        severity,
        status: 'active',
        details: {
          entityName: report.entityName,
          remainingAmount,
          totalTaxableAmount,
          remainingPercentage: remainingPercentage * 100,
          threshold: threshold * 100,
        },
      };
      
      await db.insert(workflowAlerts).values(alertData);
      alertCount++;
    }
  }
  
  return alertCount;
}

/**
 * Generate group alerts for a specific month/year
 * Flags groups where RevenueCollected < threshold * MonthlyRevenueTarget
 */
export async function generateGroupAlerts(
  monthShamsi: number,
  yearShamsi: number,
  threshold: number = 0.8
): Promise<number> {
  // Get all ministry summaries for the month/year
  const summaries = await getMinistrySummariesForMonth(monthShamsi, yearShamsi);
  
  // Clear existing group alerts for this month/year
  await db
    .delete(workflowAlerts)
    .where(
      and(
        eq(workflowAlerts.monthShamsi, monthShamsi),
        eq(workflowAlerts.yearShamsi, yearShamsi),
        eq(workflowAlerts.alertType, 'group_revenue_target')
      )
    );
  
  let alertCount = 0;
  
  for (const summary of summaries) {
    const revenueCollected = parseFloat(summary.revenueCollected || '0');
    const monthlyRevenueTarget = parseFloat(summary.monthlyRevenueTarget || '0');
    
    if (monthlyRevenueTarget === 0) continue;
    
    const achievementPercentage = revenueCollected / monthlyRevenueTarget;
    
    if (achievementPercentage < threshold) {
      // Determine severity
      let severity: 'low' | 'medium' | 'high' | 'critical' = 'low';
      if (achievementPercentage < 0.5) {
        severity = 'critical';
      } else if (achievementPercentage < 0.65) {
        severity = 'high';
      } else if (achievementPercentage < 0.8) {
        severity = 'medium';
      }
      
      const alertData: InsertWorkflowAlert = {
        entityTin: null,
        groupName: summary.groupName,
        alertType: 'group_revenue_target',
        message: `گروه ${summary.groupName} درآمد کمتر از هدف دارد: ${formatNumber(revenueCollected)} از ${formatNumber(monthlyRevenueTarget)} (${(achievementPercentage * 100).toFixed(1)}%)`,
        monthShamsi,
        yearShamsi,
        severity,
        status: 'active',
        details: {
          revenueCollected,
          monthlyRevenueTarget,
          achievementPercentage: achievementPercentage * 100,
          threshold: threshold * 100,
          totalEntities: summary.totalEntities,
        },
      };
      
      await db.insert(workflowAlerts).values(alertData);
      alertCount++;
    }
  }
  
  return alertCount;
}

/**
 * Generate all alerts (entity and group) for a specific month/year
 */
export async function generateAlerts(
  monthShamsi: number,
  yearShamsi: number
): Promise<{ entityAlerts: number; groupAlerts: number }> {
  const entityAlerts = await generateEntityAlerts(monthShamsi, yearShamsi);
  const groupAlerts = await generateGroupAlerts(monthShamsi, yearShamsi);
  
  return { entityAlerts, groupAlerts };
}

/**
 * Format number with thousand separators
 */
function formatNumber(value: number | string): string {
  const num = typeof value === 'string' ? parseFloat(value) : value;
  if (isNaN(num)) return '0';
  return num.toLocaleString('en-US');
}

/**
 * Automated Workflow Execution
 * Runs the complete workflow for a selected month/year
 * Pulls entities from master table, appends transactions, and regenerates reports/summaries
 */

export interface WorkflowExecutionResult {
  monthShamsi: number;
  yearShamsi: number;
  transactions: { created: number; updated: number };
  reports: { created: number; updated: number };
  summaries: { created: number; updated: number };
  alerts: { entityAlerts: number; groupAlerts: number };
  executionTime: number;
  status: 'completed' | 'failed';
  error?: string;
}

/**
 * Execute automated workflow for a specific month/year
 * This is the main automation function that runs the complete workflow
 */
export async function executeAutomatedWorkflow(
  monthShamsi: number,
  yearShamsi: number,
  options: {
    appendMode?: boolean; // Append new transactions (default: true)
    regenerateReports?: boolean; // Regenerate InternalReport (default: true)
    regenerateSummaries?: boolean; // Regenerate MinistrySummary (default: true)
    generateAlerts?: boolean; // Generate alerts (default: true)
  } = {}
): Promise<WorkflowExecutionResult> {
  const startTime = Date.now();
  const {
    appendMode = true,
    regenerateReports = true,
    regenerateSummaries = true,
    generateAlerts = true,
  } = options;
  
  console.log(`[Workflow Automation] Starting automated workflow for ${monthShamsi}/${yearShamsi}`);
  console.log(`[Workflow Automation] Options: appendMode=${appendMode}, regenerateReports=${regenerateReports}, regenerateSummaries=${regenerateSummaries}, generateAlerts=${generateAlerts}`);
  
  try {
    // Step 1: Pull entities from master table and populate MonthlyTransactions
    // This appends new transactions for entities that don't have records yet
    // If appendMode is false, it will update existing records
    console.log(`[Workflow Automation] Step 1: Populating MonthlyTransactions from master entities`);
    const transactions = await populateMonthlyTransactions(monthShamsi, yearShamsi);
    console.log(`[Workflow Automation] MonthlyTransactions: Created ${transactions.created}, Updated ${transactions.updated}`);
    
    // Step 2: Regenerate InternalReport (if enabled)
    let reports = { created: 0, updated: 0 };
    if (regenerateReports) {
      console.log(`[Workflow Automation] Step 2: Regenerating InternalReport`);
      reports = await populateInternalReport(monthShamsi, yearShamsi);
      console.log(`[Workflow Automation] InternalReport: Created ${reports.created}, Updated ${reports.updated}`);
    } else {
      console.log(`[Workflow Automation] Step 2: Skipping InternalReport regeneration`);
    }
    
    // Step 3: Regenerate MinistrySummary (if enabled)
    let summaries = { created: 0, updated: 0 };
    if (regenerateSummaries) {
      console.log(`[Workflow Automation] Step 3: Regenerating MinistrySummary`);
      summaries = await populateMinistrySummary(monthShamsi, yearShamsi);
      console.log(`[Workflow Automation] MinistrySummary: Created ${summaries.created}, Updated ${summaries.updated}`);
    } else {
      console.log(`[Workflow Automation] Step 3: Skipping MinistrySummary regeneration`);
    }
    
    // Step 4: Generate alerts (if enabled)
    let alerts = { entityAlerts: 0, groupAlerts: 0 };
    if (generateAlerts) {
      console.log(`[Workflow Automation] Step 4: Generating alerts`);
      // Note: generateAlerts function should be defined in this file
      // For now, we'll use a try-catch to handle if it doesn't exist yet
      try {
      // Note: generateAlerts should be defined in this file
      // For now, we'll skip alert generation if the function doesn't exist
      // This will be implemented when alert functions are available
      console.log(`[Workflow Automation] Alert generation will be handled separately`);
      // TODO: Call generateAlerts when it's available
      alerts = { entityAlerts: 0, groupAlerts: 0 };
      } catch (error: any) {
        console.error(`[Workflow Automation] Error generating alerts:`, error);
        // Continue workflow even if alerts fail
      }
    } else {
      console.log(`[Workflow Automation] Step 4: Skipping alert generation`);
    }
    
    const executionTime = Date.now() - startTime;
    console.log(`[Workflow Automation] Workflow completed successfully in ${executionTime}ms`);
    
    return {
      monthShamsi,
      yearShamsi,
      transactions,
      reports,
      summaries,
      alerts,
      executionTime,
      status: 'completed',
    };
  } catch (error: any) {
    const executionTime = Date.now() - startTime;
    console.error(`[Workflow Automation] Workflow failed after ${executionTime}ms:`, error);
    
    return {
      monthShamsi,
      yearShamsi,
      transactions: { created: 0, updated: 0 },
      reports: { created: 0, updated: 0 },
      summaries: { created: 0, updated: 0 },
      alerts: { entityAlerts: 0, groupAlerts: 0 },
      executionTime,
      status: 'failed',
      error: error.message || 'Unknown error',
    };
  }
}

/**
 * Create or update workflow configuration
 */
export async function saveWorkflowConfig(
  config: InsertWorkflowConfig
): Promise<WorkflowConfig> {
  // Check if config with same name exists
  const existing = await db
    .select()
    .from(workflowConfig)
    .where(eq(workflowConfig.configName, config.configName))
    .limit(1);
  
  if (existing.length > 0) {
    // Update existing config
    const [result] = await db
      .update(workflowConfig)
      .set({
        ...config,
        updatedAt: sql`NOW()`,
      })
      .where(eq(workflowConfig.id, existing[0].id))
      .returning();
    return result;
  } else {
    // Create new config
    const [result] = await db.insert(workflowConfig).values(config).returning();
    return result;
  }
}

/**
 * Get workflow configuration by name
 */
export async function getWorkflowConfig(configName: string): Promise<WorkflowConfig | null> {
  const [result] = await db
    .select()
    .from(workflowConfig)
    .where(eq(workflowConfig.configName, configName))
    .limit(1);
  
  return result || null;
}

/**
 * Get all workflow configurations
 */
export async function getAllWorkflowConfigs(): Promise<WorkflowConfig[]> {
  return await db
    .select()
    .from(workflowConfig)
    .orderBy(sql`${workflowConfig.yearShamsi} DESC, ${workflowConfig.monthShamsi} DESC`);
}

/**
 * Get workflow configurations scheduled for auto-run
 */
export async function getScheduledWorkflowConfigs(): Promise<WorkflowConfig[]> {
  return await db
    .select()
    .from(workflowConfig)
    .where(
      and(
        eq(workflowConfig.autoRun, true),
        sql`${workflowConfig.nextRunAt} IS NOT NULL`,
        sql`${workflowConfig.nextRunAt} <= NOW()`
      )
    )
    .orderBy(sql`${workflowConfig.nextRunAt} ASC`);
}

/**
 * Update workflow configuration status
 */
export async function updateWorkflowConfigStatus(
  configId: string,
  status: 'pending' | 'running' | 'completed' | 'failed',
  statusMessage?: string
): Promise<WorkflowConfig | null> {
  const updateData: any = {
    status,
    updatedAt: sql`NOW()`,
  };
  
  if (status === 'running') {
    updateData.lastRunAt = sql`NOW()`;
  }
  
  if (statusMessage) {
    updateData.lastStatusMessage = statusMessage;
  }
  
  const [result] = await db
    .update(workflowConfig)
    .set(updateData)
    .where(eq(workflowConfig.id, configId))
    .returning();
  
  return result || null;
}

/**
 * Run scheduled workflows
 * This function should be called periodically (e.g., via cron job) to execute scheduled workflows
 */
export async function runScheduledWorkflows(): Promise<{
  executed: number;
  results: WorkflowExecutionResult[];
}> {
  console.log(`[Workflow Automation] Checking for scheduled workflows`);
  
  const scheduledConfigs = await getScheduledWorkflowConfigs();
  console.log(`[Workflow Automation] Found ${scheduledConfigs.length} scheduled workflows`);
  
  const results: WorkflowExecutionResult[] = [];
  
  for (const config of scheduledConfigs) {
    // Update status to running
    await updateWorkflowConfigStatus(config.id, 'running', 'Workflow execution started');
    
    try {
      // Execute workflow
      const result = await executeAutomatedWorkflow(
        config.monthShamsi,
        config.yearShamsi,
        {
          appendMode: config.appendMode ?? true,
          regenerateReports: config.regenerateReports ?? true,
          regenerateSummaries: config.regenerateSummaries ?? true,
          generateAlerts: config.generateAlerts ?? true,
        }
      );
      
      results.push(result);
      
      // Update status based on result
      if (result.status === 'completed') {
        await updateWorkflowConfigStatus(
          config.id,
          'completed',
          `Workflow completed successfully. Transactions: ${result.transactions.created + result.transactions.updated}, Reports: ${result.reports.created + result.reports.updated}, Summaries: ${result.summaries.created + result.summaries.updated}, Alerts: ${result.alerts.entityAlerts + result.alerts.groupAlerts}`
        );
      } else {
        await updateWorkflowConfigStatus(
          config.id,
          'failed',
          result.error || 'Workflow execution failed'
        );
      }
    } catch (error: any) {
      console.error(`[Workflow Automation] Error executing workflow for config ${config.configName}:`, error);
      await updateWorkflowConfigStatus(
        config.id,
        'failed',
        error.message || 'Unknown error during workflow execution'
      );
      
      results.push({
        monthShamsi: config.monthShamsi,
        yearShamsi: config.yearShamsi,
        transactions: { created: 0, updated: 0 },
        reports: { created: 0, updated: 0 },
        summaries: { created: 0, updated: 0 },
        alerts: { entityAlerts: 0, groupAlerts: 0 },
        executionTime: 0,
        status: 'failed',
        error: error.message || 'Unknown error',
      });
    }
  }
  
  return {
    executed: results.length,
    results,
  };
}

