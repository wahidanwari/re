/**
 * Committee Service
 * Manages committee lifecycle, status transitions, and authority enforcement
 */

import type { User, CommitteeNew, InsertCommitteeNew } from '@shared/schema';
import { storage } from '../storage';

export type CommitteeStatus = 'DRAFT' | 'APPROVED' | 'CLOSED';

export interface CommitteeTransitionResult {
  success: boolean;
  newStatus: CommitteeStatus;
  errorMessage?: string;
  committee?: CommitteeNew;
}

export interface CommitteePermissionCheck {
  canCreate: boolean;
  canApprove: boolean;
  canClose: boolean;
  canAssign: boolean;
  reason?: string;
}

/**
 * Check if user has committee management permissions
 * Only Director, Coordinator (acting_coordinator), and System Admin can manage committees
 */
export function hasCommitteeManagementPermission(user: User | null | undefined): boolean {
  if (!user) return false;
  
  // System admin always has access
  if (user.role === 'system_admin') return true;
  
  // Director has access
  if (user.role === 'director') return true;
  
  // Coordinator (acting_coordinator package) has access
  if (user.permissionPackages && Array.isArray(user.permissionPackages)) {
    if (user.permissionPackages.includes('acting_coordinator')) return true;
  }
  
  return false;
}

/**
 * Get detailed permission check for committee operations
 */
export function getCommitteePermissions(user: User | null | undefined): CommitteePermissionCheck {
  const hasPermission = hasCommitteeManagementPermission(user);
  
  return {
    canCreate: hasPermission,
    canApprove: hasPermission,
    canClose: hasPermission,
    canAssign: hasPermission,
    reason: hasPermission ? undefined : 'Only Director, Coordinator, or System Admin can manage committees',
  };
}

/**
 * Validate committee status transition
 * Allowed transitions:
 * - DRAFT → APPROVED
 * - APPROVED → CLOSED
 * Disallowed:
 * - CLOSED → anything
 * - APPROVED → DRAFT
 * - Any other invalid transition
 */
export function validateStatusTransition(
  currentStatus: CommitteeStatus,
  newStatus: CommitteeStatus
): { isValid: boolean; errorMessage?: string } {
  // No transition needed
  if (currentStatus === newStatus) {
    return { isValid: true };
  }
  
  // Valid transitions
  if (currentStatus === 'DRAFT' && newStatus === 'APPROVED') {
    return { isValid: true };
  }
  
  if (currentStatus === 'APPROVED' && newStatus === 'CLOSED') {
    return { isValid: true };
  }
  
  // Invalid transitions
  if (currentStatus === 'CLOSED') {
    return {
      isValid: false,
      errorMessage: 'Cannot transition from CLOSED status. Committee is permanently locked.',
    };
  }
  
  if (currentStatus === 'APPROVED' && newStatus === 'DRAFT') {
    return {
      isValid: false,
      errorMessage: 'Cannot revert from APPROVED to DRAFT. Once approved, committee can only be closed.',
    };
  }
  
  // Any other invalid transition
  return {
    isValid: false,
    errorMessage: `Invalid status transition from ${currentStatus} to ${newStatus}.`,
  };
}

/**
 * Create a new committee
 * Rules:
 * - status = DRAFT
 * - year + month must be unique
 * - created_by is required
 * - committee has NO effect on cases yet
 */
export async function createCommittee(
  data: Omit<InsertCommitteeNew, 'status' | 'createdBy'>,
  user: User
): Promise<{ success: boolean; committee?: CommitteeNew; errorMessage?: string }> {
  // Check permissions
  if (!hasCommitteeManagementPermission(user)) {
    return {
      success: false,
      errorMessage: 'Only Director, Coordinator, or System Admin can create committees',
    };
  }
  
  // Check if committee with same year+month already exists
  const existing = await storage.getCommitteeByYearMonth(data.year, data.month);
  if (existing) {
    return {
      success: false,
      errorMessage: `Committee for ${data.year}/${data.month} already exists`,
    };
  }
  
  // Create committee with DRAFT status
  const committeeData: InsertCommitteeNew = {
    ...data,
    status: 'DRAFT',
    createdBy: user.id,
  };
  
  try {
    const committee = await storage.createCommitteeNew(committeeData);
    return { success: true, committee };
  } catch (error: any) {
    console.error('[COMMITTEE SERVICE] Error creating committee:', error);
    return {
      success: false,
      errorMessage: error?.message || 'Failed to create committee',
    };
  }
}

/**
 * Approve a committee
 * Rules:
 * - Only DRAFT → APPROVED allowed
 * - approved_by is required
 * - approved_at is set
 * - Committee becomes authoritative
 */
export async function approveCommittee(
  committeeId: string,
  user: User
): Promise<CommitteeTransitionResult> {
  // Check permissions
  if (!hasCommitteeManagementPermission(user)) {
    return {
      success: false,
      newStatus: 'DRAFT',
      errorMessage: 'Only Director, Coordinator, or System Admin can approve committees',
    };
  }
  
  // Get committee
  const committee = await storage.getCommitteeNew(committeeId);
  if (!committee) {
    return {
      success: false,
      newStatus: 'DRAFT',
      errorMessage: 'Committee not found',
    };
  }
  
  // Validate transition
  const validation = validateStatusTransition(committee.status as CommitteeStatus, 'APPROVED');
  if (!validation.isValid) {
    return {
      success: false,
      newStatus: committee.status as CommitteeStatus,
      errorMessage: validation.errorMessage,
    };
  }
  
  // Update committee
  try {
    const updated = await storage.updateCommitteeNew(committeeId, {
      status: 'APPROVED',
      approvedBy: user.id,
      approvedAt: new Date(),
    });
    
    return {
      success: true,
      newStatus: 'APPROVED',
      committee: updated,
    };
  } catch (error: any) {
    console.error('[COMMITTEE SERVICE] Error approving committee:', error);
    return {
      success: false,
      newStatus: committee.status as CommitteeStatus,
      errorMessage: error?.message || 'Failed to approve committee',
    };
  }
}

/**
 * Close a committee
 * Rules:
 * - Only APPROVED → CLOSED allowed
 * - No new assignments allowed
 * - Existing assignments remain valid
 * - Committee is locked permanently
 */
export async function closeCommittee(
  committeeId: string,
  user: User
): Promise<CommitteeTransitionResult> {
  // Check permissions
  if (!hasCommitteeManagementPermission(user)) {
    return {
      success: false,
      newStatus: 'APPROVED',
      errorMessage: 'Only Director, Coordinator, or System Admin can close committees',
    };
  }
  
  // Get committee
  const committee = await storage.getCommitteeNew(committeeId);
  if (!committee) {
    return {
      success: false,
      newStatus: 'APPROVED',
      errorMessage: 'Committee not found',
    };
  }
  
  // Validate transition
  const validation = validateStatusTransition(committee.status as CommitteeStatus, 'CLOSED');
  if (!validation.isValid) {
    return {
      success: false,
      newStatus: committee.status as CommitteeStatus,
      errorMessage: validation.errorMessage,
    };
  }
  
  // Update committee
  try {
    const updated = await storage.updateCommitteeNew(committeeId, {
      status: 'CLOSED',
    });
    
    return {
      success: true,
      newStatus: 'CLOSED',
      committee: updated,
    };
  } catch (error: any) {
    console.error('[COMMITTEE SERVICE] Error closing committee:', error);
    return {
      success: false,
      newStatus: committee.status as CommitteeStatus,
      errorMessage: error?.message || 'Failed to close committee',
    };
  }
}

/**
 * Check if committee can accept new assignments
 * Only APPROVED committees can accept assignments
 */
export function canCommitteeAcceptAssignments(committee: CommitteeNew | null | undefined): boolean {
  if (!committee) return false;
  return committee.status === 'APPROVED';
}

/**
 * Validate that assignment is allowed through committee
 * Prevents assignments through DRAFT or CLOSED committees
 */
export async function validateCommitteeAssignment(
  committeeId: string
): Promise<{ isValid: boolean; errorMessage?: string }> {
  const committee = await storage.getCommitteeNew(committeeId);
  
  if (!committee) {
    return {
      isValid: false,
      errorMessage: 'Committee not found',
    };
  }
  
  if (!canCommitteeAcceptAssignments(committee)) {
    return {
      isValid: false,
      errorMessage: `Cannot assign cases through committee with status ${committee.status}. Only APPROVED committees can accept assignments.`,
    };
  }
  
  return { isValid: true };
}

