/**
 * Case Report Calculation Service
 * Handles automatic calculations for case report fields
 */

import { CaseReportV2, InsertCaseReportV2 } from '@shared/schema';

/**
 * Calculate confirmedAmount (مبلغ تثبیت شده)
 * Formula: profitTransactionTax + incomeTax + salaryTax + rentTax + contractTax
 */
export function calculateConfirmedAmount(
  profitTransactionTax: number | string | null | undefined,
  incomeTax: number | string | null | undefined,
  salaryTax: number | string | null | undefined = 0,
  rentTax: number | string | null | undefined = 0,
  contractTax: number | string | null | undefined = 0
): number {
  const profitTax = parseNumericValue(profitTransactionTax);
  const income = parseNumericValue(incomeTax);
  const salary = parseNumericValue(salaryTax);
  const rent = parseNumericValue(rentTax);
  const contract = parseNumericValue(contractTax);
  return profitTax + income + salary + rent + contract;
}

/**
 * Calculate remainingCollectible (الباقی مبلغ قابل تحصیل)
 * Formula: confirmedAmount - collectedCurrentMonth
 */
export function calculateRemainingCollectible(
  confirmedAmount: number | string | null | undefined,
  collectedCurrentMonth: number | string | null | undefined
): number {
  const confirmed = parseNumericValue(confirmedAmount);
  const collected = parseNumericValue(collectedCurrentMonth);
  return Math.max(0, confirmed - collected); // Ensure non-negative
}

/**
 * Parse numeric value from various formats (string, number, null, undefined)
 * Handles comma-separated numbers, empty strings, etc.
 */
function parseNumericValue(value: number | string | null | undefined): number {
  if (value === null || value === undefined) {
    return 0;
  }
  
  if (typeof value === 'number') {
    return isNaN(value) ? 0 : value;
  }
  
  if (typeof value === 'string') {
    // Remove commas and whitespace
    const cleaned = value.replace(/,/g, '').trim();
    if (cleaned === '' || cleaned === '-') {
      return 0;
    }
    const parsed = parseFloat(cleaned);
    return isNaN(parsed) ? 0 : parsed;
  }
  
  return 0;
}

/**
 * Calculate all automatic fields for a case report
 * This function should be called before saving/updating a report
 */
export function calculateAutomaticFields(
  report: Partial<InsertCaseReportV2> | Partial<CaseReportV2>
): {
  confirmedAmount?: number;
  remainingCollectible?: number;
} {
  const calculations: {
    confirmedAmount?: number;
    remainingCollectible?: number;
  } = {};

  // Calculate confirmedAmount if source fields are present (including null/0 values)
  // Always calculate if any of the source fields is defined (even if null or 0)
  // Formula: profitTransactionTax + incomeTax + salaryTax + rentTax + contractTax
  if (
    report.profitTransactionTax !== undefined ||
    report.incomeTax !== undefined ||
    report.salaryTax !== undefined ||
    report.rentTax !== undefined ||
    report.contractTax !== undefined
  ) {
    const confirmedAmount = calculateConfirmedAmount(
      report.profitTransactionTax,
      report.incomeTax,
      report.salaryTax,
      report.rentTax,
      report.contractTax
    );
    calculations.confirmedAmount = confirmedAmount;
  }

  // Calculate remainingCollectible if source fields are present (including null/0 values)
  // Always calculate if collectedCurrentMonth is defined OR if confirmedAmount was calculated
  if (
    report.collectedCurrentMonth !== undefined ||
    calculations.confirmedAmount !== undefined ||
    report.confirmedAmount !== undefined
  ) {
    // Use calculated confirmedAmount if available, otherwise use existing value
    const confirmedAmount = calculations.confirmedAmount ?? parseNumericValue(report.confirmedAmount);
    const remainingCollectible = calculateRemainingCollectible(
      confirmedAmount,
      report.collectedCurrentMonth
    );
    calculations.remainingCollectible = remainingCollectible;
  }

  return calculations;
}

/**
 * Apply automatic calculations to a report object
 * Returns a new object with calculated fields included
 */
export function applyCalculationsToReport(
  report: Partial<InsertCaseReportV2> | Partial<CaseReportV2>
): Partial<InsertCaseReportV2> | Partial<CaseReportV2> {
  const calculations = calculateAutomaticFields(report);
  
  // Merge calculated fields into report
  return {
    ...report,
    ...calculations,
  };
}

