/**
 * Report PDF Generation Service
 * Generates professional PDF reports matching official MoF format
 * 100% RTL accurate
 */

import PDFDocument from 'pdfkit';
import type { CaseReportV2, Case, User } from '@shared/schema';
import jalaali from 'jalaali-js';

interface PDFGenerationOptions {
  report: CaseReportV2;
  caseData: Case;
  preparedByUser?: User;
  reviewedByUser?: User;
  approvedByUser?: User;
}

/**
 * Format number with thousand separators (Persian)
 */
function formatNumber(num: number | string | null | undefined): string {
  if (num === null || num === undefined) return '0';
  const numValue = typeof num === 'string' ? parseFloat(num) : num;
  if (isNaN(numValue)) return '0';
  return numValue.toLocaleString('fa-IR');
}

/**
 * Format date to Shamsi (DD-MM-YYYY)
 */
function formatShamsiDate(date: string | Date | null | undefined): string {
  if (!date) return '';
  const dateObj = typeof date === 'string' ? new Date(date) : date;
  if (isNaN(dateObj.getTime())) return '';
  const j = jalaali.toJalaali(dateObj);
  return `${String(j.jd).padStart(2, '0')}-${String(j.jm).padStart(2, '0')}-${j.jy}`;
}

/**
 * Add header section to PDF
 */
function addHeader(doc: PDFKit.PDFDocument, caseData: Case) {
  // Title
  doc.fontSize(18)
     .font('Helvetica-Bold')
     .text('گزارش بررسی قضیه', { align: 'right' })
     .moveDown(0.5);

  // Case information
  doc.fontSize(12)
     .font('Helvetica')
     .text(`نمبر قضیه: ${caseData.caseId}`, { align: 'right' })
     .text(`تاریخ ارجاع: ${formatShamsiDate(caseData.referralDate)}`, { align: 'right' })
     .text(`سال‌های بررسی: ${caseData.periodsUnderReview}`, { align: 'right' })
     .moveDown(1);
}

/**
 * Add Section 1: Entity Details
 */
function addSection1(doc: PDFKit.PDFDocument, report: CaseReportV2, caseData: Case) {
  doc.fontSize(14)
     .font('Helvetica-Bold')
     .text('بخش اول: مشخصات نهاد', { align: 'right' })
     .moveDown(0.5);

  doc.fontSize(11)
     .font('Helvetica');

  // Basic Information
  doc.text(`نام نهاد: ${report.companyName}`, { align: 'right' });
  doc.text(`نمبر تشخیصیه: ${report.tin}`, { align: 'right' });
  if (report.businessNature) {
    doc.text(`نوع تشبث: ${report.businessNature}`, { align: 'right' });
  }
  doc.text(`آمریت ارجاع کننده: ${report.groupReferrer}`, { align: 'right' });
  doc.text(`تاریخ ارجاع: ${formatShamsiDate(report.referralDate)}`, { align: 'right' });
  doc.text(`سال‌های بررسی: ${report.periodsUnderReview}`, { align: 'right' });
  doc.text(`تاریخ صادره مکتوب نهایی: ${formatShamsiDate(report.finalDocumentDate)}`, { align: 'right' });
  if (report.capitalPeriod) {
    doc.text(`دوران سرمایه: ${report.capitalPeriod}`, { align: 'right' });
  }

  // Address Information
  if (report.province || report.district || report.streetAddress) {
    doc.moveDown(0.5);
    doc.font('Helvetica-Bold').text('اطلاعات آدرس:', { align: 'right' });
    doc.font('Helvetica');
    if (report.province) doc.text(`ولایت: ${report.province}`, { align: 'right' });
    if (report.district) doc.text(`ولسوالی: ${report.district}`, { align: 'right' });
    if (report.streetAddress) doc.text(`آدرس: ${report.streetAddress}`, { align: 'right' });
    if (report.postalCode) doc.text(`کد پستی: ${report.postalCode}`, { align: 'right' });
    if (report.phone) doc.text(`شماره تماس: ${report.phone}`, { align: 'right' });
    if (report.email) doc.text(`ایمیل: ${report.email}`, { align: 'right' });
  }

  // Registration Details
  if (report.registrationNumber || report.businessLicenseNumber) {
    doc.moveDown(0.5);
    doc.font('Helvetica-Bold').text('جزئیات ثبت:', { align: 'right' });
    doc.font('Helvetica');
    if (report.registrationNumber) doc.text(`نمبر ثبت: ${report.registrationNumber}`, { align: 'right' });
    if (report.registrationDate) doc.text(`تاریخ ثبت: ${formatShamsiDate(report.registrationDate)}`, { align: 'right' });
    if (report.businessLicenseNumber) doc.text(`نمبر جواز فعالیت: ${report.businessLicenseNumber}`, { align: 'right' });
    if (report.businessLicenseDate) doc.text(`تاریخ جواز فعالیت: ${formatShamsiDate(report.businessLicenseDate)}`, { align: 'right' });
  }

  // Tax Information
  if (report.taxOffice || report.taxOfficeCode) {
    doc.moveDown(0.5);
    doc.font('Helvetica-Bold').text('اطلاعات مالیاتی:', { align: 'right' });
    doc.font('Helvetica');
    if (report.taxOffice) doc.text(`دفتر مالیاتی: ${report.taxOffice}`, { align: 'right' });
    if (report.taxOfficeCode) doc.text(`کد دفتر مالیاتی: ${report.taxOfficeCode}`, { align: 'right' });
    if (report.taxRegistrationDate) doc.text(`تاریخ ثبت مالیاتی: ${formatShamsiDate(report.taxRegistrationDate)}`, { align: 'right' });
  }

  // Additional Entity Information (Read-only for historical accuracy)
  const reportAny = report as any;
  if (reportAny.representative || reportAny.representativeContactNumber || reportAny.entityAddress) {
    doc.moveDown(0.5);
    doc.font('Helvetica-Bold').text('اطلاعات تکمیلی نهاد:', { align: 'right' });
    doc.font('Helvetica');
    if (reportAny.representative) {
      doc.text(`نماینده: ${reportAny.representative}`, { align: 'right' });
    }
    if (reportAny.representativeContactNumber) {
      doc.text(`شماره تماس نماینده: ${reportAny.representativeContactNumber}`, { align: 'right' });
    }
    if (reportAny.entityAddress) {
      doc.text(`آدرس نهاد: ${reportAny.entityAddress}`, { align: 'right' });
    }
  }

  doc.moveDown(1);
}

/**
 * Add Section 2: Extractions
 */
function addSection2(doc: PDFKit.PDFDocument, report: CaseReportV2) {
  doc.fontSize(14)
     .font('Helvetica-Bold')
     .text('بخش دوم: بیرون‌نویسی‌ها', { align: 'right' })
     .moveDown(0.5);

  doc.fontSize(11)
     .font('Helvetica');

  // Tax Types
  doc.font('Helvetica-Bold').text('انواع مالیات:', { align: 'right' });
  doc.font('Helvetica');
  doc.text(`مالیه موضوعی معاشات: ${formatNumber(report.salaryTax)} افغانی`, { align: 'right' });
  doc.text(`مالیه موضوعی بر کرایه: ${formatNumber(report.rentTax)} افغانی`, { align: 'right' });
  doc.text(`مالیه موضوعی قراردادی: ${formatNumber(report.contractTax)} افغانی`, { align: 'right' });
  doc.text(`مالیات معاملات انتفاعی: ${formatNumber(report.profitTransactionTax)} افغانی`, { align: 'right' });
  doc.text(`مالیات بر عایدات: ${formatNumber(report.incomeTax)} افغانی`, { align: 'right' });
  doc.text(`مالیات کسر شده: ${formatNumber(report.withholdingTax)} افغانی`, { align: 'right' });
  doc.text(`مالیات جریمه: ${formatNumber(report.penaltyTax)} افغانی`, { align: 'right' });
  doc.text(`سود: ${formatNumber(report.interest)} افغانی`, { align: 'right' });
  doc.text(`سایر مالیات‌ها: ${formatNumber(report.otherTaxes)} افغانی`, { align: 'right' });

  // Calculate total tax
  const totalTax = Number(report.salaryTax || 0) + Number(report.rentTax || 0) +
    Number(report.contractTax || 0) + Number(report.profitTransactionTax || 0) +
    Number(report.incomeTax || 0) + Number(report.withholdingTax || 0) +
    Number(report.penaltyTax || 0) + Number(report.interest || 0) +
    Number(report.otherTaxes || 0);

  doc.moveDown(0.3);
  doc.font('Helvetica-Bold')
     .text(`مجموع مالیات‌ها: ${formatNumber(totalTax)} افغانی`, { align: 'right' })
     .moveDown(0.5);

  // Financial Calculations
  doc.font('Helvetica-Bold').text('محاسبات مالی:', { align: 'right' });
  doc.font('Helvetica');
  doc.text(`ضرر کاهش یافته: ${formatNumber(report.reducedLoss)} افغانی`, { align: 'right' });
  doc.text(`مبلغ فاضل تحویل کاهش یافته: ${formatNumber(report.reducedRemainingAmount)} افغانی`, { align: 'right' });
  doc.text(`مبلغ تثبیت شده: ${formatNumber(report.confirmedAmount)} افغانی`, { align: 'right' });
  doc.text(`مبلغ تحصیل شده طی برج جاری: ${formatNumber(report.collectedCurrentMonth)} افغانی`, { align: 'right' });
  doc.text(`الباقی مبلغ قابل تحصیل: ${formatNumber(report.remainingCollectible)} افغانی`, { align: 'right' });

  // Calculation Details
  if (report.taxBase || report.taxRate || report.calculationMethod) {
    doc.moveDown(0.5);
    doc.font('Helvetica-Bold').text('جزئیات محاسبه:', { align: 'right' });
    doc.font('Helvetica');
    if (report.taxBase) doc.text(`مبنا مالیاتی: ${formatNumber(report.taxBase)} افغانی`, { align: 'right' });
    if (report.taxRate) doc.text(`نرخ مالیاتی: ${report.taxRate}%`, { align: 'right' });
    if (report.calculationMethod) doc.text(`روش محاسبه: ${report.calculationMethod}`, { align: 'right' });
  }

  // Payment Information
  if (report.paymentMethod || report.paymentReferenceNumber) {
    doc.moveDown(0.5);
    doc.font('Helvetica-Bold').text('اطلاعات پرداخت:', { align: 'right' });
    doc.font('Helvetica');
    if (report.paymentMethod) doc.text(`روش پرداخت: ${report.paymentMethod}`, { align: 'right' });
    if (report.paymentReferenceNumber) doc.text(`نمبر مرجع پرداخت: ${report.paymentReferenceNumber}`, { align: 'right' });
    if (report.paymentDate) doc.text(`تاریخ پرداخت: ${formatShamsiDate(report.paymentDate)}`, { align: 'right' });
    if (report.bankName) doc.text(`نام بانک: ${report.bankName}`, { align: 'right' });
    if (report.bankAccountNumber) doc.text(`شماره حساب بانکی: ${report.bankAccountNumber}`, { align: 'right' });
    if (report.bankBranch) doc.text(`شعبه بانک: ${report.bankBranch}`, { align: 'right' });
  }

  // Status & Attachment
  doc.moveDown(0.5);
  doc.font('Helvetica-Bold').text('وضعیت و ضمیمه:', { align: 'right' });
  doc.font('Helvetica');
  if (report.activityStatus) doc.text(`وضعیت فعالیت: ${report.activityStatus}`, { align: 'right' });
  if (report.attachmentNumber) doc.text(`نمبر آویز: ${report.attachmentNumber}`, { align: 'right' });
  if (report.attachmentDate) doc.text(`تاریخ آویز: ${formatShamsiDate(report.attachmentDate)}`, { align: 'right' });

  doc.moveDown(1);
}

/**
 * Add Section 3: Findings & Recommendations
 */
function addSection3(doc: PDFKit.PDFDocument, report: CaseReportV2) {
  doc.fontSize(14)
     .font('Helvetica-Bold')
     .text('بخش سوم: یافته‌ها و توصیه‌ها', { align: 'right' })
     .moveDown(0.5);

  doc.fontSize(11)
     .font('Helvetica');

  if (report.findingsSummary) {
    doc.font('Helvetica-Bold').text('خلاصه یافته‌ها:', { align: 'right' });
    doc.font('Helvetica');
    doc.text(report.findingsSummary, { align: 'right', continued: false });
    doc.moveDown(0.5);
  }

  if (report.detailedFindings) {
    doc.font('Helvetica-Bold').text('یافته‌های تفصیلی:', { align: 'right' });
    doc.font('Helvetica');
    doc.text(report.detailedFindings, { align: 'right', continued: false });
    doc.moveDown(0.5);
  }

  if (report.riskAssessment) {
    doc.font('Helvetica-Bold').text(`ارزیابی ریسک: ${report.riskAssessment}`, { align: 'right' });
    doc.moveDown(0.5);
  }

  if (report.recommendations) {
    doc.font('Helvetica-Bold').text('توصیه‌ها:', { align: 'right' });
    doc.font('Helvetica');
    doc.text(report.recommendations, { align: 'right', continued: false });
    doc.moveDown(0.5);
  }

  if (report.actionItems) {
    doc.font('Helvetica-Bold').text('اقدامات لازم:', { align: 'right' });
    doc.font('Helvetica');
    doc.text(report.actionItems, { align: 'right', continued: false });
    doc.moveDown(0.5);
  }

  if (report.followUpRequired) {
    doc.font('Helvetica-Bold').text('نیاز به پیگیری: بله', { align: 'right' });
    if (report.followUpDate) {
      doc.text(`تاریخ پیگیری: ${formatShamsiDate(report.followUpDate)}`, { align: 'right' });
    }
  }

  doc.moveDown(1);
}

/**
 * Add Section 4: Supporting Documents
 */
function addSection4(doc: PDFKit.PDFDocument, report: CaseReportV2) {
  doc.fontSize(14)
     .font('Helvetica-Bold')
     .text('بخش چهارم: اسناد حمایوی', { align: 'right' })
     .moveDown(0.5);

  doc.fontSize(11)
     .font('Helvetica');

  if (report.documentReviewDate) {
    doc.text(`تاریخ بررسی اسناد: ${formatShamsiDate(report.documentReviewDate)}`, { align: 'right' });
  }

  const documentsReviewed = Array.isArray(report.documentsReviewed) ? report.documentsReviewed : [];
  if (documentsReviewed.length > 0) {
    doc.moveDown(0.3);
    doc.font('Helvetica-Bold').text('اسناد بررسی شده:', { align: 'right' });
    doc.font('Helvetica');
    documentsReviewed.forEach((docItem: any, index: number) => {
      doc.text(`${index + 1}. ${docItem.name || docItem}`, { align: 'right' });
    });
  }

  if (report.missingDocuments) {
    doc.moveDown(0.5);
    doc.font('Helvetica-Bold').text('اسناد ناقص:', { align: 'right' });
    doc.font('Helvetica');
    doc.text(report.missingDocuments, { align: 'right', continued: false });
  }

  if (report.documentReviewNotes) {
    doc.moveDown(0.5);
    doc.font('Helvetica-Bold').text('ملاحظات بررسی اسناد:', { align: 'right' });
    doc.font('Helvetica');
    doc.text(report.documentReviewNotes, { align: 'right', continued: false });
  }

  doc.moveDown(1);
}

/**
 * Add Section 5: Approval & Signatures
 */
function addSection5(
  doc: PDFKit.PDFDocument,
  report: CaseReportV2,
  preparedByUser?: User,
  reviewedByUser?: User,
  approvedByUser?: User
) {
  doc.fontSize(14)
     .font('Helvetica-Bold')
     .text('بخش پنجم: تایید و امضا', { align: 'right' })
     .moveDown(0.5);

  doc.fontSize(11)
     .font('Helvetica');

  // Prepared By
  doc.font('Helvetica-Bold').text('تهیه شده توسط:', { align: 'right' });
  doc.font('Helvetica');
  if (preparedByUser) {
    doc.text(`نام: ${preparedByUser.fullName}`, { align: 'right' });
    doc.text(`نقش: ${report.preparedByRole || preparedByUser.role}`, { align: 'right' });
  } else {
    doc.text(`نقش: ${report.preparedByRole || 'نامشخص'}`, { align: 'right' });
  }
  if (report.preparedAt) {
    doc.text(`تاریخ: ${formatShamsiDate(report.preparedAt)}`, { align: 'right' });
  }
  doc.moveDown(0.5);

  // Reviewed By
  if (report.reviewedBy || report.reviewedAt) {
    doc.font('Helvetica-Bold').text('بررسی شده توسط:', { align: 'right' });
    doc.font('Helvetica');
    if (reviewedByUser) {
      doc.text(`نام: ${reviewedByUser.fullName}`, { align: 'right' });
      doc.text(`نقش: ${report.reviewedByRole || reviewedByUser.role}`, { align: 'right' });
    } else if (report.reviewedByRole) {
      doc.text(`نقش: ${report.reviewedByRole}`, { align: 'right' });
    }
    if (report.reviewedAt) {
      doc.text(`تاریخ: ${formatShamsiDate(report.reviewedAt)}`, { align: 'right' });
    }
    if (report.reviewNotes) {
      doc.text(`ملاحظات: ${report.reviewNotes}`, { align: 'right' });
    }
    doc.moveDown(0.5);
  }

  // Approved By
  if (report.approvedBy || report.approvedAt) {
    doc.font('Helvetica-Bold').text('تایید شده توسط:', { align: 'right' });
    doc.font('Helvetica');
    if (approvedByUser) {
      doc.text(`نام: ${approvedByUser.fullName}`, { align: 'right' });
      doc.text(`نقش: ${report.approvedByRole || approvedByUser.role}`, { align: 'right' });
    } else if (report.approvedByRole) {
      doc.text(`نقش: ${report.approvedByRole}`, { align: 'right' });
    }
    if (report.approvedAt) {
      doc.text(`تاریخ: ${formatShamsiDate(report.approvedAt)}`, { align: 'right' });
    }
  }

  doc.moveDown(2);
}

/**
 * Generate PDF for case report V2
 */
export async function generateReportPDF(
  options: PDFGenerationOptions
): Promise<PDFKit.PDFDocument> {
  const { report, caseData, preparedByUser, reviewedByUser, approvedByUser } = options;

  // Create PDF document with A4 size and margins
  const doc = new PDFDocument({
    size: 'A4',
    margin: 50,
    info: {
      Title: `گزارش قضیه ${caseData.caseId}`,
      Author: 'سیستم بررسی',
      Subject: 'گزارش بررسی قضیه',
      Creator: 'Audit System',
    },
  });

  // Add header
  addHeader(doc, caseData);

  // Add all sections
  addSection1(doc, report, caseData);
  addSection2(doc, report);
  addSection3(doc, report);
  addSection4(doc, report);
  addSection5(doc, report, preparedByUser, reviewedByUser, approvedByUser);

  // Add footer with page numbers
  const totalPages = doc.bufferedPageRange().count;
  for (let i = 0; i < totalPages; i++) {
    doc.switchToPage(i);
    doc.fontSize(8)
       .font('Helvetica')
       .text(
         `صفحه ${i + 1} از ${totalPages}`,
         50,
         doc.page.height - 30,
         { align: 'center' }
       );
  }

  return doc;
}

/**
 * Generate PDF buffer for download
 */
export async function generateReportPDFBuffer(
  options: PDFGenerationOptions
): Promise<Buffer> {
  return new Promise(async (resolve, reject) => {
    try {
      const doc = await generateReportPDF(options);
      const chunks: Buffer[] = [];

      doc.on('data', (chunk: Buffer) => chunks.push(chunk));
      doc.on('end', () => resolve(Buffer.concat(chunks)));
      doc.on('error', reject);

      doc.end();
    } catch (error) {
      reject(error);
    }
  });
}

