/**
 * Case Assignment Service
 * Handles case assignment via committees and direct assignment
 * Enforces status transitions and maintains assignment history
 */

import type { User, Case, CommitteeNew, Group } from '@shared/schema';
import { storage } from '../storage';
import { CaseStatus } from '@shared/schema';

// Status for cases assigned via committee
// NOTE: This status must be in the cases_status_check constraint
// Using 'اختصاص داده شده' (ASSIGNED) which is a valid status and semantically correct
// for cases assigned to audit groups via committee
const COMMITTEE_ASSIGNED_STATUS = 'اختصاص داده شده';

export interface EligibleCase extends Case {
  isEligible: boolean;
  reason?: string;
}

export interface AssignmentResult {
  success: boolean;
  assignmentId?: string;
  case?: Case;
  errorMessage?: string;
}

export interface AssignmentHistory {
  assignmentId: string;
  committeeId?: string;
  committeeTitle?: string;
  auditGroupId: string;
  auditGroupName?: string;
  assignmentType: 'COMMITTEE' | 'DIRECT' | 'REASSIGNMENT';
  previousAssignmentId?: string;
  reason?: string;
  assignedBy: string;
  assignedByName?: string;
  assignedAt: Date;
}

/**
 * Check if a case is eligible for committee assignment
 * Eligible if:
 * - status == "NEW" (جدید) OR status == "ASSIGNED" (اختصاص داده شده - previously committee-assigned)
 * - Case is NOT already assigned to an audit group (receivingGroup, currentAuditGroupId, or currentAssignmentId must be null)
 * - Case is NOT currently under active audit by an auditor
 */
export function isCaseEligibleForAssignment(caseItem: Case): { eligible: boolean; reason?: string } {
  // Check status - must be "جدید" (NEW) or "اختصاص داده شده" (ASSIGNED - previously committee-assigned)
  const eligibleStatuses = [CaseStatus.NEW, CaseStatus.ASSIGNED];
  if (!eligibleStatuses.includes(caseItem.status as any)) {
    return {
      eligible: false,
      reason: `وضعیت قضیه "${caseItem.status}" واجد شرایط نیست. فقط قضایای با وضعیت "جدید" یا "اختصاص داده شده" می‌توانند اختصاص داده شوند.`,
    };
  }
  
  // Check if case is already assigned to an audit group
  // A case is considered assigned to an audit group if:
  // - receivingGroup is set (legacy field, but still used)
  // - OR currentAuditGroupId is set (new committee assignment system)
  // - OR currentAssignmentId is set (indicates active assignment record exists)
  if (caseItem.receivingGroup || caseItem.currentAuditGroupId || caseItem.currentAssignmentId) {
    return {
      eligible: false,
      reason: 'قضیه قبلاً به یک گروه بررسی اختصاص داده شده است. فقط قضایای بدون اختصاص گروه می‌توانند از طریق کمیته اختصاص داده شوند.',
    };
  }
  
  // Check if case is under active audit by an auditor
  // A case is under active audit if:
  // - assignedTo is set (assigned to specific auditor)
  // - OR assignedAuditor is set
  // - AND status indicates active work (not just assigned)
  const activeAuditStatuses = [
    CaseStatus.ASSIGNED_TO_AUDITOR,
    CaseStatus.UNDER_AUDIT_REVIEW,
    CaseStatus.IN_PROGRESS,
  ];
  
  if (caseItem.assignedTo || caseItem.assignedAuditor) {
    if (activeAuditStatuses.includes(caseItem.status as any)) {
      return {
        eligible: false,
        reason: 'قضیه در حال حاضر در حال بررسی فعال توسط بازرس است و نمی‌تواند از طریق کمیته مجدداً اختصاص داده شود.',
      };
    }
  }
  
  return { eligible: true };
}

/**
 * Get all eligible cases for committee assignment
 * Returns cases with status "NEW" (جدید) or "ASSIGNED" (اختصاص داده شده) that:
 * - Are NOT already assigned to an audit group (no receivingGroup, currentAuditGroupId, or currentAssignmentId)
 * - Are NOT under active audit by an auditor
 */
export async function getEligibleCases(): Promise<EligibleCase[]> {
  try {
    // Get all cases
    const allCases = await storage.getCases();
    
    // Filter and enrich eligible cases
    const eligibleCases: EligibleCase[] = [];
    let excludedCount = 0;
    const exclusionReasons: Record<string, number> = {};
    
    for (const caseItem of allCases) {
      const eligibility = isCaseEligibleForAssignment(caseItem);
      
      // Track exclusion reasons for debugging
      if (!eligibility.eligible) {
        excludedCount++;
        const reasonKey = eligibility.reason || 'Unknown reason';
        exclusionReasons[reasonKey] = (exclusionReasons[reasonKey] || 0) + 1;
        continue;
      }
      
      // Get entity name if entityId exists
      let entityName: string | undefined;
      if (caseItem.entityId) {
        try {
          const entity = await storage.getEntity(caseItem.entityId);
          entityName = entity?.name;
        } catch (err) {
          console.warn(`[CASE ASSIGNMENT SERVICE] Could not fetch entity ${caseItem.entityId}:`, err);
        }
      }
      
      eligibleCases.push({
        ...caseItem,
        isEligible: true,
        reason: undefined,
        entityName: entityName || caseItem.companyName || 'نامشخص',
      });
    }
    
    // Log summary for debugging (only if there are exclusions to avoid noise)
    if (excludedCount > 0 || process.env.DEBUG_LOGGING === 'true') {
      console.log(`[CASE ASSIGNMENT SERVICE] Eligible cases: ${eligibleCases.length} eligible, ${excludedCount} excluded`);
      if (Object.keys(exclusionReasons).length > 0) {
        console.log(`[CASE ASSIGNMENT SERVICE] Exclusion reasons:`, exclusionReasons);
      }
    }
    
    return eligibleCases;
  } catch (error) {
    console.error('[CASE ASSIGNMENT SERVICE] Error loading eligible cases:', error);
    throw error;
  }
}

/**
 * Assign cases via committee
 * Rules:
 * - Committee must be APPROVED
 * - Cases must be eligible
 * - Creates assignment records
 * - Updates case status to "اختصاص داده شده" (ASSIGNED)
 * - Updates case current_assignment_id and current_audit_group_id
 */
export async function assignCasesViaCommittee(
  committeeId: string,
  caseIds: string[],
  auditGroupId: string,
  user: User
): Promise<{ success: boolean; assignments: AssignmentResult[]; errorMessage?: string }> {
  // Validate committee
  const committee = await storage.getCommitteeNew(committeeId);
  if (!committee) {
    return {
      success: false,
      assignments: [],
      errorMessage: 'کمیته یافت نشد',
    };
  }
  
  // Check committee status - allow DRAFT and APPROVED
  if (committee.status !== 'APPROVED' && committee.status !== 'DRAFT') {
    return {
      success: false,
      assignments: [],
      errorMessage: `نمی‌توان قضایا را از طریق کمیته با وضعیت ${committee.status} اختصاص داد. فقط کمیته‌های پیش‌نویس یا تایید شده می‌توانند قضایا را بپذیرند.`,
    };
  }
  
  // Validate audit group
  const auditGroup = await storage.getGroup(auditGroupId);
  if (!auditGroup) {
    return {
      success: false,
      assignments: [],
      errorMessage: 'گروه بررسی یافت نشد',
    };
  }
  
  // Validate and assign each case
  const assignments: AssignmentResult[] = [];
  
  for (const caseId of caseIds) {
    try {
      // Get case
      const caseItem = await storage.getCase(caseId);
      if (!caseItem) {
        assignments.push({
          success: false,
          errorMessage: `قضیه ${caseId} یافت نشد`,
        });
        continue;
      }
      
      // Check eligibility
      const eligibility = isCaseEligibleForAssignment(caseItem);
      if (!eligibility.eligible) {
        assignments.push({
          success: false,
          errorMessage: eligibility.reason || 'قضیه واجد شرایط اختصاص نیست',
        });
        continue;
      }
      
      // Get previous assignment if exists
      const previousAssignment = caseItem.currentAssignmentId
        ? await storage.getCommitteeCaseAssignment(caseItem.currentAssignmentId)
        : null;
      
      // Create assignment record
      const assignmentData = {
        committeeId: committeeId,
        caseId: caseId,
        auditGroupId: auditGroupId,
        assignmentType: 'COMMITTEE' as const,
        previousAssignmentId: previousAssignment?.id || null,
        reason: null, // Not required for COMMITTEE type
        assignedBy: user.id,
      };
      
      const assignment = await storage.createCommitteeCaseAssignment(assignmentData);
      
      // CRITICAL: Update case with auditGroupId and state change
      // This must happen atomically - all fields updated together
      const updatedCase = await storage.updateCase(caseId, {
        status: COMMITTEE_ASSIGNED_STATUS,
        currentAssignmentId: assignment.id,
        currentAuditGroupId: auditGroupId,
        receivingGroup: auditGroupId, // Update receivingGroup for compatibility
      });
      
      if (!updatedCase) {
        assignments.push({
          success: false,
          errorMessage: `خطا در به‌روزرسانی قضیه ${caseId}`,
        });
        continue;
      }
      
      // Verify the update was successful
      if (updatedCase.currentAuditGroupId !== auditGroupId || 
          updatedCase.receivingGroup !== auditGroupId ||
          updatedCase.status !== COMMITTEE_ASSIGNED_STATUS) {
        console.error('[CASE ASSIGNMENT SERVICE] Case update verification failed', {
          caseId,
          expected: { auditGroupId, status: COMMITTEE_ASSIGNED_STATUS },
          actual: {
            currentAuditGroupId: updatedCase.currentAuditGroupId,
            receivingGroup: updatedCase.receivingGroup,
            status: updatedCase.status,
          },
        });
        assignments.push({
          success: false,
          errorMessage: `قضیه به‌روزرسانی شد اما وضعیت صحیح نیست`,
        });
        continue;
      }
      
      // Audit logging (IP will be set by route)
      try {
        await storage.createAuditLog({
          userId: user.id,
          action: 'assign_case_via_committee',
          entityType: 'case',
          entityId: caseId,
          details: {
            committeeId: committeeId,
            committeeTitle: committee.title,
            auditGroupId: auditGroupId,
            auditGroupName: auditGroup.name,
            previousAssignmentId: previousAssignment?.id,
            caseId: caseItem.caseId,
          },
          ipAddress: undefined, // Will be set by route
        });
      } catch (auditError) {
        // Log but don't fail assignment if audit logging fails
        console.error('[CASE ASSIGNMENT SERVICE] Error logging assignment:', auditError);
      }
      
      assignments.push({
        success: true,
        assignmentId: assignment.id,
        case: updatedCase,
      });
    } catch (error: any) {
      console.error(`[CASE ASSIGNMENT SERVICE] Error assigning case ${caseId}:`, error);
      assignments.push({
        success: false,
        errorMessage: error?.message || `خطا در اختصاص قضیه ${caseId}`,
      });
    }
  }
  
  const allSuccessful = assignments.every(a => a.success);
  
  return {
    success: allSuccessful,
    assignments,
    errorMessage: allSuccessful ? undefined : 'برخی از اختصاصات با خطا مواجه شدند',
  };
}

/**
 * Direct assignment of a case to an audit group (without committee)
 * Creates assignment record with type "DIRECT"
 */
export async function assignCaseDirectly(
  caseId: string,
  auditGroupId: string,
  reason: string,
  user: User
): Promise<AssignmentResult> {
  // Validate case
  const caseItem = await storage.getCase(caseId);
  if (!caseItem) {
    return {
      success: false,
      errorMessage: 'Case not found',
    };
  }
  
  // Check eligibility
  const eligibility = isCaseEligibleForAssignment(caseItem);
  if (!eligibility.eligible) {
    return {
      success: false,
      errorMessage: eligibility.reason || 'Case is not eligible for assignment',
    };
  }
  
  // Validate audit group
  const auditGroup = await storage.getGroup(auditGroupId);
  if (!auditGroup) {
    return {
      success: false,
      errorMessage: 'گروه بررسی یافت نشد',
    };
  }
  
  // Validate reason (required for DIRECT assignment)
  if (!reason || reason.trim() === '') {
    return {
      success: false,
      errorMessage: 'دلیل اختصاص مستقیم الزامی است',
    };
  }
  
  // Get previous assignment if exists
  const previousAssignment = caseItem.currentAssignmentId
    ? await storage.getCommitteeCaseAssignment(caseItem.currentAssignmentId)
    : null;
  
  // Create assignment record
  const assignmentData = {
    committeeId: null,
    caseId: caseId,
    auditGroupId: auditGroupId,
    assignmentType: 'DIRECT' as const,
    previousAssignmentId: previousAssignment?.id || null,
    reason: reason,
    assignedBy: user.id,
  };
  
  try {
    const assignment = await storage.createCommitteeCaseAssignment(assignmentData);
    
    // Update case status to "اختصاص داده شده" (ASSIGNED)
    const updatedCase = await storage.updateCase(caseId, {
      status: COMMITTEE_ASSIGNED_STATUS, // 'اختصاص داده شده' (ASSIGNED)
      currentAssignmentId: assignment.id,
      currentAuditGroupId: auditGroupId,
      receivingGroup: auditGroupId,
    });
    
    if (!updatedCase) {
      return {
        success: false,
        errorMessage: 'خطا در به‌روزرسانی قضیه',
      };
    }
    
    // Audit logging (IP will be set by route)
    try {
      await storage.createAuditLog({
        userId: user.id,
        action: 'assign_case_directly',
        entityType: 'case',
        entityId: caseId,
        details: {
          auditGroupId: auditGroupId,
          auditGroupName: auditGroup.name,
          reason: reason,
          previousAssignmentId: previousAssignment?.id,
          caseId: caseItem.caseId,
        },
        ipAddress: undefined,
      });
    } catch (auditError) {
      console.error('[CASE ASSIGNMENT SERVICE] Error logging direct assignment:', auditError);
    }
    
    return {
      success: true,
      assignmentId: assignment.id,
      case: updatedCase,
    };
  } catch (error: any) {
    console.error('[CASE ASSIGNMENT SERVICE] Error in direct assignment:', error);
    return {
      success: false,
      errorMessage: error?.message || 'خطا در اختصاص قضیه',
    };
  }
}

/**
 * Get assignment history for a case
 * Returns all assignment records for the case, ordered by assigned_at DESC
 */
export async function getCaseAssignmentHistory(caseId: string): Promise<AssignmentHistory[]> {
  try {
    const assignments = await storage.getCaseAssignmentHistory(caseId);
    
    // Enrich with committee and group names
    const history: AssignmentHistory[] = [];
    
    for (const assignment of assignments) {
      let committeeTitle: string | undefined;
      if (assignment.committeeId) {
        const committee = await storage.getCommitteeNew(assignment.committeeId);
        committeeTitle = committee?.title;
      }
      
      const auditGroup = await storage.getGroup(assignment.auditGroupId);
      const auditGroupName = auditGroup?.name;
      
      const assignedByUser = await storage.getUser(assignment.assignedBy);
      const assignedByName = assignedByUser?.fullName;
      
      history.push({
        assignmentId: assignment.id,
        committeeId: assignment.committeeId || undefined,
        committeeTitle,
        auditGroupId: assignment.auditGroupId,
        auditGroupName,
        assignmentType: assignment.assignmentType as 'COMMITTEE' | 'DIRECT' | 'REASSIGNMENT',
        previousAssignmentId: assignment.previousAssignmentId || undefined,
        reason: assignment.reason || undefined,
        assignedBy: assignment.assignedBy,
        assignedByName,
        assignedAt: assignment.assignedAt,
      });
    }
    
    return history;
  } catch (error) {
    console.error('[CASE ASSIGNMENT SERVICE] Error loading assignment history:', error);
    throw error;
  }
}

/**
 * Reassign a case to a different audit group via committee
 * Creates new assignment record with type "REASSIGNMENT"
 */
export async function reassignCaseViaCommittee(
  committeeId: string,
  caseId: string,
  newAuditGroupId: string,
  reason: string,
  user: User
): Promise<AssignmentResult> {
  // Validate committee
  const committee = await storage.getCommitteeNew(committeeId);
  if (!committee) {
    return {
      success: false,
      errorMessage: 'کمیته یافت نشد',
    };
  }
  
  if (committee.status !== 'APPROVED') {
    return {
      success: false,
      errorMessage: `نمی‌توان قضایا را از طریق کمیته با وضعیت ${committee.status} مجدداً اختصاص داد. فقط کمیته‌های تایید شده می‌توانند اختصاصات را بپذیرند.`,
    };
  }
  
  // Validate case
  const caseItem = await storage.getCase(caseId);
  if (!caseItem) {
    return {
      success: false,
      errorMessage: 'Case not found',
    };
  }
  
  // Validate reason (required for REASSIGNMENT)
  if (!reason || reason.trim() === '') {
    return {
      success: false,
      errorMessage: 'دلیل اختصاص مجدد الزامی است',
    };
  }
  
  // Validate new audit group
  const auditGroup = await storage.getGroup(newAuditGroupId);
  if (!auditGroup) {
    return {
      success: false,
      errorMessage: 'گروه بررسی یافت نشد',
    };
  }
  
  // Get current assignment
  if (!caseItem.currentAssignmentId) {
    return {
      success: false,
      errorMessage: 'قضیه اختصاص فعلی ندارد که بتوان از آن مجدداً اختصاص داد',
    };
  }
  
  const previousAssignment = await storage.getCommitteeCaseAssignment(caseItem.currentAssignmentId);
  if (!previousAssignment) {
    return {
      success: false,
      errorMessage: 'رکورد اختصاص قبلی یافت نشد',
    };
  }
  
  // Create reassignment record
  const assignmentData = {
    committeeId: committeeId,
    caseId: caseId,
    auditGroupId: newAuditGroupId,
    assignmentType: 'REASSIGNMENT' as const,
    previousAssignmentId: previousAssignment.id,
    reason: reason,
    assignedBy: user.id,
  };
  
  try {
    const assignment = await storage.createCommitteeCaseAssignment(assignmentData);
    
    // Update case
    const updatedCase = await storage.updateCase(caseId, {
      status: COMMITTEE_ASSIGNED_STATUS, // 'اختصاص داده شده' (ASSIGNED)
      currentAssignmentId: assignment.id,
      currentAuditGroupId: newAuditGroupId,
      receivingGroup: newAuditGroupId,
    });
    
    if (!updatedCase) {
      return {
        success: false,
        errorMessage: 'خطا در به‌روزرسانی قضیه',
      };
    }
    
    // Audit logging (IP will be set by route)
    try {
      await storage.createAuditLog({
        userId: user.id,
        action: 'reassign_case_via_committee',
        entityType: 'case',
        entityId: caseId,
        details: {
          committeeId: committeeId,
          committeeTitle: committee.title,
          newAuditGroupId: newAuditGroupId,
          newAuditGroupName: auditGroup.name,
          previousAssignmentId: previousAssignment.id,
          reason: reason,
          caseId: caseItem.caseId,
        },
        ipAddress: undefined,
      });
    } catch (auditError) {
      console.error('[CASE ASSIGNMENT SERVICE] Error logging reassignment:', auditError);
    }
    
    return {
      success: true,
      assignmentId: assignment.id,
      case: updatedCase,
    };
  } catch (error: any) {
    console.error('[CASE ASSIGNMENT SERVICE] Error in reassignment:', error);
    return {
      success: false,
      errorMessage: error?.message || 'خطا در اختصاص مجدد قضیه',
    };
  }
}

