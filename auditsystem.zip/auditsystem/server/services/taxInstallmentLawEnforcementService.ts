/**
 * Tax Installment and Law Enforcement Report Service
 * Aggregates data for cases with installment and law enforcement statuses
 */

import { storage } from '../storage';
import { db } from '../db';
import { cases, caseReports, caseReportsV2, groups, CaseStatus } from '@shared/schema';
import { eq } from 'drizzle-orm';
import jalaali from 'jalaali-js';
import type { Case } from '@shared/schema';

export type ReportType = 'yearly' | '3-month';

export interface MonthlyCaseData {
  month: number; // Solar Hijri month (1-12)
  installmentCases: {
    total: number;
    completed: number;
    pending: number;
    amountFixed: number;
  };
  lawEnforcementCases: {
    total: number;
    completed: number;
    pending: number;
    amountFixed: number;
  };
}

export interface GroupMonthlyData {
  groupId: string;
  groupName: string;
  monthlyData: MonthlyCaseData[];
}

export interface TaxInstallmentLawEnforcementReport {
  reportType: ReportType;
  year: number; // Solar Hijri year
  quarter?: number; // 1-4, only for 3-month reports
  summary: {
    totalInstallmentCases: number;
    completedInstallmentCases: number;
    pendingInstallmentCases: number;
    totalInstallmentAmountFixed: number;
    totalLawEnforcementCases: number;
    completedLawEnforcementCases: number;
    pendingLawEnforcementCases: number;
    totalLawEnforcementAmountFixed: number;
  };
  byGroup: GroupMonthlyData[];
  monthlyTrends: MonthlyCaseData[]; // Aggregated across all groups
}

/**
 * Convert Gregorian date to Solar Hijri year
 */
function getShamsiYear(date: Date): number {
  const j = jalaali.toJalaali(date);
  return j.jy;
}

/**
 * Convert Gregorian date to Solar Hijri month
 */
function getShamsiMonth(date: Date): number {
  const j = jalaali.toJalaali(date);
  return j.jm;
}

/**
 * Parse numeric value from string or number, handling commas and nulls
 */
function parseNumericValue(value: string | number | null | undefined): number {
  if (value === null || value === undefined) return 0;
  if (typeof value === 'number') return value;
  if (typeof value === 'string') {
    const cleaned = value.replace(/,/g, '').trim();
    const parsed = parseFloat(cleaned);
    return isNaN(parsed) ? 0 : parsed;
  }
  return 0;
}

/**
 * Get confirmed amount from case report (checks both caseReports and caseReportsV2)
 */
async function getConfirmedAmount(caseId: string): Promise<number> {
  // Try caseReportsV2 first (newer format)
  const [reportV2] = await db
    .select()
    .from(caseReportsV2)
    .where(eq(caseReportsV2.caseId, caseId))
    .limit(1);

  if (reportV2?.confirmedAmount) {
    return parseNumericValue(reportV2.confirmedAmount);
  }

  // Fallback to caseReports (legacy format)
  const [report] = await db
    .select()
    .from(caseReports)
    .where(eq(caseReports.caseId, caseId))
    .limit(1);

  if (report?.confirmedAmount) {
    return parseNumericValue(report.confirmedAmount);
  }

  return 0;
}

/**
 * Get months for a given quarter
 */
function getQuarterMonths(quarter: number): number[] {
  switch (quarter) {
    case 1:
      return [1, 2, 3];
    case 2:
      return [4, 5, 6];
    case 3:
      return [7, 8, 9];
    case 4:
      return [10, 11, 12];
    default:
      throw new Error(`Invalid quarter: ${quarter}. Must be 1-4.`);
  }
}

/**
 * Get all cases for a given period (year or quarter)
 * Filters by installment and law enforcement statuses
 */
async function getFilteredCases(
  yearShamsi: number,
  reportType: ReportType,
  quarter?: number
): Promise<Case[]> {
  // Calculate date range
  let startDate: Date;
  let endDate: Date;

  if (reportType === '3-month' && quarter) {
    const quarterMonths = getQuarterMonths(quarter);
    const firstMonth = quarterMonths[0];
    const lastMonth = quarterMonths[quarterMonths.length - 1];

    const quarterStartGregorian = jalaali.toGregorian(yearShamsi, firstMonth, 1);
    let quarterEndGregorian = jalaali.toGregorian(yearShamsi, lastMonth, 30);
    if (quarterEndGregorian.gd === 0) {
      quarterEndGregorian = jalaali.toGregorian(yearShamsi, lastMonth, 29);
    }

    startDate = new Date(quarterStartGregorian.gy, quarterStartGregorian.gm - 1, quarterStartGregorian.gd);
    endDate = new Date(quarterEndGregorian.gy, quarterEndGregorian.gm - 1, quarterEndGregorian.gd);
    endDate.setDate(endDate.getDate() + 1);
  } else {
    // Yearly report
    const yearStartGregorian = jalaali.toGregorian(yearShamsi, 1, 1);
    let yearEndGregorian = jalaali.toGregorian(yearShamsi, 12, 30);
    if (yearEndGregorian.gd === 0) {
      yearEndGregorian = jalaali.toGregorian(yearShamsi, 12, 29);
    }

    startDate = new Date(yearStartGregorian.gy, yearStartGregorian.gm - 1, yearStartGregorian.gd);
    endDate = new Date(yearEndGregorian.gy, yearEndGregorian.gm - 1, yearEndGregorian.gd);
    endDate.setDate(endDate.getDate() + 1);
  }

  // Get all cases
  const allCases = await storage.getCases();

  // Filter by status (installment or law enforcement) and date range
  const filteredCases = allCases.filter(c => {
    // Check if case has installment or law enforcement status
    const isInstallment = c.status === CaseStatus.INSTALLMENT || c.status === 'در اقساط';
    const isLawEnforcement = 
      c.status === CaseStatus.SENT_TO_LAW_ENFORCEMENT || 
      c.status === 'ارسال‌شده به تنفیذ قانون' ||
      c.status === CaseStatus.REFERRED_TO_ENFORCEMENT ||
      c.status === 'ارسال‌ شده به تنفیذ قانون';

    if (!isInstallment && !isLawEnforcement) {
      return false;
    }

    // Check if case was created or completed in the period
    if (c.createdAt) {
      const createdDate = new Date(c.createdAt);
      if (createdDate >= startDate && createdDate < endDate) {
        return true;
      }
    }

    if (c.completedAt) {
      const completedDate = new Date(c.completedAt);
      if (completedDate >= startDate && completedDate < endDate) {
        return true;
      }
    }

    // Also check if case transitioned to these statuses in the period
    // (This would require checking case_status_transitions table, but for now we'll use created/completed dates)
    return false;
  });

  return filteredCases;
}

/**
 * Aggregate tax installment and law enforcement report data
 */
export async function getTaxInstallmentLawEnforcementReport(
  yearShamsi: number,
  reportType: ReportType,
  quarter?: number
): Promise<TaxInstallmentLawEnforcementReport> {
  // Validate quarter if 3-month report
  if (reportType === '3-month') {
    if (!quarter || quarter < 1 || quarter > 4) {
      throw new Error('Quarter is required for 3-month reports and must be 1-4');
    }
  }

  // Get filtered cases
  const filteredCases = await getFilteredCases(yearShamsi, reportType, quarter);

  // Get all groups for name lookup
  const allGroups = await storage.getGroups();
  const groupMap = new Map(allGroups.map(g => [g.id, g]));

  // Determine which months to include
  const monthsToInclude = reportType === '3-month' && quarter
    ? getQuarterMonths(quarter)
    : [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12];

  // Initialize data structures
  const groupMonthlyMap = new Map<string, Map<number, MonthlyCaseData>>(); // Key: groupId, Value: Map<month, data>
  const monthlyTrendsMap = new Map<number, MonthlyCaseData>(); // Key: month

  // Initialize monthly data for all months
  for (const month of monthsToInclude) {
    monthlyTrendsMap.set(month, {
      month,
      installmentCases: { total: 0, completed: 0, pending: 0, amountFixed: 0 },
      lawEnforcementCases: { total: 0, completed: 0, pending: 0, amountFixed: 0 },
    });
  }

  // Process each case
  for (const caseItem of filteredCases) {
    const groupId = caseItem.receivingGroup;
    if (!groupId) continue;

    const group = groupMap.get(groupId);
    const groupName = group?.name || groupId;

    // Determine which month to use for aggregation
    let aggregationDate: Date | null = null;
    let aggregationMonth: number | null = null;

    if (caseItem.completedAt) {
      aggregationDate = new Date(caseItem.completedAt);
      aggregationMonth = getShamsiMonth(aggregationDate);
    } else if (caseItem.createdAt) {
      aggregationDate = new Date(caseItem.createdAt);
      aggregationMonth = getShamsiMonth(aggregationDate);
    }

    // Only process if we have a valid month
    if (!aggregationMonth || !monthsToInclude.includes(aggregationMonth)) {
      continue;
    }

    // Verify the month is in the correct year
    if (aggregationDate) {
      const caseYear = getShamsiYear(aggregationDate);
      if (caseYear !== yearShamsi) {
        continue;
      }
    }

    // Initialize group monthly map if needed
    if (!groupMonthlyMap.has(groupId)) {
      const monthMap = new Map<number, MonthlyCaseData>();
      for (const month of monthsToInclude) {
        monthMap.set(month, {
          month,
          installmentCases: { total: 0, completed: 0, pending: 0, amountFixed: 0 },
          lawEnforcementCases: { total: 0, completed: 0, pending: 0, amountFixed: 0 },
        });
      }
      groupMonthlyMap.set(groupId, monthMap);
    }

    const groupMonthMap = groupMonthlyMap.get(groupId)!;
    const monthlyData = groupMonthMap.get(aggregationMonth)!;
    const monthlyTrend = monthlyTrendsMap.get(aggregationMonth)!;

    // Determine case type
    const isInstallment = caseItem.status === CaseStatus.INSTALLMENT || caseItem.status === 'در اقساط';
    const isLawEnforcement = 
      caseItem.status === CaseStatus.SENT_TO_LAW_ENFORCEMENT || 
      caseItem.status === 'ارسال‌شده به تنفیذ قانون' ||
      caseItem.status === CaseStatus.REFERRED_TO_ENFORCEMENT ||
      caseItem.status === 'ارسال‌ شده به تنفیذ قانون';

    // Check if case is completed
    const isCompleted = caseItem.status === 'تکمیل شده' || caseItem.status === 'COMPLETED' || caseItem.completedAt !== null;

    if (isInstallment) {
      // Update installment counts
      monthlyData.installmentCases.total++;
      monthlyTrend.installmentCases.total++;

      if (isCompleted) {
        monthlyData.installmentCases.completed++;
        monthlyTrend.installmentCases.completed++;

        const confirmedAmount = await getConfirmedAmount(caseItem.id);
        monthlyData.installmentCases.amountFixed += confirmedAmount;
        monthlyTrend.installmentCases.amountFixed += confirmedAmount;
      } else {
        monthlyData.installmentCases.pending++;
        monthlyTrend.installmentCases.pending++;
      }
    } else if (isLawEnforcement) {
      // Update law enforcement counts
      monthlyData.lawEnforcementCases.total++;
      monthlyTrend.lawEnforcementCases.total++;

      if (isCompleted) {
        monthlyData.lawEnforcementCases.completed++;
        monthlyTrend.lawEnforcementCases.completed++;

        const confirmedAmount = await getConfirmedAmount(caseItem.id);
        monthlyData.lawEnforcementCases.amountFixed += confirmedAmount;
        monthlyTrend.lawEnforcementCases.amountFixed += confirmedAmount;
      } else {
        monthlyData.lawEnforcementCases.pending++;
        monthlyTrend.lawEnforcementCases.pending++;
      }
    }
  }

  // Build byGroup array
  const byGroup: GroupMonthlyData[] = [];
  for (const [groupId, monthMap] of groupMonthlyMap.entries()) {
    const group = groupMap.get(groupId);
    const groupName = group?.name || groupId;

    const monthlyData = Array.from(monthMap.values()).sort((a, b) => a.month - b.month);
    byGroup.push({
      groupId,
      groupName,
      monthlyData,
    });
  }

  // Sort by group name
  byGroup.sort((a, b) => a.groupName.localeCompare(b.groupName));

  // Build monthly trends array
  const monthlyTrends = Array.from(monthlyTrendsMap.values()).sort((a, b) => a.month - b.month);

  // Calculate summary totals
  const summary = {
    totalInstallmentCases: monthlyTrends.reduce((sum, m) => sum + m.installmentCases.total, 0),
    completedInstallmentCases: monthlyTrends.reduce((sum, m) => sum + m.installmentCases.completed, 0),
    pendingInstallmentCases: monthlyTrends.reduce((sum, m) => sum + m.installmentCases.pending, 0),
    totalInstallmentAmountFixed: monthlyTrends.reduce((sum, m) => sum + m.installmentCases.amountFixed, 0),
    totalLawEnforcementCases: monthlyTrends.reduce((sum, m) => sum + m.lawEnforcementCases.total, 0),
    completedLawEnforcementCases: monthlyTrends.reduce((sum, m) => sum + m.lawEnforcementCases.completed, 0),
    pendingLawEnforcementCases: monthlyTrends.reduce((sum, m) => sum + m.lawEnforcementCases.pending, 0),
    totalLawEnforcementAmountFixed: monthlyTrends.reduce((sum, m) => sum + m.lawEnforcementCases.amountFixed, 0),
  };

  return {
    reportType,
    year: yearShamsi,
    quarter: reportType === '3-month' ? quarter : undefined,
    summary,
    byGroup,
    monthlyTrends,
  };
}

