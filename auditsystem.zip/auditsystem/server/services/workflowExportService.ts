/**
 * Workflow Export Service
 * Handles Excel and PDF exports for InternalReport and MinistrySummary
 * All data comes from workflow tables only (no master entity table modifications)
 */

import ExcelJS from "exceljs";
import PDFDocument from "pdfkit";
import { getInternalReportsForMonth, getMinistrySummariesForMonth } from "./workflowService";
import { getEntityAlerts, getGroupAlerts } from "./workflowService";
import { db } from "../db";
import { internalReport, ministrySummary } from "@shared/schema";
import { sql } from "drizzle-orm";

/**
 * Month names in Dari
 */
const MONTH_NAMES = ['', 'حمل', 'ثور', 'جوزا', 'سرطان', 'اسد', 'سنبله', 'میزان', 'عقرب', 'قوس', 'جدی', 'دلو', 'حوت'];

/**
 * Format number with thousand separators
 */
function formatNumber(value: string | number | null | undefined): string {
  if (value === null || value === undefined) return '0';
  const num = typeof value === 'string' ? parseFloat(value) : value;
  if (isNaN(num)) return '0';
  return num.toLocaleString('en-US');
}

/**
 * Export InternalReport to Excel
 */
export async function exportInternalReportToExcel(
  monthShamsi: number,
  yearShamsi: number
): Promise<ExcelJS.Buffer> {
  const monthName = MONTH_NAMES[monthShamsi] || monthShamsi.toString();
  
  // Get all internal reports for the month/year
  const reports = await getInternalReportsForMonth(monthShamsi, yearShamsi);
  
  // Get monthly totals from view
  const totalsResult = await db.execute(sql`
    SELECT * FROM internal_report_monthly_totals 
    WHERE month_shamsi = ${monthShamsi} AND year_shamsi = ${yearShamsi}
  `);
  const totals = (Array.isArray(totalsResult) && totalsResult.length > 0) 
    ? totalsResult[0] 
    : (totalsResult.rows && totalsResult.rows.length > 0) 
      ? totalsResult.rows[0] 
      : null;
  
  // Create workbook
  const workbook = new ExcelJS.Workbook();
  const worksheet = workbook.addWorksheet('گزارش داخلی');
  
  // Set RTL direction
  worksheet.views = [{ rightToLeft: true }];
  
  // Main header
  const mainHeader = `گزارش داخلی ماهوار - برج ${monthName} سال ${yearShamsi}`;
  worksheet.mergeCells(1, 1, 1, 15);
  const headerCell = worksheet.getCell(1, 1);
  headerCell.value = mainHeader;
  headerCell.font = { name: 'Arial', size: 14, bold: true };
  headerCell.alignment = { horizontal: 'center', vertical: 'middle' };
  headerCell.fill = {
    type: 'pattern',
    pattern: 'solid',
    fgColor: { argb: 'FFE0E0E0' }
  };
  headerCell.height = 30;
  
  // Column headers
  const headers = [
    'نام نهاد',
    'نمبر تشخیصیه',
    'مالیه موضوعی معاشات',
    'مالیه موضوعی بر کرایه',
    'مالیه موضوعی قراردادی',
    'مالیه موضوعی معاملات انتفاعی',
    'مالیات بر عایدات',
    'کل مبلغ قابل مالیات',
    'مبلغ تحصیل شده',
    'مبلغ باقیمانده',
    'مبلغ تثبیت شده',
    'ضرر کاهش یافته',
    'مکتوب های وارده',
    'مکتوب های صادره',
    'استعلام های وارده',
    'استعلام های صادره',
    'ملاحظات',
  ];
  
  const headerRow = worksheet.addRow(headers);
  headerRow.font = { name: 'Arial', size: 11, bold: true };
  headerRow.alignment = { horizontal: 'right', vertical: 'middle' };
  headerRow.fill = {
    type: 'pattern',
    pattern: 'solid',
    fgColor: { argb: 'FFD9D9D9' }
  };
  headerRow.height = 25;
  
  // Add data rows
  for (const report of reports) {
    // Get alerts for this entity
    const alerts = await getEntityAlerts(report.entityTin, monthShamsi, yearShamsi);
    const hasAlert = alerts.some(a => a.status === 'active');
    
    const dataRow = worksheet.addRow([
      report.entityName,
      report.entityTin,
      formatNumber(report.taxSalary),
      formatNumber(report.taxRent),
      formatNumber(report.taxContract),
      formatNumber(report.taxProfit),
      formatNumber(report.incomeTax),
      formatNumber(report.totalTaxableAmount),
      formatNumber(report.collectedAmount),
      formatNumber(report.remainingAmount),
      formatNumber(report.stabilizedAmount),
      formatNumber(report.lossReduction),
      report.correspondencesIn || 0,
      report.correspondencesOut || 0,
      report.inquiriesIn || 0,
      report.inquiriesOut || 0,
      report.notes || '',
    ]);
    
    // Highlight rows with alerts
    if (hasAlert) {
      dataRow.fill = {
        type: 'pattern',
        pattern: 'solid',
        fgColor: { argb: 'FFFFE0E0' } // Light red background
      };
    }
    
    dataRow.eachCell((cell) => {
      cell.alignment = { horizontal: 'right', vertical: 'middle' };
      if (cell.column >= 3 && cell.column <= 12) {
        // Numeric columns
        cell.numFmt = '#,##0.00';
      }
    });
  }
  
  // Add totals row
  if (totals) {
    worksheet.addRow([]);
    const totalsLabelRow = worksheet.addRow(['جمع کل:', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '']);
    totalsLabelRow.font = { name: 'Arial', size: 11, bold: true };
    totalsLabelRow.fill = {
      type: 'pattern',
      pattern: 'solid',
      fgColor: { argb: 'FFC0C0C0' }
    };
    
    // Calculate totals from reports if view doesn't have all fields
    const calculatedTotals = {
      totalTaxSalary: reports.reduce((sum, r) => sum + parseFloat(r.taxSalary || '0'), 0),
      totalTaxRent: reports.reduce((sum, r) => sum + parseFloat(r.taxRent || '0'), 0),
      totalTaxContract: reports.reduce((sum, r) => sum + parseFloat(r.taxContract || '0'), 0),
      totalTaxProfit: reports.reduce((sum, r) => sum + parseFloat(r.taxProfit || '0'), 0),
      totalIncomeTax: reports.reduce((sum, r) => sum + parseFloat(r.incomeTax || '0'), 0),
      totalLossReduction: reports.reduce((sum, r) => sum + parseFloat(r.lossReduction || '0'), 0),
    };
    
    const totalsRow = worksheet.addRow([
      '',
      '',
      formatNumber(calculatedTotals.totalTaxSalary),
      formatNumber(calculatedTotals.totalTaxRent),
      formatNumber(calculatedTotals.totalTaxContract),
      formatNumber(calculatedTotals.totalTaxProfit),
      formatNumber(calculatedTotals.totalIncomeTax),
      formatNumber(totals?.total_taxable_amount || 0),
      formatNumber(totals?.total_collected || 0),
      formatNumber(totals?.total_remaining || 0),
      formatNumber(totals?.total_stabilized || 0),
      formatNumber(calculatedTotals.totalLossReduction),
      totals?.total_correspondences_in || 0,
      totals?.total_correspondences_out || 0,
      totals?.total_inquiries_in || 0,
      totals?.total_inquiries_out || 0,
      '',
    ]);
    
    totalsRow.font = { name: 'Arial', size: 11, bold: true };
    totalsRow.fill = {
      type: 'pattern',
      pattern: 'solid',
      fgColor: { argb: 'FFC0C0C0' }
    };
    
    totalsRow.eachCell((cell) => {
      cell.alignment = { horizontal: 'right', vertical: 'middle' };
      if (cell.column >= 3 && cell.column <= 12) {
        cell.numFmt = '#,##0.00';
      }
    });
  }
  
  // Set column widths
  worksheet.columns = [
    { width: 30 }, // Entity Name
    { width: 15 }, // TIN
    { width: 18 }, // Tax Salary
    { width: 18 }, // Tax Rent
    { width: 18 }, // Tax Contract
    { width: 18 }, // Tax Profit
    { width: 18 }, // Income Tax
    { width: 18 }, // Total Taxable
    { width: 18 }, // Collected
    { width: 18 }, // Remaining
    { width: 18 }, // Stabilized
    { width: 18 }, // Loss Reduction
    { width: 15 }, // Correspondences In
    { width: 15 }, // Correspondences Out
    { width: 15 }, // Inquiries In
    { width: 15 }, // Inquiries Out
    { width: 30 }, // Notes
  ];
  
  // Generate buffer
  const buffer = await workbook.xlsx.writeBuffer();
  return buffer as ExcelJS.Buffer;
}

/**
 * Export InternalReport to PDF
 */
export async function exportInternalReportToPDF(
  monthShamsi: number,
  yearShamsi: number
): Promise<PDFDocument> {
  const monthName = MONTH_NAMES[monthShamsi] || monthShamsi.toString();
  
  // Get all internal reports for the month/year
  const reports = await getInternalReportsForMonth(monthShamsi, yearShamsi);
  
  // Get monthly totals
  const totalsResult = await db.execute(sql`
    SELECT * FROM internal_report_monthly_totals 
    WHERE month_shamsi = ${monthShamsi} AND year_shamsi = ${yearShamsi}
  `);
  const totals = (Array.isArray(totalsResult) && totalsResult.length > 0) 
    ? totalsResult[0] 
    : (totalsResult.rows && totalsResult.rows.length > 0) 
      ? totalsResult.rows[0] 
      : null;
  
  // Create PDF
  const doc = new PDFDocument({ size: 'A4', margin: 30 });
  
  // Header
  doc.fontSize(16).text(`گزارش داخلی ماهوار`, { align: 'right' });
  doc.fontSize(12).text(`برج ${monthName} سال ${yearShamsi}`, { align: 'right' });
  doc.moveDown(2);
  
  // Table header
  doc.fontSize(9).text(
    'نام نهاد | نمبر تشخیصیه | کل مبلغ قابل مالیات | مبلغ تحصیل شده | مبلغ باقیمانده | مبلغ تثبیت شده',
    { align: 'right' }
  );
  doc.moveDown(0.5);
  
  // Data rows
  for (const report of reports) {
    const line = `${report.entityName} | ${report.entityTin} | ${formatNumber(report.totalTaxableAmount)} | ${formatNumber(report.collectedAmount)} | ${formatNumber(report.remainingAmount)} | ${formatNumber(report.stabilizedAmount)}`;
    doc.fontSize(8).text(line, { align: 'right' });
    doc.moveDown(0.3);
    
    if (doc.y > doc.page.height - 50) {
      doc.addPage();
    }
  }
  
  // Totals
  if (reports.length > 0) {
    const calculatedTotals = {
      totalTaxable: reports.reduce((sum, r) => sum + parseFloat(r.totalTaxableAmount || '0'), 0),
      totalCollected: reports.reduce((sum, r) => sum + parseFloat(r.collectedAmount || '0'), 0),
      totalRemaining: reports.reduce((sum, r) => sum + parseFloat(r.remainingAmount || '0'), 0),
      totalStabilized: reports.reduce((sum, r) => sum + parseFloat(r.stabilizedAmount || '0'), 0),
    };
    
    doc.moveDown(1);
    doc.fontSize(10).text('جمع کل:', { align: 'right' });
    doc.fontSize(9).text(
      `${formatNumber(calculatedTotals.totalTaxable)} | ${formatNumber(calculatedTotals.totalCollected)} | ${formatNumber(calculatedTotals.totalRemaining)} | ${formatNumber(calculatedTotals.totalStabilized)}`,
      { align: 'right' }
    );
  }
  
  return doc;
}

/**
 * Export MinistrySummary to Excel
 */
export async function exportMinistrySummaryToExcel(
  monthShamsi: number,
  yearShamsi: number
): Promise<ExcelJS.Buffer> {
  const monthName = MONTH_NAMES[monthShamsi] || monthShamsi.toString();
  
  // Get all ministry summaries for the month/year
  const summaries = await getMinistrySummariesForMonth(monthShamsi, yearShamsi);
  
  // Get ministry totals from view
  const totalsResult = await db.execute(sql`
    SELECT * FROM ministry_summary_monthly_totals 
    WHERE month_shamsi = ${monthShamsi} AND year_shamsi = ${yearShamsi}
  `);
  const totals = (Array.isArray(totalsResult) && totalsResult.length > 0) 
    ? totalsResult[0] 
    : (totalsResult.rows && totalsResult.rows.length > 0) 
      ? totalsResult.rows[0] 
      : null;
  
  // Create workbook
  const workbook = new ExcelJS.Workbook();
  const worksheet = workbook.addWorksheet('گزارش وزارتی');
  
  // Set RTL direction
  worksheet.views = [{ rightToLeft: true }];
  
  // Main header
  const mainHeader = `گزارش وزارتی ماهوار - برج ${monthName} سال ${yearShamsi}`;
  worksheet.mergeCells(1, 1, 1, 14);
  const headerCell = worksheet.getCell(1, 1);
  headerCell.value = mainHeader;
  headerCell.font = { name: 'Arial', size: 14, bold: true };
  headerCell.alignment = { horizontal: 'center', vertical: 'middle' };
  headerCell.fill = {
    type: 'pattern',
    pattern: 'solid',
    fgColor: { argb: 'FFE0E0E0' }
  };
  headerCell.height = 30;
  
  // Column headers
  const headers = [
    'نام گروه',
    'کل نهادها',
    'نهادهای تکمیل شده',
    'نهادهای نیمه مطابق',
    'نهادهای غیرمطابق',
    'درآمد تحصیل شده',
    'هدف درآمد ماهوار',
    'درصد تغییر',
    'مکتوب های وارده',
    'مکتوب های صادره',
    'استعلام های وارده',
    'استعلام های صادره',
    'ملاحظات',
  ];
  
  const headerRow = worksheet.addRow(headers);
  headerRow.font = { name: 'Arial', size: 11, bold: true };
  headerRow.alignment = { horizontal: 'right', vertical: 'middle' };
  headerRow.fill = {
    type: 'pattern',
    pattern: 'solid',
    fgColor: { argb: 'FFD9D9D9' }
  };
  headerRow.height = 25;
  
  // Add data rows
  for (const summary of summaries) {
    // Get alerts for this group
    const alerts = await getGroupAlerts(summary.groupName, monthShamsi, yearShamsi);
    const hasAlert = alerts.some(a => a.status === 'active');
    
    const percentVariation = summary.percentVariation 
      ? `${formatNumber(summary.percentVariation)}%`
      : '—';
    
    const dataRow = worksheet.addRow([
      summary.groupName,
      summary.totalEntities || 0,
      summary.finalizedEntities || 0,
      summary.partiallyCompliantEntities || 0,
      summary.nonCompliantEntities || 0,
      formatNumber(summary.revenueCollected),
      formatNumber(summary.monthlyRevenueTarget),
      percentVariation,
      summary.incomingLetters || 0,
      summary.outgoingLetters || 0,
      summary.incomingInquiries || 0,
      summary.outgoingInquiries || 0,
      summary.notes || '',
    ]);
    
    // Highlight rows with alerts
    if (hasAlert) {
      dataRow.fill = {
        type: 'pattern',
        pattern: 'solid',
        fgColor: { argb: 'FFFFE0E0' } // Light red background
      };
    }
    
    dataRow.eachCell((cell) => {
      cell.alignment = { horizontal: 'right', vertical: 'middle' };
      if (cell.column >= 6 && cell.column <= 7) {
        // Numeric columns
        cell.numFmt = '#,##0.00';
      }
    });
  }
  
  // Add totals row
  if (summaries.length > 0) {
    worksheet.addRow([]);
    const totalsLabelRow = worksheet.addRow(['جمع کل:', '', '', '', '', '', '', '', '', '', '', '', '']);
    totalsLabelRow.font = { name: 'Arial', size: 11, bold: true };
    totalsLabelRow.fill = {
      type: 'pattern',
      pattern: 'solid',
      fgColor: { argb: 'FFC0C0C0' }
    };
    
    // Calculate totals from summaries
    const calculatedTotals = {
      totalEntities: summaries.reduce((sum, s) => sum + (s.totalEntities || 0), 0),
      totalFinalized: summaries.reduce((sum, s) => sum + (s.finalizedEntities || 0), 0),
      totalPartiallyCompliant: summaries.reduce((sum, s) => sum + (s.partiallyCompliantEntities || 0), 0),
      totalNonCompliant: summaries.reduce((sum, s) => sum + (s.nonCompliantEntities || 0), 0),
      totalRevenueCollected: summaries.reduce((sum, s) => sum + parseFloat(s.revenueCollected || '0'), 0),
      totalRevenueTarget: summaries.reduce((sum, s) => sum + parseFloat(s.monthlyRevenueTarget || '0'), 0),
      totalIncomingLetters: summaries.reduce((sum, s) => sum + (s.incomingLetters || 0), 0),
      totalOutgoingLetters: summaries.reduce((sum, s) => sum + (s.outgoingLetters || 0), 0),
      totalIncomingInquiries: summaries.reduce((sum, s) => sum + (s.incomingInquiries || 0), 0),
      totalOutgoingInquiries: summaries.reduce((sum, s) => sum + (s.outgoingInquiries || 0), 0),
    };
    
    const overallPercentVariation = calculatedTotals.totalRevenueTarget > 0
      ? `${((calculatedTotals.totalRevenueCollected / calculatedTotals.totalRevenueTarget) * 100).toFixed(2)}%`
      : '—';
    
    const totalsRow = worksheet.addRow([
      '',
      calculatedTotals.totalEntities,
      calculatedTotals.totalFinalized,
      calculatedTotals.totalPartiallyCompliant,
      calculatedTotals.totalNonCompliant,
      formatNumber(calculatedTotals.totalRevenueCollected),
      formatNumber(calculatedTotals.totalRevenueTarget),
      overallPercentVariation,
      calculatedTotals.totalIncomingLetters,
      calculatedTotals.totalOutgoingLetters,
      calculatedTotals.totalIncomingInquiries,
      calculatedTotals.totalOutgoingInquiries,
      '',
    ]);
    
    totalsRow.font = { name: 'Arial', size: 11, bold: true };
    totalsRow.fill = {
      type: 'pattern',
      pattern: 'solid',
      fgColor: { argb: 'FFC0C0C0' }
    };
    
    totalsRow.eachCell((cell) => {
      cell.alignment = { horizontal: 'right', vertical: 'middle' };
      if (cell.column >= 6 && cell.column <= 7) {
        cell.numFmt = '#,##0.00';
      }
    });
  }
  
  // Set column widths
  worksheet.columns = [
    { width: 30 }, // Group Name
    { width: 12 }, // Total Entities
    { width: 18 }, // Finalized Entities
    { width: 18 }, // Partially Compliant
    { width: 18 }, // Non-Compliant
    { width: 18 }, // Revenue Collected
    { width: 18 }, // Revenue Target
    { width: 15 }, // Percent Variation
    { width: 15 }, // Incoming Letters
    { width: 15 }, // Outgoing Letters
    { width: 15 }, // Incoming Inquiries
    { width: 15 }, // Outgoing Inquiries
    { width: 30 }, // Notes
  ];
  
  // Generate buffer
  const buffer = await workbook.xlsx.writeBuffer();
  return buffer as ExcelJS.Buffer;
}

/**
 * Export MinistrySummary to PDF
 */
export async function exportMinistrySummaryToPDF(
  monthShamsi: number,
  yearShamsi: number
): Promise<PDFDocument> {
  const monthName = MONTH_NAMES[monthShamsi] || monthShamsi.toString();
  
  // Get all ministry summaries for the month/year
  const summaries = await getMinistrySummariesForMonth(monthShamsi, yearShamsi);
  
  // Get ministry totals
  const totalsResult = await db.execute(sql`
    SELECT * FROM ministry_summary_monthly_totals 
    WHERE month_shamsi = ${monthShamsi} AND year_shamsi = ${yearShamsi}
  `);
  const totals = (Array.isArray(totalsResult) && totalsResult.length > 0) 
    ? totalsResult[0] 
    : (totalsResult.rows && totalsResult.rows.length > 0) 
      ? totalsResult.rows[0] 
      : null;
  
  // Create PDF
  const doc = new PDFDocument({ size: 'A4', margin: 30 });
  
  // Header
  doc.fontSize(16).text(`گزارش وزارتی ماهوار`, { align: 'right' });
  doc.fontSize(12).text(`برج ${monthName} سال ${yearShamsi}`, { align: 'right' });
  doc.moveDown(2);
  
  // Table header
  doc.fontSize(9).text(
    'نام گروه | کل نهادها | درآمد تحصیل شده | هدف درآمد | درصد تغییر',
    { align: 'right' }
  );
  doc.moveDown(0.5);
  
  // Data rows
  for (const summary of summaries) {
    const percentVariation = summary.percentVariation 
      ? `${formatNumber(summary.percentVariation)}%`
      : '—';
    
    const line = `${summary.groupName} | ${summary.totalEntities || 0} | ${formatNumber(summary.revenueCollected)} | ${formatNumber(summary.monthlyRevenueTarget)} | ${percentVariation}`;
    doc.fontSize(8).text(line, { align: 'right' });
    doc.moveDown(0.3);
    
    if (doc.y > doc.page.height - 50) {
      doc.addPage();
    }
  }
  
  // Totals
  if (summaries.length > 0) {
    const calculatedTotals = {
      totalEntities: summaries.reduce((sum, s) => sum + (s.totalEntities || 0), 0),
      totalRevenueCollected: summaries.reduce((sum, s) => sum + parseFloat(s.revenueCollected || '0'), 0),
      totalRevenueTarget: summaries.reduce((sum, s) => sum + parseFloat(s.monthlyRevenueTarget || '0'), 0),
    };
    
    const overallPercentVariation = calculatedTotals.totalRevenueTarget > 0
      ? `${((calculatedTotals.totalRevenueCollected / calculatedTotals.totalRevenueTarget) * 100).toFixed(2)}%`
      : '—';
    
    doc.moveDown(1);
    doc.fontSize(10).text('جمع کل:', { align: 'right' });
    doc.fontSize(9).text(
      `${calculatedTotals.totalEntities} | ${formatNumber(calculatedTotals.totalRevenueCollected)} | ${formatNumber(calculatedTotals.totalRevenueTarget)} | ${overallPercentVariation}`,
      { align: 'right' }
    );
  }
  
  return doc;
}

