/**
 * Report Validation Service
 * Validates that all required reporting fields are filled before case completion
 */

import { Case, Entity } from '@shared/schema';
import { storage } from '../storage';

export interface ReportValidationResult {
  isValid: boolean;
  missingFields: string[];
  errorMessage?: string;
}

/**
 * Required fields for مشخصات نهاد section
 */
const REQUIRED_ENTITY_FIELDS = [
  'companyName', // نام نهاد
  'tin', // نمبر تشخیصیه
  'businessNature', // نوع تشبث
  'groupReferrer', // آمریت ارجاع کننده
  'referralDate', // تاریخ ارجاع شده
  'periodsUnderReview', // سالهای بررسی
] as const;

/**
 * Required fields for بیرون نویسی section
 * Note: Financial fields may be 0 if activity status is "عدم فعالیت"
 */
const REQUIRED_FINANCIAL_FIELDS = [
  'transactionId', // نمبر تراکنش پرداخت مالیات (نمبر آویز)
  'paymentDate', // تاریخ پرداخت مالیات
] as const;

/**
 * Optional but recommended fields
 */
const RECOMMENDED_FIELDS = [
  'notes', // ملاحظات
] as const;

/**
 * Validate that a case has all required reporting fields filled
 */
export async function validateCaseReportCompletion(
  caseItem: Case,
  allowOverride: boolean = false
): Promise<ReportValidationResult> {
  const missingFields: string[] = [];

  // Validate مشخصات نهاد section (from case/entity)
  if (!caseItem.companyName || caseItem.companyName.trim() === '') {
    missingFields.push('نام نهاد');
  }
  if (!caseItem.tin || caseItem.tin.trim() === '') {
    missingFields.push('نمبر تشخیصیه');
  }
  if (!caseItem.businessNature || caseItem.businessNature.trim() === '') {
    missingFields.push('نوع تشبث');
  }
  if (!caseItem.groupReferrer || caseItem.groupReferrer.trim() === '') {
    missingFields.push('آمریت ارجاع کننده');
  }
  if (!caseItem.referralDate || caseItem.referralDate.trim() === '') {
    missingFields.push('تاریخ ارجاع شده');
  }
  if (!caseItem.periodsUnderReview || caseItem.periodsUnderReview.trim() === '') {
    missingFields.push('سالهای بررسی');
  }

  // Get case report to validate additional fields
  const caseReport = await storage.getCaseReport(caseItem.id);

  // Validate Section 1 additional fields
  if (!caseReport?.finalDocumentDate || caseReport.finalDocumentDate.trim() === '') {
    missingFields.push('تاریخ صادره مکتوب نهایی');
  }
  if (!caseReport?.capitalPeriod || caseReport.capitalPeriod.trim() === '') {
    missingFields.push('دوران سرمایه');
  }

  // Validate Section 2: بیرون‌نویسی‌ها
  if (!caseReport?.salaryTax || caseReport.salaryTax.trim() === '') {
    missingFields.push('مالیه موضوعی معاشات');
  }
  if (!caseReport?.rentTax || caseReport.rentTax.trim() === '') {
    missingFields.push('مالیه موضوعی بر کرایه');
  }
  if (!caseReport?.contractTax || caseReport.contractTax.trim() === '') {
    missingFields.push('مالیه موضوعی قراردادی');
  }
  if (!caseReport?.profitTransactionTax || caseReport.profitTransactionTax.trim() === '') {
    missingFields.push('مالیات معاملات انتفاعی');
  }
  if (!caseReport?.incomeTax || caseReport.incomeTax.trim() === '') {
    missingFields.push('مالیات بر عایدات');
  }
  if (!caseReport?.reducedLoss || caseReport.reducedLoss.trim() === '') {
    missingFields.push('ضرر کاهش یافته');
  }
  if (!caseReport?.reducedRemainingAmount || caseReport.reducedRemainingAmount.trim() === '') {
    missingFields.push('مبلغ فاضل تحویل کاهش یافته');
  }
  if (!caseReport?.confirmedAmount || caseReport.confirmedAmount.trim() === '') {
    missingFields.push('مبلغ تثبیت شده');
  }
  if (!caseReport?.collectedCurrentMonth || caseReport.collectedCurrentMonth.trim() === '') {
    missingFields.push('مبلغ تحصیل شده طی برج جاری');
  }
  if (!caseReport?.remainingCollectible || caseReport.remainingCollectible.trim() === '') {
    missingFields.push('الباقی مبلغ قابل تحصیل');
  }
  if (!caseReport?.activityStatus || caseReport.activityStatus.trim() === '') {
    missingFields.push('وضعیت فعالیت');
  }
  if (!caseReport?.attachmentNumber || caseReport.attachmentNumber.trim() === '') {
    missingFields.push('نمبر آویز');
  }
  if (!caseReport?.attachmentDate || caseReport.attachmentDate.trim() === '') {
    missingFields.push('تاریخ آویز');
  }

  // If override is allowed (Senior Auditor/Director), return warning but allow
  if (allowOverride && missingFields.length > 0) {
    return {
      isValid: true,
      missingFields,
      errorMessage: `توجه: برخی فیلدهای گزارش تکمیل نشده است: ${missingFields.join('، ')}. با توجه به دسترسی شما، می‌توانید ادامه دهید.`,
    };
  }

  // If fields are missing and no override, block completion
  if (missingFields.length > 0) {
    return {
      isValid: false,
      missingFields,
      errorMessage: `گزارش تکمیل نشده است. لطفاً تمام معلومات لازم گزارش را درج نمایید. فیلدهای ناقص: ${missingFields.join('، ')}`,
    };
  }

  return {
    isValid: true,
    missingFields: [],
  };
}

/**
 * Check if user has permission to override validation
 * Uses the reports:override_complete permission
 */
export async function canOverrideValidation(user: any): Promise<boolean> {
  if (!user) return false;
  
  // System admin can always override
  if (user.role === 'system_admin') return true;
  
  // Check for explicit permission
  try {
    const { getEffectivePermissions } = await import('./permissionService');
    const effectivePermissions = await getEffectivePermissions(user.id);
    return effectivePermissions['reports:override_complete'] === true;
  } catch (error) {
    console.error('Error checking override permission:', error);
    // Fallback to role-based check for backward compatibility
    if (user.role === 'director' || user.role === 'senior_auditor') return true;
    const packages = (user.permissionPackages || []) as string[];
    if (packages.includes('acting_coordinator')) return true;
    return false;
  }
}

