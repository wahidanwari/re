import { storage } from '../storage';
import {
  finalizeArchiveFile,
  calculateFileChecksum,
  cleanupStagingFile,
  type ArchiveFileResult,
} from '../utils/archiveStorage';
import type { InsertArchivedFile, InsertArchivedFileVersion } from '@shared/schema';

export interface IngestionRequest {
  stagingPath: string;
  stagingFilename: string;
  originalFileName: string;
  year: number;
  category: string;
  description: string;
  uploadedBy: string;
  notes?: string;
}

export interface IngestionResult {
  archivedFile: {
    id: string;
    fileName: string;
    path: string;
    version: number;
  };
  checksum: string;
}

/**
 * Process uploaded file: move to final location, create DB records, set permissions
 */
export async function ingestArchiveFile(request: IngestionRequest): Promise<IngestionResult> {
  const { stagingPath, stagingFilename, originalFileName, year, category, description, uploadedBy, notes } = request;

  try {
    // Check if file with same original name and year already exists
    const existing = await storage.findExistingArchivedFile(originalFileName, year);

    let version: number;
    let archivedFileId: string;

    if (existing) {
      // Create new version
      version = existing.currentVersion + 1;
      archivedFileId = existing.id;

      // Update current version in main file record
      await storage.updateArchivedFile(existing.id, {
        currentVersion: version,
      });
    } else {
      // Create new file record
      version = 1;
    }

    // Finalize file: move to year directory and set read-only
    const finalized = await finalizeArchiveFile(
      stagingPath,
      year,
      category,
      description,
      originalFileName,
      version
    );

    // Calculate checksum
    const checksum = await calculateFileChecksum(finalized.filepath);

    if (existing) {
      // Create version record
      const versionRecord: InsertArchivedFileVersion = {
        archivedFileId: existing.id,
        versionNumber: version,
        fileName: finalized.filename,
        path: finalized.relativePath,
        sizeBytes: 0, // Will be updated below
        uploadedBy,
        notes: notes || null,
      };

      // Get file size
      const { getArchiveFileStats } = await import('../utils/archiveStorage');
      const stats = await getArchiveFileStats(finalized.relativePath);
      versionRecord.sizeBytes = stats.size;

      await storage.createArchivedFileVersion(versionRecord);
    } else {
      // Create main file record
      const fileRecord: InsertArchivedFile = {
        fileName: finalized.filename,
        originalFileName,
        year,
        category,
        description: description || null,
        path: finalized.relativePath,
        sizeBytes: 0, // Will be updated below
        uploadedBy,
        isReadonly: true,
        currentVersion: version,
      };

      // Get file size
      const { getArchiveFileStats } = await import('../utils/archiveStorage');
      const stats = await getArchiveFileStats(finalized.relativePath);
      fileRecord.sizeBytes = stats.size;

      const newFile = await storage.createArchivedFile(fileRecord);
      archivedFileId = newFile.id;

      // Create initial version record
      const versionRecord: InsertArchivedFileVersion = {
        archivedFileId: newFile.id,
        versionNumber: 1,
        fileName: finalized.filename,
        path: finalized.relativePath,
        sizeBytes: stats.size,
        uploadedBy,
        notes: notes || null,
      };

      await storage.createArchivedFileVersion(versionRecord);
    }

    // Note: Upload access log will be created by API endpoint with IP address

    // Get the final file record
    const archivedFile = await storage.getArchivedFile(archivedFileId);
    if (!archivedFile) {
      throw new Error('Failed to retrieve archived file after creation');
    }

    return {
      archivedFile: {
        id: archivedFile.id,
        fileName: archivedFile.fileName,
        path: archivedFile.path,
        version: archivedFile.currentVersion,
      },
      checksum,
    };
  } catch (error) {
    // Cleanup staging file on error
    await cleanupStagingFile(stagingPath);
    throw error;
  }
}

/**
 * Process ingestion asynchronously (for background jobs)
 */
export async function ingestArchiveFileAsync(request: IngestionRequest): Promise<void> {
  try {
    await ingestArchiveFile(request);
  } catch (error) {
    console.error('Archive ingestion failed:', error);
    throw error;
  }
}

