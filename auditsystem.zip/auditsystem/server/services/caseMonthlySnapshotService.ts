/**
 * Case Monthly Snapshot Service
 * PHASE 2: Monthly Remaining Balance Snapshot
 * 
 * Calculates and stores monthly snapshots of remaining balance per case.
 * Formula: remaining_balance_end_of_month = confirmedAmount - total payments up to end of month
 */

import { storage } from '../storage';
import jalaali from 'jalaali-js';

export interface MonthlySnapshotCalculation {
  caseId: string;
  reportMonth: string; // YYYY-MM format
  confirmedAmount: number;
  totalPaymentsUpToMonth: number;
  remainingBalanceEndOfMonth: number;
  totalPaidInMonth: number;
}

/**
 * Get confirmedAmount (مبلغ تثبیت شده) from case report
 */
async function getConfirmedAmount(caseId: string): Promise<number> {
  // Try V2 report first (preferred)
  const reportV2 = await storage.getCaseReportV2(caseId);
  if (reportV2?.confirmedAmount) {
    const amount = typeof reportV2.confirmedAmount === 'string'
      ? parseFloat(reportV2.confirmedAmount.toString().replace(/,/g, '')) || 0
      : (typeof reportV2.confirmedAmount === 'number' ? reportV2.confirmedAmount : 0);
    if (amount > 0) {
      return amount;
    }
  }

  // Fallback to V1 report
  const report = await storage.getCaseReport(caseId);
  if (report?.confirmedAmount) {
    const amount = typeof report.confirmedAmount === 'string'
      ? parseFloat(report.confirmedAmount.replace(/,/g, '')) || 0
      : 0;
    if (amount > 0) {
      return amount;
    }
  }

  return 0;
}

/**
 * Get total payments up to end of month (inclusive)
 */
async function getTotalPaymentsUpToMonth(caseId: string, year: number, month: number): Promise<number> {
  // Get end of month date
  const daysInMonth = jalaali.jalaaliMonthLength(year, month);
  const endOfMonth = jalaali.toGregorian(year, month, daysInMonth);
  const endDate = new Date(endOfMonth.gy, endOfMonth.gm - 1, endOfMonth.gd);
  endDate.setHours(23, 59, 59, 999);

  // Get all payments up to end of month
  const allPayments = await storage.getPaymentsByCase(caseId);
  const paymentsUpToMonth = allPayments.filter(p => {
    const paymentDate = p.paymentDate instanceof Date ? p.paymentDate : new Date(p.paymentDate);
    return paymentDate <= endDate;
  });

  // Sum payment amounts
  let total = 0;
  for (const payment of paymentsUpToMonth) {
    const amount = typeof payment.paymentAmount === 'string'
      ? parseFloat(payment.paymentAmount) || 0
      : (typeof payment.paymentAmount === 'number' ? payment.paymentAmount : 0);
    total += amount;
  }

  return total;
}

/**
 * Get total payments made in a specific month
 */
async function getTotalPaidInMonth(caseId: string, year: number, month: number): Promise<number> {
  const paymentsInMonth = await storage.getPaymentsInMonth(caseId, month, year);
  
  let total = 0;
  for (const payment of paymentsInMonth) {
    const amount = typeof payment.paymentAmount === 'string'
      ? parseFloat(payment.paymentAmount) || 0
      : (typeof payment.paymentAmount === 'number' ? payment.paymentAmount : 0);
    total += amount;
  }

  return total;
}

/**
 * Calculate monthly snapshot for a case
 */
export async function calculateMonthlySnapshot(
  caseId: string,
  year: number,
  month: number
): Promise<MonthlySnapshotCalculation> {
  const confirmedAmount = await getConfirmedAmount(caseId);
  const totalPaymentsUpToMonth = await getTotalPaymentsUpToMonth(caseId, year, month);
  const totalPaidInMonth = await getTotalPaidInMonth(caseId, year, month);
  
  // Calculate remaining balance: confirmedAmount - total payments up to end of month
  const remainingBalanceEndOfMonth = Math.max(0, confirmedAmount - totalPaymentsUpToMonth);
  
  const reportMonth = `${year}-${String(month).padStart(2, '0')}`;

  return {
    caseId,
    reportMonth,
    confirmedAmount,
    totalPaymentsUpToMonth,
    remainingBalanceEndOfMonth,
    totalPaidInMonth,
  };
}

/**
 * Create or update monthly snapshot for a case
 */
export async function createOrUpdateMonthlySnapshot(
  caseId: string,
  year: number,
  month: number
): Promise<void> {
  const calculation = await calculateMonthlySnapshot(caseId, year, month);

  await storage.createOrUpdateCaseMonthlySnapshot({
    caseId: calculation.caseId,
    reportMonth: calculation.reportMonth,
    remainingBalanceEndOfMonth: calculation.remainingBalanceEndOfMonth.toString(),
    totalPaidInMonth: calculation.totalPaidInMonth.toString(),
    confirmedAmount: calculation.confirmedAmount > 0 ? calculation.confirmedAmount.toString() : null,
  });
}

/**
 * Get previous month snapshot (M-1)
 */
export async function getPreviousMonthSnapshot(
  caseId: string,
  currentYear: number,
  currentMonth: number
): Promise<MonthlySnapshotCalculation | null> {
  // Calculate previous month
  let prevYear = currentYear;
  let prevMonth = currentMonth - 1;
  if (prevMonth < 1) {
    prevMonth = 12;
    prevYear = currentYear - 1;
  }

  const snapshot = await storage.getPreviousMonthSnapshot(
    caseId,
    `${currentYear}-${String(currentMonth).padStart(2, '0')}`
  );

  if (!snapshot) {
    return null;
  }

  return {
    caseId: snapshot.caseId,
    reportMonth: snapshot.reportMonth,
    confirmedAmount: typeof snapshot.confirmedAmount === 'string'
      ? parseFloat(snapshot.confirmedAmount) || 0
      : (typeof snapshot.confirmedAmount === 'number' ? snapshot.confirmedAmount : 0),
    totalPaymentsUpToMonth: 0, // Not stored in snapshot, would need to recalculate
    remainingBalanceEndOfMonth: typeof snapshot.remainingBalanceEndOfMonth === 'string'
      ? parseFloat(snapshot.remainingBalanceEndOfMonth) || 0
      : (typeof snapshot.remainingBalanceEndOfMonth === 'number' ? snapshot.remainingBalanceEndOfMonth : 0),
    totalPaidInMonth: typeof snapshot.totalPaidInMonth === 'string'
      ? parseFloat(snapshot.totalPaidInMonth) || 0
      : (typeof snapshot.totalPaidInMonth === 'number' ? snapshot.totalPaidInMonth : 0),
  };
}

/**
 * Get payments made in current month (M)
 */
export async function getCurrentMonthPayments(
  caseId: string,
  year: number,
  month: number
): Promise<Array<{ id: string; paymentDate: Date; paymentAmount: number; paymentType: string }>> {
  const paymentsInMonth = await storage.getPaymentsInMonth(caseId, month, year);
  
  return paymentsInMonth.map(p => ({
    id: p.id,
    paymentDate: p.paymentDate instanceof Date ? p.paymentDate : new Date(p.paymentDate),
    paymentAmount: typeof p.paymentAmount === 'string'
      ? parseFloat(p.paymentAmount) || 0
      : (typeof p.paymentAmount === 'number' ? p.paymentAmount : 0),
    paymentType: p.paymentType,
  }));
}

