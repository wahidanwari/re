/**
 * Monthly Group Report Service
 * Aggregates monthly KPIs per group with deterministic calculations
 */

import { storage } from '../storage';
import { db } from '../db';
import { 
  monthlyGroupReports, monthlyReportAnomalies, 
  cases, caseReportsV2, installmentPayments, caseStatusTransitions,
  groups
} from '@shared/schema';
import { eq, and, gte, lte, sql, isNull, or, inArray } from 'drizzle-orm';
import jalaali from 'jalaali-js';
import type { User, MonthlyGroupReport, InsertMonthlyGroupReport, MonthlyReportAnomaly } from '@shared/schema';
import { CaseStatus } from '@shared/schema';

// Afghan months: حمل، ثور، جوزا، سرطان، اسد، سنبله، میزان، عقرب، قوس، جدی، دلو، حوت
const AFGHAN_MONTHS = ['حمل', 'ثور', 'جوزا', 'سرطان', 'اسد', 'سنبله', 'میزان', 'عقرب', 'قوس', 'جدی', 'دلو', 'حوت'];

export interface MonthlyReportCalculation {
  distributedCount: number;
  finalizedCount: number;
  underReviewCount: number;
  collectedAmount: number;
  installmentsCount: number;
  nonresponsiveCount: number;
  percentOfTarget: number | null;
  anomalies: Array<{
    type: string;
    severity: string;
    description: string;
    details?: any;
  }>;
  contributingCases: string[]; // Case IDs for audit trail
  contributingPayments: string[]; // Payment IDs for audit trail
}

export interface MonthlyReportBreakdown {
  report: MonthlyGroupReport;
  distributedCases: Array<{ id: string; caseId: string; companyName: string; createdAt: Date }>;
  finalizedCases: Array<{ id: string; caseId: string; companyName: string; completedAt: Date; collectedAmount: number }>;
  installmentPayments: Array<{ id: string; caseId: string; amountPaid: number; paymentDate: Date }>;
  nonresponsiveCases: Array<{ id: string; caseId: string; companyName: string; transitionedAt: Date }>;
  anomalies: MonthlyReportAnomaly[];
}

/**
 * Convert Afghan month name to month number (1-12)
 */
export function afghanMonthToNumber(monthName: string): number {
  const index = AFGHAN_MONTHS.indexOf(monthName);
  if (index === -1) {
    throw new Error(`Invalid Afghan month: ${monthName}`);
  }
  return index + 1; // 1-12
}

/**
 * Get date range for a Shamsi month/year
 */
export function getShamsiMonthDateRange(monthNumber: number, year: number): { start: Date; end: Date } {
  const monthStart = jalaali.toGregorian(year, monthNumber, 1);
  const monthEnd = jalaali.toGregorian(
    year,
    monthNumber,
    jalaali.jalaaliMonthLength(year, monthNumber)
  );
  
  const start = new Date(monthStart.gy, monthStart.gm - 1, monthStart.gd);
  const end = new Date(monthEnd.gy, monthEnd.gm - 1, monthEnd.gd);
  end.setHours(23, 59, 59, 999);
  
  return { start, end };
}

/**
 * Calculate monthly report for a group
 */
export async function calculateMonthlyReport(
  groupId: string,
  monthNumber: number,
  year: number,
  computedBy: string
): Promise<MonthlyReportCalculation> {
  const { start: monthStart, end: monthEnd } = getShamsiMonthDateRange(monthNumber, year);
  
  // Get group to check for monthly_tax_target
  const group = await storage.getGroup(groupId);
  if (!group) {
    throw new Error(`Group ${groupId} not found`);
  }
  
  const anomalies: Array<{ type: string; severity: string; description: string; details?: any }> = [];
  const contributingCases: string[] = [];
  const contributingPayments: string[] = [];
  
  // 1. Calculate distributed_count: Cases created/distributed during the month
  const distributedCases = await db
    .select({
      id: cases.id,
      caseId: cases.caseId,
      companyName: cases.companyName,
      createdAt: cases.createdAt,
      receivingGroup: cases.receivingGroup,
    })
    .from(cases)
    .where(
      and(
        eq(cases.receivingGroup, groupId),
        gte(cases.createdAt, monthStart),
        lte(cases.createdAt, monthEnd)
      )
    );
  
  const distributedCount = distributedCases.length;
  distributedCases.forEach(c => contributingCases.push(c.id));
  
  // 2. Calculate finalized_count: Cases completed during the month
  const finalizedCases = await db
    .select({
      id: cases.id,
      caseId: cases.caseId,
      companyName: cases.companyName,
      completedAt: cases.completedAt,
      receivingGroup: cases.receivingGroup,
    })
    .from(cases)
    .where(
      and(
        eq(cases.receivingGroup, groupId),
        sql`${cases.completedAt} IS NOT NULL`,
        gte(cases.completedAt, monthStart),
        lte(cases.completedAt, monthEnd)
      )
    );
  
  const finalizedCount = finalizedCases.length;
  finalizedCases.forEach(c => contributingCases.push(c.id));
  
  // 3. Calculate under_review_count = distributed_count - finalized_count
  let underReviewCount = distributedCount - finalizedCount;
  if (underReviewCount < 0) {
    anomalies.push({
      type: 'negative_under_review',
      severity: 'error',
      description: `Negative under_review_count calculated: ${underReviewCount}. This indicates data inconsistency.`,
      details: { distributedCount, finalizedCount, calculated: underReviewCount }
    });
    underReviewCount = 0; // Clamp to zero
  }
  
  // 4. Calculate collected_amount: Sum of completed case amounts + installment payments
  let collectedAmount = 0;
  
  // 4a. Sum from completed cases (collectedCurrentMonth from caseReportsV2)
  const completedCaseIds = finalizedCases.map(c => c.id);
  if (completedCaseIds.length > 0) {
    const caseReports = await db
      .select({
        caseId: caseReportsV2.caseId,
        collectedCurrentMonth: caseReportsV2.collectedCurrentMonth,
      })
      .from(caseReportsV2)
      .where(inArray(caseReportsV2.caseId, completedCaseIds));
    
    for (const report of caseReports) {
      if (report.collectedCurrentMonth) {
        const amount = parseFloat(report.collectedCurrentMonth.toString());
        if (!isNaN(amount) && amount > 0) {
          collectedAmount += amount;
        }
      }
    }
  }
  
  // 4b. Sum from installment payments during the month
  const installmentPaymentsInMonth = await db
    .select({
      id: installmentPayments.id,
      caseId: installmentPayments.caseId,
      amountPaid: installmentPayments.amountPaid,
      paymentDate: installmentPayments.paymentDate,
    })
    .from(installmentPayments)
    .innerJoin(cases, eq(installmentPayments.caseId, cases.id))
    .where(
      and(
        eq(cases.receivingGroup, groupId),
        gte(installmentPayments.paymentDate, monthStart),
        lte(installmentPayments.paymentDate, monthEnd)
      )
    );
  
  for (const payment of installmentPaymentsInMonth) {
    const amount = parseFloat(payment.amountPaid.toString());
    if (!isNaN(amount) && amount > 0) {
      collectedAmount += amount;
      contributingPayments.push(payment.id);
    }
  }
  
  // 5. Calculate installments_count: Distinct cases with installment payments
  const distinctInstallmentCaseIds = new Set(installmentPaymentsInMonth.map(p => p.caseId));
  const installmentsCount = distinctInstallmentCaseIds.size;
  
  // 6. Calculate nonresponsive_count: Cases sent to law enforcement during the month
  const nonresponsiveTransitions = await db
    .select({
      caseId: caseStatusTransitions.caseId,
      transitionedAt: caseStatusTransitions.transitionedAt,
    })
    .from(caseStatusTransitions)
    .innerJoin(cases, eq(caseStatusTransitions.caseId, cases.id))
    .where(
      and(
        eq(cases.receivingGroup, groupId),
        eq(caseStatusTransitions.toStatus, CaseStatus.SENT_TO_LAW_ENFORCEMENT),
        gte(caseStatusTransitions.transitionedAt, monthStart),
        lte(caseStatusTransitions.transitionedAt, monthEnd)
      )
    );
  
  const nonresponsiveCount = nonresponsiveTransitions.length;
  nonresponsiveTransitions.forEach(t => {
    if (!contributingCases.includes(t.caseId)) {
      contributingCases.push(t.caseId);
    }
  });
  
  // 7. Calculate percent_of_target
  let percentOfTarget: number | null = null;
  const monthlyTaxTarget = group.monthlyTaxTarget ? parseFloat(group.monthlyTaxTarget.toString()) : null;
  
  if (monthlyTaxTarget === null || monthlyTaxTarget === 0) {
    anomalies.push({
      type: 'missing_target',
      severity: 'warning',
      description: `Group ${group.name} does not have a monthly_tax_target configured. Percentage calculation skipped.`,
      details: { groupId, groupName: group.name }
    });
  } else {
    percentOfTarget = (collectedAmount / monthlyTaxTarget) * 100;
    percentOfTarget = Math.round(percentOfTarget * 100) / 100; // Round to 2 decimals
    
    if (percentOfTarget > 300) {
      anomalies.push({
        type: 'high_percentage',
        severity: 'warning',
        description: `Percentage of target achieved is very high: ${percentOfTarget}%. Please verify calculations.`,
        details: { percentOfTarget, collectedAmount, monthlyTaxTarget }
      });
    }
  }
  
  return {
    distributedCount,
    finalizedCount,
    underReviewCount,
    collectedAmount,
    installmentsCount,
    nonresponsiveCount,
    percentOfTarget,
    anomalies,
    contributingCases,
    contributingPayments,
  };
}

/**
 * Create or update monthly report for a group
 */
export async function upsertMonthlyReport(
  groupId: string,
  monthNumber: number,
  year: number,
  computedBy: string
): Promise<MonthlyGroupReport> {
  const calculation = await calculateMonthlyReport(groupId, monthNumber, year, computedBy);
  
  // Check if report already exists
  const existing = await db
    .select()
    .from(monthlyGroupReports)
    .where(
      and(
        eq(monthlyGroupReports.groupId, groupId),
        eq(monthlyGroupReports.monthNumber, monthNumber),
        eq(monthlyGroupReports.yearNumber, year)
      )
    )
    .limit(1);
  
  const { start: monthStart, end: monthEnd } = getShamsiMonthDateRange(monthNumber, year);
  
  const reportData: InsertMonthlyGroupReport = {
    groupId,
    monthNumber,
    yearNumber: year,
    monthStartDate: monthStart as any, // Date object for timestamp field
    monthEndDate: monthEnd as any, // Date object for timestamp field
    distributedCount: calculation.distributedCount,
    finalizedCount: calculation.finalizedCount,
    underReviewCount: calculation.underReviewCount,
    collectedAmount: calculation.collectedAmount.toString(),
    installmentsCount: calculation.installmentsCount,
    nonresponsiveCount: calculation.nonresponsiveCount,
    percentOfTarget: calculation.percentOfTarget ? calculation.percentOfTarget.toString() : null,
    computedBy,
  };
  
  let report: MonthlyGroupReport;
  
  if (existing.length > 0) {
    // Update existing report
    const [updated] = await db
      .update(monthlyGroupReports)
      .set({
        ...reportData,
        updatedAt: new Date(),
      })
      .where(eq(monthlyGroupReports.id, existing[0].id))
      .returning();
    report = updated;
  } else {
    // Create new report
    const [created] = await db
      .insert(monthlyGroupReports)
      .values(reportData)
      .returning();
    report = created;
  }
  
  // Store anomalies
  for (const anomaly of calculation.anomalies) {
    await db.insert(monthlyReportAnomalies).values({
      reportId: report.id,
      anomalyType: anomaly.type,
      severity: anomaly.severity,
      description: anomaly.description,
      details: anomaly.details || {},
      resolved: false,
    });
  }
  
  return report;
}

/**
 * Get monthly report with breakdown
 */
export async function getMonthlyReportBreakdown(
  groupId: string,
  monthNumber: number,
  year: number
): Promise<MonthlyReportBreakdown | null> {
  const report = await db
    .select()
    .from(monthlyGroupReports)
    .where(
      and(
        eq(monthlyGroupReports.groupId, groupId),
        eq(monthlyGroupReports.monthNumber, monthNumber),
        eq(monthlyGroupReports.yearNumber, year)
      )
    )
    .limit(1);
  
  if (report.length === 0) {
    return null;
  }
  
  const { start: monthStart, end: monthEnd } = getShamsiMonthDateRange(monthNumber, year);
  
  // Get distributed cases
  const distributedCases = await db
    .select({
      id: cases.id,
      caseId: cases.caseId,
      companyName: cases.companyName,
      createdAt: cases.createdAt,
    })
    .from(cases)
    .where(
      and(
        eq(cases.receivingGroup, groupId),
        gte(cases.createdAt, monthStart),
        lte(cases.createdAt, monthEnd)
      )
    )
    .orderBy(cases.createdAt);
  
  // Get finalized cases with collected amounts
  const finalizedCases = await db
    .select({
      id: cases.id,
      caseId: cases.caseId,
      companyName: cases.companyName,
      completedAt: cases.completedAt,
    })
    .from(cases)
    .where(
      and(
        eq(cases.receivingGroup, groupId),
        sql`${cases.completedAt} IS NOT NULL`,
        gte(cases.completedAt, monthStart),
        lte(cases.completedAt, monthEnd)
      )
    )
    .orderBy(cases.completedAt);
  
  // Get collected amounts for finalized cases
  const finalizedCaseIds = finalizedCases.map(c => c.id);
  const caseReports = finalizedCaseIds.length > 0 ? await db
    .select({
      caseId: caseReportsV2.caseId,
      collectedCurrentMonth: caseReportsV2.collectedCurrentMonth,
    })
    .from(caseReportsV2)
    .where(inArray(caseReportsV2.caseId, finalizedCaseIds)) : [];
  
  const caseReportMap = new Map(caseReports.map(r => [r.caseId, r]));
  const finalizedCasesWithAmounts = finalizedCases.map(c => ({
    ...c,
    collectedAmount: caseReportMap.get(c.id)?.collectedCurrentMonth 
      ? parseFloat(caseReportMap.get(c.id)!.collectedCurrentMonth!.toString()) 
      : 0,
  }));
  
  // Get installment payments
  const installmentPaymentsList = await db
    .select({
      id: installmentPayments.id,
      caseId: installmentPayments.caseId,
      amountPaid: installmentPayments.amountPaid,
      paymentDate: installmentPayments.paymentDate,
    })
    .from(installmentPayments)
    .innerJoin(cases, eq(installmentPayments.caseId, cases.id))
    .where(
      and(
        eq(cases.receivingGroup, groupId),
        gte(installmentPayments.paymentDate, monthStart),
        lte(installmentPayments.paymentDate, monthEnd)
      )
    )
    .orderBy(installmentPayments.paymentDate);
  
  // Get nonresponsive cases
  const nonresponsiveCases = await db
    .select({
      id: cases.id,
      caseId: cases.caseId,
      companyName: cases.companyName,
      transitionedAt: caseStatusTransitions.transitionedAt,
    })
    .from(caseStatusTransitions)
    .innerJoin(cases, eq(caseStatusTransitions.caseId, cases.id))
    .where(
      and(
        eq(cases.receivingGroup, groupId),
        eq(caseStatusTransitions.toStatus, CaseStatus.SENT_TO_LAW_ENFORCEMENT),
        gte(caseStatusTransitions.transitionedAt, monthStart),
        lte(caseStatusTransitions.transitionedAt, monthEnd)
      )
    )
    .orderBy(caseStatusTransitions.transitionedAt);
  
  // Get anomalies
  const anomalies = await db
    .select()
    .from(monthlyReportAnomalies)
    .where(eq(monthlyReportAnomalies.reportId, report[0].id))
    .orderBy(monthlyReportAnomalies.createdAt);
  
  return {
    report: report[0],
    distributedCases: distributedCases.map(c => ({
      id: c.id,
      caseId: c.caseId,
      companyName: c.companyName,
      createdAt: c.createdAt!,
    })),
    finalizedCases: finalizedCasesWithAmounts.map(c => ({
      id: c.id,
      caseId: c.caseId,
      companyName: c.companyName,
      completedAt: c.completedAt!,
      collectedAmount: c.collectedAmount,
    })),
    installmentPayments: installmentPaymentsList.map(p => ({
      id: p.id,
      caseId: p.caseId,
      amountPaid: parseFloat(p.amountPaid.toString()),
      paymentDate: p.paymentDate!,
    })),
    nonresponsiveCases: nonresponsiveCases.map(c => ({
      id: c.id,
      caseId: c.caseId,
      companyName: c.companyName,
      transitionedAt: c.transitionedAt!,
    })),
    anomalies,
  };
}

