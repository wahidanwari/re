/**
 * Enterprise Reporting Service
 * Provides query building, RBAC filtering, aggregation, and export capabilities
 */

import { storage } from '../storage';
import { Case, Entity, User, Group, Document } from '@shared/schema';
import { getEffectivePermissions } from './permissionService';
import { getCaseVisibility, getGroupVisibility } from '../utils/permissionHelpers';
import jalaali from 'jalaali-js';

export interface ReportFilter {
  groupId?: string;
  groupIds?: string[];
  userId?: string;
  caseStatus?: string[];
  dateRange?: {
    start: Date;
    end: Date;
  };
  shamsiMonth?: number;
  shamsiYear?: number;
  entityType?: string;
  hasTransaction?: boolean;
  targetAchieved?: boolean;
}

export interface ReportField {
  key: string;
  label: string;
  type: 'string' | 'number' | 'date' | 'boolean';
  source: 'case' | 'entity' | 'user' | 'group' | 'document' | 'calculated';
}

export interface ReportAggregation {
  type: 'count' | 'sum' | 'avg' | 'min' | 'max';
  field: string;
  label: string;
}

export interface ReportGrouping {
  field: string;
  label: string;
}

export interface ReportQuery {
  filters: ReportFilter;
  fields: ReportField[];
  aggregations?: ReportAggregation[];
  grouping?: ReportGrouping[];
  sorting?: {
    field: string;
    direction: 'asc' | 'desc';
  };
  limit?: number;
  offset?: number;
}

export interface ReportResult {
  data: any[];
  metadata: {
    totalRows: number;
    filteredRows: number;
    generatedAt: Date;
    generatedBy: string;
    filters: ReportFilter;
  };
  aggregations?: Record<string, any>;
}

/**
 * Build and execute a report query with RBAC filtering
 */
export async function buildReportQuery(
  user: User,
  query: ReportQuery
): Promise<ReportResult> {
  // Get user's effective permissions and visibility
  const effectivePermissions = await getEffectivePermissions(user.id);
  const caseVisibility = await getCaseVisibility(user);
  const groupVisibility = await getGroupVisibility(user);

  // Start with all cases (will be filtered by RBAC)
  let cases: Case[] = [];

  // Apply RBAC filtering
  if (user.role === 'system_admin') {
    cases = await storage.getCases();
  } else if (caseVisibility.canViewAll) {
    cases = await storage.getCases();
  } else if (caseVisibility.requiresFiltering) {
    if (caseVisibility.filterByAssignee) {
      cases = await storage.getCasesByAssignee(user.id);
    } else if (caseVisibility.filterByGroup) {
      cases = await storage.getCasesByGroup(caseVisibility.filterByGroup);
    }
  }

  // Apply query filters
  let filteredCases = cases;

  // Filter by group
  if (query.filters.groupId) {
    filteredCases = filteredCases.filter(c => c.receivingGroup === query.filters.groupId);
  }
  if (query.filters.groupIds && query.filters.groupIds.length > 0) {
    filteredCases = filteredCases.filter(c => 
      c.receivingGroup && query.filters.groupIds!.includes(c.receivingGroup)
    );
  }

  // Filter by user (assigned to)
  if (query.filters.userId) {
    filteredCases = filteredCases.filter(c => c.assignedTo === query.filters.userId);
  }

  // Filter by status
  if (query.filters.caseStatus && query.filters.caseStatus.length > 0) {
    filteredCases = filteredCases.filter(c => 
      query.filters.caseStatus!.includes(c.status)
    );
  }

  // Filter by date range
  if (query.filters.dateRange) {
    filteredCases = filteredCases.filter(c => {
      if (!c.createdAt) return false;
      const caseDate = new Date(c.createdAt);
      return caseDate >= query.filters.dateRange!.start && 
             caseDate <= query.filters.dateRange!.end;
    });
  }

  // Filter by Shamsi month/year
  if (query.filters.shamsiMonth && query.filters.shamsiYear) {
    filteredCases = filteredCases.filter(c => {
      if (!c.completedAt && !c.createdAt) return false;
      const caseDate = jalaali.toJalaali(new Date(c.completedAt || c.createdAt!));
      return caseDate.jm === query.filters.shamsiMonth && 
             caseDate.jy === query.filters.shamsiYear;
    });
  }

  // Filter by transaction (has transactionId)
  if (query.filters.hasTransaction !== undefined) {
    filteredCases = filteredCases.filter(c => {
      const hasTransaction = !!(c as any).transactionId;
      return hasTransaction === query.filters.hasTransaction;
    });
  }

  // Get related entities, users, groups, and documents
  const entityIds = [...new Set(filteredCases.map(c => c.entityId))];
  const entities = await Promise.all(
    entityIds.map(id => storage.getEntity(id))
  );
  const entityMap = new Map(
    entities.filter(e => e).map(e => [e!.id, e!])
  );

  const userIds = [...new Set(filteredCases.map(c => c.assignedTo).filter(Boolean))];
  const users = await Promise.all(
    userIds.map(id => storage.getUser(id!))
  );
  const userMap = new Map(
    users.filter(u => u).map(u => [u!.id, u!])
  );

  const groupIds = [...new Set(
    filteredCases
      .map(c => [c.receivingGroup, c.groupReferrer])
      .flat()
      .filter(Boolean)
  )];
  const groups = await Promise.all(
    groupIds.map(id => storage.getGroup(id!))
  );
  const groupMap = new Map(
    groups.filter(g => g).map(g => [g!.id, g!])
  );

  // Get documents for cases
  const caseIds = filteredCases.map(c => c.id);
  const allDocuments: Document[] = [];
  for (const caseId of caseIds) {
    const docs = await storage.getDocuments(caseId);
    allDocuments.push(...docs);
  }
  const documentsByCase = new Map<string, Document[]>();
  allDocuments.forEach(doc => {
    const existing = documentsByCase.get(doc.caseId) || [];
    existing.push(doc);
    documentsByCase.set(doc.caseId, existing);
  });

  // Build result data based on selected fields
  const resultData = filteredCases.map(caseItem => {
    const entity = entityMap.get(caseItem.entityId);
    const assignedUser = caseItem.assignedTo ? userMap.get(caseItem.assignedTo) : null;
    const receivingGroup = caseItem.receivingGroup ? groupMap.get(caseItem.receivingGroup) : null;
    const referrerGroup = caseItem.groupReferrer ? groupMap.get(caseItem.groupReferrer) : null;
    const documents = documentsByCase.get(caseItem.id) || [];
    const finalDoc = documents.find(d => d.isFinal && !d.isRevoked);

    const row: any = {};

    // Add fields based on query
    query.fields.forEach(field => {
      switch (field.source) {
        case 'case':
          row[field.key] = (caseItem as any)[field.key] || '';
          break;
        case 'entity':
          row[field.key] = entity ? (entity as any)[field.key] || '' : '';
          break;
        case 'user':
          row[field.key] = assignedUser ? (assignedUser as any)[field.key] || '' : '';
          break;
        case 'group':
          if (field.key.includes('receiving')) {
            row[field.key] = receivingGroup ? (receivingGroup as any)[field.key.replace('receiving', '')] || '' : '';
          } else if (field.key.includes('referrer')) {
            row[field.key] = referrerGroup ? (referrerGroup as any)[field.key.replace('referrer', '')] || '' : '';
          }
          break;
        case 'document':
          if (field.key === 'finalDocumentDate') {
            row[field.key] = finalDoc?.docDate || '';
          } else if (field.key === 'documentCount') {
            row[field.key] = documents.length;
          }
          break;
        case 'calculated':
          // Calculate derived fields
          if (field.key === 'daysToComplete' && caseItem.completedAt && caseItem.createdAt) {
            const days = Math.floor(
              (new Date(caseItem.completedAt).getTime() - new Date(caseItem.createdAt).getTime()) / 
              (1000 * 60 * 60 * 24)
            );
            row[field.key] = days;
          } else if (field.key === 'isOverdue') {
            // Define overdue logic (e.g., > 30 days without completion)
            const daysSinceCreation = caseItem.createdAt 
              ? Math.floor((Date.now() - new Date(caseItem.createdAt).getTime()) / (1000 * 60 * 60 * 24))
              : 0;
            row[field.key] = daysSinceCreation > 30 && caseItem.status !== 'تکمیل شده';
          } else if (field.key === 'caseCount') {
            // Count cases (used in grouping)
            row[field.key] = 1;
          } else if (field.key === 'completedCount') {
            row[field.key] = caseItem.status === 'تکمیل شده' ? 1 : 0;
          } else if (field.key === 'avgDaysToComplete') {
            // This would be calculated in aggregation
            row[field.key] = caseItem.completedAt && caseItem.createdAt
              ? Math.floor((new Date(caseItem.completedAt).getTime() - new Date(caseItem.createdAt).getTime()) / (1000 * 60 * 60 * 24))
              : null;
          } else if (field.key === 'totalCases') {
            row[field.key] = 1;
          } else if (field.key === 'targetAchievement') {
            // This would require group targets data
            row[field.key] = null; // Placeholder
          } else if (field.key === 'daysOverdue') {
            const daysSinceCreation = caseItem.createdAt 
              ? Math.floor((Date.now() - new Date(caseItem.createdAt).getTime()) / (1000 * 60 * 60 * 24))
              : 0;
            row[field.key] = daysSinceCreation > 30 && caseItem.status !== 'تکمیل شده' ? daysSinceCreation - 30 : 0;
          }
          break;
      }
    });

    return row;
  });

  // Apply grouping if specified
  let groupedData = resultData;
  if (query.grouping && query.grouping.length > 0) {
    const groupKey = query.grouping[0].field;
    const grouped = new Map<string, any[]>();
    
    resultData.forEach(row => {
      const key = String(row[groupKey] || 'unknown');
      const existing = grouped.get(key) || [];
      existing.push(row);
      grouped.set(key, existing);
    });

    groupedData = Array.from(grouped.entries()).map(([key, rows]) => ({
      [groupKey]: key,
      _count: rows.length,
      _rows: rows,
    }));
  }

  // Apply sorting
  if (query.sorting) {
    groupedData.sort((a, b) => {
      const aVal = a[query.sorting!.field];
      const bVal = b[query.sorting!.field];
      if (aVal < bVal) return query.sorting!.direction === 'asc' ? -1 : 1;
      if (aVal > bVal) return query.sorting!.direction === 'asc' ? 1 : -1;
      return 0;
    });
  }

  // Apply pagination
  const totalRows = groupedData.length;
  if (query.limit) {
    const offset = query.offset || 0;
    groupedData = groupedData.slice(offset, offset + query.limit);
  }

  // Calculate aggregations
  let aggregations: Record<string, any> | undefined;
  if (query.aggregations && query.aggregations.length > 0) {
    aggregations = {};
    query.aggregations.forEach(agg => {
      const values = resultData.map(row => row[agg.field]).filter(v => v !== null && v !== undefined);
      switch (agg.type) {
        case 'count':
          aggregations![agg.label] = values.length;
          break;
        case 'sum':
          aggregations![agg.label] = values.reduce((sum, v) => sum + (Number(v) || 0), 0);
          break;
        case 'avg':
          aggregations![agg.label] = values.length > 0 
            ? values.reduce((sum, v) => sum + (Number(v) || 0), 0) / values.length 
            : 0;
          break;
        case 'min':
          aggregations![agg.label] = values.length > 0 
            ? Math.min(...values.map(v => Number(v) || 0)) 
            : 0;
          break;
        case 'max':
          aggregations![agg.label] = values.length > 0 
            ? Math.max(...values.map(v => Number(v) || 0)) 
            : 0;
          break;
      }
    });
  }

  return {
    data: groupedData,
    metadata: {
      totalRows: cases.length,
      filteredRows: totalRows,
      generatedAt: new Date(),
      generatedBy: user.id,
      filters: query.filters,
    },
    aggregations,
  };
}

/**
 * Get available report templates
 */
export function getReportTemplates(): Array<{
  id: string;
  name: string;
  description: string;
  defaultFields: ReportField[];
  defaultFilters: Partial<ReportFilter>;
}> {
  return [
    // BUG FIX #3: Removed 'گزارش ماهانه گروه' report type - use Ministry Report instead
    {
      id: 'auditor-workload',
      name: 'بار کاری بررس',
      description: 'گزارش بار کاری و عملکرد بررس‌ها',
      defaultFields: [
        { key: 'assignedTo', label: 'بررس', type: 'string', source: 'user' },
        { key: 'caseCount', label: 'تعداد قضایا', type: 'number', source: 'calculated' },
        { key: 'completedCount', label: 'تکمیل شده', type: 'number', source: 'calculated' },
        { key: 'avgDaysToComplete', label: 'میانگین روز تا تکمیل', type: 'number', source: 'calculated' },
      ],
      defaultFilters: {},
    },
    {
      id: 'financial-summary',
      name: 'خلاصه مالی',
      description: 'گزارش مالیات جمع‌آوری شده',
      defaultFields: [
        { key: 'groupId', label: 'گروه', type: 'string', source: 'group' },
        { key: 'transactionId', label: 'نمبر تراکنش', type: 'string', source: 'case' },
        { key: 'paymentDate', label: 'تاریخ پرداخت', type: 'date', source: 'case' },
        { key: 'confirmedAmount', label: 'مبلغ تثبیت شده', type: 'number', source: 'case' },
      ],
      defaultFilters: { hasTransaction: true },
    },
    {
      id: 'compliance-overdue',
      name: 'قضایای معوق',
      description: 'گزارش قضایای معوق و نیازمند توجه',
      defaultFields: [
        { key: 'caseId', label: 'نمبر قضیه', type: 'string', source: 'case' },
        { key: 'companyName', label: 'نام نهاد', type: 'string', source: 'case' },
        { key: 'assignedTo', label: 'اختصاص داده شده به', type: 'string', source: 'user' },
        { key: 'daysOverdue', label: 'روز معوق', type: 'number', source: 'calculated' },
        { key: 'status', label: 'وضعیت', type: 'string', source: 'case' },
      ],
      defaultFilters: {},
    },
  ];
}

