/**
 * Committee Reporting Service
 * Provides authoritative reporting and analytics for committees, assignments, and audit groups
 * All reports are read-only and reflect historical data accurately
 */

import type { User, CommitteeNew, CommitteeCaseAssignment, Case, Group } from '@shared/schema';
import { storage } from '../storage';
import { hasCommitteeManagementPermission } from './committeeService';
import { getCaseAssignmentHistory } from './caseAssignmentService';
import jalaali from 'jalaali-js';

export interface CommitteeReport {
  committee: {
    id: string;
    title: string;
    year: number;
    month: number;
    status: string;
    createdAt: Date;
    approvedAt?: Date;
    createdBy: string;
    createdByName?: string;
    approvedBy?: string;
    approvedByName?: string;
  };
  cases: CommitteeReportCase[];
  summary: {
    totalCases: number;
    casesByGroup: Record<string, number>;
    casesBySource: {
      committee: number;
      direct: number;
    };
  };
}

export interface CommitteeReportCase {
  caseId: string;
  caseNumber?: number;
  entityName: string;
  auditGroupId: string;
  auditGroupName?: string;
  assignmentDate: Date;
  assignmentSource: 'COMMITTEE' | 'DIRECT' | 'REASSIGNMENT';
  assignedBy: string;
  assignedByName?: string;
  caseCurrentStatus: string;
  assignmentId: string;
}

export interface YearlyCommitteeSummary {
  year: number;
  totalCommittees: number;
  totalCasesAssignedViaCommittees: number;
  totalDirectAssignments: number;
  monthlyBreakdown: MonthlyBreakdown[];
}

export interface MonthlyBreakdown {
  month: number;
  committeeCount: number;
  casesAssignedCount: number;
}

export interface AuditGroupWorkloadReport {
  auditGroupId: string;
  auditGroupName: string;
  totalCasesViaCommittees: number;
  totalDirectAssignments: number;
  casesPendingReview: number; // Cases with status "در انتظار بررسی"
  casesCompleted: number;
  averageCasesPerCommittee: number;
  committees: {
    committeeId: string;
    committeeTitle: string;
    casesCount: number;
  }[];
}

export interface CaseAssignmentHistoryView {
  caseId: string;
  caseNumber?: number;
  entityName: string;
  assignments: AssignmentHistoryItem[];
}

export interface AssignmentHistoryItem {
  assignmentId: string;
  committeeId?: string;
  committeeTitle?: string;
  auditGroupId: string;
  auditGroupName?: string;
  assignmentDate: Date;
  assignedBy: string;
  assignedByName?: string;
  assignmentSource: 'COMMITTEE' | 'DIRECT' | 'REASSIGNMENT';
  statusAtAssignment: string;
  reason?: string;
  previousAssignmentId?: string;
}

/**
 * Get single committee report
 * Includes all cases assigned through this committee, even if reassigned later
 */
export async function getCommitteeReport(committeeId: string): Promise<CommitteeReport> {
  // Get committee
  const committee = await storage.getCommitteeNew(committeeId);
  if (!committee) {
    throw new Error('کمیته یافت نشد');
  }
  
  // Get creator and approver names
  const createdByUser = await storage.getUser(committee.createdBy);
  const approvedByUser = committee.approvedBy ? await storage.getUser(committee.approvedBy) : null;
  
  // Get all assignments for this committee
  const assignments = await storage.getCommitteeAssignments(committeeId);
  
  // Build case list
  const cases: CommitteeReportCase[] = [];
  const groupCounts: Record<string, number> = {};
  const sourceCounts = { committee: 0, direct: 0 };
  
  for (const assignment of assignments) {
    // Get case
    const caseItem = await storage.getCase(assignment.caseId);
    if (!caseItem) continue;
    
    // Get entity name
    const entity = caseItem.entityId ? await storage.getEntity(caseItem.entityId) : null;
    const entityName = entity?.name || 'نامشخص';
    
    // Get audit group name
    const auditGroup = await storage.getGroup(assignment.auditGroupId);
    const auditGroupName = auditGroup?.name;
    
    // Get assigned by name
    const assignedByUser = await storage.getUser(assignment.assignedBy);
    const assignedByName = assignedByUser?.fullName;
    
    // Determine assignment source
    const assignmentSource = assignment.assignmentType as 'COMMITTEE' | 'DIRECT' | 'REASSIGNMENT';
    
    // Count by group
    if (!groupCounts[assignment.auditGroupId]) {
      groupCounts[assignment.auditGroupId] = 0;
    }
    groupCounts[assignment.auditGroupId]++;
    
    // Count by source
    if (assignmentSource === 'COMMITTEE') {
      sourceCounts.committee++;
    } else if (assignmentSource === 'DIRECT') {
      sourceCounts.direct++;
    }
    
    cases.push({
      caseId: caseItem.caseId,
      caseNumber: caseItem.caseNumber || undefined,
      entityName,
      auditGroupId: assignment.auditGroupId,
      auditGroupName,
      assignmentDate: assignment.assignedAt,
      assignmentSource,
      assignedBy: assignment.assignedBy,
      assignedByName,
      caseCurrentStatus: caseItem.status,
      assignmentId: assignment.id,
    });
  }
  
  return {
    committee: {
      id: committee.id,
      title: committee.title,
      year: committee.year,
      month: committee.month,
      status: committee.status,
      createdAt: committee.createdAt || new Date(),
      approvedAt: committee.approvedAt || undefined,
      createdBy: committee.createdBy,
      createdByName: createdByUser?.fullName,
      approvedBy: committee.approvedBy || undefined,
      approvedByName: approvedByUser?.fullName,
    },
    cases,
    summary: {
      totalCases: cases.length,
      casesByGroup: groupCounts,
      casesBySource: sourceCounts,
    },
  };
}

/**
 * Get yearly committee summary
 */
export async function getYearlyCommitteeSummary(year: number): Promise<YearlyCommitteeSummary> {
  // Get all committees for the year
  const allCommittees = await storage.getCommitteesNew();
  const yearCommittees = allCommittees.filter(c => c.year === year);
  
  // Get all assignments for these committees
  const allAssignments: CommitteeCaseAssignment[] = [];
  for (const committee of yearCommittees) {
    const assignments = await storage.getCommitteeAssignments(committee.id);
    allAssignments.push(...assignments);
  }
  
  // Count committee assignments (type COMMITTEE)
  const committeeAssignments = allAssignments.filter(a => a.assignmentType === 'COMMITTEE');
  
  // Count direct assignments (type DIRECT) for the year
  // Convert Shamsi year to Gregorian date range
  // Shamsi year starts on 1st of Farvardin (month 1) and ends on last day of Esfand (month 12)
  const shamsiYearStart = jalaali.toGregorian(year, 1, 1);
  const shamsiYearEnd = jalaali.toGregorian(year, 12, jalaali.jalaaliMonthLength(year, 12));
  
  const startOfYear = new Date(shamsiYearStart.gy, shamsiYearStart.gm - 1, shamsiYearStart.gd);
  const endOfYear = new Date(shamsiYearEnd.gy, shamsiYearEnd.gm - 1, shamsiYearEnd.gd);
  endOfYear.setHours(23, 59, 59, 999);
  
  // Get all direct assignments for the year (optimized query)
  const allDirectAssignments = await storage.getAllDirectAssignments(startOfYear, endOfYear);
  
  // Monthly breakdown
  // Group assignments by committee month (not assignment date)
  const monthlyBreakdown: MonthlyBreakdown[] = [];
  for (let month = 1; month <= 12; month++) {
    const monthCommittees = yearCommittees.filter(c => c.month === month);
    
    // Get assignments for committees in this month
    const monthAssignmentIds = new Set<string>();
    for (const committee of monthCommittees) {
      const committeeAssignments = await storage.getCommitteeAssignments(committee.id);
      committeeAssignments.forEach(a => monthAssignmentIds.add(a.id));
    }
    
    monthlyBreakdown.push({
      month,
      committeeCount: monthCommittees.length,
      casesAssignedCount: monthAssignmentIds.size,
    });
  }
  
  return {
    year,
    totalCommittees: yearCommittees.length,
    totalCasesAssignedViaCommittees: committeeAssignments.length,
    totalDirectAssignments: allDirectAssignments.length,
    monthlyBreakdown,
  };
}

/**
 * Get audit group workload report
 */
export async function getAuditGroupWorkloadReport(auditGroupId: string): Promise<AuditGroupWorkloadReport> {
  // Get audit group
  const auditGroup = await storage.getGroup(auditGroupId);
  if (!auditGroup) {
    throw new Error('گروه بررسی یافت نشد');
  }
  
  // Get all assignments for this group (optimized query)
  const groupAssignments = await storage.getAllAssignmentsByAuditGroup(auditGroupId);
  
  // Count by source
  const casesViaCommittees = groupAssignments.filter(a => a.assignmentType === 'COMMITTEE').length;
  const directAssignments = groupAssignments.filter(a => a.assignmentType === 'DIRECT').length;
  
  // Get current cases for this group with status "در انتظار بررسی"
  const allCases = await storage.getCases();
  const pendingReviewCases = allCases.filter(
    c => c.currentAuditGroupId === auditGroupId && c.status === 'در انتظار بررسی'
  );
  
  // Get completed cases
  const completedCases = allCases.filter(
    c => c.currentAuditGroupId === auditGroupId && c.status === 'تکمیل شده'
  );
  
  // Get committees that assigned to this group
  const committeeMap = new Map<string, { id: string; title: string; count: number }>();
  
  for (const assignment of groupAssignments) {
    if (assignment.committeeId) {
      const committee = await storage.getCommitteeNew(assignment.committeeId);
      if (committee) {
        if (!committeeMap.has(committee.id)) {
          committeeMap.set(committee.id, {
            id: committee.id,
            title: committee.title,
            count: 0,
          });
        }
        const entry = committeeMap.get(committee.id)!;
        entry.count++;
      }
    }
  }
  
  const committees = Array.from(committeeMap.values()).map(c => ({
    committeeId: c.id,
    committeeTitle: c.title,
    casesCount: c.count,
  }));
  
  // Calculate average cases per committee
  const uniqueCommittees = new Set(groupAssignments.map(a => a.committeeId).filter(Boolean));
  const averageCasesPerCommittee = uniqueCommittees.size > 0
    ? casesViaCommittees / uniqueCommittees.size
    : 0;
  
  return {
    auditGroupId: auditGroup.id,
    auditGroupName: auditGroup.name,
    totalCasesViaCommittees: casesViaCommittees,
    totalDirectAssignments: directAssignments,
    casesPendingReview: pendingReviewCases.length,
    casesCompleted: completedCases.length,
    averageCasesPerCommittee,
    committees,
  };
}

/**
 * Get case assignment history view
 * Immutable and read-only view of all assignments for a case
 */
export async function getCaseAssignmentHistoryView(caseId: string): Promise<CaseAssignmentHistoryView> {
  // Get case
  const caseItem = await storage.getCase(caseId);
  if (!caseItem) {
    throw new Error('قضیه یافت نشد');
  }
  
  // Get entity name
  const entity = caseItem.entityId ? await storage.getEntity(caseItem.entityId) : null;
  const entityName = entity?.name || 'نامشخص';
  
  // Get assignment history
  const history = await getCaseAssignmentHistory(caseId);
  
  // Build history items
  const assignments: AssignmentHistoryItem[] = [];
  
  for (const item of history) {
    assignments.push({
      assignmentId: item.assignmentId,
      committeeId: item.committeeId,
      committeeTitle: item.committeeTitle,
      auditGroupId: item.auditGroupId,
      auditGroupName: item.auditGroupName,
      assignmentDate: item.assignedAt,
      assignedBy: item.assignedBy,
      assignedByName: item.assignedByName,
      assignmentSource: item.assignmentType,
      statusAtAssignment: caseItem.status, // Current status (we could track historical status if needed)
      reason: item.reason,
      previousAssignmentId: item.previousAssignmentId,
    });
  }
  
  return {
    caseId: caseItem.caseId,
    caseNumber: caseItem.caseNumber || undefined,
    entityName,
    assignments,
  };
}

/**
 * Check if user has access to committee reports
 * Only Director, Coordinator, and System Admin can see all reports
 * Audit groups can only see cases assigned to them
 */
export function hasReportAccess(user: User | null | undefined, auditGroupId?: string): boolean {
  if (!user) return false;
  
  // System admin, Director, and Coordinator have full access
  if (hasCommitteeManagementPermission(user)) {
    return true;
  }
  
  // Audit groups can only see their own cases
  if (user.groupId && auditGroupId) {
    return user.groupId === auditGroupId;
  }
  
  // Senior auditors can see their group's reports
  if (user.role === 'senior_auditor' && user.groupId && auditGroupId) {
    return user.groupId === auditGroupId;
  }
  
  return false;
}

/**
 * Get all audit groups for reporting (for dropdowns, etc.)
 */
export async function getAllAuditGroupsForReporting(): Promise<Group[]> {
  const allGroups = await storage.getGroups();
  // Filter to only audit groups (you may need to adjust this based on your group types)
  return allGroups;
}

