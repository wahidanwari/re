/**
 * Ministry Report Service
 * Calculates system-generated fields for Ministry of Finance Detailed Audit Reports
 */

import { storage } from "../storage";
import { Case, CaseReport, GroupTarget } from "@shared/schema";
import jalaali from "jalaali-js";

export interface MinistryReportData {
  groupId: string;
  groupName: string;
  groupNumber: number;
  
  // System-generated fields
  casesDistributed: number; // تعداد نهاد/شرکت های توزیع شده طی برج جاری
  casesCompleted: number; // تعداد نهاد/شرکت های نهائی شده طی برج جاری
  casesWithInstallments: number; // تعداد نهاد/شرکت های قسط شده طی برج جاری
  nonCompliantCases: number; // تعداد نهاد/شرکت های عدم اطاعت پذیر
  casesUnderReview: number; // تعداد نهاد/شرکت های تحت بررسی
  monthlyRevenueTarget: number; // هدف ماهوار عوایدی
  collectedRevenue: number; // عواید جمع آوری شده طی برج جاری
  revenueChangePercent: number; // فیصدی تنقیص/تزئید
  
  // Manual fields (from ministry_reports table)
  lettersReceived?: number; // تعداد مکتوب های وارده
  lettersSent?: number; // تعداد مکتوب های صادره
  inquiriesReceived?: number; // تعداد استعلام های وارده
  inquiriesSent?: number; // تعداد استعلام های صادره
  notes?: string; // ملاحظات
}

/**
 * Calculate system-generated fields for a ministry report
 */
export async function calculateMinistryReportData(
  groupId: string,
  monthShamsi: number,
  yearShamsi: number
): Promise<Omit<MinistryReportData, 'lettersReceived' | 'lettersSent' | 'inquiriesReceived' | 'inquiriesSent' | 'notes'>> {
  // Get all cases for this group
  const allGroupCases = await storage.getCasesByGroup(groupId);
  
  // Convert Shamsi month/year to date range
  const monthStart = jalaali.toGregorian(yearShamsi, monthShamsi, 1);
  const monthEnd = jalaali.toGregorian(
    yearShamsi,
    monthShamsi,
    jalaali.jalaaliMonthLength(yearShamsi, monthShamsi)
  );
  
  const startDate = new Date(monthStart.gy, monthStart.gm - 1, monthStart.gd);
  const endDate = new Date(monthEnd.gy, monthEnd.gm - 1, monthEnd.gd);
  endDate.setHours(23, 59, 59, 999);
  
  // Get group info
  const group = await storage.getGroup(groupId);
  if (!group) {
    throw new Error(`Group ${groupId} not found`);
  }
  
  // Extract group number from name (e.g., "گروه اول" -> 1, "گروه هفتم" -> 7)
  const groupNumberMatch = group.name.match(/گروه\s*(\S+)/);
  let groupNumber = 1;
  if (groupNumberMatch) {
    const groupNamePart = groupNumberMatch[1];
    // Map Dari numbers to digits
    const dariNumbers: Record<string, number> = {
      'اول': 1, 'دوم': 2, 'سوم': 3, 'چهارم': 4, 'پنجم': 5,
      'ششم': 6, 'هفتم': 7, 'هشتم': 8, 'نهم': 9, 'دهم': 10,
      'یازدهم': 11, 'دوازدهم': 12, 'سیزدهم': 13, 'چهاردهم': 14, 'پانزدهم': 15
    };
    groupNumber = dariNumbers[groupNamePart] || parseInt(groupNamePart) || 1;
  }
  
  // 1. Cases distributed this month (cases assigned to this group in this month)
  const casesDistributed = allGroupCases.filter(c => {
    if (!c.createdAt) return false;
    const caseDate = new Date(c.createdAt);
    return caseDate >= startDate && caseDate <= endDate;
  }).length;
  
  // 2. Cases completed this month
  const casesCompleted = allGroupCases.filter(c => {
    if (!c.completedAt) return false;
    const completedDate = new Date(c.completedAt);
    return completedDate >= startDate && completedDate <= endDate;
  }).length;
  
  // 3. Cases with installments (cases moved to "در اقساط" status within this month)
  // Count cases that transitioned to installment status this month using transition history
  // Import database utilities once at the top
  const { db } = await import('../db');
  const { caseStatusTransitions, cases: casesTable, installmentPayments } = await import('@shared/schema');
  const { eq, and, gte, lte } = await import('drizzle-orm');
  
  // Get all transitions to "در اقساط" status for cases in this group within this month
  const installmentTransitions = await db
    .select()
    .from(caseStatusTransitions)
    .innerJoin(casesTable, eq(caseStatusTransitions.caseId, casesTable.id))
    .where(
      and(
        eq(casesTable.receivingGroup, groupId),
        eq(caseStatusTransitions.toStatus, 'در اقساط'),
        gte(caseStatusTransitions.transitionedAt, startDate),
        lte(caseStatusTransitions.transitionedAt, endDate)
      )
    );
  
  const casesWithInstallments = installmentTransitions.length;
  
  // 4. Non-compliant cases (FIELD #1 FIX: Count cases with status "ارسال‌شده به تنفیذ قانون")
  // Count all cases with SENT_TO_LAW_ENFORCEMENT status for this group
  const { CaseStatus } = await import('@shared/schema');
  const nonCompliantCases = allGroupCases.filter(c => 
    c.status === CaseStatus.SENT_TO_LAW_ENFORCEMENT || 
    c.status === 'ارسال‌شده به تنفیذ قانون'
  ).length;
  
  // 5. Cases under review (FIELD #2 FIX: Count all cases assigned to group/auditor and pending review)
  // Count cases where: status = Pending Review or equivalent, AND assigned to group/auditor but not finalized
  const casesUnderReview = allGroupCases.filter(c => {
    const status = c.status;
    
    // Must be assigned to this group (receivingGroup matches) or assigned to an auditor
    const isAssignedToGroup = c.receivingGroup === groupId;
    const isAssignedToAuditor = !!(c.assignedTo || c.assignedAuditor);
    
    if (!isAssignedToGroup && !isAssignedToAuditor) return false;
    
    // Include cases in these statuses (assigned but not finalized):
    // NEW, ASSIGNED, PENDING_REVIEW_BY_SENIOR_AUDITOR, ASSIGNED_TO_AUDITOR, UNDER_AUDIT_REVIEW, PENDING_APPROVAL
    const isUnderReviewStatus = (
      status === CaseStatus.NEW ||
      status === CaseStatus.ASSIGNED ||
      status === CaseStatus.PENDING_REVIEW_BY_SENIOR_AUDITOR ||
      status === CaseStatus.ASSIGNED_TO_AUDITOR ||
      status === CaseStatus.UNDER_AUDIT_REVIEW ||
      status === CaseStatus.IN_PROGRESS ||
      status === CaseStatus.PENDING_APPROVAL ||
      status === 'جدید' ||
      status === 'اختصاص داده شده' ||
      status === 'منتظر بررسی بازرس ارشد' ||
      status === 'اختصاص داده شده به بازرس' ||
      status === 'در جریان بررسی' ||
      status === 'منتظر تایید'
    );
    
    return isUnderReviewStatus;
  }).length;
  
  // 6. Monthly revenue target (FIELD #3 FIX: Pull directly from group_targets table)
  // Dynamically fetch from Group Target Settings - no division, no caching, exact value
  const groupTargets = await storage.getGroupTargets(groupId);
  const yearTarget = groupTargets.find(t => t.yearShamsi === yearShamsi.toString());
  let monthlyRevenueTarget = 0;
  if (yearTarget && yearTarget.targetMonetary) {
    // Parse targetMonetary (handles both "1000000" and "1,000,000" formats)
    // Use the value directly - it's the monthly target configured in Group Target Settings
    const targetValue = parseFloat(yearTarget.targetMonetary.replace(/,/g, '')) || 0;
    monthlyRevenueTarget = targetValue; // No division, no rounding - exact configured value
  }
  
  // 7. Collected revenue this month (FIELD #4 FIX: Sum all payments made during current month)
  // Link to payments table: sum amount_paid where payment_date is within current month/year
  // Join with cases table to ensure proper group mapping
  // Update automatically when payments are added/modified
  let collectedRevenue = 0;
  
  // Helper function to parse Shamsi date string (DD-MM-YYYY) and check if it's in the current month
  const parseShamsiDate = (dateStr: string | null | undefined): Date | null => {
    if (!dateStr) return null;
    try {
      // Parse DD-MM-YYYY format
      const parts = dateStr.split('-');
      if (parts.length === 3) {
        const day = parseInt(parts[0]);
        const month = parseInt(parts[1]);
        const year = parseInt(parts[2]);
        if (!isNaN(day) && !isNaN(month) && !isNaN(year)) {
          const gregorian = jalaali.toGregorian(year, month, day);
          return new Date(gregorian.gy, gregorian.gm - 1, gregorian.gd);
        }
      }
    } catch (error) {
      console.error('Error parsing Shamsi date:', dateStr, error);
    }
    return null;
  };
  
  // 7a. Sum from case reports (مبلغ تحصیل شده طی برج جاری)
  // Aggregate: عواید جمع آوری شده طی برج جاری = SUM(مبلغ تحصیل شده طی برج جاری) for all cases in current month
  // Include cases where payment was made in the current month (based on paymentDate)
  // If paymentDate is not available, use case completion date as fallback
  for (const caseItem of allGroupCases) {
    // Try V2 report first (new format)
    const reportV2 = await storage.getCaseReportV2(caseItem.id);
    if (reportV2 && reportV2.collectedCurrentMonth) {
      // Check if payment date is within the current month
      const paymentDate = parseShamsiDate(reportV2.paymentDate);
      if (paymentDate && paymentDate >= startDate && paymentDate <= endDate) {
        // Handle both string and number formats
        const amount = typeof reportV2.collectedCurrentMonth === 'string' 
          ? parseFloat(reportV2.collectedCurrentMonth.replace(/,/g, '')) || 0
          : (typeof reportV2.collectedCurrentMonth === 'number' ? reportV2.collectedCurrentMonth : 0);
        collectedRevenue += amount;
      } else if (!paymentDate && caseItem.completedAt) {
        // Fallback: if payment date is not available, use case completion date
        const completedDate = new Date(caseItem.completedAt);
        if (completedDate >= startDate && completedDate <= endDate) {
          const amount = typeof reportV2.collectedCurrentMonth === 'string' 
            ? parseFloat(reportV2.collectedCurrentMonth.replace(/,/g, '')) || 0
            : (typeof reportV2.collectedCurrentMonth === 'number' ? reportV2.collectedCurrentMonth : 0);
          collectedRevenue += amount;
        }
      }
    } else {
      // Fallback to old report format
      const report = await storage.getCaseReport(caseItem.id);
      if (report && report.collectedCurrentMonth) {
        // For old format, check if case was completed this month (as proxy for payment date)
        if (caseItem.completedAt) {
          const completedDate = new Date(caseItem.completedAt);
          if (completedDate >= startDate && completedDate <= endDate) {
            const amount = parseFloat(report.collectedCurrentMonth.replace(/,/g, '')) || 0;
            collectedRevenue += amount;
          }
        }
      }
    }
  }
  
  // 7b. Sum from installment payments made during this month
  // Reuse db, casesTable, eq, and, gte, lte from imports above
  const installmentPaymentsThisMonth = await db
    .select({
      amountPaid: installmentPayments.amountPaid,
    })
    .from(installmentPayments)
    .innerJoin(casesTable, eq(installmentPayments.caseId, casesTable.id))
    .where(
      and(
        eq(casesTable.receivingGroup, groupId),
        gte(installmentPayments.paymentDate, startDate),
        lte(installmentPayments.paymentDate, endDate)
      )
    );
  
  for (const payment of installmentPaymentsThisMonth) {
    const amount = typeof payment.amountPaid === 'string'
      ? parseFloat(payment.amountPaid.replace(/,/g, '')) || 0
      : (typeof payment.amountPaid === 'number' ? payment.amountPaid : 0);
    collectedRevenue += amount;
  }
  
  // 8. Revenue achievement percentage (فیصدی تنقیص/تزئید)
  // ADDITIONAL CALCULATION: target_percentage = (عواید جمع آوری شده طی برج جاری / هدف ماهوار عوایدی) * 100
  // Display interpretation:
  //   >100% → group exceeded target
  //   =100% → group reached target
  //   <100% → group behind target
  let revenueChangePercent = 0;
  if (monthlyRevenueTarget > 0) {
    revenueChangePercent = (collectedRevenue / monthlyRevenueTarget) * 100;
    // Round to 2 decimal places for display
    revenueChangePercent = Math.round(revenueChangePercent * 100) / 100;
  } else if (collectedRevenue > 0) {
    // If target is 0 but revenue exists, show as 100% (reached/exceeded)
    revenueChangePercent = 100;
  }
  
  return {
    groupId,
    groupName: group.name,
    groupNumber,
    casesDistributed,
    casesCompleted,
    casesWithInstallments,
    nonCompliantCases,
    casesUnderReview,
    monthlyRevenueTarget,
    collectedRevenue,
    revenueChangePercent,
  };
}

/**
 * Get complete ministry report data for all groups for a given month
 */
export async function getMinistryReportForMonth(
  monthShamsi: number,
  yearShamsi: number
): Promise<MinistryReportData[]> {
  const allGroups = await storage.getGroups();
  const activeGroups = allGroups.filter(g => g.isActive);
  
  const reports: MinistryReportData[] = [];
  
  for (const group of activeGroups) {
    const systemData = await calculateMinistryReportData(group.id, monthShamsi, yearShamsi);
    
    // Get manual fields from ministry_reports table
    const manualData = await storage.getMinistryReport(group.id, monthShamsi, yearShamsi);
    
    reports.push({
      ...systemData,
      lettersReceived: manualData?.lettersReceived ?? 0,
      lettersSent: manualData?.lettersSent ?? 0,
      inquiriesReceived: manualData?.inquiriesReceived ?? 0,
      inquiriesSent: manualData?.inquiriesSent ?? 0,
      notes: manualData?.notes ?? undefined,
    });
  }
  
  // Sort by group number
  reports.sort((a, b) => a.groupNumber - b.groupNumber);
  
  return reports;
}

/**
 * Calculate "مبلغ الباقی تحصیل شده از برج قبلی" (Amount collected from previous month's remaining balance)
 * 
 * CORRECTED IMPLEMENTATION:
 * This field represents the amount collected in the current report month that belongs to 
 * unpaid tax from the previous month(s).
 * 
 * Calculation Logic (STRICT AND TRACEABLE):
 * For report month M:
 * For each case:
 * 1. Retrieve remaining_balance_end_of_month for month (M-1) from monthly snapshots
 * 2. Retrieve total payments made by the case in month (M) from payments table (traced by date)
 * 3. Calculate: collected_from_previous_month = MIN(remaining_balance_M_minus_1, payments_in_M)
 * 
 * Final field value: SUM(collected_from_previous_month) across ALL cases
 * 
 * Rules:
 * - Uses payment dates and monthly snapshot data (no inference)
 * - Installment and non-installment payments are treated equally
 * - Audit status does NOT affect calculation
 * - Does NOT change any case-level formulas
 */
export async function calculateCollectedFromPreviousMonth(
  monthShamsi: number,
  yearShamsi: number
): Promise<number> {
  // Get ALL cases (not filtered by group - this is a system-wide calculation)
  const allCases = await storage.getCases();
  
  // Calculate previous month (M-1)
  let prevYear = yearShamsi;
  let prevMonth = monthShamsi - 1;
  if (prevMonth < 1) {
    prevMonth = 12;
    prevYear = yearShamsi - 1;
  }
  const prevMonthStr = `${prevYear}-${String(prevMonth).padStart(2, '0')}`;
  
  let totalCollectedFromPrevious = 0;
  let processedCases = 0;
  let skippedCases = 0;
  
  // For each case, calculate collected_from_previous_month
  for (const caseItem of allCases) {
    try {
      // 1. Retrieve remaining_balance_end_of_month for month (M-1) from monthly snapshots
      const prevSnapshot = await storage.getCaseMonthlySnapshot(caseItem.id, prevMonthStr);
      
      if (!prevSnapshot) {
        // No previous snapshot exists - this case had no balance at end of previous month
        skippedCases++;
        continue;
      }
      
      // Parse remaining balance from snapshot
      const remainingBalanceM1 = typeof prevSnapshot.remainingBalanceEndOfMonth === 'string'
        ? parseFloat(prevSnapshot.remainingBalanceEndOfMonth) || 0
        : (typeof prevSnapshot.remainingBalanceEndOfMonth === 'number' ? prevSnapshot.remainingBalanceEndOfMonth : 0);
      
      if (remainingBalanceM1 <= 0) {
        // No previous balance - nothing to collect from previous month
        skippedCases++;
        continue;
      }
      
      // 2. Retrieve total payments made by the case in month (M) - traced by payment date
      // This includes both normal and installment payments (treated equally)
      const paymentsInMonthM = await storage.getPaymentsInMonth(caseItem.id, monthShamsi, yearShamsi);
      
      // Sum all payments in month M (all payment types included)
      let totalPaymentsInM = 0;
      for (const payment of paymentsInMonthM) {
        const amount = typeof payment.paymentAmount === 'string'
          ? parseFloat(payment.paymentAmount) || 0
          : (typeof payment.paymentAmount === 'number' ? payment.paymentAmount : 0);
        totalPaymentsInM += amount;
      }
      
      if (totalPaymentsInM <= 0) {
        // No payments in month M - nothing collected from previous month
        skippedCases++;
        continue;
      }
      
      // 3. Calculate: collected_from_previous_month = MIN(remaining_balance_M_minus_1, payments_in_M)
      // This represents the portion of payments in month M that can be attributed to previous month's balance
      const collectedFromPreviousMonth = Math.min(remainingBalanceM1, totalPaymentsInM);
      
      totalCollectedFromPrevious += collectedFromPreviousMonth;
      processedCases++;
      
    } catch (error) {
      // Log error but continue processing other cases
      console.warn(`[COLLECTED_FROM_PREVIOUS] Error calculating for case ${caseItem.id}:`, error);
      skippedCases++;
    }
  }
  
  // Log calculation summary for auditability
  console.log(`[COLLECTED_FROM_PREVIOUS] Month ${yearShamsi}-${String(monthShamsi).padStart(2, '0')}: ` +
    `Total=${totalCollectedFromPrevious.toFixed(2)}, Processed=${processedCases}, Skipped=${skippedCases}`);
  
  return totalCollectedFromPrevious;
}

