/**
 * Report Validation Service V2
 * 3-level validation: Field, Section, Report
 */

import type { CaseReportV2, Case, User } from '@shared/schema';
import { storage } from '../storage';

export interface ValidationError {
  field: string;
  message: string;
  code: string;
}

export interface ValidationWarning {
  field: string;
  message: string;
  code: string;
}

export interface SectionValidationResult {
  section: string;
  isValid: boolean;
  errors: ValidationError[];
  warnings: ValidationWarning[];
  requiredFields: number;
  filledFields: number;
  complete: boolean;
}

export interface ReportValidationResult {
  isValid: boolean;
  errors: ValidationError[];
  warnings: ValidationWarning[];
  sections: {
    section_1: SectionValidationResult;
    section_2: SectionValidationResult;
    section_3: SectionValidationResult;
    section_4: SectionValidationResult;
    section_5: SectionValidationResult;
  };
  completion: {
    percentage: number;
    sectionsComplete: number;
    sectionsTotal: number;
  };
}

/**
 * Validate a single field
 */
function validateField(
  fieldName: string,
  value: any,
  rules: {
    required?: boolean;
    type?: 'string' | 'number' | 'date' | 'email' | 'phone';
    min?: number;
    max?: number;
    pattern?: RegExp;
    custom?: (value: any) => string | null;
  }
): ValidationError | null {
  // Required check
  if (rules.required) {
    if (value === null || value === undefined || value === '' || (typeof value === 'string' && value.trim() === '')) {
      return {
        field: fieldName,
        message: `فیلد ${fieldName} الزامی است`,
        code: 'REQUIRED',
      };
    }
  }

  // Type checks
  if (value !== null && value !== undefined && value !== '') {
    if (rules.type === 'number') {
      const num = typeof value === 'string' ? parseFloat(value) : value;
      if (isNaN(num)) {
        return {
          field: fieldName,
          message: `فیلد ${fieldName} باید عدد باشد`,
          code: 'INVALID_NUMBER',
        };
      }
      if (rules.min !== undefined && num < rules.min) {
        return {
          field: fieldName,
          message: `فیلد ${fieldName} باید حداقل ${rules.min} باشد`,
          code: 'MIN_VALUE',
        };
      }
      if (rules.max !== undefined && num > rules.max) {
        return {
          field: fieldName,
          message: `فیلد ${fieldName} باید حداکثر ${rules.max} باشد`,
          code: 'MAX_VALUE',
        };
      }
    }

    if (rules.type === 'email' && typeof value === 'string') {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(value)) {
        return {
          field: fieldName,
          message: `فیلد ${fieldName} باید یک ایمیل معتبر باشد`,
          code: 'INVALID_EMAIL',
        };
      }
    }

    if (rules.type === 'date' && typeof value === 'string') {
      // Basic date validation (can be enhanced)
      if (!/^\d{2}-\d{2}-\d{4}$/.test(value)) {
        return {
          field: fieldName,
          message: `فیلد ${fieldName} باید تاریخ معتبر باشد (DD-MM-YYYY)`,
          code: 'INVALID_DATE',
        };
      }
    }

    if (rules.pattern && typeof value === 'string') {
      if (!rules.pattern.test(value)) {
        return {
          field: fieldName,
          message: `فیلد ${fieldName} فرمت نامعتبر دارد`,
          code: 'INVALID_FORMAT',
        };
      }
    }

    if (rules.custom) {
      const customError = rules.custom(value);
      if (customError) {
        return {
          field: fieldName,
          message: customError,
          code: 'CUSTOM_VALIDATION',
        };
      }
    }
  }

  return null;
}

/**
 * Validate Section 1: Entity Details
 */
function validateSection1(report: CaseReportV2, caseItem: Case): SectionValidationResult {
  const errors: ValidationError[] = [];
  const warnings: ValidationWarning[] = [];
  let filledFields = 0;
  // Section 1 requires the 6 auto-populated fields + capitalPeriod
  const requiredFields = 7; // Basic auto-populated fields + capitalPeriod

  // Basic fields (auto-populated, should always be present)
  if (report.companyName) filledFields++;
  if (report.tin) filledFields++;
  if (report.businessNature) filledFields++;
  if (report.groupReferrer) filledFields++;
  if (report.referralDate) filledFields++;
  if (report.periodsUnderReview) filledFields++;

  // capitalPeriod is required for section_1
  const capitalPeriodError = validateField('capitalPeriod', report.capitalPeriod, {
    required: true,
    type: 'string',
    custom: (value) => {
      if (!value || (typeof value === 'string' && value.trim() === '')) {
        return 'دوران سرمایه الزامی است';
      }
      return null;
    },
  });
  if (capitalPeriodError) {
    errors.push(capitalPeriodError);
  } else if (report.capitalPeriod && report.capitalPeriod.trim() !== '') {
    filledFields++;
  }

  // finalDocumentDate is optional for section_1 (validated in section_5)
  // Only validate format if provided
  if (report.finalDocumentDate && report.finalDocumentDate.trim() !== '') {
    const finalDocError = validateField('finalDocumentDate', report.finalDocumentDate, {
      required: false,
      type: 'date',
    });
    if (finalDocError) {
      errors.push(finalDocError);
    }
  }

  // Date validation: finalDocumentDate should be after referralDate
  if (report.finalDocumentDate && report.referralDate) {
    // Basic validation (can be enhanced with proper date parsing)
    // This is a warning, not an error
  }

  // Optional fields validation
  if (report.email) {
    const emailError = validateField('email', report.email, { type: 'email' });
    if (emailError) errors.push(emailError);
  }

  return {
    section: 'section_1',
    isValid: errors.length === 0,
    errors,
    warnings,
    requiredFields,
    filledFields,
    complete: errors.length === 0 && filledFields >= requiredFields,
  };
}

/**
 * Validate Section 2: Extractions
 */
function validateSection2(report: CaseReportV2): SectionValidationResult {
  const errors: ValidationError[] = [];
  const warnings: ValidationWarning[] = [];
  let filledFields = 0;
  const requiredFields = 16; // All tax types + financial + status + attachment + finalDocumentDate

  // Tax types (can be 0, but must be numbers)
  const taxFields = [
    'salaryTax', 'rentTax', 'contractTax', 'profitTransactionTax', 'incomeTax',
    'withholdingTax', 'penaltyTax', 'interest', 'otherTaxes',
  ];

  taxFields.forEach(field => {
    const value = (report as any)[field];
    const error = validateField(field, value, {
      required: true,
      type: 'number',
      min: 0,
    });
    if (error) {
      errors.push(error);
    } else {
      filledFields++;
    }
  });

  // Financial calculations
  const financialFields = [
    'reducedLoss', 'reducedRemainingAmount', 'confirmedAmount',
    'collectedCurrentMonth', 'remainingCollectible',
  ];

  financialFields.forEach(field => {
    const value = (report as any)[field];
    const error = validateField(field, value, {
      required: true,
      type: 'number',
      min: 0,
    });
    if (error) {
      errors.push(error);
    } else {
      filledFields++;
    }
  });

  // Activity status
  const activityStatusError = validateField('activityStatus', report.activityStatus, {
    required: true,
    custom: (value) => {
      if (value !== 'فعال' && value !== 'عدم فعالیت') {
        return 'وضعیت فعالیت باید "فعال" یا "عدم فعالیت" باشد';
      }
      return null;
    },
  });
  if (activityStatusError) {
    errors.push(activityStatusError);
  } else if (report.activityStatus) {
    filledFields++;
  }

  // Attachment
  const attachmentNumberError = validateField('attachmentNumber', report.attachmentNumber, {
    required: true,
  });
  if (attachmentNumberError) {
    errors.push(attachmentNumberError);
  } else if (report.attachmentNumber) {
    filledFields++;
  }

  const attachmentDateError = validateField('attachmentDate', report.attachmentDate, {
    required: true,
    type: 'date',
  });
  if (attachmentDateError) {
    errors.push(attachmentDateError);
  } else if (report.attachmentDate) {
    filledFields++;
  }

  // Final document date (shown in section_5 UI but validated here as part of completion)
  const finalDocumentDateError = validateField('finalDocumentDate', report.finalDocumentDate, {
    required: true,
    type: 'date',
  });
  if (finalDocumentDateError) {
    errors.push(finalDocumentDateError);
  } else if (report.finalDocumentDate) {
    filledFields++;
  }

  // Business rule: Calculate totals and validate
  const totalTax = Number(report.salaryTax || 0) + Number(report.rentTax || 0) + Number(report.contractTax || 0) +
    Number(report.profitTransactionTax || 0) + Number(report.incomeTax || 0) + Number(report.withholdingTax || 0) +
    Number(report.penaltyTax || 0) + Number(report.interest || 0) + Number(report.otherTaxes || 0);

  if (report.confirmedAmount && Math.abs(Number(report.confirmedAmount) - totalTax) > 0.01) {
    warnings.push({
      field: 'confirmedAmount',
      message: `مبلغ تثبیت شده (${report.confirmedAmount}) با مجموع مالیات‌ها (${totalTax}) مطابقت ندارد`,
      code: 'AMOUNT_MISMATCH',
    });
  }

  const totalCollected = Number(report.collectedCurrentMonth || 0);
  const totalRemaining = Number(report.remainingCollectible || 0);
  const confirmed = Number(report.confirmedAmount || 0);

  if (Math.abs(totalCollected + totalRemaining - confirmed) > 0.01) {
    warnings.push({
      field: 'remainingCollectible',
      message: `مجموع تحصیل شده و باقیمانده (${totalCollected + totalRemaining}) با مبلغ تثبیت شده (${confirmed}) مطابقت ندارد`,
      code: 'COLLECTION_MISMATCH',
    });
  }

  return {
    section: 'section_2',
    isValid: errors.length === 0,
    errors,
    warnings,
    requiredFields,
    filledFields,
    complete: errors.length === 0 && filledFields >= requiredFields,
  };
}

/**
 * Validate Section 3: Findings & Recommendations
 * NOTE: Section 3 is not in the current form UI, so this section is optional
 * Fields may exist in the database but are not required for completion
 */
function validateSection3(report: CaseReportV2): SectionValidationResult {
  // Section 3 is optional - validate fields if provided, but don't require them
  const errors: ValidationError[] = [];
  const warnings: ValidationWarning[] = [];
  
  // Only validate format if fields are provided, but don't require them
  if (report.findingsSummary) {
    const findingsSummaryError = validateField('findingsSummary', report.findingsSummary, {
      required: false,
      min: 50,
      custom: (value) => {
        if (typeof value === 'string' && value.trim().length < 50) {
          return 'خلاصه یافته‌ها باید حداقل 50 کاراکتر باشد';
        }
        return null;
      },
    });
    if (findingsSummaryError) {
      errors.push(findingsSummaryError);
    }
  }

  if (report.riskAssessment) {
    const riskAssessmentError = validateField('riskAssessment', report.riskAssessment, {
      required: false,
      custom: (value) => {
        if (value !== 'کم' && value !== 'متوسط' && value !== 'زیاد') {
          return 'ارزیابی ریسک باید "کم"، "متوسط" یا "زیاد" باشد';
        }
        return null;
      },
    });
    if (riskAssessmentError) {
      errors.push(riskAssessmentError);
    }
  }

  if (report.recommendations) {
    const recommendationsError = validateField('recommendations', report.recommendations, {
      required: false,
      min: 50,
      custom: (value) => {
        if (typeof value === 'string' && value.trim().length < 50) {
          return 'توصیه‌ها باید حداقل 50 کاراکتر باشد';
        }
        return null;
      },
    });
    if (recommendationsError) {
      errors.push(recommendationsError);
    }
  }

  // Follow-up date validation - only if followUpRequired is true
  if (report.followUpRequired && !report.followUpDate) {
    errors.push({
      field: 'followUpDate',
      message: 'در صورت نیاز به پیگیری، تاریخ پیگیری الزامی است',
      code: 'FOLLOW_UP_DATE_REQUIRED',
    });
  }

  // Section 3 is optional, so always complete
  return {
    section: 'section_3',
    isValid: errors.length === 0,
    errors,
    warnings,
    requiredFields: 0,
    filledFields: 0,
    complete: true, // Always complete since section is optional
  };
}

/**
 * Validate Section 4: Supporting Documents
 * NOTE: Section 4 was removed from the form UI, so this section is now optional
 * Fields may exist in the database but are not required for completion
 */
function validateSection4(report: CaseReportV2): SectionValidationResult {
  // Section 4 is optional - always return as complete since it's not in the form
  return {
    section: 'section_4',
    isValid: true,
    errors: [],
    warnings: [],
    requiredFields: 0,
    filledFields: 0,
    complete: true, // Always complete since section is optional
  };
}

/**
 * Validate Section 5: Approval & Signatures
 * NOTE: finalDocumentDate, activityStatus, attachmentNumber, attachmentDate are shown in section_5 UI
 * but are validated in section_2. This section only validates approval/signature fields.
 */
function validateSection5(report: CaseReportV2): SectionValidationResult {
  const errors: ValidationError[] = [];
  const warnings: ValidationWarning[] = [];
  let filledFields = 0;
  const requiredFields = 1; // Only preparedBy is required (auto-set)

  // Prepared by is auto-set, so it's always present if report exists
  if (report.preparedBy) {
    filledFields++;
  }

  // Review validation: both or neither
  if ((report.reviewedBy && !report.reviewedAt) || (!report.reviewedBy && report.reviewedAt)) {
    errors.push({
      field: 'reviewedBy',
      message: 'اگر بررسی انجام شده، هم بررسی‌کننده و هم تاریخ بررسی باید مشخص شوند',
      code: 'INCOMPLETE_REVIEW',
    });
  }

  // Section 5 is always complete since preparedBy is auto-set
  // The fields shown in section_5 UI (finalDocumentDate, activityStatus, etc.) are validated in section_2
  return {
    section: 'section_5',
    isValid: errors.length === 0,
    errors,
    warnings,
    requiredFields,
    filledFields,
    complete: errors.length === 0 && filledFields >= requiredFields,
  };
}

/**
 * Validate entire report (all sections)
 */
export async function validateReport(
  report: CaseReportV2,
  caseItem: Case
): Promise<ReportValidationResult> {
  const section1 = validateSection1(report, caseItem);
  const section2 = validateSection2(report);
  const section3 = validateSection3(report);
  const section4 = validateSection4(report);
  const section5 = validateSection5(report);

  const allErrors = [
    ...section1.errors,
    ...section2.errors,
    ...section3.errors,
    ...section4.errors,
    ...section5.errors,
  ];

  const allWarnings = [
    ...section1.warnings,
    ...section2.warnings,
    ...section3.warnings,
    ...section4.warnings,
    ...section5.warnings,
  ];

  // Sections 3 and 4 are optional (not in form), so only count sections 1, 2, 5
  const sectionsComplete = [
    section1.complete,
    section2.complete,
    section5.complete,
  ].filter(Boolean).length;

  // Only validate required sections (1, 2, 5) - sections 3 and 4 are optional
  const requiredSectionsErrors = [
    ...section1.errors,
    ...section2.errors,
    ...section5.errors,
  ];

  return {
    isValid: requiredSectionsErrors.length === 0,
    errors: allErrors, // Include all errors for reference, but validation only checks required sections
    warnings: allWarnings,
    sections: {
      section_1: section1,
      section_2: section2,
      section_3: section3,
      section_4: section4,
      section_5: section5,
    },
    completion: {
      percentage: Math.round((sectionsComplete / 3) * 100), // 3 required sections (1, 2, 5)
      sectionsComplete,
      sectionsTotal: 3, // Only count required sections
    },
  };
}

/**
 * Validate specific section
 */
export async function validateSection(
  report: CaseReportV2,
  section: 'section_1' | 'section_2' | 'section_3' | 'section_4' | 'section_5',
  caseItem: Case
): Promise<SectionValidationResult> {
  switch (section) {
    case 'section_1':
      return validateSection1(report, caseItem);
    case 'section_2':
      return validateSection2(report);
    case 'section_3':
      return validateSection3(report);
    case 'section_4':
      return validateSection4(report);
    case 'section_5':
      return validateSection5(report);
    default:
      throw new Error(`Unknown section: ${section}`);
  }
}

