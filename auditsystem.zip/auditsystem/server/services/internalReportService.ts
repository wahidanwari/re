/**
 * Internal Report Service
 * Generates internal reports from completed case report forms
 */

import { storage } from '../storage';
import { db } from '../db';
import { cases, caseReportsV2, caseReports, groups } from '@shared/schema';
import { eq, and, sql, inArray } from 'drizzle-orm';
import jalaali from 'jalaali-js';

export interface InternalReportRow {
  // Section 1: مشخصات نهاد
  companyName: string; // نام نهاد
  tin: string; // نمبر تشخیصیه
  businessNature: string | null; // نوع تشبث
  groupReferrer: string; // آمریت ارجاع کننده
  periodsUnderReview: string; // سالهای بررسی
  capitalPeriod: string | null; // دوران سرمایه
  
  // Section 2: بیرون‌نویسی‌ها
  salaryTax: string | number | null; // مالیه موضوعی معاشات
  rentTax: string | number | null; // مالیه موضوعی بر کرایه
  contractTax: string | number | null; // مالیه موضوعی قراردادی
  profitTransactionTax: string | number | null; // مالیات معاملات انتفاعی
  incomeTax: string | number | null; // مالیات بر عایدات
  reducedLoss: string | number | null; // ضرر کاهش یافته
  reducedRemainingAmount: string | number | null; // مبلغ فاضل تحویل کاهش یافته
  confirmedAmount: string | number | null; // مبلغ تثبیت شده
  collectedCurrentMonth: string | number | null; // مبلغ تحصیل شده طی برج جاری
  remainingCollectible: string | number | null; // الباقی مبلغ قابل تحصیل
  activityStatus: string | null; // وضعیت فعالیت
  attachmentNumber: string | null; // نمبر آویز
  attachmentDate: string | null; // تاریخ آویز
  
  // Metadata
  groupId: string;
  groupName: string;
  caseId: string;
}

export interface InternalReportTotals {
  salaryTax: number;
  rentTax: number;
  contractTax: number;
  profitTransactionTax: number;
  incomeTax: number;
  reducedLoss: number;
  reducedRemainingAmount: number;
  confirmedAmount: number;
  collectedCurrentMonth: number;
  remainingCollectible: number;
}

export interface InternalReportSummaryFields {
  confirmedRevenueCurrentMonth: number; // عواید تثبیت شده طی برج جاری
  collectedRevenueCurrentMonth: number; // عواید تحصیل شده طی برج جاری
  remainingCollectibleAmount: number; // الباقی مبلغ قابل تحصیل
  previousMonthRemainingCollected: number; // مبلغ الباقی تحصیل شده از برج قبلی
}

/**
 * Calculate summary fields for a case report
 * These are per-case fields that appear in each row
 */
export function calculateSummaryFieldsForCase(
  row: InternalReportRow,
  previousMonthRemaining: number = 0
): InternalReportSummaryFields {
  // Helper to parse numeric value
  const parseNumeric = (value: string | number | null | undefined): number => {
    if (value === null || value === undefined) return 0;
    if (typeof value === 'number') return isNaN(value) ? 0 : value;
    if (typeof value === 'string') {
      const cleaned = value.replace(/,/g, '').trim();
      if (cleaned === '' || cleaned === '-') return 0;
      const parsed = parseFloat(cleaned);
      return isNaN(parsed) ? 0 : parsed;
    }
    return 0;
  };

  // عواید تثبیت شده طی برج جاری = مبلغ تثبیت شده (same value)
  const confirmedRevenueCurrentMonth = parseNumeric(row.confirmedAmount);
  
  // عواید تحصیل شده طی برج جاری = مبلغ تحصیل شده طی برج جاری (same value)
  const collectedRevenueCurrentMonth = parseNumeric(row.collectedCurrentMonth);
  
  // الباقی مبلغ قابل تحصیل = الباقی مبلغ قابل تحصیل (same value)
  const remainingCollectibleAmount = parseNumeric(row.remainingCollectible);
  
  // مبلغ الباقی تحصیل شده از برج قبلی = previous month's remaining that was collected this month
  // For now, we'll use 0 as default, but this could be enhanced to check previous month data
  const previousMonthRemainingCollected = previousMonthRemaining;

  return {
    confirmedRevenueCurrentMonth,
    collectedRevenueCurrentMonth,
    remainingCollectibleAmount,
    previousMonthRemainingCollected,
  };
}

/**
 * Get internal report data for a specific group and month
 */
export async function getInternalReportForGroup(
  groupId: string,
  monthShamsi: number,
  yearShamsi: number
): Promise<InternalReportRow[]> {
  // Get all completed cases for the group
  const allGroupCases = await storage.getCasesByGroup(groupId);
  
  // Filter completed cases
  const completedCases = allGroupCases.filter(c => 
    c.status === 'تکمیل شده' || c.status === 'COMPLETED'
  );
  
  console.log(`[Internal Report] Group ${groupId}: Found ${completedCases.length} completed cases out of ${allGroupCases.length} total cases`);
  
  if (completedCases.length === 0) {
    console.log(`[Internal Report] No completed cases found for group ${groupId}`);
    return [];
  }
  
  const caseIds = completedCases.map(c => c.id);
  
  // Get all case reports V2 for these cases (status can be 'completed' or 'draft' if case is completed)
  const reportsV2 = await db
    .select()
    .from(caseReportsV2)
    .where(inArray(caseReportsV2.caseId, caseIds));
  
  console.log(`[Internal Report] Found ${reportsV2.length} V2 reports for ${caseIds.length} completed cases`);
  
  // Also get old case reports for backward compatibility
  const reportsOld = await db
    .select()
    .from(caseReports)
    .where(inArray(caseReports.caseId, caseIds));
  
  console.log(`[Internal Report] Found ${reportsOld.length} old reports for ${caseIds.length} completed cases`);
  
  // Create a map of caseId -> report (prefer V2, fallback to old)
  const reportMap = new Map<string, any>();
  
  // Add V2 reports
  for (const report of reportsV2) {
    // Include if status is 'completed' OR if case is completed (even if report status is 'draft')
    const caseItem = completedCases.find(c => c.id === report.caseId);
    if (caseItem && (report.status === 'completed' || caseItem.status === 'تکمیل شده')) {
      reportMap.set(report.caseId, report);
      console.log(`[Internal Report] Added V2 report for case ${report.caseId}, status: ${report.status}`);
    }
  }
  
  // Add old reports for cases that don't have V2 reports
  for (const report of reportsOld) {
    if (!reportMap.has(report.caseId)) {
      // Convert old report format to V2-like format
      // Old reports don't have companyName, tin, etc. - those come from case
      reportMap.set(report.caseId, {
        ...report,
        companyName: null, // Will use case data
        tin: null,
        businessNature: null,
        groupReferrer: null,
        referralDate: null,
        periodsUnderReview: null,
        status: 'completed', // Old reports are considered completed
        // Map old text fields to numeric where needed
        salaryTax: report.salaryTax ? (isNaN(parseFloat(report.salaryTax)) ? null : parseFloat(report.salaryTax)) : null,
        rentTax: report.rentTax ? (isNaN(parseFloat(report.rentTax)) ? null : parseFloat(report.rentTax)) : null,
        contractTax: report.contractTax ? (isNaN(parseFloat(report.contractTax)) ? null : parseFloat(report.contractTax)) : null,
        profitTransactionTax: report.profitTransactionTax ? (isNaN(parseFloat(report.profitTransactionTax)) ? null : parseFloat(report.profitTransactionTax)) : null,
        incomeTax: report.incomeTax ? (isNaN(parseFloat(report.incomeTax)) ? null : parseFloat(report.incomeTax)) : null,
        reducedLoss: report.reducedLoss ? (isNaN(parseFloat(report.reducedLoss)) ? null : parseFloat(report.reducedLoss)) : null,
        reducedRemainingAmount: report.reducedRemainingAmount ? (isNaN(parseFloat(report.reducedRemainingAmount)) ? null : parseFloat(report.reducedRemainingAmount)) : null,
        confirmedAmount: report.confirmedAmount ? (isNaN(parseFloat(report.confirmedAmount)) ? null : parseFloat(report.confirmedAmount)) : null,
        collectedCurrentMonth: report.collectedCurrentMonth ? (isNaN(parseFloat(report.collectedCurrentMonth)) ? null : parseFloat(report.collectedCurrentMonth)) : null,
        remainingCollectible: report.remainingCollectible ? (isNaN(parseFloat(report.remainingCollectible)) ? null : parseFloat(report.remainingCollectible)) : null,
      });
      console.log(`[Internal Report] Added old report for case ${report.caseId}`);
    }
  }
  
  console.log(`[Internal Report] Total reports mapped: ${reportMap.size}`);
  
  // Get group info
  const group = await storage.getGroup(groupId);
  const groupName = group?.name || groupId;
  
  // Map reports to internal report rows and filter by month
  const reportRows: InternalReportRow[] = [];
  
  for (const [caseId, report] of reportMap.entries()) {
    const caseItem = completedCases.find(c => c.id === caseId);
    if (!caseItem) continue;
    
    // Filter by month - use completedAt if available, otherwise use report createdAt or case createdAt
    let dateToCheck: Date | null = null;
    if (caseItem.completedAt) {
      dateToCheck = new Date(caseItem.completedAt);
    } else if (report.createdAt) {
      dateToCheck = new Date(report.createdAt);
    } else if (caseItem.createdAt) {
      dateToCheck = new Date(caseItem.createdAt);
    }
    
    if (dateToCheck) {
      const shamsiDate = jalaali.toJalaali(dateToCheck);
      if (shamsiDate.jm !== monthShamsi || shamsiDate.jy !== yearShamsi) {
        console.log(`[Internal Report] Case ${caseId} date ${shamsiDate.jy}/${shamsiDate.jm} doesn't match requested ${yearShamsi}/${monthShamsi}`);
        continue; // Skip if not in the requested month
      }
    } else {
      // If no date available, skip this case
      console.log(`[Internal Report] Case ${caseId} has no date available, skipping`);
      continue;
    }
    
    // Convert numeric fields to string for display
    const formatValue = (value: any): string | number | null => {
      if (value === null || value === undefined) return null;
      if (typeof value === 'number') return value;
      if (typeof value === 'string') {
        // Try to parse as number, if successful return as number, otherwise return string
        const num = parseFloat(value);
        return isNaN(num) ? value : num;
      }
      return String(value);
    };
    
    reportRows.push({
      companyName: report.companyName || caseItem.companyName || '',
      tin: report.tin || caseItem.tin || '',
      businessNature: report.businessNature || caseItem.businessNature || null,
      groupReferrer: report.groupReferrer || caseItem.groupReferrer || '',
      periodsUnderReview: report.periodsUnderReview || caseItem.periodsUnderReview || '',
      capitalPeriod: report.capitalPeriod || null,
      
      salaryTax: formatValue(report.salaryTax),
      rentTax: formatValue(report.rentTax),
      contractTax: formatValue(report.contractTax),
      profitTransactionTax: formatValue(report.profitTransactionTax),
      incomeTax: formatValue(report.incomeTax),
      reducedLoss: formatValue(report.reducedLoss),
      reducedRemainingAmount: formatValue(report.reducedRemainingAmount),
      confirmedAmount: formatValue(report.confirmedAmount),
      collectedCurrentMonth: formatValue(report.collectedCurrentMonth),
      remainingCollectible: formatValue(report.remainingCollectible),
      activityStatus: report.activityStatus || null,
      attachmentNumber: report.attachmentNumber || null,
      attachmentDate: report.attachmentDate || null,
      
      groupId,
      groupName,
      caseId: report.caseId || caseId,
    });
  }
  
  console.log(`[Internal Report] Returning ${reportRows.length} report rows for group ${groupId}, month ${monthShamsi}/${yearShamsi}`);

  return reportRows;
}

/**
 * Calculate totals across all report rows
 */
export function calculateInternalReportTotals(rows: InternalReportRow[]): InternalReportTotals {
  const totals: InternalReportTotals = {
    salaryTax: 0,
    rentTax: 0,
    contractTax: 0,
    profitTransactionTax: 0,
    incomeTax: 0,
    reducedLoss: 0,
    reducedRemainingAmount: 0,
    confirmedAmount: 0,
    collectedCurrentMonth: 0,
    remainingCollectible: 0,
  };

  // Helper function to parse numeric value
  const parseNumeric = (value: string | number | null | undefined): number => {
    if (value === null || value === undefined) return 0;
    if (typeof value === 'number') return isNaN(value) ? 0 : value;
    if (typeof value === 'string') {
      // Remove commas and parse
      const cleaned = value.replace(/,/g, '').trim();
      if (cleaned === '' || cleaned === '-') return 0;
      const parsed = parseFloat(cleaned);
      return isNaN(parsed) ? 0 : parsed;
    }
    return 0;
  };

  // Sum all numeric fields across all rows
  for (const row of rows) {
    totals.salaryTax += parseNumeric(row.salaryTax);
    totals.rentTax += parseNumeric(row.rentTax);
    totals.contractTax += parseNumeric(row.contractTax);
    totals.profitTransactionTax += parseNumeric(row.profitTransactionTax);
    totals.incomeTax += parseNumeric(row.incomeTax);
    totals.reducedLoss += parseNumeric(row.reducedLoss);
    totals.reducedRemainingAmount += parseNumeric(row.reducedRemainingAmount);
    totals.confirmedAmount += parseNumeric(row.confirmedAmount);
    totals.collectedCurrentMonth += parseNumeric(row.collectedCurrentMonth);
    totals.remainingCollectible += parseNumeric(row.remainingCollectible);
  }

  return totals;
}

/**
 * Get internal report data for all groups for a given month
 */
export async function getInternalReportForAllGroups(
  monthShamsi: number,
  yearShamsi: number
): Promise<Record<string, InternalReportRow[]>> {
  const allGroups = await storage.getGroups();
  const activeGroups = allGroups.filter(g => g.isActive);
  
  const reportsByGroup: Record<string, InternalReportRow[]> = {};
  
  for (const group of activeGroups) {
    const groupReports = await getInternalReportForGroup(
      group.id,
      monthShamsi,
      yearShamsi
    );
    
    if (groupReports.length > 0) {
      reportsByGroup[group.id] = groupReports;
    }
  }
  
  return reportsByGroup;
}

/**
 * Get Tax Installment and Law Enforcement case counts for a specific group and month
 */
export async function getTaxInstallmentLawEnforcementForGroup(
  groupId: string,
  monthShamsi: number,
  yearShamsi: number
): Promise<{
  installmentCases: {
    total: number;
    completed: number;
    pending: number;
    amountFixed: number;
  };
  lawEnforcementCases: {
    total: number;
    completed: number;
    pending: number;
    amountFixed: number;
  };
}> {
  // Get all cases for the group
  const allGroupCases = await storage.getCasesByGroup(groupId);
  
  // Filter by month and year
  const casesInMonth = allGroupCases.filter(c => {
    let dateToCheck: Date | null = null;
    if (c.completedAt) {
      dateToCheck = new Date(c.completedAt);
    } else if (c.createdAt) {
      dateToCheck = new Date(c.createdAt);
    }
    
    if (dateToCheck) {
      const shamsiDate = jalaali.toJalaali(dateToCheck);
      return shamsiDate.jm === monthShamsi && shamsiDate.jy === yearShamsi;
    }
    return false;
  });
  
  // Helper to parse numeric value
  const parseNumeric = (value: string | number | null | undefined): number => {
    if (value === null || value === undefined) return 0;
    if (typeof value === 'number') return isNaN(value) ? 0 : value;
    if (typeof value === 'string') {
      const cleaned = value.replace(/,/g, '').trim();
      const parsed = parseFloat(cleaned);
      return isNaN(parsed) ? 0 : parsed;
    }
    return 0;
  };
  
  // Helper to get confirmed amount
  const getConfirmedAmount = async (caseId: string): Promise<number> => {
    const [reportV2] = await db
      .select()
      .from(caseReportsV2)
      .where(eq(caseReportsV2.caseId, caseId))
      .limit(1);
    
    if (reportV2?.confirmedAmount) {
      return parseNumeric(reportV2.confirmedAmount);
    }
    
    const [report] = await db
      .select()
      .from(caseReports)
      .where(eq(caseReports.caseId, caseId))
      .limit(1);
    
    if (report?.confirmedAmount) {
      return parseNumeric(report.confirmedAmount);
    }
    
    return 0;
  };
  
  const installmentCases = {
    total: 0,
    completed: 0,
    pending: 0,
    amountFixed: 0,
  };
  
  const lawEnforcementCases = {
    total: 0,
    completed: 0,
    pending: 0,
    amountFixed: 0,
  };
  
  // Import CaseStatus
  const { CaseStatus } = await import('@shared/schema');
  
  for (const caseItem of casesInMonth) {
    const isInstallment = caseItem.status === CaseStatus.INSTALLMENT || caseItem.status === 'در اقساط';
    const isLawEnforcement = 
      caseItem.status === CaseStatus.SENT_TO_LAW_ENFORCEMENT || 
      caseItem.status === 'ارسال‌شده به تنفیذ قانون' ||
      caseItem.status === CaseStatus.REFERRED_TO_ENFORCEMENT ||
      caseItem.status === 'ارسال‌ شده به تنفیذ قانون';
    
    if (!isInstallment && !isLawEnforcement) continue;
    
    const isCompleted = caseItem.status === 'تکمیل شده' || caseItem.status === 'COMPLETED' || caseItem.completedAt !== null;
    
    if (isInstallment) {
      installmentCases.total++;
      if (isCompleted) {
        installmentCases.completed++;
        installmentCases.amountFixed += await getConfirmedAmount(caseItem.id);
      } else {
        installmentCases.pending++;
      }
    } else if (isLawEnforcement) {
      lawEnforcementCases.total++;
      if (isCompleted) {
        lawEnforcementCases.completed++;
        lawEnforcementCases.amountFixed += await getConfirmedAmount(caseItem.id);
      } else {
        lawEnforcementCases.pending++;
      }
    }
  }
  
  return {
    installmentCases,
    lawEnforcementCases,
  };
}

