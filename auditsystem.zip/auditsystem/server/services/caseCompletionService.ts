/**
 * Case Completion Service
 * Determines completion type based on financial state
 * 
 * Completion Types:
 * - COMPLETED_FULLY_PAID: All taxes paid
 * - COMPLETED_WITH_INSTALLMENTS: Paid via installments, remaining balance > 0
 * - COMPLETED_WITH_REMAINING_BALANCE: Audit complete, remaining balance > 0, no installments
 */

import type { Case } from '@shared/schema';
import type { IStorage } from '../storage';

export type CompletionType = 
  | 'COMPLETED_FULLY_PAID'
  | 'COMPLETED_WITH_INSTALLMENTS'
  | 'COMPLETED_WITH_REMAINING_BALANCE';

export interface CompletionTypeResult {
  type: CompletionType;
  confirmedAmount: number;
  totalPaid: number;
  remainingBalance: number;
  hasInstallmentPayments: boolean;
}

/**
 * Determines the completion type for a case based on its financial state
 */
export async function determineCompletionType(
  caseItem: Case,
  storage: IStorage
): Promise<CompletionTypeResult> {
  // Get confirmedAmount (مبلغ تثبیت شده)
  const reportV2 = await storage.getCaseReportV2(caseItem.id);
  const report = reportV2 || await storage.getCaseReport(caseItem.id);
  
  let confirmedAmount = 0;
  if (reportV2?.confirmedAmount) {
    confirmedAmount = typeof reportV2.confirmedAmount === 'string'
      ? parseFloat(reportV2.confirmedAmount.toString().replace(/,/g, '')) || 0
      : (typeof reportV2.confirmedAmount === 'number' ? reportV2.confirmedAmount : 0);
  } else if (report?.confirmedAmount) {
    confirmedAmount = typeof report.confirmedAmount === 'string'
      ? parseFloat(report.confirmedAmount.replace(/,/g, '')) || 0
      : 0;
  }
  
  // Get all payments
  const allPayments = await storage.getPaymentsByCase(caseItem.id);
  
  // Calculate total paid
  let totalPaid = 0;
  for (const payment of allPayments) {
    const amount = typeof payment.paymentAmount === 'string'
      ? parseFloat(payment.paymentAmount) || 0
      : (typeof payment.paymentAmount === 'number' ? payment.paymentAmount : 0);
    totalPaid += amount;
  }
  
  // Calculate remaining balance
  const remainingBalance = Math.max(0, confirmedAmount - totalPaid);
  
  // Check if there are installment payments
  const hasInstallmentPayments = allPayments.some(p => p.paymentType === 'installment');
  
  // Also check installment payments table for legacy data
  const installmentPayments = await storage.getInstallmentPayments(caseItem.id);
  const hasInstallmentPlan = installmentPayments.length > 0 || hasInstallmentPayments;
  
  // Determine completion type
  let type: CompletionType;
  
  // Rule 1: If fully paid (remaining balance <= 0 or very small), it's COMPLETED_FULLY_PAID
  if (remainingBalance <= 0.01) {
    type = 'COMPLETED_FULLY_PAID';
  }
  // Rule 2: If has installment payments/plan AND remaining balance > 0, it's COMPLETED_WITH_INSTALLMENTS
  else if (hasInstallmentPlan && remainingBalance > 0) {
    type = 'COMPLETED_WITH_INSTALLMENTS';
  }
  // Rule 3: Otherwise, it's COMPLETED_WITH_REMAINING_BALANCE
  else {
    type = 'COMPLETED_WITH_REMAINING_BALANCE';
  }
  
  return {
    type,
    confirmedAmount,
    totalPaid,
    remainingBalance,
    hasInstallmentPayments: hasInstallmentPlan,
  };
}

/**
 * Checks if a completed case should appear in unpaid cases list (قضایای در اقساط)
 * 
 * Rules:
 * - COMPLETED_FULLY_PAID: MUST NOT appear (remainingBalance = 0)
 * - COMPLETED_WITH_INSTALLMENTS: MUST appear (remainingBalance > 0)
 * - COMPLETED_WITH_REMAINING_BALANCE: MUST appear (remainingBalance > 0)
 */
export function shouldAppearInUnpaidCases(completionType: CompletionTypeResult): boolean {
  // Only cases with remaining balance > 0 should appear
  return completionType.remainingBalance > 0.01;
}

/**
 * Gets human-readable label for completion type
 */
export function getCompletionTypeLabel(type: CompletionType): string {
  switch (type) {
    case 'COMPLETED_FULLY_PAID':
      return 'تکمیل با پرداخت کامل';
    case 'COMPLETED_WITH_INSTALLMENTS':
      return 'تکمیل با اقساط';
    case 'COMPLETED_WITH_REMAINING_BALANCE':
      return 'تکمیل با بدهی باقی‌مانده';
    default:
      return 'نامشخص';
  }
}

