/**
 * Case State Machine Service
 * Manages case status transitions with validation and audit logging
 */

import type { Case, User } from '@shared/schema';
import { CaseStatus } from '@shared/schema';

export type TransitionName = 
  | 'assign_to_group'
  | 'assign_to_auditor'
  | 'start_review'
  | 'wait_for_documents'
  | 'resume_review'
  | 'suspend'
  | 'complete'
  | 'reopen';

export interface TransitionRule {
  from: CaseStatus;
  to: CaseStatus;
  name: TransitionName;
  requiredPermission?: string;
  requiredFields?: string[];
  validationFn?: (caseItem: Case, user: User, metadata?: any) => Promise<ValidationResult>;
}

export interface ValidationResult {
  isValid: boolean;
  errorMessage?: string;
  missingFields?: string[];
}

export interface TransitionResult {
  success: boolean;
  newStatus: CaseStatus;
  errorMessage?: string;
  transitionId?: string;
}

export interface TransitionMetadata {
  userId?: string;
  groupId?: string;
  rejectionReason?: string;
  notes?: string;
  ipAddress?: string;
  userAgent?: string;
  completionType?: string;
  completionFinancialState?: any;
}

/**
 * State machine transition rules - NEW 6-STATUS LIFECYCLE
 */
const TRANSITION_RULES: TransitionRule[] = [
  // CREATED → PENDING_SENIOR_REVIEW (assign to group)
  {
    from: CaseStatus.CREATED,
    to: CaseStatus.PENDING_SENIOR_REVIEW,
    name: 'assign_to_group',
    requiredPermission: 'cases:assign_to_group',
    validationFn: async (caseItem, user, metadata) => {
      // Must have groupId in metadata
      if (!metadata?.groupId) {
        return {
          isValid: false,
          errorMessage: 'باید گروه مشخص شود',
        };
      }
      return { isValid: true };
    },
  },
  // PENDING_SENIOR_REVIEW → UNDER_REVIEW (assign to auditor - MUST transition)
  {
    from: CaseStatus.PENDING_SENIOR_REVIEW,
    to: CaseStatus.UNDER_REVIEW,
    name: 'assign_to_auditor',
    requiredPermission: 'cases:assign_to_auditor',
    validationFn: async (caseItem, user, metadata) => {
      // Must have userId in metadata
      if (!metadata?.userId) {
        return {
          isValid: false,
          errorMessage: 'باید بازرس مشخص شود',
        };
      }
      // Self-assignment is explicitly allowed for senior auditors
      // No additional checks blocking senior self-assignment
      return { isValid: true };
    },
  },
  // UNDER_REVIEW → PENDING_DOCUMENTS (wait for documents)
  {
    from: CaseStatus.UNDER_REVIEW,
    to: CaseStatus.PENDING_DOCUMENTS,
    name: 'wait_for_documents',
    requiredPermission: 'cases:view',
    validationFn: async () => ({ isValid: true }),
  },
  // UNDER_REVIEW → SUSPENDED (suspend case)
  {
    from: CaseStatus.UNDER_REVIEW,
    to: CaseStatus.SUSPENDED,
    name: 'suspend',
    requiredPermission: 'cases:view',
    validationFn: async () => ({ isValid: true }),
  },
  // PENDING_DOCUMENTS → UNDER_REVIEW (resume review)
  {
    from: CaseStatus.PENDING_DOCUMENTS,
    to: CaseStatus.UNDER_REVIEW,
    name: 'resume_review',
    requiredPermission: 'cases:view',
    validationFn: async () => ({ isValid: true }),
  },
  // SUSPENDED → UNDER_REVIEW (resume review)
  {
    from: CaseStatus.SUSPENDED,
    to: CaseStatus.UNDER_REVIEW,
    name: 'resume_review',
    requiredPermission: 'cases:view',
    validationFn: async () => ({ isValid: true }),
  },
  // UNDER_REVIEW → COMPLETED (complete case - direct, no senior review)
  {
    from: CaseStatus.UNDER_REVIEW,
    to: CaseStatus.COMPLETED,
    name: 'complete',
    requiredPermission: 'cases:complete',
    validationFn: async (caseItem, user) => {
      // Validate report completion using V2 validation
      try {
        const { validateReport } = await import('./reportValidationServiceV2');
        const { storage } = await import('../storage');
        
        // Get report V2
        const report = await storage.getCaseReportV2(caseItem.id);
        if (!report) {
          return {
            isValid: false,
            errorMessage: 'گزارش قضیه تکمیل نشده است. لطفاً ابتدا گزارش را تکمیل کنید.',
          };
        }

        // Validate report
        const validation = await validateReport(report, caseItem);
        
        if (!validation.isValid) {
          const errorFields = validation.errors.map(e => e.field).join('، ');
          return {
            isValid: false,
            errorMessage: `گزارش کامل نیست. فیلدهای ناقص: ${errorFields}`,
            missingFields: validation.errors.map(e => e.field),
          };
        }

        // Check if report is completed
        if (report.status !== 'completed') {
          return {
            isValid: false,
            errorMessage: 'گزارش باید تکمیل شده باشد. لطفاً ابتدا گزارش را تکمیل کنید.',
          };
        }

        return { isValid: true };
      } catch (error) {
        console.error('Error validating report for case completion:', error);
        // Fallback to old validation
        const { validateCaseReportCompletion, canOverrideValidation } = await import('./reportValidationService');
        const allowOverride = await canOverrideValidation(user);
        const validation = await validateCaseReportCompletion(caseItem, allowOverride);
        
        if (!validation.isValid) {
          return {
            isValid: false,
            errorMessage: validation.errorMessage,
            missingFields: validation.missingFields,
          };
        }
        return { isValid: true };
      }
    },
  },
  // PENDING_DOCUMENTS → COMPLETED (complete case)
  {
    from: CaseStatus.PENDING_DOCUMENTS,
    to: CaseStatus.COMPLETED,
    name: 'complete',
    requiredPermission: 'cases:complete',
    validationFn: async (caseItem, user) => {
      // Same validation as UNDER_REVIEW → COMPLETED
      try {
        const { validateReport } = await import('./reportValidationServiceV2');
        const { storage } = await import('../storage');
        
        const report = await storage.getCaseReportV2(caseItem.id);
        if (!report) {
          return {
            isValid: false,
            errorMessage: 'گزارش قضیه تکمیل نشده است. لطفاً ابتدا گزارش را تکمیل کنید.',
          };
        }

        const validation = await validateReport(report, caseItem);
        
        if (!validation.isValid) {
          const errorFields = validation.errors.map(e => e.field).join('، ');
          return {
            isValid: false,
            errorMessage: `گزارش کامل نیست. فیلدهای ناقص: ${errorFields}`,
            missingFields: validation.errors.map(e => e.field),
          };
        }

        if (report.status !== 'completed') {
          return {
            isValid: false,
            errorMessage: 'گزارش باید تکمیل شده باشد. لطفاً ابتدا گزارش را تکمیل کنید.',
          };
        }

        return { isValid: true };
      } catch (error) {
        console.error('Error validating report for case completion:', error);
        const { validateCaseReportCompletion, canOverrideValidation } = await import('./reportValidationService');
        const allowOverride = await canOverrideValidation(user);
        const validation = await validateCaseReportCompletion(caseItem, allowOverride);
        
        if (!validation.isValid) {
          return {
            isValid: false,
            errorMessage: validation.errorMessage,
            missingFields: validation.missingFields,
          };
        }
        return { isValid: true };
      }
    },
  },
  // SUSPENDED → COMPLETED (complete suspended case)
  {
    from: CaseStatus.SUSPENDED,
    to: CaseStatus.COMPLETED,
    name: 'complete',
    requiredPermission: 'cases:complete',
    validationFn: async (caseItem, user) => {
      // Same validation as UNDER_REVIEW → COMPLETED
      try {
        const { validateReport } = await import('./reportValidationServiceV2');
        const { storage } = await import('../storage');
        
        const report = await storage.getCaseReportV2(caseItem.id);
        if (!report) {
          return {
            isValid: false,
            errorMessage: 'گزارش قضیه تکمیل نشده است. لطفاً ابتدا گزارش را تکمیل کنید.',
          };
        }

        const validation = await validateReport(report, caseItem);
        
        if (!validation.isValid) {
          const errorFields = validation.errors.map(e => e.field).join('، ');
          return {
            isValid: false,
            errorMessage: `گزارش کامل نیست. فیلدهای ناقص: ${errorFields}`,
            missingFields: validation.errors.map(e => e.field),
          };
        }

        if (report.status !== 'completed') {
          return {
            isValid: false,
            errorMessage: 'گزارش باید تکمیل شده باشد. لطفاً ابتدا گزارش را تکمیل کنید.',
          };
        }

        return { isValid: true };
      } catch (error) {
        console.error('Error validating report for case completion:', error);
        const { validateCaseReportCompletion, canOverrideValidation } = await import('./reportValidationService');
        const allowOverride = await canOverrideValidation(user);
        const validation = await validateCaseReportCompletion(caseItem, allowOverride);
        
        if (!validation.isValid) {
          return {
            isValid: false,
            errorMessage: validation.errorMessage,
            missingFields: validation.missingFields,
          };
        }
        return { isValid: true };
      }
    },
  },
  // COMPLETED → UNDER_REVIEW (reopen completed case)
  {
    from: CaseStatus.COMPLETED,
    to: CaseStatus.UNDER_REVIEW,
    name: 'reopen',
    requiredPermission: 'cases:complete',
    validationFn: async () => ({ isValid: true }),
  },
];

/**
 * Get allowed transitions for a case in its current state
 */
export function getAllowedTransitions(
  caseItem: Case,
  user: User
): TransitionRule[] {
  return TRANSITION_RULES.filter(rule => {
    // Check if transition is from current state
    if (rule.from !== caseItem.status) {
      return false;
    }
    
    // Check if user has required permission (if specified)
    // This will be checked more thoroughly in validateTransition
    return true;
  });
}

/**
 * Validate if a transition is allowed
 */
export async function validateTransition(
  caseItem: Case,
  user: User,
  toStatus: CaseStatus,
  transitionName: TransitionName,
  metadata?: TransitionMetadata
): Promise<ValidationResult> {
  // Find transition rule
  const rule = TRANSITION_RULES.find(
    r => r.from === caseItem.status && r.to === toStatus && r.name === transitionName
  );
  
  if (!rule) {
    return {
      isValid: false,
      errorMessage: `انتقال از ${caseItem.status} به ${toStatus} مجاز نیست`,
    };
  }
  
  // Check permission (if required)
  if (rule.requiredPermission) {
    const { getEffectivePermissions } = await import('./permissionService');
    const permissions = await getEffectivePermissions(user.id);
    
    // Special handling for assign permission (can be either)
    if (rule.requiredPermission === 'cases:assign_to_auditor') {
      const hasAssignPermission = 
        permissions['cases:assign_to_auditor'] || 
        permissions['cases:assign_to_group'] ||
        user.role === 'system_admin';
      
      if (!hasAssignPermission) {
        return {
          isValid: false,
          errorMessage: 'شما مجوز اختصاص قضیه را ندارید',
        };
      }
    } else if (rule.requiredPermission === 'cases:manage_installments' || rule.requiredPermission === 'cases:manage_law_enforcement') {
      // Only senior_auditor or system_admin can manage installments and law enforcement
      if (user.role !== 'senior_auditor' && user.role !== 'system_admin') {
        return {
          isValid: false,
          errorMessage: rule.requiredPermission === 'cases:manage_installments' 
            ? 'فقط بازرس ارشد می‌تواند قضیه را به وضعیت "در اقساط" منتقل کند'
            : 'فقط بازرس ارشد می‌تواند قضیه را به "ارسال‌شده به تنفیذ قانون" منتقل کند',
        };
      }
    } else {
      // Check specific permission
      const permissionKey = rule.requiredPermission as keyof typeof permissions;
      if (!permissions[permissionKey] && user.role !== 'system_admin') {
        return {
          isValid: false,
          errorMessage: 'شما مجوز لازم را ندارید',
        };
      }
    }
  }
  
  // Run custom validation function
  if (rule.validationFn) {
    return await rule.validationFn(caseItem, user, metadata);
  }
  
  return { isValid: true };
}

/**
 * Execute a transition (with validation and audit logging)
 */
export async function executeTransition(
  caseId: string,
  user: User,
  transitionName: TransitionName,
  metadata?: TransitionMetadata
): Promise<TransitionResult> {
  const { storage } = await import('../storage');
  const { db } = await import('../db');
  const { cases: casesTable, caseStatusTransitions: transitionsTable } = await import('@shared/schema');
  const { eq } = await import('drizzle-orm');
  
  // Get current case
  const caseItem = await storage.getCase(caseId);
  if (!caseItem) {
    return {
      success: false,
      newStatus: CaseStatus.CREATED, // Default status when case not found
      errorMessage: 'قضیه یافت نشد',
    };
  }
  
  // Normalize status for comparison (trim whitespace)
  const normalizedCurrentStatus = caseItem.status?.trim();
  
  // Find transition rule that matches both name AND current status
  const rule = TRANSITION_RULES.find(r => {
    const normalizedFromStatus = r.from?.trim();
    return r.name === transitionName && normalizedFromStatus === normalizedCurrentStatus;
  });
  
  if (!rule) {
    // Try to find any rule with this name to provide better error message
    const anyRuleWithName = TRANSITION_RULES.find(r => r.name === transitionName);
    if (anyRuleWithName) {
      return {
        success: false,
        newStatus: caseItem.status as CaseStatus,
        errorMessage: `انتقال "${transitionName}" از وضعیت "${caseItem.status}" مجاز نیست. وضعیت مورد نیاز: "${anyRuleWithName.from}"`,
      };
    }
    return {
      success: false,
      newStatus: caseItem.status as CaseStatus,
      errorMessage: 'انتقال نامعتبر است',
    };
  }
  
  // Validate transition
  const validation = await validateTransition(caseItem, user, rule.to, transitionName, metadata);
  if (!validation.isValid) {
    return {
      success: false,
      newStatus: caseItem.status as CaseStatus,
      errorMessage: validation.errorMessage,
    };
  }
  
  // Execute transition in transaction
  let transitionId: string | undefined;
  
  await db.transaction(async (tx) => {
    // Update case status
    const updateData: any = { status: rule.to };
    
    // Set status-specific fields
    if (rule.to === CaseStatus.COMPLETED) {
      updateData.completedBy = user.id;
      updateData.completedAt = new Date();
      
      // Lock report when case is completed
      const report = await storage.getCaseReportV2(caseId);
      if (report && report.status !== 'locked') {
        await storage.lockCaseReportV2(caseId);
      }
      
      // Determine completion type based on financial state
      // This is for tracking/logging purposes - completion is about audit finalization, not payment
      try {
        const { determineCompletionType } = await import('./caseCompletionService');
        const completionType = await determineCompletionType(caseItem, storage);
        
        // Log completion type for audit trail (can be stored in transition metadata)
        console.log(`[CASE COMPLETION] Case ${caseItem.caseId} completed with type: ${completionType.type}`, {
          confirmedAmount: completionType.confirmedAmount,
          totalPaid: completionType.totalPaid,
          remainingBalance: completionType.remainingBalance,
          hasInstallmentPayments: completionType.hasInstallmentPayments,
        });
        
        // Store completion type in transition metadata for audit trail
        metadata = metadata || {};
        metadata.completionType = completionType.type;
        metadata.completionFinancialState = {
          confirmedAmount: completionType.confirmedAmount,
          totalPaid: completionType.totalPaid,
          remainingBalance: completionType.remainingBalance,
        };
      } catch (error) {
        // Don't block completion if financial check fails - completion is about audit, not payment
        console.warn(`[CASE COMPLETION] Could not determine completion type for case ${caseItem.caseId}:`, error);
      }
    } else if (rule.to === CaseStatus.PENDING_SENIOR_REVIEW) {
      // Assign to group
      if (metadata?.groupId) {
        updateData.receivingGroup = metadata.groupId;
        updateData.assignedTo = null; // Clear assignedTo when assigned to group
      }
    } else if (rule.to === CaseStatus.UNDER_REVIEW) {
      // Assign to auditor - MUST transition when assigning
      if (metadata?.userId) {
        updateData.assignedTo = metadata.userId;
        updateData.assignedAuditor = metadata.userId;
        updateData.assignedBy = user.id;
        updateData.assignedAt = new Date();
      }
      // No additional fields needed for other transitions to UNDER_REVIEW
    }
    
    // Update case
    const [updatedCase] = await tx
      .update(casesTable)
      .set(updateData)
      .where(eq(casesTable.id, caseId))
      .returning();
    
    if (!updatedCase) {
      throw new Error('قضیه یافت نشد');
    }
    
    // Create transition record
    // Include completion type in metadata if this is a completion transition
    const transitionMetadata: any = {
      ipAddress: metadata?.ipAddress,
      userAgent: metadata?.userAgent,
      userRole: user.role,
      userId: metadata?.userId,
      groupId: metadata?.groupId,
    };
    
    // Add completion type information if this is a completion transition
    if (rule.to === CaseStatus.COMPLETED && metadata?.completionType) {
      transitionMetadata.completionType = metadata.completionType;
      transitionMetadata.completionFinancialState = metadata.completionFinancialState;
    }
    
    const [transition] = await tx
      .insert(transitionsTable)
      .values({
        caseId: caseId,
        fromStatus: caseItem.status,
        toStatus: rule.to,
        transitionName: transitionName,
        transitionedBy: user.id,
        notes: metadata?.notes,
        rejectionReason: metadata?.rejectionReason,
        metadata: transitionMetadata,
      })
      .returning();
    
    transitionId = transition.id;
    
    // Create audit log
    await storage.createAuditLog({
      userId: user.id,
      action: `case_transition_${transitionName}`,
      entityType: 'case',
      entityId: caseId,
      details: {
        fromStatus: caseItem.status,
        toStatus: rule.to,
        transitionName: transitionName,
        transitionId: transition.id,
        metadata: metadata,
      },
      ipAddress: metadata?.ipAddress,
    });
  });
  
  return {
    success: true,
    newStatus: rule.to,
    transitionId,
  };
}

/**
 * Get transition info for UI display
 */
export function getTransitionInfo(transitionName: TransitionName): {
  label: string;
  description: string;
  requiresConfirmation: boolean;
} {
  const info: Record<TransitionName, { label: string; description: string; requiresConfirmation: boolean }> = {
    assign_to_group: {
      label: 'اختصاص به گروه',
      description: 'قضیه را به گروه اختصاص دهید',
      requiresConfirmation: true,
    },
    assign_to_auditor: {
      label: 'اختصاص به بازرس',
      description: 'قضیه را به بازرس اختصاص دهید (وضعیت به "در حال بررسی" تغییر می‌کند)',
      requiresConfirmation: true,
    },
    start_review: {
      label: 'شروع بررسی',
      description: 'شروع بررسی قضیه',
      requiresConfirmation: false,
    },
    wait_for_documents: {
      label: 'در انتظار مدارک',
      description: 'قضیه را در وضعیت "در انتظار تکمیل مدارک" قرار دهید',
      requiresConfirmation: false,
    },
    resume_review: {
      label: 'ادامه بررسی',
      description: 'بررسی قضیه را از سر بگیرید',
      requiresConfirmation: false,
    },
    suspend: {
      label: 'تعلیق قضیه',
      description: 'قضیه را تعلیق کنید',
      requiresConfirmation: true,
    },
    complete: {
      label: 'تکمیل قضیه',
      description: 'قضیه را تکمیل کنید',
      requiresConfirmation: true,
    },
    reopen: {
      label: 'بازگشایی قضیه',
      description: 'قضیه تکمیل شده را بازگشایی کنید',
      requiresConfirmation: true,
    },
  };
  
  return info[transitionName];
}
