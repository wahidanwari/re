/**
 * Yearly Group Performance Report Service
 * Aggregates case data by group and month for a given Solar Hijri year
 */

import { storage } from '../storage';
import { db } from '../db';
import { cases, caseReports, caseReportsV2, groups } from '@shared/schema';
import { eq, and, sql, or, isNotNull } from 'drizzle-orm';
import jalaali from 'jalaali-js';
import type { Case, CaseReport, CaseReportV2 } from '@shared/schema';

export interface MonthlyGroupData {
  groupId: string;
  groupName: string;
  month: number; // Solar Hijri month (1-12)
  totalCases: number;
  completedCases: number;
  pendingCases: number;
  amountFixed: number; // Sum of confirmedAmount from completed cases
}

export interface GroupSummary {
  groupId: string;
  groupName: string;
  totalCases: number;
  completedCases: number;
  pendingCases: number;
  amountFixed: number;
  monthlyBreakdown: MonthlyGroupData[];
}

export interface YearlyGroupPerformanceReport {
  year: number; // Solar Hijri year
  groupSummaries: GroupSummary[];
  monthlyData: MonthlyGroupData[]; // All monthly data for easy access
}

export interface ThreeMonthGroupPerformanceReport {
  year: number; // Solar Hijri year
  quarter: number; // 1-4
  groupSummaries: GroupSummary[];
  monthlyData: MonthlyGroupData[]; // Only 3 months of data
}

/**
 * Convert Gregorian date to Solar Hijri year
 */
function getShamsiYear(date: Date): number {
  const j = jalaali.toJalaali(date);
  return j.jy;
}

/**
 * Convert Gregorian date to Solar Hijri month
 */
function getShamsiMonth(date: Date): number {
  const j = jalaali.toJalaali(date);
  return j.jm;
}

/**
 * Parse numeric value from string or number, handling commas and nulls
 */
function parseNumericValue(value: string | number | null | undefined): number {
  if (value === null || value === undefined) return 0;
  if (typeof value === 'number') return value;
  if (typeof value === 'string') {
    const cleaned = value.replace(/,/g, '').trim();
    const parsed = parseFloat(cleaned);
    return isNaN(parsed) ? 0 : parsed;
  }
  return 0;
}

/**
 * Get confirmed amount from case report (checks both caseReports and caseReportsV2)
 */
async function getConfirmedAmount(caseId: string): Promise<number> {
  // Try caseReportsV2 first (newer format)
  const [reportV2] = await db
    .select()
    .from(caseReportsV2)
    .where(eq(caseReportsV2.caseId, caseId))
    .limit(1);

  if (reportV2?.confirmedAmount) {
    return parseNumericValue(reportV2.confirmedAmount);
  }

  // Fallback to caseReports (legacy format)
  const [report] = await db
    .select()
    .from(caseReports)
    .where(eq(caseReports.caseId, caseId))
    .limit(1);

  if (report?.confirmedAmount) {
    return parseNumericValue(report.confirmedAmount);
  }

  return 0;
}

/**
 * Get all cases for a given Solar Hijri year
 * Cases are included if they were created or completed in that year
 */
async function getCasesForYear(yearShamsi: number): Promise<Case[]> {
  // Calculate date range for the Solar Hijri year
  // Solar Hijri year starts on Farvardin 1 (around March 21 Gregorian)
  const yearStartGregorian = jalaali.toGregorian(yearShamsi, 1, 1);
  
  // Last day of Solar Hijri year is Esfand 29 or 30 (depending on leap year)
  // Try both to get the correct end date
  let yearEndGregorian = jalaali.toGregorian(yearShamsi, 12, 30);
  // If that's invalid, use 29
  if (yearEndGregorian.gd === 0) {
    yearEndGregorian = jalaali.toGregorian(yearShamsi, 12, 29);
  }
  
  const startDate = new Date(yearStartGregorian.gy, yearStartGregorian.gm - 1, yearStartGregorian.gd);
  const endDate = new Date(yearEndGregorian.gy, yearEndGregorian.gm - 1, yearEndGregorian.gd);
  // Add one day to include the entire last day (exclusive end for range check)
  endDate.setDate(endDate.getDate() + 1);

  // Get all cases
  const allCases = await storage.getCases();

  // Filter cases that were created or completed in the given year
  const filteredCases = allCases.filter(c => {
    // Check if case was created in the year
    if (c.createdAt) {
      const createdDate = new Date(c.createdAt);
      if (createdDate >= startDate && createdDate < endDate) {
        return true;
      }
    }

    // Check if case was completed in the year
    if (c.completedAt) {
      const completedDate = new Date(c.completedAt);
      if (completedDate >= startDate && completedDate < endDate) {
        return true;
      }
    }

    return false;
  });

  return filteredCases;
}

/**
 * Aggregate yearly group performance data
 */
export async function getYearlyGroupPerformance(yearShamsi: number): Promise<YearlyGroupPerformanceReport> {
  // Get all cases for the year
  const casesForYear = await getCasesForYear(yearShamsi);

  // Get all groups for name lookup
  const allGroups = await storage.getGroups();
  const groupMap = new Map(allGroups.map(g => [g.id, g]));

  // Initialize data structures
  const monthlyDataMap = new Map<string, MonthlyGroupData>(); // Key: `${groupId}-${month}`
  const groupSummaryMap = new Map<string, GroupSummary>(); // Key: groupId

  // Process each case
  for (const caseItem of casesForYear) {
    const groupId = caseItem.receivingGroup;
    if (!groupId) continue; // Skip cases without a receiving group

    const group = groupMap.get(groupId);
    const groupName = group?.name || groupId;

    // Determine which month to use for aggregation
    // Prefer completedAt if available, otherwise use createdAt
    let aggregationDate: Date | null = null;
    let aggregationMonth: number | null = null;

    if (caseItem.completedAt) {
      aggregationDate = new Date(caseItem.completedAt);
      aggregationMonth = getShamsiMonth(aggregationDate);
    } else if (caseItem.createdAt) {
      aggregationDate = new Date(caseItem.createdAt);
      aggregationMonth = getShamsiMonth(aggregationDate);
    }

    // Only process if we have a valid month within the year
    if (!aggregationMonth || aggregationMonth < 1 || aggregationMonth > 12) {
      continue;
    }

    // Verify the month is in the correct year
    if (aggregationDate) {
      const caseYear = getShamsiYear(aggregationDate);
      if (caseYear !== yearShamsi) {
        continue; // Skip if year doesn't match
      }
    }

    // Initialize or get monthly data
    const monthlyKey = `${groupId}-${aggregationMonth}`;
    let monthlyData = monthlyDataMap.get(monthlyKey);
    
    if (!monthlyData) {
      monthlyData = {
        groupId,
        groupName,
        month: aggregationMonth,
        totalCases: 0,
        completedCases: 0,
        pendingCases: 0,
        amountFixed: 0,
      };
      monthlyDataMap.set(monthlyKey, monthlyData);
    }

    // Initialize or get group summary
    let groupSummary = groupSummaryMap.get(groupId);
    if (!groupSummary) {
      groupSummary = {
        groupId,
        groupName,
        totalCases: 0,
        completedCases: 0,
        pendingCases: 0,
        amountFixed: 0,
        monthlyBreakdown: [],
      };
      groupSummaryMap.set(groupId, groupSummary);
    }

    // Update counts
    monthlyData.totalCases++;
    groupSummary.totalCases++;

    // Check if case is completed
    const isCompleted = caseItem.status === 'تکمیل شده' || caseItem.status === 'COMPLETED';

    if (isCompleted) {
      monthlyData.completedCases++;
      groupSummary.completedCases++;

      // Get confirmed amount for completed cases
      const confirmedAmount = await getConfirmedAmount(caseItem.id);
      monthlyData.amountFixed += confirmedAmount;
      groupSummary.amountFixed += confirmedAmount;
    } else {
      monthlyData.pendingCases++;
      groupSummary.pendingCases++;
    }
  }

  // Build monthly breakdown for each group
  for (const groupSummary of groupSummaryMap.values()) {
    const monthlyBreakdown: MonthlyGroupData[] = [];
    
    // Get all monthly data for this group
    for (let month = 1; month <= 12; month++) {
      const monthlyKey = `${groupSummary.groupId}-${month}`;
      const monthlyData = monthlyDataMap.get(monthlyKey);
      
      if (monthlyData) {
        monthlyBreakdown.push(monthlyData);
      } else {
        // Add empty month entry for completeness
        monthlyBreakdown.push({
          groupId: groupSummary.groupId,
          groupName: groupSummary.groupName,
          month,
          totalCases: 0,
          completedCases: 0,
          pendingCases: 0,
          amountFixed: 0,
        });
      }
    }

    // Sort by month
    monthlyBreakdown.sort((a, b) => a.month - b.month);
    groupSummary.monthlyBreakdown = monthlyBreakdown;
  }

  // Convert maps to arrays
  const groupSummaries = Array.from(groupSummaryMap.values());
  const monthlyData = Array.from(monthlyDataMap.values());

  // Sort group summaries by group name
  groupSummaries.sort((a, b) => a.groupName.localeCompare(b.groupName));

  // Sort monthly data by group name, then by month
  monthlyData.sort((a, b) => {
    const groupCompare = a.groupName.localeCompare(b.groupName);
    if (groupCompare !== 0) return groupCompare;
    return a.month - b.month;
  });

  return {
    year: yearShamsi,
    groupSummaries,
    monthlyData,
  };
}

/**
 * Get months for a given quarter
 * Q1: months 1-3 (حمل، ثور، جوزا)
 * Q2: months 4-6 (سرطان، اسد، سنبله)
 * Q3: months 7-9 (میزان، عقرب، قوس)
 * Q4: months 10-12 (جدی، دلو، حوت)
 */
function getQuarterMonths(quarter: number): number[] {
  switch (quarter) {
    case 1:
      return [1, 2, 3];
    case 2:
      return [4, 5, 6];
    case 3:
      return [7, 8, 9];
    case 4:
      return [10, 11, 12];
    default:
      throw new Error(`Invalid quarter: ${quarter}. Must be 1-4.`);
  }
}

/**
 * Validate quarter value
 */
export function validateQuarter(quarter: number): boolean {
  return quarter >= 1 && quarter <= 4;
}

/**
 * Get all cases for a given quarter (3 months) in a Solar Hijri year
 * Cases are included if they were created or completed in any of the 3 months
 */
async function getCasesForQuarter(yearShamsi: number, quarter: number): Promise<Case[]> {
  if (!validateQuarter(quarter)) {
    throw new Error(`Invalid quarter: ${quarter}. Must be 1-4.`);
  }

  const quarterMonths = getQuarterMonths(quarter);
  const firstMonth = quarterMonths[0];
  const lastMonth = quarterMonths[quarterMonths.length - 1];

  // Calculate date range for the quarter
  // Start: First day of first month
  const quarterStartGregorian = jalaali.toGregorian(yearShamsi, firstMonth, 1);
  
  // End: Last day of last month (try 30, fallback to 29)
  let quarterEndGregorian = jalaali.toGregorian(yearShamsi, lastMonth, 30);
  if (quarterEndGregorian.gd === 0) {
    quarterEndGregorian = jalaali.toGregorian(yearShamsi, lastMonth, 29);
  }

  const startDate = new Date(quarterStartGregorian.gy, quarterStartGregorian.gm - 1, quarterStartGregorian.gd);
  const endDate = new Date(quarterEndGregorian.gy, quarterEndGregorian.gm - 1, quarterEndGregorian.gd);
  // Add one day to include the entire last day (exclusive end for range check)
  endDate.setDate(endDate.getDate() + 1);

  // Get all cases
  const allCases = await storage.getCases();

  // Filter cases that were created or completed in the quarter
  const filteredCases = allCases.filter(c => {
    // Check if case was created in the quarter
    if (c.createdAt) {
      const createdDate = new Date(c.createdAt);
      if (createdDate >= startDate && createdDate < endDate) {
        return true;
      }
    }

    // Check if case was completed in the quarter
    if (c.completedAt) {
      const completedDate = new Date(c.completedAt);
      if (completedDate >= startDate && completedDate < endDate) {
        return true;
      }
    }

    return false;
  });

  return filteredCases;
}

/**
 * Aggregate 3-month (quarter) group performance data
 */
export async function getThreeMonthGroupPerformance(
  yearShamsi: number,
  quarter: number
): Promise<ThreeMonthGroupPerformanceReport> {
  // Validate quarter
  if (!validateQuarter(quarter)) {
    throw new Error(`Invalid quarter: ${quarter}. Must be 1-4.`);
  }

  // Get months for this quarter
  const quarterMonths = getQuarterMonths(quarter);

  // Get all cases for the quarter
  const casesForQuarter = await getCasesForQuarter(yearShamsi, quarter);

  // Get all groups for name lookup
  const allGroups = await storage.getGroups();
  const groupMap = new Map(allGroups.map(g => [g.id, g]));

  // Initialize data structures
  const monthlyDataMap = new Map<string, MonthlyGroupData>(); // Key: `${groupId}-${month}`
  const groupSummaryMap = new Map<string, GroupSummary>(); // Key: groupId

  // Process each case
  for (const caseItem of casesForQuarter) {
    const groupId = caseItem.receivingGroup;
    if (!groupId) continue; // Skip cases without a receiving group

    const group = groupMap.get(groupId);
    const groupName = group?.name || groupId;

    // Determine which month to use for aggregation
    // Prefer completedAt if available, otherwise use createdAt
    let aggregationDate: Date | null = null;
    let aggregationMonth: number | null = null;

    if (caseItem.completedAt) {
      aggregationDate = new Date(caseItem.completedAt);
      aggregationMonth = getShamsiMonth(aggregationDate);
    } else if (caseItem.createdAt) {
      aggregationDate = new Date(caseItem.createdAt);
      aggregationMonth = getShamsiMonth(aggregationDate);
    }

    // Only process if we have a valid month within the quarter
    if (!aggregationMonth || !quarterMonths.includes(aggregationMonth)) {
      continue;
    }

    // Verify the month is in the correct year
    if (aggregationDate) {
      const caseYear = getShamsiYear(aggregationDate);
      if (caseYear !== yearShamsi) {
        continue; // Skip if year doesn't match
      }
    }

    // Initialize or get monthly data
    const monthlyKey = `${groupId}-${aggregationMonth}`;
    let monthlyData = monthlyDataMap.get(monthlyKey);
    
    if (!monthlyData) {
      monthlyData = {
        groupId,
        groupName,
        month: aggregationMonth,
        totalCases: 0,
        completedCases: 0,
        pendingCases: 0,
        amountFixed: 0,
      };
      monthlyDataMap.set(monthlyKey, monthlyData);
    }

    // Initialize or get group summary
    let groupSummary = groupSummaryMap.get(groupId);
    if (!groupSummary) {
      groupSummary = {
        groupId,
        groupName,
        totalCases: 0,
        completedCases: 0,
        pendingCases: 0,
        amountFixed: 0,
        monthlyBreakdown: [],
      };
      groupSummaryMap.set(groupId, groupSummary);
    }

    // Update counts
    monthlyData.totalCases++;
    groupSummary.totalCases++;

    // Check if case is completed
    const isCompleted = caseItem.status === 'تکمیل شده' || caseItem.status === 'COMPLETED';

    if (isCompleted) {
      monthlyData.completedCases++;
      groupSummary.completedCases++;

      // Get confirmed amount for completed cases
      const confirmedAmount = await getConfirmedAmount(caseItem.id);
      monthlyData.amountFixed += confirmedAmount;
      groupSummary.amountFixed += confirmedAmount;
    } else {
      monthlyData.pendingCases++;
      groupSummary.pendingCases++;
    }
  }

  // Build monthly breakdown for each group (only for the 3 months in the quarter)
  for (const groupSummary of groupSummaryMap.values()) {
    const monthlyBreakdown: MonthlyGroupData[] = [];
    
    // Get monthly data for only the quarter months
    for (const month of quarterMonths) {
      const monthlyKey = `${groupSummary.groupId}-${month}`;
      const monthlyData = monthlyDataMap.get(monthlyKey);
      
      if (monthlyData) {
        monthlyBreakdown.push(monthlyData);
      } else {
        // Add empty month entry for completeness
        monthlyBreakdown.push({
          groupId: groupSummary.groupId,
          groupName: groupSummary.groupName,
          month,
          totalCases: 0,
          completedCases: 0,
          pendingCases: 0,
          amountFixed: 0,
        });
      }
    }

    // Sort by month
    monthlyBreakdown.sort((a, b) => a.month - b.month);
    groupSummary.monthlyBreakdown = monthlyBreakdown;
  }

  // Convert maps to arrays
  const groupSummaries = Array.from(groupSummaryMap.values());
  const monthlyData = Array.from(monthlyDataMap.values());

  // Sort group summaries by group name
  groupSummaries.sort((a, b) => a.groupName.localeCompare(b.groupName));

  // Sort monthly data by group name, then by month
  monthlyData.sort((a, b) => {
    const groupCompare = a.groupName.localeCompare(b.groupName);
    if (groupCompare !== 0) return groupCompare;
    return a.month - b.month;
  });

  return {
    year: yearShamsi,
    quarter,
    groupSummaries,
    monthlyData,
  };
}

