// Permission Service - Calculates effective permissions from base role + active packages

import { db } from '../db';
import { 
  roles, 
  permissions, 
  rolePermissions, 
  packages, 
  packagePermissions, 
  userRoles, 
  userPackages, 
  users 
} from '@shared/schema';
import { eq, and, or, gt, isNull, inArray } from 'drizzle-orm';
import type { User } from '@shared/schema';
import type { Permission } from '@shared/permissions';

export type PermissionName = 
  | 'entities:view'
  | 'entities:create'
  | 'cases:view'
  | 'cases:assign_to_auditor'
  | 'cases:assign_to_group'
  | 'cases:complete'
  | 'reports:generate'
  | 'users:manage'
  | 'groups:manage'
  | 'groups:set_targets'
  | 'tickets:submit'
  | 'tickets:approve'
  | 'documents:download'
  | 'documents:upload'
  | 'logs:view'
  | 'settings:manage'
  | 'reports:override_complete';

export type EffectivePermissions = Record<PermissionName, boolean>;

/**
 * Get effective permissions for a user
 * Combines base role permissions with active package permissions
 * Packages merge/add to base role permissions
 */
export async function getEffectivePermissions(userId: string): Promise<EffectivePermissions> {
  // Initialize all permissions to false
    const effective: EffectivePermissions = {
    'entities:view': false,
    'entities:create': false,
    'cases:view': false,
    'cases:assign_to_auditor': false,
    'cases:assign_to_group': false,
    'cases:complete': false,
    'reports:generate': false,
    'users:manage': false,
    'groups:manage': false,
    'groups:set_targets': false,
    'tickets:submit': false,
    'tickets:approve': false,
    'documents:download': false,
    'documents:upload': false,
    'logs:view': false,
    'settings:manage': false,
    'reports:override_complete': false,
    'archives:view': false,
    'archives:upload': false,
    'archives:delete': false,
  };

  // Get user data first
  const userResult = await db.select().from(users).where(eq(users.id, userId)).limit(1);
  if (userResult.length === 0) {
    return effective; // User not found, return empty permissions
  }
  
  const userData = userResult[0];
  const userRole = userData.role as 'system_admin' | 'director' | 'senior_auditor' | 'auditor';
  // CRITICAL: Ensure permissionPackages is always an array
  const userPackagesArray = Array.isArray(userData.permissionPackages) 
    ? (userData.permissionPackages as ('acting_coordinator' | 'approval_authority')[])
    : (userData.permissionPackages ? [userData.permissionPackages] : []) as ('acting_coordinator' | 'approval_authority')[];

  // DEBUG LOGGING: Log permission calculation (only in debug mode)
  if (process.env.DEBUG_LOGGING === 'true') {
    console.log(`[GET_EFFECTIVE_PERMISSIONS] User: ${userId}, Role: ${userRole}, Packages: ${JSON.stringify(userPackagesArray)}`);
  }

  // System admin gets all permissions immediately
  if (userRole === 'system_admin') {
    Object.keys(effective).forEach(perm => {
      effective[perm as PermissionName] = true;
    });
    return effective;
  }

  // PRIMARY METHOD: Calculate permissions from shared/permissions.ts (source of truth)
  // This ensures permissions work even if RBAC database tables aren't populated
  const { getEffectivePermissions: calcEffective } = await import('@shared/permissions');
  const calculated = calcEffective(userRole, userPackagesArray);
  
  // Apply calculated permissions (this is the primary source)
  Object.keys(calculated).forEach(perm => {
    if (perm in effective) {
      effective[perm as PermissionName] = calculated[perm as Permission];
    }
  });
  
  // DEBUG LOGGING: Log calculated permissions (only in debug mode)
  if (process.env.DEBUG_LOGGING === 'true') {
    const permList = Object.entries(effective)
      .filter(([_, has]) => has)
      .map(([perm]) => perm);
    console.log(`[GET_EFFECTIVE_PERMISSIONS] Calculated permissions for ${userId}: ${permList.join(', ')}`);
  }

  // SECONDARY METHOD: Try to get permissions from database and merge (if database is populated)
  // This allows database overrides if RBAC tables are properly set up
  const userRoleRecords = await db
    .select({
      roleId: userRoles.roleId,
      roleName: roles.name,
    })
    .from(userRoles)
    .innerJoin(roles, eq(userRoles.roleId, roles.id))
    .where(eq(userRoles.userId, userId));

  if (userRoleRecords.length > 0) {
    const roleIds = userRoleRecords.map(ur => ur.roleId);
    
    const rolePermRecords = await db
      .select({
        permissionName: permissions.name,
        allow: rolePermissions.allow,
      })
      .from(rolePermissions)
      .innerJoin(permissions, eq(rolePermissions.permissionId, permissions.id))
      .where(
        and(
          inArray(rolePermissions.roleId, roleIds),
          eq(rolePermissions.allow, true)
        )
      );

    // Merge database permissions (database takes precedence if it has data)
    rolePermRecords.forEach(rp => {
      if (rp.permissionName in effective) {
        effective[rp.permissionName as PermissionName] = rp.allow;
      }
    });
  }

  // Get active packages from database (not expired) - for database override
  const activePackagesDb = await db
    .select({
      packageId: userPackages.packageId,
    })
    .from(userPackages)
    .where(
      and(
        eq(userPackages.userId, userId),
        or(
          isNull(userPackages.expiresAt),
          gt(userPackages.expiresAt, new Date())
        )
      )
    );

  // Merge/add package permissions from database (if database is populated)
  if (activePackagesDb.length > 0) {
    const packageIds = activePackagesDb.map(up => up.packageId);
    
    const packagePermRecords = await db
      .select({
        permissionName: permissions.name,
        allow: packagePermissions.allow,
      })
      .from(packagePermissions)
      .innerJoin(permissions, eq(packagePermissions.permissionId, permissions.id))
      .where(
        and(
          inArray(packagePermissions.packageId, packageIds),
          eq(packagePermissions.allow, true)
        )
      );

    // Merge/add package permissions from database (database takes precedence)
    packagePermRecords.forEach(pp => {
      if (pp.permissionName in effective) {
        effective[pp.permissionName as PermissionName] = pp.allow;
      }
    });
  }
  
  // Note: Packages from user.permissionPackages field are already included
  // in the primary calculation above via shared/permissions.ts

  return effective;
}

/**
 * Check if user has a specific permission
 */
export async function hasPermission(userId: string, permission: PermissionName): Promise<boolean> {
  const perms = await getEffectivePermissions(userId);
  return perms[permission] === true;
}

/**
 * Get list of permission names user has
 */
export async function getUserPermissionList(userId: string): Promise<PermissionName[]> {
  const perms = await getEffectivePermissions(userId);
  return Object.entries(perms)
    .filter(([_, has]) => has)
    .map(([perm]) => perm as PermissionName);
}

/**
 * Helper function to compute effective permissions from user object
 * This is a convenience function that combines role + packages + overrides
 */
export function computeEffectivePermissionsFromUser(
  role: 'system_admin' | 'director' | 'senior_auditor' | 'auditor',
  packages: ('acting_coordinator' | 'approval_authority')[] = []
): PermissionName[] {
  // Import shared permissions calculation
  const { getEffectivePermissions: calcEffective } = require('@shared/permissions');
  const calculated = calcEffective(role, packages);
  
  // Convert to array of permission names
  return Object.entries(calculated)
    .filter(([_, has]) => has)
    .map(([perm]) => perm as PermissionName);
}

/**
 * Helper function to check if user has coordinator package via effective permissions
 * This is more reliable than checking permissionPackages array directly
 */
export async function isCoordinator(userId: string): Promise<boolean> {
  const perms = await getEffectivePermissions(userId);
  // Coordinator has cases:assign_to_group permission
  const isCoord = perms['cases:assign_to_group'] === true;
  
  // DEBUG LOGGING: Log coordinator check (only in debug mode)
  if (process.env.DEBUG_LOGGING === 'true') {
    const userResult = await db.select().from(users).where(eq(users.id, userId)).limit(1);
    const userData = userResult[0];
    if (userData) {
      console.log(`[IS_COORDINATOR] User: ${userId} (${userData.role}), Packages: ${JSON.stringify(userData.permissionPackages || [])}, cases:assign_to_group: ${perms['cases:assign_to_group']}, IsCoordinator: ${isCoord}`);
    }
  }
  
  return isCoord;
}

/**
 * Helper function to get effective permissions for a user and return as object
 * Useful for route handlers that need to check multiple permissions
 */
export async function getUserEffectivePermissionsObject(userId: string): Promise<EffectivePermissions> {
  return await getEffectivePermissions(userId);
}

/**
 * Calculate modules list from effective permissions
 * This ensures consistency between server and client
 * 
 * @param permissions - Effective permissions object
 * @returns Array of module names that should be visible
 */
export function computeModulesFromPermissions(
  permissions: EffectivePermissions
): string[] {
  const modules: string[] = [];
  
  if (permissions['entities:view']) modules.push('entities');
  if (permissions['cases:view']) modules.push('cases');
  if (permissions['users:manage']) modules.push('users');
  if (permissions['groups:manage']) modules.push('groups');
  if (permissions['groups:set_targets']) modules.push('target-settings');
  if (permissions['tickets:submit'] || permissions['tickets:approve']) {
    modules.push('tickets');
  }
  if (permissions['cases:view']) modules.push('documents');
  if (permissions['settings:manage']) modules.push('settings');
  if (permissions['logs:view']) modules.push('audit-logs');
  if (permissions['reports:generate']) modules.push('reports');
  
  return modules;
}