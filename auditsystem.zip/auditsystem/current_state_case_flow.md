# Phase 1: Current State Analysis - Case Management Core Flow

## 1. Current Case Lifecycle

### 1.1 Status Values
**Location:** `shared/schema.ts` (line 89), `server/routes/cases.ts` (line 608), `client/src/components/StatusBadge.tsx`

**Current Status Values:**
1. `'جدید'` (New) - Initial status when case is created
2. `'در جریان بررسی'` (In Progress) - Case is being reviewed
3. `'تکمیل شده'` (Completed) - Case work is finished, report is complete
4. `'منتظر تایید'` (Pending Approval) - Case is waiting for approval
5. `'تایید شده'` (Approved) - Case has been approved
6. `'رد شده'` (Rejected) - Case has been rejected

**Status Display:**
- Status badges are defined in `StatusBadge.tsx` with color coding
- No explicit state machine or transition rules defined

### 1.2 Current Lifecycle Flow (Informal)

**Creation:**
- Case created with status `'جدید'` (New)
- Can be assigned to user (`assignedTo`) or group (`receivingGroup`)
- Audit log created: `create_case`

**Assignment:**
- Case can be assigned to individual auditor (`POST /api/cases/:id/assign` with `userId`)
- Case can be assigned to group (`POST /api/cases/:id/assign` with `groupId`)
- When assigned to group, `assignedTo` is cleared
- Audit log created: `assign_case`

**Status Updates:**
- Status can be changed via `PATCH /api/cases/:id/status`
- Status can be changed via `POST /api/cases/:id/complete` (sets to `'تکمیل شده'`)
- Status can be changed via `POST /api/cases/:id/approve` (sets to `'تایید شده'`)
- Status can be changed via `POST /api/cases/:id/reject` (sets to `'رد شده'`)

**Completion:**
- Case can be marked complete via `POST /api/cases/:id/complete`
- Requires report validation (checks all required fields)
- Updates entity status to `'COMPLETED'` if all cases for entity are completed
- Sets `completedBy` and `completedAt` fields
- Audit log created: `complete_case`

**Approval/Rejection:**
- Case can be approved via `POST /api/cases/:id/approve` (requires `tickets:approve` permission)
- Case can be rejected via `POST /api/cases/:id/reject` (requires `tickets:approve` permission, requires `rejectionReason`)
- Sets `approvedBy`/`approvedAt` or `rejectedBy`/`rejectedAt`/`rejectionReason`
- Audit logs created: `approve_case`, `reject_case`

### 1.3 Implicit Flow (No Explicit State Machine)

**Current Flow (as implemented):**
```
جدید → در جریان بررسی → تکمیل شده → منتظر تایید → تایید شده
                                                      ↓
                                                   رد شده
```

**Issues:**
- No explicit state machine defined
- Transitions are not validated (any status can be set to any other status, except approved/rejected)
- No validation of required fields before certain transitions
- No validation of assignment before status changes

## 2. API Endpoints

### 2.1 Case Management Endpoints

**Location:** `server/routes/cases.ts`

#### GET `/api/cases`
- **Purpose:** Get all cases (filtered by RBAC)
- **Auth:** Requires authentication
- **RBAC:** Filtered by user role/permissions
- **Returns:** Array of cases

#### GET `/api/cases/:id`
- **Purpose:** Get case by ID
- **Auth:** Requires authentication
- **RBAC:** User must have access to this case
- **Returns:** Single case object

#### GET `/api/cases/group/:groupId`
- **Purpose:** Get cases by group
- **Auth:** Requires authentication
- **RBAC:** User must have access to this group's cases
- **Returns:** Array of cases

#### POST `/api/cases`
- **Purpose:** Create new case
- **Auth:** Requires authentication
- **Permission:** Requires `entities:create`
- **Validation:**
  - Requires `caseNumber` (numeric, unique)
  - Validates entity exists
  - Validates no duplicate case for entity+period
  - Validates groupReferrer (inherited from entity)
  - Validates receivingGroup exists (if provided)
- **Sets Status:** `'جدید'` (New)
- **Audit Log:** `create_case`
- **Returns:** Created case

#### PUT `/api/cases/:id`
- **Purpose:** Update case (admin only)
- **Auth:** Requires authentication
- **Permission:** Requires `users:manage` (system admin only)
- **Validation:**
  - Prevents updates to approved/rejected cases
- **Audit Log:** `update_case`
- **Returns:** Updated case

#### POST `/api/cases/:id/assign`
- **Purpose:** Assign case to user or group
- **Auth:** Requires authentication
- **Permission:** Requires `cases:assign_to_auditor` OR `cases:assign_to_group` OR `users:manage`
- **Validation:**
  - Either `userId` OR `groupId` must be provided (not both)
  - Validates user/group exists
  - RBAC: Senior auditor can only assign to own group
- **Updates:**
  - Sets `assignedTo` (if userId) or `receivingGroup` (if groupId)
  - Clears `assignedTo` when assigned to group
- **Audit Log:** `assign_case`
- **Notifications:** Sends notification to assigned user/group members
- **Returns:** Updated case

#### PATCH `/api/cases/:id/status`
- **Purpose:** Update case status
- **Auth:** Requires authentication
- **Permission:** No explicit permission check (relies on RBAC for case access)
- **Validation:**
  - Validates status is in allowed list: `['جدید', 'در جریان بررسی', 'تکمیل شده', 'منتظر تایید', 'تایید شده', 'رد شده']`
  - Prevents changing status if already approved/rejected
  - If changing to `'تکمیل شده'`, validates report completion
- **RBAC:**
  - System admin can update any case
  - Coordinator can update any case
  - Auditor can only update assigned cases
  - Senior auditor can only update group cases
- **Audit Log:** `update_case_status` or `update_case_status_with_override`
- **Returns:** Updated case

#### POST `/api/cases/:id/complete`
- **Purpose:** Complete case (mark as completed)
- **Auth:** Requires authentication
- **Permission:** Requires `cases:complete`
- **Validation:**
  - Prevents completing already completed cases
  - Prevents completing approved/rejected cases
  - Validates report completion (all required fields)
  - Allows override for senior auditor/director
- **Updates:**
  - Sets status to `'تکمیل شده'`
  - Sets `completedBy` and `completedAt`
  - Updates entity status to `'COMPLETED'` if all cases completed (transaction)
- **RBAC:**
  - System admin can complete any case
  - Coordinator can complete any case
  - Auditor can only complete assigned cases
  - Senior auditor can only complete group cases
- **Audit Log:** `complete_case` or `complete_case_with_override`
- **Notifications:** Notifies assigned auditor and senior auditor
- **Returns:** Updated case with `entityStatusUpdated` flag

#### POST `/api/cases/:id/approve`
- **Purpose:** Approve case
- **Auth:** Requires authentication
- **Permission:** Requires `tickets:approve`
- **Validation:**
  - Case must be in `'تکمیل شده'` or `'منتظر تایید'` status
- **Updates:**
  - Sets status to `'تایید شده'`
  - Sets `approvedBy` and `approvedAt`
- **Audit Log:** `approve_case`
- **Notifications:** Notifies case creator
- **Returns:** Updated case

#### POST `/api/cases/:id/reject`
- **Purpose:** Reject case
- **Auth:** Requires authentication
- **Permission:** Requires `tickets:approve`
- **Validation:**
  - Requires `rejectionReason` in request body
  - Case must be in `'تکمیل شده'` or `'منتظر تایید'` status
- **Updates:**
  - Sets status to `'رد شده'`
  - Sets `rejectedBy`, `rejectedAt`, and `rejectionReason`
- **Audit Log:** `reject_case`
- **Notifications:** Notifies case creator with rejection reason
- **Returns:** Updated case

#### GET `/api/cases/:id/report`
- **Purpose:** Get case report data
- **Auth:** Requires authentication
- **RBAC:** User must have access to this case
- **Returns:** Report data (auto-populated from case/entity)

#### POST `/api/cases/:id/report`
- **Purpose:** Save case report
- **Auth:** Requires authentication
- **Permission:** Requires `cases:complete`
- **Validation:**
  - Prevents editing reports for approved/rejected cases
- **RBAC:** User must have access to this case
- **Audit Log:** `save_case_report`
- **Returns:** Saved report

### 2.2 Status Update Methods

**Three different ways to update status:**
1. `PATCH /api/cases/:id/status` - Generic status update
2. `POST /api/cases/:id/complete` - Specific completion endpoint
3. `POST /api/cases/:id/approve` - Specific approval endpoint
4. `POST /api/cases/:id/reject` - Specific rejection endpoint

**Issues:**
- Multiple endpoints for same operation (status update)
- Inconsistent validation between endpoints
- `PATCH /api/cases/:id/status` allows setting any status, while specific endpoints have stricter rules

## 3. Database Tables

### 3.1 Cases Table

**Location:** `shared/schema.ts` (lines 76-101)

**Schema:**
```typescript
cases {
  id: varchar (PK, UUID)
  caseId: text (unique, display ID)
  caseNumber: integer (unique, manual numeric ID)
  entityId: varchar (FK to entities)
  companyName: text
  tin: text
  businessNature: text
  periodsUnderReview: text
  referralDate: text
  groupReferrer: varchar (sender group - inherited from entity)
  receivingGroup: varchar (receiving audit group)
  assignedTo: varchar (FK to users, nullable)
  status: text (default: 'جدید')
  notes: text (nullable)
  approvedBy: varchar (FK to users, nullable)
  approvedAt: timestamp (nullable)
  rejectedBy: varchar (FK to users, nullable)
  rejectedAt: timestamp (nullable)
  rejectionReason: text (nullable)
  completedBy: varchar (FK to users, nullable)
  completedAt: timestamp (nullable)
  transactionId: text (nullable, نمبر آویز)
  paymentDate: text (nullable, DD-MM-YYYY format)
  createdAt: timestamp
}
```

**Issues:**
- No status enum/constraint (free text)
- No foreign key constraints on `approvedBy`, `rejectedBy`, `completedBy`
- No check constraint to ensure valid status transitions
- No index on status for filtering
- `status` field allows any string value

### 3.2 Case Reports Table

**Location:** `shared/schema.ts` (lines 224-250)

**Schema:**
```typescript
caseReports {
  id: varchar (PK, UUID)
  caseId: varchar (FK to cases, unique)
  finalDocumentDate: text
  capitalPeriod: text
  salaryTax: text
  rentTax: text
  contractTax: text
  profitTransactionTax: text
  incomeTax: text
  reducedLoss: text
  reducedRemainingAmount: text
  confirmedAmount: text
  collectedCurrentMonth: text
  remainingCollectible: text
  activityStatus: text
  attachmentNumber: text
  attachmentDate: text
  createdAt: timestamp
  updatedAt: timestamp
}
```

**Issues:**
- All fields are text (no numeric types for financial data)
- No validation constraints at database level
- No required field constraints

### 3.3 Audit Logs Table

**Location:** `shared/schema.ts` (lines 127-136)

**Schema:**
```typescript
auditLogs {
  id: varchar (PK, UUID)
  userId: varchar (FK to users, nullable)
  action: text
  entityType: text
  entityId: varchar (nullable)
  details: jsonb (consolidated JSONB field)
  ipAddress: text (nullable)
  createdAt: timestamp
}
```

**Audit Actions for Cases:**
- `create_case`
- `update_case`
- `assign_case`
- `update_case_status`
- `update_case_status_with_override`
- `complete_case`
- `complete_case_with_override`
- `approve_case`
- `reject_case`
- `save_case_report`

**Issues:**
- No structured schema for `details` field (JSONB allows any structure)
- No validation of required fields in details
- No index on `entityType` + `entityId` for case queries

## 4. Current Bugs & Issues

### 4.1 Status Transition Validation Issues

**Bug 1: No State Machine Validation**
- **Location:** `server/routes/cases.ts` (line 608-611)
- **Issue:** Status validation only checks if status is in allowed list, not if transition is valid
- **Example:** Can transition from `'جدید'` directly to `'تایید شده'` (skipping all intermediate states)
- **Impact:** Data integrity issues, incorrect workflow

**Bug 2: Inconsistent Validation Between Endpoints**
- **Location:** `PATCH /api/cases/:id/status` vs `POST /api/cases/:id/complete`
- **Issue:** 
  - `PATCH /api/cases/:id/status` allows setting any status (with minimal validation)
  - `POST /api/cases/:id/complete` has strict validation (report completion, prevents duplicates)
- **Impact:** Users can bypass validation by using generic status endpoint

**Bug 3: Missing Transition Validation**
- **Location:** `server/routes/cases.ts` (line 653)
- **Issue:** `updateCaseStatus` in storage directly sets status without checking if transition is allowed
- **Example:** Can go from `'تایید شده'` back to `'جدید'` (should be prevented)
- **Impact:** Invalid state transitions possible

**Bug 4: No Validation of Required Fields Before Status Change**
- **Location:** `server/routes/cases.ts` (line 620-651)
- **Issue:** Report validation only happens when changing to `'تکمیل شده'`, not for other statuses
- **Example:** Can set status to `'در جریان بررسی'` without assignment
- **Impact:** Cases can be in invalid states

### 4.2 Missing Audit Logs

**Bug 5: Missing Audit Log for Direct Status Updates**
- **Location:** `server/storage.ts` (line 509-516)
- **Issue:** `updateCaseStatus` method doesn't create audit log (relies on route handler)
- **Impact:** If method is called directly, no audit trail

**Bug 6: Incomplete Audit Log Details**
- **Location:** `server/routes/cases.ts` (line 659-678)
- **Issue:** Audit log for status update doesn't include:
  - Previous assignment state
  - User role who made change
  - Transition reason/notes
- **Impact:** Insufficient audit trail for debugging

**Bug 7: No Audit Log for Assignment Changes**
- **Location:** `server/routes/cases.ts` (line 518-538)
- **Issue:** Assignment audit log exists but doesn't track:
  - Previous assignment state clearly
  - Assignment reason
  - Assignment expiration (if applicable)
- **Impact:** Cannot track assignment history

### 4.3 Incorrect State Transitions

**Bug 8: Can Skip Required States**
- **Location:** `server/routes/cases.ts` (line 608-611)
- **Issue:** No validation that case must be assigned before moving to `'در جریان بررسی'`
- **Example:** Can set status to `'در جریان بررسی'` without assignment
- **Impact:** Cases can be in progress without assignee

**Bug 9: Can Complete Without Assignment**
- **Location:** `server/routes/cases.ts` (line 686-904)
- **Issue:** `POST /api/cases/:id/complete` checks RBAC but doesn't validate assignment
- **Example:** Coordinator can complete unassigned case
- **Impact:** Cases can be completed without proper assignment

**Bug 10: Can Approve/Reject Without Completion**
- **Location:** `server/routes/cases.ts` (line 915-919, 969-973)
- **Issue:** Approval/rejection only checks if status is `'تکمیل شده'` or `'منتظر تایید'`, but doesn't validate report exists
- **Example:** Can approve case that was set to `'منتظر تایید'` without going through completion
- **Impact:** Cases can be approved without proper completion

### 4.4 Database Integrity Issues

**Bug 11: No Foreign Key Constraints**
- **Location:** `shared/schema.ts` (lines 91-97)
- **Issue:** `approvedBy`, `rejectedBy`, `completedBy` don't have foreign key constraints
- **Impact:** Can reference non-existent users

**Bug 12: No Status Enum/Constraint**
- **Location:** `shared/schema.ts` (line 89)
- **Issue:** Status is free text, no enum or check constraint
- **Impact:** Can store invalid status values in database

**Bug 13: No Transition History Table**
- **Location:** N/A (doesn't exist)
- **Issue:** No table to track status transition history
- **Impact:** Cannot query "when did case move from X to Y"

### 4.5 UX Issues

**Bug 14: No Confirmation Dialogs**
- **Location:** `client/src/pages/Cases.tsx`
- **Issue:** Status changes happen immediately without confirmation
- **Example:** Clicking "Complete" immediately completes case
- **Impact:** Accidental status changes possible

**Bug 15: Unclear Button States**
- **Location:** `client/src/pages/Cases.tsx`
- **Issue:** Buttons don't clearly indicate:
  - Which actions are available for current status
  - Why certain actions are disabled
  - What will happen when clicked
- **Impact:** User confusion, incorrect actions

**Bug 16: No Status Transition Preview**
- **Location:** `client/src/pages/Cases.tsx`
- **Issue:** Users can't see what status they're transitioning to before confirming
- **Impact:** Unclear what action will do

**Bug 17: Missing Validation Feedback**
- **Location:** `client/src/pages/Cases.tsx` (line 420-442)
- **Issue:** Validation errors shown in toast, but not clearly displayed in UI
- **Impact:** Users may miss validation errors

## 5. Missing UX Components

### 5.1 Confirmation Dialogs

**Missing:**
- Confirmation dialog before status changes
- Confirmation dialog before assignment changes
- Confirmation dialog before approval/rejection

**Current State:**
- Status changes happen immediately
- No "Are you sure?" prompts
- No way to cancel action

### 5.2 Status Transition UI

**Missing:**
- Visual state machine diagram
- Clear indication of available transitions
- Disabled states with tooltips explaining why
- Status history timeline

**Current State:**
- Status badge shows current status
- No indication of what transitions are possible
- No history of status changes

### 5.3 Validation Feedback

**Missing:**
- Inline validation errors
- Field-level error messages
- Clear indication of required fields
- Progress indicator for report completion

**Current State:**
- Validation errors shown in toast notifications
- No inline field validation
- No clear indication of what's missing

### 5.4 RTL Layout Issues

**Missing:**
- RTL-aware status badges
- RTL-aware transition arrows
- RTL-aware confirmation dialogs
- RTL-aware form layouts

**Current State:**
- Basic RTL support exists
- Status badges may not be properly aligned
- Transition UI not RTL-optimized

## 6. Dependencies

### 6.1 Reporting Module

**Dependencies:**
- Case reports table (`caseReports`)
- Report validation service (`server/services/reportValidationService.ts`)
- Required fields validation before completion
- Override permission (`reports:override_complete`)

**Integration Points:**
- `POST /api/cases/:id/complete` validates report before completion
- `PATCH /api/cases/:id/status` validates report when setting to `'تکمیل شده'`
- Report data used in completion workflow

**Issues:**
- Tight coupling between case status and report validation
- No way to save partial reports without completing case
- Report validation rules hardcoded in service

### 6.2 RBAC Module

**Dependencies:**
- Permission checks: `cases:view`, `cases:complete`, `cases:assign_to_auditor`, `cases:assign_to_group`, `tickets:approve`
- Role-based access: `system_admin`, `director`, `senior_auditor`, `auditor`
- Coordinator package: `acting_coordinator`
- Permission service: `getEffectivePermissions`, `isCoordinator`

**Integration Points:**
- All case endpoints check permissions
- Case visibility filtered by role
- Assignment permissions checked
- Completion permissions checked

**Issues:**
- Permission checks scattered across routes
- No centralized permission policy for case operations
- RBAC logic mixed with business logic

### 6.3 Dashboard Module

**Dependencies:**
- Case status counts for dashboard metrics
- Case completion dates for reporting
- Entity status updates when cases complete

**Integration Points:**
- Dashboard queries cases by status
- Dashboard shows completion metrics
- Entity status updated when all cases complete

**Issues:**
- Dashboard may show incorrect counts if status transitions are invalid
- No real-time updates when status changes
- Metrics may be stale

### 6.4 Notification Module

**Dependencies:**
- Notification creation on case events
- WebSocket notifications for real-time updates

**Integration Points:**
- Notifications sent on case assignment
- Notifications sent on case completion
- Notifications sent on case approval/rejection

**Issues:**
- Notifications may be sent for invalid transitions
- No notification for status changes (only for specific actions)

## 7. Example API Calls & Responses

### Example 1: Create Case (Current)
```http
POST /api/cases
Content-Type: application/json

{
  "caseNumber": 123,
  "entityId": "entity-123",
  "receivingGroup": "group-456",
  "periodsUnderReview": "1402-1403",
  "referralDate": "01-01-1402"
}
```

**Response:**
```json
{
  "id": "case-789",
  "caseId": "123",
  "caseNumber": 123,
  "entityId": "entity-123",
  "status": "جدید",
  "groupReferrer": "گروه اول سنجش ابتدایی",
  "receivingGroup": "group-456",
  "assignedTo": null,
  "createdAt": "2024-01-15T10:00:00Z"
}
```

**Problem:** ✅ Works correctly, but no validation of assignment before status change

### Example 2: Update Status (Current - BUG)
```http
PATCH /api/cases/case-789/status
Content-Type: application/json

{
  "status": "تایید شده"
}
```

**Response:**
```json
{
  "id": "case-789",
  "status": "تایید شده",
  ...
}
```

**Problem:** ❌ Allows skipping from `'جدید'` directly to `'تایید شده'` without going through required states

### Example 3: Complete Case (Current)
```http
POST /api/cases/case-789/complete
```

**Response (if report incomplete):**
```json
{
  "message": "گزارش تکمیل نشده است...",
  "missingFields": ["مالیه موضوعی معاشات", "نمبر آویز"],
  "canOverride": false
}
```

**Response (if report complete):**
```json
{
  "id": "case-789",
  "status": "تکمیل شده",
  "completedBy": "user-123",
  "completedAt": "2024-01-15T11:00:00Z",
  "entityStatusUpdated": true
}
```

**Problem:** ✅ Validation works, but can be bypassed using `PATCH /api/cases/:id/status`

## 8. Summary of Problems

### 8.1 Critical Issues
1. **No State Machine:** No explicit state machine with allowed transitions
2. **No Transition Validation:** Any status can be set to any other status (except approved/rejected)
3. **Inconsistent Validation:** Different endpoints have different validation rules
4. **Missing Audit Logs:** Some status changes may not be logged
5. **Database Integrity:** No constraints on status values or foreign keys

### 8.2 Medium Priority Issues
1. **Missing UX Components:** No confirmation dialogs, unclear button states
2. **Incomplete Audit Trail:** Audit logs missing important details
3. **No Transition History:** Cannot query status change history
4. **RTL Layout Issues:** Status UI not fully RTL-optimized

### 8.3 Low Priority Issues
1. **Performance:** No indexes on status for filtering
2. **Code Organization:** Status logic scattered across multiple endpoints
3. **Documentation:** No clear documentation of allowed transitions

