# Simple script to run migration 034
# Usage: .\run-migration-034-simple.ps1

if (-not $env:DATABASE_URL) {
    Write-Host "ERROR: DATABASE_URL not set" -ForegroundColor Red
    Write-Host "Set it with: `$env:DATABASE_URL = 'postgresql://user:pass@host:port/dbname'" -ForegroundColor Yellow
    exit 1
}

$migrationFile = "migrations\034_add_audit_year_numeric_columns_and_constraint.sql"

if (-not (Test-Path $migrationFile)) {
    Write-Host "ERROR: Migration file not found" -ForegroundColor Red
    exit 1
}

Write-Host "Running migration 034..." -ForegroundColor Cyan
Write-Host ""

# Run the migration
psql $env:DATABASE_URL -f $migrationFile

if ($LASTEXITCODE -eq 0) {
    Write-Host ""
    Write-Host "Migration completed successfully!" -ForegroundColor Green
} else {
    Write-Host ""
    Write-Host "Migration failed. Check error messages above." -ForegroundColor Red
    Write-Host "Exit code: $LASTEXITCODE" -ForegroundColor Yellow
}

