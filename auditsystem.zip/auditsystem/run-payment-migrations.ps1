# Run Payment Traceability Migrations (PHASE 1 & 2)
# PowerShell script to run migrations 031 and 032
# 
# This script will attempt to use psql, but if that fails, it will fall back to
# using the TypeScript migration script which is more reliable.

Write-Host "🚀 Running Payment Traceability Migrations..." -ForegroundColor Cyan
Write-Host ""

# Try to load DATABASE_URL from .env file if not set
if (-not $env:DATABASE_URL) {
    if (Test-Path ".env") {
        Write-Host "📄 Loading DATABASE_URL from .env file..." -ForegroundColor Gray
        Get-Content ".env" | ForEach-Object {
            if ($_ -match '^DATABASE_URL=(.+)') {
                $env:DATABASE_URL = $matches[1].Trim()
            }
        }
    }
}

# Check if DATABASE_URL is set
if (-not $env:DATABASE_URL) {
    Write-Host "❌ ERROR: DATABASE_URL environment variable is not set!" -ForegroundColor Red
    Write-Host "   Please set it using: `$env:DATABASE_URL = 'postgresql://...'" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "   Or ensure it's in your .env file" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "💡 Alternative: Use TypeScript migration script (recommended):" -ForegroundColor Cyan
    Write-Host "   npm run db:migrate-payment-traceability" -ForegroundColor Gray
    exit 1
}

Write-Host "✓ DATABASE_URL is set" -ForegroundColor Green
Write-Host ""

# Check if Node.js/npm is available (for TypeScript fallback)
$nodePath = Get-Command node -ErrorAction SilentlyContinue
$npmPath = Get-Command npm -ErrorAction SilentlyContinue

# Check if psql is available
$psqlPath = Get-Command psql -ErrorAction SilentlyContinue
$usePsql = $false

if ($psqlPath) {
    Write-Host "✓ PostgreSQL client (psql) found" -ForegroundColor Green
    $usePsql = $true
} else {
    Write-Host "⚠️  PostgreSQL client (psql) not found" -ForegroundColor Yellow
    if ($nodePath -and $npmPath) {
        Write-Host "✓ Node.js found - will use TypeScript migration script instead" -ForegroundColor Green
        $usePsql = $false
    } else {
        Write-Host "❌ ERROR: Neither psql nor Node.js found!" -ForegroundColor Red
        Write-Host "   Please install either:" -ForegroundColor Yellow
        Write-Host "   - PostgreSQL client tools (for psql)" -ForegroundColor Yellow
        Write-Host "   - Node.js (for TypeScript migration script)" -ForegroundColor Yellow
        exit 1
    }
}

Write-Host ""

# Function to parse DATABASE_URL and extract connection parameters
function Parse-DatabaseUrl {
    param([string]$DatabaseUrl)
    
    if ($DatabaseUrl -match '^postgresql://(?:([^:]+):([^@]+)@)?([^:/]+)(?::(\d+))?/(.+)$') {
        $username = if ($matches[1]) { $matches[1] } else { $env:USER }
        $password = $matches[2]
        $host = $matches[3]
        $port = if ($matches[4]) { $matches[4] } else { "5432" }
        $database = $matches[5]
        
        # Remove query parameters from database name
        if ($database -match '^([^?]+)') {
            $database = $matches[1]
        }
        
        return @{
            Host = $host
            Port = $port
            Database = $database
            Username = $username
            Password = $password
        }
    }
    return $null
}

# Function to run migration using psql
function Run-Migration-Psql {
    param(
        [string]$MigrationFile,
        [string]$MigrationName,
        [hashtable]$ConnectionParams
    )
    
    $migrationPath = Join-Path "migrations" $MigrationFile
    
    if (-not (Test-Path $migrationPath)) {
        Write-Host "❌ Migration file not found: $migrationPath" -ForegroundColor Red
        return $false
    }
    
    Write-Host "📦 Running: $MigrationName" -ForegroundColor Cyan
    Write-Host "   File: $MigrationFile" -ForegroundColor Gray
    Write-Host "   Using: psql" -ForegroundColor Gray
    
    try {
        # Convert path to absolute
        $absolutePath = (Resolve-Path $migrationPath).Path
        
        # Set PGPASSWORD environment variable for psql
        if ($ConnectionParams.Password) {
            $env:PGPASSWORD = $ConnectionParams.Password
        }
        
        # Build psql command with connection parameters
        $psqlArgs = @(
            "-h", $ConnectionParams.Host,
            "-p", $ConnectionParams.Port,
            "-U", $ConnectionParams.Username,
            "-d", $ConnectionParams.Database,
            "-f", $absolutePath,
            "-v", "ON_ERROR_STOP=1"
        )
        
        # Run psql
        $output = & psql $psqlArgs 2>&1
        $exitCode = $LASTEXITCODE
        
        # Clear password from environment
        if ($ConnectionParams.Password) {
            Remove-Item Env:\PGPASSWORD -ErrorAction SilentlyContinue
        }
        
        # Check exit code
        if ($exitCode -eq 0) {
            Write-Host "   ✓ Migration completed successfully!" -ForegroundColor Green
            return $true
        } else {
            # Check if error is "already exists" (safe to ignore)
            $outputText = if ($output -is [array]) { $output -join "`n" } else { $output.ToString() }
            if ($outputText -match "already exists" -or $outputText -match "duplicate" -or $outputText -match "42P07" -or $outputText -match "42710") {
                Write-Host "   ⚠️  Migration already applied (safe to ignore)" -ForegroundColor Yellow
                return $true
            } else {
                Write-Host "   ❌ Migration failed!" -ForegroundColor Red
                Write-Host "   Exit code: $exitCode" -ForegroundColor Red
                if ($outputText) {
                    Write-Host "   Error output:" -ForegroundColor Red
                    Write-Host $outputText -ForegroundColor Red
                }
                return $false
            }
        }
    } catch {
        Write-Host "   ❌ Error: $_" -ForegroundColor Red
        Write-Host "   Exception details: $($_.Exception.Message)" -ForegroundColor Red
        # Clear password from environment
        if ($ConnectionParams.Password) {
            Remove-Item Env:\PGPASSWORD -ErrorAction SilentlyContinue
        }
        return $false
    }
}

# Function to run migration using TypeScript script
function Run-Migration-TypeScript {
    Write-Host "📦 Running migrations using TypeScript script..." -ForegroundColor Cyan
    Write-Host "   This is the recommended method" -ForegroundColor Gray
    Write-Host ""
    
    try {
        $result = & npm run db:migrate-payment-traceability 2>&1
        $exitCode = $LASTEXITCODE
        
        # Display output
        $result | ForEach-Object { Write-Host $_ }
        
        if ($exitCode -eq 0) {
            return $true
        } else {
            return $false
        }
    } catch {
        Write-Host "   ❌ Error running TypeScript migration: $_" -ForegroundColor Red
        return $false
    }
}

# Run migrations
$successCount = 0
$errorCount = 0

Write-Host "─" * 60
Write-Host ""

if ($usePsql) {
    # Parse DATABASE_URL
    $connParams = Parse-DatabaseUrl -DatabaseUrl $env:DATABASE_URL
    
    if (-not $connParams) {
        Write-Host "❌ ERROR: Could not parse DATABASE_URL!" -ForegroundColor Red
        Write-Host "   Expected format: postgresql://[user[:password]@]host[:port]/database" -ForegroundColor Yellow
        Write-Host ""
        Write-Host "💡 Falling back to TypeScript migration script..." -ForegroundColor Cyan
        $usePsql = $false
    } else {
        Write-Host "📡 Connection parameters parsed successfully" -ForegroundColor Green
        Write-Host "   Host: $($connParams.Host)" -ForegroundColor Gray
        Write-Host "   Port: $($connParams.Port)" -ForegroundColor Gray
        Write-Host "   Database: $($connParams.Database)" -ForegroundColor Gray
        Write-Host "   User: $($connParams.Username)" -ForegroundColor Gray
        Write-Host ""
    }
}

if ($usePsql) {
    # Use psql to run migrations
    # Migration 031
    if (Run-Migration-Psql -MigrationFile "031_create_payments_table.sql" -MigrationName "Create Payments Table (PHASE 1)" -ConnectionParams $connParams) {
        $successCount++
    } else {
        $errorCount++
    }
    
    Write-Host ""
    
    # Migration 032
    if (Run-Migration-Psql -MigrationFile "032_create_case_monthly_snapshots_table.sql" -MigrationName "Create Case Monthly Snapshots Table (PHASE 2)" -ConnectionParams $connParams) {
        $successCount++
    } else {
        $errorCount++
    }
} else {
    # Use TypeScript migration script (recommended)
    if (Run-Migration-TypeScript) {
        $successCount = 2  # Both migrations run together
        $errorCount = 0
    } else {
        $successCount = 0
        $errorCount = 1
    }
}

Write-Host ""
Write-Host "─" * 60
Write-Host ""
Write-Host "📊 Migration Summary:" -ForegroundColor Cyan
Write-Host "   ✓ Successful: $successCount" -ForegroundColor Green
Write-Host "   ❌ Errors: $errorCount" -ForegroundColor $(if ($errorCount -gt 0) { "Red" } else { "Green" })
Write-Host ""

if ($errorCount -eq 0) {
    Write-Host "✅ All migrations completed successfully!" -ForegroundColor Green
    Write-Host ""
    Write-Host "📋 Next steps:" -ForegroundColor Cyan
    Write-Host "   1. Verify tables: payments, case_monthly_snapshots" -ForegroundColor Gray
    Write-Host "   2. Test payment recording functionality" -ForegroundColor Gray
    Write-Host "   3. Test monthly snapshot calculation" -ForegroundColor Gray
} else {
    Write-Host "⚠️  Some migrations had errors. Please review the output above." -ForegroundColor Yellow
    Write-Host ""
    Write-Host "💡 Alternative: Use TypeScript migration script:" -ForegroundColor Cyan
    Write-Host "   npm run db:migrate-payment-traceability" -ForegroundColor Gray
}

Write-Host ""
Write-Host "Press any key to exit..."
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")

