# Debug script for migration 034
# Captures detailed error information

Write-Host "Debugging Migration 034" -ForegroundColor Cyan
Write-Host ""

# Check if DATABASE_URL is set
if (-not $env:DATABASE_URL) {
    Write-Host "ERROR: DATABASE_URL environment variable is not set" -ForegroundColor Red
    Write-Host "Please set it using: `$env:DATABASE_URL = 'postgresql://ard_app:123456:port/ardapp'" -ForegroundColor Yellow
    exit 1
}

$migrationFile = "migrations\034_add_audit_year_numeric_columns_and_constraint.sql"

if (-not (Test-Path $migrationFile)) {
    Write-Host "ERROR: Migration file not found: $migrationFile" -ForegroundColor Red
    exit 1
}

Write-Host "Step 1: Testing database connection..." -ForegroundColor Yellow
try {
    $testQuery = "SELECT version();"
    $testResult = & psql $env:DATABASE_URL -c $testQuery 2>&1
    if ($LASTEXITCODE -eq 0) {
        Write-Host "Database connection successful" -ForegroundColor Green
    } else {
        Write-Host "Database connection failed" -ForegroundColor Red
        Write-Host $testResult
        exit 1
    }
} catch {
    Write-Host "ERROR: Cannot connect to database" -ForegroundColor Red
    Write-Host $_.Exception.Message
    exit 1
}

Write-Host ""
Write-Host "Step 2: Checking if cases table exists..." -ForegroundColor Yellow
try {
    $checkTable = "SELECT EXISTS (SELECT FROM information_schema.tables WHERE table_name = 'cases');"
    $tableResult = & psql $env:DATABASE_URL -t -c $checkTable 2>&1
    $tableExists = $tableResult -match "t"
    if ($tableExists) {
        Write-Host "Cases table exists" -ForegroundColor Green
    } else {
        Write-Host "Cases table does not exist. Run 'npm run db:push' first." -ForegroundColor Red
        exit 1
    }
} catch {
    Write-Host "ERROR checking table" -ForegroundColor Red
    Write-Host $_.Exception.Message
}

Write-Host ""
Write-Host "Step 3: Checking for existing overlapping data..." -ForegroundColor Yellow
try {
    $overlapQuery = "SELECT COUNT(*) as overlap_count FROM cases c1 INNER JOIN cases c2 ON c1.entity_id = c2.entity_id AND c1.id != c2.id WHERE c1.audit_year_range IS NOT NULL AND c2.audit_year_range IS NOT NULL AND c1.audit_year_range != '' AND c2.audit_year_range != '';"
    $overlapResult = & psql $env:DATABASE_URL -t -c $overlapQuery 2>&1
    $overlapCount = ($overlapResult | Where-Object { $_ -match '\d+' } | ForEach-Object { [int]($_ -replace '\D','') } | Select-Object -First 1)
    if ($overlapCount -gt 0) {
        Write-Host "WARNING: Found $overlapCount potential overlapping year ranges" -ForegroundColor Yellow
        Write-Host "   The constraint may fail. Check data first." -ForegroundColor Yellow
    } else {
        Write-Host "No overlapping data found" -ForegroundColor Green
    }
} catch {
    Write-Host "Could not check for overlaps (may be normal if columns don't exist yet)" -ForegroundColor Yellow
}

Write-Host ""
Write-Host "Step 4: Checking if btree_gist extension exists..." -ForegroundColor Yellow
try {
    $extQuery = "SELECT EXISTS (SELECT 1 FROM pg_extension WHERE extname = 'btree_gist');"
    $extResult = & psql $env:DATABASE_URL -t -c $extQuery 2>&1
    $extExists = $extResult -match "t"
    if ($extExists) {
        Write-Host "btree_gist extension exists" -ForegroundColor Green
    } else {
        Write-Host "btree_gist extension does not exist" -ForegroundColor Yellow
        Write-Host "   Will attempt to create it (requires superuser)" -ForegroundColor Yellow
    }
} catch {
    Write-Host "Could not check extension" -ForegroundColor Yellow
}

Write-Host ""
Write-Host "Step 5: Running migration with detailed output..." -ForegroundColor Yellow
Write-Host ("-" * 60) -ForegroundColor Gray
Write-Host ""

# Run migration and capture all output
$outputFile = "migration-034-output.log"
Write-Host "Output will be saved to: $outputFile" -ForegroundColor Cyan
Write-Host ""

try {
    # Run migration and capture both stdout and stderr
    & psql $env:DATABASE_URL -f $migrationFile *> $outputFile 2>&1
    $exitCode = $LASTEXITCODE
    
    # Display output
    Get-Content $outputFile | ForEach-Object {
        $line = $_
        if ($line -match "ERROR|error|ERROR:") {
            Write-Host $line -ForegroundColor Red
        } elseif ($line -match "WARNING|warning|WARN") {
            Write-Host $line -ForegroundColor Yellow
        } elseif ($line -match "NOTICE|notice") {
            Write-Host $line -ForegroundColor Cyan
        } elseif ($line -match "success|SUCCESS") {
            Write-Host $line -ForegroundColor Green
        } else {
            Write-Host $line
        }
    }
    
    Write-Host ""
    Write-Host ("-" * 60) -ForegroundColor Gray
    Write-Host ""
    
    if ($exitCode -eq 0) {
        Write-Host "Migration completed (exit code: $exitCode)" -ForegroundColor Green
    } else {
        Write-Host "Migration failed (exit code: $exitCode)" -ForegroundColor Red
        Write-Host ""
        Write-Host "Full error log saved to: $outputFile" -ForegroundColor Yellow
        Write-Host ""
        Write-Host "Common error patterns:" -ForegroundColor Cyan
        Write-Host "   - 'permission denied' = Need superuser for btree_gist extension" -ForegroundColor Gray
        Write-Host "   - 'constraint' errors = Existing overlapping data" -ForegroundColor Gray
        Write-Host "   - 'syntax error' = SQL syntax issue" -ForegroundColor Gray
        Write-Host "   - 'column already exists' = Migration partially ran" -ForegroundColor Gray
    }
    
    Write-Host ""
    Write-Host "Tip: Check the log file for detailed error messages" -ForegroundColor Yellow
    
} catch {
    Write-Host ""
    Write-Host "ERROR: Failed to run migration" -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Red
    Write-Host ""
    Write-Host "Make sure psql is installed and in your PATH" -ForegroundColor Yellow
}
