import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import path from "path";
import runtimeErrorOverlay from "@replit/vite-plugin-runtime-error-modal";

// Custom logger to suppress WebSocket proxy errors and PostCSS warnings
const customLogger = {
  info: (msg: string) => {
    if (msg.includes('ws proxy error') || msg.includes('ws proxy socket error')) return;
    if (msg.includes('PostCSS plugin') && msg.includes('did not pass the `from` option')) return;
    console.log(msg);
  },
  warn: (msg: string) => {
    if (msg.includes('ws proxy error') || msg.includes('ws proxy socket error')) return;
    if (msg.includes('PostCSS plugin') && msg.includes('did not pass the `from` option')) return;
    console.warn(msg);
  },
  error: (msg: string) => {
    if (msg.includes('ws proxy error') || msg.includes('ws proxy socket error')) return;
    if (msg.includes('PostCSS plugin') && msg.includes('did not pass the `from` option')) return;
    console.error(msg);
  },
  warnOnce: (msg: string) => {
    if (msg.includes('ws proxy error') || msg.includes('ws proxy socket error')) return;
    if (msg.includes('PostCSS plugin') && msg.includes('did not pass the `from` option')) return;
    console.warn(msg);
  },
  clearScreen: () => {},
  hasErrorLogged: () => false,
  hasWarned: false,
};

export default defineConfig({
  plugins: [
    react(),
    runtimeErrorOverlay(),
    ...(process.env.NODE_ENV !== "production" &&
    process.env.REPL_ID !== undefined
      ? [
          await import("@replit/vite-plugin-cartographer").then((m) =>
            m.cartographer(),
          ),
          await import("@replit/vite-plugin-dev-banner").then((m) =>
            m.devBanner(),
          ),
        ]
      : []),
  ],
  resolve: {
    alias: {
      "@": path.resolve(import.meta.dirname, "client", "src"),
      "@shared": path.resolve(import.meta.dirname, "shared"),
      "@assets": path.resolve(import.meta.dirname, "attached_assets"),
    },
  },
  root: path.resolve(import.meta.dirname, "client"),
  build: {
    outDir: path.resolve(import.meta.dirname, "dist/public"),
    emptyOutDir: true,
  },
  customLogger: customLogger,
  server: {
    host: "0.0.0.0",
    // Client dev server port - can be overridden with VITE_PORT or CLIENT_PORT env var
    port: parseInt(process.env.VITE_PORT || process.env.CLIENT_PORT || "5174", 10),
    allowedHosts: true,
    fs: {
      strict: true,
      deny: ["**/.*"],
    },
    proxy: {
      // Proxy API requests to the backend server
      "/api": {
        // Server port - can be overridden with SERVER_PORT or PORT env var
        target: process.env.VITE_API_URL || 
                process.env.API_URL || 
                `http://localhost:${process.env.SERVER_PORT || process.env.PORT || "3000"}`,
        changeOrigin: true,
        secure: false,
        cookieDomainRewrite: "",
        cookiePathRewrite: "/",
        // Suppress expected WebSocket proxy errors during development
        configure: (proxy, _options) => {
          // Suppress all proxy errors (connection refused/reset are expected during startup)
          const originalEmit = proxy.emit.bind(proxy);
          proxy.emit = function(event: string, ...args: any[]) {
            // Suppress error events for WebSocket proxy issues
            if (event === 'error') {
              const err = args[0];
              if (err && (err.code === 'ECONNREFUSED' || err.code === 'ECONNRESET' || err.message?.includes('ECONNREFUSED') || err.message?.includes('ECONNRESET'))) {
                // Only log if explicitly debugging
                if (process.env.DEBUG_WEBSOCKET === 'true') {
                  console.error('[Vite] API proxy error:', err.message);
                }
                return false; // Prevent error from being emitted
              }
            }
            return originalEmit(event, ...args);
          };
          
          proxy.on('error', (err, _req, _res) => {
            // Suppress connection errors - they're expected during dev
            if (process.env.DEBUG_WEBSOCKET !== 'true') {
              return; // Silently ignore
            }
          });
          
          // Suppress WebSocket upgrade errors
          proxy.on('proxyReqWs', (proxyReq, req, socket) => {
            socket.on('error', (err) => {
              // Suppress all WebSocket connection errors
              if (process.env.DEBUG_WEBSOCKET !== 'true') {
                return; // Silently ignore
              }
            });
          });
        },
      },
      // Proxy WebSocket connections to the backend server
      "/ws": {
        target: process.env.VITE_API_URL || 
                process.env.API_URL || 
                `http://localhost:${process.env.SERVER_PORT || process.env.PORT || "3000"}`,
        ws: true,
        changeOrigin: true,
        secure: false,
        // Suppress expected WebSocket proxy errors during development
        configure: (proxy, _options) => {
          // Suppress all WebSocket proxy errors
          const originalEmit = proxy.emit.bind(proxy);
          proxy.emit = function(event: string, ...args: any[]) {
            // Suppress error events for WebSocket proxy issues
            if (event === 'error') {
              const err = args[0];
              if (err && (err.code === 'ECONNREFUSED' || err.code === 'ECONNRESET' || err.message?.includes('ECONNREFUSED') || err.message?.includes('ECONNRESET'))) {
                // Only log if explicitly debugging
                if (process.env.DEBUG_WEBSOCKET === 'true') {
                  console.error('[Vite] WebSocket proxy error:', err.message);
                }
                return false; // Prevent error from being emitted
              }
            }
            return originalEmit(event, ...args);
          };
          
          proxy.on('error', (err, _req, _res) => {
            // Suppress connection errors - they're expected during dev
            if (process.env.DEBUG_WEBSOCKET !== 'true') {
              return; // Silently ignore
            }
          });
          
          // Suppress socket errors
          proxy.on('proxyReqWs', (proxyReq, req, socket) => {
            socket.on('error', (err) => {
              // Suppress socket errors
              if (process.env.DEBUG_WEBSOCKET !== 'true') {
                return;
              }
            });
          });
        },
      },
    },
  },
});
