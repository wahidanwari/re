# Phase 1: Analyze - Case Completion + Full Reporting Form

## 1. Current "Complete Case" Flow

### 1.1 User Flow

**Step 1: Auditor clicks "Complete Case" button**
- Location: `client/src/pages/Cases.tsx` - `handleCompleteCase()` function (line 447)
- Action: Opens report dialog (`setReportDialogOpen(true)`)
- Selected case is stored in state

**Step 2: Report Form Dialog Opens**
- Component: `CaseReportForm` (`client/src/components/CaseReportForm.tsx`)
- Fetches existing report data via `GET /api/cases/:id/report`
- Form displays with auto-populated data from case/entity

**Step 3: User Fills Report Form**
- Two sections:
  - **Section 1: مشخصات نهاد** (Entity Details) - Mostly disabled/read-only
  - **Section 2: بیرون‌نویسی‌ها** (Extractions) - All editable fields
- No draft save functionality
- No autosave
- All fields must be filled before submission

**Step 4: User Clicks "ذخیره و ادامه" (Save and Continue)**
- `handleSaveReport()` is called (line 452)
- First saves report via `POST /api/cases/:id/report`
- Then immediately calls `completeCaseMutation.mutate()` to complete the case
- Case status changes to "تکمیل شده"

**Step 5: Backend Validation**
- `POST /api/cases/:id/complete` endpoint validates report completion
- Uses `validateCaseReportCompletion()` from `reportValidationService.ts`
- Checks all required fields are filled
- If validation fails, case completion is blocked

### 1.2 Backend Flow

**Report Save Endpoint: `POST /api/cases/:id/report`**
- Location: `server/routes/cases.ts` (line 1015)
- RBAC: Requires `cases:complete` permission
- Prevents editing reports for approved/rejected cases
- Upserts report data to `case_reports` table
- Updates case `transactionId` if `attachmentNumber` provided

**Report Fetch Endpoint: `GET /api/cases/:id/report`**
- Location: `server/routes/cases.ts` (line 931)
- RBAC: Requires `cases:view` permission
- Auto-populates data from:
  - Case table (companyName, tin, businessNature, etc.)
  - Entity table (fallback values)
  - Documents table (final document date)
  - Existing report (if any)

**Case Completion Endpoint: `POST /api/cases/:id/complete`**
- Location: `server/routes/cases.ts` (line 686)
- Uses state machine transition `'complete'`
- Validates report completion before allowing transition
- Updates case status to "تکمیل شده"
- Sets `completedBy` and `completedAt` fields
- Updates entity status if all cases completed

## 2. Current Report Fields

### 2.1 Database Schema

**Table: `case_reports`**
- Location: `shared/schema.ts` (line 252)
- Fields stored:
  - `id` (VARCHAR, PK)
  - `caseId` (VARCHAR, FK to cases, UNIQUE)
  - `finalDocumentDate` (TEXT) - تاریخ صادره مکتوب نهایی
  - `capitalPeriod` (TEXT) - دوران سرمایه
  - `salaryTax` (TEXT) - مالیه موضوعی معاشات
  - `rentTax` (TEXT) - مالیه موضوعی بر کرایه
  - `contractTax` (TEXT) - مالیه موضوعی قراردادی
  - `profitTransactionTax` (TEXT) - مالیات معاملات انتفاعی
  - `incomeTax` (TEXT) - مالیات بر عایدات
  - `reducedLoss` (TEXT) - ضرر کاهش یافته
  - `reducedRemainingAmount` (TEXT) - مبلغ فاضل تحویل کاهش یافته
  - `confirmedAmount` (TEXT) - مبلغ تثبیت شده
  - `collectedCurrentMonth` (TEXT) - مبلغ تحصیل شده طی برج جاری
  - `remainingCollectible` (TEXT) - الباقی مبلغ قابل تحصیل
  - `activityStatus` (TEXT) - وضعیت فعالیت
  - `attachmentNumber` (TEXT) - نمبر آویز
  - `attachmentDate` (TEXT) - تاریخ آویز
  - `createdAt` (TIMESTAMP)
  - `updatedAt` (TIMESTAMP)

**Note:** All financial fields are stored as TEXT, not numeric types. No structured validation for numeric values.

### 2.2 Form Fields (Current Implementation)

**Section 1: مشخصات نهاد (Entity Details)**
- `companyName` - Auto-populated from case, **DISABLED**
- `tin` - Auto-populated from case, **DISABLED**
- `businessNature` - Auto-populated from case, **DISABLED**
- `groupReferrer` - Auto-populated from case, **DISABLED**
- `referralDate` - Auto-populated from case, **DISABLED**
- `periodsUnderReview` - Auto-populated from case, **DISABLED**
- `finalDocumentDate` - **EDITABLE** (ShamsiDatePickerDDMMYYYY)
- `capitalPeriod` - **EDITABLE** (Text input)

**Section 2: بیرون‌نویسی‌ها (Extractions)**
- `salaryTax` - **EDITABLE** (Text input, placeholder "0")
- `rentTax` - **EDITABLE** (Text input, placeholder "0")
- `contractTax` - **EDITABLE** (Text input, placeholder "0")
- `profitTransactionTax` - **EDITABLE** (Text input, placeholder "0")
- `incomeTax` - **EDITABLE** (Text input, placeholder "0")
- `reducedLoss` - **EDITABLE** (Text input, placeholder "0")
- `reducedRemainingAmount` - **EDITABLE** (Text input, placeholder "0")
- `confirmedAmount` - **EDITABLE** (Text input, placeholder "0")
- `collectedCurrentMonth` - **EDITABLE** (Text input, placeholder "0")
- `remainingCollectible` - **EDITABLE** (Text input, placeholder "0")
- `activityStatus` - **EDITABLE** (Select: "فعال" / "عدم فعالیت")
- `attachmentNumber` - **EDITABLE** (Text input, auto-populated from case.transactionId)
- `attachmentDate` - **EDITABLE** (ShamsiDatePickerDDMMYYYY)

**Total: 19 fields (7 auto-populated/disabled, 12 editable)**

## 3. Missing Form Sections

Based on official MoF (Ministry of Finance) reporting requirements, the following sections are **MISSING**:

### 3.1 Section 1 Extensions (مشخصات نهاد)

**Currently Missing:**
- **Address Information:**
  - Province (ولایت)
  - District (ولسوالی)
  - Street Address (آدرس)
  - Contact Information (Phone, Email)

- **Registration Details:**
  - Registration Number (نمبر ثبت)
  - Registration Date (تاریخ ثبت)
  - Business License Number (نمبر جواز فعالیت)

- **Tax Information:**
  - Tax Office (دفتر مالیاتی)
  - Tax Registration Date (تاریخ ثبت مالیاتی)

### 3.2 Section 2 Extensions (بیرون‌نویسی‌ها)

**Currently Missing:**
- **Additional Tax Types:**
  - Withholding Tax (مالیات کسر شده)
  - Penalty Tax (مالیات جریمه)
  - Interest (سود)
  - Other Taxes (سایر مالیات‌ها)

- **Payment Information:**
  - Payment Method (روش پرداخت)
  - Payment Reference Number (نمبر مرجع پرداخت)
  - Bank Account Details (جزئیات حساب بانکی)

- **Calculation Details:**
  - Tax Base (مبنا مالیاتی)
  - Tax Rate (نرخ مالیاتی)
  - Calculation Method (روش محاسبه)

### 3.3 Section 3: Findings & Recommendations (NEW)

**Completely Missing:**
- **Audit Findings:**
  - Summary of Findings (خلاصه یافته‌ها)
  - Detailed Findings (یافته‌های تفصیلی)
  - Risk Assessment (ارزیابی ریسک)

- **Recommendations:**
  - Recommendations (توصیه‌ها)
  - Action Items (اقدامات لازم)
  - Follow-up Required (نیاز به پیگیری)

### 3.4 Section 4: Supporting Documents (NEW)

**Completely Missing:**
- **Document Checklist:**
  - Documents Reviewed (اسناد بررسی شده)
  - Documents Attached (اسناد ضمیمه)
  - Missing Documents (اسناد ناقص)

### 3.5 Section 5: Approval & Signatures (NEW)

**Completely Missing:**
- **Approval Information:**
  - Prepared By (تهیه شده توسط)
  - Reviewed By (بررسی شده توسط)
  - Approved By (تایید شده توسط)
  - Dates for each approval stage

## 4. Current Backend APIs

### 4.1 Report APIs

**GET `/api/cases/:id/report`**
- **Purpose:** Fetch report data for editing
- **Method:** GET
- **Auth:** Requires `cases:view` permission
- **Response:** JSON object with all report fields (auto-populated)
- **RBAC:** Enforced via `getCaseVisibility()`
- **Auto-population:** Merges data from case, entity, documents, and existing report

**POST `/api/cases/:id/report`**
- **Purpose:** Save/update report data
- **Method:** POST
- **Auth:** Requires `cases:complete` permission
- **Request Body:** JSON with all report fields
- **Response:** Saved report object
- **Validation:** 
  - Prevents editing approved/rejected cases
  - No field-level validation (only presence check)
- **Storage:** Upserts to `case_reports` table

### 4.2 Case Completion APIs

**POST `/api/cases/:id/complete`** (DEPRECATED - uses state machine)
- **Purpose:** Complete a case (mark as "تکمیل شده")
- **Method:** POST
- **Auth:** Requires `cases:complete` permission
- **Validation:** 
  - Calls `validateCaseReportCompletion()`
  - Checks all required fields are filled
  - Allows override for senior auditors/directors
- **Side Effects:**
  - Updates case status
  - Sets `completedBy` and `completedAt`
  - Updates entity status if all cases completed
  - Creates audit log
  - Sends notifications

**POST `/api/cases/:id/transition`** (NEW - unified endpoint)
- **Purpose:** Execute case status transition (including 'complete')
- **Method:** POST
- **Body:** `{ transition: 'complete', metadata?: {...} }`
- **Validation:** Uses state machine service
- **Same validation as old endpoint**

### 4.3 Validation Service

**File:** `server/services/reportValidationService.ts`

**Function: `validateCaseReportCompletion(caseItem, allowOverride)`**
- **Purpose:** Validate all required report fields are filled
- **Returns:** `ReportValidationResult` with:
  - `isValid: boolean`
  - `missingFields: string[]`
  - `errorMessage?: string`
- **Required Fields Checked:**
  - From case: companyName, tin, businessNature, groupReferrer, referralDate, periodsUnderReview
  - From report: finalDocumentDate, capitalPeriod, all financial fields, activityStatus, attachmentNumber, attachmentDate
- **Override Logic:** Senior auditors/directors can override with warning

**Function: `canOverrideValidation(user)`**
- **Purpose:** Check if user can override validation warnings
- **Returns:** `boolean`
- **Logic:** System admin always, or has `reports:override_complete` permission

## 5. Database Structure

### 5.1 Current Schema

**Table: `case_reports`**
```sql
CREATE TABLE case_reports (
  id VARCHAR PRIMARY KEY,
  case_id VARCHAR UNIQUE NOT NULL REFERENCES cases(id) ON DELETE CASCADE,
  final_document_date TEXT,
  capital_period TEXT,
  salary_tax TEXT,
  rent_tax TEXT,
  contract_tax TEXT,
  profit_transaction_tax TEXT,
  income_tax TEXT,
  reduced_loss TEXT,
  reduced_remaining_amount TEXT,
  confirmed_amount TEXT,
  collected_current_month TEXT,
  remaining_collectible TEXT,
  activity_status TEXT,
  attachment_number TEXT,
  attachment_date TEXT,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);
```

**Issues:**
1. All fields are TEXT - no type safety for numeric values
2. No draft/completed status field
3. No versioning/history
4. No structured sections (all flat fields)
5. No metadata (who saved, when, draft vs final)

### 5.2 Related Tables

**Table: `cases`**
- Contains basic case info (companyName, tin, etc.)
- Status field tracks case lifecycle
- `transactionId` field stores attachment number

**Table: `entities`**
- Contains entity details (fallback for case data)
- Not directly linked to reports

**Table: `documents`**
- Contains uploaded documents
- Used to auto-populate `finalDocumentDate`

## 6. Current Issues

### 6.1 RTL (Right-to-Left) Issues

**Problem 1: Form Layout**
- Location: `CaseReportForm.tsx`
- Issue: While `dir="rtl"` is set on form, individual input fields may not properly align
- Evidence: No explicit RTL classes on all inputs
- Impact: Poor UX for Persian/Arabic users

**Problem 2: Date Pickers**
- Component: `ShamsiDatePickerDDMMYYYY`
- Issue: May not be fully RTL-aware in all browsers
- Impact: Date selection may appear LTR

**Problem 3: Number Inputs**
- Issue: Financial fields use text inputs, no RTL number formatting
- Impact: Numbers may appear in wrong direction

**Problem 4: Grid Layout**
- Issue: `grid-cols-2` may not respect RTL properly
- Impact: Fields may appear in wrong order

### 6.2 No Structured Report Model

**Problem:**
- All report fields are flat in database
- No section grouping
- No hierarchical structure
- No way to represent "Section 1", "Section 2", etc. in data model

**Impact:**
- Cannot easily add new sections
- Cannot reorder sections
- Cannot hide/show sections based on case type
- Difficult to generate structured PDFs

### 6.3 No Validation

**Problem 1: Field-Level Validation**
- No numeric validation for financial fields
- No date format validation
- No range validation (e.g., dates must be in valid range)
- No business rule validation (e.g., totals must match)

**Problem 2: Section-Level Validation**
- No validation that Section 1 is complete before Section 2
- No conditional validation (e.g., if activityStatus = "عدم فعالیت", some fields may be optional)

**Problem 3: Cross-Field Validation**
- No validation that financial totals are consistent
- No validation that dates are in correct order
- No validation that attachment date is after final document date

### 6.4 No Draft-Save Functionality

**Problem 1: No Draft State**
- Database has no `isDraft` or `status` field
- Cannot distinguish between draft and final reports
- All saves are treated as final

**Problem 2: No Autosave**
- No automatic saving of form data
- User must manually click "Save"
- Risk of data loss if browser crashes

**Problem 3: No Save History**
- No versioning of reports
- Cannot see what changed between saves
- Cannot revert to previous version

**Problem 4: No Partial Save**
- Must fill all fields before saving
- Cannot save partially completed form
- Poor UX for long forms

### 6.5 No Report Locking

**Problem:**
- Reports can be edited even after case is completed
- No lock mechanism for completed reports
- Risk of data tampering after approval

**Current Protection:**
- Only prevents editing approved/rejected cases
- Does not prevent editing completed cases (before approval)

### 6.6 No PDF/Print Export

**Problem:**
- No endpoint to generate PDF of report
- No print-friendly view
- Cannot export report for official submission

**Impact:**
- Users must manually copy data
- No official report format
- Cannot submit to MoF systems

### 6.7 Poor UX

**Problem 1: All-or-Nothing Submission**
- Must fill entire form before submission
- No progress indicator
- No section-by-section completion

**Problem 2: No Field Help/Validation Messages**
- No inline help text
- No real-time validation feedback
- Error messages only on submit

**Problem 3: No Auto-calculation**
- Financial totals must be calculated manually
- No automatic sum of tax fields
- No validation of calculations

**Problem 4: No Professional Layout**
- Form does not match official MoF report format
- No header/footer with official branding
- No structured sections matching official documents

## 7. Dependencies

### 7.1 On Case Management
- Report is tied to case via `caseId` foreign key
- Case status affects report editability
- Case completion requires valid report

### 7.2 On Entity Management
- Report auto-populates from entity data
- Entity changes may affect report data
- Entity status updates when all cases completed

### 7.3 On Document Management
- Final document date auto-populated from documents
- Documents may be required for report completion
- Document upload may trigger report updates

### 7.4 On RBAC
- Report viewing requires `cases:view`
- Report editing requires `cases:complete`
- Report override requires `reports:override_complete`
- Permissions affect what fields can be edited

## 8. Technical Debt

### 8.1 Data Type Issues
- All financial fields stored as TEXT
- Should be NUMERIC or DECIMAL for calculations
- No type safety in TypeScript

### 8.2 No Migration Path
- No way to migrate existing reports to new structure
- No versioning of report schema
- Breaking changes would require manual migration

### 8.3 No API Versioning
- Report API endpoints not versioned
- Changes would break existing clients
- No backward compatibility strategy

### 8.4 No Caching
- Report data fetched on every form load
- No caching of auto-populated data
- Performance issues with large datasets

## 9. Summary

### 9.1 Current State
- **Basic reporting form exists** with 19 fields
- **Two sections** (Entity Details, Extractions)
- **Backend validation** for required fields
- **Auto-population** from case/entity/documents
- **RBAC enforcement** for viewing/editing

### 9.2 Major Gaps
1. **Missing sections:** Address, Registration, Tax Info, Findings, Recommendations, Documents, Approvals
2. **No draft mode:** Cannot save partial reports
3. **No autosave:** Risk of data loss
4. **No validation:** No field-level or business rule validation
5. **No RTL accuracy:** Layout issues for Persian/Arabic
6. **No structured model:** Flat database schema
7. **No PDF export:** Cannot generate official reports
8. **No locking:** Reports editable after completion
9. **Poor UX:** All-or-nothing submission, no progress tracking

### 9.3 Critical Issues
- **RTL broken:** Form not properly RTL-aware
- **No structured report model:** Cannot extend easily
- **No validation:** Data quality issues
- **No draft-save:** Poor user experience

### 9.4 Next Steps (Phase 2)
- Design structured report schema with sections
- Design draft/final state management
- Design autosave mechanism
- Design validation rules per section
- Design PDF export structure
- Design RTL-accurate layout matching official MoF format
- Design report locking mechanism

