# Database Cleanup Script

## ⚠️ WARNING

This script performs **destructive database operations**. Only run this if you have:
- Proper authority and approval
- Complete database backups
- Understanding of the consequences

## Overview

The `db-cleanup.ts` script safely cleans up soft-deleted (inactive) users and groups from the database. It follows a strict 12-step safety protocol:

1. **Authority Verification** - Confirms permissions and access
2. **Database Backup** - Creates a full backup before any changes
3. **Change Request Logging** - Records the operation intent
4. **Candidate Identification** - Finds all inactive users/groups
5. **Blocking Reference Checks** - Verifies no open cases/tickets/assignments
6. **Candidate Report** - Generates human-readable report for review
7. **Policy Selection** - Choose between deletion or anonymization
8. **Transaction-Based Cleanup** - Performs operations in safe transactions
9. **Confirmation Report** - Documents exactly what was changed
10. **Post-Action Verification** - Tests that freed names are reusable
11. **Housekeeping** - Runs VACUUM ANALYZE on affected tables
12. **Rollback Documentation** - Provides restore instructions

## Prerequisites

1. PostgreSQL database with `pg_dump` available (for backups)
2. Environment variables configured:
   - `DATABASE_URL` - PostgreSQL connection string
   - `CLEANUP_POLICY` - Either `"delete"` or `"anonymize"` (required for execution)
   - `CLEANUP_APPROVER_NAME` - Name of person approving the operation (required for execution)
   - `CLEANUP_APPROVER_EMAIL` - Email of approver (optional)
   - `CLEANUP_REQUESTED_BY` - Person requesting cleanup (optional, defaults to "System Administrator")

## Usage

### Step 1: Review Candidates (Dry Run)

First, run the script without the policy to see what will be cleaned:

```bash
npm run db:cleanup
```

This will:
- Create a backup
- Identify all inactive users/groups
- Check for blocking references
- Generate a candidate report in `cleanup-reports/`
- **Stop and wait for approval**

### Step 2: Review the Report

Examine the candidate report in `cleanup-reports/candidate-report-*.txt` to verify:
- Which users/groups are safe to delete
- That no blocking references exist
- That you want to proceed

### Step 3: Execute Cleanup

Once you've reviewed and approved, run with the policy:

**For Permanent Deletion:**
```bash
CLEANUP_POLICY=delete CLEANUP_APPROVER_NAME="Your Name" npm run db:cleanup
```

**For Anonymization (Preserves Historical Data):**
```bash
CLEANUP_POLICY=anonymize CLEANUP_APPROVER_NAME="Your Name" npm run db:cleanup
```

## What Gets Cleaned

### Users
- Only users with `isActive = false` are considered
- Must have zero blocking references:
  - No open/pending cases (assigned, approved, rejected, or completed by user)
  - No pending tickets requested by user
  - No active group memberships
  - No non-revoked uploaded documents
  - No group targets set by user

### Groups
- Only groups with `isActive = false` are considered
- Must have zero blocking references:
  - No active users in group
  - No open/pending cases referred by group
  - No active group members
  - No pending tickets for group
  - No group targets
  - No entities with referral group

## Cleanup Policies

### Delete Policy
- **Permanently removes** user/group records
- Deletes dependent ephemeral data:
  - User sessions
  - User roles and packages
  - Notifications
  - Group memberships
- **Preserves** historical audit logs (userId can be NULL)
- **Frees** audit IDs and group codes for reuse

### Anonymize Policy
- **Preserves** all user/group records
- Updates names to deterministic placeholders:
  - Users: `deleted_<id>_<timestamp>` for auditId
  - Groups: `deleted_<id>_<timestamp>` for code
- Marks records as permanently deleted
- **Maintains** full historical integrity
- **Frees** original names for reuse

## Output Files

All reports are saved in `cleanup-reports/`:

- `candidate-report-<timestamp>.txt` - List of safe-to-delete candidates
- `confirmation-<timestamp>.txt` - What was actually changed
- `rollback-plan-<timestamp>.txt` - Instructions for restoring from backup

Backups are saved in `backups/`:
- `db-backup-<timestamp>.sql` - Full database backup

## Rollback Procedure

If something goes wrong:

1. **Stop the application**
2. **Restore from backup:**
   ```bash
   pg_restore -h <host> -p <port> -U <user> -d <database> backups/db-backup-<timestamp>.sql
   ```
3. **Verify data integrity**
4. **Restart the application**

See the rollback plan file for detailed instructions.

## Safety Features

- ✅ All operations in transactions (can rollback)
- ✅ Explicit approval required via environment variables
- ✅ Full backup before any changes
- ✅ Comprehensive blocking reference checks
- ✅ Detailed audit logging
- ✅ Human-readable reports
- ✅ Post-action verification
- ✅ Database housekeeping (VACUUM ANALYZE)

## Troubleshooting

### "Backup verification incomplete"
- Ensure `pg_dump` is installed and in PATH
- Check database connection permissions
- Verify backup directory is writable

### "No candidates found"
- This is normal if no inactive users/groups exist
- Script will exit successfully

### "Missing required environment variables"
- Set `CLEANUP_POLICY` and `CLEANUP_APPROVER_NAME` to proceed
- First run (without these) generates the candidate report only

### Session deletion errors
- Non-critical - sessions expire automatically
- Logged but doesn't block cleanup

## Audit Trail

All cleanup operations are logged to the `audit_logs` table:
- `cleanup_initiated` - When script starts
- `cleanup_completed` - When cleanup finishes successfully
- `cleanup_failed` - If any errors occur

## Support

For issues or questions:
1. Check the cleanup reports for details
2. Review audit logs in the database
3. Verify backup integrity
4. Contact your DBA or system administrator

