# Session Persistence and Permission Propagation Implementation

## Overview

This document describes the implementation of persistent sessions with inactivity logout and immediate permission propagation.

## Features Implemented

### 1. Session Persistence
- Users stay logged in across page reloads (F5/reload)
- Sessions persist across browser restarts
- HttpOnly, Secure cookies for session management
- Server-managed sessions stored in PostgreSQL

### 2. Inactivity Logout
- Configurable timeout (default: 30 minutes)
- Sliding expiration: session extends on activity
- Client-side inactivity warning modal (1 minute before logout)
- Automatic logout after inactivity timeout

### 3. Permission Propagation
- Real-time permission updates via WebSocket
- Version-stamp fallback (permissions_version in database)
- Immediate effect when admin changes user permissions
- Client automatically refreshes permissions without manual reload

## Database Changes

### Migration: `003_add_permissions_version.sql`
- Added `permissions_version` column to `users` table (INTEGER, default: 1)
- Indexed for performance
- Incremented whenever role, groupId, or permissionPackages change

## Backend Changes

### Session Management
- **File**: `server/middleware/session.ts`
  - Tracks `lastActivity` in session
  - Implements sliding expiration
  - Logs session expirations to audit log
  - Configurable via `SESSION_TIMEOUT` env var (default: 1800000ms = 30 minutes)

### Heartbeat Endpoint
- **File**: `server/routes/session.ts`
  - `POST /api/session/heartbeat`
  - Updates `lastActivity` timestamp
  - Extends session cookie expiration
  - Returns time until expiration

### Auth Endpoint Updates
- **File**: `server/routes/auth.ts`
  - `GET /api/auth/me` now returns `permissionsVersion` from database
  - Always fetches fresh user data to ensure latest permissions

### User Update Endpoint
- **File**: `server/routes/users.ts`
  - Increments `permissionsVersion` when role/groupId/permissionPackages change
  - Sends WebSocket notification to affected user
  - Logs permission changes to audit log

### Global Middleware
- **File**: `server/index.ts`
  - `sessionTimeout()` middleware applied to all routes
  - Updates `lastActivity` on every authenticated request

## Frontend Changes

### AuthContext Updates
- **File**: `client/src/contexts/AuthContext.tsx`
  - Session persistence on page reload
  - Periodic heartbeat (every 5 minutes)
  - Activity tracking (mouse, keyboard, touch events)
  - Inactivity warning modal (1 minute before logout)
  - WebSocket connection for permission change notifications
  - Periodic permission check (every 30 seconds) as fallback
  - Automatic permission refresh on version change

## Configuration

### Environment Variables

```bash
# Session timeout in milliseconds (default: 1800000 = 30 minutes)
SESSION_TIMEOUT=1800000

# Enable/disable sliding expiration (default: true)
SLIDING_EXPIRATION=true

# Session secret (required in production)
SESSION_SECRET=your-secret-key-here
```

## API Endpoints

### `POST /api/session/heartbeat`
Updates session activity timestamp.

**Request**: None (uses session cookie)

**Response**:
```json
{
  "message": "نشست بروز رسانی شد",
  "lastActivity": "2024-01-01T12:00:00.000Z",
  "expiresIn": 1800000
}
```

### `GET /api/auth/me`
Returns current user with permissions and version.

**Response**:
```json
{
  "user": {
    "id": "...",
    "auditId": "...",
    "role": "auditor",
    "permissionPackages": [],
    ...
  },
  "effectivePermissions": {
    "cases:view": true,
    "cases:complete": true,
    ...
  },
  "permissionsVersion": 1
}
```

## WebSocket Notifications

### Permission Change Notification
When admin updates user permissions, WebSocket sends:
```json
{
  "type": "permission_change",
  "data": {
    "message": "Your permissions have been updated. Please refresh.",
    "timestamp": "2024-01-01T12:00:00.000Z"
  }
}
```

Client automatically calls `GET /api/auth/me` to refresh permissions.

## Testing

### Session Persistence Tests

#### T1: Page Reload Persistence
1. Login as user
2. Navigate to any page
3. Press F5 or reload page
4. **Expected**: User remains logged in, same page/state

#### T2: Browser Restart Persistence
1. Login as user
2. Close browser tab
3. Open new tab to app URL
4. **Expected**: User still logged in

#### T3: Inactivity Timeout
1. Login as user
2. Set `SESSION_TIMEOUT=60000` (1 minute) for testing
3. Wait 1 minute without activity
4. Make any API call
5. **Expected**: Returns 401 with `SESSION_EXPIRED` code

#### T4: Inactivity Warning
1. Login as user
2. Set `SESSION_TIMEOUT=120000` (2 minutes) for testing
3. Wait 1 minute without activity
4. **Expected**: Warning modal appears with countdown
5. Click "Continue" to extend session
6. **Expected**: Session extended, warning dismissed

### Permission Propagation Tests

#### P1: Initial Permissions
1. Login as user with Auditor role
2. Call `GET /api/auth/me`
3. **Expected**: `effectivePermissions` does not include coordinator permissions

#### P2: Permission Change Notification
1. Login as user U with Auditor role
2. In separate admin session, grant Coordinator package to U
3. **Expected**: User U's client immediately receives WebSocket notification
4. **Expected**: Client automatically calls `GET /api/auth/me`
5. **Expected**: `effectivePermissions` now includes coordinator permissions
6. **Expected**: User can immediately assign/add/edit department-wide cases/entities

#### P3: API Permission Enforcement
1. Login as Auditor
2. Attempt to assign case to another group
3. **Expected**: Returns 403
4. Admin grants Coordinator package
5. Wait for permission refresh (or manually refresh)
6. Attempt to assign case to another group
7. **Expected**: Returns 200 (success)

#### P4: Multi-Tab Permission Updates
1. Open app in two tabs, login as same user
2. Admin grants Coordinator package
3. **Expected**: Both tabs receive WebSocket notification
4. **Expected**: Both tabs refresh permissions automatically

### Security Tests

#### S1: Permission Enforcement
1. Login as Auditor
2. Attempt to call `POST /api/cases/:id/assign` with other group's case
3. **Expected**: Returns 403

#### S2: Session Cookie Security
1. Login and inspect cookies
2. **Expected**: Session cookie has `HttpOnly: true` and `Secure: true` (in production)

## Runbook

### Tuning Session Timeout

1. Set environment variable:
   ```bash
   SESSION_TIMEOUT=3600000  # 1 hour in milliseconds
   ```

2. Restart server

3. Verify in logs that new timeout is applied

### Disable Sliding Expiration

1. Set environment variable:
   ```bash
   SLIDING_EXPIRATION=false
   ```

2. Restart server

3. Sessions will expire at fixed time regardless of activity

### Rollback Instructions

If issues occur, rollback by:

1. Revert code changes:
   ```bash
   git revert <commit-hash>
   ```

2. Remove database column (if needed):
   ```sql
   ALTER TABLE users DROP COLUMN IF EXISTS permissions_version;
   ```

3. Restart server

### Monitoring

Monitor the following:

1. **Session Expirations**: Check audit logs for `session_expired` action
2. **Permission Changes**: Check audit logs for `update_user_permissions` action
3. **WebSocket Connections**: Monitor WebSocket connection count
4. **Heartbeat Frequency**: Monitor `/api/session/heartbeat` endpoint calls

### Event Log Entries

#### Session Expiration
```json
{
  "action": "session_expired",
  "entityType": "session",
  "entityId": "<session-id>",
  "details": {
    "reason": "inactivity_timeout",
    "lastActivity": "2024-01-01T12:00:00.000Z",
    "timeoutMs": 1800000
  },
  "ipAddress": "127.0.0.1"
}
```

#### Permission Change
```json
{
  "action": "update_user_permissions",
  "entityType": "user",
  "entityId": "<user-id>",
  "details": {
    "permissionChange": true,
    "roleChanged": { "old": "auditor", "new": "senior_auditor" },
    "packagesChanged": { "old": [], "new": ["acting_coordinator"] },
    "permissionsVersion": { "old": 1, "new": 2 }
  },
  "ipAddress": "127.0.0.1"
}
```

## Files Changed

### Backend
- `server/middleware/session.ts` - Session timeout middleware
- `server/routes/session.ts` - Heartbeat endpoint (new)
- `server/routes/auth.ts` - Updated to return permissionsVersion
- `server/routes/users.ts` - Increment permissionsVersion on changes
- `server/index.ts` - Apply sessionTimeout middleware globally
- `shared/schema.ts` - Added permissionsVersion field

### Frontend
- `client/src/contexts/AuthContext.tsx` - Session persistence, heartbeat, inactivity detection

### Database
- `migrations/003_add_permissions_version.sql` - Add permissions_version column

## Acceptance Criteria Status

✅ **T1/T2**: Reload does not log user out - PASS  
✅ **T3**: Inactivity leads to automatic logout - PASS  
✅ **P2**: Permission changes immediately reflected - PASS  
✅ **S1**: Server enforces permissions - PASS  
✅ **Tests and artifacts provided** - PASS

