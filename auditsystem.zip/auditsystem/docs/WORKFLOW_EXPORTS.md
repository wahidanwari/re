# Workflow Export System

## Overview

The workflow export system provides Excel and PDF export functionality for InternalReport and MinistrySummary. All exports use data from workflow tables only and never modify the master entity table.

## Export Functions

### InternalReport Exports

#### Excel Export

**Function**: `exportInternalReportToExcel(monthShamsi, yearShamsi)`

**Features**:
- Exports all active InternalReport records for the month/year
- Includes all tax breakdown fields
- Shows calculated totals (TotalTaxableAmount, RemainingAmount)
- Highlights rows with active alerts (light red background)
- Includes monthly totals row at the bottom
- RTL (Right-to-Left) formatting for Persian text
- Proper number formatting with thousand separators

**Columns**:
1. نام نهاد (Entity Name)
2. نمبر تشخیصیه (TIN)
3. مالیه موضوعی معاشات (Tax Salary)
4. مالیه موضوعی بر کرایه (Tax Rent)
5. مالیه موضوعی قراردادی (Tax Contract)
6. مالیه موضوعی معاملات انتفاعی (Tax Profit)
7. مالیات بر عایدات (Income Tax)
8. کل مبلغ قابل مالیات (Total Taxable Amount)
9. مبلغ تحصیل شده (Collected Amount)
10. مبلغ باقیمانده (Remaining Amount)
11. مبلغ تثبیت شده (Stabilized Amount)
12. ضرر کاهش یافته (Loss Reduction)
13. مکتوب های وارده (Correspondences In)
14. مکتوب های صادره (Correspondences Out)
15. استعلام های وارده (Inquiries In)
16. استعلام های صادره (Inquiries Out)
17. ملاحظات (Notes)

**Totals Row**:
- Sum of all tax types
- Total Taxable Amount
- Total Collected
- Total Remaining
- Total Stabilized
- Total correspondence and inquiry counts

#### PDF Export

**Function**: `exportInternalReportToPDF(monthShamsi, yearShamsi)`

**Features**:
- Compact PDF format for printing
- Summary view with key fields
- Monthly totals at the bottom
- Page breaks for long reports

**Fields Included**:
- Entity Name
- TIN
- Total Taxable Amount
- Collected Amount
- Remaining Amount
- Stabilized Amount

### MinistrySummary Exports

#### Excel Export

**Function**: `exportMinistrySummaryToExcel(monthShamsi, yearShamsi)`

**Features**:
- Exports all active MinistrySummary records for the month/year
- Includes entity counts by compliance status
- Shows revenue metrics and percent variation
- Highlights rows with active alerts (light red background)
- Includes ministry-level totals row at the bottom
- RTL formatting for Persian text
- Proper number formatting

**Columns**:
1. نام گروه (Group Name)
2. کل نهادها (Total Entities)
3. نهادهای تکمیل شده (Finalized Entities)
4. نهادهای نیمه مطابق (Partially Compliant Entities)
5. نهادهای غیرمطابق (Non-Compliant Entities)
6. درآمد تحصیل شده (Revenue Collected)
7. هدف درآمد ماهوار (Monthly Revenue Target)
8. درصد تغییر (Percent Variation)
9. مکتوب های وارده (Incoming Letters)
10. مکتوب های صادره (Outgoing Letters)
11. استعلام های وارده (Incoming Inquiries)
12. استعلام های صادره (Outgoing Inquiries)
13. ملاحظات (Notes)

**Totals Row**:
- Total entities across all groups
- Total finalized/partially compliant/non-compliant entities
- Total revenue collected
- Total revenue target
- Overall percent variation
- Total correspondence and inquiry counts

#### PDF Export

**Function**: `exportMinistrySummaryToPDF(monthShamsi, yearShamsi)`

**Features**:
- Compact PDF format for ministry submission
- Summary view with key metrics
- Ministry-level totals at the bottom
- Page breaks for long reports

**Fields Included**:
- Group Name
- Total Entities
- Revenue Collected
- Revenue Target
- Percent Variation

## API Endpoints

### Export InternalReport

**GET** `/api/workflow/export/internal-report/:month/:year?format=excel|pdf`

**Parameters**:
- `month`: Month in Shamsi calendar (1-12)
- `year`: Year in Shamsi calendar (e.g., 1404)
- `format`: Export format - `excel` (default) or `pdf`

**Example**:
```bash
# Excel export
GET /api/workflow/export/internal-report/10/1404?format=excel

# PDF export
GET /api/workflow/export/internal-report/10/1404?format=pdf
```

**Response**:
- Excel: `.xlsx` file download
- PDF: `.pdf` file download

### Export MinistrySummary

**GET** `/api/workflow/export/ministry-summary/:month/:year?format=excel|pdf`

**Parameters**:
- `month`: Month in Shamsi calendar (1-12)
- `year`: Year in Shamsi calendar (e.g., 1404)
- `format`: Export format - `excel` (default) or `pdf`

**Example**:
```bash
# Excel export
GET /api/workflow/export/ministry-summary/10/1404?format=excel

# PDF export
GET /api/workflow/export/ministry-summary/10/1404?format=pdf
```

**Response**:
- Excel: `.xlsx` file download
- PDF: `.pdf` file download

## Data Source

### Workflow Tables Only

All export data comes from workflow tables:
- **InternalReport**: Data from `internal_report` table
- **MinistrySummary**: Data from `ministry_summary` table
- **Totals**: Calculated from workflow tables or from database views
- **Alerts**: Retrieved from `workflow_alerts` table for highlighting

### No Master Table Access

- Exports **never** query the master `entities` table directly
- All entity information comes from `internal_report.entity_name` and `internal_report.entity_tin`
- Group information comes from `ministry_summary.group_name`
- This ensures exports are independent of master table structure

## Export Features

### Alert Highlighting

- Rows with active alerts are highlighted with light red background in Excel
- Helps identify underperforming entities and groups at a glance

### Totals Calculation

- **InternalReport**: Totals calculated from all active reports
- **MinistrySummary**: Totals calculated from all active summaries
- Totals include all numeric fields and counts

### Number Formatting

- All monetary values formatted with thousand separators
- Percentage values shown with 2 decimal places
- Proper RTL alignment for Persian numbers

### RTL Support

- Excel worksheets configured for Right-to-Left text direction
- PDF text aligned to the right
- Proper column ordering for Persian text

## Usage Examples

### Export InternalReport to Excel

```typescript
// In frontend
const response = await fetch('/api/workflow/export/internal-report/10/1404?format=excel', {
  headers: {
    'Authorization': `Bearer ${token}`
  }
});

const blob = await response.blob();
const url = window.URL.createObjectURL(blob);
const a = document.createElement('a');
a.href = url;
a.download = 'internal-report-10-1404.xlsx';
a.click();
```

### Export MinistrySummary to PDF

```typescript
// In frontend
const response = await fetch('/api/workflow/export/ministry-summary/10/1404?format=pdf', {
  headers: {
    'Authorization': `Bearer ${token}`
  }
});

const blob = await response.blob();
const url = window.URL.createObjectURL(blob);
const a = document.createElement('a');
a.href = url;
a.download = 'ministry-summary-10-1404.pdf';
a.click();
```

## File Naming

Exports are automatically named:
- **InternalReport Excel**: `internal-report-{month}-{year}.xlsx`
- **InternalReport PDF**: `internal-report-{month}-{year}.pdf`
- **MinistrySummary Excel**: `ministry-summary-{month}-{year}.xlsx`
- **MinistrySummary PDF**: `ministry-summary-{month}-{year}.pdf`

## Security

- All export endpoints require authentication
- All export endpoints require `reports:generate` permission
- All export operations are logged in audit logs
- IP addresses are tracked for audit purposes

## Performance Considerations

1. **Batch Processing**: Exports process all records in one operation
2. **Memory Efficient**: Excel/PDF generation uses streaming where possible
3. **Indexed Queries**: Database queries use indexes for fast retrieval
4. **Caching**: Consider caching exports for frequently accessed months

## Error Handling

- Invalid month/year: Returns 400 Bad Request
- No data found: Exports empty report with headers only
- Server errors: Returns 500 Internal Server Error with error message

## Notes

- All exports use data from workflow tables only
- Master entity table is never accessed or modified
- Exports include all flags, totals, and notes
- Alert highlighting helps identify issues quickly
- RTL formatting ensures proper display of Persian text
- Number formatting follows Persian/Afghan conventions

