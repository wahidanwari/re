# Workflow System Setup Commands

## Complete Setup Guide for All 7 Steps

This document provides all commands needed to set up the audit reporting workflow system.

---

## Prerequisites

1. **Database Connection**: Ensure `DATABASE_URL` is set in your `.env` file
2. **PostgreSQL**: Make sure PostgreSQL is running and accessible
3. **Node.js**: Ensure Node.js and npm are installed

---

## Step-by-Step Migration Commands

### Option 1: Run All Workflow Migrations at Once (Recommended)

**Using Node.js (Works on all platforms, recommended for Windows):**

```bash
# Make sure DATABASE_URL is set in .env file
npm run db:migrate-workflow
```

**Using psql directly (Linux/macOS or if psql is in PATH):**

```bash
# Windows PowerShell (if psql is in PATH)
$env:DATABASE_URL="postgresql://ard_app:123456@localhost:5432/ardapp"
psql $env:DATABASE_URL -f migrations/016_create_monthly_transactions_table.sql
psql $env:DATABASE_URL -f migrations/017_create_internal_report_table.sql
psql $env:DATABASE_URL -f migrations/018_create_ministry_summary_table.sql
psql $env:DATABASE_URL -f migrations/019_create_alerts_table.sql
psql $env:DATABASE_URL -f migrations/020_create_workflow_config_table.sql

# Linux/macOS
export DATABASE_URL="postgresql://user:password@localhost:5432/ardapp"
psql $DATABASE_URL -f migrations/016_create_monthly_transactions_table.sql
psql $DATABASE_URL -f migrations/017_create_internal_report_table.sql
psql $DATABASE_URL -f migrations/018_create_ministry_summary_table.sql
psql $DATABASE_URL -f migrations/019_create_alerts_table.sql
psql $DATABASE_URL -f migrations/020_create_workflow_config_table.sql
```

### Option 2: Run Individual Steps

#### Step 1: Create MonthlyTransactions Table

```bash
# Windows PowerShell
psql $env:DATABASE_URL -f migrations/016_create_monthly_transactions_table.sql

# Linux/macOS
psql $DATABASE_URL -f migrations/016_create_monthly_transactions_table.sql
```

#### Step 2: Create InternalReport Table

```bash
# Windows PowerShell
psql $env:DATABASE_URL -f migrations/017_create_internal_report_table.sql

# Linux/macOS
psql $DATABASE_URL -f migrations/017_create_internal_report_table.sql
```

#### Step 3: Create MinistrySummary Table

```bash
# Windows PowerShell
psql $env:DATABASE_URL -f migrations/018_create_ministry_summary_table.sql

# Linux/macOS
psql $DATABASE_URL -f migrations/018_create_ministry_summary_table.sql
```

#### Step 4: Link InternalReport to MinistrySummary

**Note**: Step 4 is implemented in code (no migration needed). The linking happens automatically when:
- InternalReport is populated/updated
- MinistrySummary is regenerated

#### Step 5: Create Alerts Table

```bash
# Windows PowerShell
psql $env:DATABASE_URL -f migrations/019_create_alerts_table.sql

# Linux/macOS
psql $DATABASE_URL -f migrations/019_create_alerts_table.sql
```

#### Step 6: Export System

**Note**: Step 6 (exports) is implemented in code (no migration needed). The export functions are available via API endpoints.

#### Step 7: Create WorkflowConfig Table

```bash
# Windows PowerShell
psql $env:DATABASE_URL -f migrations/020_create_workflow_config_table.sql

# Linux/macOS
psql $DATABASE_URL -f migrations/020_create_workflow_config_table.sql
```

---

## Complete Setup Script

### Windows PowerShell Script

Create a file `setup-workflow.ps1`:

```powershell
# Workflow System Setup Script for Windows
# Run this script to set up all workflow tables

$ErrorActionPreference = "Stop"

# Check if DATABASE_URL is set
if (-not $env:DATABASE_URL) {
    Write-Host "ERROR: DATABASE_URL environment variable is not set" -ForegroundColor Red
    Write-Host "Please set it first: `$env:DATABASE_URL='postgresql://user:password@localhost:5432/database_name'" -ForegroundColor Yellow
    exit 1
}

Write-Host "🚀 Starting Workflow System Setup..." -ForegroundColor Green
Write-Host ""

$migrations = @(
    "016_create_monthly_transactions_table.sql",
    "017_create_internal_report_table.sql",
    "018_create_ministry_summary_table.sql",
    "019_create_alerts_table.sql",
    "020_create_workflow_config_table.sql"
)

$successCount = 0
$errorCount = 0

foreach ($migration in $migrations) {
    $migrationPath = "migrations\$migration"
    
    if (Test-Path $migrationPath) {
        Write-Host "📦 Running $migration..." -ForegroundColor Cyan
        try {
            psql $env:DATABASE_URL -f $migrationPath
            if ($LASTEXITCODE -eq 0) {
                Write-Host "✓ $migration completed successfully" -ForegroundColor Green
                $successCount++
            } else {
                Write-Host "✗ $migration failed" -ForegroundColor Red
                $errorCount++
            }
        } catch {
            Write-Host "✗ Error running $migration : $_" -ForegroundColor Red
            $errorCount++
        }
    } else {
        Write-Host "⚠️  Migration file not found: $migrationPath" -ForegroundColor Yellow
        $errorCount++
    }
    Write-Host ""
}

Write-Host "─" * 60
Write-Host "Setup Summary:" -ForegroundColor Cyan
Write-Host "  ✓ Successful: $successCount" -ForegroundColor Green
Write-Host "  ✗ Failed: $errorCount" -ForegroundColor Red
Write-Host ""

if ($errorCount -eq 0) {
    Write-Host "🎉 All migrations completed successfully!" -ForegroundColor Green
    Write-Host ""
    Write-Host "Next steps:" -ForegroundColor Cyan
    Write-Host "  1. Verify tables: npm run verify-workflow-tables" -ForegroundColor White
    Write-Host "  2. Test workflow: POST /api/workflow/automate/10/1404" -ForegroundColor White
} else {
    Write-Host "⚠️  Some migrations failed. Please check the errors above." -ForegroundColor Yellow
    exit 1
}
```

Run with:
```powershell
.\setup-workflow.ps1
```

### Linux/macOS Bash Script

Create a file `setup-workflow.sh`:

```bash
#!/bin/bash
# Workflow System Setup Script for Linux/macOS
# Run this script to set up all workflow tables

set -e

# Check if DATABASE_URL is set
if [ -z "$DATABASE_URL" ]; then
    echo "ERROR: DATABASE_URL environment variable is not set"
    echo "Please set it first: export DATABASE_URL='postgresql://user:password@localhost:5432/database_name'"
    exit 1
fi

echo "🚀 Starting Workflow System Setup..."
echo ""

migrations=(
    "016_create_monthly_transactions_table.sql"
    "017_create_internal_report_table.sql"
    "018_create_ministry_summary_table.sql"
    "019_create_alerts_table.sql"
    "020_create_workflow_config_table.sql"
)

success_count=0
error_count=0

for migration in "${migrations[@]}"; do
    migration_path="migrations/$migration"
    
    if [ -f "$migration_path" ]; then
        echo "📦 Running $migration..."
        if psql "$DATABASE_URL" -f "$migration_path"; then
            echo "✓ $migration completed successfully"
            ((success_count++))
        else
            echo "✗ $migration failed"
            ((error_count++))
        fi
    else
        echo "⚠️  Migration file not found: $migration_path"
        ((error_count++))
    fi
    echo ""
done

echo "────────────────────────────────────────────────────────────"
echo "Setup Summary:"
echo "  ✓ Successful: $success_count"
echo "  ✗ Failed: $error_count"
echo ""

if [ $error_count -eq 0 ]; then
    echo "🎉 All migrations completed successfully!"
    echo ""
    echo "Next steps:"
    echo "  1. Verify tables: npm run verify-workflow-tables"
    echo "  2. Test workflow: POST /api/workflow/automate/10/1404"
else
    echo "⚠️  Some migrations failed. Please check the errors above."
    exit 1
fi
```

Make it executable and run:
```bash
chmod +x setup-workflow.sh
./setup-workflow.sh
```

---

## Verification Commands

### Verify All Tables Were Created

```bash
# Windows PowerShell
psql $env:DATABASE_URL -c "\dt monthly_transactions"
psql $env:DATABASE_URL -c "\dt internal_report"
psql $env:DATABASE_URL -c "\dt ministry_summary"
psql $env:DATABASE_URL -c "\dt workflow_alerts"
psql $env:DATABASE_URL -c "\dt workflow_config"

# Linux/macOS
psql $DATABASE_URL -c "\dt monthly_transactions"
psql $DATABASE_URL -c "\dt internal_report"
psql $DATABASE_URL -c "\dt ministry_summary"
psql $DATABASE_URL -c "\dt workflow_alerts"
psql $DATABASE_URL -c "\dt workflow_config"
```

### Verify Views Were Created

```bash
# Windows PowerShell
psql $env:DATABASE_URL -c "\dv internal_report_monthly_totals"
psql $env:DATABASE_URL -c "\dv ministry_summary_monthly_totals"

# Linux/macOS
psql $DATABASE_URL -c "\dv internal_report_monthly_totals"
psql $DATABASE_URL -c "\dv ministry_summary_monthly_totals"
```

### Check Table Structures

```bash
# Windows PowerShell
psql $env:DATABASE_URL -c "\d monthly_transactions"
psql $env:DATABASE_URL -c "\d internal_report"
psql $env:DATABASE_URL -c "\d ministry_summary"
psql $env:DATABASE_URL -c "\d workflow_alerts"
psql $env:DATABASE_URL -c "\d workflow_config"

# Linux/macOS
psql $DATABASE_URL -c "\d monthly_transactions"
psql $DATABASE_URL -c "\d internal_report"
psql $DATABASE_URL -c "\d ministry_summary"
psql $DATABASE_URL -c "\d workflow_alerts"
psql $DATABASE_URL -c "\d workflow_config"
```

---

## Quick Setup (One Command)

### Using psql with Multiple Files

```bash
# Windows PowerShell
$migrations = @(
    "migrations/016_create_monthly_transactions_table.sql",
    "migrations/017_create_internal_report_table.sql",
    "migrations/018_create_ministry_summary_table.sql",
    "migrations/019_create_alerts_table.sql",
    "migrations/020_create_workflow_config_table.sql"
)
foreach ($migration in $migrations) { psql $env:DATABASE_URL -f $migration }

# Linux/macOS
for migration in migrations/016*.sql migrations/017*.sql migrations/018*.sql migrations/019*.sql migrations/020*.sql; do
    psql $DATABASE_URL -f "$migration"
done
```

---

## Using Node.js Script (Recommended for Windows)

**This is the recommended method for Windows users** since `psql` may not be in PATH.

```bash
# Run all workflow migrations using Node.js
npm run db:migrate-workflow
```

This script:
- ✅ Works on Windows, Linux, and macOS
- ✅ Doesn't require `psql` to be in PATH
- ✅ Provides better error messages
- ✅ Handles "already exists" errors gracefully
- ✅ Shows progress and summary

The script is located at `server/scripts/migrate-workflow.ts` and uses the `pg` library to execute SQL directly.

---

## Post-Migration Steps

### 1. Verify Schema Sync

```bash
# Push schema changes to database (if using Drizzle)
npm run db:push
```

### 2. Test API Endpoints

```bash
# Start the server
npm run dev

# Test workflow automation
curl -X POST http://localhost:3000/api/workflow/automate/10/1404 \
  -H "Content-Type: application/json" \
  -H "Cookie: audit.sid=YOUR_SESSION_ID" \
  -d '{
    "appendMode": true,
    "regenerateReports": true,
    "regenerateSummaries": true,
    "generateAlerts": true
  }'
```

### 3. Verify Data Flow

1. Check that entities are pulled from master table
2. Verify MonthlyTransactions are created
3. Confirm InternalReport is generated
4. Check MinistrySummary is created
5. Verify alerts are generated

---

## Troubleshooting

### Migration Fails with "relation already exists"

If a table already exists, you can either:
1. Drop and recreate (⚠️ **WARNING**: This will delete data):
   ```sql
   DROP TABLE IF EXISTS monthly_transactions CASCADE;
   -- Then re-run migration
   ```

2. Skip the migration if the table structure is correct

### Migration Fails with Permission Error

Ensure your database user has proper permissions:
```sql
GRANT ALL PRIVILEGES ON DATABASE your_database TO your_user;
GRANT ALL ON SCHEMA public TO your_user;
```

### Check Migration Status

```sql
-- Check if tables exist
SELECT table_name 
FROM information_schema.tables 
WHERE table_schema = 'public' 
AND table_name IN (
    'monthly_transactions',
    'internal_report',
    'ministry_summary',
    'workflow_alerts',
    'workflow_config'
);
```

---

## Summary of All Commands

### Complete Setup (All Steps)

```bash
# Set DATABASE_URL first
export DATABASE_URL="postgresql://user:password@localhost:5432/database_name"

# Run all migrations
psql $DATABASE_URL -f migrations/016_create_monthly_transactions_table.sql
psql $DATABASE_URL -f migrations/017_create_internal_report_table.sql
psql $DATABASE_URL -f migrations/018_create_ministry_summary_table.sql
psql $DATABASE_URL -f migrations/019_create_alerts_table.sql
psql $DATABASE_URL -f migrations/020_create_workflow_config_table.sql

# Verify
psql $DATABASE_URL -c "\dt monthly_transactions"
psql $DATABASE_URL -c "\dt internal_report"
psql $DATABASE_URL -c "\dt ministry_summary"
psql $DATABASE_URL -c "\dt workflow_alerts"
psql $DATABASE_URL -c "\dt workflow_config"
```

### Individual Step Commands

- **Step 1**: `psql $DATABASE_URL -f migrations/016_create_monthly_transactions_table.sql`
- **Step 2**: `psql $DATABASE_URL -f migrations/017_create_internal_report_table.sql`
- **Step 3**: `psql $DATABASE_URL -f migrations/018_create_ministry_summary_table.sql`
- **Step 4**: No migration (code implementation)
- **Step 5**: `psql $DATABASE_URL -f migrations/019_create_alerts_table.sql`
- **Step 6**: No migration (code implementation)
- **Step 7**: `psql $DATABASE_URL -f migrations/020_create_workflow_config_table.sql`

---

## Notes

- All migrations are idempotent (safe to run multiple times)
- Migrations check if tables/views exist before creating
- Master `entities` table is never modified
- All workflow tables are separate from master data
- Views are automatically created with tables

---

## Support

If you encounter issues:
1. Check database connection: `psql $DATABASE_URL -c "SELECT 1;"`
2. Verify migration files exist in `migrations/` directory
3. Check PostgreSQL logs for detailed error messages
4. Ensure all prerequisites are met

