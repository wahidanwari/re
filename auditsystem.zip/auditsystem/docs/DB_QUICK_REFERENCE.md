# Database Management - Quick Reference

## 🚀 Quick Commands

```bash
# Fresh database rebuild (drops everything)
npm run db:rebuild

# Reset all data and re-seed (keeps schema)
npm run db:reset

# Seed default data only
npm run db:seed
```

## ⚠️ Safety

- **Production Protection:** All scripts check `NODE_ENV` and refuse to run in production
- **Environment Required:** Set `NODE_ENV=development` or `NODE_ENV=test`

## 📋 Default Users

| Username | Password | Role |
|----------|----------|------|
| `admin001` | `Admin@2024!` | System Admin |
| `auditor001` | `Auditor@2024!` | Auditor |
| `senior001` | `Senior@2024!` | Senior Auditor |

## 🔧 When to Use What

- **`db:rebuild`** → Fresh start, schema changes, corruption
- **`db:reset`** → Clean data during development
- **`db:seed`** → Add default data after rebuild

## 📚 Full Documentation

See `docs/DATABASE_WORKFLOW.md` for complete guide.

