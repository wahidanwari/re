# Monthly Transactions Table Structure

## Overview

The `monthly_transactions` table is a **workflow table** designed to store per-entity monthly audit data without modifying the master entity table. This table is part of the audit reporting workflow and serves as the foundation for generating internal reports and ministry-level summaries.

## Key Design Principles

1. **Read-Only Master Entity Link**: This table links to the master `entities` table via EntityTIN ( نمبر تشخیصیه) but **never modifies** the master table.
2. **Temporary Workflow Data**: All calculations, aggregations, and reporting data are stored in this workflow table.
3. **TIN as Unique Identifier**: Uses EntityTIN ( نمبر تشخیصیه) as the primary linking mechanism to entities.
4. **No Master Table Modification**: DO NOT modify or overwrite any data in the master entity table.

## Table Structure

### Primary Key & Entity Link

- **`id`** (TransactionID): Primary key - Workflow-generated unique ID (UUID)
- **`entity_tin`** (EntityTIN):  نمبر تشخیصیه - Links to `entities.tin` (NOT a foreign key constraint to maintain workflow independence)
- **`month_shamsi`** (Month): برج - Month in Shamsi calendar (1-12)
- **`year_shamsi`** (Year): سال - Year in Shamsi calendar (e.g., 1404)
- **Unique Constraint**: `(entity_tin, month_shamsi, year_shamsi)` - One record per entity per month/year

### Tax Fields (مالیات‌ها)

Stores tax information for the entity:

- **`tax_salary`** (TaxSalary): مالیه موضوعی معاشات - Salary tax (NUMERIC 15,2)
- **`tax_rent`** (TaxRent): مالیه موضوعی بر کرایه - Rent tax (NUMERIC 15,2)
- **`tax_contract`** (TaxContract): مالیه موضوعی قراردادی - Contract tax (NUMERIC 15,2)
- **`tax_profit`** (TaxProfit): مالیه موضوعی معاملات انتفاعی - Profit transaction tax (NUMERIC 15,2)
- **`income_tax`** (IncomeTax): مالیات بر عایدات - Income tax (NUMERIC 15,2)

### Financial Amounts (مبالغ مالی)

Tracks financial status and collection:

- **`loss_reduction`** (LossReduction): ضرر کاهش یافته - Reduced loss (NUMERIC 15,2)
- **`collected_amount`** (CollectedAmount): مبلغ تحصیل شده طی برج جاری - Amount collected in current month (NUMERIC 15,2)
- **`remaining_amount`** (RemainingAmount): الباقی مبلغ قابل تحصیل - Remaining collectible amount (NUMERIC 15,2)
- **`stabilized_amount`** (StabilizedAmount): مبلغ تثبیت شده - Confirmed/established amount (NUMERIC 15,2)

### Correspondence Data (مکاتبات)

Tracks incoming and outgoing correspondence:

- **`correspondences_in`** (CorrespondencesIn): تعداد مکتوب های وارده - Number of letters received (INTEGER)
- **`correspondences_out`** (CorrespondencesOut): تعداد مکتوب های صادره - Number of letters sent (INTEGER)

### Inquiry Data (استعلامات)

Tracks inquiries:

- **`inquiries_in`** (InquiriesIn): تعداد استعلام های وارده - Number of inquiries received (INTEGER)
- **`inquiries_out`** (InquiriesOut): تعداد استعلام های صادره - Number of inquiries sent (INTEGER)

### Additional Fields

- **`notes`** (Notes): ملاحظات - General notes (TEXT)
- **`created_at`**: Timestamp of creation
- **`updated_at`**: Timestamp of last update

## Indexes

The table includes the following indexes for performance:

1. **`idx_monthly_transactions_entity_tin`**: Index on `entity_tin` for fast entity lookups
2. **`idx_monthly_transactions_month_year`**: Composite index on `(year_shamsi, month_shamsi)` for time-based queries
3. **`idx_monthly_transactions_updated`**: Index on `updated_at DESC` for recent updates

## Usage in Workflow

1. **Data Collection**: Monthly transaction data is collected and stored per entity (identified by TIN).
2. **Internal Reports**: Data from this table is aggregated to generate per-entity internal reports.
3. **Ministry Summaries**: Data is further aggregated by group (گروه ارجاع‌دهنده) to create ministry-level summaries.
4. **Automatic Updates**: When transaction data is updated, internal reports and ministry summaries are automatically recalculated.

## Data Population

The table can be populated through:

1. **Manual Entry**: Users can manually enter monthly transaction data
2. **Case Report Integration**: Data can be extracted from completed case reports
3. **Automatic Calculation**: Some fields can be calculated from related tables (cases, documents, etc.)

## Relationship to Master Entities Table

- **Read-Only Link**: The table references `entities.tin` via `entity_tin` but does NOT have a foreign key constraint
- **Independence**: This ensures the workflow table remains independent and can be rebuilt if needed
- **Data Integrity**: EntityTIN values should match existing entities, but the workflow table can exist independently
- **No Modification**: This table NEVER modifies or overwrites data in the master `entities` table

## Next Steps

After creating this table, the workflow will include:

1. **InternalReport Table**: Aggregated per-entity monthly reports
2. **MinistrySummary Table**: Aggregated per-group monthly summaries
3. **Service Functions**: Functions to populate, update, and recalculate workflow tables
4. **API Endpoints**: REST endpoints for accessing and managing workflow data
5. **Export Functionality**: Excel/PDF export for reports and summaries

