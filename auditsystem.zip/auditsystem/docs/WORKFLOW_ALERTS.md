# Workflow Alerts System

## Overview

The workflow alerts system automatically flags entities and groups that are underperforming based on configurable thresholds. Alerts are stored in a temporary `workflow_alerts` table and can be used for dashboard highlighting and notifications.

## Alert Types

### 1. Entity Remaining Amount Alert

**Type**: `entity_remaining_amount`

**Condition**: Flags entities where `RemainingAmount > Threshold` (percentage of TotalTaxableAmount)

**Default Threshold**: 30% (configurable via `ALERT_CONFIG.ENTITY_REMAINING_THRESHOLD`)

**Severity Levels**:
- **Critical**: RemainingAmount ≥ 90% of TotalTaxableAmount
- **High**: RemainingAmount ≥ 70% of TotalTaxableAmount
- **Medium**: RemainingAmount ≥ 50% of TotalTaxableAmount
- **Low**: RemainingAmount > 30% of TotalTaxableAmount

**Example Alert Message**:
```
نهاد شرکت نمونه (123456789) دارای مبلغ باقیمانده بالا است: 150,000 از 200,000 (75.0%)
```

### 2. Group Revenue Target Alert

**Type**: `group_revenue_target`

**Condition**: Flags groups where `RevenueCollected < MonthlyRevenueTarget * threshold`

**Default Threshold**: 80% (configurable via `ALERT_CONFIG.GROUP_REVENUE_THRESHOLD`)

**Severity Levels**:
- **Critical**: Achievement < 50% of target
- **High**: Achievement < 65% of target
- **Medium**: Achievement < 80% of target
- **Low**: Achievement < 80% of target (but close)

**Example Alert Message**:
```
گروه اول سنجش ابتدایی درآمد کمتر از هدف دارد: 2,400,000 از 3,000,000 (80.0%)
```

## Alert Table Structure

### Fields

- **`id`** (AlertID): Primary key - Workflow-generated unique ID
- **`entity_tin`** (EntityTIN):  نمبر تشخیصیه - NULL if group alert
- **`group_name`** (GroupName): نام گروه - NULL if entity alert
- **`alert_type`** (AlertType): Type of alert (`entity_remaining_amount`, `group_revenue_target`)
- **`message`** (Message): Human-readable alert message
- **`month_shamsi`** (Month): برج (1-12)
- **`year_shamsi`** (Year): سال (Shamsi year)
- **`severity`**: Alert severity (`low`, `medium`, `high`, `critical`)
- **`status`**: Alert status (`active`, `acknowledged`, `resolved`, `dismissed`)
- **`details`**: JSONB field with additional alert data (threshold, actual value, target value, etc.)
- **`acknowledged_by`**: User who acknowledged the alert
- **`acknowledged_at`**: Timestamp when alert was acknowledged
- **`resolved_at`**: Timestamp when alert was resolved
- **`created_at`**: Timestamp when alert was created
- **`updated_at`**: Timestamp when alert was last updated

## Automatic Alert Generation

### When Alerts are Generated

Alerts are automatically generated when:

1. **InternalReport is updated**: After `populateInternalReport()` creates or updates reports, it automatically calls `generateAlerts()`
2. **Workflow is recalculated**: When `recalculateWorkflow()` is called, alerts are regenerated
3. **Manual generation**: Alerts can be manually generated via API endpoint

### Alert Generation Process

1. **Entity Alerts**:
   - Get all active InternalReport records for the month/year
   - For each report, calculate `RemainingAmount / TotalTaxableAmount`
   - If percentage > threshold, create alert with appropriate severity
   - Delete existing entity alerts for the month/year before creating new ones

2. **Group Alerts**:
   - Get all active MinistrySummary records for the month/year
   - For each summary, calculate `RevenueCollected / MonthlyRevenueTarget`
   - If percentage < threshold, create alert with appropriate severity
   - Delete existing group alerts for the month/year before creating new ones

## Configuration

### Alert Thresholds

```typescript
export const ALERT_CONFIG = {
  // Entity Remaining Amount Threshold (percentage of TotalTaxableAmount)
  ENTITY_REMAINING_THRESHOLD: 0.3, // 30%
  
  // Group Revenue Target Threshold (percentage)
  GROUP_REVENUE_THRESHOLD: 0.8, // 80%
};
```

### Customizing Thresholds

You can customize thresholds when calling alert generation functions:

```typescript
// Generate entity alerts with custom threshold (40%)
await generateEntityAlerts(10, 1404, 0.4);

// Generate group alerts with custom threshold (75%)
await generateGroupAlerts(10, 1404, 0.75);
```

## API Endpoints

### Get Alerts

**GET** `/api/workflow/alerts/:month/:year`
- Get all alerts for a specific month/year
- Optional query parameter: `status` (active, acknowledged, resolved, dismissed)

**Example**:
```bash
GET /api/workflow/alerts/10/1404?status=active
```

### Get Entity Alerts

**GET** `/api/workflow/alerts/entity/:entityTin`
- Get alerts for a specific entity
- Optional query parameters: `month`, `year`

**Example**:
```bash
GET /api/workflow/alerts/entity/123456789?month=10&year=1404
```

### Get Group Alerts

**GET** `/api/workflow/alerts/group/:groupName`
- Get alerts for a specific group
- Optional query parameters: `month`, `year`

**Example**:
```bash
GET /api/workflow/alerts/group/گروه اول سنجش ابتدایی?month=10&year=1404
```

### Generate Alerts

**POST** `/api/workflow/alerts/generate/:month/:year`
- Manually generate alerts for a specific month/year

**Example**:
```bash
POST /api/workflow/alerts/generate/10/1404
```

**Response**:
```json
{
  "message": "Alerts generated successfully",
  "result": {
    "entityAlerts": 15,
    "groupAlerts": 3
  }
}
```

### Acknowledge Alert

**POST** `/api/workflow/alerts/:alertId/acknowledge`
- Mark an alert as acknowledged

**Example**:
```bash
POST /api/workflow/alerts/abc123/acknowledge
```

### Resolve Alert

**POST** `/api/workflow/alerts/:alertId/resolve`
- Mark an alert as resolved

**Example**:
```bash
POST /api/workflow/alerts/abc123/resolve
```

## Service Functions

### Generate Alerts

```typescript
// Generate all alerts
await generateAlerts(monthShamsi, yearShamsi);

// Generate entity alerts only
await generateEntityAlerts(monthShamsi, yearShamsi, threshold);

// Generate group alerts only
await generateGroupAlerts(monthShamsi, yearShamsi, threshold);
```

### Get Alerts

```typescript
// Get all alerts for a month/year
const alerts = await getAlerts(monthShamsi, yearShamsi, 'active');

// Get alerts for an entity
const entityAlerts = await getEntityAlerts(entityTin, monthShamsi, yearShamsi);

// Get alerts for a group
const groupAlerts = await getGroupAlerts(groupName, monthShamsi, yearShamsi);
```

### Manage Alerts

```typescript
// Acknowledge an alert
await acknowledgeAlert(alertId, userId);

// Resolve an alert
await resolveAlert(alertId);
```

## Alert Details Structure

The `details` JSONB field contains additional information:

### Entity Alert Details

```json
{
  "entityName": "شرکت نمونه",
  "remainingAmount": 150000,
  "totalTaxableAmount": 200000,
  "remainingPercentage": 75.0,
  "threshold": 30.0
}
```

### Group Alert Details

```json
{
  "revenueCollected": 2400000,
  "monthlyRevenueTarget": 3000000,
  "achievementPercentage": 80.0,
  "threshold": 80.0,
  "totalEntities": 25
}
```

## Alert Status Workflow

```
active → acknowledged → resolved
   ↓
dismissed
```

- **active**: Alert is active and needs attention
- **acknowledged**: Alert has been reviewed but not yet resolved
- **resolved**: Issue has been addressed
- **dismissed**: Alert has been dismissed (not implemented yet)

## Dashboard Integration

### Highlighting Entities

Use entity alerts to highlight entities in InternalReport views:

```typescript
const alerts = await getEntityAlerts(entityTin, monthShamsi, yearShamsi);
const hasActiveAlert = alerts.some(a => a.status === 'active' && a.severity === 'critical');
```

### Highlighting Groups

Use group alerts to highlight groups in MinistrySummary views:

```typescript
const alerts = await getGroupAlerts(groupName, monthShamsi, yearShamsi);
const hasActiveAlert = alerts.some(a => a.status === 'active');
```

### Notification System

Alerts can be used to generate notifications:

```typescript
// Get all critical active alerts
const criticalAlerts = await getAlerts(monthShamsi, yearShamsi, 'active')
  .then(alerts => alerts.filter(a => a.severity === 'critical'));

// Send notifications for critical alerts
for (const alert of criticalAlerts) {
  await sendNotification(alert);
}
```

## Best Practices

1. **Regular Alert Generation**: Generate alerts after each workflow update
2. **Alert Acknowledgment**: Encourage users to acknowledge alerts they've reviewed
3. **Alert Resolution**: Resolve alerts when underlying issues are fixed
4. **Threshold Tuning**: Adjust thresholds based on historical data and business requirements
5. **Dashboard Display**: Show alert counts and severity in dashboard widgets

## Performance Considerations

1. **Indexes**: Alerts table has indexes on `entity_tin`, `group_name`, `month_shamsi`/`year_shamsi`, `status`, and `severity`
2. **Batch Processing**: Alert generation processes all entities/groups in one batch
3. **Cleanup**: Old alerts are automatically replaced when regenerating for a month/year
4. **Filtering**: Use status and severity filters to reduce query load

## Migration

The alerts table is created via migration `019_create_alerts_table.sql`. Run this migration to enable the alerts system.

## Notes

- Alerts are stored in a temporary workflow table (not master data)
- Alert generation is automatic but can be manually triggered
- Alerts are regenerated each time the workflow is updated
- Alert details are stored in JSONB for flexibility
- All alert operations are logged in audit logs

