# Workflow Linking: InternalReport to MinistrySummary

## Overview

The workflow system automatically links `InternalReport` to `MinistrySummary` through the master `entities` table. This ensures that any updates in `InternalReport` automatically reflect in `MinistrySummary` without modifying any master entity table data.

## Linking Mechanism

### Data Flow

```
InternalReport (entity_tin)
    ↓
EntitiesMaster (tin → referral_group)
    ↓
MinistrySummary (group_name)
```

### Step-by-Step Process

1. **InternalReport contains `entity_tin`** ( نمبر تشخیصیه)
2. **Lookup in EntitiesMaster** using `entity_tin` to get `referral_group` (گروه ارجاع‌دهنده)
3. **Resolve Group Name**:
   - If `referral_group` is a group ID, lookup in `groups` table to get `group.name`
   - If `referral_group` is a group name, use it directly
   - If group doesn't exist in `groups` table, treat as static group name
4. **Aggregate by Group Name** in `MinistrySummary`

## Automatic Updates

### When InternalReport is Updated

When `populateInternalReport()` is called and creates or updates InternalReport records, it automatically triggers `populateMinistrySummary()` to update all affected MinistrySummary records.

### Function: `updateMinistrySummaryForGroup()`

This function updates MinistrySummary for a specific group when InternalReport changes:

```typescript
updateMinistrySummaryForGroup(
  groupName: string,
  monthShamsi: number,
  yearShamsi: number
): Promise<MinistrySummary | null>
```

**Process:**
1. Gets all active InternalReport records for the month/year
2. Filters reports belonging to the specified group (via TIN → EntitiesMaster → referral_group)
3. Recalculates all aggregated metrics:
   - Entity counts (TotalEntities, FinalizedEntities, etc.)
   - RevenueCollected
   - PercentVariation
   - Correspondence and inquiry totals
4. Updates or creates the MinistrySummary record

### Automatic Trigger in `populateInternalReport()`

```typescript
// After creating/updating InternalReport records
if (created > 0 || updated > 0) {
  await populateMinistrySummary(monthShamsi, yearShamsi);
}
```

This ensures that:
- When new InternalReport records are created, MinistrySummary is updated
- When existing InternalReport records are updated, MinistrySummary is recalculated
- All groups are updated, not just the affected group (for data consistency)

## Group Resolution Logic

### 1. Get Entity from TIN

```typescript
const entity = await storage.getEntityByTin(report.entityTin);
```

### 2. Get Referral Group

```typescript
const referralGroup = entity.referralGroup; // گروه ارجاع‌دهنده
```

### 3. Resolve Group Name

```typescript
// Try as group ID first
const groupById = await storage.getGroup(referralGroup);
if (groupById) {
  groupName = groupById.name;
  groupId = groupById.id;
  groupCode = groupById.code;
} else {
  // Try as group name
  const groupByName = await storage.getGroupByName(referralGroup);
  if (groupByName) {
    groupName = groupByName.name;
    groupId = groupByName.id;
    groupCode = groupByName.code;
  } else {
    // Static group (not in groups table)
    groupName = referralGroup;
    groupId = null;
    groupCode = null;
  }
}
```

## Aggregation Logic

### Entity Counts

For each group, count entities by compliance status:

```typescript
for (const report of groupReports) {
  const remainingAmount = parseFloat(report.remainingAmount || '0');
  const totalTaxableAmount = parseFloat(report.totalTaxableAmount || '0');
  
  if (remainingAmount === 0) {
    finalizedEntities++;
  } else if (remainingAmount > 0 && remainingAmount < totalTaxableAmount) {
    partiallyCompliantEntities++;
  } else if (remainingAmount === totalTaxableAmount) {
    nonCompliantEntities++;
  }
}
```

### Revenue Metrics

```typescript
// Sum of CollectedAmount
revenueCollected = groupReports.reduce((sum, r) => 
  sum + parseFloat(r.collectedAmount || '0'), 0
);

// Get from group_targets
monthlyRevenueTarget = (yearlyTarget / 12);

// Calculate variation
percentVariation = (revenueCollected / monthlyRevenueTarget) * 100;
```

### Correspondence & Inquiries

```typescript
incomingLetters = groupReports.reduce((sum, r) => sum + (r.correspondencesIn || 0), 0);
outgoingLetters = groupReports.reduce((sum, r) => sum + (r.correspondencesOut || 0), 0);
incomingInquiries = groupReports.reduce((sum, r) => sum + (r.inquiriesIn || 0), 0);
outgoingInquiries = groupReports.reduce((sum, r) => sum + (r.inquiriesOut || 0), 0);
```

## Data Consistency

### Master Table Protection

- **No modifications** to `entities` table
- **Read-only access** to `entities.tin` and `entities.referral_group`
- **No foreign key constraints** between workflow tables and master tables

### Update Guarantees

1. **Automatic Updates**: InternalReport changes automatically trigger MinistrySummary updates
2. **Full Recalculation**: `populateMinistrySummary()` recalculates all groups for the month/year
3. **Group-Specific Updates**: `updateMinistrySummaryForGroup()` updates a single group efficiently

## Usage Examples

### Example 1: Update InternalReport (Automatic MinistrySummary Update)

```typescript
// Update InternalReport for an entity
await populateInternalReport(10, 1404);

// This automatically calls:
// await populateMinistrySummary(10, 1404);
```

### Example 2: Update Specific Group

```typescript
// Update MinistrySummary for a specific group
await updateMinistrySummaryForGroup(
  'گروه اول سنجش ابتدایی',
  10,
  1404
);
```

### Example 3: Manual Recalculation

```typescript
// Recalculate entire workflow
await recalculateWorkflow(10, 1404);

// This:
// 1. Populates MonthlyTransactions
// 2. Populates InternalReport (triggers MinistrySummary update)
// 3. Populates MinistrySummary (if not already done)
```

## API Endpoints

### Automatic Updates

When you update InternalReport via:
- `POST /api/workflow/populate/:month/:year` - Automatically updates MinistrySummary
- `POST /api/workflow/recalculate/:month/:year` - Full workflow recalculation

### Manual Group Update

You can manually trigger a group update by calling `populateMinistrySummary()` which will update all groups, or use the internal `updateMinistrySummaryForGroup()` function for a specific group.

## Error Handling

### Missing Entity

If an entity is not found for a TIN:
```typescript
if (!entity || !entity.referralGroup) {
  console.warn(`Entity not found or no referral group for TIN: ${report.entityTin}`);
  continue; // Skip this report
}
```

### Missing Group Target

If monthly revenue target is not set:
```typescript
if (!monthlyRevenueTarget || monthlyRevenueTarget === 0) {
  percentVariation = null; // Cannot calculate without target
}
```

## Performance Considerations

1. **Batch Processing**: `populateMinistrySummary()` processes all groups in one call
2. **Group-Specific Updates**: `updateMinistrySummaryForGroup()` is more efficient for single group updates
3. **Caching**: Group lookups are cached during batch processing
4. **Indexes**: Database indexes on `entity_tin`, `group_name`, and `month_shamsi`/`year_shamsi` optimize queries

## Testing

To test the linking:

1. **Create InternalReport**:
   ```bash
   POST /api/workflow/populate/10/1404
   ```

2. **Verify MinistrySummary**:
   ```bash
   GET /api/workflow/ministry-summaries/10/1404
   ```

3. **Update InternalReport**:
   ```bash
   POST /api/workflow/monthly-transactions
   {
     "entityTin": "123456789",
     "monthShamsi": 10,
     "yearShamsi": 1404,
     "collectedAmount": "150000"
   }
   ```

4. **Verify MinistrySummary Updated**:
   ```bash
   GET /api/workflow/ministry-summary/گروه اول سنجش ابتدایی/10/1404
   ```

## Notes

- All linking is done via TIN ( نمبر تشخیصیه) - no direct foreign keys
- Master entity table is never modified
- Group names are resolved dynamically (supports both group IDs and names)
- Static groups (not in `groups` table) are supported
- Updates are transactional and logged for audit purposes

