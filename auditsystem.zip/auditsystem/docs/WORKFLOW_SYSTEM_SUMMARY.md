# Audit Reporting Workflow System - Complete Summary

## Overview

The audit reporting workflow system provides a complete solution for collecting, aggregating, and reporting monthly audit data without modifying the master entity table. The system consists of three workflow tables that progressively aggregate data from entity-level transactions to group-level summaries.

## Architecture

### Data Flow

```
Master Entities Table (Read-Only)
    ↓
MonthlyTransactions (Per-Entity Monthly Data)
    ↓
InternalReport (Aggregated Per-Entity Reports)
    ↓ (via TIN → EntitiesMaster → GroupName)
MinistrySummary (Aggregated Per-Group Summaries)
```

### Automatic Updates

- **InternalReport → MinistrySummary**: Updates to InternalReport automatically trigger MinistrySummary recalculation
- **MonthlyTransactions → InternalReport**: Updates to MonthlyTransactions automatically trigger InternalReport recalculation
- **Cascading Updates**: Changes propagate through the entire workflow automatically

### Key Principles

1. **Read-Only Master Table**: All workflow tables link to the master `entities` table via TIN ( نمبر تشخیصیه) but never modify it
2. **Temporary Workflow Tables**: All calculations and aggregations are stored in temporary workflow tables
3. **Automatic Calculations**: Totals and remaining amounts are automatically calculated
4. **Cascading Updates**: Updates to transactions automatically trigger recalculation of reports and summaries

## Tables

### 1. MonthlyTransactions

**Purpose**: Store per-entity monthly transaction data

**Key Fields**:
- `entity_tin` - Links to master entities table
- `month_shamsi`, `year_shamsi` - Time period
- Tax fields: `tax_salary`, `tax_rent`, `tax_contract`, `tax_profit`, `income_tax`
- Financial amounts: `collected_amount`, `remaining_amount`, `stabilized_amount`, `loss_reduction`
- Correspondence: `correspondences_in`, `correspondences_out`
- Inquiries: `inquiries_in`, `inquiries_out`

**Unique Constraint**: `(entity_tin, month_shamsi, year_shamsi)`

### 2. InternalReport

**Purpose**: Aggregate per-entity monthly data for internal reporting

**Key Fields**:
- `entity_tin`, `entity_name` - Entity identification
- `total_taxable_amount` - Calculated: Sum of all tax types
- `remaining_amount` - Calculated: `TotalTaxableAmount - CollectedAmount`
- All tax breakdown fields
- Status: `active` or `inactive`

**Calculations**:
- `TotalTaxableAmount = TaxSalary + TaxRent + TaxContract + TaxProfit + IncomeTax`
- `RemainingAmount = TotalTaxableAmount - CollectedAmount`

**View**: `internal_report_monthly_totals` - Provides monthly totals across all entities

### 3. MinistrySummary

**Purpose**: Aggregate per-group monthly summaries for ministry reporting

**Key Fields**:
- `group_id`, `group_name`, `group_code` - Group identification
- `entity_count` - Number of entities in the group
- Aggregated totals: `total_taxable_amount`, `total_collected`, `total_stabilized`, `total_remaining`
- Tax breakdown totals
- Performance indicators: `average_collection_rate`, `completion_rate`

**View**: `ministry_summary_monthly_totals` - Provides ministry-level totals across all groups

## Service Functions

### WorkflowService (`server/services/workflowService.ts`)

#### Core Functions

1. **`populateMonthlyTransactions(monthShamsi, yearShamsi)`**
   - Creates transaction records for all entities in master table
   - Returns: `{ created, updated }`

2. **`updateMonthlyTransaction(entityTin, monthShamsi, yearShamsi, data)`**
   - Updates or creates a monthly transaction record
   - Automatically triggers InternalReport recalculation

3. **`populateInternalReport(monthShamsi, yearShamsi)`**
   - Calculates and populates internal reports from monthly transactions
   - Calculates `TotalTaxableAmount` and `RemainingAmount`
   - Returns: `{ created, updated }`

4. **`populateMinistrySummary(monthShamsi, yearShamsi)`**
   - Aggregates internal reports by referral group
   - Calculates group-level totals and performance indicators
   - Returns: `{ created, updated }`

5. **`recalculateWorkflow(monthShamsi, yearShamsi)`**
   - Recalculates all workflow tables in sequence
   - Ensures data consistency
   - Returns: Complete result with all counts

#### Getter Functions

- `getMonthlyTransaction(entityTin, monthShamsi, yearShamsi)`
- `getInternalReport(entityTin, monthShamsi, yearShamsi)`
- `getMinistrySummary(groupName, monthShamsi, yearShamsi)`
- `getInternalReportsForMonth(monthShamsi, yearShamsi)`
- `getMinistrySummariesForMonth(monthShamsi, yearShamsi)`

## API Endpoints

### Base Path: `/api/workflow`

All endpoints require authentication and `reports:generate` permission.

#### Monthly Transactions

- **GET** `/monthly-transactions/:entityTin/:month/:year`
  - Get monthly transaction for a specific entity

- **POST** `/monthly-transactions`
  - Create or update a monthly transaction
  - Body: `{ entityTin, monthShamsi, yearShamsi, ...data }`
  - Automatically recalculates InternalReport

#### Internal Reports

- **GET** `/internal-report/:entityTin/:month/:year`
  - Get internal report for a specific entity

- **GET** `/internal-reports/:month/:year`
  - Get all internal reports for a month/year

#### Ministry Summaries

- **GET** `/ministry-summary/:groupName/:month/:year`
  - Get ministry summary for a specific group

- **GET** `/ministry-summaries/:month/:year`
  - Get all ministry summaries for a month/year

#### Workflow Operations

- **POST** `/populate/:month/:year`
  - Populate all workflow tables for a month/year
  - Creates initial data structure

- **POST** `/recalculate/:month/:year`
  - Recalculate all workflow tables for a month/year
  - Ensures data consistency after updates

## Usage Examples

### 1. Initial Setup for a Month

```typescript
// Populate workflow tables for Month 10, Year 1404
POST /api/workflow/populate/10/1404

// This will:
// 1. Create MonthlyTransactions for all entities
// 2. Calculate InternalReports
// 3. Aggregate MinistrySummaries
```

### 2. Update Transaction Data

```typescript
// Update monthly transaction for an entity
POST /api/workflow/monthly-transactions
{
  "entityTin": "123456789",
  "monthShamsi": 10,
  "yearShamsi": 1404,
  "taxSalary": "100000",
  "taxRent": "50000",
  "collectedAmount": "120000",
  "correspondencesIn": 5,
  "correspondencesOut": 3
}

// This automatically:
// 1. Updates MonthlyTransaction
// 2. Recalculates InternalReport
// 3. Recalculates MinistrySummary (if needed)
```

### 3. Get Reports

```typescript
// Get internal report for an entity
GET /api/workflow/internal-report/123456789/10/1404

// Get all internal reports for a month
GET /api/workflow/internal-reports/10/1404

// Get ministry summary for a group
GET /api/workflow/ministry-summary/گروه اول سنجش ابتدایی/10/1404
```

### 4. Recalculate After Bulk Updates

```typescript
// After bulk updates, recalculate everything
POST /api/workflow/recalculate/10/1404
```

## Database Views

### internal_report_monthly_totals

Provides monthly totals aggregated across all active entities:

```sql
SELECT * FROM internal_report_monthly_totals 
WHERE month_shamsi = 10 AND year_shamsi = 1404;
```

Fields:
- `total_collected` - Sum of all collected amounts
- `total_stabilized` - Sum of all stabilized amounts
- `total_remaining` - Sum of all remaining amounts
- Plus correspondence and inquiry totals

### ministry_summary_monthly_totals

Provides ministry-level totals aggregated across all active groups:

```sql
SELECT * FROM ministry_summary_monthly_totals 
WHERE month_shamsi = 10 AND year_shamsi = 1404;
```

Fields:
- `group_count` - Number of groups
- `total_entities` - Total entities across all groups
- `total_collected`, `total_stabilized`, `total_remaining`
- All tax breakdown totals
- `overall_collection_rate` - Average collection rate

## Migration Files

1. **016_create_monthly_transactions_table.sql**
   - Creates `monthly_transactions` table

2. **017_create_internal_report_table.sql**
   - Creates `internal_report` table
   - Creates `internal_report_monthly_totals` view

3. **018_create_ministry_summary_table.sql**
   - Creates `ministry_summary` table
   - Creates `ministry_summary_monthly_totals` view

## Security

- All endpoints require authentication (`requireAuth`)
- All endpoints require `reports:generate` permission
- All operations are logged in audit logs
- IP addresses are tracked for audit purposes

## Error Handling

- Invalid month/year: Returns 400 Bad Request
- Not found: Returns 404 Not Found
- Server errors: Returns 500 Internal Server Error with error message

## Next Steps

1. **Export Functionality**: Add Excel/PDF export for reports and summaries
2. **Automatic Triggers**: Database triggers to auto-update reports when transactions change
3. **Performance Monitoring**: Track collection rates, completion rates, and KPIs
4. **Scheduled Jobs**: Automatic monthly population of workflow tables
5. **Validation**: Add data validation and business rules
6. **Notifications**: Alert on underperformance or compliance issues

## Files Created

### Migrations
- `migrations/016_create_monthly_transactions_table.sql`
- `migrations/017_create_internal_report_table.sql`
- `migrations/018_create_ministry_summary_table.sql`

### Schema
- Updated `shared/schema.ts` with all three table definitions

### Services
- `server/services/workflowService.ts`

### Routes
- `server/routes/workflow.ts`
- Updated `server/routes.ts` to register workflow routes

### Documentation
- `docs/MONTHLY_TRANSACTIONS_TABLE.md`
- `docs/INTERNAL_REPORT_TABLE.md`
- `docs/MINISTRY_SUMMARY_TABLE.md`
- `docs/WORKFLOW_SYSTEM_SUMMARY.md` (this file)

## Testing

To test the workflow system:

1. **Populate initial data**:
   ```bash
   POST /api/workflow/populate/10/1404
   ```

2. **Update a transaction**:
   ```bash
   POST /api/workflow/monthly-transactions
   {
     "entityTin": "123456789",
     "monthShamsi": 10,
     "yearShamsi": 1404,
     "taxSalary": "100000"
   }
   ```

3. **Get reports**:
   ```bash
   GET /api/workflow/internal-reports/10/1404
   GET /api/workflow/ministry-summaries/10/1404
   ```

4. **Recalculate**:
   ```bash
   POST /api/workflow/recalculate/10/1404
   ```

## Notes

- All amounts are stored as NUMERIC(15, 2) for precision
- All dates use Shamsi (Persian) calendar
- Status fields allow filtering active/inactive records
- Unique constraints prevent duplicate records per entity/group per month/year
- Indexes optimize query performance
- Views provide convenient aggregated data access

