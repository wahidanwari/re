# Workflow Automation System

## Overview

The workflow automation system allows you to configure and execute the complete audit reporting workflow for any selected month/year. The system automatically pulls entities from the master table, appends monthly transactions, and regenerates reports, summaries, and alerts.

## Key Features

1. **Selectable Month/Year**: Configure workflow to run for any specific month and year
2. **Entity Pulling**: Automatically pulls all entities from EntitiesMaster table
3. **Append Mode**: New monthly transactions are appended to MonthlyTransactions table (doesn't overwrite existing data)
4. **Automatic Regeneration**: InternalReport and MinistrySummary are automatically regenerated
5. **Separate Storage**: All workflow tables are temporary/separate - master entity table is never modified
6. **Dynamic Updates**: Alerts and report exports update dynamically with new data

## Workflow Execution Process

When you execute an automated workflow, the system performs these steps in order:

1. **Pull Entities from Master Table**
   - Reads all entities from `entities` (master table)
   - Creates transaction records for entities that don't have records yet
   - Updates existing transaction records if appendMode is false

2. **Populate MonthlyTransactions**
   - Creates/updates transaction records for each entity
   - All tax fields, amounts, and correspondence data
   - Links to master entity via EntityTIN

3. **Regenerate InternalReport** (if enabled)
   - Calculates TotalTaxableAmount, RemainingAmount from transactions
   - Aggregates per-entity monthly data
   - Updates existing reports or creates new ones

4. **Regenerate MinistrySummary** (if enabled)
   - Aggregates InternalReport data per group
   - Calculates entity counts, revenue metrics, compliance status
   - Updates existing summaries or creates new ones

5. **Generate Alerts** (if enabled)
   - Flags entities with high RemainingAmount
   - Flags groups with low RevenueCollected
   - Creates alert records for dashboard highlighting

## Configuration

### Workflow Configuration Table

The `workflow_config` table stores configuration for automated workflow processing:

**Fields**:
- `config_name`: Unique name for the configuration
- `month_shamsi`: Month (برج) - 1-12
- `year_shamsi`: Year (سال) - Shamsi year (e.g., 1404)
- `auto_run`: Whether to automatically run this workflow
- `run_on_day`: Day of month to run (for scheduling)
- `next_run_at`: Next scheduled run time
- `append_mode`: Append new transactions (true) or overwrite (false)
- `regenerate_reports`: Automatically regenerate InternalReport
- `regenerate_summaries`: Automatically regenerate MinistrySummary
- `generate_alerts`: Automatically generate alerts
- `status`: Current status ('pending', 'running', 'completed', 'failed')

## API Endpoints

### Execute Automated Workflow

**POST** `/api/workflow/automate/:month/:year`

Execute the complete workflow for a specific month/year.

**Parameters**:
- `month`: Month in Shamsi calendar (1-12)
- `year`: Year in Shamsi calendar (e.g., 1404)

**Request Body** (optional):
```json
{
  "appendMode": true,
  "regenerateReports": true,
  "regenerateSummaries": true,
  "generateAlerts": true
}
```

**Example**:
```bash
POST /api/workflow/automate/10/1404
Content-Type: application/json

{
  "appendMode": true,
  "regenerateReports": true,
  "regenerateSummaries": true,
  "generateAlerts": true
}
```

**Response**:
```json
{
  "message": "Workflow executed successfully",
  "result": {
    "monthShamsi": 10,
    "yearShamsi": 1404,
    "transactions": {
      "created": 25,
      "updated": 5
    },
    "reports": {
      "created": 25,
      "updated": 5
    },
    "summaries": {
      "created": 3,
      "updated": 2
    },
    "alerts": {
      "entityAlerts": 5,
      "groupAlerts": 1
    },
    "executionTime": 1234,
    "status": "completed"
  }
}
```

### Create/Update Workflow Configuration

**POST** `/api/workflow/config`

Create or update a workflow configuration.

**Request Body**:
```json
{
  "configName": "monthly_automation_1404_10",
  "monthShamsi": 10,
  "yearShamsi": 1404,
  "autoRun": true,
  "runOnDay": 1,
  "appendMode": true,
  "regenerateReports": true,
  "regenerateSummaries": true,
  "generateAlerts": true
}
```

**Response**:
```json
{
  "id": "abc123",
  "configName": "monthly_automation_1404_10",
  "monthShamsi": 10,
  "yearShamsi": 1404,
  "autoRun": true,
  "runOnDay": 1,
  "appendMode": true,
  "regenerateReports": true,
  "regenerateSummaries": true,
  "generateAlerts": true,
  "status": "pending",
  "createdAt": "2024-01-01T00:00:00Z"
}
```

### Get All Workflow Configurations

**GET** `/api/workflow/config`

Get all workflow configurations.

**Response**:
```json
[
  {
    "id": "abc123",
    "configName": "monthly_automation_1404_10",
    "monthShamsi": 10,
    "yearShamsi": 1404,
    "autoRun": true,
    "status": "completed",
    ...
  }
]
```

### Get Workflow Configuration by Name

**GET** `/api/workflow/config/:configName`

Get a specific workflow configuration.

**Example**:
```bash
GET /api/workflow/config/monthly_automation_1404_10
```

### Run Scheduled Workflows

**POST** `/api/workflow/scheduled/run`

Manually trigger all scheduled workflows that are due to run.

**Response**:
```json
{
  "message": "Scheduled workflows executed",
  "executed": 2,
  "results": [
    {
      "monthShamsi": 10,
      "yearShamsi": 1404,
      "status": "completed",
      ...
    }
  ]
}
```

## Usage Examples

### Execute Workflow for Current Month

```typescript
// In frontend
const response = await fetch('/api/workflow/automate/10/1404', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${token}`
  },
  body: JSON.stringify({
    appendMode: true,
    regenerateReports: true,
    regenerateSummaries: true,
    generateAlerts: true
  })
});

const result = await response.json();
console.log('Workflow executed:', result);
```

### Configure Monthly Automation

```typescript
// Create configuration for monthly automation
const config = await fetch('/api/workflow/config', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${token}`
  },
  body: JSON.stringify({
    configName: 'monthly_automation_1404_10',
    monthShamsi: 10,
    yearShamsi: 1404,
    autoRun: true,
    runOnDay: 1, // Run on 1st of each month
    appendMode: true,
    regenerateReports: true,
    regenerateSummaries: true,
    generateAlerts: true
  })
});
```

### Schedule Workflow via Cron Job

You can set up a cron job to automatically run scheduled workflows:

**Linux/macOS**:
```bash
# Run every day at 2 AM
0 2 * * * curl -X POST http://localhost:3000/api/workflow/scheduled/run \
  -H "Cookie: audit.sid=YOUR_SESSION_COOKIE"
```

**Windows Task Scheduler**:
1. Create a scheduled task
2. Action: Run a program
3. Program: `curl` or `powershell`
4. Arguments: `-X POST http://localhost:3000/api/workflow/scheduled/run`

## Append Mode vs Overwrite Mode

### Append Mode (Default: true)

- **Behavior**: Creates new transaction records for entities that don't have records yet
- **Use Case**: Adding new monthly data without losing existing data
- **Result**: MonthlyTransactions table grows with new records

### Overwrite Mode (appendMode: false)

- **Behavior**: Updates existing transaction records, overwriting previous values
- **Use Case**: Correcting or updating existing monthly data
- **Result**: Existing records are updated, no new records created

## Data Flow

```
EntitiesMaster (Read-Only)
    ↓
MonthlyTransactions (Append/Update)
    ↓
InternalReport (Auto-Regenerate)
    ↓
MinistrySummary (Auto-Regenerate)
    ↓
Alerts (Auto-Generate)
    ↓
Exports (Dynamic - Always Current)
```

## Master Table Protection

**Important**: The master `entities` table is **never modified** by the workflow automation:

- ✅ Workflow reads from `entities` table
- ✅ Workflow writes to `monthly_transactions` table
- ✅ Workflow writes to `internal_report` table
- ✅ Workflow writes to `ministry_summary` table
- ✅ Workflow writes to `workflow_alerts` table
- ❌ Workflow **never** writes to `entities` table

## Dynamic Updates

All exports and alerts update dynamically with new data:

1. **Exports**: When you export InternalReport or MinistrySummary, they always include the latest data from workflow tables
2. **Alerts**: Alerts are regenerated each time the workflow runs, ensuring they reflect current status
3. **Reports**: InternalReport and MinistrySummary are recalculated from the latest transaction data

## Error Handling

The workflow automation includes comprehensive error handling:

- **Transaction Errors**: If transaction creation fails, workflow continues with other entities
- **Report Errors**: If report generation fails, workflow logs error but continues
- **Summary Errors**: If summary generation fails, workflow logs error but continues
- **Alert Errors**: If alert generation fails, workflow continues (alerts are optional)

All errors are logged and included in the execution result.

## Performance Considerations

1. **Batch Processing**: Workflow processes all entities in batches
2. **Indexed Queries**: Database queries use indexes for fast retrieval
3. **Incremental Updates**: Only affected reports/summaries are updated
4. **Parallel Processing**: Where possible, operations run in parallel

## Best Practices

1. **Run Monthly**: Execute workflow at the beginning of each month for the previous month
2. **Append Mode**: Use append mode to preserve historical data
3. **Enable All Steps**: Enable report, summary, and alert generation for complete automation
4. **Monitor Status**: Check workflow execution status regularly
5. **Review Alerts**: Review generated alerts to identify issues early

## Migration

The workflow configuration table is created via migration `020_create_workflow_config_table.sql`. Run this migration to enable workflow automation.

## Notes

- All workflow tables are temporary/separate from master data
- Master entity table is never modified
- Workflow can be run for any month/year (past, present, or future)
- Multiple configurations can exist for different months/years
- Scheduled workflows run automatically when due
- All workflow operations are logged in audit logs

