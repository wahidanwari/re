# Ministry Summary Table Structure

## Overview

The `ministry_summary` table is a **workflow table** designed to aggregate per-group monthly summaries from `internal_report` for ministry-level reporting. This table provides group-level aggregations that can be used for ministry reporting and analysis.

## Key Design Principles

1. **Read-Only Master Table Links**: This table links to the master `entities` and `groups` tables but **never modifies** them.
2. **Temporary Workflow Data**: All calculations, aggregations, and reporting data are stored in this workflow table.
3. **Group-Level Aggregation**: Aggregates data from `internal_report` by group (گروه ارجاع‌دهنده).
4. **No Master Table Modification**: DO NOT modify or overwrite any data in the master entity or groups tables.

## Table Structure

### Primary Key & Group Link

- **`id`**: Primary key - Workflow-generated unique ID (UUID)
- **`group_id`**: Group ID - Links to `groups.id` (can be NULL for static groups)
- **`group_name`** (GroupName): نام گروه - From `groups.name` or static group name
- **`group_code`**: کد گروه - From `groups.code` (if exists)
- **`month_shamsi`** (Month): برج - Month in Shamsi calendar (1-12)
- **`year_shamsi`** (Year): سال - Year in Shamsi calendar (e.g., 1404)
- **Unique Constraint**: `(group_name, month_shamsi, year_shamsi)` - One summary per group per month/year

### Entity Counts

- **`total_entities`** (TotalEntities): Count of entities in the group (INTEGER)
- **`finalized_entities`** (FinalizedEntities): Entities with RemainingAmount = 0 (INTEGER)
- **`partially_compliant_entities`** (PartiallyCompliantEntities): Entities with 0 < RemainingAmount < TotalTaxableAmount (INTEGER)
- **`non_compliant_entities`** (NonCompliantEntities): Entities with RemainingAmount = TotalTaxableAmount (INTEGER)

### Revenue Data

- **`revenue_collected`** (RevenueCollected): Sum of CollectedAmount from all entities in the group (NUMERIC 15,2)
- **`monthly_revenue_target`** (MonthlyRevenueTarget): Target revenue for the month - Retrieved from `group_targets.targetMonetary` divided by 12 (NUMERIC 15,2)
- **`percent_variation`** (PercentVariation): Calculated as (RevenueCollected / MonthlyRevenueTarget) * 100 (NUMERIC 5,2)

### Correspondence & Inquiry Data

- **`incoming_letters`** (IncomingLetters): Sum of CorrespondencesIn from all entities in the group (INTEGER)
- **`outgoing_letters`** (OutgoingLetters): Sum of CorrespondencesOut from all entities in the group (INTEGER)
- **`incoming_inquiries`** (IncomingInquiries): Sum of InquiriesIn from all entities in the group (INTEGER)
- **`outgoing_inquiries`** (OutgoingInquiries): Sum of InquiriesOut from all entities in the group (INTEGER)

### Status

- **`status`**: Status of the summary - 'active' or 'inactive' (TEXT, default: 'active')
  - **active**: Summary is active and included in calculations
  - **inactive**: Summary is inactive and excluded from calculations

### Additional Fields

- **`notes`** (Notes): ملاحظات - General notes (TEXT)
- **`created_at`**: Timestamp of creation
- **`updated_at`**: Timestamp of last update

## Indexes

The table includes the following indexes for performance:

1. **`idx_ministry_summary_group_id`**: Partial index on `group_id` (only non-null values) for group lookups
2. **`idx_ministry_summary_group_name`**: Index on `group_name` for group name lookups
3. **`idx_ministry_summary_month_year`**: Composite index on `(year_shamsi, month_shamsi)` for time-based queries
4. **`idx_ministry_summary_status`**: Index on `status` for filtering active/inactive summaries
5. **`idx_ministry_summary_updated`**: Index on `updated_at DESC` for recent updates

## Ministry-Level Monthly Totals View

A database view `ministry_summary_monthly_totals` provides aggregated monthly totals across all active groups:

### View Fields

- **`month_shamsi`**: Month (1-12)
- **`year_shamsi`**: Year (Shamsi year)
- **`group_count`**: Number of active groups in the month
- **`total_entities`**: Total entities across all groups
- **`total_finalized_entities`**: Sum of all finalized entities
- **`total_partially_compliant_entities`**: Sum of all partially compliant entities
- **`total_non_compliant_entities`**: Sum of all non-compliant entities
- **`total_revenue_collected`**: Sum of all revenue collected
- **`total_revenue_target`**: Sum of all monthly revenue targets
- **`overall_percent_variation`**: Average percent variation across all groups
- **`total_incoming_letters`**: Sum of all incoming letters
- **`total_outgoing_letters`**: Sum of all outgoing letters
- **`total_incoming_inquiries`**: Sum of all incoming inquiries
- **`total_outgoing_inquiries`**: Sum of all outgoing inquiries

### Usage

```sql
-- Get ministry-level totals for a specific month/year
SELECT * FROM ministry_summary_monthly_totals 
WHERE month_shamsi = 10 AND year_shamsi = 1404;
```

## Data Population

The table is populated from `internal_report` with the following process:

1. **Group entities by referral group:**
   - Join `internal_report` with `entities` table via `entity_tin`
   - Group by `entities.referral_group` (گروه ارجاع‌دهنده)
   - For each group and month/year combination, aggregate data

2. **Calculate entity counts:**
   - **TotalEntities**: Count of all entities in the group
   - **FinalizedEntities**: Count entities where `RemainingAmount = 0`
   - **PartiallyCompliantEntities**: Count entities where `0 < RemainingAmount < TotalTaxableAmount`
   - **NonCompliantEntities**: Count entities where `RemainingAmount = TotalTaxableAmount`

3. **Calculate revenue metrics:**
   - **RevenueCollected**: Sum of all `CollectedAmount` values
   - **MonthlyRevenueTarget**: Get from `group_targets.targetMonetary` for the year, divide by 12
   - **PercentVariation**: Calculate as `(RevenueCollected / MonthlyRevenueTarget) * 100`

4. **Aggregate correspondence and inquiry data:**
   - **IncomingLetters**: Sum of all `CorrespondencesIn` values
   - **OutgoingLetters**: Sum of all `CorrespondencesOut` values
   - **IncomingInquiries**: Sum of all `InquiriesIn` values
   - **OutgoingInquiries**: Sum of all `InquiriesOut` values

5. **Group information:**
   - Get group name from `groups.name` if `group_id` exists
   - Handle static groups (groups that don't exist in `groups` table)
   - Store group code if available

6. **Status Management:**
   - New summaries default to 'active'
   - Summaries can be marked 'inactive' to exclude from calculations
   - Only 'active' summaries are included in ministry totals view

## Relationship to InternalReport

- **Source Data**: Aggregates data from `internal_report` table
- **Grouping**: Groups by referral group (گروه ارجاع‌دهنده) from `entities` table
- **Link**: Joins `internal_report.entity_tin` with `entities.tin`, then groups by `entities.referral_group`
- **Many-to-One**: Multiple `internal_report` records (one per entity) aggregate into one `ministry_summary` record (one per group)

## Relationship to Master Tables

- **Read-Only Link**: The table references `groups.id` via `group_id` and `groups.name` via `group_name` but does NOT have foreign key constraints
- **Entity Link**: References entities indirectly through `internal_report` → `entities` → `referral_group`
- **Independence**: This ensures the workflow table remains independent and can be rebuilt if needed
- **No Modification**: This table NEVER modifies or overwrites data in the master `entities` or `groups` tables

## Aggregation Example

### Example: Aggregate Group Data

Given the following `internal_report` records for Group A in Month 10, Year 1404:

| Entity | TotalTaxableAmount | CollectedAmount | RemainingAmount |
|--------|-------------------|-----------------|-----------------|
| Entity1 | 100,000 | 100,000 | 0 |
| Entity2 | 200,000 | 150,000 | 50,000 |
| Entity3 | 150,000 | 0 | 150,000 |

**Resulting `ministry_summary` record:**

- `total_entities` = 3
- `finalized_entities` = 1 (Entity1: RemainingAmount = 0)
- `partially_compliant_entities` = 1 (Entity2: 0 < 50,000 < 200,000)
- `non_compliant_entities` = 1 (Entity3: RemainingAmount = TotalTaxableAmount)
- `revenue_collected` = 250,000 (100,000 + 150,000 + 0)
- `monthly_revenue_target` = 300,000 (from group_targets, yearly target / 12)
- `percent_variation` = (250,000 / 300,000) * 100 = 83.33%

## Workflow Summary

The complete workflow data flow:

1. **MonthlyTransactions** (per-entity monthly data)
   ↓
2. **InternalReport** (aggregated per-entity monthly reports)
   ↓
3. **MinistrySummary** (aggregated per-group monthly summaries)

Each level aggregates data from the previous level, providing:
- Entity-level details (MonthlyTransactions)
- Entity-level summaries (InternalReport)
- Group-level summaries (MinistrySummary)
- Ministry-level totals (View)

## Next Steps

After creating this table, the workflow will include:

1. **Service Functions**: Functions to populate, update, and recalculate workflow tables
2. **API Endpoints**: REST endpoints for accessing and managing workflow data
3. **Export Functionality**: Excel/PDF export for reports and summaries
4. **Automatic Updates**: Triggers or functions to update summaries when transactions or reports change
5. **Performance Monitoring**: Track collection rates, completion rates, and other KPIs

