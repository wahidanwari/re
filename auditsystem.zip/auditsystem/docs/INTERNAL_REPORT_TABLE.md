# Internal Report Table Structure

## Overview

The `internal_report` table is a **workflow table** designed to aggregate per-entity monthly data from `monthly_transactions` for internal reporting. This table calculates totals and remaining amounts for each entity on a monthly basis.

## Key Design Principles

1. **Read-Only Master Entity Link**: This table links to the master `entities` table via EntityTIN ( نمبر تشخیصیه) but **never modifies** the master table.
2. **Temporary Workflow Data**: All calculations, aggregations, and reporting data are stored in this workflow table.
3. **Automatic Calculations**: Calculates `TotalTaxableAmount` and `RemainingAmount` from transaction data.
4. **No Master Table Modification**: DO NOT modify or overwrite any data in the master entity table.

## Table Structure

### Primary Key & Entity Link

- **`id`**: Primary key - Workflow-generated unique ID (UUID)
- **`entity_tin`** (EntityTIN):  نمبر تشخیصیه - Links to `entities.tin` (master entity table)
- **`entity_name`** (EntityName): نام نهاد - From `entities.company_name`
- **`month_shamsi`** (Month): برج - Month in Shamsi calendar (1-12)
- **`year_shamsi`** (Year): سال - Year in Shamsi calendar (e.g., 1404)
- **Unique Constraint**: `(entity_tin, month_shamsi, year_shamsi)` - One report per entity per month/year

### Calculated Fields

#### TotalTaxableAmount
- **Calculation**: `TaxSalary + TaxRent + TaxContract + TaxProfit + IncomeTax`
- **Purpose**: Sum of all tax types for the entity in the given month
- **Type**: NUMERIC(15, 2)

#### RemainingAmount
- **Calculation**: `TotalTaxableAmount - CollectedAmount`
- **Purpose**: Amount still remaining to be collected
- **Type**: NUMERIC(15, 2)

### Financial Amounts

- **`collected_amount`** (CollectedAmount): مبلغ تحصیل شده - Amount collected in current month (NUMERIC 15,2)
- **`remaining_amount`** (RemainingAmount): الباقی مبلغ قابل تحصیل - Calculated as TotalTaxableAmount - CollectedAmount (NUMERIC 15,2)
- **`stabilized_amount`** (StabilizedAmount): مبلغ تثبیت شده - Confirmed/established amount (NUMERIC 15,2)

### Tax Breakdown Fields

Stored for reference and detailed reporting:

- **`tax_salary`**: مالیه موضوعی معاشات - Salary tax (NUMERIC 15,2)
- **`tax_rent`**: مالیه موضوعی بر کرایه - Rent tax (NUMERIC 15,2)
- **`tax_contract`**: مالیه موضوعی قراردادی - Contract tax (NUMERIC 15,2)
- **`tax_profit`**: مالیه موضوعی معاملات انتفاعی - Profit transaction tax (NUMERIC 15,2)
- **`income_tax`**: مالیات بر عایدات - Income tax (NUMERIC 15,2)
- **`loss_reduction`**: ضرر کاهش یافته - Reduced loss (NUMERIC 15,2)

### Correspondence & Inquiry Data

- **`correspondences_in`**: تعداد مکتوب های وارده - Number of letters received (INTEGER)
- **`correspondences_out`**: تعداد مکتوب های صادره - Number of letters sent (INTEGER)
- **`inquiries_in`**: تعداد استعلام های وارده - Number of inquiries received (INTEGER)
- **`inquiries_out`**: تعداد استعلام های صادره - Number of inquiries sent (INTEGER)

### Status

- **`status`**: Status of the report - 'active' or 'inactive' (TEXT, default: 'active')
  - **active**: Report is active and included in calculations
  - **inactive**: Report is inactive and excluded from calculations

### Additional Fields

- **`notes`** (Notes): ملاحظات - General notes (TEXT)
- **`created_at`**: Timestamp of creation
- **`updated_at`**: Timestamp of last update

## Indexes

The table includes the following indexes for performance:

1. **`idx_internal_report_entity_tin`**: Index on `entity_tin` for fast entity lookups
2. **`idx_internal_report_month_year`**: Composite index on `(year_shamsi, month_shamsi)` for time-based queries
3. **`idx_internal_report_status`**: Index on `status` for filtering active/inactive reports
4. **`idx_internal_report_updated`**: Index on `updated_at DESC` for recent updates

## Monthly Totals View

A database view `internal_report_monthly_totals` provides aggregated monthly totals across all active entities:

### View Fields

- **`month_shamsi`**: Month (1-12)
- **`year_shamsi`**: Year (Shamsi year)
- **`entity_count`**: Number of active entities in the month
- **`total_taxable_amount`**: Sum of all TotalTaxableAmount values
- **`total_collected`**: Sum of all CollectedAmount values
- **`total_stabilized`**: Sum of all StabilizedAmount values
- **`total_remaining`**: Sum of all RemainingAmount values
- **`total_correspondences_in`**: Sum of all correspondences received
- **`total_correspondences_out`**: Sum of all correspondences sent
- **`total_inquiries_in`**: Sum of all inquiries received
- **`total_inquiries_out`**: Sum of all inquiries sent

### Usage

```sql
-- Get monthly totals for a specific month/year
SELECT * FROM internal_report_monthly_totals 
WHERE month_shamsi = 10 AND year_shamsi = 1404;
```

## Data Population

The table is populated from `monthly_transactions` with the following process:

1. **For each EntityTIN in MonthlyTransactions:**
   - Calculate `TotalTaxableAmount = TaxSalary + TaxRent + TaxContract + TaxProfit + IncomeTax`
   - Calculate `RemainingAmount = TotalTaxableAmount - CollectedAmount`
   - Copy all relevant transaction fields
   - Get `EntityName` from master `entities` table via EntityTIN

2. **Status Management:**
   - New reports default to 'active'
   - Reports can be marked 'inactive' to exclude from calculations
   - Only 'active' reports are included in monthly totals view

## Relationship to MonthlyTransactions

- **Source Data**: Aggregates data from `monthly_transactions` table
- **Link**: Both tables use `entity_tin` to link to master `entities` table
- **One-to-One**: One `internal_report` record per `monthly_transactions` record (same entity, month, year)

## Relationship to Master Entities Table

- **Read-Only Link**: The table references `entities.tin` via `entity_tin` but does NOT have a foreign key constraint
- **EntityName**: Retrieved from `entities.company_name` when populating the report
- **Independence**: This ensures the workflow table remains independent and can be rebuilt if needed
- **No Modification**: This table NEVER modifies or overwrites data in the master `entities` table

## Calculation Examples

### Example 1: Calculate TotalTaxableAmount

```
TaxSalary = 100,000
TaxRent = 50,000
TaxContract = 75,000
TaxProfit = 25,000
IncomeTax = 30,000

TotalTaxableAmount = 100,000 + 50,000 + 75,000 + 25,000 + 30,000 = 280,000
```

### Example 2: Calculate RemainingAmount

```
TotalTaxableAmount = 280,000
CollectedAmount = 150,000

RemainingAmount = 280,000 - 150,000 = 130,000
```

## Next Steps

After creating this table, the workflow will include:

1. **MinistrySummary Table**: Aggregated per-group monthly summaries
2. **Service Functions**: Functions to populate, update, and recalculate workflow tables
3. **API Endpoints**: REST endpoints for accessing and managing workflow data
4. **Export Functionality**: Excel/PDF export for reports and summaries
5. **Automatic Updates**: Triggers or functions to update reports when transactions change

