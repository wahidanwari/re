# Database Management Workflow

This document describes the database management workflow for the audit system, including how to rebuild, reset, and seed the database.

## Overview

The database layer has been stabilized with three main operations:

1. **Fresh Database Rebuild** - Complete database drop and recreation
2. **Reset Development Data** - Truncate all data and re-seed defaults
3. **Seeding** - Populate default users, roles, permissions, and packages

## Safety Features

⚠️ **All destructive operations are protected from running in production:**

- Scripts check `NODE_ENV` environment variable
- Will exit with error if `NODE_ENV=production`
- Only runs in `development` or `test` environments

## Commands

### Fresh Database Rebuild (One-Time Operation)

**Command:** `npm run db:rebuild`

**What it does:**
- Drops the entire database
- Recreates a fresh database
- Runs all migrations in order:
  - `001_canonical_rbac.sql` - RBAC system setup
  - `002_add_case_completed_by.sql` - Case completion tracking
  - `003_add_permissions_version.sql` - Permission versioning
  - `004_production_indexes.sql` - Performance indexes
  - `005_fix_audit_id_unique_constraint.sql` - Fix unique constraint for auditId
- Fixes all unique constraints
- Ensures all foreign keys are properly set up

**When to use:**
- Initial setup
- After major schema changes
- When database is corrupted or inconsistent
- When you need a completely fresh start

**After running:**
You must run `npm run db:seed` or `npm run db:reset` to populate default data.

---

### Reset Development Data (Anytime During Development)

**Command:** `npm run db:reset`

**What it does:**
- Truncates all data tables (respecting foreign key constraints)
- Resets all SERIAL sequences back to 1
- Re-seeds default data:
  - System users (admin, auditor, senior auditor)
  - Roles (system_admin, director, senior_auditor, auditor)
  - Permissions (all 14 base permissions)
  - Packages (acting_coordinator, approval_authority)
  - Role-permission mappings
  - Package-permission mappings
  - User-role assignments

**When to use:**
- During development when you need clean test data
- After testing features that create test data
- When you want to start fresh without dropping the schema
- Before running test suites

**What gets reset:**
- ✅ All users (except default seeds)
- ✅ All groups
- ✅ All group members
- ✅ All entities
- ✅ All cases
- ✅ All tickets
- ✅ All documents
- ✅ All notifications
- ✅ All audit logs
- ✅ All system settings
- ✅ All RBAC mappings

**What stays:**
- ✅ Database schema (tables, indexes, constraints)
- ✅ Default seeded users and roles

---

### Seeding Default Data

**Command:** `npm run db:seed`

**What it does:**
- Seeds default system users
- Seeds roles, permissions, and packages
- Creates role-permission mappings
- Creates package-permission mappings
- Assigns roles to default users

**Default Users Created:**

| Audit ID | Password | Full Name | Role |
|----------|----------|-----------|------|
| `admin001` | `Admin@2024!` | System Administrator | system_admin |
| `auditor001` | `Auditor@2024!` | Default Auditor | auditor |
| `senior001` | `Senior@2024!` | Default Senior Auditor | senior_auditor |

**Default Roles:**
- `system_admin` - Full system control
- `director` - Oversight, final approvals, system-wide reporting
- `senior_auditor` - Team lead, manages workflow of auditors
- `auditor` - Base-level user working on assigned cases

**Default Packages:**
- `acting_coordinator` - Grants cases:assign_to_groups, groups:manage_all, reports:internal
- `approval_authority` - Grants approvals:approve_tickets

**When to use:**
- After running `db:rebuild`
- When default users are missing
- When you need to refresh role/permission data

---

## Workflow Examples

### Initial Setup (Fresh Database)

```bash
# 1. Rebuild database from scratch
npm run db:rebuild

# 2. Seed default data (or use reset which includes seeding)
npm run db:seed
# OR
npm run db:reset
```

### Development Reset (Clean Slate)

```bash
# Reset all data and re-seed defaults
npm run db:reset
```

### After Schema Changes

```bash
# If you've added new migrations:
npm run db:rebuild

# Then seed:
npm run db:seed
```

---

## Database Schema Fixes

### Unique Constraint Fix (auditId)

**Problem:** Previously, deleted users' `auditId` values could not be reused, causing conflicts.

**Solution:** 
- Changed from full unique constraint to partial unique index
- Only active users (`is_active = true`) must have unique `auditId`
- Deleted users (`is_active = false`) no longer block reuse

**Migration:** `005_fix_audit_id_unique_constraint.sql`

**Implementation:**
```sql
CREATE UNIQUE INDEX users_audit_id_active_unique 
ON users(audit_id) 
WHERE is_active = true;
```

This allows:
- ✅ New users to reuse deleted users' auditIds
- ✅ Active users to maintain unique auditIds
- ✅ Historical data integrity (audit logs preserve user references)

---

## Table Dependencies

The reset script respects table dependencies and truncates in the correct order:

1. **Bridge Tables** (user_packages, user_roles, etc.)
2. **Data Tables** (notifications, documents, tickets, cases, etc.)
3. **Core Tables** (users, groups)
4. **RBAC Base Tables** (packages, permissions, roles)

All foreign keys use `ON DELETE CASCADE` where appropriate to ensure clean deletion.

---

## SERIAL Sequence Reset

The reset script automatically resets all SERIAL sequences back to 1:

- `roles_id_seq`
- `permissions_id_seq`
- `role_permissions_id_seq`
- `packages_id_seq`
- `package_permissions_id_seq`
- `user_roles_id_seq`
- `user_packages_id_seq`

This ensures consistent ID generation after reset.

---

## Troubleshooting

### Error: "Cannot run in production"

**Solution:** Set `NODE_ENV=development` or `NODE_ENV=test`

```bash
export NODE_ENV=development
npm run db:reset
```

### Error: "DATABASE_URL must be set"

**Solution:** Ensure `.env` file exists with `DATABASE_URL` set

```bash
# .env
DATABASE_URL=postgresql://user:password@localhost:5432/dbname
```

### Error: "Could not parse database name"

**Solution:** Ensure `DATABASE_URL` is in correct format:
- `postgresql://user:pass@host:port/dbname`
- Or `postgres://user:pass@host:port/dbname`

### Foreign Key Constraint Errors

**Solution:** Run `db:rebuild` to ensure all foreign keys are properly set up with CASCADE rules.

---

## Migration Files

All migrations are located in `migrations/`:

1. `001_canonical_rbac.sql` - RBAC system
2. `002_add_case_completed_by.sql` - Case completion
3. `003_add_permissions_version.sql` - Permission versioning
4. `004_production_indexes.sql` - Performance indexes
5. `005_fix_audit_id_unique_constraint.sql` - Unique constraint fix

---

## Best Practices

1. **Always use `db:reset` during development** - Keeps data clean
2. **Use `db:rebuild` only when needed** - More destructive, use for schema changes
3. **Never run in production** - Scripts are protected, but double-check `NODE_ENV`
4. **Commit migration files** - Always commit new migration SQL files
5. **Test migrations** - Test on development database before applying to production
6. **Backup before major operations** - Always backup production data before schema changes

---

## Script Files

- `server/scripts/rebuild-db.ts` - Fresh database rebuild
- `server/scripts/reset-db.ts` - Reset development data
- `server/scripts/seed.ts` - Comprehensive seeding
- `server/scripts/seed-admin.ts` - Legacy admin-only seeding (kept for compatibility)

---

## Summary

| Operation | Command | Use Case | Destructive |
|-----------|---------|----------|-------------|
| Rebuild | `npm run db:rebuild` | Fresh start, schema changes | ⚠️ Very (drops DB) |
| Reset | `npm run db:reset` | Clean data during dev | ⚠️ Yes (deletes all data) |
| Seed | `npm run db:seed` | Add default data | ✅ No (adds only) |

---

**Last Updated:** Database stabilization implementation
**Maintained By:** Development Team

