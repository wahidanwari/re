# Quick Start: Audit Records Migration

## Step-by-Step Migration Guide

### Prerequisites
- Database connection configured (DATABASE_URL environment variable)
- Backup of your database (recommended)

### Step 1: Run Database Schema Migration

This creates the new `audit_records` table structure with year ranges:

**Recommended (works on all platforms):**
```powershell
# Make sure DATABASE_URL is set
npm run db:migrate-audit-records-year-ranges
```

**Alternative (if you have psql installed):**
```powershell
# Windows PowerShell
psql $env:DATABASE_URL -f migrations/023_audit_records_year_ranges.sql

# Linux/Mac
psql $DATABASE_URL -f migrations/023_audit_records_year_ranges.sql

# Direct connection
psql "postgresql://user:password@localhost:5432/dbname" -f migrations/023_audit_records_year_ranges.sql
```

### Step 2: Data Migration (Optional)

If you have existing entities that need conversion:

**Preview changes (dry run):**
```powershell
npm run db:migrate-entity-audit-records -- --dry-run
```

**Apply migration:**
```powershell
npm run db:migrate-entity-audit-records
```

When prompted, type `yes` or `y` to confirm.

### Step 3: Verify Migration

1. Check that `audit_records` table exists:
```sql
SELECT COUNT(*) FROM audit_records;
```

2. Verify year ranges are set correctly:
```sql
SELECT entity_id, year_from, year_to, status FROM audit_records LIMIT 10;
```

3. Check for any gaps or issues:
```sql
SELECT 
  e.tin,
  e.company_name,
  COUNT(ar.id) as audit_count
FROM entities e
LEFT JOIN audit_records ar ON e.id = ar.entity_id
GROUP BY e.id, e.tin, e.company_name
ORDER BY audit_count DESC;
```

## Troubleshooting

### Error: "Missing script"
- Make sure you're in the project root directory
- Run `npm install` if dependencies are missing

### Error: "DATABASE_URL not set"
- Set the environment variable:
  - **Windows PowerShell**: 
    ```powershell
    $env:DATABASE_URL="postgresql://user:pass@host:5432/db"
    ```
  - **Linux/Mac**: 
    ```bash
    export DATABASE_URL="postgresql://user:pass@host:5432/db"
    ```
- Or create/update `.env` file in project root:
  ```
  DATABASE_URL=postgresql://user:pass@host:5432/db
  ```

### Error: "Migration cancelled"
- Make sure to type `yes` or `y` (not just Enter)
- The script is case-insensitive

### Error: "Overlapping year range detected"
- This is expected if you have overlapping data
- Review the conflicts and resolve manually
- The migration script will skip overlapping records

## Rollback

If you need to rollback:

1. Restore from backup:
```bash
psql $DATABASE_URL < backup.sql
```

2. Or manually drop the new table (if no data was migrated):
```sql
DROP TABLE IF EXISTS audit_records CASCADE;
-- Then restore the old audit_records table from backup
```

## Next Steps

After migration:
1. Test the API endpoints
2. Verify UI components work correctly
3. Run the test suite: `npm test`
4. Perform manual QA testing

