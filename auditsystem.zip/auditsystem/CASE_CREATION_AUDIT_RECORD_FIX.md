# Case Creation Audit Record Validation Fix

## Summary

Fixed case creation validation error where backend was prompting "لطفاً یک سابقه بررسی موجود را انتخاب کنید یا شناسه سابقه بررسی را وارد کنید" when creating cases. Implemented comprehensive frontend and backend improvements to ensure case creation always associates with a valid AuditRecord.

## Changes Implemented

### 1. Frontend - Form Behavior & Validation

#### Audit Record Selector
- **Location**: `client/src/pages/Cases.tsx`
- Added explicit `auditRecordId` field to form state
- Added dropdown selector that appears after entity selection
- Selector shows:
  - Year range (`auditYears` or `yearFrom-yearTo`)
  - Assigned group name
  - Status (in-progress, completed, archived)
  - Disables completed records (with warning)

#### Prefill Logic
- **From AuditRecord Detail Page**: 
  - Extracts `auditRecordId` from URL query parameter
  - Pre-fills `auditRecordId` and disables selector
  - Automatically fetches and populates entity data
- **From Entity Page**:
  - Loads dropdown of existing AuditRecords for selected entity
  - Requires user to choose one before enabling Submit

#### Validation
- Added inline validation message in Persian:
  - "لطفاً یک سابقه بررسی موجود را انتخاب کنید یا یک سابقه جدید برای این نهاد ایجاد کنید."
- Prevents submit while audit list is loading
- Submit button disabled until valid `auditRecordId` present
- Shows loading spinner during fetch

#### UX Improvements
- Added link/button to create new audit record when none exist
- Displays warning for completed audit records
- Clear error messages from backend (uses `messageFa` field)

### 2. Backend - API Acceptance & Helpful Errors

#### Improved Error Responses
- **Location**: `server/routes/cases.ts`
- Structured error payloads with:
  - `code`: Error code (e.g., `MISSING_AUDIT_RECORD`, `AUDIT_RECORD_COMPLETED`)
  - `message`: English error message
  - `messageFa`: Persian error message (user-facing)
  - `help`: Help text with API endpoint suggestions

#### Validation Logic
- Requires `auditRecordId` or provides helpful error
- Validates that `auditRecordId` belongs to provided `entityId`
- Prevents case creation on completed audit records
- Returns HTTP 400 with structured JSON response

#### Optional Resolve-by-Year Logic
- Accepts `entityId` + (`yearFrom` and optional `yearTo`) in case creation payload
- If `auditRecord` exists for entity + year range → resolves and uses its id
- If multiple matches → returns HTTP 409 conflict with list of matching records
- If no match and `allow_auto_create=true` → optionally creates audit record automatically
  - Requires `groupReferrer` and `referralDate` for auto-creation

#### Logging
- Logs missing-audit-record create attempts with:
  - User ID
  - Entity ID
  - Request payload (password excluded)
- Server-side detailed logs while returning friendly Persian text to client

### 3. Edge Case Handling

#### Completed Audit Records
- Backend rejects case creation for completed audits
- Frontend disables selection of completed records in dropdown
- Shows clear message: "این سابقه بررسی تکمیل شده است — ایجاد قضیه جدید برای این سابقه مجاز نیست."

#### Multiple Matches
- If multiple audit records match requested year range:
  - Returns HTTP 409 Conflict
  - Includes list of matching records with IDs, year ranges, status, and assigned groups
  - User must provide explicit `auditRecordId`

#### Entity Mismatch
- Validates that `auditRecordId` belongs to provided `entityId`
- Returns clear error if mismatch detected

## API Changes

### Case Creation Endpoint
**POST** `/api/cases`

#### Required Fields
- `entityId` (string): Entity ID
- `auditRecordId` (string): Audit Record ID **OR** use resolve-by-year below

#### Optional Resolve-by-Year Fields
- `yearFrom` (number): Start year
- `yearTo` (number): End year (optional, defaults to `yearFrom`)
- `auditYears` (string): Year range as text (e.g., "1402" or "1398-1401")
- `allow_auto_create` (boolean): If true, auto-creates audit record if not found (requires `groupReferrer` and `referralDate`)

#### Error Responses

**400 Bad Request - Missing Audit Record**
```json
{
  "code": "MISSING_AUDIT_RECORD",
  "message": "Please select an existing audit record or create a new one",
  "messageFa": "لطفاً یک سابقه بررسی موجود را انتخاب کنید یا یک سابقه جدید برای این نهاد ایجاد کنید",
  "help": "select audit record or create new via /api/audit-records/entities/:entityId/audits"
}
```

**400 Bad Request - Audit Record Completed**
```json
{
  "code": "AUDIT_RECORD_COMPLETED",
  "message": "This audit record is completed — creating new cases for this record is not allowed",
  "messageFa": "این سابقه بررسی تکمیل شده است — ایجاد قضیه جدید برای این سابقه مجاز نیست"
}
```

**400 Bad Request - Entity Mismatch**
```json
{
  "code": "AUDIT_RECORD_ENTITY_MISMATCH",
  "message": "The selected audit record does not belong to the selected entity",
  "messageFa": "سابقه بررسی انتخاب شده متعلق به نهاد انتخاب شده نیست. لطفاً سابقه بررسی صحیح را انتخاب کنید."
}
```

**409 Conflict - Multiple Matches**
```json
{
  "code": "MULTIPLE_AUDIT_RECORDS",
  "message": "Multiple audit records found for this year range",
  "messageFa": "چندین سابقه بررسی برای این بازه سالی یافت شد. لطفاً شناسه سابقه بررسی را به صورت صریح مشخص کنید.",
  "conflicts": [
    {
      "id": "audit-record-id-1",
      "auditYears": "1400-1402",
      "status": "in-progress",
      "assignedGroup": "group-id-1"
    }
  ]
}
```

## Files Modified

### Frontend
- `client/src/pages/Cases.tsx`
  - Added `auditRecordId` to form state
  - Added audit record selector dropdown
  - Added prefill logic from URL params
  - Added validation and error handling
  - Added link to create new audit record

### Backend
- `server/routes/cases.ts`
  - Improved error messages with structured responses
  - Added optional resolve-by-year logic
  - Added validation for audit record ownership
  - Added logging for debugging
  - Added handling for completed audit records

## Testing Checklist

### Frontend Tests
- [ ] Create case from audit detail page (auto-prefill)
- [ ] Create case from entity page and select audit_record
- [ ] Try submit without selection → blocked with message
- [ ] Test with completed audit record → disabled/blocked
- [ ] Test with no audit records → shows create link

### Backend Tests
- [ ] Payload includes `auditRecordId` (valid) → creates case
- [ ] Payload lacks `auditRecordId` but includes `entityId`+`year` → resolves audit_record or returns helpful error
- [ ] Payload includes `auditRecordId` that belongs to another entity → rejects
- [ ] Payload includes `auditRecordId` for completed audit → rejects
- [ ] Multiple audit records match year range → returns conflict with list

## Usage Examples

### Creating Case with Explicit Audit Record ID
```javascript
POST /api/cases
{
  "entityId": "entity-123",
  "auditRecordId": "audit-record-456",
  "companyName": "شرکت نمونه",
  "tin": "123456789",
  "periodsUnderReview": "1402",
  "referralDate": "01-01-1402",
  "groupReferrer": "گروه اول سنجش ابتدایی",
  "receivingGroup": "group-audit-1"
}
```

### Creating Case with Year Range Resolution
```javascript
POST /api/cases
{
  "entityId": "entity-123",
  "yearFrom": 1400,
  "yearTo": 1402,
  "companyName": "شرکت نمونه",
  "tin": "123456789",
  "periodsUnderReview": "1400-1402",
  "referralDate": "01-01-1402",
  "groupReferrer": "گروه اول سنجش ابتدایی",
  "receivingGroup": "group-audit-1"
}
```

### Auto-Creating Audit Record (if not found)
```javascript
POST /api/cases
{
  "entityId": "entity-123",
  "yearFrom": 1400,
  "yearTo": 1402,
  "allow_auto_create": true,
  "groupReferrer": "گروه اول سنجش ابتدایی",
  "referralDate": "01-01-1402",
  "companyName": "شرکت نمونه",
  "tin": "123456789",
  "periodsUnderReview": "1400-1402",
  "receivingGroup": "group-audit-1"
}
```

## Notes

- The `auditRecordId` field is validated by the backend but is not stored in the `cases` table schema. It's used for validation and logging purposes.
- The frontend form now requires explicit selection of an audit record before allowing case creation.
- The backend provides helpful error messages in Persian (`messageFa`) for better user experience.
- All error responses include structured data for programmatic handling while maintaining user-friendly messages.

