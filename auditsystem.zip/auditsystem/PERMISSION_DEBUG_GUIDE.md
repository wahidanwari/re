# Permission System Debugging Guide

## Overview
This guide documents the fixes applied to resolve data loading issues for users with the Coordination permission package.

## Changes Made

### 1. Added Comprehensive Logging
- **Location**: `server/middleware/permissions.ts`, `server/utils/permissionHelpers.ts`, `server/services/permissionService.ts`, `server/middleware/auth.ts`
- **Purpose**: Debug permission checks and visibility decisions
- **How to Enable**: Set `DEBUG_LOGGING=true` in `.env` file
- **What it logs**:
  - User ID, role, and permission packages
  - Effective permissions calculated
  - Coordinator status checks
  - Visibility decisions (canViewAll, requiresFiltering, etc.)
  - Route-level data counts

### 2. Fixed PermissionPackages Array Handling
- **Location**: `server/services/permissionService.ts`
- **Issue**: `permissionPackages` might not always be an array
- **Fix**: Added normalization to ensure it's always treated as an array:
  ```typescript
  const userPackagesArray = Array.isArray(userData.permissionPackages) 
    ? (userData.permissionPackages as ('acting_coordinator' | 'approval_authority')[])
    : (userData.permissionPackages ? [userData.permissionPackages] : [])
  ```

### 3. Enhanced Session Refresh
- **Location**: `server/middleware/auth.ts`
- **Purpose**: Ensure user data is refreshed on each request
- **Behavior**: 
  - Skips auth routes (login, logout)
  - Refreshes user data from database
  - Logs refresh activity in debug mode

### 4. Coordinator Detection
- **Location**: `server/services/permissionService.ts`
- **Method**: Checks for `cases:assign_to_group` permission (granted by `acting_coordinator` package)
- **Priority**: Coordinator status is checked FIRST before role-based restrictions

## Testing Instructions

### Step 1: Enable Debug Logging
Add to `.env`:
```
DEBUG_LOGGING=true
```

### Step 2: Test Scenario
1. Log in as system admin
2. Assign "Coordination Permission Package" (`acting_coordinator`) to any user
3. Log in as that user
4. Check server logs for:
   - `[REFRESH USER DATA]` - Should show user with packages
   - `[GET_EFFECTIVE_PERMISSIONS]` - Should show calculated permissions
   - `[IS_COORDINATOR]` - Should show `IsCoordinator: true`
   - `[ENTITY VISIBILITY]` / `[CASE VISIBILITY]` - Should show `Coordinator: true`
   - `[ENTITIES ROUTE]` / `[CASES ROUTE]` - Should show `canViewAll=true` and data counts

### Step 3: Verify API Endpoints
Test these endpoints as the coordinator user:
- `GET /api/entities` - Should return all entities (not empty)
- `GET /api/cases` - Should return all cases (not empty)
- `GET /api/entity-types/active` - Should return entity types
- `GET /api/tickets` - Should return tickets
- `GET /api/groups` - Should return groups

### Step 4: Check Logs
Look for these log patterns:
```
[REFRESH USER DATA] User: <id> (auditor), Packages: ["acting_coordinator"], GroupId: <groupId>
[GET_EFFECTIVE_PERMISSIONS] User: <id>, Role: auditor, Packages: ["acting_coordinator"]
[GET_EFFECTIVE_PERMISSIONS] Calculated permissions for <id>: entities:view, cases:view, cases:assign_to_group, ...
[IS_COORDINATOR] User: <id> (auditor), Packages: ["acting_coordinator"], cases:assign_to_group: true, IsCoordinator: true
[ENTITY VISIBILITY] Coordinator detected - granting full access
[ENTITIES ROUTE] Coordinator/Admin access - returning <count> entities
```

## Common Issues and Solutions

### Issue: Empty arrays returned
**Check**:
1. Is `permissionPackages` properly saved in database? (should be `["acting_coordinator"]`)
2. Is coordinator detection working? (check `[IS_COORDINATOR]` logs)
3. Is visibility helper returning `canViewAll: true`? (check `[ENTITY VISIBILITY]` logs)

### Issue: 403 Forbidden errors
**Check**:
1. Are effective permissions being calculated? (check `[GET_EFFECTIVE_PERMISSIONS]` logs)
2. Does user have required permission? (check permission list in logs)
3. Is middleware blocking? (check `[PERMISSION CHECK]` logs)

### Issue: Stale permissions
**Check**:
1. Is `refreshUserData` middleware running? (check `[REFRESH USER DATA]` logs)
2. Is session being refreshed after permission update? (check user update route logs)
3. Is `permissionsVersion` incrementing? (check user update response)

## Disabling Debug Logging
Remove or set to false in `.env`:
```
DEBUG_LOGGING=false
```

## Architecture Notes

### Permission Resolution Flow
1. User makes request → `refreshUserData` middleware loads fresh user data
2. Route handler → Calls `getEntityVisibility()` or `getCaseVisibility()`
3. Visibility helper → Calls `getEffectivePermissions()` and `isCoordinator()`
4. Permission service → Calculates from `shared/permissions.ts` (role + packages)
5. Returns visibility result → Route applies filtering based on result

### Coordinator Detection
- Coordinator = User with `cases:assign_to_group` permission
- This permission is granted by `acting_coordinator` package
- Coordinator status checked FIRST, before role-based restrictions
- Coordinator gets `canViewAll: true` for entities, cases, groups, tickets

