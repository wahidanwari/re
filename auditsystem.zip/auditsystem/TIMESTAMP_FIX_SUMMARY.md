# Event Log Timestamp Fix Summary

## Problem
Event logs were displaying incorrect timestamps - showing different times than the actual local time when events occurred.

## Root Cause
1. **Backend**: Stored timestamps in UTC (correct for databases)
2. **Frontend**: Was using `Intl.DateTimeFormat('fa-IR', ...)` which defaults to Iran timezone, not Afghanistan
3. **No explicit timezone**: Frontend wasn't explicitly formatting as Afghanistan time (Asia/Kabul)

## Solution

### 1. Backend Changes (`server/index.ts`)
- Set default timezone to `Asia/Kabul` at server startup
- Ensures all `new Date()` calls have correct timezone context
```typescript
if (!process.env.TZ) {
  process.env.TZ = 'Asia/Kabul';
}
```

### 2. Backend Storage (`server/storage.ts`)
- Updated comment to clarify: Database stores UTC (correct), frontend formats as Afghanistan time
- No changes needed to timestamp creation (already correct)

### 3. Frontend Display (`client/src/pages/AuditLogs.tsx`)
- **Changed locale**: From `'fa-IR'` to `'en-US'` (more reliable for timezone handling)
- **Added explicit timezone**: `timeZone: 'Asia/Kabul'` - ensures Afghanistan time is displayed
- **Added 24-hour format**: `hour12: false` for consistency
- **Removed duplicate timeZone**: Fixed duplicate `timeZone` property

### Key Changes:
```typescript
// BEFORE (incorrect):
return new Intl.DateTimeFormat('fa-IR', {
  year: 'numeric',
  month: '2-digit',
  day: '2-digit',
  hour: '2-digit',
  minute: '2-digit',
  second: '2-digit',
}).format(d);

// AFTER (correct):
return new Intl.DateTimeFormat('en-US', {
  timeZone: 'Asia/Kabul', // Explicitly set Afghanistan timezone
  year: 'numeric',
  month: '2-digit',
  day: '2-digit',
  hour: '2-digit',
  minute: '2-digit',
  second: '2-digit',
  hour12: false, // 24-hour format
}).format(d);
```

## How It Works

1. **Event occurs** → Backend creates timestamp with `new Date()` (UTC moment in time)
2. **Database stores** → UTC timestamp (PostgreSQL `TIMESTAMP` type)
3. **Frontend retrieves** → UTC timestamp from database
4. **Frontend displays** → Formats UTC timestamp as Afghanistan local time using `timeZone: 'Asia/Kabul'`

## Result

✅ **Correct timestamps**: Events now display the exact Afghanistan local time when they occurred
✅ **No time drift**: Timestamps remain consistent after refresh
✅ **Standardized timezone**: All event logs use Asia/Kabul timezone
✅ **No double conversion**: UTC stored once, formatted once as Afghanistan time

## Testing

1. Create an event (e.g., login, create user)
2. Check event log - timestamp should match current Afghanistan local time
3. Refresh page - timestamp should remain the same
4. Verify timezone: Should show Afghanistan time (UTC+4:30)

## Example

**Before Fix:**
- Actual time: 2:00 PM (Afghanistan)
- Displayed: 10:00 AM ❌

**After Fix:**
- Actual time: 2:00 PM (Afghanistan)
- Displayed: 2:00 PM ✅

