-- Migration: Yearly Audit Records System
-- Creates audit_records table for tracking yearly audits linked to entities
-- Ensures one audit per entity per year with uniqueness constraint

CREATE TABLE IF NOT EXISTS audit_records (
  id VARCHAR(255) PRIMARY KEY DEFAULT gen_random_uuid()::text,
  entity_id VARCHAR(255) NOT NULL REFERENCES entities(id) ON DELETE CASCADE,
  audit_year INTEGER NOT NULL, -- Year in Shamsi calendar (e.g., 1404)
  status TEXT NOT NULL DEFAULT 'in-progress', -- 'in-progress', 'completed', 'cancelled', 'on-hold'
  assigned_auditor VARCHAR(255) REFERENCES users(id) ON DELETE SET NULL,
  audit_group VARCHAR(255) REFERENCES groups(id) ON DELETE SET NULL,
  notes TEXT,
  started_at TIMESTAMP,
  completed_at TIMESTAMP,
  created_by VARCHAR(255) REFERENCES users(id) ON DELETE SET NULL,
  created_at TIMESTAMP DEFAULT now(),
  updated_at TIMESTAMP DEFAULT now(),
  
  -- Ensure uniqueness: one audit per entity per year
  CONSTRAINT audit_records_entity_year_unique UNIQUE (entity_id, audit_year)
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_audit_records_entity_id ON audit_records(entity_id);
CREATE INDEX IF NOT EXISTS idx_audit_records_audit_year ON audit_records(audit_year);
CREATE INDEX IF NOT EXISTS idx_audit_records_status ON audit_records(status);
CREATE INDEX IF NOT EXISTS idx_audit_records_assigned_auditor ON audit_records(assigned_auditor);
CREATE INDEX IF NOT EXISTS idx_audit_records_audit_group ON audit_records(audit_group);
CREATE INDEX IF NOT EXISTS idx_audit_records_created_at ON audit_records(created_at);

-- Audit Record History - Track all changes to audit records for versioning
CREATE TABLE IF NOT EXISTS audit_record_history (
  id VARCHAR(255) PRIMARY KEY DEFAULT gen_random_uuid()::text,
  audit_record_id VARCHAR(255) NOT NULL REFERENCES audit_records(id) ON DELETE CASCADE,
  version INTEGER NOT NULL DEFAULT 1,
  changed_by VARCHAR(255) NOT NULL REFERENCES users(id) ON DELETE SET NULL,
  changed_at TIMESTAMP NOT NULL DEFAULT now(),
  change_type TEXT NOT NULL, -- 'create', 'update', 'status_change', 'assignment_change'
  field_name TEXT, -- Name of the field that changed (if applicable)
  old_value JSONB, -- Previous value
  new_value JSONB, -- New value
  changes JSONB, -- Full change details
  snapshot JSONB, -- Full snapshot of audit record at this version
  notes TEXT
);

-- Create indexes for history table
CREATE INDEX IF NOT EXISTS idx_audit_record_history_audit_record_id ON audit_record_history(audit_record_id);
CREATE INDEX IF NOT EXISTS idx_audit_record_history_changed_at ON audit_record_history(changed_at);
CREATE INDEX IF NOT EXISTS idx_audit_record_history_change_type ON audit_record_history(change_type);

-- Add comment
COMMENT ON TABLE audit_records IS 'Yearly audit records linked to entities - one audit per entity per year';
COMMENT ON TABLE audit_record_history IS 'Version history for audit records - tracks all changes for audit trail';

