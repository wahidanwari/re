-- Migration: Create ministry_reports table
-- Stores manual input fields for Ministry of Finance Detailed Audit Reports
-- Each record represents one group's report data for a specific month/year

DO $$
BEGIN
  IF NOT EXISTS (SELECT FROM information_schema.tables WHERE table_name = 'ministry_reports') THEN
    CREATE TABLE ministry_reports (
      id VARCHAR PRIMARY KEY DEFAULT gen_random_uuid()::text,
      group_id VARCHAR NOT NULL REFERENCES groups(id) ON DELETE CASCADE,
      month_shamsi INTEGER NOT NULL CHECK (month_shamsi >= 1 AND month_shamsi <= 12),
      year_shamsi INTEGER NOT NULL CHECK (year_shamsi >= 1300 AND year_shamsi <= 1500),
      
      -- Manual input fields (filled by Senior Auditor)
      letters_received INTEGER DEFAULT 0, -- تعداد مکتوب های وارده
      letters_sent INTEGER DEFAULT 0, -- تعداد مکتوب های صادره
      inquiries_received INTEGER DEFAULT 0, -- تعداد استعلام های وارده
      inquiries_sent INTEGER DEFAULT 0, -- تعداد استعلام های صادره
      notes TEXT, -- ملاحظات
      
      -- Metadata
      last_updated_by VARCHAR REFERENCES users(id) ON DELETE SET NULL,
      last_updated_at TIMESTAMP DEFAULT NOW(),
      created_at TIMESTAMP DEFAULT NOW(),
      
      -- Unique constraint: one report per group per month/year
      UNIQUE(group_id, month_shamsi, year_shamsi)
    );

    -- Create indexes for faster lookups
    CREATE INDEX idx_ministry_reports_group ON ministry_reports(group_id);
    CREATE INDEX idx_ministry_reports_month_year ON ministry_reports(year_shamsi, month_shamsi);
    CREATE INDEX idx_ministry_reports_updated ON ministry_reports(last_updated_at DESC);

    -- Add comment
    COMMENT ON TABLE ministry_reports IS 'Stores manual input fields for Ministry of Finance Detailed Audit Reports';
    COMMENT ON COLUMN ministry_reports.letters_received IS 'تعداد مکتوب های وارده';
    COMMENT ON COLUMN ministry_reports.letters_sent IS 'تعداد مکتوب های صادره';
    COMMENT ON COLUMN ministry_reports.inquiries_received IS 'تعداد استعلام های وارده';
    COMMENT ON COLUMN ministry_reports.inquiries_sent IS 'تعداد استعلام های صادره';
    COMMENT ON COLUMN ministry_reports.notes IS 'ملاحظات';

    RAISE NOTICE 'Table ministry_reports created successfully';
  ELSE
    RAISE NOTICE 'Table ministry_reports already exists, skipping creation';
  END IF;
END $$;

