-- Migration: Add transactionId and paymentDate fields to cases table
-- These fields replace the old آویز fields (نمبر آویز, تاریخ آویز, برج, سال)

-- Add transactionId field (نمبر آویز)
ALTER TABLE cases 
ADD COLUMN IF NOT EXISTS transaction_id TEXT;

-- Add paymentDate field (تاریخ پرداخت مالیات) - stored in DD-MM-YYYY format (Shamsi)
ALTER TABLE cases 
ADD COLUMN IF NOT EXISTS payment_date TEXT;

-- Add comments
COMMENT ON COLUMN cases.transaction_id IS 'نمبر آویز';
COMMENT ON COLUMN cases.payment_date IS 'تاریخ پرداخت مالیات (فرمت: DD-MM-YYYY شمسی)';

