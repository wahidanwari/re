-- Migration: Merge referralDate and receivedDate into createdDate
-- Renames received_date to created_date and removes referral_date

-- Step 1: Rename received_date to created_date if it exists
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.columns 
             WHERE table_name = 'entities' AND column_name = 'received_date') THEN
    ALTER TABLE entities RENAME COLUMN received_date TO created_date;
  END IF;
END $$;

-- Step 2: If created_date doesn't exist (neither received_date existed), create it
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                 WHERE table_name = 'entities' AND column_name = 'created_date') THEN
    ALTER TABLE entities ADD COLUMN created_date TIMESTAMP;
  END IF;
END $$;

-- Step 3: Drop referral_date column if it exists (no longer needed)
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.columns 
             WHERE table_name = 'entities' AND column_name = 'referral_date') THEN
    ALTER TABLE entities DROP COLUMN referral_date;
  END IF;
END $$;

-- Step 4: Add comment
COMMENT ON COLUMN entities.created_date IS 'تاریخ ایجاد شده - تاریخ ایجاد نهاد در بخش بررسی';

