-- Migration: Add reports:override_complete permission to RBAC system
-- This is optional - permission works via code-based system (shared/permissions.ts),
-- but DB entry ensures consistency and allows future admin UI management
--
-- Run this migration if you want the permission in the database RBAC tables
-- If skipped, the permission will still work via code-based permissions

-- Insert permission if it doesn't exist
INSERT INTO permissions (name, description)
SELECT 'reports:override_complete', 'Allow override of report validation when completing cases'
WHERE NOT EXISTS (
  SELECT 1 FROM permissions WHERE name = 'reports:override_complete'
);

-- Grant to director role (if director role exists)
DO $$
DECLARE
  director_role_id INT;
  perm_id INT;
BEGIN
  SELECT id INTO director_role_id FROM roles WHERE name = 'director' LIMIT 1;
  SELECT id INTO perm_id FROM permissions WHERE name = 'reports:override_complete' LIMIT 1;
  
  IF director_role_id IS NOT NULL AND perm_id IS NOT NULL THEN
    -- Check if record already exists
    IF NOT EXISTS (
      SELECT 1 FROM role_permissions 
      WHERE role_id = director_role_id AND permission_id = perm_id
    ) THEN
      INSERT INTO role_permissions (role_id, permission_id, allow)
      VALUES (director_role_id, perm_id, TRUE);
    ELSE
      -- Update if exists
      UPDATE role_permissions 
      SET allow = TRUE 
      WHERE role_id = director_role_id AND permission_id = perm_id;
    END IF;
  END IF;
END $$;

-- Grant to senior_auditor role (if exists)
DO $$
DECLARE
  senior_auditor_role_id INT;
  perm_id INT;
BEGIN
  SELECT id INTO senior_auditor_role_id FROM roles WHERE name = 'senior_auditor' LIMIT 1;
  SELECT id INTO perm_id FROM permissions WHERE name = 'reports:override_complete' LIMIT 1;
  
  IF senior_auditor_role_id IS NOT NULL AND perm_id IS NOT NULL THEN
    -- Check if record already exists
    IF NOT EXISTS (
      SELECT 1 FROM role_permissions 
      WHERE role_id = senior_auditor_role_id AND permission_id = perm_id
    ) THEN
      INSERT INTO role_permissions (role_id, permission_id, allow)
      VALUES (senior_auditor_role_id, perm_id, TRUE);
    ELSE
      -- Update if exists
      UPDATE role_permissions 
      SET allow = TRUE 
      WHERE role_id = senior_auditor_role_id AND permission_id = perm_id;
    END IF;
  END IF;
END $$;

-- Verify migration
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM permissions WHERE name = 'reports:override_complete') THEN
    RAISE NOTICE 'Migration successful: reports:override_complete permission added';
  ELSE
    RAISE WARNING 'Migration may have failed: permission not found';
  END IF;
END $$;

