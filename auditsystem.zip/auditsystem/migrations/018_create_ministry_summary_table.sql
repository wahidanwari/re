-- Migration: Create ministry_summary table
-- WORKFLOW TABLE: Temporary table for ministry-level reporting workflow calculations
-- Aggregates per-group monthly summaries from internal_report for ministry reporting
-- This table is read-only from master entities and groups tables and used for workflow calculations

DO $$
BEGIN
  IF NOT EXISTS (SELECT FROM information_schema.tables WHERE table_name = 'ministry_summary') THEN
    CREATE TABLE ministry_summary (
      id VARCHAR PRIMARY KEY DEFAULT gen_random_uuid()::text,
      
      -- Group Link (گروه ارجاع‌دهنده)
      group_id VARCHAR, -- Group ID - links to groups.id (can be NULL for static groups)
      group_name TEXT NOT NULL, -- Group Name: نام گروه - from groups.name or static group name
      group_code TEXT, -- Group Code: کد گروه - from groups.code (if exists)
      
      -- Time Period (Shamsi Calendar)
      month_shamsi INTEGER NOT NULL CHECK (month_shamsi >= 1 AND month_shamsi <= 12), -- Month: برج
      year_shamsi INTEGER NOT NULL CHECK (year_shamsi >= 1300 AND year_shamsi <= 1500), -- Year: سال
      
      -- Entity Counts
      total_entities INTEGER DEFAULT 0, -- TotalEntities: Count of entities in the group
      finalized_entities INTEGER DEFAULT 0, -- FinalizedEntities: Entities with RemainingAmount = 0
      partially_compliant_entities INTEGER DEFAULT 0, -- PartiallyCompliantEntities: Entities with 0 < RemainingAmount < TotalTaxableAmount
      non_compliant_entities INTEGER DEFAULT 0, -- NonCompliantEntities: Entities with RemainingAmount = TotalTaxableAmount
      
      -- Revenue Data
      revenue_collected NUMERIC(15, 2) DEFAULT 0, -- RevenueCollected: Sum of CollectedAmount
      monthly_revenue_target NUMERIC(15, 2), -- MonthlyRevenueTarget: Target revenue for the month (from group_targets)
      percent_variation NUMERIC(5, 2), -- PercentVariation: (RevenueCollected / MonthlyRevenueTarget) * 100
      
      -- Correspondence & Inquiry Data
      incoming_letters INTEGER DEFAULT 0, -- IncomingLetters: Sum of CorrespondencesIn
      outgoing_letters INTEGER DEFAULT 0, -- OutgoingLetters: Sum of CorrespondencesOut
      incoming_inquiries INTEGER DEFAULT 0, -- IncomingInquiries: Sum of InquiriesIn
      outgoing_inquiries INTEGER DEFAULT 0, -- OutgoingInquiries: Sum of InquiriesOut
      
      -- Status
      status TEXT NOT NULL DEFAULT 'active', -- Status: 'active' or 'inactive'
      
      -- Notes
      notes TEXT, -- Notes: ملاحظات
      
      -- Metadata
      created_at TIMESTAMP DEFAULT NOW(),
      updated_at TIMESTAMP DEFAULT NOW(),
      
      -- Unique constraint: one summary per group per month/year
      UNIQUE(group_name, month_shamsi, year_shamsi)
    );

    -- Create indexes for faster lookups
    CREATE INDEX idx_ministry_summary_group_id ON ministry_summary(group_id) WHERE group_id IS NOT NULL;
    CREATE INDEX idx_ministry_summary_group_name ON ministry_summary(group_name);
    CREATE INDEX idx_ministry_summary_month_year ON ministry_summary(year_shamsi, month_shamsi);
    CREATE INDEX idx_ministry_summary_status ON ministry_summary(status);
    CREATE INDEX idx_ministry_summary_updated ON ministry_summary(updated_at DESC);

    -- Add comments
    COMMENT ON TABLE ministry_summary IS 'WORKFLOW TABLE: Aggregates per-group monthly summaries from internal_report for ministry reporting. Links to groups via referral group from entities.';
    COMMENT ON COLUMN ministry_summary.id IS 'Primary key - Workflow-generated unique ID';
    COMMENT ON COLUMN ministry_summary.group_id IS 'Group ID - Links to groups.id (can be NULL for static groups)';
    COMMENT ON COLUMN ministry_summary.group_name IS 'Group Name: نام گروه - From groups.name or static group name';
    COMMENT ON COLUMN ministry_summary.group_code IS 'Group Code: کد گروه - From groups.code (if exists)';
    COMMENT ON COLUMN ministry_summary.month_shamsi IS 'Month: برج (1-12)';
    COMMENT ON COLUMN ministry_summary.year_shamsi IS 'Year: سال (Shamsi year, e.g., 1404)';
    COMMENT ON COLUMN ministry_summary.total_entities IS 'TotalEntities: Count of entities in the group';
    COMMENT ON COLUMN ministry_summary.finalized_entities IS 'FinalizedEntities: Entities with RemainingAmount = 0';
    COMMENT ON COLUMN ministry_summary.partially_compliant_entities IS 'PartiallyCompliantEntities: Entities with 0 < RemainingAmount < TotalTaxableAmount';
    COMMENT ON COLUMN ministry_summary.non_compliant_entities IS 'NonCompliantEntities: Entities with RemainingAmount = TotalTaxableAmount';
    COMMENT ON COLUMN ministry_summary.revenue_collected IS 'RevenueCollected: Sum of CollectedAmount';
    COMMENT ON COLUMN ministry_summary.monthly_revenue_target IS 'MonthlyRevenueTarget: Target revenue for the month (from group_targets)';
    COMMENT ON COLUMN ministry_summary.percent_variation IS 'PercentVariation: (RevenueCollected / MonthlyRevenueTarget) * 100';
    COMMENT ON COLUMN ministry_summary.incoming_letters IS 'IncomingLetters: Sum of CorrespondencesIn';
    COMMENT ON COLUMN ministry_summary.outgoing_letters IS 'OutgoingLetters: Sum of CorrespondencesOut';
    COMMENT ON COLUMN ministry_summary.incoming_inquiries IS 'IncomingInquiries: Sum of InquiriesIn';
    COMMENT ON COLUMN ministry_summary.outgoing_inquiries IS 'OutgoingInquiries: Sum of InquiriesOut';
    COMMENT ON COLUMN ministry_summary.status IS 'Status: active or inactive';

    RAISE NOTICE 'Table ministry_summary created successfully';
  ELSE
    RAISE NOTICE 'Table ministry_summary already exists, skipping creation';
  END IF;
END $$;

-- Create a view for overall monthly totals across all groups
-- This provides ministry-level totals for a given month/year
CREATE OR REPLACE VIEW ministry_summary_monthly_totals AS
SELECT 
  month_shamsi,
  year_shamsi,
  COUNT(DISTINCT group_name) as group_count,
  SUM(total_entities) as total_entities,
  SUM(finalized_entities) as total_finalized_entities,
  SUM(partially_compliant_entities) as total_partially_compliant_entities,
  SUM(non_compliant_entities) as total_non_compliant_entities,
  SUM(revenue_collected) as total_revenue_collected,
  SUM(monthly_revenue_target) as total_revenue_target,
  AVG(percent_variation) as overall_percent_variation,
  SUM(incoming_letters) as total_incoming_letters,
  SUM(outgoing_letters) as total_outgoing_letters,
  SUM(incoming_inquiries) as total_incoming_inquiries,
  SUM(outgoing_inquiries) as total_outgoing_inquiries
FROM ministry_summary
WHERE status = 'active'
GROUP BY month_shamsi, year_shamsi;

COMMENT ON VIEW ministry_summary_monthly_totals IS 'Ministry-level monthly totals aggregated across all active groups';

