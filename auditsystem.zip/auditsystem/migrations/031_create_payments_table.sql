-- Migration: Create payments table for payment traceability
-- PHASE 1: Payment Traceability Foundation
-- Purpose: Enable reliable, traceable payment ledger so that every tax payment can be queried by month

-- Create payments table
CREATE TABLE IF NOT EXISTS payments (
  id VARCHAR PRIMARY KEY DEFAULT gen_random_uuid(),
  case_id VARCHAR NOT NULL REFERENCES cases(id) ON DELETE CASCADE,
  payment_date TIMESTAMP WITH TIME ZONE NOT NULL,
  payment_amount NUMERIC(15, 2) NOT NULL,
  payment_type VARCHAR(20) NOT NULL CHECK (payment_type IN ('normal', 'installment')),
  created_at TIMESTAMP DEFAULT NOW()
);

-- Create indexes for efficient querying
CREATE INDEX IF NOT EXISTS idx_payments_case_id ON payments(case_id);
CREATE INDEX IF NOT EXISTS idx_payments_payment_date ON payments(payment_date);
CREATE INDEX IF NOT EXISTS idx_payments_payment_type ON payments(payment_type);
CREATE INDEX IF NOT EXISTS idx_payments_created_at ON payments(created_at);

-- Composite index for month-based queries (case_id + payment_date)
CREATE INDEX IF NOT EXISTS idx_payments_case_date ON payments(case_id, payment_date);

-- Add comments
COMMENT ON TABLE payments IS 'Payment ledger for traceable tax payments - PHASE 1: Payment Traceability Foundation';
COMMENT ON COLUMN payments.case_id IS 'Foreign key to cases table';
COMMENT ON COLUMN payments.payment_date IS 'Date of payment (required)';
COMMENT ON COLUMN payments.payment_amount IS 'Payment amount (required)';
COMMENT ON COLUMN payments.payment_type IS 'Type of payment: normal (from case report) or installment (from installment payment modal)';
COMMENT ON COLUMN payments.created_at IS 'Timestamp when payment record was created';

