-- Migration: Add completedBy field to cases table
-- Tracks who completed a case (auditor or senior auditor)

-- Add completedBy column to cases table
ALTER TABLE cases ADD COLUMN IF NOT EXISTS completed_by VARCHAR(255);

-- Add index for faster queries on completedBy
CREATE INDEX IF NOT EXISTS idx_cases_completed_by ON cases(completed_by);

-- Add foreign key constraint to users table (optional, for referential integrity)
-- ALTER TABLE cases ADD CONSTRAINT fk_cases_completed_by 
--   FOREIGN KEY (completed_by) REFERENCES users(id) ON DELETE SET NULL;

