-- Migration: Canonical RBAC System
-- Creates roles, permissions, packages, and audit_logs tables

-- Roles table
-- Create only if it doesn't exist, or ensure it has SERIAL id
DO $$
BEGIN
  IF NOT EXISTS (SELECT FROM information_schema.tables WHERE table_name = 'roles') THEN
    CREATE TABLE roles (
      id SERIAL PRIMARY KEY,
      name VARCHAR(64) UNIQUE NOT NULL,
      description TEXT
    );
  ELSE
    -- Table exists (created by Drizzle), ensure id is SERIAL
    -- Check if id column is SERIAL, if not, alter it
    IF NOT EXISTS (
      SELECT 1 FROM information_schema.columns 
      WHERE table_name = 'roles' 
      AND column_name = 'id' 
      AND column_default LIKE 'nextval%'
    ) THEN
      -- Convert id to SERIAL by creating sequence and setting default
      CREATE SEQUENCE IF NOT EXISTS roles_id_seq;
      ALTER TABLE roles ALTER COLUMN id SET DEFAULT nextval('roles_id_seq');
      -- Note: Sequence will be set after INSERTs below
    END IF;
  END IF;
END $$;

-- Permissions table
DO $$
BEGIN
  IF NOT EXISTS (SELECT FROM information_schema.tables WHERE table_name = 'permissions') THEN
    CREATE TABLE permissions (
      id SERIAL PRIMARY KEY,
      name VARCHAR(128) UNIQUE NOT NULL,
      description TEXT
    );
  ELSE
    -- Ensure id is SERIAL
    IF NOT EXISTS (
      SELECT 1 FROM information_schema.columns 
      WHERE table_name = 'permissions' 
      AND column_name = 'id' 
      AND column_default LIKE 'nextval%'
    ) THEN
      CREATE SEQUENCE IF NOT EXISTS permissions_id_seq;
      ALTER TABLE permissions ALTER COLUMN id SET DEFAULT nextval('permissions_id_seq');
      -- Note: Sequence will be set after INSERTs below
    END IF;
  END IF;
END $$;

-- Role-Permission mapping
DO $$
BEGIN
  IF NOT EXISTS (SELECT FROM information_schema.tables WHERE table_name = 'role_permissions') THEN
    CREATE TABLE role_permissions (
      id SERIAL PRIMARY KEY,
      role_id INT NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
      permission_id INT NOT NULL REFERENCES permissions(id) ON DELETE CASCADE,
      allow BOOLEAN NOT NULL DEFAULT TRUE,
      UNIQUE(role_id, permission_id)
    );
  ELSE
    -- Table exists (created by Drizzle), ensure unique constraint exists
    BEGIN
      ALTER TABLE role_permissions ADD CONSTRAINT role_permissions_role_id_permission_id_unique 
      UNIQUE (role_id, permission_id);
    EXCEPTION 
      WHEN duplicate_object THEN
        -- Constraint already exists, ignore
        NULL;
      WHEN OTHERS THEN
        -- Check if any unique constraint exists on this table
        IF NOT EXISTS (
          SELECT 1 FROM pg_constraint 
          WHERE conrelid = 'role_permissions'::regclass 
          AND contype = 'u'
        ) THEN
          RAISE;
        END IF;
    END;
    -- Ensure id is SERIAL
    IF NOT EXISTS (
      SELECT 1 FROM information_schema.columns 
      WHERE table_name = 'role_permissions' 
      AND column_name = 'id' 
      AND column_default LIKE 'nextval%'
    ) THEN
      CREATE SEQUENCE IF NOT EXISTS role_permissions_id_seq;
      ALTER TABLE role_permissions ALTER COLUMN id SET DEFAULT nextval('role_permissions_id_seq');
    END IF;
  END IF;
END $$;

-- Packages table
DO $$
BEGIN
  IF NOT EXISTS (SELECT FROM information_schema.tables WHERE table_name = 'packages') THEN
    CREATE TABLE packages (
      id SERIAL PRIMARY KEY,
      name VARCHAR(64) UNIQUE NOT NULL,
      description TEXT
    );
  ELSE
    -- Ensure id is SERIAL
    IF NOT EXISTS (
      SELECT 1 FROM information_schema.columns 
      WHERE table_name = 'packages' 
      AND column_name = 'id' 
      AND column_default LIKE 'nextval%'
    ) THEN
      CREATE SEQUENCE IF NOT EXISTS packages_id_seq;
      ALTER TABLE packages ALTER COLUMN id SET DEFAULT nextval('packages_id_seq');
      -- Note: Sequence will be set after INSERTs below
    END IF;
  END IF;
END $$;

-- Package-Permission mapping
DO $$
BEGIN
  IF NOT EXISTS (SELECT FROM information_schema.tables WHERE table_name = 'package_permissions') THEN
    CREATE TABLE package_permissions (
      id SERIAL PRIMARY KEY,
      package_id INT NOT NULL REFERENCES packages(id) ON DELETE CASCADE,
      permission_id INT NOT NULL REFERENCES permissions(id) ON DELETE CASCADE,
      allow BOOLEAN NOT NULL DEFAULT TRUE,
      UNIQUE(package_id, permission_id)
    );
  ELSE
    -- Table exists (created by Drizzle), ensure unique constraint exists
    BEGIN
      ALTER TABLE package_permissions ADD CONSTRAINT package_permissions_package_id_permission_id_unique 
      UNIQUE (package_id, permission_id);
    EXCEPTION 
      WHEN duplicate_object THEN
        NULL;
      WHEN OTHERS THEN
        IF NOT EXISTS (
          SELECT 1 FROM pg_constraint 
          WHERE conrelid = 'package_permissions'::regclass 
          AND contype = 'u'
        ) THEN
          RAISE;
        END IF;
    END;
    -- Ensure id is SERIAL
    IF NOT EXISTS (
      SELECT 1 FROM information_schema.columns 
      WHERE table_name = 'package_permissions' 
      AND column_name = 'id' 
      AND column_default LIKE 'nextval%'
    ) THEN
      CREATE SEQUENCE IF NOT EXISTS package_permissions_id_seq;
      ALTER TABLE package_permissions ALTER COLUMN id SET DEFAULT nextval('package_permissions_id_seq');
    END IF;
  END IF;
END $$;

-- User-Role mapping (users can have one base role)
DO $$
BEGIN
  IF NOT EXISTS (SELECT FROM information_schema.tables WHERE table_name = 'user_roles') THEN
    CREATE TABLE user_roles (
      id SERIAL PRIMARY KEY,
      user_id VARCHAR(255) NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      role_id INT NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
      assigned_at TIMESTAMP DEFAULT now(),
      UNIQUE(user_id, role_id)
    );
  ELSE
    -- Table exists (created by Drizzle), ensure unique constraint exists
    BEGIN
      ALTER TABLE user_roles ADD CONSTRAINT user_roles_user_id_role_id_unique 
      UNIQUE (user_id, role_id);
    EXCEPTION 
      WHEN duplicate_object THEN
        NULL;
      WHEN OTHERS THEN
        IF NOT EXISTS (
          SELECT 1 FROM pg_constraint 
          WHERE conrelid = 'user_roles'::regclass 
          AND contype = 'u'
        ) THEN
          RAISE;
        END IF;
    END;
    -- Ensure id is SERIAL
    IF NOT EXISTS (
      SELECT 1 FROM information_schema.columns 
      WHERE table_name = 'user_roles' 
      AND column_name = 'id' 
      AND column_default LIKE 'nextval%'
    ) THEN
      CREATE SEQUENCE IF NOT EXISTS user_roles_id_seq;
      ALTER TABLE user_roles ALTER COLUMN id SET DEFAULT nextval('user_roles_id_seq');
    END IF;
  END IF;
END $$;

-- User-Package mapping (users can have multiple packages)
DO $$
BEGIN
  IF NOT EXISTS (SELECT FROM information_schema.tables WHERE table_name = 'user_packages') THEN
    CREATE TABLE user_packages (
      id SERIAL PRIMARY KEY,
      user_id VARCHAR(255) NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      package_id INT NOT NULL REFERENCES packages(id) ON DELETE CASCADE,
      assigned_at TIMESTAMP DEFAULT now(),
      expires_at TIMESTAMP NULL,
      UNIQUE(user_id, package_id)
    );
  ELSE
    -- Table exists (created by Drizzle), ensure unique constraint exists
    BEGIN
      ALTER TABLE user_packages ADD CONSTRAINT user_packages_user_id_package_id_unique 
      UNIQUE (user_id, package_id);
    EXCEPTION 
      WHEN duplicate_object THEN
        NULL;
      WHEN OTHERS THEN
        IF NOT EXISTS (
          SELECT 1 FROM pg_constraint 
          WHERE conrelid = 'user_packages'::regclass 
          AND contype = 'u'
        ) THEN
          RAISE;
        END IF;
    END;
    -- Ensure id is SERIAL
    IF NOT EXISTS (
      SELECT 1 FROM information_schema.columns 
      WHERE table_name = 'user_packages' 
      AND column_name = 'id' 
      AND column_default LIKE 'nextval%'
    ) THEN
      CREATE SEQUENCE IF NOT EXISTS user_packages_id_seq;
      ALTER TABLE user_packages ALTER COLUMN id SET DEFAULT nextval('user_packages_id_seq');
    END IF;
  END IF;
END $$;

-- Enhanced audit_logs table migration
-- Only migrate if old structure exists (with old_value/new_value columns)
-- If table already has new structure (created by Drizzle), skip migration
DO $$
BEGIN
  -- Check if audit_logs exists AND has old structure columns
  IF EXISTS (SELECT FROM information_schema.tables WHERE table_name = 'audit_logs')
     AND EXISTS (
       SELECT 1 FROM information_schema.columns 
       WHERE table_name = 'audit_logs' 
       AND column_name IN ('old_value', 'new_value')
     ) THEN
    -- Old structure exists, migrate to new structure
    CREATE TABLE IF NOT EXISTS audit_logs_new (
      id SERIAL PRIMARY KEY,
      user_id VARCHAR(255) NULL REFERENCES users(id) ON DELETE SET NULL,
      action VARCHAR(128) NOT NULL,
      details JSONB,
      entity_type VARCHAR(64),
      entity_id VARCHAR(255),
      ip_address VARCHAR(45),
      created_at TIMESTAMP DEFAULT now()
    );

    -- Migrate data from old structure
    INSERT INTO audit_logs_new (user_id, action, details, entity_type, entity_id, ip_address, created_at)
    SELECT 
      user_id::text,
      action,
      CASE 
        WHEN old_value IS NOT NULL OR new_value IS NOT NULL THEN
          jsonb_build_object('old_value', old_value, 'new_value', new_value)
        ELSE NULL
      END as details,
      entity_type,
      entity_id,
      ip_address,
      created_at
    FROM audit_logs;
    
    DROP TABLE audit_logs;
    ALTER TABLE audit_logs_new RENAME TO audit_logs;
  END IF;
  -- If table doesn't exist or already has new structure, Drizzle handles it
END $$;

-- Add case_number column to cases table
ALTER TABLE cases ADD COLUMN IF NOT EXISTS case_number INTEGER UNIQUE;

-- Create index for case_number
CREATE UNIQUE INDEX IF NOT EXISTS ux_cases_case_number ON cases(case_number) WHERE case_number IS NOT NULL;

-- Populate roles
-- Use explicit IDs to avoid SERIAL sequence issues
INSERT INTO roles (id, name, description) VALUES
  (1, 'system_admin', 'System Administrator - Full system control'),
  (2, 'director', 'Director - Oversight, final approvals, system-wide reporting'),
  (3, 'senior_auditor', 'Senior Auditor - Team lead, manages workflow of auditors'),
  (4, 'auditor', 'Auditor - Base-level user working on assigned cases')
ON CONFLICT (name) DO NOTHING;

-- Ensure sequence is set correctly after inserts
SELECT setval('roles_id_seq', COALESCE((SELECT MAX(id) FROM roles), 0) + 1, false);

-- Populate permissions
-- Use explicit IDs to avoid SERIAL sequence issues
INSERT INTO permissions (id, name, description) VALUES
  (1, 'cases:read_all', 'Read all cases'),
  (2, 'cases:read_assigned', 'Read assigned cases'),
  (3, 'cases:assign_to_groups', 'Assign cases to groups'),
  (4, 'cases:assign_to_auditors', 'Assign cases to auditors'),
  (5, 'cases:update_progress', 'Update case progress'),
  (6, 'users:manage_all', 'Manage all users'),
  (7, 'groups:manage_all', 'Manage all groups'),
  (8, 'groups:manage_own', 'Manage own group'),
  (9, 'approvals:create_tickets', 'Create approval tickets'),
  (10, 'approvals:approve_tickets', 'Approve/reject tickets'),
  (11, 'reports:system_wide', 'View system-wide reports'),
  (12, 'reports:internal', 'View internal reports'),
  (13, 'reports:group_level', 'View group-level reports'),
  (14, 'system:manage_settings', 'Manage system settings')
ON CONFLICT (name) DO NOTHING;

-- Ensure sequence is set correctly after inserts
SELECT setval('permissions_id_seq', COALESCE((SELECT MAX(id) FROM permissions), 0) + 1, false);

-- Populate packages
-- Use explicit IDs to avoid SERIAL sequence issues
INSERT INTO packages (id, name, description) VALUES
  (1, 'acting_coordinator', 'Acting Coordinator Package - Grants cases:assign_to_groups, groups:manage_all, reports:internal'),
  (2, 'approval_authority', 'Approval Authority Package - Grants approvals:approve_tickets')
ON CONFLICT (name) DO NOTHING;

-- Ensure sequence is set correctly after inserts
SELECT setval('packages_id_seq', COALESCE((SELECT MAX(id) FROM packages), 0) + 1, false);

-- Get role IDs (using subqueries)
DO $$
DECLARE
  sys_admin_id INT;
  director_id INT;
  senior_auditor_id INT;
  auditor_id INT;
  acting_coord_id INT;
  approval_auth_id INT;
BEGIN
  SELECT id INTO sys_admin_id FROM roles WHERE name = 'system_admin';
  SELECT id INTO director_id FROM roles WHERE name = 'director';
  SELECT id INTO senior_auditor_id FROM roles WHERE name = 'senior_auditor';
  SELECT id INTO auditor_id FROM roles WHERE name = 'auditor';
  SELECT id INTO acting_coord_id FROM packages WHERE name = 'acting_coordinator';
  SELECT id INTO approval_auth_id FROM packages WHERE name = 'approval_authority';

  -- System Admin: All permissions
  INSERT INTO role_permissions (role_id, permission_id, allow)
  SELECT sys_admin_id, id, TRUE FROM permissions
  ON CONFLICT (role_id, permission_id) DO UPDATE SET allow = TRUE;

  -- Director: Read cases, approve tickets, view reports
  INSERT INTO role_permissions (role_id, permission_id, allow)
  SELECT director_id, id, TRUE FROM permissions
  WHERE name IN ('cases:read_all', 'cases:read_assigned', 'approvals:approve_tickets', 
                 'reports:system_wide', 'reports:internal', 'reports:group_level')
  ON CONFLICT (role_id, permission_id) DO UPDATE SET allow = TRUE;

  -- Senior Auditor: Read cases, assign to auditors, update progress, manage own group, create tickets, group reports
  INSERT INTO role_permissions (role_id, permission_id, allow)
  SELECT senior_auditor_id, id, TRUE FROM permissions
  WHERE name IN ('cases:read_all', 'cases:read_assigned', 'cases:assign_to_auditors', 
                 'cases:update_progress', 'groups:manage_own', 'approvals:create_tickets', 
                 'reports:group_level')
  ON CONFLICT (role_id, permission_id) DO UPDATE SET allow = TRUE;

  -- Auditor: Read assigned cases, update progress, create tickets
  INSERT INTO role_permissions (role_id, permission_id, allow)
  SELECT auditor_id, id, TRUE FROM permissions
  WHERE name IN ('cases:read_assigned', 'cases:update_progress', 'approvals:create_tickets')
  ON CONFLICT (role_id, permission_id) DO UPDATE SET allow = TRUE;

  -- Acting Coordinator Package
  INSERT INTO package_permissions (package_id, permission_id, allow)
  SELECT acting_coord_id, id, TRUE FROM permissions
  WHERE name IN ('cases:assign_to_groups', 'groups:manage_all', 'reports:internal')
  ON CONFLICT (package_id, permission_id) DO UPDATE SET allow = TRUE;

  -- Approval Authority Package
  INSERT INTO package_permissions (package_id, permission_id, allow)
  SELECT approval_auth_id, id, TRUE FROM permissions
  WHERE name IN ('approvals:approve_tickets')
  ON CONFLICT (package_id, permission_id) DO UPDATE SET allow = TRUE;
END $$;

-- Migrate existing users to user_roles table
DO $$
DECLARE
  user_record RECORD;
  role_id_val INT;
BEGIN
  FOR user_record IN SELECT id, role FROM users LOOP
    SELECT id INTO role_id_val FROM roles WHERE name = user_record.role;
    IF role_id_val IS NOT NULL THEN
      INSERT INTO user_roles (user_id, role_id)
      VALUES (user_record.id, role_id_val)
      ON CONFLICT (user_id, role_id) DO NOTHING;
    END IF;
  END LOOP;
END $$;

-- Migrate existing permission packages to user_packages
DO $$
DECLARE
  user_record RECORD;
  package_id_val INT;
  package_name TEXT;
BEGIN
  FOR user_record IN SELECT id, permission_packages FROM users WHERE permission_packages IS NOT NULL LOOP
    FOREACH package_name IN ARRAY user_record.permission_packages LOOP
      SELECT id INTO package_id_val FROM packages WHERE name = package_name;
      IF package_id_val IS NOT NULL THEN
        INSERT INTO user_packages (user_id, package_id)
        VALUES (user_record.id, package_id_val)
        ON CONFLICT (user_id, package_id) DO NOTHING;
      END IF;
    END LOOP;
  END LOOP;
END $$;

