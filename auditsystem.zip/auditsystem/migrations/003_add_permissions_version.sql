-- Migration: Add permissions_version to users table
-- This version stamp is incremented whenever user roles or permission packages change
-- Clients can compare versions to detect permission changes

-- Add permissions_version column to users table
ALTER TABLE users 
ADD COLUMN IF NOT EXISTS permissions_version INTEGER DEFAULT 1;

-- Initialize all existing users with version 1
UPDATE users SET permissions_version = 1 WHERE permissions_version IS NULL;

-- Create index for faster lookups
CREATE INDEX IF NOT EXISTS idx_users_permissions_version ON users(permissions_version);

