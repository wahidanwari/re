-- Migration: Case Status State Machine
-- Creates status enum, constraints, and transition history table

-- Step 1: Add status check constraint to cases table
DO $$
BEGIN
  -- Drop existing constraint if it exists
  ALTER TABLE cases DROP CONSTRAINT IF EXISTS cases_status_check;
  
  -- Add check constraint for valid status values
  ALTER TABLE cases
    ADD CONSTRAINT cases_status_check 
    CHECK (status IN ('جدید', 'اختصاص داده شده', 'در جریان بررسی', 'تکمیل شده', 'منتظر تایید', 'تایید شده', 'رد شده'));
END $$;

-- Step 2: Create case_status_transitions table
DO $$
BEGIN
  IF NOT EXISTS (SELECT FROM information_schema.tables WHERE table_name = 'case_status_transitions') THEN
    CREATE TABLE case_status_transitions (
      id VARCHAR PRIMARY KEY DEFAULT gen_random_uuid()::text,
      case_id VARCHAR NOT NULL REFERENCES cases(id) ON DELETE CASCADE,
      from_status TEXT NOT NULL,
      to_status TEXT NOT NULL,
      transition_name TEXT NOT NULL,
      transitioned_by VARCHAR NOT NULL REFERENCES users(id) ON DELETE SET NULL,
      transitioned_at TIMESTAMP NOT NULL DEFAULT NOW(),
      notes TEXT,
      rejection_reason TEXT,
      metadata JSONB,
      created_at TIMESTAMP NOT NULL DEFAULT NOW()
    );
    
    -- Create indexes
    CREATE INDEX idx_case_status_transitions_case_id ON case_status_transitions(case_id);
    CREATE INDEX idx_case_status_transitions_transitioned_at ON case_status_transitions(transitioned_at);
    CREATE INDEX idx_case_status_transitions_from_status ON case_status_transitions(from_status);
    CREATE INDEX idx_case_status_transitions_to_status ON case_status_transitions(to_status);
    CREATE INDEX idx_case_status_transitions_transitioned_by ON case_status_transitions(transitioned_by);
  END IF;
END $$;

-- Step 3: Add foreign key constraints for user references
DO $$
BEGIN
  -- Add foreign key for approved_by
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints 
    WHERE constraint_name = 'fk_cases_approved_by'
  ) THEN
    ALTER TABLE cases
      ADD CONSTRAINT fk_cases_approved_by 
      FOREIGN KEY (approved_by) REFERENCES users(id) ON DELETE SET NULL;
  END IF;
  
  -- Add foreign key for rejected_by
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints 
    WHERE constraint_name = 'fk_cases_rejected_by'
  ) THEN
    ALTER TABLE cases
      ADD CONSTRAINT fk_cases_rejected_by 
      FOREIGN KEY (rejected_by) REFERENCES users(id) ON DELETE SET NULL;
  END IF;
  
  -- Add foreign key for completed_by
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints 
    WHERE constraint_name = 'fk_cases_completed_by'
  ) THEN
    ALTER TABLE cases
      ADD CONSTRAINT fk_cases_completed_by 
      FOREIGN KEY (completed_by) REFERENCES users(id) ON DELETE SET NULL;
  END IF;
  
  -- Add foreign key for assigned_to
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints 
    WHERE constraint_name = 'fk_cases_assigned_to'
  ) THEN
    ALTER TABLE cases
      ADD CONSTRAINT fk_cases_assigned_to 
      FOREIGN KEY (assigned_to) REFERENCES users(id) ON DELETE SET NULL;
  END IF;
END $$;

-- Step 4: Add check constraints for business rules
DO $$
BEGIN
  -- Ensure approved cases have required fields
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints 
    WHERE constraint_name = 'cases_approved_check'
  ) THEN
    ALTER TABLE cases
      ADD CONSTRAINT cases_approved_check 
      CHECK (
        (status != 'تایید شده') OR 
        (approved_by IS NOT NULL AND approved_at IS NOT NULL)
      );
  END IF;
  
  -- Ensure rejected cases have required fields
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints 
    WHERE constraint_name = 'cases_rejected_check'
  ) THEN
    ALTER TABLE cases
      ADD CONSTRAINT cases_rejected_check 
      CHECK (
        (status != 'رد شده') OR 
        (rejected_by IS NOT NULL AND rejected_at IS NOT NULL AND rejection_reason IS NOT NULL)
      );
  END IF;
  
  -- Ensure completed cases have required fields
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints 
    WHERE constraint_name = 'cases_completed_check'
  ) THEN
    ALTER TABLE cases
      ADD CONSTRAINT cases_completed_check 
      CHECK (
        (status NOT IN ('تکمیل شده', 'منتظر تایید', 'تایید شده', 'رد شده')) OR 
        (completed_by IS NOT NULL AND completed_at IS NOT NULL)
      );
  END IF;
END $$;

-- Step 5: Create indexes for performance
DO $$
BEGIN
  -- Index on status for filtering
  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes WHERE indexname = 'idx_cases_status'
  ) THEN
    CREATE INDEX idx_cases_status ON cases(status);
  END IF;
  
  -- Index on assigned_to (partial, only for non-null values)
  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes WHERE indexname = 'idx_cases_assigned_to'
  ) THEN
    CREATE INDEX idx_cases_assigned_to ON cases(assigned_to) WHERE assigned_to IS NOT NULL;
  END IF;
  
  -- Index on receiving_group (partial, only for non-null values)
  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes WHERE indexname = 'idx_cases_receiving_group'
  ) THEN
    CREATE INDEX idx_cases_receiving_group ON cases(receiving_group) WHERE receiving_group IS NOT NULL;
  END IF;
END $$;

