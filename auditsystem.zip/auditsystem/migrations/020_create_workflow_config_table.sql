-- Migration: Create workflow_config table
-- Stores configuration for automated workflow processing
-- Allows scheduling and configuration of workflow runs for specific months/years

DO $$
BEGIN
  IF NOT EXISTS (SELECT FROM information_schema.tables WHERE table_name = 'workflow_config') THEN
    CREATE TABLE workflow_config (
      id VARCHAR PRIMARY KEY DEFAULT gen_random_uuid()::text,
      
      -- Configuration Name
      config_name TEXT NOT NULL UNIQUE, -- Name of the configuration (e.g., 'monthly_automation', 'manual_run_1404_10')
      
      -- Target Month/Year
      month_shamsi INTEGER NOT NULL CHECK (month_shamsi >= 1 AND month_shamsi <= 12), -- Month: برج
      year_shamsi INTEGER NOT NULL CHECK (year_shamsi >= 1300 AND year_shamsi <= 1500), -- Year: سال
      
      -- Automation Settings
      auto_run BOOLEAN DEFAULT false, -- Whether to automatically run this workflow
      run_on_day INTEGER CHECK (run_on_day >= 1 AND run_on_day <= 31), -- Day of month to run (for scheduling)
      last_run_at TIMESTAMP, -- Last time this workflow was run
      next_run_at TIMESTAMP, -- Next scheduled run time
      
      -- Processing Options
      append_mode BOOLEAN DEFAULT true, -- Append new transactions (true) or overwrite (false)
      regenerate_reports BOOLEAN DEFAULT true, -- Automatically regenerate InternalReport
      regenerate_summaries BOOLEAN DEFAULT true, -- Automatically regenerate MinistrySummary
      generate_alerts BOOLEAN DEFAULT true, -- Automatically generate alerts
      
      -- Status
      status TEXT NOT NULL DEFAULT 'pending', -- 'pending', 'running', 'completed', 'failed'
      last_status_message TEXT, -- Last status message or error
      
      -- Metadata
      created_by VARCHAR REFERENCES users(id) ON DELETE SET NULL,
      created_at TIMESTAMP DEFAULT NOW(),
      updated_at TIMESTAMP DEFAULT NOW()
    );

    -- Create indexes
    CREATE INDEX idx_workflow_config_month_year ON workflow_config(year_shamsi, month_shamsi);
    CREATE INDEX idx_workflow_config_auto_run ON workflow_config(auto_run) WHERE auto_run = true;
    CREATE INDEX idx_workflow_config_next_run ON workflow_config(next_run_at) WHERE next_run_at IS NOT NULL;
    CREATE INDEX idx_workflow_config_status ON workflow_config(status);

    -- Add comments
    COMMENT ON TABLE workflow_config IS 'Configuration for automated workflow processing. Allows scheduling workflow runs for specific months/years.';
    COMMENT ON COLUMN workflow_config.config_name IS 'Unique name for this configuration';
    COMMENT ON COLUMN workflow_config.month_shamsi IS 'Month: برج (1-12)';
    COMMENT ON COLUMN workflow_config.year_shamsi IS 'Year: سال (Shamsi year, e.g., 1404)';
    COMMENT ON COLUMN workflow_config.auto_run IS 'Whether to automatically run this workflow';
    COMMENT ON COLUMN workflow_config.append_mode IS 'Append new transactions (true) or overwrite existing (false)';
    COMMENT ON COLUMN workflow_config.regenerate_reports IS 'Automatically regenerate InternalReport after transactions';
    COMMENT ON COLUMN workflow_config.regenerate_summaries IS 'Automatically regenerate MinistrySummary after reports';
    COMMENT ON COLUMN workflow_config.generate_alerts IS 'Automatically generate alerts after summaries';

    RAISE NOTICE 'Table workflow_config created successfully';
  ELSE
    RAISE NOTICE 'Table workflow_config already exists, skipping creation';
  END IF;
END $$;

