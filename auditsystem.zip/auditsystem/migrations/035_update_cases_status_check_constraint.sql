-- Migration: Update cases_status_check constraint to include all valid statuses
-- Adds missing statuses: 'منتظر بررسی بازرس ارشد', 'اختصاص داده شده به بازرس', etc.
-- NOTE: 'در انتظار بررسی' is replaced with 'اختصاص داده شده' (ASSIGNED) for committee-assigned cases

DO $$
BEGIN
  -- Step 1: Drop existing constraint FIRST to allow data updates
  ALTER TABLE cases DROP CONSTRAINT IF EXISTS cases_status_check;
  
  -- Step 2: Update any existing cases with invalid statuses to valid ones
  -- This ensures data consistency before adding the new constraint
  
  -- Update 'در انتظار بررسی' to 'اختصاص داده شده' (ASSIGNED)
  UPDATE cases
  SET status = 'اختصاص داده شده'
  WHERE status = 'در انتظار بررسی';
  
  -- Update 'ارجاع به تنفیذ قانون' to 'ارسال‌ شده به تنفیذ قانون' (REFERRED_TO_ENFORCEMENT)
  UPDATE cases
  SET status = 'ارسال‌ شده به تنفیذ قانون'
  WHERE status = 'ارجاع به تنفیذ قانون';
  
  -- Step 3: Add updated check constraint with all valid status values
  ALTER TABLE cases
    ADD CONSTRAINT cases_status_check 
    CHECK (status IN (
      'جدید',
      'اختصاص داده شده',
      'منتظر بررسی بازرس ارشد',
      'اختصاص داده شده به بازرس',
      'در جریان بررسی',
      'تکمیل شده',
      'منتظر تایید',
      'تایید شده',
      'رد شده',
      'عدم پاسخگو',
      'ارسال‌ شده به تنفیذ قانون',
      'در اقساط',
      'ارسال‌شده به تنفیذ قانون'
    ));
END $$;

