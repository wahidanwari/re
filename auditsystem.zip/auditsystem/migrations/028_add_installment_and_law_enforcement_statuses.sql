-- Migration: Add Installment and Law Enforcement Case Statuses
-- Adds two new case statuses: 'در اقساط' and 'ارسال‌شده به تنفیذ قانون'
-- Updates installment_payments table structure to match requirements

-- Step 1: Update case status constraint to include new statuses
DO $$
BEGIN
  -- Drop existing constraint if it exists
  ALTER TABLE cases DROP CONSTRAINT IF EXISTS cases_status_check;
  
  -- Add check constraint for valid status values (including new statuses)
  ALTER TABLE cases
    ADD CONSTRAINT cases_status_check 
    CHECK (status IN (
      'جدید', 
      'اختصاص داده شده', 
      'در جریان بررسی', 
      'تکمیل شده', 
      'منتظر تایید', 
      'تایید شده', 
      'رد شده',
      'عدم پاسخگو',
      'ارسال‌ شده به تنفیذ قانون',
      'در اقساط',
      'ارسال‌شده به تنفیذ قانون'
    ));
END $$;

-- Step 2: Update installment_payments table structure
DO $$
BEGIN
  -- Add new columns if they don't exist
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'installment_payments' AND column_name = 'amount_paid') THEN
    -- Rename amount to amount_paid if it exists
    IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'installment_payments' AND column_name = 'amount') THEN
      ALTER TABLE installment_payments RENAME COLUMN amount TO amount_paid;
    ELSE
      ALTER TABLE installment_payments ADD COLUMN amount_paid NUMERIC(15, 2) NOT NULL DEFAULT 0;
    END IF;
  END IF;

  -- Add remaining_balance column
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'installment_payments' AND column_name = 'remaining_balance') THEN
    ALTER TABLE installment_payments ADD COLUMN remaining_balance NUMERIC(15, 2) NOT NULL DEFAULT 0;
  END IF;

  -- Add notes column
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'installment_payments' AND column_name = 'notes') THEN
    ALTER TABLE installment_payments ADD COLUMN notes TEXT;
  END IF;

  -- Add updated_at column
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'installment_payments' AND column_name = 'updated_at') THEN
    ALTER TABLE installment_payments ADD COLUMN updated_at TIMESTAMP DEFAULT NOW();
  END IF;

  -- Remove old columns if they exist (month_reference, taxpayer_id)
  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'installment_payments' AND column_name = 'month_reference') THEN
    ALTER TABLE installment_payments DROP COLUMN month_reference;
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'installment_payments' AND column_name = 'taxpayer_id') THEN
    ALTER TABLE installment_payments DROP COLUMN taxpayer_id;
  END IF;
END $$;

-- Step 3: Create index on status for new statuses (if not exists)
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_cases_status_installment') THEN
    CREATE INDEX idx_cases_status_installment ON cases(status) WHERE status = 'در اقساط';
  END IF;

  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_cases_status_law_enforcement') THEN
    CREATE INDEX idx_cases_status_law_enforcement ON cases(status) WHERE status = 'ارسال‌شده به تنفیذ قانون';
  END IF;
END $$;

-- Step 4: Add comment for documentation
COMMENT ON COLUMN cases.status IS 'Case status: جدید, اختصاص داده شده, در جریان بررسی, تکمیل شده, منتظر تایید, تایید شده, رد شده, عدم پاسخگو, ارسال‌ شده به تنفیذ قانون, در اقساط, ارسال‌شده به تنفیذ قانون';

