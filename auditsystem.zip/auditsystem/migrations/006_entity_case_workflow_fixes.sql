-- Migration: Entity/Case Workflow Fixes
-- Renames fields and adds receivingGroup to cases table

-- Step 1: Add receivingGroup column to cases (for audit groups receiving the case)
ALTER TABLE cases ADD COLUMN IF NOT EXISTS receiving_group VARCHAR(255);

-- Step 2: Add receivedDate to entities (for tracking when entity was received)
ALTER TABLE entities ADD COLUMN IF NOT EXISTS received_date TIMESTAMP;

-- Step 3: Add index for receiving_group
CREATE INDEX IF NOT EXISTS idx_cases_receiving_group ON cases(receiving_group) WHERE receiving_group IS NOT NULL;

-- Step 4: Add foreign key constraint for receiving_group (optional, can reference groups)
-- Note: We don't add FK constraint here to allow flexibility, but we ensure data integrity at application level

-- Step 5: Migrate existing data
-- If groupReferrer points to an audit group, copy it to receiving_group
-- Otherwise, receiving_group stays NULL (will be set when case is assigned)
UPDATE cases 
SET receiving_group = group_referrer
WHERE group_referrer IN (
  SELECT id FROM groups 
  WHERE name LIKE '%سنجش%' OR name LIKE '%بررسی%' OR code LIKE 'AUD%'
);

-- Note: groupReferrer will continue to store the sender group (from entity)
-- receivingGroup will store the audit group receiving the case

