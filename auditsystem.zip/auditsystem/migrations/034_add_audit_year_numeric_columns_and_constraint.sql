-- Migration: Add numeric audit year columns and exclusion constraint
-- Converts audit_year_range (TEXT) to audit_year_start and audit_year_end (INTEGER)
-- Adds PostgreSQL exclusion constraint to prevent overlapping year ranges per entity

-- Step 1: Enable btree_gist extension for exclusion constraints
-- Note: This requires superuser privileges. If it fails, the constraint will be skipped
-- and application-level validation will be used instead.
DO $$
BEGIN
  CREATE EXTENSION IF NOT EXISTS btree_gist;
  RAISE NOTICE 'btree_gist extension enabled successfully';
EXCEPTION
  WHEN insufficient_privilege THEN
    RAISE NOTICE 'Warning: Cannot create btree_gist extension (requires superuser). Exclusion constraint will be skipped.';
  WHEN OTHERS THEN
    RAISE NOTICE 'Warning: Error creating btree_gist extension: %. Exclusion constraint will be skipped.', SQLERRM;
END $$;

-- Step 2: Add new numeric columns for audit years
ALTER TABLE cases 
ADD COLUMN IF NOT EXISTS audit_year_start INTEGER;

ALTER TABLE cases 
ADD COLUMN IF NOT EXISTS audit_year_end INTEGER;

COMMENT ON COLUMN cases.audit_year_start IS 'سال شروع بررسی (numeric, e.g., 1399)';
COMMENT ON COLUMN cases.audit_year_end IS 'سال پایان بررسی (numeric, e.g., 1401)';

-- Step 3: Migrate existing data from audit_year_range to numeric columns
-- Parse formats: "1399–1401", "1399-1401", "1399—1401", or single year "1400"
DO $$
DECLARE
  case_record RECORD;
  range_str TEXT;
  start_year INTEGER;
  end_year INTEGER;
  range_match TEXT[];
  single_year_match TEXT[];
BEGIN
  FOR case_record IN SELECT id, audit_year_range FROM cases WHERE audit_year_range IS NOT NULL AND audit_year_range != '' LOOP
    range_str := TRIM(case_record.audit_year_range);
    
    -- Try to match range format (e.g., "1399–1401")
    range_match := regexp_match(range_str, '^(\d{4})[\s\-–—]+(\d{4})$');
    
    IF range_match IS NOT NULL THEN
      start_year := range_match[1]::INTEGER;
      end_year := range_match[2]::INTEGER;
    ELSE
      -- Try to match single year format (e.g., "1400")
      single_year_match := regexp_match(range_str, '^(\d{4})$');
      IF single_year_match IS NOT NULL THEN
        start_year := single_year_match[1]::INTEGER;
        end_year := start_year;
      ELSE
        -- Invalid format - log and skip
        RAISE NOTICE 'Could not parse audit_year_range for case %: %', case_record.id, range_str;
        CONTINUE;
      END IF;
    END IF;
    
    -- Validate parsed years
    IF start_year IS NOT NULL AND end_year IS NOT NULL AND start_year <= end_year THEN
      UPDATE cases 
      SET audit_year_start = start_year, audit_year_end = end_year
      WHERE id = case_record.id;
    ELSE
      RAISE NOTICE 'Invalid year range for case %: start=%, end=%', case_record.id, start_year, end_year;
    END IF;
  END LOOP;
END $$;

-- Step 4: Create indexes on the new columns for performance
CREATE INDEX IF NOT EXISTS idx_cases_audit_year_start ON cases(audit_year_start) WHERE audit_year_start IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_cases_audit_year_end ON cases(audit_year_end) WHERE audit_year_end IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_cases_entity_audit_years ON cases(entity_id, audit_year_start, audit_year_end) 
  WHERE audit_year_start IS NOT NULL AND audit_year_end IS NOT NULL;

-- Step 5: Check for existing overlapping data before creating constraint
-- This prevents constraint creation from failing due to existing violations
DO $$
DECLARE
  overlap_count INTEGER;
BEGIN
  -- Check for overlapping year ranges
  SELECT COUNT(*) INTO overlap_count
  FROM cases c1
  INNER JOIN cases c2 ON c1.entity_id = c2.entity_id AND c1.id != c2.id
  WHERE c1.audit_year_start IS NOT NULL 
    AND c1.audit_year_end IS NOT NULL
    AND c2.audit_year_start IS NOT NULL 
    AND c2.audit_year_end IS NOT NULL
    AND c1.audit_year_start <= c2.audit_year_end
    AND c2.audit_year_start <= c1.audit_year_end;
  
  IF overlap_count > 0 THEN
    RAISE WARNING 'Found % overlapping year ranges. Please resolve conflicts before creating constraint.', overlap_count;
    RAISE WARNING 'Constraint creation skipped. Application-level validation will be used.';
  ELSE
    RAISE NOTICE 'No overlapping year ranges found. Proceeding with constraint creation.';
  END IF;
END $$;

-- Step 6: Add exclusion constraint to prevent overlapping year ranges per entity
-- This constraint ensures that for any given entity_id, no two cases can have overlapping year ranges
-- The constraint uses int4range with inclusive bounds [start, end]
-- Note: Requires btree_gist extension (created in Step 1)
DO $$
DECLARE
  extension_exists BOOLEAN;
BEGIN
  -- Check if btree_gist extension exists
  SELECT EXISTS(
    SELECT 1 FROM pg_extension WHERE extname = 'btree_gist'
  ) INTO extension_exists;
  
  IF NOT extension_exists THEN
    RAISE NOTICE 'btree_gist extension not available. Skipping exclusion constraint creation.';
    RAISE NOTICE 'Application-level validation will enforce overlap prevention.';
    RETURN;
  END IF;
  
  -- Drop existing constraint if it exists (for idempotency)
  ALTER TABLE cases DROP CONSTRAINT IF EXISTS no_overlapping_audit_years;
  
  -- Add exclusion constraint
  -- This prevents any two rows with the same entity_id from having overlapping year ranges
  -- The && operator checks for range overlap
  BEGIN
    ALTER TABLE cases 
      ADD CONSTRAINT no_overlapping_audit_years
      EXCLUDE USING GIST (
        entity_id WITH =,
        int4range(audit_year_start, audit_year_end, '[]') WITH &&
      )
      WHERE (audit_year_start IS NOT NULL AND audit_year_end IS NOT NULL);
      
    RAISE NOTICE 'Exclusion constraint no_overlapping_audit_years created successfully';
  EXCEPTION
    WHEN duplicate_object THEN
      RAISE NOTICE 'Constraint no_overlapping_audit_years already exists. Skipping.';
    WHEN OTHERS THEN
      RAISE WARNING 'Error creating exclusion constraint: %', SQLERRM;
      RAISE WARNING 'Application-level validation will enforce overlap prevention.';
  END;
END $$;

-- Step 7: Add check constraint to ensure start <= end
ALTER TABLE cases 
  DROP CONSTRAINT IF EXISTS cases_audit_years_check;
  
ALTER TABLE cases 
  ADD CONSTRAINT cases_audit_years_check
  CHECK (
    (audit_year_start IS NULL AND audit_year_end IS NULL) OR
    (audit_year_start IS NOT NULL AND audit_year_end IS NOT NULL AND audit_year_start <= audit_year_end)
  );

-- Step 8: Add comment to constraint if it exists
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM pg_constraint 
    WHERE conname = 'no_overlapping_audit_years' 
    AND conrelid = 'cases'::regclass
  ) THEN
    COMMENT ON CONSTRAINT no_overlapping_audit_years ON cases IS 
      'Prevents overlapping audit year ranges for the same entity. Uses PostgreSQL exclusion constraint with GIST index.';
  END IF;
END $$;

-- Step 9: Note about keeping audit_year_range for backward compatibility
-- The audit_year_range column is kept for backward compatibility and can be
-- automatically populated from audit_year_start and audit_year_end via triggers or application logic
-- For now, we keep both columns to allow gradual migration

