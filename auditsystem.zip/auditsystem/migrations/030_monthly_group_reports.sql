-- Migration: Monthly Group Reports and Group Monthly Tax Target
-- Adds monthly_tax_target to groups and creates monthly_group_reports table

-- Step 1: Add monthly_tax_target to groups table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'groups' AND column_name = 'monthly_tax_target'
  ) THEN
    ALTER TABLE groups 
    ADD COLUMN monthly_tax_target NUMERIC(15, 2);
    
    COMMENT ON COLUMN groups.monthly_tax_target IS 'Monthly tax collection target for this group (optional). Used for calculating percentage of target achieved in monthly reports.';
  END IF;
END $$;

-- Step 2: Create monthly_group_reports table
DO $$
BEGIN
  IF NOT EXISTS (SELECT FROM information_schema.tables WHERE table_name = 'monthly_group_reports') THEN
    CREATE TABLE monthly_group_reports (
      id VARCHAR PRIMARY KEY DEFAULT gen_random_uuid()::text,
      group_id VARCHAR NOT NULL REFERENCES groups(id) ON DELETE CASCADE,
      month_number INTEGER NOT NULL, -- Afghan month number (1-12)
      year_number INTEGER NOT NULL, -- Shamsi year
      month_start_date DATE NOT NULL,
      month_end_date DATE NOT NULL,
      
      -- Count fields
      distributed_count INTEGER NOT NULL DEFAULT 0, -- Cases distributed during month
      finalized_count INTEGER NOT NULL DEFAULT 0, -- Cases finalized during month
      under_review_count INTEGER NOT NULL DEFAULT 0, -- distributed_count - finalized_count
      
      -- Financial fields
      collected_amount NUMERIC(15, 2) NOT NULL DEFAULT 0, -- Total revenue collected
      
      -- Additional metrics
      installments_count INTEGER NOT NULL DEFAULT 0, -- Cases with installment payments
      nonresponsive_count INTEGER NOT NULL DEFAULT 0, -- Cases sent to law enforcement
      
      -- Target achievement
      percent_of_target NUMERIC(5, 2), -- Percentage of monthly_tax_target achieved (null if target not set)
      
      -- Manual overrides (JSONB for flexibility)
      manual_overrides JSONB, -- Stores manual adjustments with audit trail
      
      -- Metadata
      computed_by VARCHAR REFERENCES users(id) ON DELETE SET NULL,
      created_at TIMESTAMP NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
      
      -- Constraints
      CONSTRAINT monthly_group_reports_group_month_year_unique UNIQUE (group_id, month_number, year_number),
      CONSTRAINT monthly_group_reports_month_number_check CHECK (month_number >= 1 AND month_number <= 12),
      CONSTRAINT monthly_group_reports_year_number_check CHECK (year_number >= 1300 AND year_number <= 1500),
      CONSTRAINT monthly_group_reports_under_review_count_check CHECK (under_review_count >= 0)
    );
    
    -- Indexes for efficient queries
    CREATE INDEX idx_monthly_group_reports_group_id ON monthly_group_reports(group_id);
    CREATE INDEX idx_monthly_group_reports_month_year ON monthly_group_reports(year_number, month_number);
    CREATE INDEX idx_monthly_group_reports_date_range ON monthly_group_reports(month_start_date, month_end_date);
    CREATE INDEX idx_monthly_group_reports_computed_by ON monthly_group_reports(computed_by);
    
    COMMENT ON TABLE monthly_group_reports IS 'Monthly aggregated reports per group with KPIs and financial metrics';
    COMMENT ON COLUMN monthly_group_reports.distributed_count IS 'Number of cases distributed to this group during the month';
    COMMENT ON COLUMN monthly_group_reports.finalized_count IS 'Number of cases finalized (completed) during the month';
    COMMENT ON COLUMN monthly_group_reports.under_review_count IS 'Number of entities/companies currently under review (distributed_count - finalized_count)';
    COMMENT ON COLUMN monthly_group_reports.collected_amount IS 'Total revenue collected during the month (from completed cases + installment payments)';
    COMMENT ON COLUMN monthly_group_reports.installments_count IS 'Number of distinct cases with installment payments during the month';
    COMMENT ON COLUMN monthly_group_reports.nonresponsive_count IS 'Number of cases sent to law enforcement during the month';
    COMMENT ON COLUMN monthly_group_reports.percent_of_target IS 'Percentage of monthly_tax_target achieved (null if target not configured)';
    COMMENT ON COLUMN monthly_group_reports.manual_overrides IS 'JSONB field storing manual adjustments: {field: value, adjusted_by: user_id, adjusted_at: timestamp, reason: text}';
  END IF;
END $$;

-- Step 3: Create table for storing aggregation anomalies/warnings
DO $$
BEGIN
  IF NOT EXISTS (SELECT FROM information_schema.tables WHERE table_name = 'monthly_report_anomalies') THEN
    CREATE TABLE monthly_report_anomalies (
      id VARCHAR PRIMARY KEY DEFAULT gen_random_uuid()::text,
      report_id VARCHAR NOT NULL REFERENCES monthly_group_reports(id) ON DELETE CASCADE,
      anomaly_type VARCHAR NOT NULL, -- 'negative_under_review', 'missing_target', 'high_percentage', 'data_inconsistency'
      severity VARCHAR NOT NULL DEFAULT 'warning', -- 'info', 'warning', 'error'
      description TEXT NOT NULL,
      details JSONB, -- Additional context
      resolved BOOLEAN NOT NULL DEFAULT false,
      resolved_by VARCHAR REFERENCES users(id) ON DELETE SET NULL,
      resolved_at TIMESTAMP,
      created_at TIMESTAMP NOT NULL DEFAULT NOW()
    );
    
    CREATE INDEX idx_monthly_report_anomalies_report_id ON monthly_report_anomalies(report_id);
    CREATE INDEX idx_monthly_report_anomalies_resolved ON monthly_report_anomalies(resolved);
    CREATE INDEX idx_monthly_report_anomalies_type ON monthly_report_anomalies(anomaly_type);
    
    COMMENT ON TABLE monthly_report_anomalies IS 'Tracks data quality issues and anomalies detected during monthly report aggregation';
  END IF;
END $$;

