-- Migration: Legacy Excel Archives Module
-- Creates tables for archiving legacy Excel files with versioning and access logging

-- ArchivedFile table - Main file metadata
CREATE TABLE IF NOT EXISTS archived_files (
  id VARCHAR PRIMARY KEY DEFAULT gen_random_uuid()::text,
  file_name TEXT NOT NULL, -- Stored filename: [YYYY]_[Category]_[ShortDescription]_[OriginalFileName]_[v{N}].xlsx
  original_file_name TEXT NOT NULL, -- Original filename from upload
  year INTEGER NOT NULL, -- Shamsi year (e.g., 1400, 1401)
  category TEXT NOT NULL, -- Category classification
  description TEXT, -- Short description
  path TEXT NOT NULL, -- Relative path from archive root
  size_bytes BIGINT NOT NULL,
  uploaded_by VARCHAR REFERENCES users(id) ON DELETE SET NULL,
  uploaded_at TIMESTAMP NOT NULL DEFAULT NOW(),
  is_readonly BOOLEAN NOT NULL DEFAULT true,
  current_version INTEGER NOT NULL DEFAULT 1,
  deleted_at TIMESTAMP, -- Soft delete timestamp
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);

-- ArchivedFileVersion table - Version history
CREATE TABLE IF NOT EXISTS archived_file_versions (
  id VARCHAR PRIMARY KEY DEFAULT gen_random_uuid()::text,
  archived_file_id VARCHAR NOT NULL REFERENCES archived_files(id) ON DELETE CASCADE,
  version_number INTEGER NOT NULL,
  file_name TEXT NOT NULL, -- Version-specific filename
  path TEXT NOT NULL, -- Version-specific path
  size_bytes BIGINT NOT NULL,
  uploaded_by VARCHAR REFERENCES users(id) ON DELETE SET NULL,
  uploaded_at TIMESTAMP NOT NULL DEFAULT NOW(),
  notes TEXT, -- Optional notes for this version
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  UNIQUE(archived_file_id, version_number)
);

-- ArchivedFileAccessLog table - Access audit trail
CREATE TABLE IF NOT EXISTS archived_file_access_logs (
  id VARCHAR PRIMARY KEY DEFAULT gen_random_uuid()::text,
  archived_file_id VARCHAR NOT NULL REFERENCES archived_files(id) ON DELETE CASCADE,
  user_id VARCHAR REFERENCES users(id) ON DELETE SET NULL,
  action TEXT NOT NULL, -- 'DOWNLOAD', 'UPLOAD', 'VIEW_METADATA'
  ip_address TEXT,
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_archived_files_year ON archived_files(year);
CREATE INDEX IF NOT EXISTS idx_archived_files_category ON archived_files(category);
CREATE INDEX IF NOT EXISTS idx_archived_files_file_name ON archived_files(file_name);
CREATE INDEX IF NOT EXISTS idx_archived_files_original_file_name ON archived_files(original_file_name);
CREATE INDEX IF NOT EXISTS idx_archived_files_uploaded_by ON archived_files(uploaded_by);
CREATE INDEX IF NOT EXISTS idx_archived_files_deleted_at ON archived_files(deleted_at) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS idx_archived_file_versions_file_id ON archived_file_versions(archived_file_id);
CREATE INDEX IF NOT EXISTS idx_archived_file_access_logs_file_id ON archived_file_access_logs(archived_file_id);
CREATE INDEX IF NOT EXISTS idx_archived_file_access_logs_user_id ON archived_file_access_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_archived_file_access_logs_created_at ON archived_file_access_logs(created_at);

-- Composite index for search queries
CREATE INDEX IF NOT EXISTS idx_archived_files_year_category ON archived_files(year, category) WHERE deleted_at IS NULL;

