-- Migration: Add new case status fields and committee updates
-- Adds auditYearRange, assignedAuditor to cases
-- Adds month, year, locked fields to committees
-- Supports new status transitions: PendingReviewBySeniorAuditor, AssignedToAuditor, UnderAuditReview

-- Add auditYearRange to cases table (سال‌های بررسی)
ALTER TABLE cases 
ADD COLUMN IF NOT EXISTS audit_year_range TEXT;

COMMENT ON COLUMN cases.audit_year_range IS 'سال‌های بررسی (e.g., "1399–1401")';

-- Add assignedAuditor to cases table (explicit auditor assignment)
ALTER TABLE cases 
ADD COLUMN IF NOT EXISTS assigned_auditor VARCHAR REFERENCES users(id) ON DELETE SET NULL;

COMMENT ON COLUMN cases.assigned_auditor IS 'بازرس اختصاص داده شده (explicit auditor assignment)';

-- Add month and year to committees table (Afghan months)
ALTER TABLE committees 
ADD COLUMN IF NOT EXISTS month TEXT;

ALTER TABLE committees 
ADD COLUMN IF NOT EXISTS year INTEGER;

COMMENT ON COLUMN committees.month IS 'Afghan month name (حمل، ثور، جوزا، سرطان، اسد، سنبله، میزان، عقرب، قوس، جدی، دلو، حوت)';
COMMENT ON COLUMN committees.year IS 'Year (Shamsi, e.g., 1404)';

-- Add locked field to committees table
ALTER TABLE committees 
ADD COLUMN IF NOT EXISTS locked BOOLEAN DEFAULT false;

COMMENT ON COLUMN committees.locked IS 'Locked after approval - no new cases can be added';

-- Create index on assigned_auditor for faster lookups
CREATE INDEX IF NOT EXISTS idx_cases_assigned_auditor ON cases(assigned_auditor);

-- Create index on audit_year_range for filtering
CREATE INDEX IF NOT EXISTS idx_cases_audit_year_range ON cases(audit_year_range);

-- Create index on committee month/year for filtering
CREATE INDEX IF NOT EXISTS idx_committees_month_year ON committees(year, month);

-- Update existing committees to extract month/year from period if possible
-- This is a best-effort migration - manual review may be needed
UPDATE committees 
SET 
  month = CASE 
    WHEN period LIKE '%حمل%' THEN 'حمل'
    WHEN period LIKE '%ثور%' THEN 'ثور'
    WHEN period LIKE '%جوزا%' THEN 'جوزا'
    WHEN period LIKE '%سرطان%' THEN 'سرطان'
    WHEN period LIKE '%اسد%' THEN 'اسد'
    WHEN period LIKE '%سنبله%' THEN 'سنبله'
    WHEN period LIKE '%میزان%' THEN 'میزان'
    WHEN period LIKE '%عقرب%' THEN 'عقرب'
    WHEN period LIKE '%قوس%' THEN 'قوس'
    WHEN period LIKE '%جدی%' THEN 'جدی'
    WHEN period LIKE '%دلو%' THEN 'دلو'
    WHEN period LIKE '%حوت%' THEN 'حوت'
    ELSE NULL
  END,
  year = CASE 
    WHEN period ~ '[0-9]{4}' THEN (regexp_match(period, '[0-9]{4}'))[1]::INTEGER
    ELSE NULL
  END
WHERE month IS NULL OR year IS NULL;

-- Update case status constraint to include new statuses
DO $$
BEGIN
  -- Drop existing constraint if it exists
  ALTER TABLE cases DROP CONSTRAINT IF EXISTS cases_status_check;
  
  -- Add check constraint for valid status values (including new statuses)
  ALTER TABLE cases
    ADD CONSTRAINT cases_status_check 
    CHECK (status IN (
      'جدید', 
      'اختصاص داده شده',
      'منتظر بررسی بازرس ارشد',
      'اختصاص داده شده به بازرس',
      'در جریان بررسی',
      'تکمیل شده', 
      'منتظر تایید', 
      'تایید شده', 
      'رد شده',
      'عدم پاسخگو',
      'در اقساط',
      'ارسال‌شده به تنفیذ قانون'
    ));
END $$;

