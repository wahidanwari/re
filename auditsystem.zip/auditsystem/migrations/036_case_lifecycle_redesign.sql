-- Migration: Case Lifecycle Redesign
-- Replaces 13 statuses with 6 new statuses and adds boolean flags
-- Migration date: 2025-01-XX

DO $$
BEGIN
  -- Step 1: Add new boolean flag columns
  ALTER TABLE cases 
    ADD COLUMN IF NOT EXISTS is_law_enforcement BOOLEAN DEFAULT false,
    ADD COLUMN IF NOT EXISTS is_tax_installment BOOLEAN DEFAULT false,
    ADD COLUMN IF NOT EXISTS is_cancelled BOOLEAN DEFAULT false;

  -- Step 2: Set flags based on old statuses BEFORE migrating statuses
  -- ارسال‌شده به تنفیذ قانون → isLawEnforcement = true
  UPDATE cases 
  SET is_law_enforcement = true 
  WHERE status IN ('ارسال‌ شده به تنفیذ قانون', 'ارسال‌ شده به تنفیذ قانون', 'ارجاع به تنفیذ قانون');

  -- در اقساط → isTaxInstallment = true
  UPDATE cases 
  SET is_tax_installment = true 
  WHERE status = 'در اقساط';

  -- لغو شده → isCancelled = true
  UPDATE cases 
  SET is_cancelled = true 
  WHERE status = 'لغو شده';

  -- Step 3: Drop old constraint BEFORE migrating statuses
  -- This allows us to update statuses to new values
  ALTER TABLE cases DROP CONSTRAINT IF EXISTS cases_status_check;

  -- Step 4: Migrate statuses to new lifecycle states
  -- در انتظار تصمیم کمیته → ایجاد شده
  UPDATE cases 
  SET status = 'ایجاد شده' 
  WHERE status = 'در انتظار تصمیم کمیته';

  -- در انتظار تخصیص به گروه → ایجاد شده
  UPDATE cases 
  SET status = 'ایجاد شده' 
  WHERE status = 'در انتظار تخصیص به گروه';

  -- جدید → ایجاد شده
  UPDATE cases 
  SET status = 'ایجاد شده' 
  WHERE status = 'جدید';

  -- اختصاص داده شده → در انتظار بررسی بازرس ارشد
  UPDATE cases 
  SET status = 'در انتظار بررسی بازرس ارشد' 
  WHERE status = 'اختصاص داده شده';

  -- منتظر بررسی بازرس ارشد → در انتظار بررسی بازرس ارشد
  UPDATE cases 
  SET status = 'در انتظار بررسی بازرس ارشد' 
  WHERE status = 'منتظر بررسی بازرس ارشد';

  -- اختصاص داده شده به بازرس → در انتظار بررسی بازرس ارشد
  UPDATE cases 
  SET status = 'در انتظار بررسی بازرس ارشد' 
  WHERE status = 'اختصاص داده شده به بازرس';

  -- شروع بررسی / فعال → در حال بررسی
  UPDATE cases 
  SET status = 'در حال بررسی' 
  WHERE status IN ('شروع بررسی', 'فعال', 'در جریان بررسی', 'در حال بررسی');

  -- در انتظار مدارک → در انتظار تکمیل مدارک
  UPDATE cases 
  SET status = 'در انتظار تکمیل مدارک' 
  WHERE status = 'در انتظار مدارک';

  -- متوقف / معلق → تعلیق شده
  UPDATE cases 
  SET status = 'تعلیق شده' 
  WHERE status IN ('متوقف', 'معلق', 'تعلیق شده');

  -- بسته شده / پایان یافته → تکمیل شده
  UPDATE cases 
  SET status = 'تکمیل شده' 
  WHERE status IN ('بسته شده', 'پایان یافته', 'تکمیل شده', 'تایید شده');

  -- رد شده → تکمیل شده (with flag if needed, but status is completed)
  UPDATE cases 
  SET status = 'تکمیل شده' 
  WHERE status = 'رد شده';

  -- منتظر تایید → تکمیل شده
  UPDATE cases 
  SET status = 'تکمیل شده' 
  WHERE status = 'منتظر تایید';

  -- عدم پاسخگو → در حال بررسی (keep as under review)
  UPDATE cases 
  SET status = 'در حال بررسی' 
  WHERE status = 'عدم پاسخگو';

  -- Catch-all: Migrate any remaining old statuses to 'ایجاد شده'
  -- This handles any statuses we might have missed
  UPDATE cases 
  SET status = 'ایجاد شده' 
  WHERE status NOT IN (
    'ایجاد شده',
    'در انتظار بررسی بازرس ارشد',
    'در حال بررسی',
    'در انتظار تکمیل مدارک',
    'تعلیق شده',
    'تکمیل شده'
  );

  -- Step 5: For cases with flags, ensure status is appropriate
  -- Law enforcement cases should remain in their current lifecycle state
  -- Installment cases should remain in their current lifecycle state
  -- Cancelled cases should remain in their current lifecycle state
  -- (Flags are independent of lifecycle state)

  -- Step 6: Add new constraint with ONLY the 6 new statuses
  ALTER TABLE cases
    ADD CONSTRAINT cases_status_check 
    CHECK (status IN (
      'ایجاد شده',
      'در انتظار بررسی بازرس ارشد',
      'در حال بررسی',
      'در انتظار تکمیل مدارک',
      'تعلیق شده',
      'تکمیل شده'
    ));

  -- Step 7: Create indexes for flags (after constraint is in place)
  CREATE INDEX IF NOT EXISTS idx_cases_is_law_enforcement ON cases(is_law_enforcement) WHERE is_law_enforcement = true;
  CREATE INDEX IF NOT EXISTS idx_cases_is_tax_installment ON cases(is_tax_installment) WHERE is_tax_installment = true;
  CREATE INDEX IF NOT EXISTS idx_cases_is_cancelled ON cases(is_cancelled) WHERE is_cancelled = true;

  -- Step 8: Update status index
  CREATE INDEX IF NOT EXISTS idx_cases_status_new ON cases(status);

END $$;

