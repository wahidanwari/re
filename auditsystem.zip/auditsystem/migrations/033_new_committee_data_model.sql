-- Migration: New Committee Data Model
-- Purpose: Create clean, authoritative data model for new Committee module
-- Note: Old committees table is archived to preserve data, new structure created

-- ============================================================================
-- STEP 1: Archive old committees table (if it exists)
-- ============================================================================
-- Rename old table to preserve data, then create new structure

DO $$
BEGIN
  -- Rename old committees table if it exists and hasn't been renamed already
  IF EXISTS (
    SELECT 1 FROM information_schema.tables 
    WHERE table_name = 'committees' 
    AND table_schema = 'public'
  ) AND NOT EXISTS (
    SELECT 1 FROM information_schema.tables 
    WHERE table_name = 'committees_old' 
    AND table_schema = 'public'
  ) THEN
    ALTER TABLE committees RENAME TO committees_old;
    RAISE NOTICE 'Old committees table renamed to committees_old';
  END IF;
END $$;

-- ============================================================================
-- STEP 2: CREATE TABLE: committees (NEW IMPLEMENTATION)
-- ============================================================================

CREATE TABLE IF NOT EXISTS committees (
  id VARCHAR PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,                    -- e.g. "کمیته حمل ۱۴۰۵"
  year INTEGER NOT NULL,                   -- e.g. 1405 (Shamsi)
  month INTEGER NOT NULL,                  -- 1-12 (Shamsi month number)
  status TEXT NOT NULL DEFAULT 'DRAFT',    -- DRAFT, APPROVED, CLOSED
  created_by VARCHAR NOT NULL REFERENCES users(id) ON DELETE SET NULL,
  created_at TIMESTAMP DEFAULT NOW(),
  approved_by VARCHAR REFERENCES users(id) ON DELETE SET NULL,
  approved_at TIMESTAMP,
  
  -- Constraints
  CONSTRAINT committees_year_month_unique UNIQUE (year, month),
  CONSTRAINT committees_month_check CHECK (month >= 1 AND month <= 12),
  CONSTRAINT committees_status_check CHECK (status IN ('DRAFT', 'APPROVED', 'CLOSED'))
);

-- Create indexes for committees (only if table exists)
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'committees' AND table_schema = 'public') THEN
    CREATE INDEX IF NOT EXISTS idx_committees_year_month ON committees(year, month);
    CREATE INDEX IF NOT EXISTS idx_committees_status ON committees(status);
    CREATE INDEX IF NOT EXISTS idx_committees_created_by ON committees(created_by);
  END IF;
END $$;

-- ============================================================================
-- 2. CREATE TABLE: committee_case_assignments
-- ============================================================================
-- Purpose: Records EVERY authoritative assignment decision
-- Rows are immutable (append-only)

CREATE TABLE IF NOT EXISTS committee_case_assignments (
  id VARCHAR PRIMARY KEY DEFAULT gen_random_uuid(),
  committee_id VARCHAR REFERENCES committees(id) ON DELETE SET NULL,
  case_id VARCHAR NOT NULL REFERENCES cases(id) ON DELETE CASCADE,
  audit_group_id VARCHAR NOT NULL REFERENCES groups(id) ON DELETE RESTRICT,
  assignment_type TEXT NOT NULL,          -- COMMITTEE, DIRECT, REASSIGNMENT
  previous_assignment_id VARCHAR, -- Self-reference FK added below
  reason TEXT,                             -- REQUIRED when assignment_type = DIRECT or REASSIGNMENT
  assigned_by VARCHAR NOT NULL REFERENCES users(id) ON DELETE SET NULL,
  assigned_at TIMESTAMP NOT NULL DEFAULT NOW(),
  
  -- Constraints
  CONSTRAINT committee_case_assignments_type_check CHECK (assignment_type IN ('COMMITTEE', 'DIRECT', 'REASSIGNMENT')),
  CONSTRAINT committee_case_assignments_reason_check CHECK (
    (assignment_type IN ('DIRECT', 'REASSIGNMENT') AND reason IS NOT NULL) OR
    (assignment_type = 'COMMITTEE')
  )
);

-- Add self-reference foreign key constraint for previous_assignment_id
-- Only add if it doesn't already exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints 
    WHERE constraint_name = 'fk_committee_case_assignments_previous_assignment'
    AND table_name = 'committee_case_assignments'
  ) THEN
    ALTER TABLE committee_case_assignments 
    ADD CONSTRAINT fk_committee_case_assignments_previous_assignment 
    FOREIGN KEY (previous_assignment_id) 
    REFERENCES committee_case_assignments(id) ON DELETE SET NULL;
  END IF;
END $$;

-- Create indexes for committee_case_assignments (only if table exists)
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'committee_case_assignments' AND table_schema = 'public') THEN
    CREATE INDEX IF NOT EXISTS idx_committee_case_assignments_case_id ON committee_case_assignments(case_id);
    CREATE INDEX IF NOT EXISTS idx_committee_case_assignments_committee_id ON committee_case_assignments(committee_id);
    CREATE INDEX IF NOT EXISTS idx_committee_case_assignments_audit_group_id ON committee_case_assignments(audit_group_id);
    CREATE INDEX IF NOT EXISTS idx_committee_case_assignments_type ON committee_case_assignments(assignment_type);
    CREATE INDEX IF NOT EXISTS idx_committee_case_assignments_assigned_at ON committee_case_assignments(assigned_at);
    CREATE INDEX IF NOT EXISTS idx_committee_case_assignments_previous_assignment ON committee_case_assignments(previous_assignment_id);
    
    -- Note: "Only one active assignment per case" is enforced at application level
    -- by ensuring the latest assignment (by assigned_at) is the active one.
    -- The index below helps with querying the latest assignment per case.
    CREATE INDEX IF NOT EXISTS idx_committee_case_assignments_case_assigned_at 
    ON committee_case_assignments(case_id, assigned_at DESC);
  END IF;
END $$;

-- ============================================================================
-- 3. UPDATE CASES TABLE (NON-DESTRUCTIVE)
-- ============================================================================
-- Add fields to point to LATEST assignment only
-- Historical data remains in committee_case_assignments

-- Add current_assignment_id if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'cases' AND column_name = 'current_assignment_id'
  ) THEN
    -- Check if committee_case_assignments table exists before adding FK
    IF EXISTS (
      SELECT 1 FROM information_schema.tables 
      WHERE table_name = 'committee_case_assignments' AND table_schema = 'public'
    ) THEN
      ALTER TABLE cases ADD COLUMN current_assignment_id VARCHAR REFERENCES committee_case_assignments(id) ON DELETE SET NULL;
    ELSE
      -- Add column without FK first, FK will be added later
      ALTER TABLE cases ADD COLUMN current_assignment_id VARCHAR;
    END IF;
  END IF;
END $$;

-- Add FK constraint for current_assignment_id if column exists but constraint doesn't
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'cases' AND column_name = 'current_assignment_id'
  ) AND EXISTS (
    SELECT 1 FROM information_schema.tables 
    WHERE table_name = 'committee_case_assignments' AND table_schema = 'public'
  ) AND NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints 
    WHERE table_name = 'cases' 
    AND constraint_name LIKE '%current_assignment_id%'
    AND constraint_type = 'FOREIGN KEY'
  ) THEN
    ALTER TABLE cases 
    ADD CONSTRAINT fk_cases_current_assignment_id 
    FOREIGN KEY (current_assignment_id) 
    REFERENCES committee_case_assignments(id) ON DELETE SET NULL;
  END IF;
END $$;

-- Add current_audit_group_id if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'cases' AND column_name = 'current_audit_group_id'
  ) THEN
    ALTER TABLE cases ADD COLUMN current_audit_group_id VARCHAR REFERENCES groups(id) ON DELETE SET NULL;
  END IF;
END $$;

-- Create indexes for new case fields (only if columns exist)
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'cases' AND column_name = 'current_assignment_id'
  ) THEN
    CREATE INDEX IF NOT EXISTS idx_cases_current_assignment_id ON cases(current_assignment_id);
  END IF;
  
  IF EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'cases' AND column_name = 'current_audit_group_id'
  ) THEN
    CREATE INDEX IF NOT EXISTS idx_cases_current_audit_group_id ON cases(current_audit_group_id);
  END IF;
END $$;

-- ============================================================================
-- COMMENTS
-- ============================================================================

COMMENT ON TABLE committees IS 'New Committee module - Monthly committees with approval workflow';
COMMENT ON TABLE committee_case_assignments IS 'Immutable assignment records - tracks all case assignments with full history';
COMMENT ON COLUMN committees.title IS 'Committee title (e.g., "کمیته حمل ۱۴۰۵")';
COMMENT ON COLUMN committees.year IS 'Shamsi year (e.g., 1405)';
COMMENT ON COLUMN committees.month IS 'Shamsi month number (1-12)';
COMMENT ON COLUMN committees.status IS 'Committee status: DRAFT, APPROVED, CLOSED';
COMMENT ON COLUMN committee_case_assignments.assignment_type IS 'COMMITTEE: assigned via committee, DIRECT: direct assignment, REASSIGNMENT: reassigned from previous';
COMMENT ON COLUMN committee_case_assignments.previous_assignment_id IS 'Points to previous assignment for reassignments (creates audit trail)';
COMMENT ON COLUMN committee_case_assignments.reason IS 'Required for DIRECT and REASSIGNMENT types';
COMMENT ON COLUMN cases.current_assignment_id IS 'Points to latest assignment record (denormalized for performance)';
COMMENT ON COLUMN cases.current_audit_group_id IS 'Current audit group (denormalized from latest assignment)';

