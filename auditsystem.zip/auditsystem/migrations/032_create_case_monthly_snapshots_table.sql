-- Migration: Create case_monthly_snapshots table for monthly remaining balance snapshots
-- PHASE 2: Monthly Remaining Balance Snapshot
-- Purpose: Enable month-to-month comparison of remaining tax balances per case

-- Create case_monthly_snapshots table
CREATE TABLE IF NOT EXISTS case_monthly_snapshots (
  id VARCHAR PRIMARY KEY DEFAULT gen_random_uuid(),
  case_id VARCHAR NOT NULL REFERENCES cases(id) ON DELETE CASCADE,
  report_month VARCHAR(7) NOT NULL, -- YYYY-MM format (e.g., "1404-03" for Shamsi year-month)
  remaining_balance_end_of_month NUMERIC(15, 2) NOT NULL,
  total_paid_in_month NUMERIC(15, 2) NOT NULL DEFAULT 0,
  confirmed_amount NUMERIC(15, 2), -- Store confirmedAmount (مبلغ تثبیت شده) for reference
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW(),
  
  -- Unique constraint: one snapshot per case per month
  UNIQUE(case_id, report_month)
);

-- Create indexes for efficient querying
CREATE INDEX IF NOT EXISTS idx_case_monthly_snapshots_case_id ON case_monthly_snapshots(case_id);
CREATE INDEX IF NOT EXISTS idx_case_monthly_snapshots_report_month ON case_monthly_snapshots(report_month);
CREATE INDEX IF NOT EXISTS idx_case_monthly_snapshots_case_month ON case_monthly_snapshots(case_id, report_month);

-- Composite index for month-based queries
CREATE INDEX IF NOT EXISTS idx_case_monthly_snapshots_month_balance ON case_monthly_snapshots(report_month, remaining_balance_end_of_month);

-- Add comments
COMMENT ON TABLE case_monthly_snapshots IS 'Monthly snapshots of remaining balance per case - PHASE 2: Monthly Remaining Balance Snapshot';
COMMENT ON COLUMN case_monthly_snapshots.case_id IS 'Foreign key to cases table';
COMMENT ON COLUMN case_monthly_snapshots.report_month IS 'Month in YYYY-MM format (Shamsi calendar, e.g., "1404-03")';
COMMENT ON COLUMN case_monthly_snapshots.remaining_balance_end_of_month IS 'Remaining balance at end of month = confirmedAmount - total payments up to end of month';
COMMENT ON COLUMN case_monthly_snapshots.total_paid_in_month IS 'Total payments made during this specific month';
COMMENT ON COLUMN case_monthly_snapshots.confirmed_amount IS 'مبلغ تثبیت شده (confirmedAmount) at time of snapshot';

