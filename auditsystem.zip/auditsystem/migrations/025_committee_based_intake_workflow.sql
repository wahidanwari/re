-- Migration: Committee-Based Audit Case Intake Workflow
-- Purpose: Add support for periodic audit committees with batch entity intake and automatic case generation

-- 1. Add status field to entities table (Entity lifecycle status)
ALTER TABLE entities 
ADD COLUMN IF NOT EXISTS status TEXT DEFAULT 'Active';

-- Add comment
COMMENT ON COLUMN entities.status IS 'Entity lifecycle status: Active, Under Audit, Dormant, Deleted/Archived';

-- 2. Add committeeId field to cases table
ALTER TABLE cases 
ADD COLUMN IF NOT EXISTS committee_id VARCHAR;

-- Add comment
COMMENT ON COLUMN cases.committee_id IS 'Committee ID if case was created through committee intake';

-- 3. Create committees table
CREATE TABLE IF NOT EXISTS committees (
  id VARCHAR PRIMARY KEY DEFAULT gen_random_uuid()::text,
  name TEXT NOT NULL,
  period TEXT NOT NULL,
  start_date TIMESTAMP NOT NULL,
  end_date TIMESTAMP NOT NULL,
  notes TEXT,
  status TEXT NOT NULL DEFAULT 'Active',
  created_by VARCHAR NOT NULL REFERENCES users(id) ON DELETE SET NULL,
  created_at TIMESTAMP DEFAULT NOW()
);

-- Add comments
COMMENT ON TABLE committees IS 'Periodic audit committees for batch entity intake';
COMMENT ON COLUMN committees.name IS 'Committee Name';
COMMENT ON COLUMN committees.period IS 'Period (Month/Year)';
COMMENT ON COLUMN committees.start_date IS 'Start Date';
COMMENT ON COLUMN committees.end_date IS 'End Date';
COMMENT ON COLUMN committees.notes IS 'Optional notes';
COMMENT ON COLUMN committees.status IS 'Active / Closed';
COMMENT ON COLUMN committees.created_by IS 'User who created the committee';

-- 4. Create committee_entities junction table
CREATE TABLE IF NOT EXISTS committee_entities (
  id VARCHAR PRIMARY KEY DEFAULT gen_random_uuid()::text,
  committee_id VARCHAR NOT NULL REFERENCES committees(id) ON DELETE CASCADE,
  entity_id VARCHAR NOT NULL REFERENCES entities(id) ON DELETE CASCADE,
  created_at TIMESTAMP DEFAULT NOW(),
  UNIQUE(committee_id, entity_id) -- Prevent duplicate entity entries per committee
);

-- Add comments
COMMENT ON TABLE committee_entities IS 'Junction table linking committees to entities';
COMMENT ON COLUMN committee_entities.committee_id IS 'Committee ID';
COMMENT ON COLUMN committee_entities.entity_id IS 'Entity ID';

-- 5. Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_committees_status ON committees(status);
CREATE INDEX IF NOT EXISTS idx_committees_created_by ON committees(created_by);
CREATE INDEX IF NOT EXISTS idx_committees_period ON committees(period);
CREATE INDEX IF NOT EXISTS idx_committee_entities_committee_id ON committee_entities(committee_id);
CREATE INDEX IF NOT EXISTS idx_committee_entities_entity_id ON committee_entities(entity_id);
CREATE INDEX IF NOT EXISTS idx_cases_committee_id ON cases(committee_id);
CREATE INDEX IF NOT EXISTS idx_entities_status ON entities(status);

-- 6. Add foreign key constraint for cases.committee_id (if not exists)
-- Note: This is a nullable foreign key, so we need to check if constraint exists first
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint 
    WHERE conname = 'cases_committee_id_fkey'
  ) THEN
    ALTER TABLE cases 
    ADD CONSTRAINT cases_committee_id_fkey 
    FOREIGN KEY (committee_id) REFERENCES committees(id) ON DELETE SET NULL;
  END IF;
END $$;

