-- Migration: Structured Case Reports V2
-- Creates new structured report tables with sections, history, and calculated fields

-- Step 1: Create case_reports_v2 table
CREATE TABLE IF NOT EXISTS case_reports_v2 (
  id VARCHAR PRIMARY KEY DEFAULT gen_random_uuid()::text,
  case_id VARCHAR UNIQUE NOT NULL REFERENCES cases(id) ON DELETE CASCADE,
  
  -- Report Status
  status VARCHAR NOT NULL DEFAULT 'draft',
  version INTEGER NOT NULL DEFAULT 1,
  
  -- Section 1: Entity Details - Basic
  company_name TEXT NOT NULL,
  tin TEXT NOT NULL,
  business_nature TEXT,
  group_referrer TEXT NOT NULL,
  referral_date TEXT NOT NULL,
  periods_under_review TEXT NOT NULL,
  final_document_date TEXT,
  capital_period TEXT,
  
  -- Address Information
  province TEXT,
  district TEXT,
  street_address TEXT,
  postal_code TEXT,
  phone TEXT,
  email TEXT,
  
  -- Registration Details
  registration_number TEXT,
  registration_date TEXT,
  business_license_number TEXT,
  business_license_date TEXT,
  
  -- Tax Information
  tax_office TEXT,
  tax_registration_date TEXT,
  tax_office_code TEXT,
  
  -- Section 2: Tax Types
  salary_tax NUMERIC(15, 2) DEFAULT 0,
  rent_tax NUMERIC(15, 2) DEFAULT 0,
  contract_tax NUMERIC(15, 2) DEFAULT 0,
  profit_transaction_tax NUMERIC(15, 2) DEFAULT 0,
  income_tax NUMERIC(15, 2) DEFAULT 0,
  withholding_tax NUMERIC(15, 2) DEFAULT 0,
  penalty_tax NUMERIC(15, 2) DEFAULT 0,
  interest NUMERIC(15, 2) DEFAULT 0,
  other_taxes NUMERIC(15, 2) DEFAULT 0,
  
  -- Financial Calculations
  reduced_loss NUMERIC(15, 2) DEFAULT 0,
  reduced_remaining_amount NUMERIC(15, 2) DEFAULT 0,
  confirmed_amount NUMERIC(15, 2) DEFAULT 0,
  collected_current_month NUMERIC(15, 2) DEFAULT 0,
  remaining_collectible NUMERIC(15, 2) DEFAULT 0,
  
  -- Calculation Details
  tax_base NUMERIC(15, 2),
  tax_rate NUMERIC(5, 2),
  calculation_method TEXT,
  
  -- Payment Information
  payment_method TEXT,
  payment_reference_number TEXT,
  payment_date TEXT,
  bank_name TEXT,
  bank_account_number TEXT,
  bank_branch TEXT,
  
  -- Status & Attachment
  activity_status TEXT,
  attachment_number TEXT,
  attachment_date TEXT,
  
  -- Section 3: Findings & Recommendations
  findings_summary TEXT,
  detailed_findings TEXT,
  risk_assessment TEXT,
  recommendations TEXT,
  action_items TEXT,
  follow_up_required BOOLEAN DEFAULT false,
  follow_up_date TEXT,
  
  -- Section 4: Supporting Documents
  documents_reviewed JSONB DEFAULT '[]'::jsonb,
  documents_attached JSONB DEFAULT '[]'::jsonb,
  missing_documents TEXT,
  document_review_date TEXT,
  document_review_notes TEXT,
  
  -- Section 5: Approval & Signatures
  prepared_by VARCHAR REFERENCES users(id) ON DELETE SET NULL,
  prepared_at TIMESTAMP,
  prepared_by_role TEXT,
  reviewed_by VARCHAR REFERENCES users(id) ON DELETE SET NULL,
  reviewed_at TIMESTAMP,
  reviewed_by_role TEXT,
  review_notes TEXT,
  approved_by VARCHAR REFERENCES users(id) ON DELETE SET NULL,
  approved_at TIMESTAMP,
  approved_by_role TEXT,
  
  -- Metadata
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
  last_saved_by VARCHAR REFERENCES users(id) ON DELETE SET NULL,
  last_saved_at TIMESTAMP,
  
  -- Constraints
  CONSTRAINT case_reports_v2_status_check CHECK (status IN ('draft', 'completed', 'locked')),
  CONSTRAINT case_reports_v2_risk_assessment_check CHECK (risk_assessment IN ('کم', 'متوسط', 'زیاد') OR risk_assessment IS NULL),
  CONSTRAINT case_reports_v2_activity_status_check CHECK (activity_status IN ('فعال', 'عدم فعالیت') OR activity_status IS NULL)
);

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_case_reports_v2_case_id ON case_reports_v2(case_id);
CREATE INDEX IF NOT EXISTS idx_case_reports_v2_status ON case_reports_v2(status);
CREATE INDEX IF NOT EXISTS idx_case_reports_v2_prepared_by ON case_reports_v2(prepared_by);
CREATE INDEX IF NOT EXISTS idx_case_reports_v2_created_at ON case_reports_v2(created_at);

-- Step 2: Create case_report_history table
CREATE TABLE IF NOT EXISTS case_report_history (
  id VARCHAR PRIMARY KEY DEFAULT gen_random_uuid()::text,
  report_id VARCHAR NOT NULL REFERENCES case_reports_v2(id) ON DELETE CASCADE,
  version INTEGER NOT NULL,
  changed_by VARCHAR NOT NULL REFERENCES users(id) ON DELETE SET NULL,
  changed_at TIMESTAMP NOT NULL DEFAULT NOW(),
  change_type VARCHAR NOT NULL,
  section VARCHAR,
  changes JSONB,
  snapshot JSONB,
  notes TEXT,
  
  CONSTRAINT case_report_history_change_type_check CHECK (change_type IN ('create', 'update', 'status_change', 'section_complete'))
);

-- Create indexes for history
CREATE INDEX IF NOT EXISTS idx_case_report_history_report_id ON case_report_history(report_id);
CREATE INDEX IF NOT EXISTS idx_case_report_history_changed_at ON case_report_history(changed_at);
CREATE INDEX IF NOT EXISTS idx_case_report_history_version ON case_report_history(report_id, version);

-- Step 3: Migrate existing data from case_reports to case_reports_v2
DO $$
BEGIN
  IF EXISTS (SELECT FROM information_schema.tables WHERE table_name = 'case_reports') THEN
    INSERT INTO case_reports_v2 (
      case_id, status, version,
      company_name, tin, business_nature, group_referrer, referral_date, periods_under_review,
      final_document_date, capital_period,
      salary_tax, rent_tax, contract_tax, profit_transaction_tax, income_tax,
      reduced_loss, reduced_remaining_amount, confirmed_amount, collected_current_month, remaining_collectible,
      activity_status, attachment_number, attachment_date,
      created_at, updated_at
    )
    SELECT 
      cr.case_id,
      'completed'::VARCHAR,
      1,
      c.company_name,
      c.tin,
      c.business_nature,
      c.group_referrer,
      c.referral_date,
      c.periods_under_review,
      cr.final_document_date,
      cr.capital_period,
      COALESCE(CAST(NULLIF(cr.salary_tax, '') AS NUMERIC), 0),
      COALESCE(CAST(NULLIF(cr.rent_tax, '') AS NUMERIC), 0),
      COALESCE(CAST(NULLIF(cr.contract_tax, '') AS NUMERIC), 0),
      COALESCE(CAST(NULLIF(cr.profit_transaction_tax, '') AS NUMERIC), 0),
      COALESCE(CAST(NULLIF(cr.income_tax, '') AS NUMERIC), 0),
      COALESCE(CAST(NULLIF(cr.reduced_loss, '') AS NUMERIC), 0),
      COALESCE(CAST(NULLIF(cr.reduced_remaining_amount, '') AS NUMERIC), 0),
      COALESCE(CAST(NULLIF(cr.confirmed_amount, '') AS NUMERIC), 0),
      COALESCE(CAST(NULLIF(cr.collected_current_month, '') AS NUMERIC), 0),
      COALESCE(CAST(NULLIF(cr.remaining_collectible, '') AS NUMERIC), 0),
      cr.activity_status,
      cr.attachment_number,
      cr.attachment_date,
      cr.created_at,
      cr.updated_at
    FROM case_reports cr
    JOIN cases c ON c.id = cr.case_id
    WHERE NOT EXISTS (
      SELECT 1 FROM case_reports_v2 cr2 WHERE cr2.case_id = cr.case_id
    )
    ON CONFLICT (case_id) DO NOTHING;
  END IF;
EXCEPTION
  WHEN OTHERS THEN
    -- Ignore errors (table might not exist or already migrated)
    NULL;
END $$;
