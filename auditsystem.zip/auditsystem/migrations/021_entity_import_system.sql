-- Migration: Entity Import System
-- Adds import tracking tables and extends entities table with import-related fields

-- Add new columns to entities table
ALTER TABLE entities 
  ADD COLUMN IF NOT EXISTS referred_date_shamsi VARCHAR(10),
  ADD COLUMN IF NOT EXISTS referred_date DATE,
  ADD COLUMN IF NOT EXISTS import_batch_id INTEGER,
  ADD COLUMN IF NOT EXISTS created_by_import BOOLEAN DEFAULT FALSE,
  ADD COLUMN IF NOT EXISTS responsible_evaluator VARCHAR(255);

-- Create import_batches table
CREATE TABLE IF NOT EXISTS import_batches (
  id SERIAL PRIMARY KEY,
  uploaded_by VARCHAR(255) NOT NULL REFERENCES users(id) ON DELETE SET NULL,
  file_name TEXT NOT NULL,
  file_path TEXT NOT NULL,
  file_size_bytes INTEGER NOT NULL,
  total_rows INTEGER DEFAULT 0,
  created_count INTEGER DEFAULT 0,
  updated_count INTEGER DEFAULT 0,
  invalid_count INTEGER DEFAULT 0,
  status VARCHAR(50) NOT NULL DEFAULT 'pending', -- 'pending', 'processing', 'completed', 'failed'
  error_file_path TEXT,
  started_at TIMESTAMP,
  completed_at TIMESTAMP,
  error_message TEXT,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

-- Create import_errors table
CREATE TABLE IF NOT EXISTS import_errors (
  id SERIAL PRIMARY KEY,
  batch_id INTEGER NOT NULL REFERENCES import_batches(id) ON DELETE CASCADE,
  row_number INTEGER NOT NULL,
  tin TEXT,
  company_name TEXT,
  error_type VARCHAR(50) NOT NULL, -- 'validation_error', 'duplicate_tin', 'database_error'
  error_message TEXT NOT NULL,
  raw_row_data JSONB,
  created_at TIMESTAMP DEFAULT NOW()
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_import_batches_uploaded_by ON import_batches(uploaded_by);
CREATE INDEX IF NOT EXISTS idx_import_batches_status ON import_batches(status);
CREATE INDEX IF NOT EXISTS idx_import_batches_created_at ON import_batches(created_at);
CREATE INDEX IF NOT EXISTS idx_import_errors_batch_id ON import_errors(batch_id);
CREATE INDEX IF NOT EXISTS idx_entities_import_batch_id ON entities(import_batch_id);
CREATE INDEX IF NOT EXISTS idx_entities_created_by_import ON entities(created_by_import);

-- Add comments
COMMENT ON TABLE import_batches IS 'Tracks Excel import batches for entities';
COMMENT ON TABLE import_errors IS 'Stores validation and processing errors for import rows';
COMMENT ON COLUMN entities.referred_date_shamsi IS 'Shamsi date string (DD-MM-YYYY) for referral date';
COMMENT ON COLUMN entities.referred_date IS 'Gregorian date for referral date';
COMMENT ON COLUMN entities.import_batch_id IS 'Reference to import batch that created/updated this entity';
COMMENT ON COLUMN entities.created_by_import IS 'Flag indicating entity was created via import';
COMMENT ON COLUMN entities.responsible_evaluator IS 'Responsible evaluator name from import';


