-- Migration: Create monthly_transactions table
-- WORKFLOW TABLE: Temporary table for audit reporting workflow calculations
-- Stores per-entity monthly audit data without modifying the master entity table
-- All data must be linked to entities table via EntityTIN ( نمبر تشخیصیه)
-- This table is read-only from master entities table and used for workflow calculations

DO $$
BEGIN
  IF NOT EXISTS (SELECT FROM information_schema.tables WHERE table_name = 'monthly_transactions') THEN
    CREATE TABLE monthly_transactions (
      -- TransactionID: Workflow-generated unique ID
      id VARCHAR PRIMARY KEY DEFAULT gen_random_uuid()::text,
      
      -- EntityTIN: Link to master entity table ( نمبر تشخیصیه)
      entity_tin TEXT NOT NULL, --  نمبر تشخیصیه - links to entities.tin
      
      -- Time Period (Shamsi Calendar)
      month_shamsi INTEGER NOT NULL CHECK (month_shamsi >= 1 AND month_shamsi <= 12), -- برج
      year_shamsi INTEGER NOT NULL CHECK (year_shamsi >= 1300 AND year_shamsi <= 1500), -- سال
      
      -- Tax Fields (مالیات‌ها)
      tax_salary NUMERIC(15, 2) DEFAULT 0, -- مالیه موضوعی معاشات
      tax_rent NUMERIC(15, 2) DEFAULT 0, -- مالیه موضوعی بر کرایه
      tax_contract NUMERIC(15, 2) DEFAULT 0, -- مالیه موضوعی قراردادی
      tax_profit NUMERIC(15, 2) DEFAULT 0, -- مالیه موضوعی معاملات انتفاعی
      income_tax NUMERIC(15, 2) DEFAULT 0, -- مالیات بر عایدات
      
      -- Financial Amounts (مبالغ مالی)
      loss_reduction NUMERIC(15, 2) DEFAULT 0, -- ضرر کاهش یافته
      collected_amount NUMERIC(15, 2) DEFAULT 0, -- مبلغ تحصیل شده طی برج جاری
      remaining_amount NUMERIC(15, 2) DEFAULT 0, -- الباقی مبلغ قابل تحصیل
      stabilized_amount NUMERIC(15, 2) DEFAULT 0, -- مبلغ تثبیت شده
      
      -- Correspondence Data (مکاتبات)
      correspondences_in INTEGER DEFAULT 0, -- تعداد مکتوب های وارده
      correspondences_out INTEGER DEFAULT 0, -- تعداد مکتوب های صادره
      
      -- Inquiry Data (استعلامات)
      inquiries_in INTEGER DEFAULT 0, -- تعداد استعلام های وارده
      inquiries_out INTEGER DEFAULT 0, -- تعداد استعلام های صادره
      
      -- Notes (ملاحظات)
      notes TEXT, -- ملاحظات
      
      -- Metadata
      created_at TIMESTAMP DEFAULT NOW(),
      updated_at TIMESTAMP DEFAULT NOW(),
      
      -- Unique constraint: one transaction record per entity (TIN) per month/year
      UNIQUE(entity_tin, month_shamsi, year_shamsi)
    );

    -- Create indexes for faster lookups
    CREATE INDEX idx_monthly_transactions_entity_tin ON monthly_transactions(entity_tin);
    CREATE INDEX idx_monthly_transactions_month_year ON monthly_transactions(year_shamsi, month_shamsi);
    CREATE INDEX idx_monthly_transactions_updated ON monthly_transactions(updated_at DESC);

    -- Add comments
    COMMENT ON TABLE monthly_transactions IS 'WORKFLOW TABLE: Temporary table for audit reporting workflow calculations. Stores per-entity monthly audit data. Links to entities table via EntityTIN.';
    COMMENT ON COLUMN monthly_transactions.id IS 'TransactionID: Workflow-generated unique ID';
    COMMENT ON COLUMN monthly_transactions.entity_tin IS 'EntityTIN:  نمبر تشخیصیه - Links to entities.tin (master entity table)';
    COMMENT ON COLUMN monthly_transactions.month_shamsi IS 'Month: برج (1-12)';
    COMMENT ON COLUMN monthly_transactions.year_shamsi IS 'Year: سال (Shamsi year, e.g., 1404)';
    COMMENT ON COLUMN monthly_transactions.tax_salary IS 'TaxSalary: مالیه موضوعی معاشات';
    COMMENT ON COLUMN monthly_transactions.tax_rent IS 'TaxRent: مالیه موضوعی بر کرایه';
    COMMENT ON COLUMN monthly_transactions.tax_contract IS 'TaxContract: مالیه موضوعی قراردادی';
    COMMENT ON COLUMN monthly_transactions.tax_profit IS 'TaxProfit: مالیه موضوعی معاملات انتفاعی';
    COMMENT ON COLUMN monthly_transactions.income_tax IS 'IncomeTax: مالیات بر عایدات';
    COMMENT ON COLUMN monthly_transactions.loss_reduction IS 'LossReduction: ضرر کاهش یافته';
    COMMENT ON COLUMN monthly_transactions.collected_amount IS 'CollectedAmount: مبلغ تحصیل شده طی برج جاری';
    COMMENT ON COLUMN monthly_transactions.remaining_amount IS 'RemainingAmount: الباقی مبلغ قابل تحصیل';
    COMMENT ON COLUMN monthly_transactions.stabilized_amount IS 'StabilizedAmount: مبلغ تثبیت شده';
    COMMENT ON COLUMN monthly_transactions.correspondences_in IS 'CorrespondencesIn: تعداد مکتوب های وارده';
    COMMENT ON COLUMN monthly_transactions.correspondences_out IS 'CorrespondencesOut: تعداد مکتوب های صادره';
    COMMENT ON COLUMN monthly_transactions.inquiries_in IS 'InquiriesIn: تعداد استعلام های وارده';
    COMMENT ON COLUMN monthly_transactions.inquiries_out IS 'InquiriesOut: تعداد استعلام های صادره';
    COMMENT ON COLUMN monthly_transactions.notes IS 'Notes: ملاحظات';

    RAISE NOTICE 'Table monthly_transactions created successfully';
  ELSE
    RAISE NOTICE 'Table monthly_transactions already exists, skipping creation';
  END IF;
END $$;

