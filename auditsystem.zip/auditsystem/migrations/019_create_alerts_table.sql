-- Migration: Create alerts table
-- WORKFLOW TABLE: Temporary table for storing underperformance alerts
-- Flags entities and groups that need attention based on performance thresholds

DO $$
BEGIN
  IF NOT EXISTS (SELECT FROM information_schema.tables WHERE table_name = 'workflow_alerts') THEN
    CREATE TABLE workflow_alerts (
      id VARCHAR PRIMARY KEY DEFAULT gen_random_uuid()::text,
      
      -- Alert Target (either EntityTIN or GroupName)
      entity_tin TEXT, -- EntityTIN:  نمبر تشخیصیه (NULL if group alert)
      group_name TEXT, -- GroupName: نام گروه (NULL if entity alert)
      
      -- Alert Type
      alert_type TEXT NOT NULL, -- AlertType: 'entity_remaining_amount', 'group_revenue_target', etc.
      
      -- Alert Message
      message TEXT NOT NULL, -- Message: Human-readable alert message
      
      -- Time Period
      month_shamsi INTEGER NOT NULL CHECK (month_shamsi >= 1 AND month_shamsi <= 12), -- Month: برج
      year_shamsi INTEGER NOT NULL CHECK (year_shamsi >= 1300 AND year_shamsi <= 1500), -- Year: سال
      
      -- Alert Severity
      severity TEXT NOT NULL DEFAULT 'medium', -- 'low', 'medium', 'high', 'critical'
      
      -- Alert Status
      status TEXT NOT NULL DEFAULT 'active', -- 'active', 'acknowledged', 'resolved', 'dismissed'
      
      -- Alert Details (JSONB for flexible data storage)
      details JSONB, -- Additional alert details (threshold, actual value, target value, etc.)
      
      -- Metadata
      acknowledged_by VARCHAR REFERENCES users(id) ON DELETE SET NULL,
      acknowledged_at TIMESTAMP,
      resolved_at TIMESTAMP,
      created_at TIMESTAMP DEFAULT NOW(),
      updated_at TIMESTAMP DEFAULT NOW()
    );

    -- Create indexes for faster lookups
    CREATE INDEX idx_workflow_alerts_entity_tin ON workflow_alerts(entity_tin) WHERE entity_tin IS NOT NULL;
    CREATE INDEX idx_workflow_alerts_group_name ON workflow_alerts(group_name) WHERE group_name IS NOT NULL;
    CREATE INDEX idx_workflow_alerts_type ON workflow_alerts(alert_type);
    CREATE INDEX idx_workflow_alerts_month_year ON workflow_alerts(year_shamsi, month_shamsi);
    CREATE INDEX idx_workflow_alerts_status ON workflow_alerts(status);
    CREATE INDEX idx_workflow_alerts_severity ON workflow_alerts(severity);
    CREATE INDEX idx_workflow_alerts_created ON workflow_alerts(created_at DESC);

    -- Add comments
    COMMENT ON TABLE workflow_alerts IS 'WORKFLOW TABLE: Stores underperformance alerts for entities and groups. Temporary table for dashboard highlighting and notifications.';
    COMMENT ON COLUMN workflow_alerts.id IS 'AlertID: Primary key - Workflow-generated unique ID';
    COMMENT ON COLUMN workflow_alerts.entity_tin IS 'EntityTIN:  نمبر تشخیصیه - NULL if this is a group alert';
    COMMENT ON COLUMN workflow_alerts.group_name IS 'GroupName: نام گروه - NULL if this is an entity alert';
    COMMENT ON COLUMN workflow_alerts.alert_type IS 'AlertType: Type of alert (e.g., entity_remaining_amount, group_revenue_target)';
    COMMENT ON COLUMN workflow_alerts.message IS 'Message: Human-readable alert message';
    COMMENT ON COLUMN workflow_alerts.month_shamsi IS 'Month: برج (1-12)';
    COMMENT ON COLUMN workflow_alerts.year_shamsi IS 'Year: سال (Shamsi year, e.g., 1404)';
    COMMENT ON COLUMN workflow_alerts.severity IS 'Severity: low, medium, high, critical';
    COMMENT ON COLUMN workflow_alerts.status IS 'Status: active, acknowledged, resolved, dismissed';
    COMMENT ON COLUMN workflow_alerts.details IS 'Details: Additional alert data in JSON format';

    RAISE NOTICE 'Table workflow_alerts created successfully';
  ELSE
    RAISE NOTICE 'Table workflow_alerts already exists, skipping creation';
  END IF;
END $$;

