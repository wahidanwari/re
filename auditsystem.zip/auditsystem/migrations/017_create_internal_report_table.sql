-- Migration: Create internal_report table
-- WORKFLOW TABLE: Temporary table for internal reporting workflow calculations
-- Aggregates per-entity monthly data from monthly_transactions for internal reporting
-- This table is read-only from master entities table and used for workflow calculations

DO $$
BEGIN
  IF NOT EXISTS (SELECT FROM information_schema.tables WHERE table_name = 'internal_report') THEN
    CREATE TABLE internal_report (
      id VARCHAR PRIMARY KEY DEFAULT gen_random_uuid()::text,
      
      -- Entity Link (via TIN -  نمبر تشخیصیه)
      entity_tin TEXT NOT NULL, -- EntityTIN:  نمبر تشخیصیه - links to entities.tin
      entity_name TEXT NOT NULL, -- EntityName: نام نهاد - from entities.company_name
      
      -- Time Period (Shamsi Calendar)
      month_shamsi INTEGER NOT NULL CHECK (month_shamsi >= 1 AND month_shamsi <= 12), -- Month: برج
      year_shamsi INTEGER NOT NULL CHECK (year_shamsi >= 1300 AND year_shamsi <= 1500), -- Year: سال
      
      -- Calculated Tax Amounts
      total_taxable_amount NUMERIC(15, 2) DEFAULT 0, -- TotalTaxableAmount: Sum of all tax types
      -- Calculated as: TaxSalary + TaxRent + TaxContract + TaxProfit + IncomeTax
      
      -- Financial Amounts
      collected_amount NUMERIC(15, 2) DEFAULT 0, -- CollectedAmount: مبلغ تحصیل شده
      remaining_amount NUMERIC(15, 2) DEFAULT 0, -- RemainingAmount: Calculated as TotalTaxableAmount - CollectedAmount
      stabilized_amount NUMERIC(15, 2) DEFAULT 0, -- StabilizedAmount: مبلغ تثبیت شده
      
      -- Additional Fields from MonthlyTransactions
      tax_salary NUMERIC(15, 2) DEFAULT 0, -- مالیه موضوعی معاشات
      tax_rent NUMERIC(15, 2) DEFAULT 0, -- مالیه موضوعی بر کرایه
      tax_contract NUMERIC(15, 2) DEFAULT 0, -- مالیه موضوعی قراردادی
      tax_profit NUMERIC(15, 2) DEFAULT 0, -- مالیه موضوعی معاملات انتفاعی
      income_tax NUMERIC(15, 2) DEFAULT 0, -- مالیات بر عایدات
      loss_reduction NUMERIC(15, 2) DEFAULT 0, -- ضرر کاهش یافته
      
      -- Correspondence & Inquiry Data
      correspondences_in INTEGER DEFAULT 0, -- تعداد مکتوب های وارده
      correspondences_out INTEGER DEFAULT 0, -- تعداد مکتوب های صادره
      inquiries_in INTEGER DEFAULT 0, -- تعداد استعلام های وارده
      inquiries_out INTEGER DEFAULT 0, -- تعداد استعلام های صادره
      
      -- Status
      status TEXT NOT NULL DEFAULT 'active', -- Status: 'active' or 'inactive'
      
      -- Notes
      notes TEXT, -- Notes: ملاحظات
      
      -- Metadata
      created_at TIMESTAMP DEFAULT NOW(),
      updated_at TIMESTAMP DEFAULT NOW(),
      
      -- Unique constraint: one report per entity (TIN) per month/year
      UNIQUE(entity_tin, month_shamsi, year_shamsi)
    );

    -- Create indexes for faster lookups
    CREATE INDEX idx_internal_report_entity_tin ON internal_report(entity_tin);
    CREATE INDEX idx_internal_report_month_year ON internal_report(year_shamsi, month_shamsi);
    CREATE INDEX idx_internal_report_status ON internal_report(status);
    CREATE INDEX idx_internal_report_updated ON internal_report(updated_at DESC);

    -- Add comments
    COMMENT ON TABLE internal_report IS 'WORKFLOW TABLE: Aggregates per-entity monthly data from monthly_transactions for internal reporting. Links to entities table via EntityTIN.';
    COMMENT ON COLUMN internal_report.id IS 'Primary key - Workflow-generated unique ID';
    COMMENT ON COLUMN internal_report.entity_tin IS 'EntityTIN:  نمبر تشخیصیه - Links to entities.tin (master entity table)';
    COMMENT ON COLUMN internal_report.entity_name IS 'EntityName: نام نهاد - From entities.company_name';
    COMMENT ON COLUMN internal_report.month_shamsi IS 'Month: برج (1-12)';
    COMMENT ON COLUMN internal_report.year_shamsi IS 'Year: سال (Shamsi year, e.g., 1404)';
    COMMENT ON COLUMN internal_report.total_taxable_amount IS 'TotalTaxableAmount: Sum of TaxSalary + TaxRent + TaxContract + TaxProfit + IncomeTax';
    COMMENT ON COLUMN internal_report.collected_amount IS 'CollectedAmount: مبلغ تحصیل شده';
    COMMENT ON COLUMN internal_report.remaining_amount IS 'RemainingAmount: Calculated as TotalTaxableAmount - CollectedAmount';
    COMMENT ON COLUMN internal_report.stabilized_amount IS 'StabilizedAmount: مبلغ تثبیت شده';
    COMMENT ON COLUMN internal_report.status IS 'Status: active or inactive';

    RAISE NOTICE 'Table internal_report created successfully';
  ELSE
    RAISE NOTICE 'Table internal_report already exists, skipping creation';
  END IF;
END $$;

-- Create a view for monthly totals (aggregated across all entities for a given month/year)
-- This provides the "monthly totals at the bottom" functionality
CREATE OR REPLACE VIEW internal_report_monthly_totals AS
SELECT 
  month_shamsi,
  year_shamsi,
  COUNT(*) as entity_count,
  SUM(total_taxable_amount) as total_taxable_amount,
  SUM(collected_amount) as total_collected,
  SUM(stabilized_amount) as total_stabilized,
  SUM(remaining_amount) as total_remaining,
  SUM(correspondences_in) as total_correspondences_in,
  SUM(correspondences_out) as total_correspondences_out,
  SUM(inquiries_in) as total_inquiries_in,
  SUM(inquiries_out) as total_inquiries_out
FROM internal_report
WHERE status = 'active'
GROUP BY month_shamsi, year_shamsi;

COMMENT ON VIEW internal_report_monthly_totals IS 'Monthly totals aggregated across all active entities for internal reporting';

