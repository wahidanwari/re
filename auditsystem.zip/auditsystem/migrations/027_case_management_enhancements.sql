-- Migration: Case Management Enhancements
-- Adds assignment tracking, override fields, metrics, installments, and flags
-- Migration Date: 2025-01-XX

-- Step 1: Add new columns to cases table
DO $$
BEGIN
  -- Add assignment tracking columns
  ALTER TABLE cases ADD COLUMN IF NOT EXISTS assigned_by VARCHAR REFERENCES users(id) ON DELETE SET NULL;
  ALTER TABLE cases ADD COLUMN IF NOT EXISTS assigned_at TIMESTAMP;
  
  -- Add override field columns (original values)
  ALTER TABLE cases ADD COLUMN IF NOT EXISTS institution_info_original TEXT;
  
  -- Add override field columns (manual values)
  ALTER TABLE cases ADD COLUMN IF NOT EXISTS institution_info_manual TEXT;
  ALTER TABLE cases ADD COLUMN IF NOT EXISTS institution_info_overridden_by VARCHAR REFERENCES users(id) ON DELETE SET NULL;
  ALTER TABLE cases ADD COLUMN IF NOT EXISTS institution_info_overridden_at TIMESTAMP;
  ALTER TABLE cases ADD COLUMN IF NOT EXISTS representative_name_manual VARCHAR;
  ALTER TABLE cases ADD COLUMN IF NOT EXISTS representative_phone_manual VARCHAR;
  ALTER TABLE cases ADD COLUMN IF NOT EXISTS institution_address_manual TEXT;
  
  -- Add reopen tracking
  ALTER TABLE cases ADD COLUMN IF NOT EXISTS reopened_by VARCHAR REFERENCES users(id) ON DELETE SET NULL;
  ALTER TABLE cases ADD COLUMN IF NOT EXISTS reopened_at TIMESTAMP;
  ALTER TABLE cases ADD COLUMN IF NOT EXISTS reopen_reason TEXT;
END $$;

-- Step 2: Update status check constraint to include new statuses
DO $$
BEGIN
  -- Drop existing constraint if it exists
  ALTER TABLE cases DROP CONSTRAINT IF EXISTS cases_status_check;
  
  -- Add check constraint for valid status values (including new statuses)
  ALTER TABLE cases
    ADD CONSTRAINT cases_status_check 
    CHECK (status IN (
      'جدید', 
      'اختصاص داده شده', 
      'در جریان بررسی', 
      'تکمیل شده', 
      'منتظر تایید', 
      'تایید شده', 
      'رد شده',
      'عدم پاسخگو',
      'ارسال‌ شده به تنفیذ قانون'
    ));
END $$;

-- Step 3: Create case_metrics table
DO $$
BEGIN
  IF NOT EXISTS (SELECT FROM information_schema.tables WHERE table_name = 'case_metrics') THEN
    CREATE TABLE case_metrics (
      id VARCHAR PRIMARY KEY DEFAULT gen_random_uuid()::text,
      case_id VARCHAR NOT NULL UNIQUE REFERENCES cases(id) ON DELETE CASCADE,
      installments_this_month INTEGER DEFAULT 0,
      nonresponsive_count INTEGER DEFAULT 0,
      incoming_documents INTEGER DEFAULT 0,
      outgoing_documents INTEGER DEFAULT 0,
      incoming_inquiries INTEGER DEFAULT 0,
      outgoing_inquiries INTEGER DEFAULT 0,
      remarks TEXT,
      last_updated_by VARCHAR REFERENCES users(id) ON DELETE SET NULL,
      last_updated_at TIMESTAMP DEFAULT NOW(),
      created_at TIMESTAMP DEFAULT NOW()
    );
    
    -- Create indexes
    CREATE INDEX idx_case_metrics_case_id ON case_metrics(case_id);
    CREATE INDEX idx_case_metrics_last_updated_at ON case_metrics(last_updated_at);
  END IF;
END $$;

-- Step 4: Create installment_payments table
DO $$
BEGIN
  IF NOT EXISTS (SELECT FROM information_schema.tables WHERE table_name = 'installment_payments') THEN
    CREATE TABLE installment_payments (
      id VARCHAR PRIMARY KEY DEFAULT gen_random_uuid()::text,
      case_id VARCHAR NOT NULL REFERENCES cases(id) ON DELETE CASCADE,
      taxpayer_id VARCHAR,
      payment_date DATE NOT NULL,
      month_reference VARCHAR NOT NULL, -- e.g., 'ثور', 'جوزا', etc.
      amount NUMERIC(15, 2) NOT NULL DEFAULT 0,
      created_by VARCHAR NOT NULL REFERENCES users(id) ON DELETE SET NULL,
      created_at TIMESTAMP DEFAULT NOW()
    );
    
    -- Create indexes
    CREATE INDEX idx_installment_payments_case_id ON installment_payments(case_id);
    CREATE INDEX idx_installment_payments_payment_date ON installment_payments(payment_date);
    CREATE INDEX idx_installment_payments_month_reference ON installment_payments(month_reference);
    CREATE INDEX idx_installment_payments_created_at ON installment_payments(created_at);
  END IF;
END $$;

-- Step 5: Create case_flags table
DO $$
BEGIN
  IF NOT EXISTS (SELECT FROM information_schema.tables WHERE table_name = 'case_flags') THEN
    CREATE TABLE case_flags (
      id VARCHAR PRIMARY KEY DEFAULT gen_random_uuid()::text,
      case_id VARCHAR NOT NULL REFERENCES cases(id) ON DELETE CASCADE,
      type VARCHAR NOT NULL, -- 'nonresponsive_attempt', 'nonresponsive_mark', 'escalation_to_enforcement', 'assignment', 'override', etc.
      details JSONB, -- Flexible storage for attempt count, notes, etc.
      created_by VARCHAR NOT NULL REFERENCES users(id) ON DELETE SET NULL,
      created_at TIMESTAMP DEFAULT NOW()
    );
    
    -- Create indexes
    CREATE INDEX idx_case_flags_case_id ON case_flags(case_id);
    CREATE INDEX idx_case_flags_type ON case_flags(type);
    CREATE INDEX idx_case_flags_created_at ON case_flags(created_at);
  END IF;
END $$;

-- Step 6: Create case_section_status table for tracking section completion
DO $$
BEGIN
  IF NOT EXISTS (SELECT FROM information_schema.tables WHERE table_name = 'case_section_status') THEN
    CREATE TABLE case_section_status (
      id VARCHAR PRIMARY KEY DEFAULT gen_random_uuid()::text,
      case_id VARCHAR NOT NULL REFERENCES cases(id) ON DELETE CASCADE,
      section_id VARCHAR NOT NULL, -- 'section_1', 'section_2', etc.
      is_completed BOOLEAN DEFAULT FALSE,
      completed_by VARCHAR REFERENCES users(id) ON DELETE SET NULL,
      completed_at TIMESTAMP,
      created_at TIMESTAMP DEFAULT NOW(),
      updated_at TIMESTAMP DEFAULT NOW(),
      UNIQUE(case_id, section_id)
    );
    
    -- Create indexes
    CREATE INDEX idx_case_section_status_case_id ON case_section_status(case_id);
    CREATE INDEX idx_case_section_status_section_id ON case_section_status(section_id);
  END IF;
END $$;

-- Step 7: Backfill institution_info_original from entities table if possible
DO $$
BEGIN
  UPDATE cases c
  SET institution_info_original = (
    SELECT 
      COALESCE(
        e.registered_address || E'\n' || 
        COALESCE(e.contact_person, '') || E'\n' || 
        COALESCE(e.phone, ''),
        ''
      )
    FROM entities e
    WHERE e.id = c.entity_id
  )
  WHERE c.institution_info_original IS NULL;
END $$;

-- Step 8: Create indexes for performance
DO $$
BEGIN
  -- Index on assigned_by
  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes WHERE indexname = 'idx_cases_assigned_by'
  ) THEN
    CREATE INDEX idx_cases_assigned_by ON cases(assigned_by) WHERE assigned_by IS NOT NULL;
  END IF;
  
  -- Index on assigned_at
  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes WHERE indexname = 'idx_cases_assigned_at'
  ) THEN
    CREATE INDEX idx_cases_assigned_at ON cases(assigned_at) WHERE assigned_at IS NOT NULL;
  END IF;
  
  -- Index on status for filtering (including new statuses)
  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes WHERE indexname = 'idx_cases_status_enhanced'
  ) THEN
    CREATE INDEX idx_cases_status_enhanced ON cases(status);
  END IF;
END $$;

-- Step 9: Add comments for documentation
COMMENT ON COLUMN cases.assigned_by IS 'User who assigned this case';
COMMENT ON COLUMN cases.assigned_at IS 'Timestamp when case was assigned';
COMMENT ON COLUMN cases.institution_info_original IS 'Original extracted institution information';
COMMENT ON COLUMN cases.institution_info_manual IS 'Manual override of institution information';
COMMENT ON COLUMN cases.representative_name_manual IS 'Manual override of representative name';
COMMENT ON COLUMN cases.representative_phone_manual IS 'Manual override of representative phone';
COMMENT ON COLUMN cases.institution_address_manual IS 'Manual override of institution address';
COMMENT ON TABLE case_metrics IS 'Senior auditor reporting metrics per case';
COMMENT ON TABLE installment_payments IS 'Individual installment payment records';
COMMENT ON TABLE case_flags IS 'Case flags and events (nonresponsive, escalation, etc.)';
COMMENT ON TABLE case_section_status IS 'Tracks completion status of form sections per case';

