-- Migration: Production Performance Indexes
-- Adds indexes for improved query performance on frequently accessed columns

-- Users table indexes
CREATE INDEX IF NOT EXISTS idx_users_audit_id ON users(audit_id);
CREATE INDEX IF NOT EXISTS idx_users_role ON users(role);
CREATE INDEX IF NOT EXISTS idx_users_group_id ON users(group_id) WHERE group_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_users_is_active ON users(is_active);
CREATE INDEX IF NOT EXISTS idx_users_last_login_at ON users(last_login_at) WHERE last_login_at IS NOT NULL;

-- Groups table indexes
CREATE INDEX IF NOT EXISTS idx_groups_code ON groups(code);
CREATE INDEX IF NOT EXISTS idx_groups_is_active ON groups(is_active);

-- Group Members indexes
CREATE INDEX IF NOT EXISTS idx_group_members_group_id ON group_members(group_id);
CREATE INDEX IF NOT EXISTS idx_group_members_user_id ON group_members(user_id);
CREATE INDEX IF NOT EXISTS idx_group_members_is_active ON group_members(is_active) WHERE is_active = true;
CREATE UNIQUE INDEX IF NOT EXISTS idx_group_members_unique ON group_members(group_id, user_id) WHERE is_active = true;

-- Group Targets indexes
CREATE INDEX IF NOT EXISTS idx_group_targets_group_id ON group_targets(group_id);
CREATE INDEX IF NOT EXISTS idx_group_targets_year ON group_targets(year_shamsi);

-- Entities table indexes
CREATE INDEX IF NOT EXISTS idx_entities_tin ON entities(tin);
CREATE INDEX IF NOT EXISTS idx_entities_referral_group ON entities(referral_group) WHERE referral_group IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_entities_status ON entities(status);
CREATE INDEX IF NOT EXISTS idx_entities_created_at ON entities(created_at);

-- Cases table indexes
CREATE INDEX IF NOT EXISTS idx_cases_case_id ON cases(case_id);
CREATE INDEX IF NOT EXISTS idx_cases_case_number ON cases(case_number) WHERE case_number IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_cases_entity_id ON cases(entity_id);
CREATE INDEX IF NOT EXISTS idx_cases_assigned_to ON cases(assigned_to) WHERE assigned_to IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_cases_group_referrer ON cases(group_referrer);
CREATE INDEX IF NOT EXISTS idx_cases_status ON cases(status);
CREATE INDEX IF NOT EXISTS idx_cases_completed_by ON cases(completed_by) WHERE completed_by IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_cases_created_at ON cases(created_at);

-- Tickets table indexes
CREATE INDEX IF NOT EXISTS idx_tickets_ticket_id ON tickets(ticket_id);
CREATE INDEX IF NOT EXISTS idx_tickets_case_id ON tickets(case_id) WHERE case_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_tickets_requested_by ON tickets(requested_by);
CREATE INDEX IF NOT EXISTS idx_tickets_group_id ON tickets(group_id) WHERE group_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_tickets_status ON tickets(status);
CREATE INDEX IF NOT EXISTS idx_tickets_type ON tickets(type);
CREATE INDEX IF NOT EXISTS idx_tickets_created_at ON tickets(created_at);

-- Documents table indexes
CREATE INDEX IF NOT EXISTS idx_documents_case_id ON documents(case_id);
CREATE INDEX IF NOT EXISTS idx_documents_uploader_id ON documents(uploader_id);
CREATE INDEX IF NOT EXISTS idx_documents_doc_type ON documents(doc_type);
CREATE INDEX IF NOT EXISTS idx_documents_is_final ON documents(is_final) WHERE is_final = true;
CREATE INDEX IF NOT EXISTS idx_documents_is_revoked ON documents(is_revoked) WHERE is_revoked = false;
CREATE INDEX IF NOT EXISTS idx_documents_uploaded_at ON documents(uploaded_at);

-- Notifications table indexes
CREATE INDEX IF NOT EXISTS idx_notifications_user_id ON notifications(user_id);
CREATE INDEX IF NOT EXISTS idx_notifications_is_read ON notifications(is_read) WHERE is_read = false;
CREATE INDEX IF NOT EXISTS idx_notifications_type ON notifications(type);
CREATE INDEX IF NOT EXISTS idx_notifications_created_at ON notifications(created_at);
CREATE INDEX IF NOT EXISTS idx_notifications_user_unread ON notifications(user_id, is_read) WHERE is_read = false;

-- Audit Logs table indexes
CREATE INDEX IF NOT EXISTS idx_audit_logs_user_id ON audit_logs(user_id) WHERE user_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_audit_logs_action ON audit_logs(action);
CREATE INDEX IF NOT EXISTS idx_audit_logs_entity_type ON audit_logs(entity_type) WHERE entity_type IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_audit_logs_entity_id ON audit_logs(entity_id) WHERE entity_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_audit_logs_created_at ON audit_logs(created_at);
CREATE INDEX IF NOT EXISTS idx_audit_logs_ip_address ON audit_logs(ip_address) WHERE ip_address IS NOT NULL;
-- Composite index for common query patterns
CREATE INDEX IF NOT EXISTS idx_audit_logs_entity_lookup ON audit_logs(entity_type, entity_id) WHERE entity_type IS NOT NULL AND entity_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_audit_logs_user_action ON audit_logs(user_id, action) WHERE user_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_audit_logs_date_range ON audit_logs(created_at DESC);

-- System Settings indexes
CREATE INDEX IF NOT EXISTS idx_system_settings_key ON system_settings(key);
CREATE INDEX IF NOT EXISTS idx_system_settings_category ON system_settings(category);

-- Session table indexes (for express-session with connect-pg-simple)
-- Note: connect-pg-simple creates its own indexes, but we can add additional ones if needed
-- Only create index if session table exists (it's created by connect-pg-simple at runtime)
DO $$
BEGIN
  IF EXISTS (SELECT FROM information_schema.tables WHERE table_name = 'session') THEN
    CREATE INDEX IF NOT EXISTS idx_session_expire ON session(expire) WHERE expire IS NOT NULL;
  END IF;
END $$;

-- Role-Permission indexes
CREATE INDEX IF NOT EXISTS idx_role_permissions_role_id ON role_permissions(role_id);
CREATE INDEX IF NOT EXISTS idx_role_permissions_permission_id ON role_permissions(permission_id);
CREATE INDEX IF NOT EXISTS idx_role_permissions_allow ON role_permissions(allow) WHERE allow = true;

-- Package-Permission indexes
CREATE INDEX IF NOT EXISTS idx_package_permissions_package_id ON package_permissions(package_id);
CREATE INDEX IF NOT EXISTS idx_package_permissions_permission_id ON package_permissions(permission_id);
CREATE INDEX IF NOT EXISTS idx_package_permissions_allow ON package_permissions(allow) WHERE allow = true;

-- User-Role indexes
CREATE INDEX IF NOT EXISTS idx_user_roles_user_id ON user_roles(user_id);
CREATE INDEX IF NOT EXISTS idx_user_roles_role_id ON user_roles(role_id);

-- User-Package indexes
CREATE INDEX IF NOT EXISTS idx_user_packages_user_id ON user_packages(user_id);
CREATE INDEX IF NOT EXISTS idx_user_packages_package_id ON user_packages(package_id);
CREATE INDEX IF NOT EXISTS idx_user_packages_expires_at ON user_packages(expires_at) WHERE expires_at IS NOT NULL;
-- Note: Cannot use NOW() in index predicate (not IMMUTABLE)
-- Use expires_at IS NULL for active packages instead
CREATE INDEX IF NOT EXISTS idx_user_packages_active ON user_packages(user_id, expires_at) WHERE expires_at IS NULL;

-- Analyze tables after index creation for query planner optimization
ANALYZE users;
ANALYZE groups;
ANALYZE group_members;
ANALYZE group_targets;
ANALYZE entities;
ANALYZE cases;
ANALYZE tickets;
ANALYZE documents;
ANALYZE notifications;
ANALYZE audit_logs;
ANALYZE system_settings;
ANALYZE role_permissions;
ANALYZE package_permissions;
ANALYZE user_roles;
ANALYZE user_packages;

