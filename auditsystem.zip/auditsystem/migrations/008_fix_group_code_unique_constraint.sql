-- Migration: Fix group code unique constraint to allow reuse after soft delete
-- Creates a partial unique index that only applies to active groups

-- Step 1: Drop the constraint first (this will automatically drop the associated index)
-- PostgreSQL creates both a constraint and an index for unique constraints
ALTER TABLE groups DROP CONSTRAINT IF EXISTS groups_code_unique;
ALTER TABLE groups DROP CONSTRAINT IF EXISTS groups_code_key;

-- Step 2: Drop the index if it exists independently (in case it wasn't dropped with the constraint)
DROP INDEX IF EXISTS groups_code_unique;

-- Step 3: Create a partial unique index that only applies to active groups
-- This allows soft-deleted groups (isActive = false) to have duplicate codes
CREATE UNIQUE INDEX groups_code_active_unique ON groups(code) WHERE is_active = true;

-- Add comment
COMMENT ON INDEX groups_code_active_unique IS 'Ensures unique group codes only for active groups, allowing reuse after soft delete';

