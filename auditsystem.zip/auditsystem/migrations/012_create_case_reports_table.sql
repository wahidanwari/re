-- Migration: Create case_reports table
-- Stores comprehensive reporting data for case completion
-- Includes Section 1: Entity Details and Section 2: Extractions

DO $$
BEGIN
  IF NOT EXISTS (SELECT FROM information_schema.tables WHERE table_name = 'case_reports') THEN
    CREATE TABLE case_reports (
      id VARCHAR PRIMARY KEY DEFAULT gen_random_uuid(),
      case_id VARCHAR NOT NULL UNIQUE REFERENCES cases(id) ON DELETE CASCADE,
      
      -- Section 1: مشخصات نهاد (Entity Details)
      -- Most fields auto-populate from case/entity, but some need manual entry:
      final_document_date TEXT, -- تاریخ صادره مکتوب نهایی
      capital_period TEXT, -- دوران سرمایه
      
      -- Section 2: بیرون‌نویسی‌ها (Extractions)
      salary_tax TEXT, -- مالیه موضوعی معاشات
      rent_tax TEXT, -- مالیه موضوعی بر کرایه
      contract_tax TEXT, -- مالیه موضوعی قراردادی
      profit_transaction_tax TEXT, -- مالیات معاملات انتفاعی
      income_tax TEXT, -- مالیات بر عایدات
      reduced_loss TEXT, -- ضرر کاهش یافته
      reduced_remaining_amount TEXT, -- مبلغ فاضل تحویل کاهش یافته
      confirmed_amount TEXT, -- مبلغ تثبیت شده
      collected_current_month TEXT, -- مبلغ تحصیل شده طی برج جاری
      remaining_collectible TEXT, -- الباقی مبلغ قابل تحصیل
      activity_status TEXT, -- وضعیت فعالیت
      attachment_number TEXT, -- نمبر آویز
      attachment_date TEXT, -- تاریخ آویز
      
      created_at TIMESTAMP DEFAULT NOW(),
      updated_at TIMESTAMP DEFAULT NOW()
    );

    -- Create index on case_id for faster lookups
    CREATE INDEX IF NOT EXISTS idx_case_reports_case_id ON case_reports(case_id);
    
    -- Create index on updated_at for reporting queries
    CREATE INDEX IF NOT EXISTS idx_case_reports_updated_at ON case_reports(updated_at);
  ELSE
    -- Table exists, ensure all columns exist
    -- Add any missing columns (for incremental updates)
    
    -- Section 1 fields
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'case_reports' AND column_name = 'final_document_date') THEN
      ALTER TABLE case_reports ADD COLUMN final_document_date TEXT;
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'case_reports' AND column_name = 'capital_period') THEN
      ALTER TABLE case_reports ADD COLUMN capital_period TEXT;
    END IF;
    
    -- Section 2 fields
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'case_reports' AND column_name = 'salary_tax') THEN
      ALTER TABLE case_reports ADD COLUMN salary_tax TEXT;
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'case_reports' AND column_name = 'rent_tax') THEN
      ALTER TABLE case_reports ADD COLUMN rent_tax TEXT;
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'case_reports' AND column_name = 'contract_tax') THEN
      ALTER TABLE case_reports ADD COLUMN contract_tax TEXT;
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'case_reports' AND column_name = 'profit_transaction_tax') THEN
      ALTER TABLE case_reports ADD COLUMN profit_transaction_tax TEXT;
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'case_reports' AND column_name = 'income_tax') THEN
      ALTER TABLE case_reports ADD COLUMN income_tax TEXT;
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'case_reports' AND column_name = 'reduced_loss') THEN
      ALTER TABLE case_reports ADD COLUMN reduced_loss TEXT;
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'case_reports' AND column_name = 'reduced_remaining_amount') THEN
      ALTER TABLE case_reports ADD COLUMN reduced_remaining_amount TEXT;
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'case_reports' AND column_name = 'confirmed_amount') THEN
      ALTER TABLE case_reports ADD COLUMN confirmed_amount TEXT;
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'case_reports' AND column_name = 'collected_current_month') THEN
      ALTER TABLE case_reports ADD COLUMN collected_current_month TEXT;
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'case_reports' AND column_name = 'remaining_collectible') THEN
      ALTER TABLE case_reports ADD COLUMN remaining_collectible TEXT;
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'case_reports' AND column_name = 'activity_status') THEN
      ALTER TABLE case_reports ADD COLUMN activity_status TEXT;
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'case_reports' AND column_name = 'attachment_number') THEN
      ALTER TABLE case_reports ADD COLUMN attachment_number TEXT;
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'case_reports' AND column_name = 'attachment_date') THEN
      ALTER TABLE case_reports ADD COLUMN attachment_date TEXT;
    END IF;
    
    -- Ensure indexes exist
    CREATE INDEX IF NOT EXISTS idx_case_reports_case_id ON case_reports(case_id);
    CREATE INDEX IF NOT EXISTS idx_case_reports_updated_at ON case_reports(updated_at);
  END IF;
END $$;

