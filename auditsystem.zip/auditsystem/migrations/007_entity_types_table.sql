-- Migration: Entity Types Management System
-- Creates entity_types table for dynamic entity type management

CREATE TABLE IF NOT EXISTS entity_types (
  id VARCHAR(255) PRIMARY KEY DEFAULT gen_random_uuid()::text,
  name VARCHAR(128) NOT NULL UNIQUE,
  status VARCHAR(20) NOT NULL DEFAULT 'active',
  created_at TIMESTAMP DEFAULT now(),
  updated_at TIMESTAMP DEFAULT now()
);

-- Create index for active types
CREATE INDEX IF NOT EXISTS idx_entity_types_status ON entity_types(status) WHERE status = 'active';

-- Migrate existing hardcoded types to the table
-- Use a DO block to handle the insert safely
DO $$
BEGIN
  -- Ensure unique constraint exists on name
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint 
    WHERE conrelid = 'entity_types'::regclass 
    AND conname LIKE '%name%' 
    AND contype = 'u'
  ) THEN
    -- Create unique constraint if it doesn't exist
    ALTER TABLE entity_types ADD CONSTRAINT entity_types_name_unique UNIQUE (name);
  END IF;
  
  -- Insert values, ignoring conflicts
  INSERT INTO entity_types (name, status) 
  SELECT 'لوژستیکی', 'active'
  WHERE NOT EXISTS (SELECT 1 FROM entity_types WHERE name = 'لوژستیکی');
  
  INSERT INTO entity_types (name, status) 
  SELECT 'صحی', 'active'
  WHERE NOT EXISTS (SELECT 1 FROM entity_types WHERE name = 'صحی');
  
  INSERT INTO entity_types (name, status) 
  SELECT 'تجارتی', 'active'
  WHERE NOT EXISTS (SELECT 1 FROM entity_types WHERE name = 'تجارتی');
  
  INSERT INTO entity_types (name, status) 
  SELECT 'صنعتی', 'active'
  WHERE NOT EXISTS (SELECT 1 FROM entity_types WHERE name = 'صنعتی');
  
  INSERT INTO entity_types (name, status) 
  SELECT 'تحصیلی', 'active'
  WHERE NOT EXISTS (SELECT 1 FROM entity_types WHERE name = 'تحصیلی');
END $$;

-- Add comment
COMMENT ON TABLE entity_types IS 'Dynamic entity types managed from system settings';

