-- Migration: Linked Audit Record Architecture
-- Refactors entity-audit workflow to separate permanent entity identity from audit instances
-- 
-- Changes:
-- 1. Remove audit-related fields from entities table (referralGroup, referredDate, yearsUnderReview, etc.)
-- 2. Add audit-specific fields to audit_records (audit_years, referring_group, referral_date, assigned_group)
-- 3. Migrate existing audit data from entities to audit_records
-- 4. Update constraints and indexes

-- Step 1: Add new fields to audit_records table
DO $$
BEGIN
  -- Add audit_years field (text) if it doesn't exist
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                 WHERE table_name = 'audit_records' AND column_name = 'audit_years') THEN
    ALTER TABLE audit_records ADD COLUMN audit_years TEXT;
  END IF;
  
  -- Add referring_group field if it doesn't exist
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                 WHERE table_name = 'audit_records' AND column_name = 'referring_group') THEN
    ALTER TABLE audit_records ADD COLUMN referring_group VARCHAR(255);
  END IF;
  
  -- Add referral_date field if it doesn't exist
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                 WHERE table_name = 'audit_records' AND column_name = 'referral_date') THEN
    ALTER TABLE audit_records ADD COLUMN referral_date TIMESTAMP;
  END IF;
  
  -- Add assigned_group field (rename from audit_group_id if needed, or add as new)
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                 WHERE table_name = 'audit_records' AND column_name = 'assigned_group') THEN
    -- If audit_group_id exists, we'll keep both for now (assigned_group is the new name)
    ALTER TABLE audit_records ADD COLUMN assigned_group VARCHAR(255) REFERENCES groups(id) ON DELETE SET NULL;
  END IF;
  
  -- Make audit_years NOT NULL after migration
  -- (We'll do this after migrating data)
END $$;

-- Step 2: Migrate audit data from entities to audit_records
-- For each entity with audit-related data, create an audit_record
DO $$
DECLARE
  entity_rec RECORD;
  year_from_val INTEGER;
  year_to_val INTEGER;
  audit_years_val TEXT;
  new_audit_record_id VARCHAR(255);
BEGIN
  -- Loop through entities that have audit-related data
  FOR entity_rec IN 
    SELECT 
      id,
      referral_group,
      referred_date,
      years_under_review,
      created_date,
      responsible_evaluator
    FROM entities
    WHERE (referral_group IS NOT NULL OR referred_date IS NOT NULL OR years_under_review IS NOT NULL)
  LOOP
    -- Parse years_under_review to extract year range
    -- Support formats: "1400", "1400-1402", "1392–1400" (with en-dash or hyphen)
    audit_years_val := entity_rec.years_under_review;
    
    -- Try to parse year range
    IF audit_years_val IS NOT NULL AND audit_years_val != '' THEN
      -- Check if it's a range (contains dash or en-dash)
      IF audit_years_val ~ '[-–]' THEN
        -- Extract year_from and year_to from range
        year_from_val := CAST(SPLIT_PART(REPLACE(audit_years_val, '–', '-'), '-', 1) AS INTEGER);
        year_to_val := CAST(SPLIT_PART(REPLACE(audit_years_val, '–', '-'), '-', 2) AS INTEGER);
      ELSE
        -- Single year
        year_from_val := CAST(audit_years_val AS INTEGER);
        year_to_val := year_from_val;
      END IF;
    ELSE
      -- Default to current year if no years specified
      -- Use a reasonable default (e.g., 1400) or skip this entity
      CONTINUE;
    END IF;
    
    -- Check if audit record already exists for this entity and year range
    IF NOT EXISTS (
      SELECT 1 FROM audit_records 
      WHERE entity_id = entity_rec.id 
      AND year_from = year_from_val 
      AND year_to = year_to_val
    ) THEN
      -- Create new audit record
      INSERT INTO audit_records (
        entity_id,
        audit_years,
        referring_group,
        referral_date,
        year_from,
        year_to,
        assigned_group,
        status,
        responsible_evaluator,
        created_at,
        updated_at
      ) VALUES (
        entity_rec.id,
        audit_years_val,
        entity_rec.referral_group,
        COALESCE(entity_rec.referred_date, entity_rec.created_date),
        year_from_val,
        year_to_val,
        NULL, -- assigned_group will be set later
        'in-progress',
        entity_rec.responsible_evaluator,
        COALESCE(entity_rec.created_date, NOW()),
        NOW()
      );
    END IF;
  END LOOP;
END $$;

-- Step 3: Update existing audit_records to populate new fields from year_from/year_to
UPDATE audit_records
SET audit_years = CASE 
  WHEN year_from = year_to THEN year_from::TEXT
  ELSE year_from::TEXT || '–' || year_to::TEXT
END
WHERE audit_years IS NULL AND year_from IS NOT NULL AND year_to IS NOT NULL;

-- Step 4: Copy audit_group_id to assigned_group for existing records
UPDATE audit_records
SET assigned_group = audit_group_id
WHERE assigned_group IS NULL AND audit_group_id IS NOT NULL;

-- Step 5: Make audit_years NOT NULL (after migration)
ALTER TABLE audit_records ALTER COLUMN audit_years SET NOT NULL;

-- Step 6: Remove audit-related fields from entities table
-- Keep only permanent identity fields: companyName, tin, businessNature
-- Also keep: registeredAddress, contactPerson, phone, notes (for entity details)
DO $$
BEGIN
  -- Remove referral_group
  IF EXISTS (SELECT 1 FROM information_schema.columns 
             WHERE table_name = 'entities' AND column_name = 'referral_group') THEN
    ALTER TABLE entities DROP COLUMN referral_group;
  END IF;
  
  -- Remove created_date (audit-related)
  IF EXISTS (SELECT 1 FROM information_schema.columns 
             WHERE table_name = 'entities' AND column_name = 'created_date') THEN
    ALTER TABLE entities DROP COLUMN created_date;
  END IF;
  
  -- Remove years_under_review
  IF EXISTS (SELECT 1 FROM information_schema.columns 
             WHERE table_name = 'entities' AND column_name = 'years_under_review') THEN
    ALTER TABLE entities DROP COLUMN years_under_review;
  END IF;
  
  -- Remove periods_under_review (audit-related)
  IF EXISTS (SELECT 1 FROM information_schema.columns 
             WHERE table_name = 'entities' AND column_name = 'periods_under_review') THEN
    ALTER TABLE entities DROP COLUMN periods_under_review;
  END IF;
  
  -- Remove referred_date_shamsi
  IF EXISTS (SELECT 1 FROM information_schema.columns 
             WHERE table_name = 'entities' AND column_name = 'referred_date_shamsi') THEN
    ALTER TABLE entities DROP COLUMN referred_date_shamsi;
  END IF;
  
  -- Remove referred_date
  IF EXISTS (SELECT 1 FROM information_schema.columns 
             WHERE table_name = 'entities' AND column_name = 'referred_date') THEN
    ALTER TABLE entities DROP COLUMN referred_date;
  END IF;
  
  -- Remove status (audit-related, not part of permanent identity)
  IF EXISTS (SELECT 1 FROM information_schema.columns 
             WHERE table_name = 'entities' AND column_name = 'status') THEN
    ALTER TABLE entities DROP COLUMN status;
  END IF;
  
  -- Remove responsible_evaluator (audit-related, belongs in audit_records)
  IF EXISTS (SELECT 1 FROM information_schema.columns 
             WHERE table_name = 'entities' AND column_name = 'responsible_evaluator') THEN
    ALTER TABLE entities DROP COLUMN responsible_evaluator;
  END IF;
END $$;

-- Step 7: Add unique constraint for (entity_id, audit_years) to prevent duplicates
-- Note: This is approximate - exact uniqueness would require parsing audit_years
-- We'll rely on application-level validation for exact year overlap detection
CREATE UNIQUE INDEX IF NOT EXISTS idx_audit_records_entity_audit_years 
ON audit_records(entity_id, audit_years) 
WHERE audit_years IS NOT NULL;

-- Step 8: Update indexes
CREATE INDEX IF NOT EXISTS idx_audit_records_referring_group ON audit_records(referring_group);
CREATE INDEX IF NOT EXISTS idx_audit_records_assigned_group ON audit_records(assigned_group);
CREATE INDEX IF NOT EXISTS idx_audit_records_referral_date ON audit_records(referral_date);

-- Step 9: Add comments
COMMENT ON COLUMN audit_records.audit_years IS 'سال‌های بررسی - Supports single year or ranges (e.g., "1392–1400")';
COMMENT ON COLUMN audit_records.referring_group IS 'گروه ارجاع‌دهنده';
COMMENT ON COLUMN audit_records.referral_date IS 'تاریخ ارجاع به بررسی';
COMMENT ON COLUMN audit_records.assigned_group IS 'گروه اختصاص داده شده (the group performing the audit)';

-- Step 10: Update status default to 'in-progress' (matching new schema)
ALTER TABLE audit_records ALTER COLUMN status SET DEFAULT 'in-progress';

COMMENT ON TABLE entities IS 'Permanent entity identity - only contains: نام نهاد, نمبر تشخیصیه, ماهیت تشبث';
COMMENT ON TABLE audit_records IS 'Linked audit instances - one entity can have multiple audit records across different years';

