-- Migration: Fix auditId unique constraint to allow reuse after deletion
-- This allows deleted users' auditIds to be reused by new users
-- Only active users must have unique auditIds

-- Drop existing unique constraint/index if it exists
DROP INDEX IF EXISTS users_audit_id_unique;
ALTER TABLE users DROP CONSTRAINT IF EXISTS users_audit_id_unique;

-- Create partial unique index for active users only
-- This allows deleted (inactive) users' auditIds to be reused
CREATE UNIQUE INDEX users_audit_id_active_unique 
ON users(audit_id) 
WHERE is_active = true;

-- Add comment explaining the constraint
COMMENT ON INDEX users_audit_id_active_unique IS 
'Ensures audit_id is unique only for active users. Deleted users (is_active=false) do not block reuse of their audit_id.';

