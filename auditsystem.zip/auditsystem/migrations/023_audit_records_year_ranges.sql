-- Migration: Update audit_records to support year ranges
-- Replaces single audit_year with year_from and year_to for multi-year audit support
-- Adds overlap detection constraint and new fields per requirements

-- Step 1: Create new audit_records table with year ranges
CREATE TABLE IF NOT EXISTS audit_records_new (
  id VARCHAR(255) PRIMARY KEY DEFAULT gen_random_uuid()::text,
  entity_id VARCHAR(255) NOT NULL REFERENCES entities(id) ON DELETE CASCADE,
  year_from INTEGER NOT NULL, -- Start year in Shamsi calendar (e.g., 1400)
  year_to INTEGER NOT NULL, -- End year in Shamsi calendar (e.g., 1402)
  audit_group_id VARCHAR(255) REFERENCES groups(id) ON DELETE SET NULL,
  assigned_at TIMESTAMP,
  created_by_user_id VARCHAR(255) REFERENCES users(id) ON DELETE SET NULL,
  status TEXT NOT NULL DEFAULT 'planned', -- 'planned', 'in_progress', 'completed', 'closed', 'transferred'
  notes TEXT,
  responsible_evaluator VARCHAR(255) REFERENCES users(id) ON DELETE SET NULL,
  created_at TIMESTAMP DEFAULT now(),
  updated_at TIMESTAMP DEFAULT now(),
  completed_at TIMESTAMP,
  
  -- Constraint: year_from <= year_to
  CONSTRAINT audit_records_year_range_check CHECK (year_from <= year_to)
);

-- Step 2: Migrate existing data from old audit_records table
-- If audit_records table exists, migrate data
DO $$
DECLARE
  rec RECORD;
BEGIN
  -- Check if old audit_records table exists
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'audit_records') THEN
    -- Migrate existing records
    FOR rec IN 
      SELECT * FROM audit_records
    LOOP
      INSERT INTO audit_records_new (
        id,
        entity_id,
        year_from,
        year_to,
        audit_group_id,
        assigned_at,
        created_by_user_id,
        status,
        notes,
        responsible_evaluator,
        created_at,
        updated_at,
        completed_at
      ) VALUES (
        rec.id,
        rec.entity_id,
        rec.audit_year, -- Use audit_year as both from and to for single-year audits
        rec.audit_year,
        rec.audit_group, -- Map audit_group to audit_group_id
        rec.started_at, -- Map started_at to assigned_at
        rec.created_by,
        CASE 
          WHEN rec.status = 'in-progress' THEN 'in_progress'
          WHEN rec.status = 'completed' THEN 'completed'
          WHEN rec.status = 'cancelled' THEN 'closed'
          WHEN rec.status = 'on-hold' THEN 'planned'
          ELSE 'planned'
        END,
        rec.notes,
        rec.assigned_auditor, -- Map assigned_auditor to responsible_evaluator
        rec.created_at,
        rec.updated_at,
        rec.completed_at
      )
      ON CONFLICT (id) DO NOTHING;
    END LOOP;
  END IF;
END $$;

-- Step 3: Drop old audit_records table and rename new one
DROP TABLE IF EXISTS audit_records CASCADE;
ALTER TABLE audit_records_new RENAME TO audit_records;

-- Step 4: Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_audit_records_entity_id ON audit_records(entity_id);
CREATE INDEX IF NOT EXISTS idx_audit_records_audit_group_id ON audit_records(audit_group_id);
CREATE INDEX IF NOT EXISTS idx_audit_records_status ON audit_records(status);
CREATE INDEX IF NOT EXISTS idx_audit_records_year_range ON audit_records(entity_id, year_from, year_to);
CREATE INDEX IF NOT EXISTS idx_audit_records_created_at ON audit_records(created_at);
CREATE INDEX IF NOT EXISTS idx_audit_records_responsible_evaluator ON audit_records(responsible_evaluator);

-- Step 5: Create function to check for overlapping year ranges
CREATE OR REPLACE FUNCTION check_audit_record_overlap(
  p_entity_id VARCHAR(255),
  p_year_from INTEGER,
  p_year_to INTEGER,
  p_exclude_id VARCHAR(255) DEFAULT NULL
) RETURNS TABLE(
  id VARCHAR(255),
  year_from INTEGER,
  year_to INTEGER,
  status TEXT
) AS $$
BEGIN
  RETURN QUERY
  SELECT 
    ar.id,
    ar.year_from,
    ar.year_to,
    ar.status
  FROM audit_records ar
  WHERE ar.entity_id = p_entity_id
    AND (p_exclude_id IS NULL OR ar.id != p_exclude_id)
    AND NOT (ar.year_to < p_year_from OR ar.year_from > p_year_to);
END;
$$ LANGUAGE plpgsql;

-- Step 6: Create trigger function to prevent overlapping ranges
CREATE OR REPLACE FUNCTION prevent_audit_record_overlap()
RETURNS TRIGGER AS $$
DECLARE
  overlapping_count INTEGER;
BEGIN
  -- Check for overlapping ranges
  SELECT COUNT(*) INTO overlapping_count
  FROM audit_records
  WHERE entity_id = NEW.entity_id
    AND id != COALESCE(NEW.id, '')
    AND NOT (year_to < NEW.year_from OR year_from > NEW.year_to);
  
  IF overlapping_count > 0 THEN
    RAISE EXCEPTION 'Overlapping year range detected for entity %. Existing ranges conflict with %-%', 
      NEW.entity_id, NEW.year_from, NEW.year_to;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Step 7: Create trigger to enforce non-overlapping ranges
DROP TRIGGER IF EXISTS trigger_prevent_audit_record_overlap ON audit_records;
CREATE TRIGGER trigger_prevent_audit_record_overlap
  BEFORE INSERT OR UPDATE ON audit_records
  FOR EACH ROW
  EXECUTE FUNCTION prevent_audit_record_overlap();

-- Step 8: Update audit_record_history table to reference new structure
-- The history table should already exist, but we ensure it references the correct table
-- No changes needed to history table structure

-- Step 9: Add comments
COMMENT ON TABLE audit_records IS 'Audit records with year ranges - one entity can have multiple non-overlapping audit records';
COMMENT ON COLUMN audit_records.year_from IS 'Start year in Shamsi calendar (e.g., 1400)';
COMMENT ON COLUMN audit_records.year_to IS 'End year in Shamsi calendar (e.g., 1402)';
COMMENT ON COLUMN audit_records.status IS 'Status: planned, in_progress, completed, closed, transferred';
COMMENT ON FUNCTION check_audit_record_overlap IS 'Check for overlapping year ranges for an entity';

