# Phase 1: Current State Analysis - Authentication & RBAC

## 1. Login & Session Management

### 1.1 Login Flow
**Location:** `server/routes/auth.ts` (lines 15-157)

**Current Implementation:**
- Uses Passport.js with LocalStrategy (username: `auditId`, password: `password`)
- Login endpoint: `POST /api/auth/login`
- On successful login:
  - Updates `lastLoginAt` in database
  - Creates audit log entry
  - Calls `req.logIn(user)` to establish session
  - Returns user object with `effectivePermissions` (both array and object format)
  - Returns `permissionsVersion` (default: 1)

**Response Structure:**
```json
{
  "message": "ورود موفقیت آمیز",
  "user": {
    ...userData,
    "effectivePermissions": ["entities:view", "cases:view", ...], // Array format
  },
  "effectivePermissions": { "entities:view": true, ... }, // Object format
  "mustChangePassword": false,
  "passwordExpired": false
}
```

**Issues:**
- ✅ Effective permissions ARE returned on login
- ⚠️ Session user data may become stale if permissions change after login
- ⚠️ No automatic session refresh when permissions change

### 1.2 Session Store
**Location:** `server/config/session.ts`

**Current Implementation:**
- **Type:** PostgreSQL session store (`connect-pg-simple`)
- **Table:** `session` (auto-created if missing)
- **Configuration:**
  - `maxAge`: 10 hours (36000000ms) - configurable via `SESSION_MAX_AGE`
  - `httpOnly`: true (XSS protection)
  - `secure`: true in production
  - `sameSite`: 'lax'
  - `rolling`: false (explicit control, not auto-extending)
- **Inactivity Timeout:** 90 minutes (5400000ms) - configurable via `SESSION_INACTIVITY_TIMEOUT`
- **Sliding Expiration:** Enabled by default (updates `lastActivity` on each request)

**Known Issues:**
- ✅ Session store is properly configured
- ⚠️ Session invalidation strategy is incomplete - when permissions change, session is not automatically regenerated
- ⚠️ Session user data (`req.user`) is refreshed via middleware but session cookie itself is not invalidated

### 1.3 Session Refresh Mechanism
**Location:** `server/middleware/auth.ts` (lines 9-39)

**Current Implementation:**
- `refreshUserData()` middleware refreshes `req.user` from database on each request
- Skips refresh for `/api/auth/*` routes
- Updates `req.user` with fresh data from database

**Issues:**
- ✅ User data is refreshed on each request
- ⚠️ Session cookie itself is not regenerated when permissions change
- ⚠️ Frontend may cache stale permission data

## 2. Permission Packages & effectivePermissions

### 2.1 Permission Calculation
**Location:** `shared/permissions.ts` (primary) + `server/services/permissionService.ts` (server-side)

**Current Implementation:**
- **Base Roles:** `system_admin`, `director`, `senior_auditor`, `auditor`
- **Permission Packages:** `acting_coordinator`, `approval_authority`
- **Calculation Logic:**
  1. Start with base role permissions
  2. Merge/add package permissions (packages ADD permissions, don't remove)
  3. System admin gets all permissions immediately
  4. Database RBAC tables are checked as secondary source (if populated)

**Primary Source:** `shared/permissions.ts` - `getEffectivePermissions(role, packages)`
- This is the source of truth
- Used by both client and server

**Secondary Source:** Database RBAC tables (if populated)
- `roles`, `permissions`, `role_permissions`
- `packages`, `package_permissions`, `user_packages`
- Database permissions take precedence if they exist

**Issues:**
- ✅ Calculation logic is correct
- ⚠️ Dual source of truth (code + database) can cause confusion
- ⚠️ Database override logic may not be fully tested

### 2.2 effectivePermissions Resolver
**Location:** `server/services/permissionService.ts` (lines 44-194)

**Current Implementation:**
- Function: `getEffectivePermissions(userId: string): Promise<EffectivePermissions>`
- Returns: Object with all permissions as boolean values
- Used by:
  - `/api/auth/login` - returns on login
  - `/api/auth/me` - returns on user data fetch
  - `/api/auth/effective-permissions` - dedicated endpoint
  - `/api/users/:id/effective-permissions` - admin endpoint (requires `users:manage`)

**Issues:**
- ✅ Resolver exists and works
- ⚠️ No endpoint to recompute permissions for a specific user
- ⚠️ No endpoint to invalidate/regenerate session after permission changes

### 2.3 Permission Versioning
**Location:** `shared/schema.ts` (line 26), `server/routes/users.ts` (lines 137-139)

**Current Implementation:**
- `users.permissionsVersion` field (integer, default: 1)
- Incremented when:
  - User role changes
  - Permission packages change
  - Group ID changes
- Used by frontend to detect permission changes and invalidate cache

**Issues:**
- ✅ Versioning mechanism exists
- ⚠️ Frontend cache invalidation relies on version comparison but may not always work correctly
- ⚠️ Session invalidation not triggered when version changes

## 3. Permission Checks

### 3.1 Backend Permission Middleware
**Location:** `server/middleware/permissions.ts`

**Middleware Functions:**
- `requirePermission(permission)` - requires single permission
- `requireAnyPermission(permissions[])` - requires any of the permissions
- `requireAllPermissions(permissions[])` - requires all permissions
- `userHasPermission(user, permission)` - helper function
- `getUserEffectivePermissions(user)` - helper function

**Usage Locations:**
- `server/routes/users.ts` - user management routes
- `server/routes/cases.ts` - case management routes
- `server/routes/groups.ts` - group management routes
- `server/routes/tickets.ts` - ticket routes
- `server/routes/documents.ts` - document routes
- `server/routes/reports.ts` - report routes
- `server/routes/settings.ts` - settings routes
- `server/routes/audit-logs.ts` - audit log routes
- `server/routes/entity-types.ts` - entity type routes
- `server/routes/backup.ts` - backup routes

**Permission Check Flow:**
1. Check if user is authenticated
2. System admin bypasses all checks
3. Call `hasPermission(userId, permission)` from `permissionService`
4. `hasPermission` calls `getEffectivePermissions(userId)` and checks specific permission

**Issues:**
- ✅ Permission checks are properly implemented
- ⚠️ Each check calls `getEffectivePermissions` which queries database - could be optimized with caching
- ⚠️ No rate limiting on permission checks

### 3.2 Frontend Permission Checks
**Location:** `client/src/utils/permissions.ts`, `client/src/hooks/usePermissions.ts`

**Current Implementation:**
- `getUserPermissions(user, forceRefresh)` - fetches from `/api/auth/effective-permissions`
- `userHasPermission(user, permission)` - synchronous check using cache or fallback calculation
- `userHasPermissionAsync(user, permission)` - async check that fetches from API
- Cache mechanism with `permissionsVersion` comparison

**Cache Strategy:**
- Caches permissions per user ID
- Invalidates cache when `permissionsVersion` changes
- Can force refresh with `forceRefresh: true`

**Issues:**
- ✅ Frontend permission checks work
- ⚠️ Cache may become stale if `permissionsVersion` is not properly incremented
- ⚠️ Fallback calculation in `userHasPermission` may not match server calculation exactly

## 4. Reproducible Failure Scenarios

### 4.1 Scenario: Assign Coordination Package → User Sees Modules but APIs Return Empty

**Steps to Reproduce:**
1. User logs in as `auditor` (no packages)
2. Admin assigns `acting_coordinator` package to user
3. `permissionsVersion` is incremented
4. WebSocket notification is sent to user
5. Frontend receives notification and refreshes user data
6. User sees new modules in sidebar (e.g., "Entities", "Cases")
7. User clicks on module
8. API call returns empty array or 403 error

**Root Cause Analysis:**
- Frontend cache may not be properly invalidated
- Session may still have old user data in `req.user`
- Permission check in API middleware may use stale session data
- `refreshUserData` middleware may not be applied to all routes

**Evidence:**
- `server/middleware/auth.ts` - `refreshUserData` skips `/api/auth/*` routes
- `client/src/utils/permissions.ts` - cache invalidation relies on version comparison
- `server/routes/users.ts` - session refresh only happens if current user updates themselves

### 4.2 Scenario: Permission Changes Not Reflected Until Re-login

**Steps to Reproduce:**
1. User is logged in
2. Admin changes user's role or packages
3. `permissionsVersion` is incremented
4. WebSocket notification is sent
5. Frontend refreshes user data
6. Permissions still show old values until user logs out and back in

**Root Cause:**
- Session cookie is not regenerated
- `req.user` is refreshed but session store may cache old data
- Frontend cache may not be properly cleared

### 4.3 Scenario: API Returns 403 Even Though User Has Permission

**Steps to Reproduce:**
1. User has `acting_coordinator` package
2. User should have `cases:assign_to_group` permission
3. User tries to assign case to group
4. API returns 403 "عدم دسترسی - شما مجوز لازم را ندارید"

**Root Cause:**
- `getEffectivePermissions` may not be calculating correctly
- Database override may be interfering
- Package permissions may not be properly merged

## 5. API Endpoints

### 5.1 Current Endpoints

**Authentication:**
- `POST /api/auth/login` - Returns user + effectivePermissions
- `POST /api/auth/logout` - Logs out user
- `GET /api/auth/me` - Returns current user + effectivePermissions + permissionsVersion
- `GET /api/auth/effective-permissions` - Returns effectivePermissions object
- `POST /api/auth/change-password` - Changes password
- `POST /api/auth/forgot-password` - Creates password reset ticket

**User Management:**
- `GET /api/users/:id/effective-permissions` - Admin endpoint to get user's effective permissions + modules list
- `PUT /api/users/:id` - Updates user (increments permissionsVersion if permissions change)

**Missing Endpoints:**
- ❌ `POST /api/users/:id/recompute-permissions` - No endpoint to manually recompute permissions
- ❌ `POST /api/users/:id/invalidate-session` - No endpoint to invalidate user's session
- ❌ `POST /api/auth/refresh-session` - No endpoint to refresh current user's session

### 5.2 Example API Calls & Responses

#### Example 1: Login Response (Current)
```http
POST /api/auth/login
Content-Type: application/json

{
  "auditId": "AUDIT001",
  "password": "password123"
}
```

**Response:**
```json
{
  "message": "ورود موفقیت آمیز",
  "user": {
    "id": "user-123",
    "auditId": "AUDIT001",
    "role": "auditor",
    "permissionPackages": [],
    "effectivePermissions": ["cases:view", "cases:complete", "documents:upload", "tickets:submit"]
  },
  "effectivePermissions": {
    "entities:view": false,
    "cases:view": true,
    "cases:complete": true,
    "documents:upload": true,
    "tickets:submit": true,
    ...
  },
  "mustChangePassword": false,
  "passwordExpired": false
}
```

**Problem:** No `permissionsVersion` in response (should be included)

#### Example 2: Get Current User (Current)
```http
GET /api/auth/me
```

**Response:**
```json
{
  "user": {
    "id": "user-123",
    "auditId": "AUDIT001",
    "role": "auditor",
    "permissionPackages": [],
    "effectivePermissions": ["cases:view", "cases:complete", ...]
  },
  "effectivePermissions": {
    "cases:view": true,
    ...
  },
  "effectivePermissionsList": ["cases:view", ...],
  "permissionsVersion": 1
}
```

**Problem:** ✅ This endpoint works correctly

#### Example 3: Get Effective Permissions (Current)
```http
GET /api/auth/effective-permissions
```

**Response:**
```json
{
  "entities:view": false,
  "entities:create": false,
  "cases:view": true,
  "cases:assign_to_auditor": false,
  "cases:assign_to_group": false,
  "cases:complete": true,
  "reports:generate": false,
  "users:manage": false,
  "groups:manage": false,
  "groups:set_targets": false,
  "tickets:submit": true,
  "tickets:approve": false,
  "documents:download": false,
  "documents:upload": true,
  "logs:view": false,
  "settings:manage": false,
  "reports:override_complete": false
}
```

**Problem:** ✅ This endpoint works correctly

#### Example 4: Update User with Package Assignment (Current)
```http
PUT /api/users/user-123
Content-Type: application/json

{
  "permissionPackages": ["acting_coordinator"]
}
```

**Response:**
```json
{
  "id": "user-123",
  "auditId": "AUDIT001",
  "role": "auditor",
  "permissionPackages": ["acting_coordinator"],
  "effectivePermissions": ["entities:view", "cases:view", "cases:assign_to_group", ...],
  "effectivePermissionsObject": {
    "entities:view": true,
    "cases:view": true,
    "cases:assign_to_group": true,
    ...
  },
  "modules": ["entities", "cases", "documents", "reports"],
  "permissionsChanged": true,
  "message": "User updated successfully. Permissions have been refreshed."
}
```

**Problem:** 
- ✅ Response includes effectivePermissions and modules
- ⚠️ Session is only refreshed if current user updates themselves
- ⚠️ No session invalidation for other users

## 6. Frontend Contract for Modules List

### 6.1 Current Implementation
**Location:** `server/routes/users.ts` (lines 52-67), `client/src/components/AppSidebar.tsx`

**Module Mapping:**
- `entities:view` → `entities`
- `cases:view` → `cases`
- `users:manage` → `users`
- `groups:manage` → `groups`
- `groups:set_targets` → `target-settings`
- `tickets:submit` OR `tickets:approve` → `tickets`
- `cases:view` → `documents` (same permission as cases)
- `settings:manage` → `settings`
- `logs:view` → `audit-logs`

**Issues:**
- ✅ Module list is returned in `/api/users/:id/effective-permissions`
- ⚠️ Module list is NOT returned in `/api/auth/me` or `/api/auth/login`
- ⚠️ Frontend calculates modules client-side using permission checks
- ⚠️ Inconsistency between server-calculated modules and client-calculated modules

## 7. Session Invalidation/Regeneration Strategy

### 7.1 Current Strategy
**Location:** `server/routes/users.ts` (lines 254-282)

**Current Implementation:**
- When permissions change:
  - If current user updates themselves: Session is refreshed (lines 257-276)
  - If admin updates another user: WebSocket notification is sent (lines 244-252)
  - Session cookie is NOT regenerated
  - Session store entry is NOT invalidated

**Issues:**
- ⚠️ No proper session invalidation mechanism
- ⚠️ Session regeneration only works for self-updates
- ⚠️ No endpoint to manually invalidate sessions
- ⚠️ Session store (PostgreSQL) does not have a method to invalidate by user ID

## 8. Summary of Problems

### 8.1 Critical Issues
1. **Session Invalidation:** No proper mechanism to invalidate/regenerate sessions when permissions change
2. **Stale Session Data:** Session may contain old user data even after permissions change
3. **Missing Endpoints:** No endpoints to recompute permissions or invalidate sessions
4. **Module List Inconsistency:** Module list not returned in login/me endpoints, only in admin endpoint

### 8.2 Medium Priority Issues
1. **Cache Invalidation:** Frontend cache may not always invalidate correctly
2. **Permission Calculation:** Dual source of truth (code + database) may cause confusion
3. **Performance:** Each permission check queries database - could be optimized

### 8.3 Low Priority Issues
1. **Logging:** Permission checks are logged but may be too verbose
2. **Error Handling:** Some error cases may not be properly handled

## 9. Dependencies

### 9.1 Backend Dependencies
- `express-session` - Session management
- `connect-pg-simple` - PostgreSQL session store
- `passport` + `passport-local` - Authentication
- `drizzle-orm` - Database ORM
- PostgreSQL database

### 9.2 Frontend Dependencies
- `wouter` - Routing
- `@tanstack/react-query` - Data fetching/caching
- WebSocket client - Real-time notifications

### 9.3 Database Dependencies
- `users` table - User data, role, permissionPackages, permissionsVersion
- `session` table - Session store
- RBAC tables (optional): `roles`, `permissions`, `role_permissions`, `packages`, `package_permissions`, `user_packages`

## 10. Known Errors

### 10.1 Session Store Errors
- No known errors with PostgreSQL session store
- Session table is auto-created if missing

### 10.2 Permission Calculation Errors
- No known errors in calculation logic
- Potential issue: Database override may interfere with code-based calculation

### 10.3 Cache Errors
- Frontend cache may not invalidate when permissionsVersion changes
- Cache may become stale if version comparison fails

