# Case Lifecycle Redesign - Implementation Summary

**Date:** 2025-01-XX
**Status:** ✅ COMPLETE

## Overview

This document summarizes the complete implementation of the approved audit case lifecycle redesign, replacing 13 statuses with 6 new statuses and introducing boolean flags for special states.

---

## 1. NEW CASE STATUS ENUM

### Final 6 Statuses (shared/schema.ts)

| Status Key | Dari Value | Description |
|------------|-----------|-------------|
| `CREATED` | `'ایجاد شده'` | Case created, initial state |
| `PENDING_SENIOR_REVIEW` | `'در انتظار بررسی بازرس ارشد'` | Case assigned to group, waiting for senior auditor to assign to auditor |
| `UNDER_REVIEW` | `'در حال بررسی'` | Case is actively being reviewed by auditor |
| `PENDING_DOCUMENTS` | `'در انتظار تکمیل مدارک'` | Case waiting for documents from entity |
| `SUSPENDED` | `'تعلیق شده'` | Case is suspended |
| `COMPLETED` | `'تکمیل شده'` | Case work is finished, report complete |

### Removed Statuses

All other lifecycle statuses have been removed:
- ❌ `NEW`, `ASSIGNED`, `ASSIGNED_TO_AUDITOR`, `UNDER_AUDIT_REVIEW`, `IN_PROGRESS`
- ❌ `PENDING_APPROVAL`, `APPROVED`, `REJECTED`
- ❌ `NONRESPONSIVE`, `REFERRED_TO_ENFORCEMENT`, `INSTALLMENT`, `SENT_TO_LAW_ENFORCEMENT`

---

## 2. BOOLEAN FLAGS (NEW FIELDS)

### Added to Cases Table

Three new boolean fields replace old lifecycle statuses:

| Field | Database Column | Default | Purpose |
|-------|----------------|---------|---------|
| `isLawEnforcement` | `is_law_enforcement` | `false` | Case sent to law enforcement (replaces `'ارسال‌شده به تنفیذ قانون'` status) |
| `isTaxInstallment` | `is_tax_installment` | `false` | Case is in installment payment plan (replaces `'در اقساط'` status) |
| `isCancelled` | `is_cancelled` | `false` | Case is cancelled (replaces `'لغو شده'` status) |

### Key Behavior

- **Flags are independent of lifecycle status** - A case can be in any lifecycle state and have flags set
- **Flags do NOT change lifecycle status** - Setting `isLawEnforcement = true` does not change the case's status
- **Flags are used for filtering and reporting** - UI tabs filter by flags, not status

---

## 3. MIGRATION SCRIPT

### File: `migrations/036_case_lifecycle_redesign.sql`

**Migration Rules:**

| Old Status | New Status | Notes |
|------------|------------|-------|
| `در انتظار تصمیم کمیته` | `ایجاد شده` | |
| `در انتظار تخصیص به گروه` | `ایجاد شده` | |
| `جدید` | `ایجاد شده` | |
| `اختصاص داده شده` | `در انتظار بررسی بازرس ارشد` | |
| `منتظر بررسی بازرس ارشد` | `در انتظار بررسی بازرس ارشد` | |
| `اختصاص داده شده به بازرس` | `در انتظار بررسی بازرس ارشد` | |
| `شروع بررسی` / `فعال` / `در جریان بررسی` | `در حال بررسی` | |
| `در انتظار مدارک` | `در انتظار تکمیل مدارک` | |
| `متوقف` / `معلق` | `تعلیق شده` | |
| `بسته شده` / `پایان یافته` / `تکمیل شده` / `تایید شده` | `تکمیل شده` | |
| `رد شده` | `تکمیل شده` | |
| `منتظر تایید` | `تکمیل شده` | |
| `عدم پاسخگو` | `در حال بررسی` | |

**Flag Migration:**

- `'ارسال‌شده به تنفیذ قانون'` → `isLawEnforcement = true`
- `'در اقساط'` → `isTaxInstallment = true`
- `'لغو شده'` → `isCancelled = true`

**Database Constraint:**

Updated `cases_status_check` constraint to only allow the 6 new statuses.

---

## 4. STATE MACHINE TRANSITIONS

### File: `server/services/caseStateMachine.ts`

**New Transition Rules:**

| From Status | To Status | Transition Name | Permission | Notes |
|-------------|-----------|----------------|------------|-------|
| `CREATED` | `PENDING_SENIOR_REVIEW` | `assign_to_group` | `cases:assign_to_group` | Requires `groupId` |
| `PENDING_SENIOR_REVIEW` | `UNDER_REVIEW` | `assign_to_auditor` | `cases:assign_to_auditor` | **MUST transition** - Requires `userId`, sets assignment fields |
| `UNDER_REVIEW` | `PENDING_DOCUMENTS` | `wait_for_documents` | `cases:view` | |
| `UNDER_REVIEW` | `SUSPENDED` | `suspend` | `cases:view` | |
| `PENDING_DOCUMENTS` | `UNDER_REVIEW` | `resume_review` | `cases:view` | |
| `SUSPENDED` | `UNDER_REVIEW` | `resume_review` | `cases:view` | |
| `UNDER_REVIEW` | `COMPLETED` | `complete` | `cases:complete` | Requires report validation, locks report |
| `PENDING_DOCUMENTS` | `COMPLETED` | `complete` | `cases:complete` | Requires report validation, locks report |
| `SUSPENDED` | `COMPLETED` | `complete` | `cases:complete` | Requires report validation, locks report |
| `COMPLETED` | `UNDER_REVIEW` | `reopen` | `cases:complete` | |

**Removed Transitions:**

- ❌ All transitions involving old statuses (APPROVED, REJECTED, INSTALLMENT, SENT_TO_LAW_ENFORCEMENT, etc.)
- ❌ `submit_for_approval`, `approve`, `reject` transitions
- ❌ `to_installment`, `move_to_installment`, `to_law_enforcement`, `send_to_law_enforcement` transitions

---

## 5. ASSIGNMENT LOGIC

### File: `server/routes/cases.ts` (POST /api/cases/:id/assign)

**Group Assignment:**
- **Allowed from:** `CREATED` (`'ایجاد شده'`) status only
- **Transitions to:** `PENDING_SENIOR_REVIEW` (`'در انتظار بررسی بازرس ارشد'`)
- **Error if wrong status:** "قضیه باید در وضعیت 'ایجاد شده' باشد تا به گروه اختصاص داده شود"

**Auditor Assignment:**
- **Allowed from:** `PENDING_SENIOR_REVIEW` (`'در انتظار بررسی بازرس ارشد'`) status only
- **Transitions to:** `UNDER_REVIEW` (`'در حال بررسی'`) **AUTOMATICALLY**
- **Error if wrong status:** "قضیه باید در وضعیت 'در انتظار بررسی بازرس ارشد' باشد"
- **Self-assignment:** ✅ **EXPLICITLY ALLOWED** - Senior auditor can assign to themselves
- **No blocking checks** - Removed any checks that prevented senior self-assignment

**Key Changes:**
- Assignment to auditor **MUST** transition to `UNDER_REVIEW` (no separate "start audit" step)
- Status check is enforced at API level before state machine transition

---

## 6. COMPLETION LOGIC

### Direct Completion (No Senior Review)

**File:** `server/services/caseStateMachine.ts`

**Completion Transitions:**
- `UNDER_REVIEW` → `COMPLETED`
- `PENDING_DOCUMENTS` → `COMPLETED`
- `SUSPENDED` → `COMPLETED`

**Validation:**
- Report V2 must exist
- Report must pass validation (all required fields)
- Report status must be `'completed'`

**Actions on Completion:**
- Sets `completedBy = user.id`
- Sets `completedAt = new Date()`
- **Locks report** (sets report status to `'locked'`)
- No intermediate `PENDING_APPROVAL` state
- No separate approval step

---

## 7. UI UPDATES

### StatusBadge Component

**File:** `client/src/components/StatusBadge.tsx`

**Updated Status Configurations:**

| Status | Badge Variant | CSS Classes |
|--------|---------------|-------------|
| `'ایجاد شده'` | `default` | `bg-blue-500 hover:bg-blue-600 text-white` |
| `'در انتظار بررسی بازرس ارشد'` | `default` | `bg-blue-400 hover:bg-blue-500 text-white` |
| `'در حال بررسی'` | `secondary` | `bg-amber-500 hover:bg-amber-600 text-white` |
| `'در انتظار تکمیل مدارک'` | `default` | `bg-yellow-500 hover:bg-yellow-600 text-white` |
| `'تعلیق شده'` | `secondary` | `bg-gray-500 hover:bg-gray-600 text-white` |
| `'تکمیل شده'` | `default` | `bg-green-500 hover:bg-green-600 text-white` |

### Cases Page

**File:** `client/src/pages/Cases.tsx`

**Tab Filtering Updates:**

1. **"قضایای تازه اختصاص داده شده" tab:**
   - Filters: `CREATED`, `PENDING_SENIOR_REVIEW`, `UNDER_REVIEW`, `PENDING_DOCUMENTS`

2. **"قضایای تکمیل شده" tab:**
   - Filters: `COMPLETED` only

3. **"قضایای در اقساط" tab:**
   - **Uses flag:** `isTaxInstallment === true` (NOT status)

4. **"قضایای ارسال‌شده به تنفیذ قانون" tab:**
   - **Uses flag:** `isLawEnforcement === true` (NOT status)

**Button Visibility Updates:**

- **"شروع بررسی" button:** Removed (assignment now auto-transitions)
- **"تنظیم به عنوان قضیه قسط" button:** Updates `isTaxInstallment` flag (not status)
- **Installment Payments component:** Shows when `isTaxInstallment === true` (not status check)

---

## 8. BACKEND UPDATES

### Assignment Endpoint

**File:** `server/routes/cases.ts`

- Group assignment: Only from `CREATED` status
- Auditor assignment: Only from `PENDING_SENIOR_REVIEW` status
- **Self-assignment explicitly allowed** - No blocking checks

### Completion Endpoint

**File:** `server/routes/cases.ts` (POST /api/cases/:id/complete)

- Directly transitions to `COMPLETED`
- No intermediate approval state
- Locks report on completion

### Flag Updates

**File:** `server/routes/cases.ts`

- Installment payment creation: Sets `isTaxInstallment = true` (not status)
- Law enforcement escalation: Sets `isLawEnforcement = true` (not status)
- Non-responsive marking: No status change (tracked via flags/metrics)

### Deprecated Endpoints

- `POST /api/cases/:id/start-audit`: Returns error message (assignment now auto-transitions)
- `PATCH /api/cases/:id/status`: Updated transition mapping for new statuses

---

## 9. ERROR MESSAGES

All error messages updated to reflect new state model:

- "قضیه باید در وضعیت 'ایجاد شده' باشد تا به گروه اختصاص داده شود"
- "قضیه باید در وضعیت 'در انتظار بررسی بازرس ارشد' باشد"
- "نمی توان وضعیت قضیه تکمیل شده را تغییر داد" (replaces old "تایید شده یا رد شده" message)
- "نمی‌توان گزارش قضیه تکمیل شده را ویرایش کرد" (replaces old "تایید شده یا رد شده" message)

---

## 10. DATABASE CHANGES

### Migration: `036_case_lifecycle_redesign.sql`

1. **Adds flag columns:**
   ```sql
   ALTER TABLE cases 
     ADD COLUMN is_law_enforcement BOOLEAN DEFAULT false,
     ADD COLUMN is_tax_installment BOOLEAN DEFAULT false,
     ADD COLUMN is_cancelled BOOLEAN DEFAULT false;
   ```

2. **Sets flags from old statuses** (before status migration)

3. **Migrates statuses** using mapping rules

4. **Updates constraint:**
   ```sql
   ALTER TABLE cases
     ADD CONSTRAINT cases_status_check 
     CHECK (status IN (
       'ایجاد شده',
       'در انتظار بررسی بازرس ارشد',
       'در حال بررسی',
       'در انتظار تکمیل مدارک',
       'تعلیق شده',
       'تکمیل شده'
     ));
   ```

5. **Creates indexes** for flags

---

## 11. VERIFICATION CHECKLIST

After implementation, verify:

- ✅ Senior auditor can assign cases to himself (no 400/403 errors)
- ✅ Assignment automatically transitions to `UNDER_REVIEW`
- ✅ No cases blocked due to legacy status checks
- ✅ Reports remain accurate (no data loss)
- ✅ Flag-based filtering works in UI tabs
- ✅ Status badges display correctly
- ✅ Completion locks reports
- ✅ Migration script runs successfully

---

## 12. FILES MODIFIED

### Schema & Migration
- `shared/schema.ts` - Updated CaseStatus enum, added flags
- `migrations/036_case_lifecycle_redesign.sql` - Data migration script

### Backend
- `server/services/caseStateMachine.ts` - Complete rewrite with new transitions
- `server/routes/cases.ts` - Updated assignment, completion, flag updates

### Frontend
- `client/src/components/StatusBadge.tsx` - Updated status configurations
- `client/src/pages/Cases.tsx` - Updated tab filtering, button visibility, flag-based checks

---

## END OF IMPLEMENTATION

**Status:** ✅ All requirements implemented
**Next Steps:** Run migration script, test assignment flow, verify flag-based filtering

